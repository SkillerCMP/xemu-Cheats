#!/usr/bin/env python3
"""v3.14x SET_BEGIN_END / Vulkan draw-end observation-only source guard."""
from __future__ import annotations
import argparse, pathlib, re

def req(t,n,l):
    if n not in t: raise AssertionError(f"missing {l}: {n}")
def forbid(t,n,l):
    if n in t: raise AssertionError(f"forbidden {l}: {n}")
def between(t,a,b,l):
    try: return t[t.index(a):t.index(b,t.index(a)+len(a))]
    except ValueError as e: raise AssertionError(f"missing {l} bounds") from e

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); a=ap.parse_args()
    root=pathlib.Path(a.root); dbg=root/'ui/xui/debug-tools'; d=dbg/'addons/diagnostics'
    hook=(d/'pgraph-pusher-progress-trace-hook.h').read_text()
    ph=(d/'pgraph-pusher-progress-trace.h').read_text()
    pc=(d/'pgraph-pusher-progress-trace.c').read_text()
    dh=(d/'pgraph-draw-trace-hook.h').read_text()
    backend=(d/'diagnostics-backend.h').read_text()
    ui=(d/'diagnostics.cc').read_text()
    stub=(dbg/'addons/stubs/pgraph-pusher-progress-trace-stub.c').read_text()
    pgraph=(root/'hw/xbox/nv2a/pgraph/pgraph.c').read_text()
    vk=(root/'hw/xbox/nv2a/pgraph/vk/draw.c').read_text()

    # SET_BEGIN_END is split at the already-timed PFIFO puller boundary.
    req(hook,'uint32_t method_base, uint32_t parameter, const char *method_name','parameter identity handoff')
    req(ph,'XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_BEGIN','BEGIN variant ABI')
    req(ph,'XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_END','END variant ABI')
    req(ph,'uint32_t variant;','retained method variant')
    req(pc,'pending_method_base == 0x17FCu','SET_BEGIN_END variant gate')
    req(pc,'pending_parameter == 0','END parameter split')
    req(pc,'"%s(BEGIN)"','BEGIN readable name')
    req(pc,'"%s(END)"','END readable name')
    req(stub,'uint32_t method_base, uint32_t parameter, const char *method_name','stub signature')
    identity=between(pgraph,'uint32_t graphics_class =','if (subchannel != 0)','PGRAPH identity handoff')
    req(identity,'pusher_method_base, parameter,','parameter passed to diagnostics')
    forbid(identity,'qemu_clock_get_ns','identity handoff timer')

    # Existing hardware behavior remains one draw_begin / draw_end call each.
    be=between(pgraph,'DEF_METHOD(NV097, SET_BEGIN_END)','DEF_METHOD(NV097, SET_TEXTURE_OFFSET)','SET_BEGIN_END method')
    if be.count('d->pgraph.renderer->ops.draw_end(d);') != 1:
        raise AssertionError('SET_BEGIN_END must retain exactly one renderer draw_end call')
    if be.count('d->pgraph.renderer->ops.draw_begin(d);') != 1:
        raise AssertionError('SET_BEGIN_END must retain exactly one renderer draw_begin call')
    req(be,'pgraph_reset_inline_buffers(pg);','original inline buffer reset')
    req(be,'pg->primitive_mode = PRIM_TYPE_INVALID;','original END primitive reset')

    # Vulkan END work is decomposed only by observation calls.
    req(vk,'pgraph-draw-trace-hook.h','Vulkan draw trace hook include')
    for stage in (
        'VK_DRAW_END_TOTAL','VK_FLUSH_DRAW','VK_VERTEX_BIND','VK_ELEMENT_SCAN',
        'VK_SYNC_VERTEX_RAM','VK_REMAP_ATTRIBUTES','VK_PRE_DRAW','VK_PIPELINE_PREP',
        'VK_FRAMEBUFFER_PREP','VK_DESCRIPTOR_UPDATE','VK_COMMAND_BUFFER','VK_UPLOAD',
        'VK_BEGIN_DRAW','VK_RENDER_PASS','VK_PIPELINE_BIND','VK_DESCRIPTOR_BIND',
        'VK_ISSUE_DRAW','VK_END_DRAW','VK_SURFACE_DIRTY'):
        req(dh,'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_'+stage,stage+' hook enum')
        req(backend,'XEMU_DIAG_PGRAPH_DRAW_'+stage,stage+' backend enum')
        req(ui,stage,stage+' readable export/UI name')
        req(vk,'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_'+stage,stage+' Vulkan hook')
    draw_end=between(vk,'void pgraph_vk_draw_end(NV2AState *d)','static int compare_memory_sync_requirement_by_addr','Vulkan draw_end')
    if draw_end.count('pgraph_vk_flush_draw(d);') != 1:
        raise AssertionError('Vulkan draw_end must retain exactly one pgraph_vk_flush_draw call')
    if draw_end.count('pgraph_vk_set_surface_dirty(pg, color_write, depth_test || stencil_test);') != 1:
        raise AssertionError('Vulkan draw_end must retain exactly one surface-dirty call')
    req(ui,'Record long PGRAPH draw-end stages','draw-end UI control')
    req(ui,'SET_BEGIN_END / Renderer Draw-End Breakdown','targeted UI/export heading')
    req(ui,'variant=','method variant text export')

    universal='\n'.join([hook,ph,pc,dh,backend,stub,identity,draw_end])
    for x in ('45410049','0021ED87','0021EA70','81399000','8139A000'):
        forbid(universal,x,'Def Jam-specific constant')
    print('PASS: v3.14x SET_BEGIN_END / Vulkan draw-end breakdown source guard')
    return 0
if __name__=='__main__': raise SystemExit(main())
