#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 5: proven-dead surface and forwarding-wrapper guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    output = (debug / "debug-output-paths.hh").read_text(encoding="utf-8")
    current_h = (debug / "current-game.hh").read_text(encoding="utf-8")
    rpc_utils = (debug / "addons/hdd/kernel-rpc-utils.hh").read_text(encoding="utf-8")
    rpc = (debug / "addons/hdd/guest-kernel-rpc.cc").read_text(encoding="utf-8")

    # This background process-launcher had no caller in the complete reconstructed
    # source tree. Keep the live SDL main-thread directory opener unchanged.
    forbid(output, "OpenDirectoryDetached", "dead detached directory opener")
    forbid(output, "#include <glib/gstdio.h>", "unused GLib stdio include")
    forbid(output, "#include <cstdio>", "unused C stdio include")
    require(output, "inline bool OpenDirectory(Folder folder", "live directory opener")
    require(output, "SDL_OpenURL(uri)", "live SDL URL open behavior")

    # Per-row lookups use Labels()/generation-backed caches; this accessor had no
    # production caller anywhere in the reconstructed Xemu source tree.
    forbid(current_h, "PrimaryLabelAt(", "dead Current Game label accessor")
    require(current_h, "const XemuXbeLabels::Database &Labels() const { return m_labels; }",
            "authoritative Current Game label database accessor")
    require(current_h, "uint64_t LabelGeneration() const { return m_label_generation; }",
            "label-generation cache invalidation accessor")

    # Pass 4 introduced one authoritative LE64 decoder. Do not add another
    # forwarding name around it in Kernel RPC.
    forbid(rpc_utils, "inline uint64_t Le64(", "Kernel RPC LE64 forwarding wrapper")
    require(rpc_utils,
            "result.end_of_file = XemuDebugBinaryUtils::read_le64(data + 40u);",
            "direct shared LE64 decoder use")
    require(rpc_utils, "result.attributes = Le32(data + 48u);",
            "FileNetworkOpenInformation attributes decode")

    # Rename/Move still places the destination ANSI_STRING in the exact payload
    # offset; only the never-read derived address local was removed.
    forbid(rpc, "destination_ansi_address", "unused rename destination ANSI address local")
    require(rpc,
            "std::copy(dest_ansi.begin(), dest_ansi.end(), payload.begin()+kRenameDestinationAnsiOffset);",
            "rename destination ANSI payload placement")
    require(rpc,
            "XemuKernelRpc::StoreLe32(dest_ansi.data()+4, destination_path_address);",
            "rename destination path pointer encoding")

    # The separately supplied SDK archive is research/reference input only and
    # must never become a source/build dependency or provenance marker.
    forbidden_reference_tokens = ("XDk-5849", "XDK-5849", "5849.zip", "XDk_5849")
    production_suffixes = {".c", ".cc", ".cpp", ".h", ".hh", ".py", ".sh"}
    for path in debug.rglob("*"):
        if (not path.is_file() or "tests" in path.parts or
                path.suffix not in production_suffixes):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for token in forbidden_reference_tokens:
            forbid(text, token, f"reference-archive token in {path.relative_to(debug)}")

    print("PASS: Cleanup Pass 5 proven-dead surface/forwarder invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
