#!/usr/bin/env python3
"""Strict observation/ownership/ABI guard for the v3.14z all-draw profiler."""
from __future__ import annotations
import argparse, pathlib, re
from v314y_vulkan_observer_test_utils import DRAW_PATH, check_vk_observation_only, function, tokens

STAGES=('VK_TEXTURE_BIND','VK_SHADER_BIND','VK_PIPELINE_STATE_KEY',
        'VK_PIPELINE_CACHE_LOOKUP','VK_PIPELINE_BUILD_STATE','VK_PIPELINE_CREATE',
        'VK_PIPELINE_INSTALL')

def req(text, token):
    if token not in text: raise AssertionError('Missing: '+token)

def reject(source):
    try: check_vk_observation_only(source)
    except AssertionError: return
    raise AssertionError('unsafe renderer mutation was accepted')

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);a=p.parse_args()
    root=pathlib.Path(a.root);d=root/'ui/xui/debug-tools/addons/diagnostics'
    source=(root/DRAW_PATH).read_text();check_vk_observation_only(source)
    hook=(d/'pgraph-draw-trace-hook.h').read_text()
    backend=(d/'diagnostics-backend.h').read_text();ui=(d/'diagnostics.cc').read_text()
    core=(d/'pgraph-pusher-progress-trace.c').read_text();draw=(d/'pgraph-draw-trace.c').read_text()
    private=(d/'pgraph-draw-aggregate.h').read_text()
    for stage in STAGES:
        for text,prefix in ((source,'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_'),
                            (hook,'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_'),
                            (backend,'XEMU_DIAG_PGRAPH_DRAW_')):
            req(text,prefix+stage)
        req(ui,'return "'+stage+'"')
    # All pre-existing and new frontend enum values must match actual recorder ABI.
    h=re.search(r'typedef enum XemuDebugToolsPgraphDrawTraceStage \{(.*?)\}',hook,re.S)[1]
    b=re.search(r'typedef enum XemuDiagnosticsPgraphDrawTraceStage \{(.*?)\}',backend,re.S)[1]
    hn=re.findall('XEMU_DEBUG_TOOLS_PGRAPH_DRAW_(\\w+)',h)
    bn=re.findall('XEMU_DIAG_PGRAPH_DRAW_(\\w+)',b)
    assert hn[:-1]==bn and hn[-1]=='STAGE_COUNT'
    assert hn.index('VK_TEXTURE_BIND')==36  # All old numeric stage IDs preserved.
    for name in ('create_pipeline','create_clear_pipeline'):
        fn=function(source,f'static void {name}(PGRAPHState *pg)')
        assert fn.count('vkCreateGraphicsPipelines(')==1
        start=fn.index('XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PIPELINE_CREATE, pg, 0, 0')
        call=fn.index('VK_CHECK(vkCreateGraphicsPipelines(')
        finish=fn.index('XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PIPELINE_CREATE);')
        assert start < call < finish
        assert 'lru_lookup' not in fn[call:finish] and 'get_render_pass' not in fn[call:finish]
        hit=function(fn,'if (snode->pipeline != VK_NULL_HANDLE)')
        req(hit,'XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_HIT');req(hit,'return;')
        assert fn.count('XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_HIT')==1
        assert fn.count('XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_MISS')==1
    reuse=function(source,'if (r->pipeline_binding && !pipeline_dirty)')
    req(reuse,'XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_FAST_REUSE');req(reuse,'return;')
    req(core,'static __thread XemuDebugToolsPgraphPusherMethodWork g_method_work;')
    req(core,'PGRAPH_DRAW_AGGREGATE_STACK_CAPACITY 24')
    req(core,'g_method_work.generation == qatomic_read(&g_method_breakdown.generation)')
    req(core,'event.draw = g_method_work.draw;')
    req(core,'duration < 5000000ULL')
    agg=core[core.index('static bool pusher_draw_aggregate_active'):core.index('static void pusher_method_work_begin')]
    for prohibited in ('malloc','calloc','g_new','mutex','sleep','pgraph_reg','vkCreate','stl_le_p'):
        assert prohibited not in agg,prohibited
    for token in ('xemu_debug_tools_pgraph_draw_aggregate_begin(stage)',
                  'xemu_debug_tools_pgraph_draw_aggregate_end(stage)',
                  'aggregate_host_ns ? aggregate_host_ns'):
        req(draw,token)
    req(private,'uint64_t xemu_debug_tools_pgraph_draw_aggregate_begin')
    for token in ('DRAW_SUMMARY','DRAW_STAGE','self_ns=','cache_hit=','sub5ms=','Record PFIFO method-time breakdown'):
        req(ui,token)
    # Adversarial checks extend y's unchanged whole-file frozen renderer parity.
    for old,new in (
        ('XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_HIT);','r->framebuffer_index++);'),
        ('    pgraph_vk_bind_textures(d);','    pgraph_vk_bind_textures(d); pgraph_vk_bind_textures(d);'),
        ('if (r->pipeline_binding && !pipeline_dirty)','if (r->pipeline_binding)'),
        ('pgraph_vk_bind_textures(d);','pgraph_vk_bind_shaders(pg);'),
    ):
        assert old in source
        reject(source.replace(old,new,1))
    print('PASS: v3.14z stage ABI, cache-branch sites, bounded aggregate ownership, exports and four unsafe mutations')
    return 0
if __name__=='__main__':raise SystemExit(main())
