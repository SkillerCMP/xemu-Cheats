#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 12 + Windows build correction current Debug Tools production audit guard."""
from __future__ import annotations

import argparse
import hashlib
import pathlib

from v287_source_test_utils import extract_function, extract_member_functions

EXPECTED_PRODUCTION_FILE_COUNT = 170
EXPECTED_PRODUCTION_SHA256 = "823f69ea3507a7bab3e1a3eff9313beba701c16bbae91618b885d6a134b1b429"
EXPECTED_GUEST_METHOD_COUNT = 43
EXPECTED_UNCHANGED_GUEST_METHOD_COUNT = 37
EXPECTED_UNCHANGED_GUEST_METHOD_SHA256 = "3e67690eda61e9b9ef165f7198a97669bde0678b9c2ad380ccd101604b4d4957"
EXPECTED_CLEANED_GUEST_METHOD_SHA256 = "94e579bffbdc07e1c432f11408fb0b4227e124685e4809348c3f3cd8b2d9382f"

NON_RUNTIME_FILES = {
    "README.md", "CHANGELOG.md", "build-capstone.sh", "build-capstone-windows.sh",
    "build-keystone.sh", "prepare-build-dependencies.sh", "build-xemu.sh",
    "docker-build-windows.sh", "restore-executable-bits.py", "validate-project-layout.py",
}

REMOVED_LEGACY_GUEST_METHODS = {
    "BuildRecursiveDeletePlan",
    "DrawKernelDeleteConfirmation",
    "DrawKernelDeleteControls",
    "DrawKernelDeleteFolderConfirmation",
    "DrawKernelDeleteFolderControls",
    "DrawKernelImportConfirmation",
    "DrawKernelImportControls",
    "PrepareImportFolder",
    "RefreshDeleteCandidates",
    "RefreshDeleteFolderCandidates",
    "RefreshSelectedDeleteFolderPreview",
    "StartKernelDeleteSelectedFile",
    "StartKernelDeleteSelectedFolder",
    "StartKernelImportFolder",
}

CLEANED_GUEST_METHODS = {
    "DrawTestPanel", "HandleKernelDeleteCompletion", "StartHddDelete",
    "Tick", "TickWaitingSafePoint", "StartHddRelocate",
}

SCOPED_SHA256 = {
    # v2.88.1 startup-safe debugger F0 ownership lifecycle hotfix.
    "cheat-engine.hh": "d95f44e022bce2a293ba4be03aeb3ce4766560d1ff2aa0ee5eaa949a7e6c9400",
    "cheat-engine-source.cc": "22983413d1ce87045da91c00dbee52741a6e1d7efc386d98909711abb75edd86",
    # v2.88 Breakpoints/Changes debugger panel ownership.
    "addons/memory-tools/memory-tools-debugger-ui.cc": "f6cea8e1571dd23f85d6a17065bb34f87917676ad2a7b7c246be5de9c2423afb",
    "addons/memory-tools/memory-tools-inject-ui.cc": "9b220407b9a72db8d9cb4e5c27a69b95502066986392ecab0ea82e0c5f92a145",
    "addons/memory-tools/memory-tools-inject.cc": "c6b8c97db0a47d1b5f9b097ac276d37f4f93e9e655b857e33c0ef91a86f138ea",
    "addons/memory-tools/memory-tools.hh": "001bc6d84c6a96cc632ee31e8c46784444d5b268af82130ae0f2bf3ed42fcc6e",
    "cheat-engine-memory.h": "07a26b99506f2668c4a7d54de3c9d99ccb5786ac4083df24cb7b4af1ecf851ed",
    "external-code-memory.c": "19c792b0dd3ebf61a57e3bc384870df513af404844b43b106d225f70f60420dd",
    "current-game.cc": "39f30ac5ff0bc1463a81d4c70d9ee28687598dfc85e63a750715ccfc566eb9eb",
    "current-game.hh": "a8959596492e693c1da03c3d8b0ff7b57554a109299d48c29ca89449da6c5fde",
    "addons/hdd/guest-kernel-rpc-completion.cc": "f751e173083b16ea1f0db3858e162a75eb344ce5bd401476e022ff284966bc6f",
    "addons/hdd/guest-kernel-rpc-filesystem.cc": "ed0bbbb638aec3b2c6dd0498665c0eec946d7a271dfadf99f738f2635aa0126b",
    "addons/hdd/guest-kernel-rpc-status.hh": "bc91f4e72568e786bb6f5519805b6b9afed3e3a085fff2ff86c8eb4a07aa4e27",
    "addons/hdd/guest-kernel-rpc-ui.cc": "87310ad22b4fbb3dfc5071fc54ecbaaa920cb8485fbfe8728c6e0e9928b555f3",
    "addons/hdd/guest-kernel-rpc.cc": "da9dae07a9a9997e655b139d55d4d6c2133f5c6f1b0ee8acadb64f0d1231fc1c",
    "addons/hdd/guest-kernel-rpc-memory.c": "1fdca5b343b0a9a5345e23d3eb085a2c50708bcebf6e0f48a314a89838b01342",
    "addons/hdd/guest-kernel-rpc.hh": "a819fbb6f39fcefea307cc55bb6d3b7f38f0819c2046e144a99ade09aae2a0a8",
    "guest-pause-guard.hh": "2973d651414a7ca4d906eaf6d892a637a11f82ec13ca3642a95f25128e89cf27",
    # Pass 12 Windows build correction: keep QEMU main-loop C headers out of C++.
    "guest-pause-guard.cc": "d8ba1ef85d4add7c2ada2b447fff85b8b7fc8984dd4b7aac9b23d9f2e16d4f93",
    "addons/hdd/hdd-directory.hh": "3c8946391c6e5eb2ad3df1018096795a265fafa2b98d9ee98324721886f1c31c",
    "addons/hdd/hdd-export-service.cc": "361d55cf025a9dd2c374f5596e62061d60ab6e39084c58dac50ee4eae2ec694e",
    "host-export-utils.hh": "dc0630d958eec4643fdf4ca0ef444c3afc1ca927405486ee5193d51df1b1562f",
    "addons/hdd/kernel-rpc-filesystem.cc": "229023ce8d542b928e5519e45ec9897e47b5bb2852d383407adb63ad478aab55",
    "addons/hdd/kernel-rpc-filesystem.hh": "1bcc1b3ae5060e4b5f73e28560deb840957f1210c2dfc6ed43e50818853dc818",
    "addons/hdd/kernel-rpc-utils.hh": "d0803273ca7ecbba16f02844129841fd3440bc79b39d061b6a162a13ad80249b",
    "label-packs.cc": "3d34cd4b0df60559f18b2877ec8ffa31f4084b6816ba595fa364e91d625befaf",
    "label-symbol-utils.hh": "19f796f4b9b01dd1a3d19a42729e4245691b50278cad02be9a26a6b6ab93829e",
    "map-labels.cc": "b8002332a41c80ff2d6eb12264782349e1b5701dd2beac18a3fa2395584cf124",
    # v2.91.10 Diagnostics is a physical full-profile add-on. The UI/registration
    # remain in xemu_ss while its Xbox/CPU-facing backend is target-specific.
    "meson.build": "8384050569aae622e7d36111d69f2956328aebdfbcc4d3712175317ec082d399",
    "debug-tools.cc": "c367b0757dd7fb1ab65d8da1b8c8f06a34d9b1d37aee48e1c9745c26017ab84e",
    "debug-tools.hh": "8cf482b9ba673eb1feaf2a71022cb76f0baf2bbdb8246b39a90e557f67c259d2",
    "debug-tools-module.hh": "75de317da4fb88d15cdae54a6bcf415e30fd8d0dcda2e5467c4274524869d043",
    "addons/diagnostics/debug-tools-diagnostics-addon.cc": "fc2f6336dec19f1dfa6000746d5df12bddbdac5eb96eaddbad44d5a039abac77",
    "addons/diagnostics/diagnostics.cc": "268c9ea6e39819ffed0f9813f5b04572f0fdedd7e1c1826784ac41fa25a2a5da",
    "addons/diagnostics/pgraph-ptimer-latency-trace.c": "9ae5d0da3c38425855db54970f2e4f63f1b43b2134fef46a2a1f8a116f2d099e",
    "addons/diagnostics/diagnostics.hh": "f0a26095cd592f735656d35288addd75345faa6e91705161b86a989f5f167a04",
    "addons/diagnostics/diagnostics-backend.c": "122e3a5da1241a2fe0b6270a542b1252ce2cc37310b8e7e19ccfd1c223429b91",
    "addons/diagnostics/diagnostics-cpu-context.h": "5aaf64a7fd90b0b646286271746a5ec2a934d2e5a840b911c123df1371ff204a",
    "addons/diagnostics/diagnostics-ptimer-utils.h": "572388cf684a389bc336b96eaa3fe1932c1f098452d65121c63e83e067503fb0",
    "addons/diagnostics/ptimer-trace-hook.h": "b37dbbb78c9b0b31317ffb567cd303303f9e95d45f9db8988c88a5eb630f361a",
    "addons/diagnostics/ptimer-trace.h": "00beb91dc8a8725f3f876ad6cfa9f4ef39b9b7537a628fd65793e2b8012f6c6b",
    "addons/diagnostics/ptimer-trace.c": "37cc97fda523330cfe9acd956614c6da2c15ad50f8730f82383e3f9489fd6a7b",
    "addons/diagnostics/diagnostics-backend.h": "f4ebc766a6e0d83071514abe6b278f891c02611845735b46c04729fca04d0484",
    # Cleanup Pass 9 shared PGRAPH/PTIMER latency record ownership.
    "addons/diagnostics/pgraph-ptimer-latency-trace-hook.h": "cf18c1b41be46812fdc2d48f69e3eedce375175aad6620926798b1031dda2fe4",
    "addons/diagnostics/pgraph-ptimer-latency-trace-types.h": "31bbdf23c9cf37f12a340d42f1088412dd3d80e931fc52f8d639ed5dba98dae0",
    "addons/stubs/debug-tools-diagnostics-addon-stub.cc": "d4466840206773e967e6e3ed073f5f6c52042f30d9250a3f6f107f5d1a619028",
    "addons/stubs/ptimer-trace-stub.c": "404496c1881fb75b570bcdcf54c8effae00871ebf319793acd20fbd65b944759",
    # v2.94 generated-output layout + QEMU timer-dispatch recorder.
    "debug-output-paths.hh": "52be9aa52abc042b216fd508f935fc495c42c66be7bda6006fc1af6f2e29f1c0",
    "addons/diagnostics/qemu-timer-trace-hook.h": "0fcc79db680af2385f82e85e94c0b4a5ec48d5bdb7c39daa07e767cf2fe0e3f3",
    "addons/diagnostics/qemu-timer-trace.h": "0bad27e91d93ce33891114707db2aa5251bba8c82fd14cb66f31466cb3d92d96",
    "addons/diagnostics/qemu-timer-trace.c": "6cd459fe3f5b993a23df4f2cd9a1b67d716bca7b1cda0cf81a6819985874422e",
    "addons/stubs/qemu-timer-trace-stub.c": "e3127810f446a89d6396cda059ed38d5b8e79d92a1d5f0c54ac3064ee45dbbdc",
    # v3.02 lightweight slow QEMU timer callback detector.
    "addons/diagnostics/slow-timer-trace-hook.h": "bc9f1c462ce6ef0ce299c2e775767ea23e46c5d417d62392a84b2b9d546ba801",
    "addons/diagnostics/slow-timer-trace.h": "804de50673ad42ec9cae66db47bc0f0ad27f01985c8a61d1c1206679bbe9967c",
    "addons/diagnostics/slow-timer-trace.c": "8f49da7f92d0a08cd69995841f6207df9a3527c38ed0d09852647ac933bcc926",
    # v3.03 OHCI slow-frame stage profiler.
    "addons/diagnostics/ohci-slow-frame-trace-hook.h": "9e20140ca9fc42fdc3bd6abcd8f95365e03180e5122b101e6afd5959191de49d",
    "addons/diagnostics/ohci-slow-frame-trace.c": "1bf3bcfc0d7ee4fffe757c3d034b14f3f5636d1727ba34643abead94d845e00e",
    "addons/stubs/ohci-slow-frame-trace-stub.c": "2ab583a660230897cb461298d85fafddd32c546aa10b404e2168515db481cb7c",
    # v3.04 targeted controller input-poll stage profiler.
    "addons/diagnostics/controller-input-poll-trace-hook.h": "0e510da21ef57b3136375e88cae21f9516098617d8fee8e2b26db51bfca52920",
    "addons/diagnostics/controller-input-poll-trace.c": "76e91763234b329ac8c96ff15aec8d2d4200bed3e1ec0baa84f81aba412ec8ff",
    "addons/stubs/controller-input-poll-trace-stub.c": "f865703dc5d276051fa3e9782b0ebddb927c813905ee70e0783d707cc746910f",
    # v2.97 BQL Ownership Trace: lock-free Diagnostics state + non-full stub.
    "addons/diagnostics/bql-trace-hook.h": "4e4889785290881823b679c420aa0a40e6d8297f003285ed14edfbb22414d08c",
    "addons/diagnostics/lock-trace-common.h": "72df7346bb1ddfd6e0df97d9d798b5069ff01730bcee622e62cbd195952dfc64",
    "addons/diagnostics/lock-trace-common.c": "3ed2643ca8f8bfff685ff34686c87952b0eda4b173ee86071b4ca3fd2dbf053e",
    "addons/diagnostics/bql-trace.h": "b3f1178043d9b3c862ad5749a7146600641a9b89ce7337a604b1441b7b8eef9f",
    "addons/diagnostics/bql-trace.c": "b391723334efcf5a5e985deb9320c8814b200b808c92e7224da21ad033254a3b",
    "addons/diagnostics/main-loop-lock-trace-hook.h": "eccd54d8ae6ed3a9b55698299e50fc3707f63f8ea479a191905facb6867a79fb",
    "addons/diagnostics/main-loop-lock-trace.h": "017aba793f5cc2f8daca4bb235b190b7d348bddb54a9ab94ae3a3d4e9383fb92",
    "addons/diagnostics/main-loop-lock-trace.c": "272ddbbfcedb3c32551e231b299c7d76c68dc9bdf307e68843400a955683df36",
    "addons/stubs/bql-trace-stub.c": "e095d9394882b23a6da1814b00a6fc647fa5489ed2f65f95894664a2f8af0d87",
    # v2.98 MMIO Dispatch Trace: lock-free long-dispatch recorder + non-full stub.
    "addons/diagnostics/mmio-trace-hook.h": "2b51c024b3aa61a32b9c93ae7ff70f2595a9b1a9344a372fcd55eb255e446c7d",
    "addons/diagnostics/mmio-trace.h": "02263fb33bf05ca5dcd0ac5272a752636f10ecddf5fdd36c39860412bd67cf54",
    "addons/diagnostics/mmio-trace.c": "92972b94505ab4ce1406c8aa73eadc229c5fce88fad21318abdd23bdb2226ea7",
    "addons/stubs/mmio-trace-stub.c": "52ce342f8f0173a19074bb62b94d2ca8357c22f8785c28ccbf4ffc52bf7a4cf4",
    # v2.99 PGRAPH Lock Ownership Trace: lock-free owner/method recorder + stub.
    "addons/diagnostics/pgraph-lock-trace-hook.h": "d9a5769f5ce4298e2326fe8b7d7977887eb4c63c1b805386fce444e5ac0557b9",
    "addons/diagnostics/pgraph-lock-trace.h": "c3642362e002b464327b449e456c16f1acfaa89f21a485a8cf562f9c8f1bfea9",
    "addons/diagnostics/pgraph-lock-trace.c": "8aa796a9c0f02f56e7b8bc20ff9f0cdcdf371c1d79d03978b48370b67ffb2824",
    "addons/stubs/pgraph-lock-trace-stub.c": "7878fcfe430f179d4f75bb1154abca6c3e8a702bdd3b323559d38f2f0b5c6a7e",
    # v3.00 PGRAPH Draw-End Stage Trace: long-draw TLS staging + lock-free ring.
    "addons/diagnostics/pgraph-draw-trace-hook.h": "3dd3737943647fba5d2f3e1fd4e89bcaba5e1d1f4036955ef413a61aab6def71",
    "addons/diagnostics/pgraph-draw-trace.h": "14e7fef211cc0f0319141cff3d43408ff256f9b0d1a7f8a43c1255453e516e58",
    "addons/diagnostics/pgraph-draw-trace.c": "e4f5d666ee5c6d785dbc151cfcbb4aa9d13b39b9446a3dbc6094f9e82b8eea2d",
    # v3.09 FLIP_STALL/VBlank lifecycle recorder + non-Full stub.
    "addons/diagnostics/flip-stall-trace-hook.h": "bbb44134702c32609cc82b5780d1cf03e16f996efd4dbe95331ba60058c616c7",
    "addons/diagnostics/flip-stall-trace.h": "874570c19990c14ba18a93ea5f44c6e4715d747108b372c244b5a99b68410ca6",
    "addons/diagnostics/flip-stall-trace.c": "7b1190155d7edc506dc76684d13f2731406f78c867a5979e93d5644a63b3a441",
    "addons/stubs/flip-stall-trace-stub.c": "4226abe0df4a16573a5afeb17325a9827657b59739f6af43a2a5fc51a11b5143",
    # v3.10 Xbox scheduler/thread-wake investigator + non-Full IRQ hook stub.
    "addons/diagnostics/scheduler-trace-hook.h": "b3c185e38c9fe74521816476ba23a13c52fe4c2069aa9608205876b3f84a722f",
    "addons/diagnostics/scheduler-trace.h": "51b6002295b417ed6d2b79c6cf8812ed2773535a10386f29fe3cf8e8d51c9f25",
    "addons/diagnostics/scheduler-trace.c": "6fab2c25aa6a3b5273f1bb1fc4cf6acf0d9a5ea2d762f13f73327290ebcb37e8",
    "addons/stubs/scheduler-trace-stub.c": "81f9f66dfa946ff9672f98a7a17b57ccaf5a7e9d9aee8c16a010e9748328682f",
    "addons/stubs/pgraph-draw-trace-stub.c": "867a5b04b584d1446bef37987f6e8e4107c9705888e80b812405ba9b4d70f274",
    # v3.07 Controller/XID reconnect diagnostics: Full-only recorder + non-Full stub.
    "addons/diagnostics/controller-xid-trace-hook.h": "224dce977d3456da2be4ad019dbe29fff14346793ec5751ee142470ea762957d",
    "addons/diagnostics/controller-xid-trace.h": "fb0951a8990a89280191de53b88b4d9713d5e678e056c46e303366a798a6932b",
    "addons/diagnostics/controller-xid-trace.c": "84aaf2f633a5f77466684d49607a24421c70dd0c16cf64cdb48a463dfea68e37",
    "addons/stubs/controller-xid-trace-stub.c": "cf4645188349bc9dac8c4fb5c8ba440a17ba34567d8ea0ff4aeabf1a8fd42bf7",
    # Cleanup Pass 8 shared timestamp/export result + note cleanup.
    "host-export-result.hh": "92eb06c8b280b83daede0e00f7aef32d7f0f0fdae2d615eff81d08663d4a995e",
    "xdvdfs-export-service.hh": "63123853ce9d42feded3b2bb44732c8b7fbfe4b6f23870a37d5dacbf0ecb8cc6",
    "addons/hdd/hdd-export-service.hh": "6eed6a2bbea5e8ab9808f1618869f2b8c83bd2493a41cbda0165d028914038f6",
    "addons/memory-tools/memory-tools-internal.hh": "b03b5aa2e467fbf1ab8eb36fb4647651ee27f1befadd0b6630f2c08c91984db4",
    "cheat-engine-memory.c": "0f01f7497b7464b342a663a5dd8ad1246af5324934596fd5a22878af73bb2940",
    "addons/memory-tools/memory-tools-dump.cc": "716f6d4ff1080ed6d76205d2e3c64792d38a997397dc71edd3c848786378ad81",
    "addons/memory-tools/memory-tools-dump-ui.cc": "f21fa78c152c6adc48c9b6d53879d9da4919071b7f892255b97dc63d9741960a",
    # v2.91.9 x86 Execution Trace: entirely owned by the Memory Tools add-on
    # and the existing debugger backend bridge; no new master-side hook.
    "addons/memory-tools/debug-tools-memory-tools-addon.cc": "eba08c270f7d9e3758aeaeeba3d15b0760492617ddb8d351fd4a53401a79b267",
    "addons/memory-tools/execution-trace.cc": "35219545547f67551ef82fb6f0ef0c31ae23454b4a8f22c3790af54506ee855f",
    "addons/memory-tools/execution-trace-ui.cc": "c0832b712ab82f528a93206f8e825c7e5b1354c09b3b78c08e3f06bf3b2a8a56",
    "addons/memory-tools/memory-tools.cc": "c02a188bb33c3f8819999310862f8d2c18aacb34603e8d219fddaea320163616",
    # v3.07 Guest Input Investigator: TCG profiler + standalone Memory Tools UI.
    "addons/memory-tools/guest-input-profiler-hook.h": "156c47e67e810680cbd710819c31853b4bf353868b969b84eb5c596afb48b813",
    "addons/memory-tools/guest-input-profiler.c": "e10f3df3aede84fa98862ca52d1e5236f4e01157d4d74e3ead4df54b7530eafd",
    "addons/memory-tools/guest-input-investigator.hh": "ca1a9de4813dc3121c4c0b041a61a9e943107534fbac71fde352bfa8e537c689",
    "addons/memory-tools/guest-input-investigator.cc": "b7459b0da582ce2d172a39cf363e7eefd6767d53221d69974751f4cd234af0a5",
    "addons/stubs/guest-input-profiler-stub.c": "8845c21c4338d71bb12a700943e78c50bada31234a2c3f18cf5724673c193902",
    "backend/xemu-dbg.c": "ab118fd0771fc3850213c4b4740263b6888c45a24dedc16389a2415a2c8ff531",
    "backend/xemu-dbg.h": "a13b3e885cebdc8f7d4a722975021e66207aa9ae55a75cba9a61a04ccf0e07b2",
    # Cleanup Pass 7 proven-dead API/surface pruning.
    "disc-block-ref.hh": "63602b36bfd6ff329df50f9242bb59651b56379504569b9c3bb1a8d71e156d56",
    "xbe-labels.cc": "7ea4c1b62c4fe8f7a44a8e5a3b55ca6564aacfce3d542bb0dfc8eca7911517fa",
    "xbe-labels.hh": "265fdd9b9931e70217318d13f1e615b9d639ab1e23e42ace47df4110d3b77fe7",
    "backend/whpx-debug.c": "59dab42ded910a7c099a92c3f9f308fd70c5077f6ee3c4e0009b2fa02d60c718",
    "backend/whpx-debug.h": "c95e33434713fe2cd81b5679a69ab86ac7ad9d08b182a07788fa165e68035069",
    # v2.90 single-backend F0/Change IA-32 assembly ownership.
    "cheat-engine-fhooks.cc": "ace5f8909dc0a03e3befa261d38fcbfcdbc469a664ca7ce42f174d15addb3fbe",
    "x86-cheat-assembler.cc": "3a17450ff52e7a6c695d9da706fb10643d2c550b4520d7a34b95ebe4d3caaf26",
    "x86-cheat-assembler-keystone.cc": "e849c4aa2486bc5a8f7d9727bc4e0c10d83f4159b1cbccdc7a339a1b53b6a392",
    "x86-cheat-assembler.hh": "775802aeff53a005167d37e97657097dd0a332d01b96f0d532d03f825161fce2",
    "x86-cheat-assembler-internal.hh": "40098a6b2a9744ae15fc41e5e428036e8e7654cb6ad5f3c68be61f18ef2d3148",
    "pdb-labels.cc": "502414b1c779080001690ad1d3f489041d944939504a1e887ef62fa3edc2ff50",
    "xdvdfs-export-service.cc": "e28f386b5e14520d8a6f320de459671aa27d102e2d2e47f3d4ddf734e72e58d1",
}


def require(text: str, needle: str, what: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {what}: {needle}")


def forbid(text: str, needle: str, what: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {what}: {needle}")


def production_digest(debug: pathlib.Path) -> tuple[int, str]:
    digest = hashlib.sha256(); count = 0
    for path in sorted(p for p in debug.rglob("*") if p.is_file()):
        relp = path.relative_to(debug); rel = relp.as_posix()
        if "tests" in relp.parts or rel in NON_RUNTIME_FILES:
            continue
        rb = rel.encode("utf-8"); data = path.read_bytes()
        digest.update(len(rb).to_bytes(4, "little")); digest.update(rb)
        digest.update(len(data).to_bytes(8, "little")); digest.update(data)
        count += 1
    return count, digest.hexdigest()


def body_digest(records: list[tuple[str, str]]) -> str:
    digest = hashlib.sha256()
    for name, body in sorted(records):
        digest.update(name.encode("utf-8")); digest.update(b"\0")
        digest.update(body.encode("utf-8")); digest.update(b"\0")
    return digest.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    actual = production_digest(debug)
    expected = (EXPECTED_PRODUCTION_FILE_COUNT, EXPECTED_PRODUCTION_SHA256)
    if actual != expected:
        raise AssertionError(f"current production surface changed (files={actual[0]}, sha256={actual[1]})")
    for rel, expected_sha in SCOPED_SHA256.items():
        got = hashlib.sha256((debug / rel).read_bytes()).hexdigest()
        if got != expected_sha:
            raise AssertionError(f"audited production file changed: {rel} ({got})")

    guest_files = (
        "addons/hdd/guest-kernel-rpc.cc", "addons/hdd/guest-kernel-rpc-ui.cc",
        "addons/hdd/guest-kernel-rpc-completion.cc", "addons/hdd/guest-kernel-rpc-filesystem.cc",
    )
    guest = "\n".join((debug / rel).read_text(encoding="utf-8") for rel in guest_files)
    # Cleanup Pass 5 removes one never-read local from BeginKernelRelocateAttempt.
    # Reinsert it only for the historical method-body digest so this guard still
    # freezes every behavior-bearing byte in the previously protected methods.
    pass5_anchor = "    const uint32_t source_oa_address = base + kRenameSourceObjectAttributesOffset;\n"
    pass5_dead_local = "    const uint32_t destination_ansi_address = base + kRenameDestinationAnsiOffset;\n"
    if guest.count(pass5_anchor) != 1 or pass5_dead_local in guest:
        raise AssertionError("Cleanup Pass 5 rename-address normalization precondition changed")
    guest_for_historical_digest = guest.replace(pass5_anchor, pass5_anchor + pass5_dead_local, 1)
    records = extract_member_functions(guest_for_historical_digest, "GuestKernelRpcManager")
    names = {name for name, _ in records}
    if len(records) != EXPECTED_GUEST_METHOD_COUNT:
        raise AssertionError(f"unexpected GuestKernelRpcManager method count: {len(records)}")
    if names & REMOVED_LEGACY_GUEST_METHODS:
        raise AssertionError(f"retired Kernel RPC diagnostic mutation methods returned: {sorted(names & REMOVED_LEGACY_GUEST_METHODS)}")
    unchanged = [(n, b) for n, b in records if n not in CLEANED_GUEST_METHODS]
    cleaned = [(n, b) for n, b in records if n in CLEANED_GUEST_METHODS]
    if len(unchanged) != EXPECTED_UNCHANGED_GUEST_METHOD_COUNT or body_digest(unchanged) != EXPECTED_UNCHANGED_GUEST_METHOD_SHA256:
        raise AssertionError("a Guest Kernel RPC method outside the approved cleanup/hotfix bodies changed unexpectedly")
    if body_digest(cleaned) != EXPECTED_CLEANED_GUEST_METHOD_SHA256:
        raise AssertionError("an approved cleanup/hotfix Guest Kernel RPC body changed without audit update")

    core = (debug / "addons/hdd/guest-kernel-rpc.cc").read_text(encoding="utf-8")
    ui = (debug / "addons/hdd/guest-kernel-rpc-ui.cc").read_text(encoding="utf-8")
    completion = (debug / "addons/hdd/guest-kernel-rpc-completion.cc").read_text(encoding="utf-8")
    filesystem = (debug / "addons/hdd/guest-kernel-rpc-filesystem.cc").read_text(encoding="utf-8")
    header = (debug / "addons/hdd/guest-kernel-rpc.hh").read_text(encoding="utf-8")
    status = (debug / "addons/hdd/guest-kernel-rpc-status.hh").read_text(encoding="utf-8")

    forbid(core, "ImGui::", "ImGui ownership in Kernel RPC scheduling core")
    forbid(core, '#include "../common.hh"', "UI common header in Kernel RPC core")
    forbid(core, '#include "../misc.hh"', "UI/file-dialog header in Kernel RPC core")
    ui_names = {n for n, _ in extract_member_functions(ui, "GuestKernelRpcManager")}
    if ui_names != {"DrawTestPanel"}:
        raise AssertionError(f"unexpected Kernel RPC UI ownership after dead-code cleanup: {sorted(ui_names)}")
    for button in ('RUN HARMLESS IRQL TEST', 'RUN READ-ONLY FILE TEST', 'RUN PATH DIAGNOSTICS'):
        require(ui, button, f"retained diagnostic button {button}")
    for legacy in REMOVED_LEGACY_GUEST_METHODS:
        forbid(header + guest, legacy, "retired diagnostic mutation method")
    forbid(header, "KernelDeleteSingleFile", "retired standalone delete mode")
    for field in ("m_delete_candidates", "m_delete_folder_candidates", "m_import_area_index",
                  "m_delete_confirm_pending", "m_import_confirm_pending"):
        forbid(header, field, "retired diagnostic mutation state")

    for token in ("IrqlName", "NtStatusName", "kDeleteIrqlOffset", "kImportIrqlOffset",
                  "kSafePointSampleIntervalMs"):
        require(status, token, f"shared Kernel RPC status helper {token}")
    for duplicate in ("const char *IrqlName(", "const char *NtStatusName(",
                      "constexpr uint64_t kSafePointSampleIntervalMs"):
        forbid(core + completion, duplicate, "duplicate Kernel RPC status implementation")

    # Production delete/import still uses the same kernel-owned mutation path.
    start_delete = extract_function(filesystem, "bool GuestKernelRpcManager::StartHddDelete(")
    require(start_delete, "BuildRawPartitionSetSnapshot", "fresh delete start snapshot")
    require(start_delete, "XemuKernelFs::SameDeletePlan", "fresh delete-plan identity gate")
    require(start_delete, "LoadRecursiveDeleteEntry", "kernel delete entry executor")
    delete_completion = extract_function(completion, "void GuestKernelRpcManager::HandleKernelDeleteCompletion(")
    require(delete_completion, "BuildRawPartitionSnapshot", "fresh post-delete FATX verification")
    forbid(delete_completion, "m_delete_candidates", "retired candidate fallback")
    start_import = extract_function(filesystem, "bool GuestKernelRpcManager::StartHddImport(")
    require(start_import, "SameImportPlan", "fresh import-plan identity gate")
    require(start_import, "LoadKernelImportOperation", "kernel import executor preparation")
    for token in ("m_import_write_status", "m_import_flush_status", "m_import_close_status",
                  "BuildRawPartitionSnapshot("):
        require(completion, token, f"write/flush/close/fresh-verify contract token {token}")

    host = (debug / "host-export-utils.hh").read_text(encoding="utf-8")
    hdd_export = (debug / "addons/hdd/hdd-export-service.cc").read_text(encoding="utf-8")
    xdvdfs_export = (debug / "xdvdfs-export-service.cc").read_text(encoding="utf-8")
    for helper in ("IsReservedWindowsDeviceName", "HostSafeName", "NumberedCandidate",
                   "OpenUniqueHostFile", "CreateUniqueHostDirectory"):
        require(host, helper, f"shared host-export helper {helper}")
    require(host, "constexpr unsigned kUniquePathAttempts = 10000;",
            "shared bounded unique-path attempt count")
    open_unique = extract_function(host, "inline bool OpenUniqueHostFile(")
    require(open_unique, "O_EXCL", "shared atomic create-new file ownership")
    require(open_unique, "g_remove(candidate.c_str())", "shared failed-open cleanup")
    create_unique = extract_function(host, "inline bool CreateUniqueHostDirectory(")
    if create_unique.count("ec == std::errc::file_exists") != 1:
        raise AssertionError("shared export directory collision retry changed")
    for service, text in (("HDD", hdd_export), ("XDVDFS", xdvdfs_export)):
        forbid(text, "bool OpenUniqueHostFile(", f"duplicate {service} export file-claim helper")
        forbid(text, "bool CreateUniqueHostDirectory(", f"duplicate {service} export directory-claim helper")
        forbid(text, "O_EXCL", f"duplicate {service} exclusive-create mechanism")
        require(text, "using XemuHostExportUtils::OpenUniqueHostFile;",
                f"{service} shared unique-file delegation")
        require(text, "using XemuHostExportUtils::CreateUniqueHostDirectory;",
                f"{service} shared unique-directory delegation")
    require(xdvdfs_export, 'using XemuDebugBinaryUtils::range_inside;', "shared XDVDFS range helper")
    forbid(xdvdfs_export, "bool RangeInside(", "duplicate XDVDFS range helper")

    hdd_hh = (debug / "addons/hdd/hdd-directory.hh").read_text(encoding="utf-8")
    pause_hh = (debug / "guest-pause-guard.hh").read_text(encoding="utf-8")
    memory_h = (debug / "cheat-engine-memory.h").read_text(encoding="utf-8")
    forbid(hdd_hh, "HasSnapshot()", "unused HDD snapshot accessor")
    forbid(pause_hh, "WasRunning()", "unused guest-pause accessor")
    forbid(memory_h, "Legacy newline-delimited virtual-only text helper", "stale orphan comment")

    # Final whole-tree cleanup: no dead public accessors or retired filesystem
    # compatibility wrappers may creep back into production.
    current_cc = (debug / "current-game.cc").read_text(encoding="utf-8")
    current_hh = (debug / "current-game.hh").read_text(encoding="utf-8")
    for accessor in ("LoadedLabelPacks()", "LoadedMapPath()", "LoadedPdbPath()", "XbePdbIdentity()"):
        forbid(current_hh, accessor, "unused Current Game accessor")
    require(current_cc, "template <typename Output>", "shared local-file reader template")
    require(current_cc, "static bool read_local_file(", "shared local-file reader")
    if current_cc.count("static bool read_local_file(") != 1:
        raise AssertionError("duplicate Current Game local-file reader returned")
    for wrapper in ("read_local_binary_file", "read_local_text_file"):
        forbid(current_cc, wrapper, f"retired Current Game local-file forwarding wrapper {wrapper}")
    require(current_cc, "read_local_file(path, 64ull * 1024ull * 1024ull,",
            "direct bounded MAP read through shared local-file reader")
    require(current_cc, "read_local_file(path, 512ull * 1024ull * 1024ull,",
            "direct bounded PDB read through shared local-file reader")

    label_utils = (debug / "label-symbol-utils.hh").read_text(encoding="utf-8")
    map_labels = (debug / "map-labels.cc").read_text(encoding="utf-8")
    pdb_labels = (debug / "pdb-labels.cc").read_text(encoding="utf-8")
    require(label_utils, "sort_and_dedupe_labels", "shared label sort/dedupe helper")
    require(map_labels, "XemuLabelSymbolUtils::sort_and_dedupe_labels(labels);", "MAP shared label cleanup")
    require(pdb_labels, "XemuLabelSymbolUtils::sort_and_dedupe_labels(labels);", "PDB shared label cleanup")

    kernel_fs_cc = (debug / "addons/hdd/kernel-rpc-filesystem.cc").read_text(encoding="utf-8")
    kernel_fs_hh = (debug / "addons/hdd/kernel-rpc-filesystem.hh").read_text(encoding="utf-8")
    retired_backend = (
        "FatxPathFromComponents", "NativeEPathFromComponents",
        "ValidateCurrentTitleDataPath", "BuildRecursiveDeletePlan",
        "BuildImportPlan", "ValidateImportHostPlan",
        "ValidateImportDestinationAvailable", "ValidateImportHostEntry(",
    )
    for symbol in retired_backend:
        forbid(kernel_fs_cc + kernel_fs_hh, symbol, "retired test-era filesystem wrapper")
    for field in ("std::string area;", "std::string title_directory;", "uint32_t title_id = 0;"):
        forbid(kernel_fs_hh, field, "retired TransferPlan metadata")
    for phase in ("Mutating", "Verifying"):
        forbid(header, phase, "unused filesystem operation phase")
    forbid(hdd_hh, "Snapshot()", "unused HDD snapshot accessor")


    # Final duplicate-helper audit: keep the stable KRPC public names while
    # delegating byte decoding to the shared binary helpers, and reuse the
    # shared ASCII case helper in portable label packs.
    krpc_utils = (debug / "addons/hdd/kernel-rpc-utils.hh").read_text(encoding="utf-8")
    require(krpc_utils, '#include "binary-utils.hh"', "shared KRPC binary helper include")
    require(krpc_utils, "return XemuDebugBinaryUtils::read_le16(p);", "shared KRPC LE16 decode")
    require(krpc_utils, "return XemuDebugBinaryUtils::read_le32(p);", "shared KRPC LE32 decode")
    label_packs = (debug / "label-packs.cc").read_text(encoding="utf-8")
    require(label_packs, '#include "label-symbol-utils.hh"', "shared label-pack case helper include")
    forbid(label_packs, "static std::string upper(", "duplicate label-pack uppercase helper")
    require(label_packs, "XemuLabelSymbolUtils::upper_ascii(", "shared label-pack uppercase helper")

    meson = (debug / "meson.build").read_text(encoding="utf-8")
    require(meson, "'addons/hdd/guest-kernel-rpc-ui.cc',", "Kernel RPC UI Meson registration")

    print("PASS: v3.15 Cleanup Pass 12 production audit includes the Windows compile correction while preserving historical contracts")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
