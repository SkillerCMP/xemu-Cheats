#!/usr/bin/env python3
"""v3.14v D3D pusher/GPU-progress correlation + conservative resolver guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"forbidden {label}: {needle}")


def between(text: str, start: str, end: str, label: str) -> str:
    try:
        a = text.index(start)
        b = text.index(end, a + len(start))
    except ValueError as exc:
        raise AssertionError(f"missing {label} bounds") from exc
    return text[a:b]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = pathlib.Path(args.root)
    debug = root / "ui/xui/debug-tools"
    diag_dir = debug / "addons/diagnostics"

    hook = (diag_dir / "pgraph-pusher-progress-trace-hook.h").read_text(encoding="utf-8")
    trace_h = (diag_dir / "pgraph-pusher-progress-trace.h").read_text(encoding="utf-8")
    trace_c = (diag_dir / "pgraph-pusher-progress-trace.c").read_text(encoding="utf-8")
    stub = (debug / "addons/stubs/pgraph-pusher-progress-trace-stub.c").read_text(encoding="utf-8")
    backend_h = (diag_dir / "diagnostics-backend.h").read_text(encoding="utf-8")
    backend_c = (diag_dir / "diagnostics-backend.c").read_text(encoding="utf-8")
    diag = (diag_dir / "diagnostics.cc").read_text(encoding="utf-8")
    labels = (debug / "xbe-labels.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-labels.cc").read_text(encoding="utf-8")

    require(hook, "XemuDebugToolsPgraphPusherPfifoScope", "PFIFO timing scope")
    require(hook, "XemuDebugToolsPgraphPusherSemaphoreScope", "semaphore timing scope")
    require(hook, "xemu_debug_tools_pgraph_pusher_progress_note_dma_put", "DMA PUT hook")
    require(hook, "xemu_debug_tools_pgraph_pusher_progress_semaphore_target", "semaphore target hook")
    require(trace_h, "XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_DMA_PUT", "DMA PUT event")
    require(trace_h, "XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PFIFO_RUN", "PFIFO run event")
    require(trace_h, "XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_SEMAPHORE_RELEASE", "semaphore event")
    require(trace_h, "semaphore_guest_va", "guest semaphore address capture")
    require(trace_h, "semaphore_old_value", "old semaphore value capture")
    require(trace_h, "dma_put_to_event_ns", "DMA PUT to semaphore latency capture")
    require(trace_c, "xemu_debug_tools_diagnostics_current_cpu_context", "DMA PUT guest-PC capture")
    require(trace_c, "worst_dma_put_to_semaphore_ns", "DMA PUT to semaphore statistic")
    require(stub, "xemu_debug_tools_pgraph_pusher_progress_note_dma_put", "non-Diagnostics stub")
    require(meson, "addons/diagnostics/pgraph-pusher-progress-trace.c", "Diagnostics trace source")
    require(meson, "addons/stubs/pgraph-pusher-progress-trace-stub.c", "non-Diagnostics trace stub")

    require(backend_h, "XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS", "trace buffer id")
    require(backend_h, "XemuDiagnosticsPgraphPusherProgressEvent", "bridge event alias")
    require(backend_c, "xemu_debug_tools_pgraph_pusher_progress_trace_set_buffer_multiplier", "buffer bridge")
    require(diag, "Record D3D pusher / GPU progress correlation", "Diagnostics UI control")
    require(diag, "D3D Pusher / GPU Progress Correlation", "Diagnostics UI/export section")
    require(diag, "Resolved DMA PUT guest PC labels:", "DMA PUT label dictionary")
    require(diag, "Observation-only note: this trace does not alter", "observation-only export contract")
    require(diag, "m_view.SetAll(true)", "Select All export integration")

    # The resolver now prefers raw PCs to huge false carry-forward names while
    # retaining the small XDK offsets used by GpuGet/KickOff/BlockOnTime.
    require(labels, "static uint32_t max_offset_for_label(const Label &label)", "resolver offset policy")
    require(labels, "return 0x2000u;", "trusted symbol-source bound")
    require(labels, "return 0x400u;", "inferred-label bound")
    require(labels, "return 0x200u;", "entry-point bound")
    require(labels, "constexpr uint32_t kMaxTrustedOffset = 0x2000u;", "backward scan bound")
    forbid(labels, "kMaxFunctionOffset = 0x10000u", "legacy 64-KiB carry-forward bound")

    # Patch 300 is integration/observation only: user.c records submission,
    # pfifo.c records GET/PUT consumption, pgraph.c observes the existing
    # semaphore write immediately around the original operations.
    user = (root / "hw/xbox/nv2a/user.c").read_text(encoding="utf-8")
    pfifo = (root / "hw/xbox/nv2a/pfifo.c").read_text(encoding="utf-8")
    pgraph = (root / "hw/xbox/nv2a/pgraph/pgraph.c").read_text(encoding="utf-8")
    require(user, "pgraph-pusher-progress-trace-hook.h", "NV USER hook include")
    put_case = between(user, "case NV_USER_DMA_PUT: {", "case NV_USER_DMA_GET:", "DMA PUT case")
    require(put_case, "d->pfifo.regs[NV_PFIFO_CACHE1_DMA_PUT] = val;", "original DMA PUT write")
    require(put_case, "xemu_debug_tools_pgraph_pusher_progress_note_dma_put", "DMA PUT observation")
    if put_case.index("d->pfifo.regs[NV_PFIFO_CACHE1_DMA_PUT] = val;") > put_case.index("xemu_debug_tools_pgraph_pusher_progress_note_dma_put"):
        raise AssertionError("DMA PUT observation must follow the existing register write")

    require(pfifo, "pgraph-pusher-progress-trace-hook.h", "PFIFO hook include")
    require(pfifo, "xemu_debug_tools_pgraph_pusher_progress_pfifo_begin", "PFIFO begin observation")
    require(pfifo, "pusher_progress_method_words += (uint32_t)num_words_processed;", "PFIFO method progress count")
    require(pfifo, "xemu_debug_tools_pgraph_pusher_progress_pfifo_end", "PFIFO end observation")

    require(pgraph, "pgraph-pusher-progress-trace-hook.h", "PGRAPH hook include")
    sem = between(pgraph, "DEF_METHOD(NV097, BACK_END_WRITE_SEMAPHORE_RELEASE)",
                  "DEF_METHOD(NV097, SET_ZMIN_MAX_CONTROL)", "semaphore method")
    for needle, label in [
        ("xemu_debug_tools_pgraph_pusher_progress_semaphore_begin", "semaphore begin"),
        ("d->pgraph.renderer->ops.surface_update(d, false, true, true);", "original surface update"),
        ("nv_dma_map(d, pg->dma_semaphore", "original semaphore mapping"),
        ("xemu_debug_tools_pgraph_pusher_progress_semaphore_target", "semaphore target observation"),
        ("xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite", "semaphore prewrite observation"),
        ("stl_le_p((uint32_t*)semaphore_data, parameter);", "original semaphore write"),
    ]:
        require(sem, needle, label)
    order = [
        sem.index("d->pgraph.renderer->ops.surface_update(d, false, true, true);"),
        sem.index("xemu_debug_tools_pgraph_pusher_progress_semaphore_begin"),
        sem.index("xemu_debug_tools_pgraph_pusher_progress_semaphore_target"),
        sem.index("xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite"),
        sem.index("stl_le_p((uint32_t*)semaphore_data, parameter);"),
    ]
    if order != sorted(order):
        raise AssertionError("semaphore observation ordering changed")
    if sem.index("xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite") > sem.index("stl_le_p((uint32_t*)semaphore_data, parameter);"):
        raise AssertionError("semaphore event must be captured immediately before the unchanged write")

    # Universal by design: no title ID or known Def Jam/XDK linked address is
    # baked into the new recorder or hook call sites.
    universal_text = "\n".join([hook, trace_h, trace_c, stub, put_case, sem])
    for forbidden in ("45410049", "0021ED87", "0021EA70", "0021E830", "81399000"):
        forbid(universal_text, forbidden, "Def Jam-specific constant")

    # Standalone Export Labels format remains the established seven columns.
    require(dump,
            "VIRTUAL    PHYSICAL   TYPE       SOURCE   CONFIDENCE  LOCATION                 LABEL\\n",
            "existing label dump header")

    print("PASS: v3.14v D3D pusher/GPU-progress correlation source guard")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
