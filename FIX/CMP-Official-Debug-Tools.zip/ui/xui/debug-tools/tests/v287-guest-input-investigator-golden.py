#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.07-derived Guest Input Investigator + exclusive Settings capture guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, needle: str, message: str) -> None:
    if needle not in text:
        raise AssertionError(message)


def forbid(text: str, needle: str, message: str) -> None:
    if needle in text:
        raise AssertionError(message)


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    mem = debug / "addons/memory-tools"

    input_manager = (root / "ui/xui/input-manager.cc").read_text(encoding="utf-8")
    tcg = (root / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")
    hook = (mem / "guest-input-profiler-hook.h").read_text(encoding="utf-8")
    profiler = (mem / "guest-input-profiler.c").read_text(encoding="utf-8")
    investigator = (mem / "guest-input-investigator.cc").read_text(encoding="utf-8")
    debugger_ui = (mem / "memory-tools-debugger-ui.cc").read_text(encoding="utf-8")
    memory_tools = (mem / "memory-tools.cc").read_text(encoding="utf-8")
    investigator_hh = (mem / "guest-input-investigator.hh").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    stub = (debug / "addons/stubs/guest-input-profiler-stub.c").read_text(encoding="utf-8")

    # Main xemu Settings/menu owns the controller immediately for its lifetime.
    require(input_manager, "input_rebinding ||\n        main_scene_active",
            "Settings/menu exclusive controller capture missing")
    forbid(input_manager, "main_scene_active && io.NavActive && controller_activity",
           "Settings capture still waits for the first controller event")
    require(input_manager, "g_scene_mgr.IsDisplayingScene()",
            "Settings capture is not scoped to SceneManager")

    # The TCG core contains only a tiny observation/chaining-control hook.
    require(tcg, 'guest-input-profiler-hook.h', "TCG profiler hook include missing")
    require(tcg, "xemu_debug_tools_guest_input_profiler_active()",
            "TCG profile-active observation missing")
    require(tcg, "CF_NO_GOTO_TB | CF_NO_GOTO_PTR",
            "TCG profiler does not force dispatch visibility while active")
    require(tcg, "xemu_debug_tools_guest_input_profiler_record((uint32_t)s.pc)",
            "TCG basic-block PC observation missing")
    for leaked in ("GUEST_INPUT_PROFILE_CAPACITY", "GuestInputProfileSlot",
                   "m_guest_input_working_rows", "normalized_failed_ratio"):
        forbid(tcg, leaked, f"Guest Input profiler implementation leaked into TCG core: {leaked}")

    # Storage and compare policy remain Memory Tools-owned.
    require(hook, "XemuDebugToolsGuestInputProfileEntry", "profiler ABI missing")
    require(profiler, "GUEST_INPUT_PROFILE_CAPACITY", "fixed profiler table missing")
    require(profiler, "qatomic_read(&g_guest_input_active)", "disabled hot-path gate missing")
    require(profiler, "qatomic_fetch_inc(&g_guest_input_total_hits)", "profile hit counter missing")
    require(investigator, "Start WORKING Capture", "WORKING capture UI missing")
    require(investigator, "Start FAILED Capture", "FAILED capture UI missing")
    require(investigator, "normalized_failed_ratio", "normalized profile comparison missing")
    require(investigator, "WORKING only", "working-only candidate marker missing")
    require(investigator, "ImGui::SetClipboardText(clipboard)", "candidate copy action missing")
    require(investigator, 'ImGui::Button("Save Controller Snapshot"',
            "Controller Snapshot save action missing")
    require(investigator, "XEMU Controller Snapshot v1.00",
            "Controller Snapshot format header missing")
    require(investigator, "XemuDebugOutput::Folder::Snapshots",
            "Controller Snapshot does not target DEBUG/Snapshots")
    require(investigator, "INPUT DIFF - COMPLETE COMPARISON",
            "Controller Snapshot complete diff section missing")
    require(investigator, "WORKING RAW PROFILE - COMPLETE",
            "Controller Snapshot WORKING raw profile missing")
    require(investigator, "FAILED RAW PROFILE - COMPLETE",
            "Controller Snapshot FAILED raw profile missing")
    require(investigator, "xemu_debug_tools_controller_xid_trace_snapshot",
            "Controller Snapshot retained Controller/XID/OHCI trace missing")
    forbid(investigator, "#include <fstream>",
           "Controller Snapshot reintroduced Windows-unsafe <fstream>")
    forbid(investigator, "std::ofstream",
           "Controller Snapshot reintroduced Windows-unsafe std::ofstream")
    require(investigator, 'g_fopen(output.c_str(), "wb")',
            "Controller Snapshot Windows-safe g_fopen output missing")
    require(investigator, "std::fwrite(text.data(), 1, text.size(), out)",
            "Controller Snapshot Windows-safe fwrite missing")
    require(investigator, "std::fclose(out)",
            "Controller Snapshot Windows-safe fclose missing")
    require(debugger_ui, 'ImGui::Button("INPUT DIFF")', "x86 Debugger INPUT DIFF button missing")
    require(memory_tools, "xemu_guest_input_investigator_draw();", "investigator detached draw missing")
    require(investigator_hh, "xemu_guest_input_investigator_notify_game_reset", "guest-reset profiler cleanup contract missing")

    # Profile selection remains generic and game-independent.
    combined = tcg + hook + profiler + investigator + input_manager
    for leaked in ("Def Jam", "Need for Speed", "45410049", "4541009E"):
        forbid(combined, leaked, f"game-specific behavior leaked into Guest Input Investigator: {leaked}")

    # Non-Memory profiles retain a complete no-op link surface.
    require(meson, "'addons/memory-tools/guest-input-profiler.c',",
            "Memory profile profiler source missing from Meson")
    require(meson, "'addons/memory-tools/guest-input-investigator.cc',",
            "Memory profile investigator source missing from Meson")
    require(meson, "'addons/stubs/guest-input-profiler-stub.c',",
            "non-Memory profiler stub missing from Meson")
    require(stub, "return 0;", "non-Memory profiler stub is not inert")
    forbid(stub, "qemu_", "non-Memory profiler stub gained runtime dependencies")

    print("PASS: Settings exclusive controller capture + TCG Guest Input Investigator")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
