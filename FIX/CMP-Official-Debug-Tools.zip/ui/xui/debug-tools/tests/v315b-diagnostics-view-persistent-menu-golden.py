#!/usr/bin/env python3
"""v3.15b Diagnostics View persistent multi-select menu guard."""
from __future__ import annotations
import argparse
import pathlib
from v314y_vulkan_observer_test_utils import function


def validate(ui: str) -> None:
    view = function(ui, 'void DiagnosticsWindow::DrawViewMenu()')
    assert 'ImGui::BeginMenu("View")' in view
    assert 'ImGui::MenuItem(' not in view, 'MenuItem would auto-close Diagnostics View on selection'
    assert 'ImGui::Button("Check All")' in view
    assert 'ImGui::Button("Uncheck All")' in view
    assert 'ImGui::Checkbox(section.label' in view
    assert 'm_view.SetAll(true)' in view and 'm_view.SetAll(false)' in view
    assert 'click outside it to close' in view
    for submenu in ('CPU / Timing', 'NV2A / PTIMER', 'Audio'):
        assert f'ImGui::BeginMenu("{submenu}")' in view


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    a = ap.parse_args()
    ui_path = pathlib.Path(a.root) / 'ui/xui/debug-tools/addons/diagnostics/diagnostics.cc'
    ui = ui_path.read_text()
    validate(ui)
    # Negative control: reintroducing the old auto-close widget must be rejected.
    try:
        validate(ui.replace('ImGui::Checkbox(section.label', 'ImGui::MenuItem(section.label', 1))
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError('auto-closing Diagnostics View regression was accepted')
    print('PASS: v3.15b Diagnostics View uses persistent multi-select widgets and closes only on popup dismissal')


if __name__ == '__main__':
    main()
