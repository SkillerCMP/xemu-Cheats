#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--root', required=True)
args = ap.parse_args()
root = Path(args.root)
dbg = root / 'ui/xui/debug-tools'

hook = (dbg / 'addons/diagnostics/pgraph-flip-delay-trace-hook.h').read_text(encoding='utf-8')
trace_h = (dbg / 'addons/diagnostics/pgraph-flip-delay-trace.h').read_text(encoding='utf-8')
trace_c = (dbg / 'addons/diagnostics/pgraph-flip-delay-trace.c').read_text(encoding='utf-8')
stub = (dbg / 'addons/stubs/pgraph-flip-delay-trace-stub.c').read_text(encoding='utf-8')
diag = (dbg / 'addons/diagnostics/diagnostics.cc').read_text(encoding='utf-8')
cpu_exec = (root / 'accel/tcg/cpu-exec.c').read_text(encoding='utf-8')

for token in (
    'xemu_debug_tools_pgraph_flip_delay_guest_pc_sampler_active',
    'xemu_debug_tools_pgraph_flip_delay_note_guest_pc',
):
    if token not in hook or token not in stub:
        raise SystemExit(f'FAIL: missing PC sampler hook/stub contract: {token}')

for token in (
    'XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_PC_SAMPLE_INTERVAL_NS 500000ULL',
    'XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT 8',
    'post_release_pc_samples',
    'post_release_pc_tracked_unique',
    'post_release_pc_untracked_samples',
    'hot_pc[',
    'hot_pc_hits[',
):
    if token not in trace_h:
        raise SystemExit(f'FAIL: missing post-release PC sampler event contract: {token}')

for token in (
    'XEMU_PGRAPH_FLIP_DELAY_PC_TRACKED_CAPACITY 128',
    'flip_delay_copy_hot_pcs_locked',
    'guest_pc < 0x00010000u || guest_pc >= 0x80000000u',
    'event->host_ns + g_flip_delay.threshold_ns / 2',
    'qatomic_set(&g_flip_delay.pc_capture_active, 1)',
    'qatomic_set(&g_flip_delay.pc_capture_active, 0)',
):
    if token not in trace_c:
        raise SystemExit(f'FAIL: missing low-intrusion PC sampling behavior: {token}')

if 'pgraph-flip-delay-trace-hook.h' not in cpu_exec:
    raise SystemExit('FAIL: TCG dispatcher missing PGRAPH delay PC sampler hook include')
for token in (
    'pgraph_flip_delay_guest_pc_sample_active',
    'xemu_debug_tools_pgraph_flip_delay_note_guest_pc((uint32_t)s.pc)',
):
    if token not in cpu_exec:
        raise SystemExit(f'FAIL: TCG dispatcher missing natural PC sampling hook: {token}')

# The new sampler must not change TB execution policy. In particular it must
# never join the existing conditions that set CF_NO_GOTO_* or CF_COUNT_MASK.
active_pos = cpu_exec.find('pgraph_flip_delay_guest_pc_sample_active')
note_pos = cpu_exec.find('xemu_debug_tools_pgraph_flip_delay_note_guest_pc((uint32_t)s.pc)')
if active_pos < 0 or note_pos < 0:
    raise SystemExit('FAIL: PC sampler TCG hook positions missing')
window = cpu_exec[max(0, active_pos-500):note_pos+300]
for forbidden in (
    'guest_input_profile_active || guest_input_consumer_capture_active || pgraph_flip_delay_guest_pc_sample_active',
    'CF_COUNT_MASK) | CF_NO_GOTO_TB | CF_NO_GOTO_PTR | 1',
):
    if forbidden in window:
        raise SystemExit(f'FAIL: PC sampler changes TCG execution policy: {forbidden}')

for token in (
    'Post-release guest PC samples',
    'Guest-PC hotspot sampling is TCG-only',
    'hot_pc0 hot_hits0',
    'Guest-PC sampler note: TCG only',
):
    if token not in diag:
        raise SystemExit(f'FAIL: missing PC sampler UI/export integration: {token}')

print('PASS: v3.14t samples post-release title PCs at natural TCG dispatcher boundaries without forcing single-step/direct-chain changes')
