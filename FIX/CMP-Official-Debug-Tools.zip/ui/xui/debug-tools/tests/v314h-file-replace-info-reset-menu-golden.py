#!/usr/bin/env python3
"""v3.14h File Replace titled info window + Cheat Engine reset menu guard."""
from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[4])
args = parser.parse_args()
root = args.root.resolve()
dt = root / "ui/xui/debug-tools"
fr = dt / "addons/file-replace"
ui = (fr / "file-replace-ui.cc").read_text(encoding="utf-8")
fr_core = (fr / "file-replace.cc").read_text(encoding="utf-8")
fr_hdr = (fr / "file-replace.hh").read_text(encoding="utf-8")
cheat_ui = (dt / "cheat-engine-ui.cc").read_text(encoding="utf-8")
cheat_src = (dt / "cheat-engine-source.cc").read_text(encoding="utf-8")
cheat_hdr = (dt / "cheat-engine.hh").read_text(encoding="utf-8")
actions = (root / "ui/xui/actions.cc").read_text(encoding="utf-8")
atapi = (root / "hw/ide/atapi.c").read_text(encoding="utf-8")


def need(text, token, label):
    if token not in text:
        raise SystemExit(f"FAIL: missing {label}: {token}")


def forbid(text, token, label):
    if token in text:
        raise SystemExit(f"FAIL: forbidden {label}: {token}")

# The information surface is now a real ImGui window. Passing the bool pointer
# to Begin supplies the standard title-bar X close control.
need(fr_hdr, "m_information_window_open", "persistent information-window state")
need(ui, '"File Replace Information - " + information_option->name', "titled info window")
need(ui, "&m_information_window_open", "standard ImGui title-bar X close control")
need(ui, "ImGuiWindowFlags_NoCollapse", "non-collapsible information window")
need(ui, 'ImGui::MenuItem("Information")', "right-click Information command")
need(ui, 'ImGui::SmallButton("i")', "information button")
forbid(ui, 'ImGui::BeginPopup("##OptionInfoPopup")', "old untitled information popup")

# Reset is a direct Cheat Engine menu-bar item, not a submenu, and uses the
# same upstream ActionReset path as stock xemu reset UI.
need(cheat_ui, '#include "../actions.hh"', "existing reset action declaration")
need(cheat_ui, 'ImGui::MenuItem("Reset Game")', "direct Reset Game menu-bar item")
forbid(cheat_ui, 'ImGui::BeginMenu("Reset Game")', "Reset Game submenu")
need(cheat_ui, "ActionReset();", "existing xemu reset path")
need(cheat_ui, "patch_reset_required || file_replace_reset_required", "combined reset-required state")
need(cheat_ui, "ImGuiCol_Text", "reset warning text style")
need(cheat_ui, "ImVec4(1.00f, 0.20f, 0.20f, 1.00f)", "red reset warning color")
need(cheat_hdr, "bool HasResetRequired() const;", "Patch reset-required API")
need(cheat_src, "block.preentry && block.selected != block.preentry_applied", "Patch pending-reset calculation")
need(fr_hdr, "bool HasResetRequired() const;", "File Replace reset-required API")
need(fr_core, "return SelectionDiffersFromActive();", "File Replace pending-reset calculation")

# Preserve lifecycle ordering: notify addons/PREENTRY before QEMU receives the
# reset request, so selected File Replace data is armed before DVD startup.
need(actions, "debug_tools_notify_game_reset();", "Debug Tools reset notification")
need(actions, "qemu_system_reset_request(SHUTDOWN_CAUSE_GUEST_RESET);", "QEMU reset request")
if actions.index("debug_tools_notify_game_reset();") >= actions.index(
        "qemu_system_reset_request(SHUTDOWN_CAUSE_GUEST_RESET);"):
    raise SystemExit("FAIL: Debug Tools reset notification must precede QEMU reset request")

# v3.16 keeps the reset/info behavior with pre-read synchronous/AIO hooks.
if atapi.count("xemu_file_replace_pread(") != 2 or "xemu_file_replace_aio_preadv(" not in (root / "hw/ide/core.c").read_text():
    raise SystemExit("FAIL: missing v3.16 synchronous/buffered ATAPI coverage")

print("PASS: v3.14h titled File Replace info window + direct reset menu guard")
