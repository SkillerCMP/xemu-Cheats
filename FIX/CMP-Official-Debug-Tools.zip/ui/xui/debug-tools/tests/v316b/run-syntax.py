#!/usr/bin/env python3
"""Declaration-only SDL/ImGui/JSON syntax checks, NOT a full dependency build."""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--compiler',default='g++');a=p.parse_args()
dt=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='xemu-v316b-syntax-') as t:
 d=Path(t)/'ui/xui/debug-tools';shutil.copytree(dt,d)
 (d.parent/'common.hh').write_text('#pragma once\n#include <cstddef>\n#include <cstdint>\n#include <cstring>\n#include <cstdio>\n#include <string>\n#include <algorithm>\n#include <imgui.h>\nbool SDL_OpenURL(const char*);const char* SDL_GetError();\n')
 for name in ('font-manager.hh','misc.hh'):(d.parent/name).write_text('#pragma once\n')
 (d.parent/'actions.hh').write_text('#pragma once\nvoid ActionReset();\n')
 cmd=[a.compiler,'-std=c++17','-Wall','-Wextra','-Werror','-fsyntax-only','-I'+str(d/'tests/v316b/stubs'),'-I'+str(d),str(d/'cheat-engine-ui.cc'),str(d/'cheat-engine-persistence.cc'),str(d/'addons/Video-Recorder/video-recorder-font.cc')]
 print('+',' '.join(cmd));subprocess.run(cmd,check=True)
 print('PASS declaration-stub syntax: full Cheat Engine UI, persistence and recorder font provider')
