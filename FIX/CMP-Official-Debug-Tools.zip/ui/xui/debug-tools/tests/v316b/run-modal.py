#!/usr/bin/env python3
"""Actual context/confirmation method bodies, simulated ImGui input, no real window."""
from pathlib import Path
import argparse,subprocess,tempfile,sys,shutil
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
d=Path(__file__).resolve().parents[2];sys.path.insert(0,str(d/'tests'));from v287_source_test_utils import extract_function
s=(d/'cheat-engine-ui.cc').read_text();test=(d/'tests/v316b/modal-golden.cc').read_text();body='\n'.join(extract_function(s,f'void CheatEngineWindow::{n}(')for n in ['DrawCodeContextMenu','DrawDeleteCodePopup'])
with tempfile.TemporaryDirectory(prefix='xemu-v316b-modal-')as t:
 t=Path(t);h=t/'ui/xui/debug-tools';h.mkdir(parents=True)
 for name in ['cheat-engine.hh','x86-cheat-assembler.hh']:shutil.copyfile(d/name,h/name)
 (h.parent/'common.hh').write_text('#pragma once\n#include <cstddef>\n')
 (t/'test.cc').write_text(test.replace('// ACTUAL_METHODS',body));cmd=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-I'+str(h)]
 if a.sanitizers:cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
 cmd+=[str(t/'test.cc'),'-o',str(t/'test')];subprocess.run(cmd,check=True);subprocess.run([str(t/'test')],check=True)
