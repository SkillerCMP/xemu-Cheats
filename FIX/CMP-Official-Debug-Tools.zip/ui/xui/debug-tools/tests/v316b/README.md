# v3.16b isolated regression tests

These scripts use C++17 and run on Linux. They are not full XEMU builds.

- `run-native.py --bug-file "/path/Cheat file BUG.txt"`: actual parser, executor,
  hook ownership, deletion and SHA-256 source hash. Guest memory/pause and generic
  x86 encoder are simulated; atomic file IO uses the real installed GLib runtime.
  Backup/target-write failures are fault-injected with a linker wrapper. Omitting
  `--bug-file` runs synthetic cases without the private 22-block user fixture.
- `run-recorder.py`: actual antialiased RGB renderer and extracted ComposeFrame;
  synthetic font coverage tests blending, wrapping, clipping, font-cache reuse,
  left/right panel placement and byte-identical preservation of game pixels.
  Optional PIL-generated glyph fixtures are only for visual inspection; they
  are not a test of ImGui rasterization or video encoding. No font fixture is
  shipped. The production provider uses the existing embedded Roboto Condensed.
- `run-modal.py`: actual context-menu and confirmation method bodies, simulated
  ImGui input; checks cancellation, stale selection refusal and explicit deletion.
- `run-syntax.py`: declaration-only syntax checks of complete UI/persistence and
  the font provider. The local facades are NOT actual SDL/ImGui/JSON libraries.

All accept `--compiler g++` or `--compiler clang++`. Native, recorder and modal
scripts accept `--sanitizers` for address/undefined-behavior instrumentation.
No script changes its optional user input. File writes use temporary directories.

File Replace regression remains unmodified. To run its v3.16 suite against the
v3.16a memalign include, supply the test-only additional facade:

```sh
CPATH="$PWD/tests/v316b/bridge-extra" python3 addons/file-replace/tests/run-v316.py
```

Run that command from `ui/xui/debug-tools`. All facades stay under tests and
are never listed as production include paths or source files in meson.build.
