// Actual F0/F2 frontend + production parsing helpers. Only generic x86 encoding
// is a 1-byte NOP stand-in: this test does NOT validate Keystone machine bytes.
#include "x86-cheat-assembler.hh"
#include "x86-cheat-assembler-internal.hh"
#include <iostream>
#include <cstdlib>
int encodes=0;
namespace xemu_cheat_assembler_internal {
bool encode_instruction(const std::string&,size_t,const std::unordered_map<std::string,size_t>*,uint32_t,std::vector<uint8_t>&out,std::string&){++encodes;out.push_back(0x90);return true;}
}
static unsigned checks;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL "<<__LINE__<<": "<<#x<<"\n";std::exit(1);}}while(0)
static bool assemble(std::initializer_list<const char*>list,XemuCheatAsmResult&r){std::vector<XemuCheatAsmLine>src;int n=20;for(auto l:list)src.push_back({n++,l});return xemu_cheat_assemble_x86_32_at(src,0x68010000,0x680F0000,0x680F1000,r);}
int main(){
 XemuCheatAsmResult r;
 CHECK(assemble({"$jne LinkHybridNativeInitDone","$LinkHybridNativeInitDone:","$popad","$popfd"},r));CHECK(r.ok);
 int n=encodes;CHECK(!assemble({"$jne LinkHybridNativeInitDone","$LinkHybridNativeInitDone","$popad"},r));CHECK(encodes==n);CHECK(r.error.find("trailing ':'")!=std::string::npos);CHECK(r.error_line==20);
 CHECK(assemble({"$jz Done", "$Done: nop"},r));
 CHECK(assemble({"$jmp 0x00011250","$call eax","$jmp dword ptr [eax]","$mov eax,fs:[0x18]"},r));
 CHECK(assemble({"$jmp near done","$Done: nop","$call short done"},r));
 CHECK(assemble({"$mov T0,01","$cmp T0,02","$jne Done","$Done: nop"},r));
 CHECK(assemble({"$mov esi,Data","$nop","$Data:","$dd 3F800000"},r));CHECK(r.data.size()==4);CHECK(r.data[3]==0x3F);
 n=encodes;CHECK(!assemble({"$loop notDefined","$nop"},r));CHECK(encodes==n);
 CHECK(!assemble({"$jne First","$First: nop","$First: nop"},r));CHECK(r.error.find("duplicate")!=std::string::npos);
 std::vector<XemuCheatAsmLine>many(16385,{42,"nop"});n=encodes;CHECK(!xemu_cheat_assemble_x86_32(many,r));CHECK(encodes==n);
 many={{88,std::string(4097,'x')}};CHECK(!xemu_cheat_assemble_x86_32(many,r));CHECK(r.error_line==88);CHECK(encodes==n);
 // F2 uses the real raw/relocation path, not the NOP encoder.
 many={{1,"0F84 Exit"},{2,"90"},{3,"Exit:"},{4,"90"}};
 CHECK(xemu_cheat_assemble_f2_raw_at(many,0x68010000,r));CHECK(r.bytes.size()==8);CHECK(r.bytes[0]==0x0F&&r.bytes[1]==0x84);CHECK(r.bytes[2]==1);
 many={{9,"0F84 Missing"},{10,"90"}};CHECK(!xemu_cheat_assemble_f2_raw_at(many,0x68010000,r));
 std::cout<<"PASS "<<checks<<" actual frontend/label assertions (generic x86 encoder mocked)\n";
}
