// Exercise the actual popup/context-menu methods with deterministic ImGui input.
// Separate engine tests cover real TXT writes. This is NOT a window-system test.
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <cstdint>
#include <cstdio>
#include <iostream>
#define private public
#include "cheat-engine.hh"
#undef private
struct ImVec2{float x,y;ImVec2(float a=0,float b=0):x(a),y(b){}};
constexpr int ImGuiCond_Appearing=2,ImGuiWindowFlags_AlwaysAutoResize=64;
static bool menu=false,opened=false,disabled=false,succeed=true;static std::string button;static int deletes=0;
namespace ImGui {
bool BeginPopupContextItem(const char*){return menu;}
bool MenuItem(const char*,const char*,bool,bool available){bool answer=menu&&available;menu=false;return answer;}
void TextDisabled(const char*){}void EndPopup(){}void OpenPopup(const char*){opened=true;}
void SetNextWindowSize(ImVec2,int){}bool BeginPopupModal(const char*,bool*,int){return opened;}
void TextWrapped(const char*,...){}void Separator(){}void Spacing(){}void SameLine(){}void SetItemDefaultFocus(){}
bool Button(const char*n,ImVec2){return !disabled&&button==n;}
void CloseCurrentPopup(){opened=false;}void BeginDisabled(bool v){disabled=v;}void EndDisabled(){disabled=false;}
}
CheatEngineWindow::CheatEngineWindow()=default;
bool CheatEngineWindow::DeleteCodeFromSource(size_t,uint64_t,const std::string&,std::string&error){++deletes;if(!succeed)error="test write refusal";return succeed;}
// ACTUAL_METHODS
static unsigned checks;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL "<<__LINE__<<": "<<#x<<"\n";return 1;}}while(0)
int main(){CheatEngineWindow e;CheatEngineWindow::CheatBlock b;b.name="Test code";b.source_begin=0;e.m_blocks.push_back(b);e.m_loaded_path="codes.txt";e.m_source_revision=10;
 menu=true;e.DrawCodeContextMenu(0);CHECK(deletes==0);CHECK(e.m_delete_popup_requested);CHECK(e.m_delete_name==b.name);CHECK(e.m_delete_source_revision==10);
 button="";e.DrawDeleteCodePopup();CHECK(opened);CHECK(deletes==0);
 button="Cancel";e.DrawDeleteCodePopup();CHECK(!opened);CHECK(deletes==0);
 menu=true;e.DrawCodeContextMenu(0);++e.m_source_revision;button="Delete";e.DrawDeleteCodePopup();CHECK(opened);CHECK(deletes==0);
 button="Cancel";e.DrawDeleteCodePopup();CHECK(!opened);
 menu=true;e.DrawCodeContextMenu(0);button="Delete";succeed=false;e.DrawDeleteCodePopup();CHECK(opened);CHECK(deletes==1);CHECK(!e.m_delete_error.empty());
 succeed=true;e.DrawDeleteCodePopup();CHECK(!opened);CHECK(deletes==2);
 e.m_engine_enabled=false;e.m_live_cheats_enabled=false;menu=true;e.DrawCodeContextMenu(0);CHECK(e.m_delete_popup_requested);
 e.m_delete_popup_requested=false;e.m_blocks[0].source_begin=std::string::npos;menu=true;e.DrawCodeContextMenu(0);CHECK(!e.m_delete_popup_requested);
 std::cout<<"PASS "<<checks<<" actual confirmation/context-menu flow assertions (ImGui input simulated)\n";
}
