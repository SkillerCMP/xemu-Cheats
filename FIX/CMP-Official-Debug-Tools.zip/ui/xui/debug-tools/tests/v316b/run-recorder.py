#!/usr/bin/env python3
"""Test real RGB renderer and extracted ComposeFrame. Synthetic alpha coverage;
optional PIL mask fixture for visual inspection is NOT an ImGui/encoder test."""
from pathlib import Path
import argparse,subprocess,tempfile,sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true');p.add_argument('--font-fixture',type=Path);p.add_argument('--preview',type=Path);a=p.parse_args()
d=Path(__file__).resolve().parents[2];sys.path.insert(0,str(d/'tests'));from v287_source_test_utils import extract_function
s=(d/'addons/Video-Recorder/video-recorder.cc').read_text();test=(d/'tests/v316b/recorder-golden.cc').read_text();body=extract_function(s,'static std::string SanitizeAscii(')+'\n'+extract_function(s,'void VideoRecorder::ComposeFrame(')
with tempfile.TemporaryDirectory(prefix='xemu-v316b-recorder-')as t:
 t=Path(t);(t/'test.cc').write_text(test.replace('// ACTUAL_COMPOSITOR',body));cmd=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-I'+str(d)]
 if a.sanitizers:cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
 cmd+=[str(t/'test.cc'),str(d/'addons/Video-Recorder/video-recorder-text.cc'),'-o',str(t/'test')];subprocess.run(cmd,check=True)
 subprocess.run([str(t/'test')]+([str(a.font_fixture.resolve()),str(a.preview.resolve())]if a.font_fixture and a.preview else []),check=True)
