#!/usr/bin/env python3
"""Build actual engine/parser/F-hook/deletion code against guest/assembler seams.
Use real GLib runtime for atomic TXT writes. NOT a full XEMU/Keystone/UI build.
The temporary tree supplies common.hh declarations instead of SDL/QEMU headers.
"""
from pathlib import Path
import argparse,os,shutil,subprocess,tempfile,sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true')
p.add_argument('--bug-file',type=Path);a=p.parse_args()
dt=Path(__file__).resolve().parents[2];sys.path.insert(0,str(dt/'tests'))
from v287_source_test_utils import extract_function

def run(cmd):
 print('+',' '.join(map(str,cmd)),flush=True);subprocess.run(list(map(str,cmd)),check=True)
with tempfile.TemporaryDirectory(prefix='xemu-v316b-') as temp:
 root=Path(temp);d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
 (d.parent/'common.hh').write_text('#pragma once\n#include <cstddef>\n#include <cstdint>\n#include <string>\nbool SDL_OpenURL(const char*);const char* SDL_GetError();\n')
 for name in ('font-manager.hh','misc.hh'):(d.parent/name).write_text('#pragma once\n')
 flags=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-ffunction-sections','-fdata-sections']
 if a.sanitizers:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
 flags+=['-I'+str(d/'tests/v316b/stubs'),'-I'+str(d)]
 persistence=(d/'cheat-engine-persistence.cc').read_text()
 hash_src='#include "cheat-engine.hh"\n#include <algorithm>\n#include <cctype>\n#include <cstdio>\n#include <glib.h>\n'+extract_function(persistence,'std::string Sha256Text(')+'\n'+extract_function(persistence,'std::string CheatEngineWindow::PersistentContentHash(')
 (root/'hash.cc').write_text(hash_src)
 impl=[d/n for n in ('cheat-engine-source.cc','cheat-engine-execute.cc','cheat-engine-fhooks.cc','cheat-engine.cc','cheat-engine-delete.cc','cheat-source-file.cc')]
 run(flags+[d/'tests/v316b/engine-golden.cc',d/'tests/v316b/engine-shims.cc',*impl,root/'hash.cc','-Wl,--gc-sections','-Wl,--wrap=g_file_set_contents_full','-l:libglib-2.0.so.0','-o',root/'engine'])
 run([root/'engine',a.bug_file.resolve() if a.bug_file else '-',root/'cheats'])
 # Extract the exact pure helpers, avoiding any Keystone-header dependency.
 backend=(d/'x86-cheat-assembler-keystone.cc').read_text()
 funcs=['std::string trim(','std::string upper(','std::string strip_comment(','bool parse_register(','int reg32(','bool valid_label(','bool parse_number(','std::vector<std::string> split_operands(','void emit_u32(','bool condition_code(']
 helpers='#include "x86-cheat-assembler-internal.hh"\n#include <algorithm>\n#include <cctype>\n#include <limits>\nnamespace xemu_cheat_assembler_internal {\n'+'\n'.join(extract_function(backend,s) for s in funcs)+'\n}\n'
 (root/'helpers.cc').write_text(helpers)
 run(flags+[d/'tests/v316b/frontend-golden.cc',d/'x86-cheat-assembler.cc',root/'helpers.cc','-Wl,--gc-sections','-o',root/'frontend'])
 run([root/'frontend'])
 print('PASS native v3.16b engine/deletion, source-hash and actual F0/F2 frontend tests')
