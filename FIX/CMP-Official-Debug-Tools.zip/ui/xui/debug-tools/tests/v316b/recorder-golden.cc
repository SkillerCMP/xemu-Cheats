#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <mutex>
#include <string>
#include <vector>
#include <atomic>
#define private public
#include "addons/Video-Recorder/video-recorder.hh"
#undef private
static unsigned checks;static int loads;static bool font_fail;
static std::string font_fixture;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL "<<__LINE__<<": "<<#x<<"\n";std::exit(1);}}while(0)
namespace XemuRecorderText {
bool LoadFont(int height,Glyphs&out){
 ++loads;if(font_fail)return false;
 if(!font_fixture.empty()){
  std::ifstream f(font_fixture,std::ios::binary);if(!f)return false;
  for(auto&g:out){int32_t n[5];f.read((char*)n,sizeof n);if(!f)return false;g.x=n[0];g.y=n[1];g.width=n[2];g.height=n[3];g.advance=n[4]/64.0f;g.alpha.resize((size_t)g.width*g.height);f.read((char*)g.alpha.data(),g.alpha.size());if(!f)return false;}return true;
 }
 for(auto&g:out){g.x=0;g.y=0;g.width=3;g.height=1;g.advance=float(height/2);g.alpha={0,128,255};}return true;
}
}
static std::vector<std::string> names,credits,groups;
void debug_tools_get_active_cheat_details(std::vector<std::string>&n,std::vector<std::string>&c,std::vector<std::string>&g){n=names;c=credits;g=groups;}
VideoRecorder::VideoRecorder()=default;VideoRecorder::~VideoRecorder()=default;
static void save(const std::string&path,const std::vector<uint8_t>&rgb,int w,int h){std::ofstream f(path,std::ios::binary);f<<"P6\n"<<w<<" "<<h<<"\n255\n";f.write((const char*)rgb.data(),rgb.size());CHECK(bool(f));}
// ACTUAL_COMPOSITOR
int main(int argc,char**argv){
 XemuRecorderText::Renderer text;CHECK(text.EnsureFont(16));CHECK(loads==1);CHECK(text.EnsureFont(16));CHECK(loads==1);
 CHECK(text.Measure("ABCD")==32);CHECK(text.Wrap("AB CD",16)==std::vector<std::string>({"AB","CD"}));CHECK(text.Wrap("ABCDE",1).size()==5);CHECK(text.Wrap("",1).size()==1);
 std::vector<uint8_t> rgb(8*4*3,24);text.Draw(rgb,8,4,1,1,3,"A",235,116,100);
 CHECK(rgb[(1*8+1)*3]==24);CHECK(rgb[(1*8+2)*3]==130);CHECK(rgb[(1*8+3)*3]==235);
 CHECK(rgb[(1*8+2)*3+1]==70);CHECK(rgb[(1*8+2)*3+2]==62);
 auto before=rgb;text.Draw(rgb,8,4,0,0,0,"A",255,255,255);CHECK(rgb==before);
 std::vector<uint8_t>small(3,1);text.Draw(small,8,4,0,0,4,"A",255,255,255);CHECK(small==std::vector<uint8_t>({1,1,1}));
 for(int x=-40;x<40;++x)for(int y=-8;y<8;++y){rgb.assign(8*4*3,24);text.Draw(rgb,8,4,x,y,3,"AAAAAAAAAAAAAAAA",235,116,100);CHECK(rgb.size()==8*4*3);}
 font_fail=true;CHECK(!text.EnsureFont(32));CHECK(text.EnsureFont(16));font_fail=false;CHECK(text.EnsureFont(32));
 VideoRecorder recorder;std::vector<uint8_t>game,frame;int fw,fh;
 for(int h: {24,480,720,1080,1440,2160})for(int panel: {0,1}){
  const int w=120;game.resize((size_t)w*h*3);for(size_t i=0;i<game.size();++i)game[i]=(uint8_t)(i*7);
  names={"Link Hybrid native equipment init v0.23H [ATTACHMENT ONLY]","Link Hybrid final visibility v0.24H [TEST]"};credits={"Skiller","Skiller"};groups={"LINK MOVESET","LINK MOVESET"};
  recorder.m_show_codes=true;recorder.m_panel_position=panel;recorder.ComposeFrame(game,w,h,frame,fw,fh);
  const int side=260*std::max(1,h/720);CHECK(fw==w+side);CHECK(fh==h);CHECK(frame.size()==(size_t)fw*fh*3);
  for(int y=0;y<h;++y)CHECK(!std::memcmp(game.data()+(size_t)y*w*3,frame.data()+((size_t)y*fw+(panel?side:0))*3,w*3));
  int prior=loads;recorder.ComposeFrame(game,w,h,frame,fw,fh);CHECK(loads==prior);
 }
 recorder.m_show_codes=false;recorder.ComposeFrame(game,120,2160,frame,fw,fh);CHECK(frame==game);CHECK(fw==120&&fh==2160);
 // The overflow marker must not overwrite a code/credit line. Exercise dense list.
 recorder.m_show_codes=true;names.assign(200,"Very long active code name with wrap and credits");credits.assign(200,"Tester");groups.assign(200,"Group");game.assign(320*480*3,47);recorder.ComposeFrame(game,320,480,frame,fw,fh);CHECK(frame.size()==(size_t)fw*fh*3);
 if(argc==3){
  font_fixture=argv[1];recorder.m_panel_text=XemuRecorderText::Renderer();recorder.m_panel_position=0;
  names={"Link Hybrid Identity + Guest Slot [TEST]","Link Hybrid native equipment init v0.23H [ATTACHMENT ONLY]","Link Hybrid final visibility v0.24H [TEST]","SPAWN > LINK [v0.16 COSTUME1 TEST]"};credits.assign(4,"Skiller");groups={"LINK MOVESET","LINK MOVESET","LINK MOVESET","Spawn Guest Replacements"};
  game.assign(640*480*3,47);recorder.ComposeFrame(game,640,480,frame,fw,fh);save(argv[2],frame,fw,fh);
 }
 std::cout<<"PASS "<<checks<<" renderer/compositor assertions (font provider fixture; actual RGB renderer and ComposeFrame)\n";
}
