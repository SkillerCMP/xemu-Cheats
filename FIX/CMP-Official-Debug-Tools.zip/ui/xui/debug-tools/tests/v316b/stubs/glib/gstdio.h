#pragma once
#include <cstdio>
#include <sys/stat.h>
using GStatBuf=struct stat;
extern "C" {FILE* g_fopen(const char*,const char*); int g_stat(const char*,GStatBuf*);int g_remove(const char*);int g_rename(const char*,const char*);}
