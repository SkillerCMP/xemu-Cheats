#pragma once
enum ShutdownCause { SHUTDOWN_CAUSE_NONE=0, SHUTDOWN_CAUSE_HOST_QMP_SYSTEM_RESET=1 };
ShutdownCause qemu_reset_requested_get(); ShutdownCause qemu_shutdown_requested_get();
