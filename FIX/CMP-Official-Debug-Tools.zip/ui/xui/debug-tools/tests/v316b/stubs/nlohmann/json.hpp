// Declaration-only: validates C++ usage but NOT actual JSON dependency behavior.
#pragma once
#include <string>
#include <cstdint>
#include <cstddef>
namespace nlohmann {class json {public:
 class const_iterator {public:const json&operator*()const;const_iterator&operator++();bool operator!=(const const_iterator&)const;bool operator==(const const_iterator&)const;};
 const_iterator find(const char*)const;const_iterator begin()const;const_iterator end()const;
 const json&operator[](const char*)const;json&operator[](const char*);
 template<class T>json&operator=(T);template<class T>T get()const;
 template<class...Args>static json parse(Args...);static json array();
 bool is_discarded()const;bool is_object()const;bool is_array()const;bool is_string()const;std::size_t size()const;
 std::string dump(int)const;void push_back(json&&);
};}
