// Names/types of the existing generated XEMU embedded font resource, no font bytes.
extern const unsigned char RobotoCondensed_Regular_data[];
extern const unsigned int RobotoCondensed_Regular_size;
