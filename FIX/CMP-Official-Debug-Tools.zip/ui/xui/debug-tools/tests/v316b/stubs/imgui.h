// Declaration-only syntax facade. Not real Dear ImGui and not a UI runtime test.
#pragma once
#include <cstdint>
using ImWchar=unsigned short;using ImU32=unsigned int;using ImGuiWindowFlags=int;using ImGuiCond=int;using ImGuiPopupFlags=int;
struct ImVec2{float x,y;ImVec2(float a=0,float b=0):x(a),y(b){}};
struct ImVec4{float x,y,z,w;ImVec4(float a=0,float b=0,float c=0,float d=0):x(a),y(b),z(c),w(d){}};
constexpr int ImGuiCond_FirstUseEver=1,ImGuiCond_Appearing=2,ImGuiCond_Always=4;
constexpr int ImGuiWindowFlags_NoCollapse=1,ImGuiWindowFlags_NoTitleBar=2,ImGuiWindowFlags_NoMove=4,ImGuiWindowFlags_NoResize=8,ImGuiWindowFlags_NoSavedSettings=16,ImGuiWindowFlags_MenuBar=32,ImGuiWindowFlags_AlwaysAutoResize=64;
constexpr int ImGuiTreeNodeFlags_DefaultOpen=1,ImGuiTreeNodeFlags_SpanAvailWidth=2;
constexpr int ImGuiCol_Text=0,ImGuiCol_Button=1,ImGuiCol_ButtonHovered=2,ImGuiCol_ButtonActive=3,ImGuiCol_CheckMark=4,ImGuiCol_TabActive=5,ImGuiCol_Tab=6,ImGuiCol_TabHovered=7,ImGuiCol_TabUnfocused=8,ImGuiCol_TabUnfocusedActive=9;
struct ImGuiIO{ImVec2 DisplaySize;};struct ImDrawList{void AddLine(ImVec2,ImVec2,ImU32,float);};
struct ImFontGlyph{float AdvanceX,X0,Y0,X1,Y1,U0,V0,U1,V1;};
struct ImFontConfig{bool FontDataOwnedByAtlas;float SizePixels;int OversampleH,OversampleV;bool PixelSnapH;};
struct ImFont{const ImFontGlyph*FindGlyph(ImWchar)const;};
struct ImFontAtlas{ImFontAtlas();~ImFontAtlas();ImFont*AddFontFromMemoryTTF(void*,int,float,const ImFontConfig*,const ImWchar*);bool Build();void GetTexDataAsAlpha8(unsigned char**,int*,int*,int* = nullptr);};
namespace ImGui{
ImGuiIO&GetIO();float GetFrameHeightWithSpacing();ImVec2 GetItemRectMin();ImVec2 GetItemRectMax();ImDrawList*GetWindowDrawList();ImU32 GetColorU32(int);const ImVec4&GetStyleColorVec4(int);
bool BeginPopupContextItem(const char* = nullptr,ImGuiPopupFlags=1);void OpenPopup(const char*,ImGuiPopupFlags=0);bool BeginPopupModal(const char*,bool* = nullptr,ImGuiWindowFlags=0);void CloseCurrentPopup();void SetItemDefaultFocus();void EndPopup();
void SetNextWindowSize(const ImVec2&,ImGuiCond=0);void BeginDisabled(bool=true);void EndDisabled();
bool Button(const char*,const ImVec2& = ImVec2(0,0));
bool MenuItem(const char*,const char* = nullptr,bool=false,bool=true);bool MenuItem(const char*,const char*,bool*,bool=true);
bool Checkbox(const char*,bool*);
template<class... Args> bool Begin(Args...);
template<class... Args> bool BeginChild(Args...);
template<class... Args> bool BeginMenu(Args...);
template<class... Args> bool BeginMenuBar(Args...);
template<class... Args> bool BeginTabBar(Args...);
template<class... Args> bool BeginTabItem(Args...);
template<class... Args> bool IsItemHovered(Args...);
template<class... Args> bool TreeNodeEx(Args...);
template<class... Args> void End(Args...);
template<class... Args> void EndChild(Args...);
template<class... Args> void EndMenu(Args...);
template<class... Args> void EndMenuBar(Args...);
template<class... Args> void EndTabBar(Args...);
template<class... Args> void EndTabItem(Args...);
template<class... Args> void PopID(Args...);
template<class... Args> void PopStyleColor(Args...);
template<class... Args> void PushID(Args...);
template<class... Args> void PushStyleColor(Args...);
template<class... Args> void SameLine(Args...);
template<class... Args> void Separator(Args...);
template<class... Args> void SetNextWindowPos(Args...);
template<class... Args> void SetTooltip(Args...);
template<class... Args> void Spacing(Args...);
template<class... Args> void TextColored(Args...);
template<class... Args> void TextDisabled(Args...);
template<class... Args> void TextUnformatted(Args...);
template<class... Args> void TextWrapped(Args...);
template<class... Args> void TreePop(Args...);
}
