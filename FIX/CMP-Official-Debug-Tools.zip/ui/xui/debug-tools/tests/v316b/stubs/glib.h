// TEST ONLY. C ABI declarations for the installed GLib runtime. Production uses
// the platform's real development headers, never this directory.
#pragma once
#include <cstddef>
#include <cstdint>
using gchar=char; using guchar=unsigned char; using gsize=size_t; using gssize=ptrdiff_t;
using gint=int; using gboolean=int; using guint=unsigned; using GQuark=uint32_t;
struct GError { GQuark domain; gint code; gchar *message; }; struct GDir;
enum GFileTest {G_FILE_TEST_IS_REGULAR=1, G_FILE_TEST_IS_SYMLINK=2,G_FILE_TEST_IS_DIR=4,G_FILE_TEST_IS_EXECUTABLE=8,G_FILE_TEST_EXISTS=16};
enum GFileSetContentsFlags {G_FILE_SET_CONTENTS_NONE=0,G_FILE_SET_CONTENTS_CONSISTENT=1,G_FILE_SET_CONTENTS_DURABLE=2,G_FILE_SET_CONTENTS_ONLY_EXISTING=4};
enum GChecksumType {G_CHECKSUM_MD5,G_CHECKSUM_SHA1,G_CHECKSUM_SHA256,G_CHECKSUM_SHA512,G_CHECKSUM_SHA384};
extern "C" {
void g_free(void*); void g_error_free(GError*); void g_clear_error(GError**);
gchar* g_build_filename(const gchar*,...); gchar* g_canonicalize_filename(const gchar*,const gchar*);
gchar* g_filename_to_uri(const gchar*,const gchar*,GError**);
gboolean g_file_get_contents(const gchar*,gchar**,gsize*,GError**);
gboolean g_file_set_contents(const gchar*,const gchar*,gssize,GError**);
gboolean g_file_set_contents_full(const gchar*,const gchar*,gssize,GFileSetContentsFlags,int,GError**);
gboolean g_file_test(const gchar*,GFileTest); gint g_mkdir_with_parents(const gchar*,gint);
GDir* g_dir_open(const gchar*,guint,GError**); const gchar* g_dir_read_name(GDir*); void g_dir_close(GDir*);
gint g_ascii_strcasecmp(const gchar*,const gchar*); gchar* g_uuid_string_random(void);
gchar* g_compute_checksum_for_data(GChecksumType,const guchar*,gsize);
const gchar *g_getenv(const gchar*); gchar* g_strdup(const gchar*); gchar* g_path_get_dirname(const gchar*);
}
