// TEST ONLY: host API/guest-memory and assembler seams, NOT an emulator.
#include "cheat-engine.hh"
#include "current-game.hh"
#include "cheat-engine-memory.h"
#include "guest-pause-guard.hh"
#include "system/runstate.h"
#include <cstring>
#include <unordered_map>
int probe_calls=0, final_calls=0, memory_writes=0, patch_calls=0;
bool patch_fail=false, pause_valid=true;
std::unordered_map<uint32_t,uint8_t> guest_memory;
CurrentGameManager current_game_manager;
std::string CurrentGameManager::FormatTitleId(uint32_t){return "4E4D0003";}
std::string CurrentGameManager::FormatDatabaseGameId(uint32_t){return "NM0003";}
void CurrentGameManager::RefreshRunningXbe(bool){}
bool SDL_OpenURL(const char*){return true;} const char* SDL_GetError(){return "test";}
ShutdownCause qemu_reset_requested_get(){return SHUTDOWN_CAUSE_NONE;}
ShutdownCause qemu_shutdown_requested_get(){return SHUTDOWN_CAUSE_NONE;}
void CheatEngineWindow::EnsurePersistenceOptionLoaded(){m_persistence_option_loaded=true;}
void CheatEngineWindow::SavePersistentState(){}
void CheatEngineWindow::RestorePersistentState(){}
XemuDebugGuestPauseGuard::XemuDebugGuestPauseGuard(){m_valid=pause_valid;}
XemuDebugGuestPauseGuard::~XemuDebugGuestPauseGuard(){}
void XemuDebugGuestPauseGuard::Resume(){m_resume=false;}
extern "C" {
int xemu_cheat_cpu_available(){return 1;}
int xemu_cheat_get_executable_dir(char *p,size_t n){if(n<5)return 0;strcpy(p,"/tmp");return 1;}
int xemu_cheat_memory_read(int,uint32_t a,void *p,size_t n){
    auto *b=(uint8_t*)p;
    for(size_t i=0;i<n;++i){auto q=guest_memory.find(a+(uint32_t)i);b[i]=q==guest_memory.end()?0:q->second;}
    return 1;
}
int xemu_cheat_memory_write(int,uint32_t a,const void *p,size_t n){
    ++memory_writes; const auto*b=(const uint8_t*)p;
    for(size_t i=0;i<n;++i)guest_memory[a+(uint32_t)i]=b[i];return 1;
}
int xemu_cheat_patch_virtual(uint32_t a,const void *p,size_t n){++patch_calls;if(patch_fail)return 0;return xemu_cheat_memory_write(1,a,p,n);}
uint64_t xemu_cheat_ram_size(){return 64u*1024u*1024u;}
int xemu_cheat_external_code_allocate(size_t n,uint32_t *p){static uint32_t cursor=0x68010000;*p=cursor;cursor+=(uint32_t)n+32;return 1;}
int xemu_cheat_external_preserve_allocate(size_t n,uint32_t *p){return xemu_cheat_external_code_allocate(n,p);}
const char* xemu_cheat_external_code_last_error(){return "test allocation failure";}
int xemu_cheat_external_code_free(uint32_t,size_t){return 1;}
int xemu_cheat_external_preserve_free(uint32_t,size_t){return 1;}
int xemu_cheat_external_code_write(uint32_t a,size_t offset,const void *p,size_t n){return xemu_cheat_memory_write(1,a+(uint32_t)offset,p,n);}
void xemu_cheat_external_code_reset_allocations(){}
int xemu_cheat_get_x86_registers(XemuCheatX86Registers *p){*p={};p->eip=0x100;p->esp=0x10000;return 1;}
int xemu_cheat_disassembler_available(){return 1;}
int xemu_cheat_disassemble_paired(uint32_t a,int count,XemuCheatDisasmRow *r,size_t cap,size_t *n){
    *n=std::min(cap,(size_t)count);
    for(size_t i=0;i<*n;++i){r[i]={};r[i].virtual_address=a+(uint32_t)i;r[i].size=1;r[i].bytes[0]=0x90;strcpy(r[i].mnemonic,"nop");}return 1;
}
int xemu_cheat_virtual_to_physical(uint32_t a,uint64_t *p){*p=a;return 1;}
int xemu_cheat_prepare_virtual_map(){return 1;}
}
static bool assemble(const std::vector<XemuCheatAsmLine>&lines,XemuCheatAsmResult &r){
    r={}; for(auto &l:lines)if(l.text.find("bad_asm")!=std::string::npos){r.error="test rejected invalid assembly";r.error_line=l.source_line;return false;}
    r.ok=true;r.bytes={0x90};return true;
}
bool xemu_cheat_assemble_x86_32(const std::vector<XemuCheatAsmLine>&l,XemuCheatAsmResult&r){++probe_calls;return assemble(l,r);}
bool xemu_cheat_assemble_x86_32_at(const std::vector<XemuCheatAsmLine>&l,uint32_t,uint32_t,uint32_t,XemuCheatAsmResult&r){++final_calls;return assemble(l,r);}
bool xemu_cheat_assemble_f2_raw_at(const std::vector<XemuCheatAsmLine>&l,uint32_t base,XemuCheatAsmResult&r){if(base)++final_calls;else ++probe_calls;return assemble(l,r);}
// Fault-inject only the requested atomic write; other calls use the real GLib.
#include <glib.h>
int atomic_write_fail_at=0, atomic_write_count=0;
extern "C" gboolean __real_g_file_set_contents_full(const gchar*,const gchar*,gssize,GFileSetContentsFlags,int,GError**);
extern "C" gboolean __wrap_g_file_set_contents_full(const gchar*p,const gchar*d,gssize n,GFileSetContentsFlags f,int mode,GError**e){
 ++atomic_write_count;if(atomic_write_fail_at==atomic_write_count)return 0;
 return __real_g_file_set_contents_full(p,d,n,f,mode,e);
}
