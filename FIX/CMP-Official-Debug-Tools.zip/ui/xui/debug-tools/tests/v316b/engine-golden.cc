#include <bits/stdc++.h>
#define private public
#include "cheat-engine.hh"
#undef private
#include "cheat-source-file.hh"
#include <filesystem>
#include <sys/stat.h>
extern int probe_calls, final_calls, memory_writes, patch_calls;
extern bool patch_fail,pause_valid;
extern int atomic_write_fail_at,atomic_write_count;
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL line "<<__LINE__<<": "<<#x<<"\n";std::exit(1);}}while(0)
static std::string read(const std::string&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
static void write(const std::string&p,const std::string&s){std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
static size_t delete_backups(const std::string&dir){size_t n=0;for(const auto &e:std::filesystem::directory_iterator(dir)){auto f=e.path().filename().string();if(f.find(".delete-")!=std::string::npos&&e.path().extension()==".bak")++n;}return n;}
static void load(CheatEngineWindow&e,const std::string&path,const std::string&s){write(path,s);CHECK(e.LoadSourceFile(path));}
static std::string hook(const std::string&name,const std::string&address,const std::string&body="nop"){
 return "+"+name+"\n%Credits: Tester\n$F0000000 "+address+"\n$"+body+"\n$DEADCODE\n";
}
int main(int argc,char**argv){
 CHECK(argc==3);std::string dir=argv[2];std::filesystem::create_directories(dir);
 std::string path=dir+"/codes.txt",error;
 if (std::string(argv[1]) != "-") {
 CheatEngineWindow e; auto text=read(argv[1]);CHECK(!text.empty());int before=probe_calls;
 load(e,path,text);CHECK(probe_calls==before);CHECK(e.m_blocks.size()==22);
 size_t hooks=0;for(auto&b:e.m_blocks)for(auto&c:b.codes)if((c.command>>28)==15&&((c.command>>24)&15)<=2){++hooks;CHECK(!c.f_precompiled);}
 CHECK(hooks==32);
 std::cout<<"Original BUG fixture: "<<e.m_blocks.size()<<" blocks, "<<hooks<<" F hooks; ZERO probe calls on load\n";
 // Every explicit block can be deleted without crossing groups or neighbours.
 while(!e.m_blocks.empty()){
  size_t idx=e.m_blocks.size()/2;auto old=e.m_source;auto b=e.m_blocks[idx];size_t n=e.m_blocks.size();
  CHECK(b.source_begin!=std::string::npos);CHECK(e.DeleteCodeFromSource(idx,e.m_source_revision,path,error));
  CHECK(e.m_blocks.size()==n-1);old.erase(b.source_begin,b.source_end-b.source_begin);CHECK(read(path)==old);CHECK(e.m_source==old);CHECK(probe_calls==before);
 }
 }
 {
 CheatEngineWindow e;load(e,path,hook("first","00002000")+hook("second","00003000"));
 CHECK(probe_calls==0); e.m_blocks[0].enabled=true;e.ExecuteBlock(0,e.m_blocks[0]);CHECK(probe_calls==1);CHECK(final_calls==1);
 int writes=memory_writes;for(int i=0;i<100;++i)e.ExecuteBlock(0,e.m_blocks[0]);CHECK(probe_calls==1);CHECK(final_calls==1);CHECK(memory_writes==writes);
 e.m_blocks[1].enabled=true;e.ExecuteBlock(1,e.m_blocks[1]);CHECK(e.m_f_hooks.at(1ull<<32).installed);
 auto unaffected=e.m_f_hooks.at(1ull<<32).external_entry;
 CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(e.m_blocks[0].name=="second");CHECK(e.m_blocks[0].enabled);
 CHECK(e.m_f_hooks.at(0).installed);CHECK(e.m_f_hooks.at(0).external_entry==unaffected);CHECK(e.HasResetRequired());
 int final_before=final_calls;e.ExecuteBlock(0,e.m_blocks[0]);CHECK(final_calls==final_before);
 }
 {
 CheatEngineWindow e;load(e,path,"+bad multi-hook\n$20001000 DEADBEEF\n$F0000000 00004000\n$nop\n$DEADCODE\n$F0000000 00005000\n$bad_asm\n$DEADCODE\n");
 e.m_blocks[0].enabled=true;int writes=memory_writes,before=probe_calls;
 e.ExecuteBlock(0,e.m_blocks[0]);CHECK(memory_writes==writes);CHECK(!e.m_blocks[0].enabled);CHECK(!e.m_blocks[0].runtime_error.empty());CHECK(probe_calls==before+2);
 for(int i=0;i<100;++i)e.ExecuteBlock(0,e.m_blocks[0]);CHECK(probe_calls==before+2);CHECK(memory_writes==writes);
 e.m_blocks[0].runtime_error.clear();e.m_blocks[0].enabled=true;e.ExecuteBlock(0,e.m_blocks[0]);
 CHECK(!e.m_blocks[0].runtime_error.empty());CHECK(probe_calls==before+2);CHECK(!e.m_blocks[0].selected);
 }
 {
 CheatEngineWindow e;load(e,path,hook("owner","00006000")+hook("conflict","00006002"));
 e.m_blocks[0].enabled=true;e.ExecuteBlock(0,e.m_blocks[0]);e.m_blocks[1].enabled=true;e.ExecuteBlock(1,e.m_blocks[1]);
 CHECK(e.m_f_hooks.at(0).installed);CHECK(!e.m_blocks[1].enabled);CHECK(e.m_blocks[1].runtime_error.find("owner")!=std::string::npos);
 }
 {
 CheatEngineWindow e;load(e,path,hook("restore-fails","00007000"));e.m_blocks[0].enabled=true;e.ExecuteBlock(0,e.m_blocks[0]);
 auto source=e.m_source;patch_fail=true;CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(read(path)==source);CHECK(e.m_blocks.size()==1);CHECK(e.m_f_hooks.at(0).installed);patch_fail=false;
 pause_valid=false;CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(read(path)==source);pause_valid=true;
 }
 {
 CheatEngineWindow e;auto text=std::string("!Group:\r\n+:PREENTRY:Same\r\n$20000100 00000001\r\n+Same\r\n$F0000000 00008000\r\n$jne Done\r\n$Done:\r\n$nop\r\n$DEADCODE\r\n$Data:\r\n$dd 12345678\r\n; NEXT CODE COMMENT\r\n+Same\r\n$20000104 00000002\r\n!!\r\n");load(e,path,text);
 CHECK(e.m_blocks.size()==3);e.m_blocks[0].preentry_applied=true;e.m_blocks[0].selected=true;e.RememberPreEntrySelection(e.m_blocks[0]);e.m_blocks[2].selected=true;e.m_blocks[2].enabled=true;
 CHECK(e.DeleteCodeFromSource(1,e.m_source_revision,path,error));CHECK(e.m_blocks[0].preentry_applied);CHECK(e.m_blocks[1].identity_ordinal==1);CHECK(e.m_blocks[1].selected&&e.m_blocks[1].enabled);
 CHECK(e.m_source.find("$Data:")==std::string::npos);CHECK(e.m_source.find("; NEXT CODE COMMENT\r\n")!=std::string::npos);CHECK(e.m_source.find("!!\r\n")!=std::string::npos);
 CheatEngineWindow parsed;parsed.m_source=e.m_source;parsed.ParseSource(false);CHECK(parsed.m_blocks.size()==e.m_blocks.size());for(size_t i=0;i<parsed.m_blocks.size();++i)CHECK(parsed.m_blocks[i].source_begin==e.m_blocks[i].source_begin);
 }
 {
 CheatEngineWindow e;load(e,path,"+unterminated\n$F0000000 00001000\n$nop\n+neighbour\n$20000104 00000002\n");CHECK(e.m_blocks.size()==2);CHECK(!e.m_blocks[0].codes[0].f_terminated);CHECK(e.m_blocks[1].name=="neighbour");
 CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(e.m_blocks.size()==1);
 }
 {
 CheatEngineWindow e;load(e,path,hook("stale","00009000"));auto original=e.m_source;write(path,original+"; external edit\n");CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(e.m_source==original);CHECK(read(path)!=original);
 write(path,original);CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision+1,path,error));CHECK(e.m_blocks.size()==1);
 CHECK(chmod(path.c_str(),0444)==0);CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(read(path)==original);chmod(path.c_str(),0644);
 CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path+"x",error));CHECK(e.m_blocks.size()==1);
 }
 {
 auto text=std::string("original\r\n");write(path,text);auto before=delete_backups(dir);CHECK(XemuCheatSource::Replace(path,text,"replacement\n",error));CHECK(read(path)=="replacement\n");CHECK(delete_backups(dir)==before);
 }
 {
 CheatEngineWindow e; load(e,path,hook("hash","00001000"));
 auto &b=e.m_blocks[0]; auto &c=b.codes[0];auto h=e.PersistentContentHash(b);
 c.f_probe_code={0xCC};c.f_probe_data={1,2,3};c.f_uses_temp=true;c.f_temp_bytes=40;c.f_precompiled=true;
 CHECK(e.PersistentContentHash(b)==h);
 c.f_body[0].text="nop ; formatting comment";CHECK(e.PersistentContentHash(b)==h);
 c.f_body[0].text="mov eax, 1234";CHECK(e.PersistentContentHash(b)!=h);
 }
 {
 CheatEngineWindow e;load(e,path,hook("disk-failure","0000A000"));auto source=e.m_source;auto before=delete_backups(dir);
 atomic_write_count=0;atomic_write_fail_at=1;CHECK(!e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(read(path)==source);CHECK(e.m_source==source);CHECK(e.m_blocks.size()==1);CHECK(error.find("replace cheat source")!=std::string::npos);CHECK(delete_backups(dir)==before);
 atomic_write_count=0;atomic_write_fail_at=0;CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));CHECK(e.m_blocks.empty());CHECK(read(path).empty());CHECK(delete_backups(dir)==before);
 }
 {
 // A literal F-looking line inside an A payload must not trigger compilation.
 CheatEngineWindow e;load(e,path,"+literal data\n$A0000100 00000008\n$F0000000 00000000\n");int before=probe_calls;
 CHECK(e.PrepareBlockTypeF(e.m_blocks[0]));CHECK(probe_calls==before);
 }
 std::cout<<"PASS "<<checks<<" engine/deletion assertions (guest bridge + assembler mocked; real GLib atomic file IO)\n";
}
