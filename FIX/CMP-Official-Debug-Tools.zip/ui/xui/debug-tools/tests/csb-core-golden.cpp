#include "../addons/custom-soundtrack-builder/custom-soundtrack-builder-core.hh"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

static uint32_t u32(const std::vector<unsigned char>& b, size_t o) {
    return (uint32_t)b[o] | ((uint32_t)b[o+1] << 8) |
           ((uint32_t)b[o+2] << 16) | ((uint32_t)b[o+3] << 24);
}

int main(int argc, char** argv) {
    const std::string out = argc > 1 ? argv[1] : "/tmp/csb-ST.DB";
    std::vector<XemuCsb::StDbTrack> tracks = {
        {0, 5000, "Sample A"},
        {1, 6000, "Sample B"},
        {2, 7000, "Sample C"},
        {3, 8000, "Sample D"},
        {4, 9000, "Sample E"},
        {5, 10000, "Sample F"},
        {6, 11000, "Sample G"},
    };
    std::string error;
    assert(XemuCsb::WriteStDbOneSoundtrack(out, 2, "CSB Golden", tracks, error));
    std::ifstream in(out, std::ios::binary);
    std::vector<unsigned char> b((std::istreambuf_iterator<char>(in)), {});
    assert(b.size() == 0xCA00 + 2 * 0x200);
    assert(u32(b, 0x0000) == 1);
    assert(u32(b, 0x0004) == 1);
    assert(u32(b, 0x0008) == 3);
    assert(u32(b, 0x000C) == 2);
    assert(u32(b, 0x019C) == 7);
    assert(u32(b, 0x0200) == 0x00021371);
    assert(u32(b, 0x0204) == 2);
    assert(u32(b, 0x0208) == 7);
    assert(u32(b, 0x020C) == 0);
    assert(u32(b, 0x0210) == 1);
    assert(u32(b, 0x035C) == 56000);
    assert(u32(b, 0xCA00) == 0x00031073);
    assert(u32(b, 0xCA04) == 2);
    assert(u32(b, 0xCA10) == 0x00020000);
    assert(u32(b, 0xCA24) == 0x00020005);
    assert(u32(b, 0xCC10) == 0x00020006);
    assert(u32(b, 0xCC00) == 0x00031073);
    assert(u32(b, 0xCC08) == 1);
    assert(XemuCsb::XboxSoundtrackFolderName(0x2a) == "002A");
    assert(XemuCsb::XboxSoundtrackFileName(2, 6) == "00020006.WMA");

    // Multi-soundtrack writer/reader round trip used by TEST5 manager mode.
    const std::string multi = out + ".multi";
    std::vector<XemuCsb::StDbSoundtrack> sets = {
        {0, "Existing Zero", {{0, 1000, "Zero A"}, {3, 2000, "Zero B"}}},
        {7, "Existing Seven", {{2, 3000, "Seven A"}}},
    };
    assert(XemuCsb::WriteStDb(multi, sets, error));
    {
        std::ifstream m(multi, std::ios::binary);
        std::vector<unsigned char> mb((std::istreambuf_iterator<char>(m)), {});
        assert(u32(mb, 0x0004) == 2);
        assert(u32(mb, 0x000C) == 0);
        assert(u32(mb, 0x0010) == 7);
        assert(u32(mb, 0x019C) == 4);
    }
    std::vector<XemuCsb::StDbSoundtrack> parsed;
    XemuCsb::StDbMetadata metadata;
    assert(XemuCsb::ReadStDbFile(multi, parsed, error, &metadata));
    assert(metadata.soundtrack_id_index_matches_records);
    assert(metadata.next_soundtrack_id == 8);
    assert(metadata.next_song_id == 4);
    assert(parsed.size() == 2);
    assert(parsed[0].soundtrack_id == 0 && parsed[0].name == "Existing Zero");
    assert(parsed[0].tracks.size() == 2 && parsed[0].tracks[1].song_id == 3 && parsed[0].tracks[1].title == "Zero B");
    assert(parsed[1].soundtrack_id == 7 && parsed[1].tracks.size() == 1 && parsed[1].tracks[0].song_id == 2);
    // Preserve dashboard monotonic counters even when the current records have
    // lower IDs (for example after deleting the most recently added item).
    const std::string floors = out + ".floors";
    XemuCsb::StDbWriteOptions options;
    options.minimum_next_soundtrack_id = 12;
    options.minimum_next_song_id = 40;
    assert(XemuCsb::WriteStDb(floors, sets, error, options));
    {
        std::ifstream f(floors, std::ios::binary);
        std::vector<unsigned char> fb((std::istreambuf_iterator<char>(f)), {});
        assert(u32(fb, 0x0008) == 12);
        assert(u32(fb, 0x019C) == 40);
        assert(u32(fb, 0x000C) == 0 && u32(fb, 0x0010) == 7);
    }

    // TEST11 wrote only maxSoundtrackId at soundtrackIds[0].  Keep reading
    // that recoverably malformed header, identify it, then prove a rewrite
    // repairs only the index semantics while preserving the soundtrack data.
    std::vector<unsigned char> malformed;
    { std::ifstream m(multi, std::ios::binary); malformed.assign(std::istreambuf_iterator<char>(m), {}); }
    malformed[0x000C] = 7; malformed[0x000D] = malformed[0x000E] = malformed[0x000F] = 0;
    malformed[0x0010] = malformed[0x0011] = malformed[0x0012] = malformed[0x0013] = 0;
    parsed.clear(); metadata = {};
    assert(XemuCsb::ReadStDb(malformed, parsed, error, &metadata));
    assert(!metadata.soundtrack_id_index_matches_records);
    assert(parsed.size() == 2 && parsed[0].soundtrack_id == 0 && parsed[1].soundtrack_id == 7);

    const std::string empty = out + ".empty";
    assert(XemuCsb::WriteStDb(empty, {}, error));
    parsed.clear();
    assert(XemuCsb::ReadStDbFile(empty, parsed, error) && parsed.empty());
    std::puts("PASS: CSB TEST12 dashboard-compatible ST.DB header/packed-ID layout");
    return 0;
}
