#!/usr/bin/env python3
"""v3.16e: compact docs, explicit patch prerequisites and unchanged deletion API."""
from __future__ import annotations
import argparse
from pathlib import Path
import os
from optional_patch_contract import ENVIRONMENT_KEY, OPTIONAL_PATCHES, parse_optional_patches, optional_patch_enabled


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('.'))
    args = parser.parse_args()
    debug = args.root/'ui/xui/debug-tools'
    readme = (debug/'README.md').read_text()
    assert len(readme.splitlines()) <= 80, 'landing README must stay compact'
    assert 'Manifest v3 only' in readme and 'Manifest v2' not in readme
    assert 'no permanent backup' in readme.lower()
    assert not (debug/'docs').exists(), 'obsolete release docs returned to addon source'
    assert (debug/'addons/file-replace/file-replace-v3.schema.json').is_file()
    assert parse_optional_patches('all') == OPTIONAL_PATCHES
    assert parse_optional_patches('none') == frozenset()
    assert parse_optional_patches('10, 40') == frozenset({10,40})
    for bad in ('', '300', '10,', 'bogus', '10,foo', '10,70'):
        try:
            parse_optional_patches(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f'invalid optional-patch declaration accepted: {bad}')
    previous = os.environ.get(ENVIRONMENT_KEY)
    try:
        os.environ.pop(ENVIRONMENT_KEY, None)
        assert all(optional_patch_enabled(n) for n in OPTIONAL_PATCHES), 'default must not weaken full-stack checks'
        os.environ[ENVIRONMENT_KEY]='none'
        assert not any(optional_patch_enabled(n) for n in OPTIONAL_PATCHES)
        os.environ[ENVIRONMENT_KEY]='10,40'
        assert optional_patch_enabled(10) and optional_patch_enabled(40)
        assert not optional_patch_enabled(30)
        os.environ[ENVIRONMENT_KEY]='bad'
        try:
            optional_patch_enabled(10)
        except ValueError:
            pass
        else:
            raise AssertionError('malformed environment silently skipped checks')
    finally:
        if previous is None:
            os.environ.pop(ENVIRONMENT_KEY,None)
        else:
            os.environ[ENVIRONMENT_KEY]=previous
    runner=(debug/'tests/v287-run-regression-tests.py').read_text()
    assert '--optional-patches' in runner and 'rglob("*.py")' in runner
    bridge_stubs=debug/'addons/file-replace/tests/bridge-stubs'
    assert 'qemu_vfree' not in (bridge_stubs/'fake-qemu.h').read_text()
    assert 'void qemu_vfree(void *);' in (bridge_stubs/'qemu/memalign.h').read_text()
    source=(debug/'cheat-source-file.cc').read_text()
    assert 'ReadUnchanged(path, expected, error)' in source
    assert 'G_FILE_SET_CONTENTS_CONSISTENT | G_FILE_SET_CONTENTS_DURABLE' in source
    assert 'g_uuid_string_random' not in source and '.delete-' not in source
    print('PASS: v3.16e compact docs, explicit optional patch contract and no-backup source transaction')


if __name__ == '__main__':
    main()
