#!/usr/bin/env python3
"""Current ownership guard for the v3.10 cleanup."""
from __future__ import annotations
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--root", default=".")
root = Path(parser.parse_args().root).resolve()
debug = root / "ui/xui/debug-tools"

def require(path: Path, needle: str, label: str) -> None:
    data = path.read_text(encoding="utf-8", errors="replace")
    if needle not in data:
        raise AssertionError(f"missing {label}: {needle}")

def forbid(path: Path, needle: str, label: str) -> None:
    data = path.read_text(encoding="utf-8", errors="replace")
    if needle in data:
        raise AssertionError(f"unexpected {label}: {needle}")

# Debug Tools-owned helpers/docs must not leak into the xemu repository root.
for name in ("Build-Xemu-DOCKER.bat", "Build-Xemu-MINGW64.bat", "XEMU_RAW_CHEAT_ENGINE.md"):
    if (root / name).exists():
        raise AssertionError(f"repository-root Debug Tools addition returned: {name}")
if not (debug / "Codetypes/XEMU-Code-Types-Guide.pdf").is_file():
    raise AssertionError("missing Debug Tools-owned code-types guide")

# The retired global Branch/Functions watcher must stay gone while the useful
# conditional branch breakpoint backend remains in the x86 Debugger.
if list((debug / "addons/memory-tools").glob("*branch-function*")):
    raise AssertionError("retired Branch/Functions watcher source returned")
dbg = debug / "addons/memory-tools/memory-tools-debugger.cc"
inject_ui = debug / "addons/memory-tools/memory-tools-inject-ui.cc"
require(dbg, "EvaluateConditionalBranch", "conditional-branch evaluator")
require(inject_ui, 'ImGui::BeginMenu("Branch Breaks")', "conditional-branch breakpoint submenu")
require(inject_ui, "Break when Taken", "taken branch breakpoint")
require(inject_ui, "Break when Not Taken", "not-taken branch breakpoint")

# Controller reconnect behavior is a core XID/input fix and must remain usable
# independently of whether Diagnostics is compiled.
input_c = root / "ui/xemu-input.c"
input_h = root / "ui/xemu-input.h"
require(input_h, "bool                connected;", "host-connected state")
require(input_c, "Reconnect the same host GUID without guest XID re-enumeration", "persistent reconnect")
require(input_c, "guest controller retained", "neutral retained guest XID")

# XBE polling buffer reuse is a core optimization, not Debug Tools UI state.
xbe = root / "xemu-xbe.c"
require(xbe, "static uint32_t headers_capacity;", "XBE header buffer capacity")
require(xbe, "realloc(xbe.headers, xbe.headers_len)", "XBE header buffer reuse")

# Build helper staging is subtree-owned now.
docker = debug / "tools" / "docker-build-windows.sh"
forbid(docker, "for helper in Build-Xemu-DOCKER.bat Build-Xemu-MINGW64.bat", "root helper staging loop")
require(docker, "Debug Tools sources and active helpers are staged from their owning subtree", "subtree helper ownership note")

print("v3.10 cleanup ownership: PASS")
