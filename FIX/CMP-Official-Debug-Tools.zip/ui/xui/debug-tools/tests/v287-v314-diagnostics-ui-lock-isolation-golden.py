#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.14 Diagnostics isolation retained after v3.15 all-detached unlock."""
from __future__ import annotations

import argparse
from pathlib import Path
from optional_patch_contract import optional_patch_enabled


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


def section(text: str, start: str, end: str) -> str:
    begin = text.index(start)
    finish = text.index(end, begin)
    return text[begin:finish]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root)
    debug = root / "ui/xui/debug-tools"

    xemu_c = (root / "ui/xemu.c").read_text(encoding="utf-8")
    hud_cc = (root / "ui/xui/main.cc").read_text(encoding="utf-8")
    hud_h = (root / "ui/xui/xemu-hud.h").read_text(encoding="utf-8")
    input_c = (root / "ui/xemu-input.c").read_text(encoding="utf-8")
    detached_h = (debug / "detached-tools.hh").read_text(encoding="utf-8")
    detached_cc = (debug / "detached-tools.cc").read_text(encoding="utf-8")
    facade_h = (debug / "debug-tools.hh").read_text(encoding="utf-8")
    facade_cc = (debug / "debug-tools.cc").read_text(encoding="utf-8")
    diag_addon = (debug / "addons/diagnostics/debug-tools-diagnostics-addon.cc").read_text(encoding="utf-8")
    diag_h = (debug / "addons/diagnostics/diagnostics.hh").read_text(encoding="utf-8")
    diag_cc = (debug / "addons/diagnostics/diagnostics.cc").read_text(encoding="utf-8")
    mem_addon = (debug / "addons/memory-tools/debug-tools-memory-tools-addon.cc").read_text(encoding="utf-8")
    hdd_addon = (debug / "addons/hdd/debug-tools-hdd-addon.cc").read_text(encoding="utf-8")
    hook = (debug / "addons/diagnostics/bql-trace-hook.h").read_text(encoding="utf-8")

    # The global helper keeps the established main-loop -> BQL order. v3.14
    # changes only where selected UI work is performed relative to that helper.
    require(xemu_c,
            "void xemu_main_loop_lock(void)\n{\n    qemu_mutex_lock_main_loop();\n    bql_lock();",
            "global main-loop/BQL lock order")
    require(xemu_c,
            "    bql_unlock();\n    qemu_mutex_unlock_main_loop();\n}",
            "global BQL/main-loop unlock order")

    # v3.15 generalizes v3.14: the synchronized HUD update ends before every
    # detached frame is built. Diagnostics must remain on that unlocked path.
    render = section(xemu_c,
                     "static void gl_render_frame_common(struct xemu_console *scon, bool playback_only)",
                     "static void gl_render_frame(struct xemu_console *scon)")
    require(render,
            "xemu_main_loop_unlock();\n\n    if (!playback_only) {",
            "HUD lock release before unlocked detached phase")
    require(render, "xemu_hud_build_detached_frames_unlocked();",
            "unlocked detached frame build call")
    require(render, "xemu_hud_render();", "normal render call")
    if not (render.index("xemu_main_loop_unlock();") <
            render.index("xemu_hud_build_detached_frames_unlocked();") <
            render.index("xemu_hud_render();")):
        raise AssertionError("unlocked detached build must occur after unlock and before render")
    require(hud_h, "void xemu_hud_build_detached_frames_unlocked(void);",
            "C HUD unlocked detached bridge")
    forbid(hud_cc, "debug_tools_build_locked_detached_frames",
           "retired locked detached builder")
    require(hud_cc, "void xemu_hud_build_detached_frames_unlocked()",
            "unlocked detached HUD bridge implementation")
    require(hud_cc, "debug_tools_build_unlocked_detached_frames();",
            "unlocked detached facade route")

    # The v3.14 per-tool lock-policy split is intentionally retired by v3.15.
    # Precreate remains an independent host-resource policy.
    forbid(detached_h, "build_outside_emulator_lock",
           "retired per-tool lock policy")
    forbid(detached_h, "trace_stage", "retired locked-build trace field")
    forbid(detached_h, "detached_tools_build_locked_frames",
           "retired locked detached declaration")
    require(detached_h, "void detached_tools_build_unlocked_frames();",
            "unlocked detached declaration")
    forbid(detached_cc, "ScopedLockedDetachedStage",
           "retired locked detached stage scope")
    forbid(detached_cc, "detached_tools_build_locked_frames",
           "retired locked detached implementation")
    require(detached_cc, "BuildToolFrame(tool);",
            "all-tool unlocked frame build")
    forbid(facade_h, "debug_tools_build_locked_detached_frames",
           "retired locked facade declaration")
    require(facade_h, "void debug_tools_build_unlocked_detached_frames();",
            "unlocked detached facade declaration")
    forbid(facade_cc, "detached_tools_build_locked_frames",
           "retired locked facade forwarding")
    require(facade_cc, "detached_tools_build_unlocked_frames();",
            "unlocked detached facade forwarding")

    # Diagnostics retains its precreated window and queued snapshot model.
    require(diag_addon,
            "500,\n        true,\n    });",
            "Diagnostics unlocked/precreated detached registration")
    require(mem_addon,
            "400,\n        true,\n    });",
            "Memory Tools unlocked/precreated detached registration")
    require(hdd_addon,
            "200,\n        false,\n    });",
            "HDD unlocked detached registration")
    require(facade_cc,
            "100,\n        false,\n    });",
            "Current Game unlocked detached registration")
    require(facade_cc,
            "300,\n        false,\n    });",
            "Cheat Engine unlocked detached registration")

    # Manual detached-Diagnostics actions may not sample guest memory directly.
    # They queue requests and Tick performs the synchronized capture next frame.
    draw = section(diag_cc, "void DiagnosticsWindow::Draw(bool detached)", "}",)
    # section() above intentionally ends at the first closing brace and is too
    # short for the buttons; inspect bounded text from Draw start instead.
    draw_start = diag_cc.index("void DiagnosticsWindow::Draw(bool detached)")
    draw_text = diag_cc[draw_start:]
    require(draw_text, "m_manual_refresh_requested = true;",
            "queued manual refresh")
    require(draw_text, "m_manual_snapshot_requested = true;",
            "queued manual snapshot capture")
    refresh_button = section(draw_text,
                             'if (ImGui::Button("Refresh Now"))',
                             'ImGui::SameLine();')
    forbid(refresh_button, "Sample(", "live guest sample from unlocked Refresh button")
    save_start = draw_text.index('if (ImGui::Button("Save Snapshot"))')
    save_end = draw_text.index('ImGui::SameLine();', save_start)
    save_button = draw_text[save_start:save_end]
    forbid(save_button, "QueueSnapshotSave(",
           "live snapshot capture from unlocked Save button")
    for field in ("m_manual_refresh_requested", "m_manual_snapshot_requested"):
        require(diag_h, field, f"Diagnostics queued request field {field}")
    tick = section(diag_cc, "void DiagnosticsWindow::Tick()", "void DiagnosticsWindow::ProcessDeferredActions()")
    require(tick, "if (m_manual_snapshot_requested)",
            "synchronized manual snapshot consumption")
    require(tick, "QueueSnapshotSave(now_ms, false);",
            "synchronized manual snapshot capture")
    require(tick, "if (m_manual_refresh_requested)",
            "synchronized manual refresh consumption")
    require(tick, "Sample(now_ms);", "synchronized Diagnostics sample")

    if optional_patch_enabled(10):
        # Host-poll preparation is host/UI-only and no longer pins global locks.
        # The commit critical section and stale-batch revalidation are preserved.
        poll = section(xemu_c, "static void poll_events(struct xemu_console *scon)",
                       "static void display_very_early_init")
        prep_at = poll.index("xemu_input_host_poll_prepare();")
        commit_at = poll.index("xemu_input_host_poll_commit(host_input_batch);")
        prep_window = poll[max(0, prep_at - 350):prep_at + 80]
        forbid(prep_window, "xemu_main_loop_lock();",
               "main-loop lock around host-poll prepare")
        commit_window = poll[max(0, commit_at - 250):commit_at + 180]
        require(commit_window, "xemu_main_loop_lock();",
                "host-poll commit lock")
        require(commit_window, "xemu_main_loop_unlock();",
                "host-poll commit unlock")
        require(input_c, "xemu_input_host_poll_find_live_state(entry)",
                "host-poll stale ControllerState revalidation")
        require(input_c, "iter->sdl_gamepad != entry->sdl_gamepad",
                "host-poll SDL handle revalidation")
        require(input_c, "iter->sdl_joystick_id != entry->sdl_joystick_id",
                "host-poll joystick ID revalidation")

    # v3.15 retires the per-detached-window BQL stages because those frames no
    # longer execute while BQL is held. Live stage IDs retain their old values.
    require(hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_HUD_CORE", "HUD BQL stage")
    require(hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_TICK", "tick BQL stage")
    require(hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT = 4",
            "stable SDL-event BQL stage ID")
    for name in (
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_DETACHED_BUILD",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CURRENT_GAME",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_HDD_DIRECTORY",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CHEAT_ENGINE",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_MEMORY_TOOLS",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_DIAGNOSTICS",
    ):
        forbid(hook, name, f"retired detached stage {name}")
        forbid(diag_cc, name, f"retired Diagnostics stage presentation {name}")

    # Generic fix only: no title/address/timer special cases in the changed root
    # integration or detached-host implementation.
    combined = "\n".join((xemu_c, hud_cc, detached_cc, diag_cc))
    for marker in ("Def Jam", "45410049", "00216445", "00263080"):
        forbid(combined, marker, f"title-specific marker {marker}")

    print("PASS: v3.14 Diagnostics isolation remains intact under v3.15 all-detached unlock")


if __name__ == "__main__":
    main()
