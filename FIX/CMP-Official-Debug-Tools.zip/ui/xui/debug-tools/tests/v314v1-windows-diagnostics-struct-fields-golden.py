#!/usr/bin/env python3
"""v3.14v1 guard for Diagnostics table/event-struct field ownership."""
from __future__ import annotations

import argparse
import pathlib
import re


def between(text: str, start: str, end: str, label: str) -> str:
    try:
        a = text.index(start)
        b = text.index(end, a + len(start))
    except ValueError as exc:
        raise AssertionError(f"missing {label} bounds") from exc
    return text[a:b]


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"forbidden {label}: {needle}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = pathlib.Path(args.root)
    diag_dir = root / "ui/xui/debug-tools/addons/diagnostics"

    diag = (diag_dir / "diagnostics.cc").read_text(encoding="utf-8")
    # Visibility guards add one indentation level; preserve exact table bounds.
    diag = re.sub(r'(ImGui::BeginTable\(\n)[ \t]+', r'\1                ', diag)
    inc_types = (diag_dir / "pgraph-ptimer-latency-trace-types.h").read_text(encoding="utf-8")
    pusher_types = (diag_dir / "pgraph-pusher-progress-trace.h").read_text(encoding="utf-8")

    # Verify the two event layouts that the Windows compiler caught us mixing.
    inc_struct = between(
        inc_types,
        "typedef struct XemuDebugToolsPgraphIncrementEvent {",
        "} XemuDebugToolsPgraphIncrementEvent;",
        "PGRAPH increment struct",
    )
    pusher_struct = between(
        pusher_types,
        "typedef struct XemuDebugToolsPgraphPusherProgressEvent {",
        "} XemuDebugToolsPgraphPusherProgressEvent;",
        "pusher progress struct",
    )
    require(inc_struct, "surface_update_ns", "PGRAPH increment surface-update field")
    forbid(inc_struct, "dma_put_to_event_ns", "pusher-only field in PGRAPH increment struct")
    require(pusher_struct, "dma_put_to_event_ns", "pusher DMA-PUT latency field")
    forbid(pusher_struct, "surface_update_ns", "increment-only field in pusher struct")

    # Guard the specific UI tables so a source-only test cannot pass merely
    # because both field names exist somewhere else in diagnostics.cc.
    inc_ui = between(
        diag,
        'ImGui::BeginTable(\n                "pgraph_increment_trace"',
        'ImGui::TextUnformatted("FLIP_STALL / VBlank Investigator")',
        "PGRAPH increment UI",
    )
    require(inc_ui, "e.surface_update_ns", "PGRAPH increment UI surface update")
    forbid(inc_ui, "e.dma_put_to_event_ns", "pusher field in PGRAPH increment UI")

    pusher_ui = between(
        diag,
        'ImGui::BeginTable(\n                "pgraph_pusher_progress"',
        'ImGui::TextUnformatted("Xbox Scheduler / Thread Wake Investigator")',
        "pusher progress UI",
    )
    require(pusher_ui, 'ImGui::TableSetupColumn("PUT->event")', "pusher latency column")
    require(pusher_ui, "e.dma_put_to_event_ns", "pusher UI DMA-PUT latency")
    forbid(pusher_ui, "e.surface_update_ns", "increment field in pusher UI")

    print("PASS: v3.14v1 Diagnostics event-struct field ownership guard")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
