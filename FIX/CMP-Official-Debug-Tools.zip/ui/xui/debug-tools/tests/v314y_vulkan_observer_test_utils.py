"""Narrow C token/observation normalization for the v3.14y Vulkan regression.

Only the added draw-stage include and whitelisted, read-only stage calls are
removed. Legacy finish instrumentation, every renderer operation, condition,
assertion, and preprocessor directive remains part of the frozen token sequence.
"""
from __future__ import annotations

import hashlib
import re

DRAW_PATH = "hw/xbox/nv2a/pgraph/vk/draw.c"
HOOK_INCLUDE = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace-hook.h"'
BEGIN = "xemu_debug_tools_pgraph_draw_trace_stage_begin"
END = "xemu_debug_tools_pgraph_draw_trace_stage_end"
PREFIX = "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_"
STAGES = frozenset(PREFIX + s for s in (
    "VK_DRAW_END_TOTAL", "VK_FLUSH_DRAW", "VK_VERTEX_BIND", "VK_ELEMENT_SCAN",
    "VK_SYNC_VERTEX_RAM", "VK_REMAP_ATTRIBUTES", "VK_PRE_DRAW", "VK_PIPELINE_PREP",
    "VK_FRAMEBUFFER_PREP", "VK_DESCRIPTOR_UPDATE", "VK_COMMAND_BUFFER", "VK_UPLOAD",
    "VK_BEGIN_DRAW", "VK_RENDER_PASS", "VK_PIPELINE_BIND", "VK_DESCRIPTOR_BIND",
    "VK_ISSUE_DRAW", "VK_END_DRAW", "VK_SURFACE_DIRTY",
    "VK_TEXTURE_BIND",
    "VK_SHADER_BIND",
    "VK_PIPELINE_STATE_KEY",
    "VK_PIPELINE_CACHE_LOOKUP",
    "VK_PIPELINE_BUILD_STATE",
    "VK_PIPELINE_CREATE",
    "VK_PIPELINE_INSTALL",
    "VK_VERTEX_RANGE_PREP",
    "VK_VERTEX_DIRTY_CHECK",
    "VK_VERTEX_RANGE_UPDATE",
    "VK_VERTEX_SURFACE_DOWNLOAD",
    "VK_VERTEX_OVERLAP_CHECK",
    "VK_VERTEX_DIRTY_FINISH",
    "VK_VERTEX_COPY",
    "VK_VERTEX_BITMAP",
    "VK_FINISH_TOTAL",
    "VK_FINISH_QUEUE_SUBMIT",
    "VK_FINISH_FENCE_WAIT",

))
# Explicitly enumerated read-only expressions; calls, stores, ++/-- and arbitrary
# new expressions cannot be hidden from the behavioral comparison as "tracing".
VALUES = frozenset({'(depth_test||stencil_test)?1:0',
    '0',
    'color_write?1:0',
    'index_count',
    'index_data_size',
    'inline_array_data_size',
    'max_element',
    'max_element+1',
    'min_element',
    'offset',
    'pg->clearing?1:0',
    'pg->draw_arrays_length',
    'pg->draw_arrays_max_count',
    'pg->draw_arrays_min_start',
    'pg->inline_array_length',
    'pg->inline_buffer_length',
    'pg->inline_elements_length',
    'r->framebuffer_dirty?1:0',
    'r->in_command_buffer?1:0',
    'r->in_render_pass?1:0',
    'r->num_active_vertex_attribute_descriptions',
    'r->query_in_flight?1:0',
    'render_pass_dirty?1:0',
    'vertex_size', 'finish_reason', 'size', 'num_syncs',
    'r->num_vertex_ram_buffer_syncs', '1'})
TOKEN = re.compile(
    r'/\*[\s\S]*?\*/|//[^\n]*|(?:u8|[LuU])?"(?:\\.|[^"\\])*"'
    r"|(?:[LuU])?'(?:\\.|[^'\\])*'"
    r'|[A-Za-z_]\w*|(?:0[xX][0-9A-Fa-f]+|\d+(?:\.\d*)?)(?:[eEpP][+-]?\d+)?[uUlLfF]*'
    r'|>>=|<<=|->|\+\+|--|==|!=|<=|>=|&&|\|\||<<|>>|\+=|-=|\*=|/=|%=|&=|\^=|\|=|##'
    r'|[^\s]'
)
# Generated from the v3.14w package, NOT from the candidate being tested.
BASELINE_V314W_TOKEN_SHA256 = "BBF2A0145A7A708F8B6159D4A9E6FF872A1CEA4A4D07E147F0C01E6F632F0589"
BASELINE_V314W_RAW_SHA256 = "D2D41340446E85109DB390C8B67F782AB50443B0102107BCDAC63247B8F97A94"
EXPECTED_PRE_DRAW = r"""static void begin_pre_draw(PGRAPHState *pg)
{
    PGRAPHVkState *r = pg->vk_renderer_state;

    assert(r->color_binding || r->zeta_binding);
    assert(!r->color_binding || r->color_binding->initialized);
    assert(!r->zeta_binding || r->zeta_binding->initialized);

    if (pg->clearing) {
        create_clear_pipeline(pg);
    } else {
        create_pipeline(pg);
    }

    bool render_pass_dirty = r->pipeline_binding->render_pass != r->render_pass;

    if (r->framebuffer_dirty || render_pass_dirty) {
        pgraph_vk_ensure_not_in_render_pass(pg);
    }
    if (render_pass_dirty) {
        r->render_pass = r->pipeline_binding->render_pass;
    }
    if (r->framebuffer_dirty) {
        create_frame_buffer(pg);
        r->framebuffer_dirty = false;
    }
    if (!pg->clearing) {
        pgraph_vk_update_descriptor_sets(pg);
    }
    if (r->framebuffer_index == 0) {
        create_frame_buffer(pg);
    }

    pgraph_vk_ensure_command_buffer(pg);
}"""


def tokens(source: str) -> list[str]:
    return [m.group(0) for m in TOKEN.finditer(source)
            if not m.group(0).startswith(('/*', '//'))]


def function(source: str, signature: str) -> str:
    start = source.index(signature)
    opening = source.index('{', start)
    depth = 0
    # Consume strings/comments atomically so their braces are not scope braces.
    for match in TOKEN.finditer(source, opening):
        token = match.group(0)
        if token == '{':
            depth += 1
        elif token == '}':
            depth -= 1
            if depth == 0:
                return source[start:match.end()]
    raise AssertionError(f"Unterminated function: {signature}")


def strip_stage_hooks(source: str) -> str:
    source = source.replace(HOOK_INCLUDE, '')
    pattern = re.compile(r'\b(' + BEGIN + '|' + END + r')\s*\(([^;]*?)\)\s*;')
    def remove(match: re.Match[str]) -> str:
        name = match.group(1)
        args = [tokens(s) for s in match.group(2).split(',')]
        wanted = 4 if name == BEGIN else 1
        if len(args) != wanted or len(args[0]) != 1 or args[0][0] not in STAGES:
            raise AssertionError('Unexpected draw-stage hook form: ' + match.group(0))
        if name == BEGIN:
            if args[1] != ['pg'] or any(''.join(a) not in VALUES for a in args[2:]):
                raise AssertionError('Non-whitelisted or side-effecting observation argument: '
                                     + match.group(0))
        return ''
    result = pattern.sub(remove, source)
    cache_name = 'xemu_debug_tools_pgraph_draw_trace_pipeline_cache'
    cache_pattern = re.compile(r'\b' + cache_name + r'\s*\(([^;]*?)\)\s*;')
    cache_values = {'XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_' + v for v in
                    ('FAST_REUSE', 'CACHE_HIT', 'CACHE_MISS')}
    def remove_cache(match):
        if tokens(match.group(1)) not in [[v] for v in cache_values]:
            raise AssertionError('Non-whitelisted pipeline outcome hook: ' + match.group(0))
        return ''
    result = cache_pattern.sub(remove_cache, result)
    if cache_name in result:
        raise AssertionError('Unrecognized pipeline outcome hook')
    metric_name = 'xemu_debug_tools_pgraph_draw_trace_metric'
    metric_pattern = re.compile(r'\b' + metric_name + r'\s*\(([^;]*?)\)\s*;')
    metric_values = {
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_REQUESTED_RANGES': 'r->num_vertex_ram_buffer_syncs',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_MERGED_RANGES': 'num_syncs',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_TESTED_BYTES': 'size',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_RANGES': '1',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_BYTES': 'size',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_CALLS': '1',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_BYTES': 'size',
        'XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_OVERLAP_FINISHES': '1',
    }
    def remove_metric(match):
        args = [''.join(tokens(s)) for s in match.group(1).split(',')]
        if len(args) != 2 or metric_values.get(args[0]) != args[1]:
            raise AssertionError('Non-whitelisted metric hook: ' + match.group(0))
        return ''
    result = metric_pattern.sub(remove_metric, result)
    if metric_name in result:
        raise AssertionError('Unrecognized metric hook')
    # Ending predicate observation on the unchanged false branch leaves a
    # semantically empty else after hooks are removed. No nonempty else is erased.
    result = re.sub(r'\belse\s*\{\s*\}', '', result)
    if BEGIN in result or END in result:
        raise AssertionError('Unrecognized draw-stage hook remains after normalization')
    return result


def token_hash(source: str) -> str:
    return hashlib.sha256('\n'.join(tokens(source)).encode()).hexdigest().upper()


def check_vk_observation_only(source: str) -> None:
    behavior = strip_stage_hooks(source)
    pre_draw = function(behavior, 'static void begin_pre_draw(PGRAPHState *pg)')
    if tokens(pre_draw) != tokens(EXPECTED_PRE_DRAW):
        raise AssertionError('begin_pre_draw renderer ordering/logic differs from v3.14w: '
                             'descriptor update MUST precede zero-framebuffer recovery')
    if token_hash(behavior) != BASELINE_V314W_TOKEN_SHA256:
        raise AssertionError('Vulkan draw.c has a non-observational change relative to v3.14w')
