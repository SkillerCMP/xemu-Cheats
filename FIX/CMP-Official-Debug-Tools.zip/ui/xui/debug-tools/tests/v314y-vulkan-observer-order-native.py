#!/usr/bin/env python3
"""Compile the ACTUAL begin_pre_draw against deterministic renderer dependency stubs.

No GPU, Vulkan driver, or game is exercised. Descriptor/uniform exhaustion and
pipeline/framebuffer flushing are modeled dependency effects. The candidate
function, not a reimplementation, is compiled and compared with frozen v3.14w.
"""
from __future__ import annotations
import argparse
import os
import pathlib
import subprocess
import tempfile
from v314y_vulkan_observer_test_utils import DRAW_PATH, EXPECTED_PRE_DRAW, function

HARNESS = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace-hook.h"

typedef struct SurfaceBinding { bool initialized; } SurfaceBinding;
typedef struct PipelineBinding { unsigned int render_pass; } PipelineBinding;
typedef struct PGRAPHVkState {
    SurfaceBinding *color_binding, *zeta_binding;
    PipelineBinding *pipeline_binding;
    bool framebuffer_dirty, in_command_buffer, in_render_pass;
    unsigned int framebuffer_index, render_pass;
    unsigned int descriptor_reset_mask;
    bool pipeline_flush;
} PGRAPHVkState;
typedef struct PGRAPHState {
    PGRAPHVkState *vk_renderer_state;
    bool clearing;
} PGRAPHState;

enum { OP_PIPELINE = 1, OP_CLEAR_PIPELINE, OP_END_RENDER_PASS, OP_FRAMEBUFFER,
       OP_DESCRIPTOR, OP_DESCRIPTOR_FLUSH, OP_PIPELINE_FLUSH,
       OP_FRAMEBUFFER_FLUSH, OP_COMMAND_BUFFER };
static unsigned int op_log[64], op_count, trace_stack[32], trace_depth, trace_count;
static bool trace_enabled;
static void op(unsigned int code) { assert(op_count < 64); op_log[op_count++] = code; }
static void finish(PGRAPHState *pg, unsigned int reason)
{
    PGRAPHVkState *r = pg->vk_renderer_state;
    op(reason);
    if (r->in_command_buffer) {
        r->framebuffer_index = 0;
        r->in_command_buffer = false;
        r->in_render_pass = false;
    }
}
static void create_pipeline(PGRAPHState *pg)
{
    op(OP_PIPELINE);
    if (pg->vk_renderer_state->pipeline_flush) finish(pg, OP_PIPELINE_FLUSH);
}
static void create_clear_pipeline(PGRAPHState *pg)
{
    op(OP_CLEAR_PIPELINE);
    if (pg->vk_renderer_state->pipeline_flush) finish(pg, OP_PIPELINE_FLUSH);
}
static void pgraph_vk_ensure_not_in_render_pass(PGRAPHState *pg)
{
    op(OP_END_RENDER_PASS);
    pg->vk_renderer_state->in_render_pass = false;
}
static void create_frame_buffer(PGRAPHState *pg)
{
    PGRAPHVkState *r = pg->vk_renderer_state;
    op(OP_FRAMEBUFFER);
    if (r->framebuffer_index >= 4) finish(pg, OP_FRAMEBUFFER_FLUSH);
    assert(r->framebuffer_index < 4);
    ++r->framebuffer_index;
}
static void pgraph_vk_update_descriptor_sets(PGRAPHState *pg)
{
    op(OP_DESCRIPTOR);
    /* Mirrors the source reset boundary for descriptor or UBO exhaustion. */
    if (pg->vk_renderer_state->descriptor_reset_mask) finish(pg, OP_DESCRIPTOR_FLUSH);
}
static void pgraph_vk_ensure_command_buffer(PGRAPHState *pg)
{
    op(OP_COMMAND_BUFFER);
    pg->vk_renderer_state->in_command_buffer = true;
}

/* Test observers intentionally only touch diagnostic counters/stack. Real
 * recorder code is not substituted for the renderer dependency stubs here. */
void xemu_debug_tools_pgraph_draw_trace_stage_begin(
    unsigned int stage, const void *pg, uint64_t value0, uint64_t value1)
{
    (void)pg; (void)value0; (void)value1;
    if (!trace_enabled) return;
    assert(trace_depth < 32);
    trace_stack[trace_depth++] = stage;
    ++trace_count;
}
void xemu_debug_tools_pgraph_draw_trace_stage_end(unsigned int stage)
{
    if (!trace_enabled) return;
    assert(trace_depth > 0);
    assert(trace_stack[--trace_depth] == stage);
}

@REFERENCE@
@CANDIDATE@

static bool same_state(const PGRAPHVkState *a, const PGRAPHVkState *b)
{
    return a->framebuffer_dirty == b->framebuffer_dirty &&
           a->framebuffer_index == b->framebuffer_index &&
           a->render_pass == b->render_pass &&
           a->in_command_buffer == b->in_command_buffer &&
           a->in_render_pass == b->in_render_pass;
}

int main(void)
{
    SurfaceBinding surface = { .initialized = true };
    unsigned int cases = 0, mismatches = 0, invalid_framebuffers = 0;
    const unsigned int indices[] = {0, 1, 3, 4};
    for (unsigned int enabled = 0; enabled < 2; ++enabled)
    for (unsigned int clearing = 0; clearing < 2; ++clearing)
    for (unsigned int reset = 0; reset < 4; ++reset)
    for (unsigned int dirty = 0; dirty < 2; ++dirty)
    for (unsigned int pass_dirty = 0; pass_dirty < 2; ++pass_dirty)
    for (unsigned int command = 0; command < 2; ++command)
    for (unsigned int in_pass = 0; in_pass < 2; ++in_pass)
    for (unsigned int pipeline_flush = 0; pipeline_flush < 2; ++pipeline_flush)
    for (unsigned int ix = 0; ix < sizeof(indices)/sizeof(indices[0]); ++ix) {
        unsigned int index = indices[ix];
        /* Exclude impossible initial ownership states. */
        if ((!command && index) || (in_pass && (!command || !index))) continue;
        PipelineBinding pipeline = { .render_pass = pass_dirty ? 2u : 1u };
        PGRAPHVkState reference = {
            .color_binding = &surface, .zeta_binding = NULL,
            .pipeline_binding = &pipeline, .framebuffer_dirty = dirty != 0,
            .in_command_buffer = command != 0, .in_render_pass = in_pass != 0,
            .framebuffer_index = index, .render_pass = 1,
            .descriptor_reset_mask = reset, .pipeline_flush = pipeline_flush != 0,
        };
        PGRAPHVkState candidate = reference;
        PGRAPHState ref_pg = { .vk_renderer_state = &reference, .clearing = clearing != 0 };
        PGRAPHState test_pg = { .vk_renderer_state = &candidate, .clearing = clearing != 0 };
        unsigned int expected_ops[64], expected_count;
        op_count = trace_depth = trace_count = 0;
        trace_enabled = false;
        reference_begin_pre_draw(&ref_pg);
        assert(reference.framebuffer_index > 0 && reference.in_command_buffer);
        expected_count = op_count;
        memcpy(expected_ops, op_log, sizeof(expected_ops));
        op_count = trace_depth = trace_count = 0;
        trace_enabled = enabled != 0;
        candidate_begin_pre_draw(&test_pg);
        if (!candidate.framebuffer_index || !candidate.in_command_buffer ||
            !same_state(&reference, &candidate) || op_count != expected_count ||
            memcmp(expected_ops, op_log, op_count * sizeof(op_log[0])) != 0) {
            ++mismatches;
            if (candidate.framebuffer_index == 0) ++invalid_framebuffers;
            if (mismatches <= 2 || (candidate.framebuffer_index == 0 && invalid_framebuffers <= 2))
            fprintf(stderr, "FAIL renderer order: trace=%u clear=%u reset=%u dirty=%u "
                    "pass_dirty=%u cmd=%u in_pass=%u pipeline_flush=%u index=%u -> "
                    "candidate framebuffer_index=%u, expected=%u\n",
                    enabled, clearing, reset, dirty, pass_dirty, command, in_pass,
                    pipeline_flush, index, candidate.framebuffer_index, reference.framebuffer_index);
        }
        assert(trace_depth == 0);
        assert(enabled ? trace_count > 0 : trace_count == 0);
        ++cases;
    }
    if (mismatches) {
        fprintf(stderr, "FAIL: %u/%u cases differ; %u cases leave framebuffer_index=0\n",
                mismatches, cases, invalid_framebuffers);
        return 1;
    }
    printf("PASS: actual begin_pre_draw matches frozen v3.14w operations/state in %u cases "
           "(trace on/off, clear/draw, descriptor/UBO flush, dirty/recovery, pipeline flush)\n", cases);
    return 0;
}
'''


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--compiler', required=True)
    parser.add_argument('--source', help='Alternate actual draw.c for negative-control validation')
    parser.add_argument('--sanitize', action='store_true')
    args = parser.parse_args()
    root = pathlib.Path(args.root).resolve()
    path = pathlib.Path(args.source) if args.source else root / DRAW_PATH
    candidate = function(path.read_text(), 'static void begin_pre_draw(PGRAPHState *pg)')
    candidate = candidate.replace('static void begin_pre_draw(', 'static void candidate_begin_pre_draw(', 1)
    reference = EXPECTED_PRE_DRAW.replace('static void begin_pre_draw(', 'static void reference_begin_pre_draw(', 1)
    harness = HARNESS.replace('@REFERENCE@', reference).replace('@CANDIDATE@', candidate)
    with tempfile.TemporaryDirectory(prefix='xemu-vulkan-observer-order-') as tmp:
        src = pathlib.Path(tmp) / 'observer-order.c'
        exe = pathlib.Path(tmp) / ('observer-order.exe' if os.name == 'nt' else 'observer-order')
        src.write_text(harness)
        cmd = [args.compiler, '-x', 'c', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror',
               '-I', str(root), str(src), '-o', str(exe)]
        if args.sanitize:
            cmd += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer']
        subprocess.run(cmd, check=True)
        subprocess.run([str(exe)], check=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
