#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.07-derived Controller/XID reconnect diagnostics + persistence guard."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


def require(text: str, needle: str, message: str) -> None:
    if needle not in text:
        raise AssertionError(message)


def forbid(text: str, needle: str, message: str) -> None:
    if needle in text:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    diag = debug / "addons/diagnostics"

    hook_rel = "ui/xui/debug-tools/addons/diagnostics/controller-xid-trace-hook.h"
    normal_hook_files = {
        "ui/xemu-input.c",
        "hw/xbox/xid.c",
        "hw/xbox/xid-gamepad.c",
        "hw/usb/hcd-ohci.c",
        "ui/xui/input-manager.cc",
    }

    # Controller/XID/OHCI observation hooks must remain tiny and isolated to
    # exactly these five normal xemu source files.
    seen = set()
    for base in (root / "ui", root / "hw"):
        for path in base.rglob("*"):
            if not path.is_file() or "debug-tools" in path.parts:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if "controller_xid_trace" in text or "controller-xid-trace-hook.h" in text:
                seen.add(path.relative_to(root).as_posix())
    if seen != normal_hook_files:
        raise AssertionError(
            f"Controller/XID normal-source hook isolation changed: {sorted(seen)}"
        )

    input_c = (root / "ui/xemu-input.c").read_text(encoding="utf-8")
    xid_c = (root / "hw/xbox/xid.c").read_text(encoding="utf-8")
    xid_gamepad_c = (root / "hw/xbox/xid-gamepad.c").read_text(encoding="utf-8")
    ohci_c = (root / "hw/usb/hcd-ohci.c").read_text(encoding="utf-8")
    input_manager = (root / "ui/xui/input-manager.cc").read_text(encoding="utf-8")
    core = input_c + xid_c + xid_gamepad_c + ohci_c + input_manager

    require(input_c, "HOST_GAMEPAD_ADDED", "host SDL add observation missing")
    require(input_c, "HOST_GAMEPAD_OPENED", "host SDL open observation missing")
    require(input_c, "HOST_GAMEPAD_REMOVED", "host SDL remove observation missing")
    require(input_c, "HOST_BIND", "host bind observation missing")
    require(input_c, "HOST_UNBIND", "host unbind observation missing")
    require(input_c, "trace_host_state", "independent host state observation missing")
    require(xid_c, "XID_GET_REPORT", "GET_REPORT observation missing")
    require(xid_gamepad_c, "XID_INTERRUPT_IN", "interrupt-IN observation missing")
    require(xid_c, "trace_xid_state", "mapped XID state observation missing")
    require(xid_gamepad_c, "XID_REALIZE", "XID realize observation missing")
    require(xid_c, "XID_UNREALIZE", "XID unrealize observation missing")
    require(xid_c, "XID_RESET", "XID reset observation missing")
    require(xid_c, "USB_CONTROL_REQUEST", "XID USB control-request observation missing")
    require(ohci_c, "OHCI_PORT_ATTACH", "OHCI root-port attach observation missing")
    require(ohci_c, "OHCI_PORT_DETACH", "OHCI root-port detach observation missing")
    require(ohci_c, "OHCI_PORT_RESET", "OHCI root-port reset observation missing")
    require(ohci_c, "OHCI_RHSC", "OHCI root-hub status-change observation missing")
    require(ohci_c, "OHCI_SETUP_TD", "OHCI setup-TD observation missing")
    require(ohci_c, "OHCI_TD_DEVICE_MISSING", "OHCI missing-device TD observation missing")
    require(ohci_c, "OHCI_TD_COMPLETE", "OHCI endpoint-2 IN completion observation missing")
    require(ohci_c, "OHCI_DONE_HEAD", "OHCI done-head observation missing")
    require(ohci_c, "OHCI_WDH_IRQ", "OHCI WDH interrupt observation missing")
    require(ohci_c, "trace_guest_input_write",
            "OHCI endpoint-2 guest-memory write observation missing")
    require(xid_gamepad_c, "trace_xid_packet_complete",
            "XID packet-completion observation missing")

    require(input_c, "HOST_PERSISTENT_NEUTRAL",
            "persistent neutral host transition missing")
    require(input_c, "HOST_PERSISTENT_REATTACHED",
            "persistent host reattach transition missing")
    require(input_c, "guest controller retained",
            "host disconnect no longer documents guest-XID retention")
    forbid(input_c, "xemu_input_bind(iter->bound, NULL, 0);",
           "temporary SDL removal still unplugs the guest controller")
    require(input_manager, "trace_input_mode", "input test-mode trace hook missing")
    require(input_manager, "input_rebinding ||\n        main_scene_active",
            "main xemu Settings/menu scene no longer exclusively owns controller input")
    forbid(input_manager, "main_scene_active && io.NavActive && controller_activity",
           "menu capture still waits one frame for controller activity")
    require(input_manager, "g_scene_mgr.IsDisplayingScene()",
            "input capture is no longer scoped to the main xemu scene")
    require(input_manager, "input_rebinding ||",
            "input rebinding no longer explicitly owns guest-input suppression")

    # The pre-existing assert(state) behavior is deliberate: diagnostics records
    # the missing binding immediately before the same assertion; it does not fix
    # or bypass the failure.
    missing = xid_c.index("XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_BOUND_MISSING")
    assertion = xid_c.index("assert(state);", missing)
    if not (missing < assertion):
        raise AssertionError("XID_BOUND_MISSING must be recorded before assert(state)")
    require(xid_c, "assert(state);", "existing XID bound-state assertion removed")

    # No game-specific policy is allowed in these controller/XID hooks.
    for leaked in ("Def Jam", "45410049", "45410042", "def_jam_ffny"):
        forbid(core, leaked, f"game-specific metadata leaked into Controller/XID hooks: {leaked}")

    hook = (diag / "controller-xid-trace-hook.h").read_text(encoding="utf-8")
    recorder = (diag / "controller-xid-trace.c").read_text(encoding="utf-8")
    backend = (diag / "diagnostics-backend.c").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    stub = (debug / "addons/stubs/controller-xid-trace-stub.c").read_text(encoding="utf-8")

    require(hook, "HOST_INPUT_STATE", "host-state hook contract missing")
    require(hook, "XID_INPUT_STATE", "XID-state hook contract missing")
    require(hook, "XID_BOUND_MISSING", "missing-bound hook contract missing")
    require(hook, "OHCI_PORT_ATTACH", "OHCI hook contract missing")
    require(hook, "USB_CONTROL_REQUEST", "USB enumeration hook contract missing")
    require(hook, "HOST_PERSISTENT_NEUTRAL", "persistent-neutral hook contract missing")
    require(hook, "INPUT_TEST_MODE_ON", "input-test-mode hook contract missing")
    require(hook, "XID_IN_PACKET_COMPLETE", "XID packet-completion hook contract missing")
    require(hook, "OHCI_TD_COMPLETE", "OHCI TD-completion hook contract missing")
    require(hook, "OHCI_WDH_IRQ", "OHCI WDH hook contract missing")
    require(hook, "OHCI_GUEST_INPUT_WRITE",
            "OHCI guest-memory write hook contract missing")
    require(hook, "trace_guest_input_write",
            "OHCI guest-memory write hook function missing")
    require(recorder, "XemuControllerXidPacketSignature",
            "XID report change/heartbeat coalescing missing")
    require(recorder, "XemuControllerXidGuestWriteSignature",
            "guest-memory report change/heartbeat coalescing missing")
    require(recorder, "report[XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX]",
            "full 20-byte XID report retention missing")
    require(recorder, "input_mode_valid", "input test-mode transition coalescing missing")
    require(recorder, "XEMU_CONTROLLER_XID_HEARTBEAT_NS 1000000000ULL",
            "1-second state/poll heartbeat throttle missing")
    require(recorder, "total_observations++", "all-observation counter missing")
    require(recorder, "memcmp(last->axis", "host state-change coalescing missing")
    require(recorder, "memcmp(last->xid_analog", "XID state-change coalescing missing")
    require(backend, "xemu_diagnostics_get_controller_xid_trace_status",
            "Diagnostics backend bridge missing")
    require(ui, "Controller / XID / OHCI USB Reconnect Trace", "Diagnostics UI section missing")
    require(ui, "Check All Recording Options", "NV2A/PTIMER Check All recording checkbox missing")
    require(ui, 'ImGui::Button("Clear All")', "NV2A/PTIMER Clear All diagnostics button missing")
    for clear_call in (
        "xemu_diagnostics_ptimer_trace_clear();",
        "xemu_diagnostics_qemu_timer_trace_clear();",
        "xemu_diagnostics_slow_timer_trace_clear();",
        "xemu_diagnostics_ohci_slow_frame_trace_clear();",
        "xemu_diagnostics_pgraph_increment_trace_clear();",
        "xemu_diagnostics_ptimer_irq_latency_trace_clear();",
        "xemu_diagnostics_controller_input_poll_trace_clear();",
        "xemu_diagnostics_bql_trace_clear();",
        "xemu_diagnostics_mmio_trace_clear();",
        "xemu_diagnostics_pgraph_lock_trace_clear();",
        "xemu_diagnostics_pgraph_draw_trace_clear();",
        "xemu_diagnostics_controller_xid_trace_clear();",
    ):
        require(ui, clear_call, f"Clear All missing recorder reset: {clear_call}")
    require(ui, 'm_sample_count = 0;', "Clear All does not reset diagnostic sample count")
    require(ui, 'm_events.clear();', "Clear All does not reset Recent Events")
    require(ui, 'm_pc_history.clear();', "Clear All does not reset CPU stall history")
    require(ui, "counters count every observation", "throttle/counter UI explanation missing")
    require(ui, "OHCI_GUEST_INPUT_WRITE",
            "guest-memory delivery event is missing from Diagnostics output")
    require(meson, "addons/diagnostics/controller-xid-trace.c",
            "Full-profile Controller/XID recorder missing from Meson")
    require(meson, "addons/stubs/controller-xid-trace-stub.c",
            "non-Full Controller/XID stub missing from Meson")
    require(stub, "(void)event_type;", "non-Full stub is not a no-op implementation")
    require(stub, "xemu_debug_tools_controller_xid_trace_guest_input_write",
            "non-Full guest-memory delivery hook stub missing")
    require(stub, "xemu_debug_tools_controller_xid_trace_get_status",
            "non-Full Controller Snapshot status surface missing")
    require(stub, "xemu_debug_tools_controller_xid_trace_snapshot",
            "non-Full Controller Snapshot trace surface missing")
    forbid(stub, "qemu_", "non-Full Controller/XID stub gained runtime dependencies")

    # The cumulative NV2A/PGRAPH files remain frozen except for the explicitly
    # guarded observation-only v3.09 FLIP_STALL/VBlank and v3.10 scheduler-wake hook surfaces.
    protected = {
        "hw/xbox/nv2a/nv2a.c": "6f2b7013616345c223beec2442838b7d4073ec236d548f9bd55450c8e017f1bb",
        "hw/xbox/nv2a/pfifo.c": "6de0f77609a7af6e4ecefe0ad4d149b9bea35d9846438a3648df16a0b0559a67",
        "hw/xbox/nv2a/pgraph/gl/renderer.c": "64da8314c8ccc46f1689dc8cbd2debb0e2e2e22ea0283c3eff21378f90b8e176",
        "hw/xbox/nv2a/pgraph/null/renderer.c": "bb99b7be7e589f18d458ea4f0024c2f38f263b75b6441c9742e4670f8ae9ee12",
        "hw/xbox/nv2a/pgraph/pgraph.c": "20c9cc0b94d026212d8da0a8fc580f2fafe8563c851f94e2a3b229ec8bf24767",
        "hw/xbox/nv2a/pgraph/pgraph.h": "56b76d6e9a3acb44edcc847a7be8f31f4dd0c7a710530f6effd3ac613c22d233",
        "hw/xbox/nv2a/pgraph/vk/renderer.c": "afe2c87f34ff1c89158b5b75513111079705d8d8eea66fcc957588dc2b10b6e0",
    }
    for rel, expected in protected.items():
        actual = sha256(root / rel)
        if actual != expected:
            raise AssertionError(
                f"protected Def Jam v3.07 file changed: {rel} ({actual})"
            )

    print("PASS: v3.07 Controller/XID/OHCI persistence + USB delivery diagnostics + protected DJ files (305.2 NV2A observation hook audited)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
