#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.07-derived Controller/XID reconnect diagnostics + persistence guard."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
from optional_patch_contract import optional_patch_enabled


def require(text: str, needle: str, message: str) -> None:
    if needle not in text:
        raise AssertionError(message)


def forbid(text: str, needle: str, message: str) -> None:
    if needle in text:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    diag = debug / "addons/diagnostics"

    hook_rel = "ui/xui/debug-tools/addons/diagnostics/controller-xid-trace-hook.h"
    normal_hook_files = {
        "ui/xemu-input.c",
        "hw/xbox/xid.c",
        "hw/xbox/xid-gamepad.c",
        "hw/usb/hcd-ohci.c",
        "ui/xui/input-manager.cc",
    }

    # Controller/XID/OHCI observation hooks must remain tiny and isolated to
    # exactly these five normal xemu source files.
    seen = set()
    for base in (root / "ui", root / "hw"):
        for path in base.rglob("*"):
            if not path.is_file() or "debug-tools" in path.parts:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if "controller_xid_trace" in text or "controller-xid-trace-hook.h" in text:
                seen.add(path.relative_to(root).as_posix())
    if seen != normal_hook_files:
        raise AssertionError(
            f"Controller/XID normal-source hook isolation changed: {sorted(seen)}"
        )

    input_c = (root / "ui/xemu-input.c").read_text(encoding="utf-8")
    xid_c = (root / "hw/xbox/xid.c").read_text(encoding="utf-8")
    xid_gamepad_c = (root / "hw/xbox/xid-gamepad.c").read_text(encoding="utf-8")
    ohci_c = (root / "hw/usb/hcd-ohci.c").read_text(encoding="utf-8")
    input_manager = (root / "ui/xui/input-manager.cc").read_text(encoding="utf-8")
    core = input_c + xid_c + xid_gamepad_c + ohci_c + input_manager

    require(input_c, "HOST_GAMEPAD_ADDED", "host SDL add observation missing")
    require(input_c, "HOST_GAMEPAD_OPENED", "host SDL open observation missing")
    require(input_c, "HOST_GAMEPAD_REMOVED", "host SDL remove observation missing")
    require(input_c, "HOST_BIND", "host bind observation missing")
    require(input_c, "HOST_UNBIND", "host unbind observation missing")
    require(input_c, "trace_host_state", "independent host state observation missing")
    require(xid_c, "XID_GET_REPORT", "GET_REPORT observation missing")
    require(xid_gamepad_c, "XID_INTERRUPT_IN", "interrupt-IN observation missing")
    require(xid_c, "trace_xid_state", "mapped XID state observation missing")
    require(xid_gamepad_c, "XID_REALIZE", "XID realize observation missing")
    require(xid_c, "XID_UNREALIZE", "XID unrealize observation missing")
    require(xid_c, "XID_RESET", "XID reset observation missing")
    require(xid_c, "USB_CONTROL_REQUEST", "XID USB control-request observation missing")
    require(ohci_c, "OHCI_PORT_ATTACH", "OHCI root-port attach observation missing")
    require(ohci_c, "OHCI_PORT_DETACH", "OHCI root-port detach observation missing")
    require(ohci_c, "OHCI_PORT_RESET", "OHCI root-port reset observation missing")
    require(ohci_c, "OHCI_RHSC", "OHCI root-hub status-change observation missing")
    require(ohci_c, "OHCI_SETUP_TD", "OHCI setup-TD observation missing")
    require(ohci_c, "OHCI_TD_DEVICE_MISSING", "OHCI missing-device TD observation missing")
    require(ohci_c, "OHCI_TD_COMPLETE", "OHCI endpoint-2 IN completion observation missing")
    require(ohci_c, "OHCI_DONE_HEAD", "OHCI done-head observation missing")
    require(ohci_c, "OHCI_WDH_IRQ", "OHCI WDH interrupt observation missing")
    require(ohci_c, "trace_guest_input_write",
            "OHCI endpoint-2 guest-memory write observation missing")
    require(xid_gamepad_c, "trace_xid_packet_complete",
            "XID packet-completion observation missing")

    if optional_patch_enabled(10):
        require(input_c, "HOST_PERSISTENT_NEUTRAL",
                "persistent neutral host transition missing")
        require(input_c, "HOST_PERSISTENT_REATTACHED",
                "persistent host reattach transition missing")
        require(input_c, "guest controller retained",
                "host disconnect no longer documents guest-XID retention")
        forbid(input_c, "xemu_input_bind(iter->bound, NULL, 0);",
               "temporary SDL removal still unplugs the guest controller")
    require(input_manager, "trace_input_mode", "input test-mode trace hook missing")
    require(input_manager, "input_rebinding ||\n        main_scene_active",
            "main xemu Settings/menu scene no longer exclusively owns controller input")
    forbid(input_manager, "main_scene_active && io.NavActive && controller_activity",
           "menu capture still waits one frame for controller activity")
    require(input_manager, "g_scene_mgr.IsDisplayingScene()",
            "input capture is no longer scoped to the main xemu scene")
    require(input_manager, "input_rebinding ||",
            "input rebinding no longer explicitly owns guest-input suppression")

    # The pre-existing assert(state) behavior is deliberate: diagnostics records
    # the missing binding immediately before the same assertion; it does not fix
    # or bypass the failure.
    missing = xid_c.index("XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_BOUND_MISSING")
    assertion = xid_c.index("assert(state);", missing)
    if not (missing < assertion):
        raise AssertionError("XID_BOUND_MISSING must be recorded before assert(state)")
    require(xid_c, "assert(state);", "existing XID bound-state assertion removed")

    # No game-specific policy is allowed in these controller/XID hooks.
    for leaked in ("Def Jam", "45410049", "45410042", "def_jam_ffny"):
        forbid(core, leaked, f"game-specific metadata leaked into Controller/XID hooks: {leaked}")

    hook = (diag / "controller-xid-trace-hook.h").read_text(encoding="utf-8")
    recorder = (diag / "controller-xid-trace.c").read_text(encoding="utf-8")
    backend = (diag / "diagnostics-backend.c").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    stub = (debug / "addons/stubs/controller-xid-trace-stub.c").read_text(encoding="utf-8")

    require(hook, "HOST_INPUT_STATE", "host-state hook contract missing")
    require(hook, "XID_INPUT_STATE", "XID-state hook contract missing")
    require(hook, "XID_BOUND_MISSING", "missing-bound hook contract missing")
    require(hook, "OHCI_PORT_ATTACH", "OHCI hook contract missing")
    require(hook, "USB_CONTROL_REQUEST", "USB enumeration hook contract missing")
    require(hook, "HOST_PERSISTENT_NEUTRAL", "persistent-neutral hook contract missing")
    require(hook, "INPUT_TEST_MODE_ON", "input-test-mode hook contract missing")
    require(hook, "XID_IN_PACKET_COMPLETE", "XID packet-completion hook contract missing")
    require(hook, "OHCI_TD_COMPLETE", "OHCI TD-completion hook contract missing")
    require(hook, "OHCI_WDH_IRQ", "OHCI WDH hook contract missing")
    require(hook, "OHCI_GUEST_INPUT_WRITE",
            "OHCI guest-memory write hook contract missing")
    require(hook, "trace_guest_input_write",
            "OHCI guest-memory write hook function missing")
    require(recorder, "XemuControllerXidPacketSignature",
            "XID report change/heartbeat coalescing missing")
    require(recorder, "XemuControllerXidGuestWriteSignature",
            "guest-memory report change/heartbeat coalescing missing")
    require(recorder, "report[XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX]",
            "full 20-byte XID report retention missing")
    require(recorder, "input_mode_valid", "input test-mode transition coalescing missing")
    require(recorder, "XEMU_CONTROLLER_XID_HEARTBEAT_NS 1000000000ULL",
            "1-second state/poll heartbeat throttle missing")
    require(recorder, "total_observations++", "all-observation counter missing")
    require(recorder, "memcmp(last->axis", "host state-change coalescing missing")
    require(recorder, "memcmp(last->xid_analog", "XID state-change coalescing missing")
    require(backend, "xemu_diagnostics_get_controller_xid_trace_status",
            "Diagnostics backend bridge missing")
    require(ui, "Controller / XID / OHCI USB Reconnect Trace", "Diagnostics UI section missing")
    require(ui, "Check All Recording Options", "NV2A/PTIMER Check All recording checkbox missing")
    require(ui, 'ImGui::Button("Clear All")', "NV2A/PTIMER Clear All diagnostics button missing")
    for clear_call in (
        "xemu_diagnostics_ptimer_trace_clear();",
        "xemu_diagnostics_qemu_timer_trace_clear();",
        "xemu_diagnostics_slow_timer_trace_clear();",
        "xemu_diagnostics_ohci_slow_frame_trace_clear();",
        "xemu_diagnostics_pgraph_increment_trace_clear();",
        "xemu_diagnostics_ptimer_irq_latency_trace_clear();",
        "xemu_diagnostics_controller_input_poll_trace_clear();",
        "xemu_diagnostics_bql_trace_clear();",
        "xemu_diagnostics_mmio_trace_clear();",
        "xemu_diagnostics_pgraph_lock_trace_clear();",
        "xemu_diagnostics_pgraph_draw_trace_clear();",
        "xemu_diagnostics_controller_xid_trace_clear();",
    ):
        require(ui, clear_call, f"Clear All missing recorder reset: {clear_call}")
    require(ui, 'm_sample_count = 0;', "Clear All does not reset diagnostic sample count")
    require(ui, 'm_events.clear();', "Clear All does not reset Recent Events")
    require(ui, 'm_pc_history.clear();', "Clear All does not reset CPU stall history")
    require(ui, "counters count every observation", "throttle/counter UI explanation missing")
    require(ui, "OHCI_GUEST_INPUT_WRITE",
            "guest-memory delivery event is missing from Diagnostics output")
    require(meson, "addons/diagnostics/controller-xid-trace.c",
            "Full-profile Controller/XID recorder missing from Meson")
    require(meson, "addons/stubs/controller-xid-trace-stub.c",
            "non-Full Controller/XID stub missing from Meson")
    require(stub, "(void)event_type;", "non-Full stub is not a no-op implementation")
    require(stub, "xemu_debug_tools_controller_xid_trace_guest_input_write",
            "non-Full guest-memory delivery hook stub missing")
    require(stub, "xemu_debug_tools_controller_xid_trace_get_status",
            "non-Full Controller Snapshot status surface missing")
    require(stub, "xemu_debug_tools_controller_xid_trace_snapshot",
            "non-Full Controller Snapshot trace surface missing")
    forbid(stub, "qemu_", "non-Full Controller/XID stub gained runtime dependencies")

    # The cumulative NV2A/PGRAPH files remain frozen except for the explicitly
    # guarded observation-only v3.09 FLIP_STALL/VBlank and v3.10 scheduler-wake hook surfaces.
    protected = {
        "hw/xbox/nv2a/nv2a.c": "6f2b7013616345c223beec2442838b7d4073ec236d548f9bd55450c8e017f1bb",
        "hw/xbox/nv2a/pfifo.c": "6de0f77609a7af6e4ecefe0ad4d149b9bea35d9846438a3648df16a0b0559a67",
        "hw/xbox/nv2a/pgraph/gl/renderer.c": "64da8314c8ccc46f1689dc8cbd2debb0e2e2e22ea0283c3eff21378f90b8e176",
        "hw/xbox/nv2a/pgraph/null/renderer.c": "bb99b7be7e589f18d458ea4f0024c2f38f263b75b6441c9742e4670f8ae9ee12",
        "hw/xbox/nv2a/pgraph/pgraph.c": "20c9cc0b94d026212d8da0a8fc580f2fafe8563c851f94e2a3b229ec8bf24767",
        "hw/xbox/nv2a/pgraph/pgraph.h": "56b76d6e9a3acb44edcc847a7be8f31f4dd0c7a710530f6effd3ac613c22d233",
        "hw/xbox/nv2a/pgraph/vk/renderer.c": "afe2c87f34ff1c89158b5b75513111079705d8d8eea66fcc957588dc2b10b6e0",
    }
    # These seven frozen behavior hashes include optional Patch 20. Keep all
    # observation-shape checks below even on a Patch-300-only reconstruction;
    # do not compare its different core algorithm against a Patch-20 hash.
    check_patch20_behavior = optional_patch_enabled(20)
    for rel, expected in protected.items():
        path = root / rel
        text = path.read_text(encoding="utf-8")
        normalized = text
        if rel == "hw/xbox/nv2a/pgraph/pgraph.c":
            # v3.14r adds exactly two observation-only A/V/PGRAPH trace lines.
            # Strip only those lines before checking the frozen Def Jam behavior
            # hash so any real PGRAPH fix/locking change still fails this guard.
            include = '#include "ui/xui/debug-tools/addons/diagnostics/av-sync-trace-hook.h"\n'
            hook = '    xemu_debug_tools_av_sync_trace_note_pgraph_flip(pg->frame_time);\n'
            if text.count(include) != 1 or text.count(hook) != 1:
                raise AssertionError(
                    "v3.14r PGRAPH A/V observation hook count/layout changed"
                )
            normalized = normalized.replace(include, "").replace(hook, "")

            # v3.14v adds an observation-only semaphore-progress recorder around
            # the existing NV097 guest-memory write. Normalize only its exact
            # hook surface so Patch 20 remains the behavior owner.
            pusher_include = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace-hook.h"\n'
            pusher_begin = (
                '    XemuDebugToolsPgraphPusherSemaphoreScope pusher_progress_scope;\n'
                '    xemu_debug_tools_pgraph_pusher_progress_semaphore_begin(\n'
                '        &pusher_progress_scope, pg->dma_semaphore, semaphore_offset, parameter);\n'
            )
            pusher_target = (
                '    if (pusher_progress_scope.active) {\n'
                '        const hwaddr semaphore_phys = semaphore_data - d->vram_ptr;\n'
                '        const uint32_t semaphore_guest_va =\n'
                '            semaphore_phys < memory_region_size(d->vram) &&\n'
                '                    semaphore_phys <= 0x7FFFFFFFu\n'
                '                ? 0x80000000u + (uint32_t)semaphore_phys\n'
                '                : 0;\n'
                '        xemu_debug_tools_pgraph_pusher_progress_semaphore_target(\n'
                '            &pusher_progress_scope, (uint32_t)semaphore_phys,\n'
                '            semaphore_guest_va, ldl_le_p((uint32_t*)semaphore_data));\n'
                '    }\n'
                '    xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite(\n'
                '        &pusher_progress_scope,\n'
                '        qatomic_read(&d->pgraph.waiting_for_nop) ? 1 : 0,\n'
                '        qatomic_read(&d->pgraph.waiting_for_flip) ? 1 : 0);\n\n'
            )
            for token, label in ((pusher_include, "include"), (pusher_begin, "begin"),
                                 (pusher_target, "target/prewrite")):
                if text.count(token) != 1:
                    raise AssertionError(
                        f"v3.14v PGRAPH semaphore observation {label} count/layout changed"
                    )
            normalized = normalized.replace(pusher_include, "")
            # Each observation block replaced one stock blank line; restore it
            # before comparing to the frozen behavior hash.
            normalized = normalized.replace(pusher_begin, "")
            normalized = normalized.replace(pusher_target, "")

            # v3.14w adds an identity-only handoff for the PFIFO puller timer; v3.14x
            # also forwards the already-present method parameter so Diagnostics can
            # distinguish SET_BEGIN_END(BEGIN) from SET_BEGIN_END(END).
            # It only maps the already-resolved class/method through the existing
            # Kelvin table; timing remains in pfifo.c. Strip this exact block so
            # all pre-existing PGRAPH behavior stays protected by the frozen hash.
            method_identity = (
                '    /* Diagnostics-only identity handoff for the PFIFO puller timer. The timer\n'
                '     * itself lives at the existing pfifo_run_puller() call boundary so this\n'
                '     * path adds no clock read inside PGRAPH. */\n'
                '    uint32_t pusher_method_base = method;\n'
                '    const char *pusher_method_name = NULL;\n'
                '    if (graphics_class == NV_KELVIN_PRIMITIVE) {\n'
                '        size_t pusher_method_index = METHOD_ADDR_TO_INDEX(method);\n'
                '        if (pusher_method_index < ARRAY_SIZE(pgraph_kelvin_methods) &&\n'
                '            pgraph_kelvin_methods[pusher_method_index].handler != NULL) {\n'
                '            pusher_method_base = pgraph_kelvin_methods[pusher_method_index].base;\n'
                '            pusher_method_name = pgraph_kelvin_methods[pusher_method_index].name;\n'
                '        }\n'
                '    }\n'
                '    xemu_debug_tools_pgraph_pusher_method_breakdown_note_method(\n'
                '        subchannel, graphics_class, method, pusher_method_base, parameter,\n'
                '        pusher_method_name);\n\n'
            )
            if text.count(method_identity) != 1:
                raise AssertionError(
                    "v3.14w PGRAPH method identity observation count/layout changed"
                )
            normalized = normalized.replace(method_identity, "")
        elif rel == "hw/xbox/nv2a/pfifo.c":
            # v3.14s adds only the stable pre-PGRAPH timing marker to both PFIFO
            # puller entry paths. Remove exactly that observation surface before
            # checking the protected behavior hash.
            include = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-flip-delay-trace-hook.h"\n'
            calls = (
                '        xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(\n'
                '            &d->pgraph, 0, parameter);\n',
                '        xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(\n'
                '            &d->pgraph, method, parameter);\n',
            )
            if text.count(include) != 1 or any(text.count(call) != 1 for call in calls):
                raise AssertionError(
                    "v3.14s PFIFO flip-delay observation hook count/layout changed"
                )
            normalized = normalized.replace(include, "")
            for call in calls:
                normalized = normalized.replace(call, "")

            # v3.14v wraps PFIFO pusher work in an observation-only GET/PUT
            # summary. Strip exactly those hooks before checking the frozen
            # behavior hash.
            pusher_include = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace-hook.h"\n'
            pusher_begin = (
                '    XemuDebugToolsPgraphPusherPfifoScope pusher_progress_scope;\n'
                '    uint32_t pusher_progress_method_words = 0;\n'
                '    xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(\n'
                '        &pusher_progress_scope, channel_id, *dma_get, *dma_put);\n\n'
            )
            pusher_words = '            pusher_progress_method_words += (uint32_t)num_words_processed;\n'
            pusher_end = (
                '    xemu_debug_tools_pgraph_pusher_progress_pfifo_end(\n'
                '        &pusher_progress_scope, *dma_get, *dma_put,\n'
                '        pusher_progress_method_words,\n'
                '        qatomic_read(&d->pgraph.waiting_for_nop) ? 1 : 0,\n'
                '        qatomic_read(&d->pgraph.waiting_for_flip) ? 1 : 0,\n'
                '        can_fifo_access(d) ? 1 : 0);\n\n'
            )
            for token, label in ((pusher_include, "include"), (pusher_begin, "begin"),
                                 (pusher_words, "word counter"), (pusher_end, "end")):
                if text.count(token) != 1:
                    raise AssertionError(f"v3.14v PFIFO pusher observation {label} count/layout changed")
            normalized = normalized.replace(pusher_include, "")
            normalized = normalized.replace(pusher_begin, "\n")
            normalized = normalized.replace(pusher_words, "")
            normalized = normalized.replace(pusher_end, "")

            # v3.14w times only the already-existing pfifo_run_puller() call.
            # Normalize exactly the begin/end timing scope; the puller call, its
            # arguments, error handling, DMA accounting, and control flow remain
            # in the protected text and therefore stay covered by the frozen
            # Def Jam behavior hash.
            method_breakdown_begin = (
                '            XemuDebugToolsPgraphPusherPullerScope method_breakdown_scope;\n'
                '            xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin(\n'
                '                &method_breakdown_scope);\n'
            )
            method_breakdown_end = (
                '            xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end(\n'
                '                &method_breakdown_scope,\n'
                '                num_words_processed > 0 ? (uint32_t)num_words_processed : 0);\n'
            )
            for token, label in ((method_breakdown_begin, "puller begin"),
                                 (method_breakdown_end, "puller end")):
                if text.count(token) != 1:
                    raise AssertionError(
                        f"v3.14w PFIFO method-time observation {label} count/layout changed"
                    )
            normalized = normalized.replace(method_breakdown_begin, "")
            normalized = normalized.replace(method_breakdown_end, "")
        elif rel in (
            "hw/xbox/nv2a/pgraph/gl/renderer.c",
            "hw/xbox/nv2a/pgraph/null/renderer.c",
            "hw/xbox/nv2a/pgraph/vk/renderer.c",
        ):
            # v3.14s wraps process_pending() with a begin/cancel observation pair.
            # Patch 20 still owns the actual CPU-MMIO drain between PFIFO unlock
            # and PGRAPH_LOCK; only these Patch-300 marker lines are normalized.
            include = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-flip-delay-trace-hook.h"\n'
            kind = {
                "hw/xbox/nv2a/pgraph/gl/renderer.c": "XEMU_PGRAPH_FLIP_DELAY_RENDERER_GL",
                "hw/xbox/nv2a/pgraph/null/renderer.c": "XEMU_PGRAPH_FLIP_DELAY_RENDERER_NULL",
                "hw/xbox/nv2a/pgraph/vk/renderer.c": "XEMU_PGRAPH_FLIP_DELAY_RENDERER_VK",
            }[rel]
            begin = (
                '    xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(\n'
                f'        &d->pgraph, {kind});\n\n'
            )
            cancel = '    xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel();\n'
            if text.count(include) != 1 or text.count(begin) != 1 or text.count(cancel) != 1:
                raise AssertionError(
                    f"v3.14s renderer flip-delay hook count/layout changed: {rel}"
                )
            normalized = normalized.replace(include, "").replace(begin, "").replace(cancel, "")
        actual = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        if check_patch20_behavior and actual != expected:
            raise AssertionError(
                f"protected Def Jam v3.07 file changed: {rel} ({actual})"
            )

    print("PASS: Controller/XID/OHCI observations + explicitly requested Patch 10/20 behavior guards")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
