#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")

vp = (ROOT / "hw/xbox/mcpx/apu/vp/vp.c").read_text(encoding="utf-8")
header = (DIAG / "d3d-timer-state-trace.h").read_text(encoding="utf-8")
source = (DIAG / "d3d-timer-state-trace.c").read_text(encoding="utf-8")
guest = (DIAG / "guest-timer-deadline-trace.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")

m = re.search(r"static void voice_lock\(MCPXAPUState \*d, uint16_t v, bool lock\)\n\{(.*?)\n\}", vp, re.S)
if not m:
    raise AssertionError("voice_lock body not found")
voice_lock = m.group(1)
require(voice_lock, "qatomic_or(&d->vp.voice_locked[v / 64], mask);", "atomic voice lock set")
require(voice_lock, "qatomic_and(&d->vp.voice_locked[v / 64], ~mask);", "atomic voice lock clear")
require(voice_lock, "qemu_cond_signal(&d->cond);", "APU wake")
forbid(voice_lock, "qemu_mutex_lock(&d->lock)", "vCPU wait on APU frame mutex")
forbid(voice_lock, "bql_unlock()", "BQL drop workaround in voice_lock")
forbid(voice_lock, "bql_lock()", "BQL reacquire workaround in voice_lock")
require(vp, "qatomic_set(&d->vp.voice_locked[i], 0);", "atomic voice lock reset")

require(header, "XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS 64", "256-byte timer record window")
require(header, "XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_MAX_PROBES_PER_CYCLE 48", "bounded probe budget")
require(header, "changed_from_schedule_mask", "same-cycle delta mask")
require(header, "changed_from_last_good_mask", "last-good delta mask")
for pc in ("0x00223FE9u", "0x00223314u", "0x00223352u", "0x0022336Du", "0x002239A0u", "0x00223760u", "0x002237F7u", "0x00223801u"):
    require(source, pc, f"focused dispatcher probe {pc}")
require(source, "cpu_memory_rw_debug(cpu, timer_object, bytes, sizeof(bytes), false)", "single contiguous timer-object read")
require(source, "d3d_timer_state_changed_mask", "snapshot delta comparison")
require(source, "last_good_dwords", "last-good snapshot retention")
require(source, "current_probe_count", "per-cycle probe budget")

require(guest, "xemu_debug_tools_d3d_timer_state_trace_should_probe(guest_pc)", "exact-probe gate")
require(guest, "xemu_debug_tools_d3d_timer_state_trace_note(", "timer-state capture bridge")
require(guest, "XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_CALL", "dynamic timer object arm")
require(guest, "timer_state_object = event.ecx;", "dynamic timer object from D3D call")
require(guest, "!xemu_debug_tools_ptimer_irq_delivery_trace_active()", "full 305.1 page suppression remains")
require(backend_h, "XemuDiagnosticsD3dTimerStateEvent", "backend event type")
require(backend_c, "xemu_debug_tools_d3d_timer_state_trace_snapshot", "backend snapshot bridge")
require(meson, "addons/diagnostics/d3d-timer-state-trace.c", "timer-state build source")
require(ui, "D3D Timer Record / List State Trace (Patch 305.3)", "snapshot section")
require(ui, "if (m_export_guest_timer_deadline_trace) {", "305.3 export gate uses declared trace field")
forbid(ui, "if (m_export_guest_timer_deadline) {", "stale undeclared 305.3 export gate field")

cc_members = set(re.findall(r"\bm_[A-Za-z0-9_]+\b", ui))
hh_text = (DIAG / "diagnostics.hh").read_text(encoding="utf-8")
hh_members = set(re.findall(r"\bm_[A-Za-z0-9_]+\b", hh_text))
missing_members = sorted(cc_members - hh_members)
if missing_members:
    raise AssertionError(f"diagnostics.cc member(s) missing from diagnostics.hh: {missing_members}")
require(ui, "changed_from_schedule", "snapshot schedule delta output")
require(ui, "changed_from_last_good", "snapshot last-good delta output")

forbid(source, "cpu_memory_rw_debug(cpu, timer_object +", "per-dword debug reads")
forbid(source, "cpu_interrupt(", "interrupt injection")
forbid(source, "timer_mod(", "timer modification")
forbid(source, "vm_stop", "guest pause")

print("PASS: Patch 305.3 APU nonblocking VOICE_LOCK + focused D3D timer-state trace")
