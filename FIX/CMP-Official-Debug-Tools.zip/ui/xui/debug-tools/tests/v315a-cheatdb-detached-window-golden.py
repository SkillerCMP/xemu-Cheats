#!/usr/bin/env python3
"""v3.15a CheatDB detached-window integration guard."""
from __future__ import annotations
import argparse
from pathlib import Path


def need(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def section(text: str, start: str, end: str) -> str:
    a = text.index(start)
    b = text.index(end, a + len(start))
    return text[a:b]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    dt = root / "ui/xui/debug-tools"
    cc = (dt / "addons/cheat-db/cheat-db.cc").read_text(encoding="utf-8")
    hh = (dt / "addons/cheat-db/cheat-db.hh").read_text(encoding="utf-8")
    cheat_ui = (dt / "cheat-engine-ui.cc").read_text(encoding="utf-8")
    library = (dt / "addons/game-library/game-library.cc").read_text(encoding="utf-8")
    readme = (dt / "addons/cheat-db/README.md").read_text(encoding="utf-8")

    need(cc, '#include "../../detached-tools.hh"', "detached host API")
    need(hh, "void DrawDetached();", "detached draw API")
    need(cc, '"xemu - Cheat Database"', "standalone OS-window title")
    need(cc, "detached_tools_register({", "detached registration")
    need(cc, "&is_open,", "detached open state")
    need(cc, "DrawCheatDbDetached,", "detached draw callback")
    need(cc, "detached_tools_open_or_focus(&is_open);", "open/focus handoff")

    tick = section(cc, "void CheatDbManager::Tick()", "void CheatDbManager::DrawDetached()")
    forbid(tick, "ImGui::", "CheatDB drawing in synchronized/main HUD tick")
    need(tick, "ReloadCurrentCheatFile();", "post-merge synchronized reload")

    draw = cc[cc.index("void CheatDbManager::DrawDetached()") :]
    need(draw, 'ImGui::Begin("##DetachedCheatDatabase", nullptr, window_flags)',
         "detached fullscreen root")
    need(draw, "ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);",
         "detached root origin")
    need(draw, "ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Always);",
         "detached root fills OS window")
    for flag in ("ImGuiWindowFlags_NoTitleBar", "ImGuiWindowFlags_NoResize",
                 "ImGuiWindowFlags_NoMove", "ImGuiWindowFlags_NoSavedSettings"):
        need(draw, flag, f"detached root flag {flag}")
    forbid(draw, 'ImGui::Begin("XEMU x CMP Cheat Database"',
           "old embedded CheatDB window")

    # Both launch surfaces continue to use the single shared manager, so they
    # cannot accidentally spawn a second embedded implementation.
    need(cheat_ui, "cheat_db_manager.OpenForCurrentGame();", "Cheat Engine current-game handoff")
    need(cheat_ui, "cheat_db_manager.OpenGlobal();", "Cheat Engine global handoff")
    need(library, "cheat_db_manager.OpenForGame(cheat_game);", "Game Library handoff")
    forbid(cheat_ui, "DetachedCheatDatabase", "duplicate detached UI in Cheat Engine")
    forbid(library, "DetachedCheatDatabase", "duplicate detached UI in Game Library")

    need(readme, "same standalone `xemu - Cheat Database` OS window",
         "detached behavior documentation")
    need(readme, "unlocked detached-frame", "unlocked UI phase documentation")

    print("PASS: v3.15a CheatDB is hosted only in the shared detached Debug Tools window")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
