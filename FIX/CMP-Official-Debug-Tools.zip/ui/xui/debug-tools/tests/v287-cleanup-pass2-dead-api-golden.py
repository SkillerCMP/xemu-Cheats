#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 2 dead-API/state pruning guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    mem = root / "ui/xui/debug-tools/addons/memory-tools"
    diag = root / "ui/xui/debug-tools/addons/diagnostics"

    header = (mem / "memory-tools.hh").read_text(encoding="utf-8")
    search = (mem / "memory-tools-search.cc").read_text(encoding="utf-8")
    dump = (mem / "memory-tools-dump.cc").read_text(encoding="utf-8")
    trace = (mem / "execution-trace.cc").read_text(encoding="utf-8")
    diag_h = (diag / "diagnostics.hh").read_text(encoding="utf-8")
    diag_cc = (diag / "diagnostics.cc").read_text(encoding="utf-8")

    dead_api = (
        "ReadRaw(",
        "size_t ValueSize(ValueKind kind) const;",
        "MemoryToolsWindow::ValueSize(ValueKind kind)",
        "bool MatchTarget(uint32_t raw, uint32_t target, NextScanMode mode) const;",
        "MemoryToolsWindow::MatchTarget(uint32_t raw, uint32_t target",
        "bool MatchPrevious(uint32_t current, uint32_t previous, NextScanMode mode) const;",
        "MemoryToolsWindow::MatchPrevious(uint32_t current, uint32_t previous",
        "ScanMappedVirtualRam(",
        "WriteVirtualMapIndex(",
    )
    combined = header + search + dump
    for token in dead_api:
        forbid(combined, token, "Cleanup Pass 2 dead Memory Tools API")

    for token in (
        "ValueSizeForKind(",
        "MatchTargetForKind(",
        "MatchPreviousForKind(",
        "WriteDumpVirtualMapIndex(",
        "CaptureSnapshotInto(",
    ):
        require(combined, token, "retained Memory Tools implementation")

    for token in (
        "uint32_t m_trace_range_start =",
        "uint32_t m_trace_range_end =",
        "m_trace_range_start = range_start;",
        "m_trace_range_end = range_end;",
    ):
        forbid(header + trace, token, "redundant execution-trace range state")
    for token in ("m_trace_capture_range_start", "m_trace_capture_range_end"):
        require(header + trace, token, "authoritative execution-trace capture range")

    forbid(diag_h + diag_cc, "m_device_valid", "never-read Diagnostics device-valid state")
    require(diag_cc, "xemu_diagnostics_get_device_snapshot(&m_device);",
            "Diagnostics device snapshot call")

    print("PASS: Cleanup Pass 2 dead API/state pruning invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
