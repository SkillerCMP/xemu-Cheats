#!/usr/bin/env python3
"""Current ownership guard for the post-v3.10 cleanup."""
from __future__ import annotations
import argparse
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument("--root", default=".")
root = Path(parser.parse_args().root).resolve()
debug = root / "ui/xui/debug-tools"
tools = debug / "tools"
codetypes = debug / "Codetypes"

helpers = (
    "build-capstone-windows.sh",
    "build-capstone.sh",
    "build-keystone.sh",
    "build-xemu.sh",
    "docker-build-windows.sh",
    "prepare-build-dependencies.sh",
    "read-build-profile.py",
    "restore-executable-bits.py",
    "validate-project-layout.py",
)
for name in helpers:
    if (debug / name).exists():
        raise AssertionError(f"build/maintenance helper returned to Debug Tools root: {name}")
    if not (tools / name).is_file():
        raise AssertionError(f"missing tools-owned helper: {name}")

# v3.13 deliberately retires the standalone BAT launchers and old manuals.
for name in ("Build-Xemu-DOCKER.bat", "Build-Xemu-MINGW64.bat"):
    if list(debug.rglob(name)):
        raise AssertionError(f"retired standalone builder returned: {name}")
if (debug / "docs").exists():
    raise AssertionError("retired Debug Tools docs folder returned")
for name in ("CHANGELOG.md", "XEMU_RAW_CHEAT_ENGINE.md"):
    if (debug / name).exists():
        raise AssertionError(f"retired root manual returned: {name}")
if not (codetypes / "XEMU-Code-Types-Guide.pdf").is_file():
    raise AssertionError("missing user code-types PDF")
landing = debug / "README.md"
if not landing.is_file():
    raise AssertionError("missing compact Debug Tools root README")
if len(landing.read_text(encoding="utf-8").splitlines()) > 80:
    raise AssertionError("Debug Tools root README became long-form documentation again")

build_sh = (root / "build.sh").read_text(encoding="utf-8")
needle = "ui/xui/debug-tools/tools/build-xemu.sh"
if build_sh.count(needle) != 2:
    raise AssertionError("root build.sh must contain only the tools/build-xemu.sh existence+exec hook")
if "ui/xui/debug-tools/build-xemu.sh" in build_sh.replace(needle, ""):
    raise AssertionError("obsolete root-level Debug Tools build helper path returned")

meson = (debug / "meson.build").read_text(encoding="utf-8")
if "join_paths(meson.current_source_dir(), 'tools', 'read-build-profile.py')" not in meson:
    raise AssertionError("Meson profile reader is not tools-owned")


# Diagnostics-owned inline helper implementations stay out of upstream files.
timer_h = (root / "include/qemu/timer.h").read_text(encoding="utf-8")
timer_source_hook = (debug / "addons/diagnostics/qemu-timer-source-hook.h").read_text(encoding="utf-8")
if 'qemu-timer-source-hook.h' not in timer_h:
    raise AssertionError("qemu/timer.h is missing the Diagnostics-owned source hook include")
for symbol in ("xemu_timer_debug_set_callback_source", "xemu_timer_new_ms_debug"):
    if re.search(r"static\s+inline[^;{]*\b" + re.escape(symbol) + r"\s*\(", timer_h, re.S):
        raise AssertionError(f"timer source helper implementation leaked back upstream: {symbol}")
    if symbol not in timer_source_hook:
        raise AssertionError(f"missing timer source helper in Diagnostics hook: {symbol}")

ohci_c = (root / "hw/usb/hcd-ohci.c").read_text(encoding="utf-8")
ohci_api_hook = (debug / "addons/diagnostics/ohci-slow-frame-trace-hook.h").read_text(encoding="utf-8")
ohci_profile_hook = (debug / "addons/diagnostics/ohci-slow-frame-profile-hook.h").read_text(encoding="utf-8")
if 'qemu/timer.h' in ohci_api_hook:
    raise AssertionError("public OHCI trace API header must not pull qemu/timer.h into UI translation units")
if 'ohci-slow-frame-profile-hook.h' not in ohci_c:
    raise AssertionError("upstream OHCI hook must include the Diagnostics-owned profile helper header")
for symbol in ("ohci_profile_now_ns", "ohci_profile_add_leaf", "ohci_profile_finish"):
    if re.search(r"static\s+inline[^;{]*\b" + re.escape(symbol) + r"\s*\(", ohci_c, re.S):
        raise AssertionError(f"OHCI profiling helper implementation leaked back upstream: {symbol}")
    if f"{symbol}(" in ohci_api_hook:
        raise AssertionError(f"OHCI-only profiling helper leaked into public trace API header: {symbol}")
    if f"{symbol}(" not in ohci_profile_hook:
        raise AssertionError(f"missing OHCI profiling helper in Diagnostics profile hook: {symbol}")

print("v3.11 cleanup ownership: PASS")
