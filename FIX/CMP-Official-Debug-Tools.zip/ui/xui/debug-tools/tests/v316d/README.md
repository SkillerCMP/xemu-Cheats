# v3.16d Delete Code regression

`run-delete.py` compiles the production parser/executor/F-hook/deletion and host
source-file transaction with test-only guest/assembler seams. The file write is
real GLib `G_FILE_SET_CONTENTS_CONSISTENT | G_FILE_SET_CONTENTS_DURABLE` IO.
It verifies confirmation-independent engine semantics, failure preservation,
external-edit rejection, hook retirement, and that successful/failed deletes
create no persistent `.delete-*.bak` files.
