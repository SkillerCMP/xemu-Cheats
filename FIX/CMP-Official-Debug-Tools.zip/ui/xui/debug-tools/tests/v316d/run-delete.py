#!/usr/bin/env python3
"""Build the actual Delete Code transaction against test-only guest/assembler seams.
Uses real GLib durable/consistent file replacement. Not a full XEMU/UI build.
"""
from pathlib import Path
import argparse, shutil, subprocess, tempfile, sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true');p.add_argument('--bug-file',type=Path)
a=p.parse_args()
dt=Path(__file__).resolve().parents[2];sys.path.insert(0,str(dt/'tests'))
from v287_source_test_utils import extract_function

def run(cmd):
    print('+',' '.join(map(str,cmd)),flush=True);subprocess.run(list(map(str,cmd)),check=True)
with tempfile.TemporaryDirectory(prefix='xemu-v316d-delete-') as temp:
    root=Path(temp);d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
    (d.parent/'common.hh').write_text('#pragma once\n#include <cstddef>\n#include <cstdint>\n#include <string>\nbool SDL_OpenURL(const char*);const char* SDL_GetError();\n')
    for name in ('font-manager.hh','misc.hh'):(d.parent/name).write_text('#pragma once\n')
    flags=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-ffunction-sections','-fdata-sections']
    if a.sanitizers:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    flags+=['-I'+str(d/'tests/v316b/stubs'),'-I'+str(d)]
    persistence=(d/'cheat-engine-persistence.cc').read_text()
    hash_src='#include "cheat-engine.hh"\n#include <algorithm>\n#include <cctype>\n#include <cstdio>\n#include <glib.h>\n'+extract_function(persistence,'std::string Sha256Text(')+'\n'+extract_function(persistence,'std::string CheatEngineWindow::PersistentContentHash(')
    (root/'hash.cc').write_text(hash_src)
    impl=[d/n for n in ('cheat-engine-source.cc','cheat-engine-execute.cc','cheat-engine-fhooks.cc','cheat-engine.cc','cheat-engine-delete.cc','cheat-source-file.cc')]
    exe=root/'delete-engine'
    run(flags+[d/'tests/v316b/engine-golden.cc',d/'tests/v316b/engine-shims.cc',*impl,root/'hash.cc','-Wl,--gc-sections','-Wl,--wrap=g_file_set_contents_full','-l:libglib-2.0.so.0','-o',exe])
    run([exe,a.bug_file.resolve() if a.bug_file else '-',root/'cheats'])
    print('PASS v3.16d Delete Code no-backup transaction test')
