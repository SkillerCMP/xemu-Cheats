#!/usr/bin/env python3
"""v3.14e executable/section identity and legacy compatibility guard."""
import argparse
import hashlib
import pathlib
import struct


def require(text: str, needle: str, what: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {what}: {needle}")


def executable_identity(title_id, base, image_size, entry, tls, kernel_thunk,
                        nonkernel_import, sections):
    b = bytearray(b"XEMU-XBE-CODE-IDENTITY-V1")
    for value in (title_id, base, image_size, entry, tls, kernel_thunk,
                  nonkernel_import, len(sections)):
        b += struct.pack("<I", value)
    for flags, va, vsize, raw_size, digest in sections:
        for value in (flags, va, vsize, raw_size):
            b += struct.pack("<I", value)
        if len(digest) != 20:
            raise AssertionError("synthetic section SHA-1 must be 20 bytes")
        b += digest
    return hashlib.sha256(b).hexdigest().upper()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    current = (debug / "current-game.cc").read_text(encoding="utf-8")
    header = (debug / "current-game.hh").read_text(encoding="utf-8")
    ui = (debug / "current-game-ui.cc").read_text(encoding="utf-8")
    cheat = (debug / "cheat-engine-source.cc").read_text(encoding="utf-8")
    persist = (debug / "cheat-engine-persistence.cc").read_text(encoding="utf-8")
    labels = (debug / "label-packs.cc").read_text(encoding="utf-8")

    for needle, what in (
        ("XEMU-XBE-CODE-IDENTITY-V1", "identity domain/version marker"),
        ("sha256_executable_identity", "executable identity helper"),
        ("append_identity_u32(identity, xbe->cert->m_titleid)", "Title ID scope"),
        ("append_identity_u32(identity, h.m_base)", "XBE base"),
        ("append_identity_u32(identity, h.m_sizeof_image)", "image size"),
        ("append_identity_u32(identity, h.m_entry)", "entry point"),
        ("append_identity_u32(identity, h.m_tls_addr)", "TLS layout"),
        ("append_identity_u32(identity, h.m_kernel_image_thunk_addr)", "kernel thunk layout"),
        ("append_identity_u32(identity, h.m_nonkernel_import_dir_addr)", "nonkernel import layout"),
        ("append_identity_u32(identity, read_le32(sh + 0))", "section flags"),
        ("append_identity_u32(identity, read_le32(sh + 4))", "section virtual address"),
        ("append_identity_u32(identity, read_le32(sh + 8))", "section virtual size"),
        ("append_identity_u32(identity, read_le32(sh + 16))", "section raw size"),
        ("sh + kXbeSectionDigestOffset + 20", "section SHA-1 digest"),
        ("next.legacy_header_sha256 = sha256_legacy_identity_headers(xbe);", "legacy normalized identity"),
        ("next.header_sha256 = sha256_executable_identity(xbe);", "canonical executable identity"),
    ):
        require(current, needle, what)

    # Metadata that caused the WWE split must not be consumed by the new helper.
    start = current.index("static std::string sha256_executable_identity")
    end = current.index("static std::string hex_bytes", start)
    helper = current[start:end]
    for forbidden in ("m_title_name", "m_allowed_media", "m_game_region",
                      "m_digsig", "m_timedate", "m_logo_bitmap_addr"):
        if forbidden in helper:
            raise AssertionError(f"mutable metadata leaked into executable identity: {forbidden}")

    require(header, "std::string legacy_header_sha256;", "legacy normalized storage")
    require(ui, "runtime layout + section SHA-1 digests", "identity UI explanation")
    require(ui, "Title/Region/Allowed Media/signature/logo/debug/certificate metadata do not affect it.",
            "excluded metadata UI explanation")
    require(cheat, "legacy_header_hash_matches(header)", "legacy cheat compatibility")
    require(persist, "LegacyNormalizedPersistencePath()", "legacy persistence filename compatibility")
    require(labels, "legacy_header_match", "legacy label-pack compatibility")

    # Synthetic proof: packaging/certificate metadata is not an input at all;
    # executable content or virtual layout changes remain identity-visible.
    sections = [
        (0x00000005, 0x00011000, 0x2500, 0x2400, bytes(range(20))),
        (0x00000003, 0x00014000, 0x1800, 0x1600, bytes(range(20, 40))),
    ]
    base_args = (0x54510024, 0x00010000, 0x00BB3AA0, 0x000705B2,
                 0x004D4F14, 0x004D4720, 0, sections)
    identity = executable_identity(*base_args)

    # These represent Title Name / Region / Allowed Media / RSA-signature/logo
    # edits. They intentionally have nowhere to enter the function.
    packaging_variant = executable_identity(*base_args)
    if identity != packaging_variant:
        raise AssertionError("packaging-only changes split executable identity")

    digest_changed = list(sections)
    changed_digest = bytearray(digest_changed[0][4])
    changed_digest[3] ^= 0x80
    digest_changed[0] = (*digest_changed[0][:4], bytes(changed_digest))
    if identity == executable_identity(*base_args[:-1], digest_changed):
        raise AssertionError("section content digest change did not change identity")

    layout_changed = list(sections)
    first = layout_changed[0]
    layout_changed[0] = (first[0], first[1] + 0x1000, first[2], first[3], first[4])
    if identity == executable_identity(*base_args[:-1], layout_changed):
        raise AssertionError("section virtual address change did not change identity")

    title_changed = list(base_args)
    title_changed[0] ^= 1
    if identity == executable_identity(*title_changed):
        raise AssertionError("Title ID must scope executable identity")

    print("PASS: v3.14e executable identity is code/layout based with legacy compatibility")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
