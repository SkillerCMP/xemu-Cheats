#!/usr/bin/env python3
"""v3.16d: confirmed Delete Code must not create persistent .bak clutter."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);a=p.parse_args()
d=a.root/'ui/xui/debug-tools'
source=(d/'cheat-source-file.cc').read_text(); header=(d/'cheat-source-file.hh').read_text(); delete=(d/'cheat-engine-delete.cc').read_text(); ui=(d/'cheat-engine-ui.cc').read_text()
def need(text,needle,label):
    if needle not in text: raise SystemExit(f'MISSING {label}: {needle}')
def forbid(text,needle,label):
    if needle in text: raise SystemExit(f'FORBIDDEN {label}: {needle}')
need(source,'G_FILE_SET_CONTENTS_CONSISTENT','GLib consistent temp+rename write')
need(source,'G_FILE_SET_CONTENTS_DURABLE','durable write')
need(source,'ReadUnchanged(path, expected, error)','compare-before-replace')
need(delete,'XemuCheatSource::Replace(path, m_source, next_source, error)','no-backup transaction call')
need(ui,'No backup file is created.','explicit confirmation wording')
for text,label in [(source,'source transaction'),(delete,'delete model'),(ui,'delete UI')]:
    forbid(text,'.delete-',label)
    forbid(text,'Backup:',label)
forbid(source,'g_uuid_string_random','backup UUID creation')
forbid(header,'std::string &backup','backup API parameter')
print('PASS v3.16d Delete Code has confirmation + durable atomic replacement and no persistent backup artifact')
