#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace {
constexpr std::size_t kSector = 512;

struct EffectiveModel {
    std::map<std::uint64_t, std::array<std::uint8_t, kSector>> overlay;
    std::vector<std::uint8_t> base;
    bool fail_base = false;
    std::size_t base_calls = 0;
    std::size_t base_bytes = 0;

    bool Read(std::uint64_t offset, std::uint8_t *out, std::size_t bytes) {
        assert(offset % kSector == 0 && bytes % kSector == 0);
        const std::size_t sectors = bytes / kSector;
        std::vector<bool> covered(sectors, false);
        for (std::size_t i = 0; i < sectors; ++i) {
            auto it = overlay.find(offset / kSector + i);
            if (it != overlay.end()) {
                std::memcpy(out + i * kSector, it->second.data(), kSector);
                covered[i] = true;
            }
        }
        for (std::size_t i = 0; i < sectors;) {
            if (covered[i]) { ++i; continue; }
            const std::size_t first = i;
            while (i < sectors && !covered[i]) ++i;
            const std::size_t n = (i - first) * kSector;
            ++base_calls;
            base_bytes += n;
            if (fail_base) return false;
            std::memcpy(out + first * kSector,
                        base.data() + offset + first * kSector, n);
        }
        return true;
    }
};

struct HostEntry { bool dir; std::uint64_t size; std::int64_t mtime; };
using Manifest = std::map<std::string, HostEntry>;

bool SameHostEntry(const HostEntry &a, const HostEntry &b) {
    if (a.dir != b.dir) return false;
    return a.dir || (a.size == b.size && a.mtime == b.mtime);
}

bool AdditionsOnly(const Manifest &base, const Manifest &cur) {
    for (const auto &[path, entry] : base) {
        auto it = cur.find(path);
        if (it == cur.end() || !SameHostEntry(entry, it->second)) return false;
    }
    return true;
}

std::array<std::uint8_t, kSector> Fill(std::uint8_t value) {
    std::array<std::uint8_t, kSector> a{};
    a.fill(value);
    return a;
}
}

int main() {
    {
        EffectiveModel m;
        m.base.resize(4 * kSector, 0x11);
        m.fail_base = true;
        m.overlay[0] = Fill(0xA0);
        m.overlay[1] = Fill(0xA1);
        std::vector<std::uint8_t> out(2 * kSector);
        assert(m.Read(0, out.data(), out.size()));
        assert(m.base_calls == 0);
        assert(out[0] == 0xA0 && out[kSector] == 0xA1);
    }
    {
        EffectiveModel m;
        m.base.resize(5 * kSector);
        for (std::size_t i = 0; i < 5; ++i)
            std::memset(m.base.data() + i * kSector, int(0x10 + i), kSector);
        m.overlay[1] = Fill(0xE1);
        m.overlay[3] = Fill(0xE3);
        std::vector<std::uint8_t> out(5 * kSector);
        assert(m.Read(0, out.data(), out.size()));
        assert(m.base_calls == 3); // gaps: [0], [2], [4]
        assert(m.base_bytes == 3 * kSector);
        assert(out[0] == 0x10);
        assert(out[kSector] == 0xE1);
        assert(out[2*kSector] == 0x12);
        assert(out[3*kSector] == 0xE3);
        assert(out[4*kSector] == 0x14);
    }
    {
        Manifest base{{"E", {true,0,10}}, {"E/A.bin", {false,4,100}}};
        Manifest added = base;
        added["E/New.bin"] = {false,8,200};
        added["E"].mtime = 999; // child addition may update directory mtime
        assert(AdditionsOnly(base, added));

        Manifest modified = base;
        modified["E/A.bin"].mtime++;
        assert(!AdditionsOnly(base, modified));

        Manifest removed = base;
        removed.erase("E/A.bin");
        assert(!AdditionsOnly(base, removed));
    }
    std::cout << "PASS: v3.14c Folder-HDD behavior model\n";
    return 0;
}
