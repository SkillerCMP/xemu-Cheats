"""Execute the entire actual BuildSnapshotText; dependencies return empty test data.
This checks selection/gating and formatting, not live emulator collection."""
from pathlib import Path
import re, subprocess, tempfile
from v314aa_ui_test_stubs import prepare
from v314y_vulkan_observer_test_utils import function

def test_report(root, compiler):
    S=Path(root)
    with tempfile.TemporaryDirectory(prefix='xemu-view-report-') as td:
        P=Path(td);prepare(S,P)
        headers=['ui/xui/debug-tools/addons/diagnostics/diagnostics-backend.h','ui/xui/debug-tools/cheat-engine-memory.h','ui/xui/debug-tools/addons/diagnostics/av-sync-trace.h','ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace.h','ui/xui/debug-tools/debug-tools.hh']
        defs=[];names=set()
        for h in headers:
            text=(S/h).read_text();text=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
            for m in re.finditer(r'^([A-Za-z_][\w\s*]*?)\s+((?:xemu_diagnostics_|xemu_cheat_|xemu_debug_tools_|debug_tools_background_worker_|debug_tools_external_)\w+)\s*\(([^;{}]*)\)\s*;',text,re.M):
                ret,name,args=m.groups();ret=' '.join(ret.split())
                if name in names or 'typedef' in ret:continue
                names.add(name);defs.append(f'{ret} {name}({args}) {{ api_calls++; '+('return;' if ret=='void' else 'return {};')+' }')
        cpp='''#include <bits/stdc++.h>
        #define private public
        #include "ui/xui/debug-tools/addons/diagnostics/diagnostics.hh"
        #include "ui/xui/debug-tools/current-game.hh"
        #undef private
        #include "ui/xui/debug-tools/addons/diagnostics/diagnostics.cc"
        static unsigned api_calls;
        '''+ '\n'.join(defs)+'''\nCurrentGameManager current_game_manager;
        '''+function((S/'ui/xui/debug-tools/current-game.cc').read_text(),'std::string CurrentGameManager::FormatTitleId(uint32_t title_id)')+r'''
        int main() {
         using namespace XemuDiagnosticsView;
         DiagnosticsWindow w;
         current_game_manager.m_info.valid=true;
         current_game_manager.m_info.title_name="Fixture game";
         current_game_manager.m_info.title_id=0x45410049;
         w.m_regs_valid=true;w.m_stack_valid=true;w.m_disasm_count=1;
         w.m_device.nv2a_available=1;w.m_device.apu_available=1;
         w.m_view.SetAll(false);
         auto text=w.BuildSnapshotText();
         assert(api_calls==0);
         assert(text.find("Game: Fixture game")!=std::string::npos);
         const std::pair<Section,const char *> probes[] = {
         {Section::CurrentGame,"Guest-PC label database:"},
         {Section::Overview,"Accelerator:"},
         {Section::Background,"Debug Tools Background Work\n"},
         {Section::Registers,"EAX "},
         {Section::Instructions,"Disassembly from EIP:"},
         {Section::Stack,"Stack at ESP:"},
         {Section::Clocks,"Installed Xbox RAM bytes:"},
         {Section::InterruptState,"PMC pending/enabled:"},
         {Section::Ptimer,"PTIMER now/alarm:"},
         {Section::PtimerTrace,"PTIMER Detailed Timing Trace\n"},
         {Section::SlowTimer,"Slow QEMU Timer Callback Trace\n"},
         {Section::Ohci,"OHCI Slow Frame Stage Trace\n"},
         {Section::Increment,"PGRAPH Increment Stage Trace\n"},
         {Section::FlipStall,"FLIP_STALL / VBlank Trace\n"},
         {Section::FlipDelay,"PGRAPH Flip Delay Breakdown\n"},
         {Section::PusherProgress,"D3D Pusher / GPU Progress Correlation\n"},
         {Section::MethodBreakdown,"PFIFO Method-Time Breakdown\n"},
         {Section::Scheduler,"Xbox Scheduler / Thread Wake Trace\n"},
         {Section::IrqLatency,"PTIMER IRQ Service Latency Trace\n"},
         {Section::IrqDelivery,"PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)\n"},
         {Section::HostStall,"Windows Host Stall / Page-Fault Correlation (Patch 305.4)\n"},
         {Section::InputPoll,"Controller Input Poll Stage Trace\n"},
         {Section::QemuTimer,"QEMU Timer Dispatch Trace\n"},
         {Section::Bql,"BQL Ownership Trace\n"},
         {Section::MainLoop,"QEMU Main Loop Lock Ownership Trace\n"},
         {Section::Mmio,"MMIO Dispatch Trace\n"},
         {Section::PgraphLock,"PGRAPH Lock Ownership Trace\n"},
         {Section::DrawStages,"PGRAPH Draw-End Stage Trace\n"},
         {Section::ControllerXid,"Controller / XID / OHCI USB Reconnect Trace\n"},
         {Section::GpuWait,"PGRAPH waiting NOP/flip/context:"},
         {Section::GuestInput,"Guest Input Consumer Candidate Trace (TCG)\n"},
         {Section::GuestTimer,"Guest Timer / Deadline Correlation Trace (TCG, current research preset)\n"},
         {Section::D3dCallback,"D3D InputBuffer Callback Dispatch Capture (pinned one-shot)\n"},
         {Section::LateCapture,"PTIMER Late Callback Capture (pinned one-shot)\n"},
         {Section::D3dTimerState,"D3D Timer Record / List State Trace (Patch 305.3)\n"},
         {Section::AudioMetrics,"Frames processed:"},
         {Section::AudioPacing,"Pacing deviation us min/avg/max:"},
         {Section::AvSync,"Audio / Video Sync Trace\n"},
         {Section::Watches,"Custom Watches\n"},
         {Section::History,"Recent Events\n"},
         };
         for (auto selected:probes) {
           w.m_view.SetAll(false);
           w.m_view.checked[static_cast<size_t>(selected.first)]=true;
           text=w.BuildSnapshotText();
           for(auto probe:probes) {
             bool present=text.find(probe.second)!=std::string::npos;
             if (present!=(probe.first==selected.first)) {
               std::cerr<<"Bad report gate: selected="<<(int)selected.first<<" probe="<<(int)probe.first<<"\n"<<text;
               return 1;
             }
           }
         }
         w.m_view.SetAll(true);text=w.BuildSnapshotText();
         for(auto probe:probes) assert(text.find(probe.second)!=std::string::npos);
         w.m_view.SetAll(false);api_calls=0;text=w.BuildSnapshotText();
         assert(api_calls==0);
         assert(text.find("PFIFO")==std::string::npos);
         std::cout<<"PASS: entire actual BuildSnapshotText: 40 single selections, all/none; 1,600 cross-section exclusions; no diagnostic getter when none selected\n";
        }
        '''
        (P/'test.cpp').write_text(cpp)
        cmd=[compiler,'-std=c++17','-O1','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I',str(P),str(P/'test.cpp'),str(S/'ui/xui/debug-tools/xbe-labels.cc'),'-o',str(P/'test')]
        subprocess.run(cmd,check=True)
        subprocess.run([str(P/'test')],check=True)
