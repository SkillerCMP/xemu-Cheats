#!/usr/bin/env python3
# v2.87 current regression ownership.
import argparse
import pathlib


def req(text: str, needle: str, what: str):
    if needle not in text:
        raise AssertionError(f"missing {what}: {needle}")


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--root', default='.')
    root = pathlib.Path(ap.parse_args().root).resolve()
    d = root / 'ui/xui/debug-tools/addons/diagnostics'
    ui = (d/'diagnostics.cc').read_text(encoding='utf-8')
    hh = (d/'diagnostics.hh').read_text(encoding='utf-8')
    backend_h = (d/'diagnostics-backend.h').read_text(encoding='utf-8')
    backend_c = (d/'diagnostics-backend.c').read_text(encoding='utf-8')
    helper = (d/'diagnostics-trace-buffer.h').read_text(encoding='utf-8')

    req(helper, 'XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER 100U', '100x hard safety cap')
    req(helper, 'XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE', 'chunk allocation helper')
    req(helper, 'XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT', 'chunk addressing helper')
    req(ui, 'Buffer Sizes...', 'buffer sizing popup button')
    req(ui, 'All recorders multiplier', 'global multiplier editor')
    req(ui, 'Apply to All', 'global multiplier apply')
    req(ui, 'Allowed range: 1x to 100x', 'runtime allocation warning')
    req(ui, 'Recent Events', 'Recent Events individual multiplier')
    req(ui, 'Diagnostics Buffer Sizes\\n', 'snapshot buffer-size summary')
    req(hh, 'm_buffer_multiplier_edit', 'per-recorder UI multiplier state')
    req(hh, 'm_recent_events_multiplier', 'Recent Events runtime multiplier')
    req(backend_h, 'XEMU_DIAG_BUFFER_CONTROLLER_XID', 'controller buffer id')
    req(backend_h, 'XEMU_DIAG_BUFFER_COUNT', 'complete buffer id range')
    req(backend_c, 'xemu_debug_tools_controller_xid_trace_set_buffer_multiplier', 'controller buffer bridge')
    req(backend_c, 'xemu_debug_tools_qemu_timer_trace_set_buffer_multiplier', 'QEMU timer buffer bridge')

    expected = [
        ('ptimer-trace.c', 'xemu_debug_tools_ptimer_trace_set_buffer_multiplier'),
        ('qemu-timer-trace.c', 'xemu_debug_tools_qemu_timer_trace_set_buffer_multiplier'),
        ('slow-timer-trace.c', 'xemu_debug_tools_slow_timer_trace_set_buffer_multiplier'),
        ('ohci-slow-frame-trace.c', 'xemu_debug_tools_ohci_slow_frame_trace_set_buffer_multiplier'),
        ('controller-input-poll-trace.c', 'xemu_debug_tools_controller_input_poll_trace_set_buffer_multiplier'),
        ('pgraph-ptimer-latency-trace.c', 'xemu_debug_tools_pgraph_increment_trace_set_buffer_multiplier'),
        ('pgraph-ptimer-latency-trace.c', 'xemu_debug_tools_ptimer_irq_latency_trace_set_buffer_multiplier'),
        ('bql-trace.c', 'xemu_debug_tools_bql_trace_set_buffer_multiplier'),
        ('mmio-trace.c', 'xemu_debug_tools_mmio_trace_set_buffer_multiplier'),
        ('pgraph-lock-trace.c', 'xemu_debug_tools_pgraph_lock_trace_set_buffer_multiplier'),
        ('pgraph-draw-trace.c', 'xemu_debug_tools_pgraph_draw_trace_set_buffer_multiplier'),
        ('controller-xid-trace.c', 'xemu_debug_tools_controller_xid_trace_set_buffer_multiplier'),
    ]
    for rel, needle in expected:
        req((d/rel).read_text(encoding='utf-8'), needle, f'{rel} runtime multiplier')

    # Base capacities remain unchanged: 1x must exactly preserve the old behavior.
    bases = {
        'ptimer-trace.h': 'XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY 4096',
        'qemu-timer-trace.h': 'XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY 16384',
        'slow-timer-trace.h': 'XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY 128',
        'mmio-trace.h': 'XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY 4096',
        'pgraph-lock-trace.h': 'XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY 4096',
        'pgraph-draw-trace.h': 'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY 4096',
        'controller-xid-trace.h': 'XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY 4096',
    }
    for rel, needle in bases.items():
        req((d/rel).read_text(encoding='utf-8'), needle, f'{rel} unchanged 1x base')
    req((d/'bql-trace.h').read_text(encoding='utf-8'),
        'XEMU_DEBUG_TOOLS_BQL_TRACE_CAPACITY XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY',
        'BQL 1x base capacity alias')
    req((d/'lock-trace-common.h').read_text(encoding='utf-8'),
        'XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY 4096',
        'shared lock-trace unchanged 1x base')

    print('PASS: runtime per-recorder + Apply-to-All diagnostics buffer multipliers (1x..100x)')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
