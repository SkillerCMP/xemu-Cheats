#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--root', required=True)
args = ap.parse_args()
root = Path(args.root)
dbg = root / 'ui/xui/debug-tools'

required = [
    dbg / 'addons/diagnostics/pgraph-flip-delay-trace-hook.h',
    dbg / 'addons/diagnostics/pgraph-flip-delay-trace.h',
    dbg / 'addons/diagnostics/pgraph-flip-delay-trace.c',
    dbg / 'addons/stubs/pgraph-flip-delay-trace-stub.c',
]
for path in required:
    if not path.is_file():
        raise SystemExit(f'FAIL: missing PGRAPH flip-delay file: {path}')

meson = (dbg / 'meson.build').read_text(encoding='utf-8')
for token in (
    "'addons/diagnostics/pgraph-flip-delay-trace.c'",
    "'addons/stubs/pgraph-flip-delay-trace-stub.c'",
):
    if token not in meson:
        raise SystemExit(f'FAIL: missing PGRAPH flip-delay Meson ownership: {token}')

trace_h = (dbg / 'addons/diagnostics/pgraph-flip-delay-trace.h').read_text(encoding='utf-8')
trace_c = (dbg / 'addons/diagnostics/pgraph-flip-delay-trace.c').read_text(encoding='utf-8')
for token in (
    'XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_DEFAULT_THRESHOLD_NS 40000000ULL',
    'post_release_to_next_stall_ns',
    'release_to_flip_increment_ns',
    'flip_increment_to_next_stall_ns',
    'renderer_finish_total_ns',
    'cpu_mmio_gate_wait_total_ns',
    'pfifo_cpu_mmio_gate_wait_total_ns',
    'renderer_cpu_mmio_gate_wait_total_ns',
    'pgraph_lock_wait_total_ns',
    'surface_lock_wait_total_ns',
):
    if token not in trace_h:
        raise SystemExit(f'FAIL: missing flip-delay contract: {token}')
for token in (
    'flip_delay_finalize_locked',
    'XEMU_DEBUG_TOOLS_FLIP_STALL_BEGIN',
    'XEMU_DEBUG_TOOLS_FLIP_WAITING_SET',
    'XEMU_DEBUG_TOOLS_FLIP_VBLANK_READ_INCREMENT',
    'XEMU_DEBUG_TOOLS_FLIP_PFIFO_RELEASE',
    'xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_attempt',
    'xemu_debug_tools_pgraph_flip_delay_note_increment',
):
    if token not in trace_c:
        raise SystemExit(f'FAIL: missing flip-delay analysis behavior: {token}')

pfifo = (root / 'hw/xbox/nv2a/pfifo.c').read_text(encoding='utf-8')
for renderer in (
    root / 'hw/xbox/nv2a/pgraph/gl/renderer.c',
    root / 'hw/xbox/nv2a/pgraph/null/renderer.c',
    root / 'hw/xbox/nv2a/pgraph/vk/renderer.c',
):
    rtext = renderer.read_text(encoding='utf-8')
    if 'pgraph-flip-delay-trace-hook.h' not in rtext:
        raise SystemExit(f'FAIL: renderer missing flip-delay gate hook: {renderer}')
    if rtext.count('xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(') != 1:
        raise SystemExit(f'FAIL: renderer gate begin count changed: {renderer}')
    if rtext.count('xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel();') != 1:
        raise SystemExit(f'FAIL: renderer gate cancel count changed: {renderer}')
    begin = rtext.find('xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(')
    lock = rtext.find('PGRAPH_LOCK(&d->pgraph);', begin)
    cancel = rtext.find('xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel();', begin)
    if lock < 0 or cancel < 0 or not (begin < lock < cancel):
        raise SystemExit(f'FAIL: renderer pre-PGRAPH gate layout changed: {renderer}')
    wait = rtext.find('pgraph_wait_for_cpu_mmio_accesses(&d->pgraph);', begin, lock)
    # Patch 20 owns this wait. If it is present, it must remain between the
    # Patch-300 gate marker and the existing PGRAPH lock-attempt boundary.
    if 'pgraph_wait_for_cpu_mmio_accesses(&d->pgraph);' in rtext and wait < 0:
        raise SystemExit(f'FAIL: Patch-20 renderer CPU-MMIO wait escaped measured gate: {renderer}')

if 'pgraph-flip-delay-trace-hook.h' not in pfifo:
    raise SystemExit('FAIL: PFIFO does not include flip-delay observation hook')
if pfifo.count('xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(') != 2:
    raise SystemExit('FAIL: PFIFO must mark both PGRAPH entry paths')
# The marker must remain before unlock so Patch 20 can insert its CPU-MMIO wait
# between PFIFO unlock and PGRAPH_LOCK without Patch 300 depending on Patch 20.
for call in ('&d->pgraph, 0, parameter);', '&d->pgraph, method, parameter);'):
    pos = pfifo.find(call)
    if pos < 0:
        raise SystemExit(f'FAIL: missing PFIFO gate call form: {call}')
    tail = pfifo[pos:pos + 260]
    unlock = tail.find('qemu_mutex_unlock(&d->pfifo.lock);')
    lock = tail.find('PGRAPH_LOCK(&d->pgraph);')
    if unlock < 0 or lock < 0 or not (unlock < lock):
        raise SystemExit('FAIL: PFIFO gate marker is not immediately before unlock/PGRAPH entry')
    wait = tail.find('pgraph_wait_for_cpu_mmio_accesses(&d->pgraph);')
    if 'pgraph_wait_for_cpu_mmio_accesses(&d->pgraph);' in pfifo and not (unlock < wait < lock):
        raise SystemExit('FAIL: Patch-20 PFIFO CPU-MMIO wait escaped measured gate')

lock_c = (dbg / 'addons/diagnostics/pgraph-lock-trace.c').read_text(encoding='utf-8')
inc_c = (dbg / 'addons/diagnostics/pgraph-ptimer-latency-trace.c').read_text(encoding='utf-8')
flip_c = (dbg / 'addons/diagnostics/flip-stall-trace.c').read_text(encoding='utf-8')
for token in (
    'xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_attempt()',
    'xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_acquired()',
):
    if token not in lock_c:
        raise SystemExit(f'FAIL: PGRAPH lock bridge missing: {token}')
if 'xemu_debug_tools_pgraph_flip_delay_note_increment(src)' not in inc_c:
    raise SystemExit('FAIL: PGRAPH increment profiler does not feed delay breakdown')
if 'xemu_debug_tools_pgraph_flip_delay_note_flip_event(&event)' not in flip_c:
    raise SystemExit('FAIL: FLIP lifecycle does not feed delay breakdown')

diag = (dbg / 'addons/diagnostics/diagnostics.cc').read_text(encoding='utf-8')
for token in (
    'PGRAPH Flip Delay Breakdown',
    'Record long PGRAPH flip breakdown',
    'Long frame threshold (ms)##pgraph_flip_delay',
    'XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY',
    'm_view.IsVisible(DiagnosticSection::FlipDelay)',
    'Worst CPU-MMIO gate / PGRAPH lock wait ns',
    'Worst PFIFO / renderer CPU-MMIO gate ns',
    'Detailed stage breakdown: NV2A / PTIMER -> PGRAPH Flip Delay Breakdown.',
):
    if token not in diag:
        raise SystemExit(f'FAIL: missing flip-delay UI/export integration: {token}')

print('PASS: v3.14s captures >=40 ms PGRAPH frames and correlates stall, guest/command, CPU-MMIO, PGRAPH-lock, renderer, VBlank, surface and release timing')
