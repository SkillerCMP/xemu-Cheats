#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")

header = (DIAG / "host-stall-trace.h").read_text(encoding="utf-8")
source = (DIAG / "host-stall-trace.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
hh = (DIAG / "diagnostics.hh").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")
cpu_exec = (ROOT / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")
main_loop = (ROOT / "util/main-loop.c").read_text(encoding="utf-8")

require(header, "XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY 256", "bounded event ring")
require(header, "XEMU_DEBUG_TOOLS_HOST_STALL_SAMPLE_INTERVAL_NS (250 * 1000ULL)", "vCPU sample cadence")
require(header, "XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS (500 * 1000ULL)", "off-CPU threshold")
require(header, "XEMU_DEBUG_TOOLS_HOST_STALL_BUSY_THRESHOLD_NS (2 * 1000 * 1000ULL)", "busy span threshold")
require(header, "page_fault_delta", "PageFaultCount delta")
require(header, "working_set_before", "working set counters")
require(header, "private_usage_before", "private commit counter")
require(header, "available_phys_before", "available physical memory")
require(header, "callback_expected_due_ns", "D7EA0 correlation")
require(header, "ptimer_irq_active", "PTIMER correlation")

require(source, "GetThreadTimes", "thread CPU-time source")
require(source, "QueryThreadCycleTime", "thread cycle source")
require(source, "K32GetProcessMemoryInfo", "kernel32 process-memory path")
require(source, "GetProcessMemoryInfo", "psapi fallback")
require(source, "GlobalMemoryStatusEx", "host physical-memory state")
require(source, "XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED", "page-fault correlation class")
require(source, "wall_ns > cpu_delta ? wall_ns - cpu_delta : 0", "off-CPU calculation")
require(source, "xemu_debug_tools_guest_timer_deadline_trace_get_status", "D7EA0 status bridge")
require(source, "xemu_debug_tools_ptimer_irq_delivery_trace_get_status", "PTIMER status bridge")
require(source, "#ifdef _WIN32", "Windows-only sampling")

require(cpu_exec, "xemu_debug_tools_host_stall_note_vcpu(cpu);", "TCG vCPU sampling hook")
require(main_loop, "xemu_debug_tools_host_stall_main_loop_wait_begin(poll_timeout_ns);", "main-loop wait begin hook")
require(main_loop, "xemu_debug_tools_host_stall_main_loop_wait_end(poll_timeout_ns);", "main-loop wait end hook")
require(main_loop, "g_poll_ret = qemu_poll_ns(poll_fds, n_poll_fds + w->num, poll_timeout_ns);", "unchanged qemu_poll call")

require(backend_h, "XemuDiagnosticsHostStallEvent", "backend event alias")
require(backend_c, "xemu_debug_tools_host_stall_trace_snapshot", "backend snapshot bridge")
require(meson, "addons/diagnostics/host-stall-trace.c", "host-stall build source")
require(ui, "Windows Host Stall / Page-Fault Correlation (Patch 305.4)", "snapshot/UI section")
require(ui, "PageFaultCount includes soft and hard faults", "non-causal page-fault warning")
require(ui, "xemu_diagnostics_host_stall_trace_set_enabled(value);", "Check All wiring")
require(ui, "xemu_diagnostics_host_stall_trace_clear();", "Clear All wiring")
require(ui, "m_export_host_stall_trace", "export gate")
require(hh, "bool m_export_host_stall_trace = true;", "declared export field")

cc_members = set(re.findall(r"\bm_[A-Za-z0-9_]+\b", ui))
hh_members = set(re.findall(r"\bm_[A-Za-z0-9_]+\b", hh))
missing_members = sorted(cc_members - hh_members)
if missing_members:
    raise AssertionError(f"diagnostics.cc member(s) missing from diagnostics.hh: {missing_members}")

forbid(source, "timer_mod(", "guest timer modification")
forbid(source, "cpu_interrupt(", "interrupt injection")
forbid(source, "vm_stop", "guest pause")
forbid(source, "SetThreadPriority", "host scheduling behavior change")
forbid(source, "VirtualLock", "host working-set behavior change")

print("PASS: Patch 305.4 Windows host-stall/page-fault correlation trace")
