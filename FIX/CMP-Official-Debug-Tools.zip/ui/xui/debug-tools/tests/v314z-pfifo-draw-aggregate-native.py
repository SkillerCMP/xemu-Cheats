#!/usr/bin/env python3
"""Compile the actual two Diagnostics C recorders against deterministic QEMU stubs.

No emulator/GPU/game is executed. Tests public hooks, retained exported structs,
sub-threshold accumulation, shared host timestamps, bounds, reset generations,
TLS isolation and retained-ring wrap. Private state is used only for saturation
injection and deterministic reset between independent synthetic scenarios.
"""
from __future__ import annotations
import argparse, os, pathlib, subprocess, tempfile

STUBS = {
'qemu/osdep.h': r'''
#pragma once
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <pthread.h>
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define g_new0(t,n) ((t *)calloc((n),sizeof(t)))
#define g_try_new0(t,n) g_new0(t,n)
static inline size_t g_strlcpy(char *d,const char *s,size_t n) {
    size_t l=strlen(s); if(n) {size_t m=MIN(l,n-1);memcpy(d,s,m);d[m]=0;}return l;
}
''',
'qemu/atomic.h': r'''
#pragma once
#define qatomic_read(p) __atomic_load_n((p),__ATOMIC_RELAXED)
#define qatomic_set(p,v) __atomic_store_n((p),(v),__ATOMIC_RELAXED)
#define qatomic_load_acquire(p) __atomic_load_n((p),__ATOMIC_ACQUIRE)
#define qatomic_store_release(p,v) __atomic_store_n((p),(v),__ATOMIC_RELEASE)
#define qatomic_fetch_inc(p) __atomic_fetch_add((p),1,__ATOMIC_SEQ_CST)
#define qatomic_inc(p) ((void)qatomic_fetch_inc(p))
#define qatomic_cmpxchg(p,o,n) ({__typeof__(*(p)) old_=(o); __atomic_compare_exchange_n((p),&old_,(n),0,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);old_;})
#define smp_wmb() __atomic_thread_fence(__ATOMIC_SEQ_CST)
#define smp_rmb() __atomic_thread_fence(__ATOMIC_SEQ_CST)
''',
'qemu/timer.h': r'''
#pragma once
#include <stdint.h>
enum {QEMU_CLOCK_HOST=0,QEMU_CLOCK_VIRTUAL=1};
static uint64_t test_now=1000000000, host_reads, virtual_reads;
static inline int64_t qemu_clock_get_ns(int clock) {
    if(clock==QEMU_CLOCK_HOST) {host_reads++;return (int64_t)test_now;}
    virtual_reads++;return (int64_t)test_now;
}
''',
'qemu/thread.h': r'''
#pragma once
static __thread int test_thread_id=1;
static inline int qemu_get_thread_id(void) {return test_thread_id;}
''',
'hw/core/cpu.h': r'''
#pragma once
#include <stdint.h>
typedef struct CPUState CPUState;
typedef struct CPUClass {uint64_t (*get_pc)(CPUState *);} CPUClass;
struct CPUState {int cpu_index;CPUClass *cc;};
static __thread CPUState *current_cpu;
''',
'hw/xbox/nv2a/pgraph/pgraph.h': r'''
#pragma once
#include <stdint.h>
typedef struct TestRenderer {const char *name;} TestRenderer;
typedef struct PGRAPHState {
    uint32_t primitive_mode, draw_arrays_length, draw_arrays_max_count;
    uint32_t inline_elements_length, inline_buffer_length, inline_array_length;
    uint32_t zpass_pixel_count_enable, flush_pending, sync_pending;
    TestRenderer *renderer;
} PGRAPHState;
''',
}

HARNESS=r'''
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace.c"
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace.c"
#define S(n) XEMU_DEBUG_TOOLS_PGRAPH_DRAW_##n
#define B(n) xemu_debug_tools_pgraph_draw_trace_stage_begin(S(n),NULL,0,0)
#define E(n) xemu_debug_tools_pgraph_draw_trace_stage_end(S(n))
static XemuDebugToolsPgraphPusherPfifoScope run;
static void begin_run(void) {
    xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(&run,3,0x100,0x4000);
}
static void end_run(void) {
    xemu_debug_tools_pgraph_pusher_progress_pfifo_end(&run,0x4000,0x4000,100,0,0,1);
}
static void reset(int methods,int details) {
    xemu_debug_tools_pgraph_pusher_progress_trace_set_enabled(0);
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(0);
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear();
    xemu_debug_tools_pgraph_draw_trace_set_enabled(0);
    xemu_debug_tools_pgraph_draw_trace_clear();
    if(methods) xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(1);
    if(details) xemu_debug_tools_pgraph_draw_trace_set_enabled(1);
    test_now=1000000000;host_reads=virtual_reads=0;
}
static void draw(unsigned mode) {
    XemuDebugToolsPgraphPusherPullerScope scope;
    xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin(&scope);
    xemu_debug_tools_pgraph_pusher_method_breakdown_note_method(0,0x97,0x17fc,0x17fc,0,"NV097_SET_BEGIN_END");
    B(SET_BEGIN_END_TOTAL);test_now+=10000;
    B(VK_PIPELINE_PREP);test_now+=10000;
    B(VK_TEXTURE_BIND);test_now+=50000;E(VK_TEXTURE_BIND);test_now+=10000;
    B(VK_SHADER_BIND);test_now+=100000;E(VK_SHADER_BIND);test_now+=10000;
    xemu_debug_tools_pgraph_draw_trace_pipeline_cache(mode);
    E(VK_PIPELINE_PREP);test_now+=210000;
    E(SET_BEGIN_END_TOTAL);
    xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end(&scope,1);
}
static XemuDebugToolsPgraphPusherMethodBreakdownEvent only_event(void) {
    XemuDebugToolsPgraphPusherMethodBreakdownEvent event;
    XemuDebugToolsPgraphPusherMethodBreakdownStatus status;
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(&status);
    assert(status.count==1);
    assert(xemu_debug_tools_pgraph_pusher_method_breakdown_trace_snapshot(&event,1)==1);
    return event;
}
static void no_events(void) {
    XemuDebugToolsPgraphPusherMethodBreakdownStatus st;
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(&st);assert(st.count==0);
}
static void *toggle_thread(void *arg) {
    (void)arg;test_thread_id=2;
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(0);
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear();
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(1);
    xemu_debug_tools_pgraph_draw_trace_set_enabled(0);
    xemu_debug_tools_pgraph_draw_trace_set_enabled(1);
    return NULL;
}
int main(void) {
    uint64_t shared_reads=0;
    reset(0,0);
    for(int i=0;i<1000;i++){begin_run();draw(1);end_run();}
    assert(host_reads==0 && virtual_reads==0);no_events();
    puts("PASS: recorders off, 1000 modeled draws, zero clock reads");
    for(int details=0;details<2;details++) {
        reset(1,details);begin_run();
        for(int i=0;i<189;i++) draw(1+i%3);
        end_run();
        XemuDebugToolsPgraphPusherMethodBreakdownEvent e=only_event();
        assert(e.draw.completed_draws==189 && e.draw.sub5ms_draws==189);
        assert(e.draw.fast_reuse==63 && e.draw.cache_hits==63 && e.draw.cache_misses==63);
        assert(e.draw.dropped_spans==0 && e.draw.invalid_spans==0 && !e.draw.saturated);
        assert(e.draw.stages[S(SET_BEGIN_END_TOTAL)].total_ns==189*400000ULL);
        assert(e.draw.stages[S(VK_PIPELINE_PREP)].total_ns==189*180000ULL);
        assert(e.draw.stages[S(VK_PIPELINE_PREP)].self_ns==189*30000ULL);
        assert(e.draw.stages[S(VK_TEXTURE_BIND)].total_ns==189*50000ULL);
        assert(e.draw.stages[S(VK_SHADER_BIND)].total_ns==189*100000ULL);
        uint64_t self_sum=0;
        for(unsigned i=1;i<S(STAGE_COUNT);i++) self_sum+=e.draw.stages[i].self_ns;
        assert(self_sum==e.draw.stages[S(SET_BEGIN_END_TOTAL)].total_ns);
        assert(e.top_method_count==1 && e.top_methods[0].call_count==189);
        assert(e.draw.stages[S(SET_BEGIN_END_TOTAL)].max_ns==400000);
        assert(qatomic_read(&pgraph_draw_trace.total_events)==0);
        if(!details) shared_reads=host_reads;else assert(host_reads==shared_reads);
    }
    puts("PASS: 189 sub-5ms draws retained per run; nested inclusive/self totals, cache counters and shared timestamps");
    reset(0,1);begin_run();B(SET_BEGIN_END_TOTAL);test_now+=6000000;E(SET_BEGIN_END_TOTAL);end_run();
    no_events();assert(pgraph_draw_trace.retained_draws==1);
    puts("PASS: detailed-only recorder retains >=5ms draws independently");
    reset(1,0);begin_run();draw(1);end_run();no_events();
    puts("PASS: PFIFO run retention threshold unchanged");
    reset(1,1);begin_run();B(SET_BEGIN_END_TOTAL);
    for(int i=0;i<200;i++){B(VK_UPLOAD);test_now+=50000;E(VK_UPLOAD);}
    E(SET_BEGIN_END_TOTAL);end_run();
    XemuDebugToolsPgraphPusherMethodBreakdownEvent e=only_event();
    assert(e.draw.stages[S(VK_UPLOAD)].calls==200);
    assert(e.draw.stages[S(VK_UPLOAD)].total_ns==10000000);
    assert(!e.draw.dropped_spans && !e.draw.invalid_spans);
    assert(pgraph_draw_trace.total_events<=PGRAPH_DRAW_TRACE_TLS_EVENTS);
    puts("PASS: all 200 spans aggregate even after detailed pending-event capacity is reached");
    reset(1,0);begin_run();B(SET_BEGIN_END_TOTAL);
    for(int i=0;i<40;i++) B(VK_UPLOAD);
    test_now+=6000000;
    for(int i=0;i<40;i++) E(VK_UPLOAD);
    E(SET_BEGIN_END_TOTAL);end_run();e=only_event();
    assert(e.draw.dropped_spans==17 && e.draw.invalid_spans==0);
    assert(e.draw.completed_draws==1 && e.draw.stages[S(VK_UPLOAD)].calls==23);
    puts("PASS: fixed-depth overflow is bounded and reported");
    reset(1,0);begin_run();B(SET_BEGIN_END_TOTAL);B(VK_TEXTURE_BIND);
    E(VK_SHADER_BIND);E(SET_BEGIN_END_TOTAL);test_now+=6000000;end_run();e=only_event();
    assert(e.draw.invalid_spans && e.draw.completed_draws==0);
    reset(1,0);begin_run();B(SET_BEGIN_END_TOTAL);B(VK_UPLOAD);
    test_now-=10;E(VK_UPLOAD);test_now+=6000010;E(SET_BEGIN_END_TOTAL);end_run();e=only_event();
    assert(e.draw.invalid_spans==1 && e.draw.stages[S(VK_UPLOAD)].total_ns==0);
    puts("PASS: mismatched stage ends and reversed host clock flagged, no unsigned-duration underflow");
    reset(1,0);begin_run();B(SET_BEGIN_END_TOTAL);
    xemu_debug_tools_pgraph_draw_trace_stage_begin(S(STAGE_COUNT),NULL,0,0);
    xemu_debug_tools_pgraph_draw_trace_pipeline_cache(999);
    g_method_work.draw.stages[S(SET_BEGIN_END_TOTAL)].total_ns=UINT64_MAX-2;
    test_now+=6000000;E(SET_BEGIN_END_TOTAL);end_run();e=only_event();
    assert(e.draw.saturated && e.draw.stages[S(SET_BEGIN_END_TOTAL)].total_ns==UINT64_MAX);
    assert(e.draw.invalid_spans==2);
    puts("PASS: invalid IDs and saturating aggregate counters");
    reset(1,1);begin_run();B(SET_BEGIN_END_TOTAL);test_now+=6000000;
    pthread_t t;assert(!pthread_create(&t,NULL,toggle_thread,NULL));assert(!pthread_join(t,NULL));
    E(SET_BEGIN_END_TOTAL);end_run();no_events();assert(pgraph_draw_trace.total_events==0);
    begin_run();B(SET_BEGIN_END_TOTAL);test_now+=6000000;E(SET_BEGIN_END_TOTAL);end_run();
    e=only_event();assert(e.draw.completed_draws==1 && pgraph_draw_trace.retained_draws==1);
    puts("PASS: other-thread clear/re-enable discards old TLS intervals; next run records normally");
    reset(1,0);B(SET_BEGIN_END_TOTAL);E(SET_BEGIN_END_TOTAL);assert(host_reads==0);
    for(unsigned i=0;i<XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY+3;i++) {
        begin_run();B(SET_BEGIN_END_TOTAL);test_now+=6000000;E(SET_BEGIN_END_TOTAL);end_run();
    }
    XemuDebugToolsPgraphPusherMethodBreakdownStatus status;
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(&status);
    assert(status.count==1024 && status.overwritten_events==3);
    XemuDebugToolsPgraphPusherMethodBreakdownEvent *ev=calloc(1024,sizeof(*ev));assert(ev);
    assert(xemu_debug_tools_pgraph_pusher_method_breakdown_trace_snapshot(ev,1024)==1024);
    for(unsigned i=0;i<1024;i++) {assert(ev[i].sequence==i+3);assert(ev[i].draw.completed_draws==1);}
    free(ev);
    puts("PASS: 1027 modeled runs / 1024 bounded retained slots; ordered wrap snapshots");
    printf("ABI sizes: aggregate=%zu, retained_run=%zu, run_ring=%zu, TLS=%zu bytes\n",
        sizeof(XemuDebugToolsPgraphDrawAggregate),sizeof(XemuDebugToolsPgraphPusherMethodBreakdownEvent),
        sizeof(XemuDebugToolsPgraphPusherMethodBreakdownSlot)*1024,sizeof(g_method_work));
    return 0;
}
'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--compiler',default='gcc');ap.add_argument('--sanitize',action='store_true');args=ap.parse_args()
    root=pathlib.Path(args.root).resolve()
    with tempfile.TemporaryDirectory(prefix='xemu-v314z-') as temp:
        d=pathlib.Path(temp)
        for name,text in STUBS.items():
            p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
        src=d/'harness.c';src.write_text(HARNESS);exe=d/'test'
        flags=['-x','c','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-pthread']
        if args.sanitize:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
        subprocess.run([args.compiler,*flags,'-I',str(d),'-I',str(root),str(src),'-o',str(exe)],check=True)
        env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0'
        subprocess.run([str(exe)],check=True,env=env)
        # Also compile and link the actual non-Diagnostics public hook stubs.
        smoke=d/'stub-smoke.c';smoke.write_text('''#include "ui/xui/debug-tools/addons/stubs/pgraph-draw-trace-stub.c"
int main(void){xemu_debug_tools_pgraph_draw_trace_stage_begin(1,0,0,0);xemu_debug_tools_pgraph_draw_trace_pipeline_cache(1);xemu_debug_tools_pgraph_draw_trace_stage_end(1);return 0;}
''')
        subprocess.run([args.compiler,*flags,'-I',str(root),str(smoke),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True,env=env)
        print('PASS: actual disabled-profile hook stub compiles/links/runs')
    return 0
if __name__=='__main__':raise SystemExit(main())
