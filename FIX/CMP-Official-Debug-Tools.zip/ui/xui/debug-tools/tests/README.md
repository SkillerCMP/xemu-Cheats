# Debug Tools regression tests — current consolidated suite

This directory contains **current behavior and ownership guards** for the packaged
Debug Tools tree. Historical release-fingerprint tests that no longer described
the current source were removed in the v3.10 cleanup; current feature tests are
kept by behavior rather than by a chain of obsolete whole-file hashes.

The runner has three phases:

- **static** — project/layout validation, Python/Bash syntax and source/model goldens;
- **native** — host-native C++ parser/assembler/FATX/label contracts;
- **heavy** — randomized allocator, search/format and debugger/F0 stress checks.

Key current guards include normalized Current Game identity, persistent cheats,
Folder-HDD, Video Recorder ownership, addon-only profile 5, branch Taken/Not-Taken
breakpoints without the retired Branch/Functions watcher, diagnostics trace
contracts, detached-window behavior and the v3.10 ownership cleanup.

`v310-cleanup-ownership-golden.py` specifically enforces that repository-root
Debug Tools build helpers/docs stay inside `ui/xui/debug-tools`, the controller
reconnect fix remains a core input behavior, XBE header-buffer reuse remains a
core optimization, and the retired global watcher does not return.

## Optional core patch prerequisites (v3.16e)

Patch 300 is always the foundation. The runner's default remains the **full
10/20/30/40/50/60 stack**, so a missing expected implementation still fails:

```sh
python3 ui/xui/debug-tools/tests/v287-run-regression-tests.py --root . --phase static
python3 ui/xui/debug-tools/tests/v287-run-regression-tests.py --root . --phase static --optional-patches none
python3 ui/xui/debug-tools/tests/v287-run-regression-tests.py --root . --phase static --optional-patches 10,40
```

Use the second command on a Patch-300-only reconstruction and the third only
when 10 and 40 were actually applied. This is an explicit declaration, not
feature-detection by searching for assertions' expected text. A declared patch
whose implementation is missing or broken still fails its original guards.

Mixed guards keep their always-applicable assertions. Only Patch 10's host-input
checks, Patch 20's cumulative NV2A behavior hashes, Patch 30's VBlank/APU checks,
and Patch 40's XBE-buffer checks are gated
where needed. Each excluded assertion group prints **SKIP**, not a passing test
of that optional feature. For direct test invocation use the test-only
`XEMU_TEST_OPTIONAL_PATCHES` environment variable; unset means `all`.

The three historical Vulkan token-fingerprint guards still fail on the current
full stack with Patch 60. They are not disabled or re-baselined by this cleanup.
They pass on the Patch-300-only foundation; investigate separately before
changing their algorithm-specific expectations.

Python syntax checks include nested test/helper directories. The focused tests
remain independently runnable (replace `g++` with `clang++` for a second pass):

```sh
python3 ui/xui/debug-tools/tests/v316d/run-delete.py --compiler g++
python3 ui/xui/debug-tools/tests/v316c/run-native.py --compiler g++
python3 ui/xui/debug-tools/tests/v316b/run-modal.py --compiler g++
python3 ui/xui/debug-tools/tests/v316b/run-recorder.py --compiler g++
python3 ui/xui/debug-tools/tests/v316e/run-source-file.py --compiler g++
```

The v3.16e file test links the production `cheat-source-file.cc` to real native
GLib and checks permission modes, exact edits, refusal/error paths, and no
persistent backup. Guest/UI/assembler tests elsewhere use named test doubles;
none of these commands claims a full XEMU executable build or gameplay test.

The File Replace fake-QEMU harness now has its own test-local `qemu/memalign.h`.
The free-function declaration is no longer supplied by the fake `osdep.h` path;
removing the production direct include must fail the strict C compile, just as
it did in the Windows v3.16 build. This fixes the harness, not File Replace.
