# Debug Tools regression tests — current consolidated suite

This directory contains **current behavior and ownership guards** for the packaged
Debug Tools tree. Historical release-fingerprint tests that no longer described
the current source were removed in the v3.10 cleanup; current feature tests are
kept by behavior rather than by a chain of obsolete whole-file hashes.

The runner has three phases:

- **static** — project/layout validation, Python/Bash syntax and source/model goldens;
- **native** — host-native C++ parser/assembler/FATX/label contracts;
- **heavy** — randomized allocator, search/format and debugger/F0 stress checks.

Key current guards include normalized Current Game identity, persistent cheats,
Folder-HDD, Video Recorder ownership, addon-only profile 5, branch Taken/Not-Taken
breakpoints without the retired Branch/Functions watcher, diagnostics trace
contracts, detached-window behavior and the v3.10 ownership cleanup.

`v310-cleanup-ownership-golden.py` specifically enforces that repository-root
Debug Tools build helpers/docs stay inside `ui/xui/debug-tools`, the controller
reconnect fix remains a core input behavior, XBE header-buffer reuse remains a
core optimization, and the retired global watcher does not return.
