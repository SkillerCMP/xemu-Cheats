#include "addons/file-replace/file-replace-disc-overlay.hh"
#include "addons/file-replace/file-replace-disc-overlay.h"

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <vector>

using namespace XemuFileReplace;

static int fail(const char *message)
{
    std::fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

int main()
{
    ClearDiscOverlay();
    std::vector<uint8_t> raw(32, 0xAA);
    if (xemu_file_replace_disc_overlay_apply(0x1234, 0x1000, raw.data(), raw.size()) != 0)
        return fail("inactive overlay changed data");

    auto snap = std::make_shared<OverlaySnapshot>();
    snap->disc_identity = 0x1234;
    snap->game_identity = "HASH";

    OverlayRange a;
    a.disc_start = 0x1008;
    a.reserved_size = 8;
    a.replacement = {1, 2, 3, 4};
    a.padding = PaddingMode::Original;
    a.id = "a";
    snap->ranges.push_back(a);

    OverlayRange b;
    b.disc_start = 0x1018;
    b.reserved_size = 8;
    b.replacement = {9, 8, 7};
    b.padding = PaddingMode::Zero;
    b.id = "b";
    snap->ranges.push_back(b);
    InstallDiscOverlay(snap);

    raw.assign(32, 0xAA);
    if (xemu_file_replace_disc_overlay_apply(0x9999, 0x1000, raw.data(), raw.size()) != 0)
        return fail("disc identity mismatch changed data");

    const size_t changed = xemu_file_replace_disc_overlay_apply(
        0x1234, 0x1000, raw.data(), raw.size());
    if (changed != 12) return fail("unexpected changed-byte count");
    if (raw[8] != 1 || raw[9] != 2 || raw[10] != 3 || raw[11] != 4)
        return fail("replacement bytes not copied");
    if (raw[12] != 0xAA || raw[15] != 0xAA)
        return fail("original padding did not preserve source bytes");
    if (raw[24] != 9 || raw[25] != 8 || raw[26] != 7)
        return fail("zero range replacement bytes wrong");
    for (int i = 27; i < 32; ++i) {
        if (raw[i] != 0) return fail("zero padding did not clear remainder");
    }

    OverlayStats stats = DiscOverlayStats();
    if (stats.read_hits != 1 || stats.bytes_replaced != 12)
        return fail("overlay stats wrong");

    // Partial request crossing into an override must touch only the overlap.
    std::vector<uint8_t> partial(8, 0xCC);
    if (xemu_file_replace_disc_overlay_apply(0x1234, 0x1004,
                                             partial.data(), partial.size()) != 4)
        return fail("partial overlap byte count wrong");
    if (partial[0] != 0xCC || partial[3] != 0xCC ||
        partial[4] != 1 || partial[7] != 4)
        return fail("partial overlap content wrong");

    // Hot reload swaps immutable snapshots; future reads see only the new bytes.
    auto reload = std::make_shared<OverlaySnapshot>();
    reload->disc_identity = 0x1234;
    reload->game_identity = "HASH";
    OverlayRange r;
    r.disc_start = 0x1008;
    r.reserved_size = 4;
    r.replacement = {0xF1, 0xF2, 0xF3, 0xF4};
    r.padding = PaddingMode::Original;
    reload->ranges.push_back(r);
    InstallDiscOverlay(reload);
    raw.assign(16, 0x55);
    if (xemu_file_replace_disc_overlay_apply(0x1234, 0x1000, raw.data(), raw.size()) != 4)
        return fail("reload application count wrong");
    if (raw[8] != 0xF1 || raw[11] != 0xF4)
        return fail("reloaded bytes not visible");

    ClearDiscOverlay();
    std::puts("PASS: File Replace immutable DVD overlay byte-substitution model");
    return 0;
}
