#!/usr/bin/env python3
"""v3.14ai XEMU-CHEATDB safe-merge and UI-integration guards."""
from __future__ import annotations
import argparse
from pathlib import Path


def need(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    dt = root / "ui/xui/debug-tools"
    addon = dt / "addons/cheat-db"

    cc = (addon / "cheat-db.cc").read_text(encoding="utf-8")
    hh = (addon / "cheat-db.hh").read_text(encoding="utf-8")
    fmt = (addon / "cheat-db-format.hh").read_text(encoding="utf-8")
    readme = (addon / "README.md").read_text(encoding="utf-8")
    cheat_ui = (dt / "cheat-engine-ui.cc").read_text(encoding="utf-8")
    cheat_hh = (dt / "cheat-engine.hh").read_text(encoding="utf-8")
    cheat_source = (dt / "cheat-engine-source.cc").read_text(encoding="utf-8")
    library = (dt / "addons/game-library/game-library.cc").read_text(encoding="utf-8")
    core = (dt / "debug-tools.cc").read_text(encoding="utf-8")
    meson = (dt / "meson.build").read_text(encoding="utf-8")

    # Database is CMP-addon-owned; no new upstream/core patch hook is required.
    need(meson, "addons/cheat-db/cheat-db.cc", "CheatDB build ownership")
    need(core, "XemuCheatDb::cheat_db_manager.Register();", "shared manager registration")
    need(hh, "class CheatDbManager", "shared manager API")
    need(readme, "CMP-Official-Debug-Tools.zip", "addon ownership documentation")

    # Real repository and generated manifest format.
    need(cc, "SkillerCMP/XEMU-CHEATDB/main/cheatdb-manifest.json", "manifest URL")
    for token in ("schema_version", "source_commit", "relative_path", "sha256",
                  "download_url", "cheat_root"):
        need(cc, token, f"manifest field {token}")
    need(cc, "parsed.schema_version != 1", "manifest schema guard")
    need(cc, "kMaxManifestBytes", "manifest size bound")
    need(cc, "kMaxCheatFileBytes", "cheat file size bound")
    need(cc, "kMaxManifestFiles", "manifest entry bound")
    need(cc, "bool SameGameIdentity(const GameRef &a, const GameRef &b)",
         "revision-aware game identity comparison")
    need(cc, "path.find(identity16)", "manifest filename identity preference")

    # Downloads must use the existing QEMU HTTP helper from background jobs.
    need(cc, '#include "qemu/http.h"', "existing QEMU HTTP API")
    need(cc, "http_get(url.c_str()", "HTTP GET implementation")
    for worker in ("void ManifestWork(void *opaque)", "void ReviewWork(void *opaque)",
                   "void ApplyWork(void *opaque)", "void GlobalWork(void *opaque)"):
        need(cc, worker, f"background worker {worker}")
    need(cc, "debug_tools_queue_background_job(", "background job queue")
    tick = cc[cc.index("void CheatDbManager::Tick()") :]
    forbid(tick, "http_get(", "network access on UI tick")
    # File hashing is allowed in workers, not in the per-frame button-state function.
    state_fn = cc[cc.index("ButtonState CheatDbManager::CurrentGameButtonState() const"):
                  cc.index("const char *CheatDbManager::CurrentGameButtonLabel() const")]
    forbid(state_fn, "FileSha256(", "per-frame whole-file hashing")

    # CMP CodeFormat block identity and parser syntax must align with Cheat Engine.
    for token in ('t.rfind("!!", 0)', "if (t[0] == '!')", "if (t[0] == '+')",
                  '":PREENTRY:"', 'block.group_path + "\\n" + block.name',
                  "block.ordinal"):
        need(fmt, token, f"CMP parser {token}")
    need(cheat_source, 'Groups use CMP-style nesting:', "authoritative CMP syntax docs")
    need(cheat_source, '+:PREENTRY:Cheat Name', "authoritative PREENTRY syntax")

    # Per-block safe classification. Local-only/local-edited content is never
    # selected by the safe path and cannot be deleted by MergeSelected.
    for token in ("ItemStatus::Same", "ItemStatus::New", "ItemStatus::Updated",
                  "ItemStatus::LocalModified", "ItemStatus::Conflict",
                  "ItemStatus::LocalOnly"):
        need(cc, token, f"status {token}")
    need(cc, "ClassifyRemoteBlock(has_local, item.local_hash",
         "tested CMP block ownership classifier")
    need(fmt, "inline BlockCompareStatus ClassifyRemoteBlock",
         "pure ownership classifier")
    need(cc, "item.status == ItemStatus::New || item.status == ItemStatus::Updated",
         "safe auto-update selection")
    need(cc, "LOCAL ONLY - KEEP", "local-only UI protection")
    need(cc, "LOCAL MODIFIED - KEEP unless selected", "local modification protection")
    need(cc, "CONFLICT - KEEP unless selected", "conflict protection")
    need(fmt, "std::vector<std::string> lines = local.lines;", "local source as merge base")
    forbid(fmt, "local.lines.clear", "destructive local replacement")

    # Ownership metadata and backup before any existing local file change.
    need(cc, '".cheatdb-state.json"', "ownership state file")
    need(cc, 'JoinFile(cheat_dir, "Backup")', "backup root")
    need(cc, 'g_date_time_format(now, "%Y%m%d-%H%M%S")', "timestamped backup")
    apply_fn = cc[cc.index("bool ApplyReviewToDisk(ApplyJob &job)"):
                  cc.index("void ApplyWork(void *opaque)")]
    if apply_fn.index("BackupFile(") > apply_fn.index("WriteTextFile(review.local_path, merged.text"):
        raise AssertionError("existing local file must be backed up before merged write")
    need(apply_fn, "Local cheat file changed after the review opened", "stale-review protection")

    # Cheat Engine button lives beside Reload and offers global management.
    reload_pos = cheat_ui.index('ImGui::Button("Reload (Cheat File)")')
    db_pos = cheat_ui.index("CurrentGameButtonLabel()")
    if not reload_pos < db_pos:
        raise AssertionError("CheatDB current-game button must follow Reload (Cheat File)")
    for token in ('"Download Cheats"', '"Update Cheats"', '"Cheat Database"'):
        need(cc + cheat_ui, token, f"Cheat Engine UI {token}")
    need(cheat_hh, "CheatDirectoryPath() const", "shared Cheats directory API")
    need(cheat_hh, "LoadedCheatPath() const", "loaded cheat path API")
    need(cheat_hh, "ReloadCurrentCheatFile()", "post-update reload API")
    need(cheat_source, "std::string CheatEngineWindow::CheatDirectoryPath() const",
         "Cheats directory implementation")

    # Game Library uses the same manager; no second downloader/merger is allowed.
    need(library, "XemuCheatDb::cheat_db_manager.GameLibraryButtonLabel", "library button")
    need(library, "XemuCheatDb::cheat_db_manager.OpenForGame", "library manager handoff")
    forbid(library, "http_get(", "duplicate Game Library downloader")
    forbid(library, "MergeSelected(", "duplicate Game Library merger")

    # Global operation is explicitly safe and offers the requested all-database path.
    need(cc, '"Global Download / Update"', "global view")
    need(cc, '"Download Missing / Update All Safely"', "global safe update action")
    need(cc, "GlobalWork", "global worker")

    # This feature is .txt CMP CodeFormat only; TOML must not leak into it.
    for text, where in ((cc, "cheat-db.cc"), (fmt, "cheat-db-format.hh"), (readme, "README.md")):
        forbid(text.lower(), "toml", f"TOML terminology in {where}")
    need(cc, 'EndsWithTxt(file.relative_path)', ".txt database filtering")

    print("PASS: v3.14ai CheatDB manifest, CMP block merge, local-preservation, background-work and shared UI guards")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
