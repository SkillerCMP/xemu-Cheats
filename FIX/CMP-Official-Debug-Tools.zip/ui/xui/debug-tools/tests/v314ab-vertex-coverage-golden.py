#!/usr/bin/env python3
"""Observation-only vertex synchronization and bounded all-run coverage guard."""
import argparse,pathlib
from v314y_vulkan_observer_test_utils import strip_stage_hooks,token_hash,check_vk_observation_only,function
from v314ab_vertex_test_utils import BASE_VERTEX_TOKEN_HASH,FROZEN_VERTEX,FROZEN_SYNC

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);a=ap.parse_args();root=pathlib.Path(a.root)
    d=root/'ui/xui/debug-tools/addons/diagnostics'
    v=(root/'hw/xbox/nv2a/pgraph/vk/vertex.c').read_text();draw=(root/'hw/xbox/nv2a/pgraph/vk/draw.c').read_text()
    assert token_hash(strip_stage_hooks(v))==BASE_VERTEX_TOKEN_HASH
    check_vk_observation_only(draw)
    assert token_hash(strip_stage_hooks(function(draw,'static void sync_vertex_ram_buffer(')))==token_hash(FROZEN_SYNC)
    for old,new in [('pgraph_vk_finish(pg, VK_FINISH_REASON_VERTEX_BUFFER_DIRTY);',''),
                    ('pgraph_vk_download_surfaces_in_range_if_dirty(pg, offset, size);',''),
                    ('data, size);','data, size + 1);')]:
        assert old in v
        assert token_hash(strip_stage_hooks(v.replace(old,new,1)))!=BASE_VERTEX_TOKEN_HASH
    core=(d/'pgraph-pusher-progress-trace.c').read_text()
    finish=function(core,'static void pusher_method_work_finish(')
    assert finish.index('pusher_coverage_finish(')<finish.index('event.duration_ns < XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS')
    for name in ['pusher_coverage_finish','coverage_publish']:
        fn=function(core,('static void ' if name=='pusher_coverage_finish' else 'static bool ')+name+'(')
        for bad in ['mutex_lock','sleep(', 'qemu_clock_get_ns','malloc(', 'g_new0']:
            assert bad not in fn,(name,bad)
    pub=function(core,'static bool coverage_publish(')
    assert 'qatomic_cmpxchg(&slot->busy, 0, 1)' in pub and 'while' not in pub
    assert 'qatomic_store_release(&slot->busy, 0)' in pub
    assert 'qatomic_load_acquire(&g_coverage_slots)' in pub
    snap=function(core,'size_t xemu_debug_tools_pgraph_pusher_coverage_snapshot(')
    assert 'qatomic_cmpxchg(&slot->busy, 0, 1)' in snap and 'slot->event.epoch == epoch' in snap
    assert 'VERTEX_METRICS' in (d/'diagnostics.cc').read_text()
    print('PASS: frozen whole vertex.c and draw.c behavior/order, unchanged dirty predicates/copy/waits, bounded nonblocking all-run publication')
if __name__=='__main__':main()
