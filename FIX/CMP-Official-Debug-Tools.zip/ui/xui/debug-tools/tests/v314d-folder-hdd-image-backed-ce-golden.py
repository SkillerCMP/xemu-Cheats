#!/usr/bin/env python3
"""v3.14d image-backed C/E Folder-HDD architecture guard."""
from __future__ import annotations
import argparse
from pathlib import Path


def req(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    d = root / "ui/xui/debug-tools/addons/Folder-HDD"
    c = (d / "folder-hdd.c").read_text(encoding="utf-8")
    sync = (d / "folder-hdd-sync.cc").read_text(encoding="utf-8")
    hdr = (d / "folder-hdd-sync.h").read_text(encoding="utf-8")
    readme = (d / "README.md").read_text(encoding="utf-8")

    # C/E are authoritative image backings; loose folders are mirrors only.
    for token in (
        'CMP_IMAGES_DIRECTORY "Images"',
        'CMP_C_IMAGE_FILENAME "C.img"',
        'CMP_E_IMAGE_FILENAME "E.img"',
        "cmp_ce_images_prepare",
        "cmp_ce_image_read",
        "cmp_ce_image_write",
        "cmp_ce_images_flush_locked",
        "cmp_ce_images_import_host_locked",
    ):
        req(c, token, "image-backed C/E runtime")
    req(c, "loose folders are mirrors", "guest read ownership comment")
    req(c, "cmp_partition_build_with_hints", "allocation-preserving host import")
    req(c, "cmp_folder_hdd_sync_collect_allocation_hints", "live allocation hints")
    req(c, "cmp_folder_hdd_sync_mark_image_dirty", "pre-write durable dirty marker")
    req(c, "cmp_folder_hdd_sync_mark_converged", "persistent convergence marker")
    req(c, "ce_created_mask != 3u", "partial image-pair fail-safe")
    req(c, "cmp_get_le32(header + 4) == p.volume_id", "C/E image identity validation")

    # Guest C/E I/O must not fall back to loose host files.
    disk_read = c[c.index("static int cmp_disk_read("):c.index("static CMPOverlayPage", c.index("static int cmp_disk_read("))]
    req(disk_read, "cmp_ce_image_read", "C/E block image read")
    forbid(disk_read, "cmp_file_read", "live loose-file guest read")
    disk_write = c[c.index("static int cmp_disk_write("):c.index("static void cmp_overlay_cleanup", c.index("static int cmp_disk_write("))]
    req(disk_write, "cmp_ce_image_write", "C/E block image write")

    # X/Y/Z Hybrid cache ownership must remain unchanged.
    for token in (
        'CMP_CACHE_FILENAME "xbox_cache.img"',
        "CMP_CACHE_DISK_START 0x00080000ULL",
        "CMP_CACHE_DISK_END   0x8CA80000ULL",
        "cmp_cache_read",
        "cmp_cache_write",
    ):
        req(c, token, "X/Y/Z Hybrid cache")

    # Cross-session baseline and dirty marker are persisted under Images/.
    for token in (
        '"ce-sync-baseline.tsv"',
        '"ce-image-dirty.flag"',
        '"CMP-CE-IMAGE-MANIFEST-1\\n"',
        "cmp_folder_hdd_sync_persistent_state",
        "cmp_folder_hdd_sync_mark_image_dirty",
        "cmp_folder_hdd_sync_mark_converged",
    ):
        req(sync, token, "persistent C/E convergence state")
    req(hdr, "CMPFolderHddAllocationHint", "allocation-hint bridge")

    # The old C/E retained-overlay/resynthesized-live-folder model is retired.
    for token in (
        "cmp_rebuild_partitions_locked",
        "cmp_try_collapse_persisted_overlay",
        "committed guest FATX overlay must remain active",
        "host_overlay_written",
    ):
        forbid(c, token, "retired C/E live-folder overlay model")

    # Safety: host/Xbox conflict protection remains conservative.
    req(sync, "HostWritebackAllowsAdditionsOnly", "host-addition compatibility gate")
    req(sync, "host path changed while Xbox writes were pending", "existing-file modification protection")
    req(sync, "host path was removed while Xbox writes were pending", "existing-file removal protection")
    req(sync, "host/Xbox file-addition conflict", "same-path addition conflict")

    # The dedicated folder-hdd profile must remain documented/supported.
    req(readme, "profile 5 remains supported", "folder-hdd profile ownership")
    req(readme, "Images/C.img", "documented C image")
    req(readme, "Images/E.img", "documented E image")

    print("PASS: v3.14d image-backed C/E Folder-HDD architecture guard")


if __name__ == "__main__":
    main()
