#!/usr/bin/env python3
"""Guard the explicitly retired assets and the replacement user guide.

Uses only the standard library; rendering/PDF example checks are also performed
when the release package is prepared, not by the user's platform build.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--root', default='.')
root = Path(parser.parse_args().root).resolve()
debug = root / 'ui/xui/debug-tools'
for name in ('Build-Xemu-MINGW64.bat', 'Build-Xemu-DOCKER.bat'):
    assert not list(debug.rglob(name)), f'retired builder returned: {name}'
assert not (debug / 'docs').exists(), 'retired Debug Tools docs folder returned'
pdf = debug / 'Codetypes/XEMU-Code-Types-Guide.pdf'
data = pdf.read_bytes()
assert data.startswith(b'%PDF-') and data.rstrip().endswith(b'%%EOF'), 'invalid guide container'
assert len(data) > 10000, 'guide unexpectedly empty/truncated'
assert 'Codetypes/XEMU-Code-Types-Guide.pdf' in (debug / 'README.md').read_text()
for name in ('build-xemu.sh', 'build-capstone.sh', 'build-capstone-windows.sh',
             'build-keystone.sh', 'prepare-build-dependencies.sh',
             'docker-build-windows.sh', 'read-build-profile.py'):
    assert (debug / 'tools' / name).is_file(), f'active helper lost: {name}'
runner = (debug / 'tests/v287-run-regression-tests.py').read_text()
assert 'v313-raw-code-semantics-golden.py' in runner
reference = (debug / 'tests/fixtures/v312-pointer-reference.inc').read_text().strip().encode()
assert hashlib.sha256(reference).hexdigest() == 'f7d62f80b068698b4ea2b4ef8da3014c8bcd2e2fefd48d24aa57bbea556842a0'
cases = json.loads((debug / 'tests/fixtures/codetypes-examples.json').read_text())
assert len(cases) >= 70 and len({c['id'] for c in cases}) == len(cases)
print('PASS: v3.13 retired assets, code-types PDF, active helpers and example/reference fixtures')
