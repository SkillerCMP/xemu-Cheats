#!/usr/bin/env python3
"""Actual C recorder/vertex functions against deterministic dependencies, not a GPU test."""
import argparse, importlib.util, pathlib, subprocess, tempfile
from v314y_vulkan_observer_test_utils import function
from v314ab_vertex_test_utils import FROZEN_VERTEX, FROZEN_SYNC

def load(path):
    spec=importlib.util.spec_from_file_location('aggregate_fixtures',path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

COVERAGE=r'''
#include <sched.h>
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace.c"
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace.c"
#define S(n) XEMU_DEBUG_TOOLS_PGRAPH_DRAW_##n
#define B(n) xemu_debug_tools_pgraph_draw_trace_stage_begin(S(n),NULL,0,0)
#define E(n) xemu_debug_tools_pgraph_draw_trace_stage_end(S(n))
static XemuDebugToolsPgraphCoverageEvent events[XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY];
static void reset(void) {
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(0);
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear();
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(1);
 xemu_debug_tools_pgraph_draw_trace_set_enabled(0);
 test_now=1000000000;
}
static void small_run(void) {
 XemuDebugToolsPgraphPusherPfifoScope run;
 xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(&run,0,0x100,0x200);
 B(SET_BEGIN_END_TOTAL);
 B(VK_SYNC_VERTEX_RAM);
 B(VK_VERTEX_DIRTY_CHECK);test_now+=100000;E(VK_VERTEX_DIRTY_CHECK);
 B(VK_VERTEX_DIRTY_FINISH);
 B(VK_FINISH_FENCE_WAIT);test_now+=200000;E(VK_FINISH_FENCE_WAIT);
 test_now+=100000;E(VK_VERTEX_DIRTY_FINISH);
 B(VK_VERTEX_COPY);test_now+=100000;E(VK_VERTEX_COPY);
 xemu_debug_tools_pgraph_draw_trace_metric(XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_BYTES,8192);
 xemu_debug_tools_pgraph_draw_trace_metric(XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_CALLS,1);
 xemu_debug_tools_pgraph_draw_trace_metric(XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_OVERLAP_FINISHES,1);
 E(VK_SYNC_VERTEX_RAM);test_now+=500000;E(SET_BEGIN_END_TOTAL);
 xemu_debug_tools_pgraph_pusher_progress_pfifo_end(&run,0x200,0x200,50,0,0,1);
}
static int stress_finished_batch, stress_reader_stopped;
static void *stress_producer(void *opaque) {
 (void)opaque;
 for(unsigned i=0;i<5000;i++)small_run();
 __atomic_store_n(&stress_finished_batch,1,__ATOMIC_RELEASE);
 while(!__atomic_load_n(&stress_reader_stopped,__ATOMIC_ACQUIRE))sched_yield();
 small_run(); /* Flush a potentially deferred tail after reader stops. */
 return NULL;
}
int main(void) {
 uint64_t skipped,total_runs,total_short,total_ns,bytes;
 reset();for(int i=0;i<240;i++)small_run();
 size_t n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
 assert(n==3 && !skipped);
 total_runs=total_short=total_ns=bytes=0;
 for(size_t i=0;i<n;i++) {
  XemuDebugToolsPgraphCoverageEvent *e=&events[i];
  assert(e->sequence==i && e->closed==(i<2));
  assert(e->end_ns==e->runs*1000000 && e->vertex_ns==e->runs*500000);
  assert(e->fence_wait_ns==e->runs*200000 && e->copy_ns==e->runs*100000);
  assert(e->vertex_fence_wait_ns==e->runs*200000 && e->vertex_fence_waits==e->runs);
  assert(!e->invalid_spans && !e->dropped_spans && !e->saturated);
  total_runs+=e->runs;total_short+=e->short_runs;total_ns+=e->run_ns;bytes+=e->copy_bytes;
 }
 assert(total_runs==240 && total_short==240 && total_ns==240000000 && bytes==240*8192);
 XemuDebugToolsPgraphPusherMethodBreakdownStatus st;
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(&st);assert(!st.count);
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(0);
 assert(xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped)==3);
 puts("PASS: 240 sub-5ms scopes covered; nested vertex/fence/copy metrics exact; raw long-run threshold unchanged; stop preserves windows");
 reset();qatomic_set(&g_coverage_slots[0].busy,1);
 small_run();small_run();small_run();
 n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);assert(n==0 && skipped==1);
 qatomic_set(&g_coverage_slots[0].busy,0);small_run();
 n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
 assert(n==1 && !skipped && events[0].runs==4 && events[0].publication_deferrals==3);
 puts("PASS: busy reader never blocks producer; deferred publication catches up without losing run contributions");
 reset();for(unsigned i=0;i<2050;i++) {
  XemuDebugToolsPgraphPusherPfifoScope run;
  xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(&run,0,0x100,0x200);
  test_now+=100000000;
  xemu_debug_tools_pgraph_pusher_progress_pfifo_end(&run,0x200,0x200,1,0,0,1);
 }
 n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
 assert(n==2048 && !skipped && events[0].sequence==2 && events[n-1].sequence==2049);
 for(size_t i=0;i<n;i++)assert(events[i].runs==1 && !events[i].short_runs && events[i].closed);
 xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear();
 assert(!xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped));
 small_run();n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
 assert(n==1 && events[0].sequence==0 && events[0].runs==1);
 puts("PASS: 2048-window wrap, sorted retained range, clear generation invalidation and restart");
 /* Model a clear racing just after the finish generation check. */
 reset();XemuDebugToolsPgraphPusherPfifoScope pending;
 xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(&pending,0,0x100,0x200);
 qatomic_inc(&g_coverage_epoch);test_now+=1000000;
 pusher_coverage_finish(test_now,test_now,1);
 assert(!xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped));
 puts("PASS: in-flight old run cannot be relabeled into a freshly cleared coverage epoch");
 reset();xemu_debug_tools_pgraph_draw_trace_set_enabled(1);
 XemuDebugToolsPgraphPusherPfifoScope run;
 xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(&run,0,0x100,0x200);
 B(SET_BEGIN_END_TOTAL);B(VK_SYNC_VERTEX_RAM);
 for(int i=0;i<100;i++){B(VK_VERTEX_COPY);test_now+=100000;E(VK_VERTEX_COPY);}
 E(VK_SYNC_VERTEX_RAM);E(SET_BEGIN_END_TOTAL);
 xemu_debug_tools_pgraph_pusher_progress_pfifo_end(&run,0x200,0x200,1,0,0,1);
 XemuDebugToolsPgraphDrawTraceStatus ds;
 xemu_debug_tools_pgraph_draw_trace_get_status(&ds);
 assert(ds.retained_draws==1 && ds.truncated_draws==1);
 assert(g_method_work.draw.stages[S(VK_VERTEX_COPY)].calls==100);
 assert(!g_method_work.draw.invalid_spans && !g_method_work.draw.dropped_spans);
 puts("PASS: detail pool truncation is reported while every child still aggregates");
 reset();pthread_t producer;assert(!pthread_create(&producer,NULL,stress_producer,NULL));
 do {
  n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
  for(size_t i=0;i<n;i++) {
   assert(events[i].run_ns==events[i].runs*1000000);
   assert(events[i].copy_bytes==events[i].runs*8192);
   assert(events[i].vertex_fence_wait_ns==events[i].runs*200000);
   assert(!events[i].invalid_spans && !events[i].dropped_spans);
   if(i)assert(events[i-1].sequence<events[i].sequence);
  }
 }while(!__atomic_load_n(&stress_finished_batch,__ATOMIC_ACQUIRE));
 __atomic_store_n(&stress_reader_stopped,1,__ATOMIC_RELEASE);
 assert(!pthread_join(producer,NULL));
 n=xemu_debug_tools_pgraph_pusher_coverage_snapshot(events,2048,&skipped);
 total_runs=0;for(size_t i=0;i<n;i++)total_runs+=events[i].runs;
 assert(!skipped && total_runs==5001);
 puts("PASS: concurrent producer/reader stress: internally consistent sorted snapshots and all 5001 runs recovered after final publication");

 return 0;
}
'''

VERTEX_SUPPORT=r'''
#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace-hook.h"
typedef uint64_t hwaddr;
typedef uint64_t VkDeviceSize;
#define TARGET_PAGE_SIZE 4096
#define TARGET_PAGE_MASK (~(hwaddr)(TARGET_PAGE_SIZE-1))
#define TARGET_PAGE_ALIGN(x) (((x)+TARGET_PAGE_SIZE-1)&TARGET_PAGE_MASK)
#define ROUND_UP(x,y) (((x)+(y)-1)&~((hwaddr)(y)-1))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define NV2A_VK_DGROUP_BEGIN(...) ((void)0)
#define NV2A_VK_DGROUP_END(...) ((void)0)
#define NV2A_VK_DPRINTF(...) ((void)0)
#define DIRTY_MEMORY_NV2A 0
#define BUFFER_VERTEX_RAM 0
#define NV2A_PROF_GEOM_BUFFER_UPDATE_1 0
#define VK_FINISH_REASON_VERTEX_BUFFER_DIRTY 7
#define BYTES (32*TARGET_PAGE_SIZE)
typedef struct MemorySyncRequirement {hwaddr addr,size;} MemorySyncRequirement;
typedef struct PGRAPHVkState {
 int num_vertex_ram_buffer_syncs;
 MemorySyncRequirement vertex_ram_buffer_syncs[16];
 uint64_t uploaded_bitmap[1];
 struct {unsigned char *mapped;} storage_buffers[1];
} PGRAPHVkState;
typedef struct PGRAPHState {PGRAPHVkState *vk_renderer_state;} PGRAPHState;
typedef struct NV2AState {PGRAPHState pgraph;uint64_t *vram;unsigned char *vram_ptr;} NV2AState;
static uint64_t logs[1024][3], log_count, metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_COUNT];
static unsigned stack[64],depth,recording,surface_clear;
static void op(uint64_t a,uint64_t b,uint64_t c){assert(log_count<1024);logs[log_count][0]=a;logs[log_count][1]=b;logs[log_count++][2]=c;}
void xemu_debug_tools_pgraph_draw_trace_stage_begin(unsigned stage,const void *pg,uint64_t a,uint64_t b){(void)pg;(void)a;(void)b;if(recording){assert(depth<64);stack[depth++]=stage;}}
void xemu_debug_tools_pgraph_draw_trace_stage_end(unsigned stage){if(recording){assert(depth && stack[--depth]==stage);}}
void xemu_debug_tools_pgraph_draw_trace_metric(unsigned m,uint64_t v){if(recording){assert(m<XEMU_DEBUG_TOOLS_PGRAPH_METRIC_COUNT);metrics[m]+=v;}}
static uint64_t mask(unsigned a,unsigned n){assert(a+n<=32);return ((1ULL<<n)-1)<<a;}
static bool memory_region_test_and_clear_dirty(uint64_t *v,hwaddr a,VkDeviceSize s,int flag){(void)flag;uint64_t bits=mask(a/TARGET_PAGE_SIZE,s/TARGET_PAGE_SIZE);bool result=(*v&bits)!=0;*v&=~bits;op(1,a,s);return result;}
static size_t find_next_bit(uint64_t *map,size_t end,size_t start){op(3,start,end);while(start<end && !(*map&(1ULL<<start)))start++;return start;}
static void bitmap_set(uint64_t *map,size_t start,size_t count){op(6,start,count);*map|=mask(start,count);}
static void pgraph_vk_download_surfaces_in_range_if_dirty(PGRAPHState *pg,hwaddr a,VkDeviceSize s){op(2,a,s);if(surface_clear)pg->vk_renderer_state->uploaded_bitmap[0]&=~mask(a/TARGET_PAGE_SIZE,TARGET_PAGE_ALIGN(s)/TARGET_PAGE_SIZE);}
static void pgraph_vk_finish(PGRAPHState *pg,int reason){assert(reason==7);op(4,reason,0);pg->vk_renderer_state->uploaded_bitmap[0]=0;}
static void nv2a_profile_inc_counter(int c){op(5,c,0);}
static void *tracked_memcpy(void *d,const void *s,size_t n){op(7,n,0);return memcpy(d,s,n);}
#define memcpy tracked_memcpy
'''
VERTEX_MAIN=r'''
#undef memcpy
int main(void){
 static unsigned char src[BYTES],first[BYTES],second[BYTES];
 static uint64_t first_logs[1024][3];
 for(unsigned mode=0;mode<2;mode++)for(unsigned seed=0;seed<1024;seed++) {
  PGRAPHVkState initial={0},a={0},b={0};
  uint64_t dirty_a=(uint64_t)(seed*2654435761u),dirty_b=dirty_a;
  initial.num_vertex_ram_buffer_syncs=seed%17;
  initial.uploaded_bitmap[0]=(uint64_t)(seed*1664525u+1013904223u);
  for(int i=0;i<initial.num_vertex_ram_buffer_syncs;i++){
   initial.vertex_ram_buffer_syncs[i].addr=((seed+7*i)%28)*4096+(seed%127);
   initial.vertex_ram_buffer_syncs[i].size=1+((seed+257*i)%8192);
  }
  a=initial;b=initial;memset(first,0,BYTES);memset(second,0,BYTES);
  for(unsigned i=0;i<BYTES;i++)src[i]=(unsigned char)(i+seed);
  a.storage_buffers[0].mapped=first;b.storage_buffers[0].mapped=second;
  NV2AState da={.pgraph={.vk_renderer_state=&a},.vram=&dirty_a,.vram_ptr=src};
  NV2AState db={.pgraph={.vk_renderer_state=&b},.vram=&dirty_b,.vram_ptr=src};
  surface_clear=seed%2;recording=0;log_count=0;
  baseline_sync_vertex_ram_buffer(&da.pgraph);
  uint64_t count=log_count;memcpy(first_logs,logs,sizeof(logs));
  log_count=depth=0;memset(metrics,0,sizeof(metrics));recording=mode;
  sync_vertex_ram_buffer(&db.pgraph);
  assert(!depth && count==log_count && !memcmp(first_logs,logs,count*sizeof(logs[0])));
  assert(!memcmp(first,second,BYTES) && dirty_a==dirty_b && a.uploaded_bitmap[0]==b.uploaded_bitmap[0]);
  assert(a.num_vertex_ram_buffer_syncs==b.num_vertex_ram_buffer_syncs);
  assert(!memcmp(a.vertex_ram_buffer_syncs,b.vertex_ram_buffer_syncs,sizeof(a.vertex_ram_buffer_syncs)));
  if(mode){
    uint64_t copies=0,bytes=0,finishes=0;
    for(uint64_t i=0;i<count;i++){if(logs[i][0]==7){copies++;bytes+=logs[i][1];}if(logs[i][0]==4)finishes++;}
    assert(metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_REQUESTED_RANGES]==(unsigned)initial.num_vertex_ram_buffer_syncs);
    assert(metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_CALLS]==copies);
    assert(metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_BYTES]==bytes);
    assert(metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_OVERLAP_FINISHES]==finishes);
  }
 }
 puts("PASS: 2048 actual sync/update cases versus frozen aa: identical dirty tests, surface/finish/copy order, ranges, bitmaps and bytes; trace on/off; metric counts exact");
 return 0;
}
'''

MARKERS=r'''
#include "ui/xui/debug-tools/addons/diagnostics/av-sync-trace.c"
int main(void) {
 XemuDebugToolsAvSyncMarker markers[64];uint64_t total;
 assert(!xemu_debug_tools_av_sync_trace_mark(1));
 xemu_debug_tools_av_sync_trace_set_enabled(1);
 xemu_debug_tools_av_sync_trace_note_audio_batch(NULL,256);
 xemu_debug_tools_av_sync_trace_note_vblank(16666666);
 xemu_debug_tools_av_sync_trace_note_pgraph_flip(12);
 XemuDebugToolsAvSyncTraceStatus before,after;
 xemu_debug_tools_av_sync_trace_get_status(&before);
 for(unsigned i=0;i<70;i++){test_now+=1000;assert(xemu_debug_tools_av_sync_trace_mark(1+i%3));}
 size_t n=xemu_debug_tools_av_sync_trace_markers_snapshot(markers,64,&total);
 assert(n==64 && total==70 && markers[0].sequence==6 && markers[63].sequence==69);
 for(size_t i=0;i<n;i++)assert(markers[i].audio_samples==256 && markers[i].video_vblanks==1 && markers[i].pgraph_flips==1);
 xemu_debug_tools_av_sync_trace_get_status(&after);
 assert(before.audio_batches==after.audio_batches && before.total_events==after.total_events);
 assert(before.audio_host_drift_ns==after.audio_host_drift_ns && before.video_host_drift_ns==after.video_host_drift_ns);
 assert(!xemu_debug_tools_av_sync_trace_mark(0) && !xemu_debug_tools_av_sync_trace_mark(4));
 xemu_debug_tools_av_sync_trace_set_enabled(0);
 assert(!xemu_debug_tools_av_sync_trace_mark(1));
 assert(xemu_debug_tools_av_sync_trace_markers_snapshot(markers,64,&total)==64);
 xemu_debug_tools_av_sync_trace_clear();
 assert(!xemu_debug_tools_av_sync_trace_markers_snapshot(markers,64,&total) && !total);
 puts("PASS: actual A/V user markers: bounded 64-ring, kinds/timestamps/counters, stop/clear; no audio/VBlank baseline or cadence mutation");
 return 0;
}
'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--compiler',default='gcc');ap.add_argument('--sanitize',action='store_true');a=ap.parse_args()
    root=pathlib.Path(a.root);t=root/'ui/xui/debug-tools/tests';fixtures=load(t/'v314z-pfifo-draw-aggregate-native.py')
    with tempfile.TemporaryDirectory(prefix='xemu-vertex-coverage-') as td:
        tmp=pathlib.Path(td)
        for name,content in fixtures.STUBS.items():
            p=tmp/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
        thread=tmp/'qemu/thread.h';thread.write_text(thread.read_text()+r'''
#include <pthread.h>
typedef pthread_mutex_t QemuMutex;
static inline void qemu_mutex_init(QemuMutex *m){assert(!pthread_mutex_init(m,NULL));}
static inline void qemu_mutex_lock(QemuMutex *m){assert(!pthread_mutex_lock(m));}
static inline void qemu_mutex_unlock(QemuMutex *m){assert(!pthread_mutex_unlock(m));}
''')
        apu=tmp/'hw/xbox/mcpx/apu/apu_int.h';apu.parent.mkdir(parents=True,exist_ok=True);apu.write_text('''#pragma once
typedef struct MCPXAPUState {struct {void *stream;} monitor;} MCPXAPUState;
static inline int SDL_GetAudioStreamQueued(void *stream){(void)stream;return 4096;}
''')
        draw=(root/'hw/xbox/nv2a/pgraph/vk/draw.c').read_text();vertex=(root/'hw/xbox/nv2a/pgraph/vk/vertex.c').read_text()
        v=VERTEX_SUPPORT+function(draw,'static int compare_memory_sync_requirement_by_addr(')+'\n'
        v+=FROZEN_VERTEX.replace('pgraph_vk_update_vertex_ram_buffer(', 'baseline_update_vertex_ram_buffer(')+'\n'
        v+=FROZEN_SYNC.replace('sync_vertex_ram_buffer(', 'baseline_sync_vertex_ram_buffer(').replace('pgraph_vk_update_vertex_ram_buffer(', 'baseline_update_vertex_ram_buffer(')+'\n'
        v+=function(vertex,'void pgraph_vk_update_vertex_ram_buffer(')+'\n'+function(draw,'static void sync_vertex_ram_buffer(')+'\n'+VERTEX_MAIN
        for name,src in [('coverage',COVERAGE),('vertex',v),('markers',MARKERS)]:
            p=tmp/(name+'.c');p.write_text(src);exe=tmp/name
            flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-g'] if a.sanitize else []
            subprocess.run([a.compiler,'-x','c','-std=gnu11','-O2','-Wall','-Wextra','-Werror',*flags,'-I',str(tmp),'-I',str(root),str(p),'-pthread','-o',str(exe)],check=True)
            subprocess.run([str(exe)],check=True)
if __name__=='__main__':main()
