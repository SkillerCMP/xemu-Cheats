#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v2.94-v3.01 DEBUG output + QEMU timer/main-loop/BQL/MMIO/PGRAPH lock/draw trace guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    diag = debug / "addons/diagnostics"

    output_h = (debug / "debug-output-paths.hh").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-dump.cc").read_text(encoding="utf-8")
    dump_ui = (debug / "addons/memory-tools/memory-tools-dump-ui.cc").read_text(encoding="utf-8")
    trace = (debug / "addons/memory-tools/execution-trace.cc").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    hh = (diag / "diagnostics.hh").read_text(encoding="utf-8")
    backend_h = (diag / "diagnostics-backend.h").read_text(encoding="utf-8")
    backend = (diag / "diagnostics-backend.c").read_text(encoding="utf-8")
    qhook = (diag / "qemu-timer-trace-hook.h").read_text(encoding="utf-8")
    qtrace_h = (diag / "qemu-timer-trace.h").read_text(encoding="utf-8")
    qtrace = (diag / "qemu-timer-trace.c").read_text(encoding="utf-8")
    qstub = (debug / "addons/stubs/qemu-timer-trace-stub.c").read_text(encoding="utf-8")
    bql_hook = (diag / "bql-trace-hook.h").read_text(encoding="utf-8")
    bql_h = (diag / "bql-trace.h").read_text(encoding="utf-8")
    bql = (diag / "bql-trace.c").read_text(encoding="utf-8")
    lock_common_h = (diag / "lock-trace-common.h").read_text(encoding="utf-8")
    lock_common = (diag / "lock-trace-common.c").read_text(encoding="utf-8")
    bql_stub = (debug / "addons/stubs/bql-trace-stub.c").read_text(encoding="utf-8")
    mmio_hook = (diag / "mmio-trace-hook.h").read_text(encoding="utf-8")
    mmio_h = (diag / "mmio-trace.h").read_text(encoding="utf-8")
    mmio = (diag / "mmio-trace.c").read_text(encoding="utf-8")
    mmio_stub = (debug / "addons/stubs/mmio-trace-stub.c").read_text(encoding="utf-8")
    pgraph_lock_hook = (diag / "pgraph-lock-trace-hook.h").read_text(encoding="utf-8")
    pgraph_lock_h = (diag / "pgraph-lock-trace.h").read_text(encoding="utf-8")
    pgraph_lock = (diag / "pgraph-lock-trace.c").read_text(encoding="utf-8")
    pgraph_lock_stub = (debug / "addons/stubs/pgraph-lock-trace-stub.c").read_text(encoding="utf-8")
    pgraph_draw_hook = (diag / "pgraph-draw-trace-hook.h").read_text(encoding="utf-8")
    pgraph_draw_h = (diag / "pgraph-draw-trace.h").read_text(encoding="utf-8")
    pgraph_draw = (diag / "pgraph-draw-trace.c").read_text(encoding="utf-8")
    pgraph_draw_stub = (debug / "addons/stubs/pgraph-draw-trace-stub.c").read_text(encoding="utf-8")
    cputlb = (root / "accel/tcg/cputlb.c").read_text(encoding="utf-8")
    pgraph_h = (root / "hw/xbox/nv2a/pgraph/pgraph.h").read_text(encoding="utf-8")
    pgraph_c = (root / "hw/xbox/nv2a/pgraph/pgraph.c").read_text(encoding="utf-8")
    pgraph_gl_draw = (root / "hw/xbox/nv2a/pgraph/gl/draw.c").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    ptimer = (root / "hw/xbox/nv2a/ptimer.c").read_text(encoding="utf-8")
    timer = (root / "util/qemu-timer.c").read_text(encoding="utf-8")
    main_loop = (root / "util/main-loop.c").read_text(encoding="utf-8")
    cpus = (root / "system/cpus.c").read_text(encoding="utf-8")

    # All generated debug artifacts share one root beside xemu.exe.
    for token in ('"DEBUG"', '"Ram-Dumps"', '"Trace-Dumps"', '"Snapshots"'):
        require(output_h, token, "shared DEBUG output path")
    require(dump, "XemuDebugOutput::Folder::RamDumps", "RAM dump shared path")
    require(trace, "XemuDebugOutput::Folder::TraceDumps", "execution trace shared path")
    require(dump_ui, r"\\DEBUG\\Ram-Dumps", "RAM Dump fallback UI path")
    forbid(dump, 'g_build_filename(executable_dir, "Ram-Dumps"', "legacy RAM dump root")
    forbid(trace, 'g_build_filename(executable_dir, "Trace-Dumps"', "legacy trace dump root")

    # Diagnostics manual/live snapshots share DEBUG/Snapshots. Manual save is
    # one click and no longer opens a save dialog; live always overwrites one file.
    require(ui, "XemuDebugOutput::Folder::Snapshots", "snapshot shared path")
    require(ui, '"XEMU-Diagnostics-Live.txt"', "single rolling live snapshot")
    require(ui, 'stem += "-Diagnostics-";', "timestamped manual snapshot stem")
    require(ui, "XemuDebugOutput::UniqueFilePath", "unique manual snapshot path")
    forbid(ui, "ShowSaveFileDialog", "manual Diagnostics save dialog")
    require(ui, 'ImGui::Button("Open Snapshots Folder")', "snapshot-folder shortcut")

    # View menu controls export only; capture controls remain separate.
    require(ui, 'ImGui::BeginMenu("View")', "Diagnostics View menu")
    for token in (
        '"CPU / Timing"', '"NV2A / PTIMER"',
        '"PTIMER Detailed Timing Trace"', '"QEMU Timer Dispatch Trace"',
        '"BQL Ownership Trace"', '"MMIO Dispatch Trace"',
        '"PGRAPH Lock Ownership Trace"', '"PGRAPH Draw-End Stage Trace"',
        '"Audio"', '"Custom Watches"', '"Recent Events"'):
        require(ui, token, "View export option")
    for member in (
        "m_export_cpu_timing", "m_export_nv2a_ptimer", "m_export_ptimer_trace",
        "m_export_qemu_timer_trace", "m_export_bql_trace", "m_export_mmio_trace",
        "m_export_pgraph_lock_trace", "m_export_pgraph_draw_trace", "m_export_audio",
        "m_export_watches", "m_export_history"):
        require(hh, member, "export section state")

    # QEMU timer trace implementation/state remains physically inside Diagnostics.
    for name in ("qemu-timer-trace-hook.h", "qemu-timer-trace.h", "qemu-timer-trace.c"):
        if not (diag / name).is_file():
            raise AssertionError(f"missing Diagnostics QEMU timer trace file: {name}")
    require(qtrace_h, "XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY 16384", "QEMU timer trace ring")
    require(qtrace, "QemuMutex lock", "Diagnostics-owned timer trace lock")
    require(qtrace, "QTIMER_MAINLOOP_WINDOW_NS", "near-deadline main-loop filter")
    require(qtrace, "wait_elapsed_host_ns", "host wait elapsed capture")
    require(qtrace, "wait_elapsed_virtual_ns", "virtual wait elapsed capture")
    require(qtrace, "timeout_ns != 0", "non-blocking main-loop wait suppression")
    require(qtrace, "run_timers_relevant", "paired run-timers exit retention")
    require(qtrace, "dispatch_late_ns", "timer dispatch lateness capture")
    require(qtrace, "watched_timer", "PTIMER-only timer filtering")
    require(qstub, "xemu_debug_tools_qemu_timer_trace_watch", "non-full profile no-op watch")
    forbid(qhook, "QemuMutex", "trace state in core hook contract")
    forbid(qhook, "events[", "ring storage in core hook contract")

    require(meson, "addons/diagnostics/qemu-timer-trace.c", "full-profile QEMU timer trace source")
    require(meson, "addons/stubs/qemu-timer-trace-stub.c", "non-full QEMU timer trace stub")
    for name in ("bql-trace-hook.h", "bql-trace.h", "bql-trace.c", "mmio-trace-hook.h", "mmio-trace.h", "mmio-trace.c"):
        if not (diag / name).is_file():
            raise AssertionError(f"missing Diagnostics BQL trace file: {name}")
    if not (debug / "addons/stubs/bql-trace-stub.c").is_file():
        raise AssertionError("missing non-full BQL trace stub")
    require(meson, "addons/diagnostics/bql-trace.c", "full-profile BQL ownership trace source")
    require(meson, "addons/stubs/bql-trace-stub.c", "non-full BQL ownership trace stub")
    require(meson, "addons/diagnostics/mmio-trace.c", "full-profile MMIO dispatch trace source")
    require(meson, "addons/stubs/mmio-trace-stub.c", "non-full MMIO dispatch trace stub")
    require(meson, "addons/diagnostics/pgraph-lock-trace.c", "full-profile PGRAPH lock trace source")
    require(meson, "addons/stubs/pgraph-lock-trace-stub.c", "non-full PGRAPH lock trace stub")
    require(meson, "addons/diagnostics/pgraph-draw-trace.c", "full-profile PGRAPH draw trace source")
    require(meson, "addons/stubs/pgraph-draw-trace-stub.c", "non-full PGRAPH draw trace stub")
    require(bql_h, "XEMU_DEBUG_TOOLS_BQL_TRACE_CAPACITY XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY", "BQL trace ring alias")
    require(lock_common_h, "XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY 4096", "BQL trace ring")
    require(bql_h, "XEMU_DEBUG_TOOLS_BQL_TRACE_LONG_NS", "BQL long wait/hold threshold")
    require(lock_common, "qatomic_fetch_inc(&trace->total_events)", "lock-free BQL trace sequence")
    require(lock_common, "committed_sequence_plus_one", "lock-free BQL ring commit marker")
    require(lock_common, "owner_thread_id", "BQL owner tracking")
    require(lock_common, "owner_caller_file", "BQL owner callsite tracking")
    require(lock_common, "owner_guest_pc_start", "BQL owner guest-PC tracking")
    forbid(bql_hook, "QemuMutex", "BQL trace mutex/state in core hook contract")
    forbid(bql_hook, "events[", "BQL ring storage in core hook contract")
    require(bql_stub, "xemu_debug_tools_bql_trace_lock_attempt", "non-full BQL hook stub")
    require(backend_h, "XemuDiagnosticsQemuTimerTraceEvent", "frontend timer trace ABI")
    require(backend, "xemu_debug_tools_qemu_timer_trace_snapshot", "backend timer trace bridge")
    require(ui, '"Record PTIMER QEMU dispatch"', "QEMU timer recorder UI")
    require(ui, '"QEMU Timer Dispatch Trace\\n', "QEMU timer snapshot section")

    # Core files contain only reviewed observation hooks; no ring/filter/UI state.
    require(ptimer, "qemu-timer-trace-hook.h", "PTIMER timer-watch hook include")
    require(ptimer, "xemu_debug_tools_qemu_timer_trace_watch(&d->ptimer.timer)", "PTIMER timer watch registration")
    require(timer, "xemu_debug_tools_qemu_timer_hook_install", "generic timer observer installation hook")
    require(timer, "XEMU_DEBUG_TOOLS_QTIMER_TIMER_MOD", "timer-mod observation")
    require(timer, "XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_BEGIN", "dispatch begin observation")
    require(timer, "XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_END", "dispatch end observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_ENTER", "main-loop wait-enter observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_EXIT", "main-loop wait-exit observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_ENTER", "run-timers enter observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_EXIT", "run-timers exit observation")
    for core_text, label in ((ptimer, "ptimer.c"), (timer, "qemu-timer.c"), (main_loop, "main-loop.c")):
        for token in ("XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY", "overwritten_events", "wait_elapsed_host_ns"):
            forbid(core_text, token, f"Diagnostics trace implementation in {label}")


    # Main-Loop Wait Stage Trace splits the previously opaque os_host_main_loop_wait interval into
    # internal observation-only stages and tags events with host thread IDs.
    for token in (
        "XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_GLIB_PREPARE_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_POLL_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_POLL_BUSYWAIT_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_POLL_BACKEND_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_MAIN_LOOP_LOCK_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_REPLAY_LOCK_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_BQL_LOCK_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_GLIB_CHECK_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_GLIB_DISPATCH_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_WAIT_OBJECTS_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_POLLING_CALLBACKS_ENTER",
        "XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_RELEASE_ENTER",
    ):
        require(qhook, token, "Main-Loop Wait Stage Trace event contract")
    require(qtrace_h, "thread_id", "QEMU timer trace thread correlation")
    require(qtrace, "qemu_get_thread_id()", "Diagnostics-owned thread tagging")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER",
            "GLib context acquire stage observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_POLL_ENTER",
            "outer qemu_poll stage observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_MAIN_LOOP_LOCK_ENTER",
            "Xemu main-loop-lock reacquire observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_REPLAY_LOCK_ENTER",
            "replay mutex reacquire observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_BQL_LOCK_ENTER",
            "BQL reacquire observation")
    require(main_loop, "XEMU_DEBUG_TOOLS_QTIMER_GLIB_DISPATCH_ENTER",
            "GLib dispatch observation")
    win_marker = '#else\n/***********************************************************/\n/* Polling handling */'
    if win_marker not in main_loop:
        raise AssertionError("could not locate Windows main-loop branch")
    win_main_loop = main_loop.split(win_marker, 1)[1]
    for token, label in (
        ("XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER", "Windows GLib acquire"),
        ("XEMU_DEBUG_TOOLS_QTIMER_GLIB_PREPARE_ENTER", "Windows GLib prepare"),
        ("XEMU_DEBUG_TOOLS_QTIMER_POLL_ENTER", "Windows outer qemu_poll"),
        ("XEMU_DEBUG_TOOLS_QTIMER_MAIN_LOOP_LOCK_ENTER", "Windows main-loop lock"),
        ("XEMU_DEBUG_TOOLS_QTIMER_REPLAY_LOCK_ENTER", "Windows replay lock"),
        ("XEMU_DEBUG_TOOLS_QTIMER_BQL_LOCK_ENTER", "Windows BQL lock"),
        ("XEMU_DEBUG_TOOLS_QTIMER_WAIT_OBJECTS_ENTER", "Windows wait-object callbacks"),
        ("XEMU_DEBUG_TOOLS_QTIMER_GLIB_CHECK_ENTER", "Windows GLib check"),
        ("XEMU_DEBUG_TOOLS_QTIMER_GLIB_DISPATCH_ENTER", "Windows GLib dispatch"),
        ("XEMU_DEBUG_TOOLS_QTIMER_POLLING_CALLBACKS_ENTER", "Windows polling callbacks"),
        ("XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_RELEASE_ENTER", "Windows GLib release"),
    ):
        require(win_main_loop, token, label)
    require(timer, "XEMU_DEBUG_TOOLS_QTIMER_POLL_BUSYWAIT_ENTER",
            "Xbox busy-wait substage observation")
    require(timer, "XEMU_DEBUG_TOOLS_QTIMER_POLL_BACKEND_ENTER",
            "poll backend substage observation")
    require(ui, "Late-wait stage host ns", "late-dispatch stage breakdown export")
    require(ui, "qemu_poll_ns Xbox busy-wait / host thread deschedule",
            "busy-wait/deschedule diagnosis")
    require(ui, "BQL reacquire", "BQL delay diagnosis")

    # v2.97 BQL Ownership Trace hooks the global BQL boundary but keeps all
    # owner/timing/ring implementation under Diagnostics.
    require(cpus, "bql-trace-hook.h", "BQL observation hook include")
    require(cpus, "xemu_debug_tools_bql_trace_lock_attempt(file, line);",
            "BQL acquire-attempt observation")
    require(cpus, "xemu_debug_tools_bql_trace_lock_acquired(file, line);",
            "BQL acquired observation")
    require(cpus, "xemu_debug_tools_bql_trace_unlock_begin();",
            "BQL release-begin observation")
    require(cpus, "xemu_debug_tools_bql_trace_unlock_end();",
            "BQL release-end observation")
    for token in ("XEMU_DEBUG_TOOLS_BQL_TRACE_CAPACITY", "owner_thread_id",
                  "committed_sequence_plus_one", "owner_guest_pc_start"):
        forbid(cpus, token, "BQL trace implementation in system/cpus.c")
    require(backend_h, "XemuDiagnosticsBqlTraceEvent", "frontend BQL trace ABI")
    require(backend, "xemu_debug_tools_bql_trace_snapshot", "backend BQL trace bridge")
    require(ui, '"Record BQL ownership"', "BQL recorder UI")
    require(ui, "xemu_diagnostics_bql_trace_set_enabled(1);",
            "QEMU dispatch auto-arms BQL ownership trace")
    require(ui, '"BQL Ownership Trace\\n', "BQL snapshot section")
    require(ui, "Worst BQL wait ns", "BQL wait analysis export")
    require(ui, "Blocking owner TID/CPU", "BQL blocking-owner analysis export")
    require(ui, "Owner acquisition callsite", "BQL owner callsite export")
    require(ui, "Longest BQL hold overlapping worst wait ns",
            "BQL wait/holder overlap analysis export")
    require(ui, "XEMU Diagnostics Snapshot v3.09", "v3.09 snapshot version")

    # v2.98 MMIO Dispatch Trace identifies the actual long device access that
    # overlaps the BQL hold without moving trace state into the TCG core.
    require(cputlb, "mmio-trace-hook.h", "MMIO observation include")
    if cputlb.count("xemu_debug_tools_mmio_trace_begin(") != 4:
        raise AssertionError("expected exactly four TCG MMIO begin observations")
    if cputlb.count("xemu_debug_tools_mmio_trace_end(&mmio_trace_scope);") != 4:
        raise AssertionError("expected exactly four TCG MMIO end observations")
    require(mmio_h, "XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY 4096", "MMIO ring capacity")
    require(mmio_h, "XEMU_DEBUG_TOOLS_MMIO_TRACE_LONG_NS", "MMIO long threshold")
    require(mmio, "memory_region_name(mr)", "MMIO MemoryRegion naming")
    require(mmio, "object_get_typename(OBJECT(mr->owner))", "MMIO owner-type naming")
    require(mmio, "committed_sequence_plus_one", "lock-free MMIO ring")
    require(mmio_stub, "xemu_debug_tools_mmio_trace_begin", "non-full MMIO stub")
    require(backend_h, "XemuDiagnosticsMmioTraceEvent", "frontend MMIO trace ABI")
    require(backend, "xemu_debug_tools_mmio_trace_snapshot", "backend MMIO trace bridge")
    require(ui, '"Record long MMIO dispatches"', "MMIO recorder UI")
    require(ui, '"MMIO Dispatch Trace\\n', "MMIO snapshot section")
    require(ui, "Worst MMIO MemoryRegion", "MMIO region analysis")
    require(ui, "Worst MMIO owner type", "MMIO owner analysis")
    require(ui, "xemu_diagnostics_mmio_trace_set_enabled(1);", "QEMU dispatch auto-arms MMIO")

    # v2.99 PGRAPH Lock Ownership Trace narrows the long PGRAPH MMIO dispatch
    # to the actual d->pgraph.lock owner and PFIFO method context.
    require(pgraph_h, "pgraph-lock-trace-hook.h", "PGRAPH lock hook include")
    require(pgraph_h, "PGRAPH_LOCK(pg)", "PGRAPH observed lock wrapper")
    require(pgraph_h, "PGRAPH_UNLOCK(pg)", "PGRAPH observed unlock wrapper")
    require(pgraph_c, "xemu_debug_tools_pgraph_lock_trace_method_enter",
            "PGRAPH method context observation")
    require(pgraph_lock_h, "XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY 4096",
            "PGRAPH lock ring capacity")
    require(pgraph_lock_h, "XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS",
            "PGRAPH lock long threshold")
    require(pgraph_lock, "committed_sequence_plus_one",
            "lock-free PGRAPH lock ring")
    require(pgraph_lock, "owner_method_graphics_class",
            "PGRAPH owner method/class context")
    require(pgraph_lock_stub, "xemu_debug_tools_pgraph_lock_trace_lock_attempt",
            "non-full PGRAPH lock stub")
    forbid(pgraph_lock_hook, "QemuMutex",
           "PGRAPH lock state in hook contract")
    require(backend_h, "XemuDiagnosticsPgraphLockTraceEvent",
            "frontend PGRAPH lock trace ABI")
    require(backend, "xemu_debug_tools_pgraph_lock_trace_snapshot",
            "backend PGRAPH lock trace bridge")
    require(ui, '"Record PGRAPH lock ownership"', "PGRAPH lock recorder UI")
    require(ui, '"PGRAPH Lock Ownership Trace', "PGRAPH lock snapshot section")
    require(ui, "Worst PGRAPH lock hold ns", "PGRAPH lock hold analysis")
    require(ui, "Owner method at wait attempt", "PGRAPH owner method analysis")
    require(ui, "xemu_diagnostics_pgraph_lock_trace_set_enabled(1);",
            "QEMU dispatch auto-arms PGRAPH lock trace")

    # v3.00 PGRAPH Draw-End Stage Trace isolates expensive
    # NV097_SET_BEGIN_END(END) work below the PGRAPH lock owner.
    require(pgraph_c, "pgraph-draw-trace-hook.h", "PGRAPH draw hook include")
    require(pgraph_gl_draw, "pgraph-draw-trace-hook.h",
            "OpenGL draw stage hook include")
    require(pgraph_draw_h, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY 4096",
            "PGRAPH draw ring capacity")
    require(pgraph_draw_h, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS",
            "PGRAPH draw long threshold")
    require(pgraph_draw, "PGRAPH_DRAW_TRACE_TLS_EVENTS",
            "PGRAPH per-draw TLS buffer")
    require(pgraph_draw, "committed_sequence_plus_one",
            "lock-free PGRAPH draw ring")
    require(pgraph_draw, "total_ns >= XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS",
            "long-draw-only commit filter")
    require(pgraph_draw_stub, "xemu_debug_tools_pgraph_draw_trace_stage_begin",
            "non-full PGRAPH draw stub")
    forbid(pgraph_draw_hook, "QemuMutex", "PGRAPH draw state in hook contract")
    require(backend_h, "XemuDiagnosticsPgraphDrawTraceEvent",
            "frontend PGRAPH draw trace ABI")
    require(backend, "xemu_debug_tools_pgraph_draw_trace_snapshot",
            "backend PGRAPH draw trace bridge")
    require(ui, '"Record long PGRAPH draw-end stages"',
            "PGRAPH draw recorder UI")
    require(ui, '"PGRAPH Draw-End Stage Trace\\n',
            "PGRAPH draw snapshot section")
    require(ui, "Worst draw stage breakdown",
            "PGRAPH draw breakdown analysis")
    require(ui, "xemu_diagnostics_pgraph_draw_trace_set_enabled(1);",
            "QEMU dispatch auto-arms PGRAPH draw trace")

    # Official master now owns the no-storm PTIMER epoch behavior; Diagnostics
    # must preserve that 64-bit register-time implementation.
    require(ptimer,
            "d->ptimer.alarm_time = advance_alarm_epoch(d->ptimer.alarm_time);",
            "official PTIMER next-epoch fix")
    require(ptimer,
            "return (reg_time + (1ULL << 32)) & PTIMER_REG_TIME_MASK;",
            "official PTIMER next-epoch wrap")

    print("PASS: v2.94-v3.04 DEBUG output + Diagnostics Main-Loop Wait Stage/BQL/MMIO/PGRAPH Lock/Draw/OHCI/Input Poll Trace invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
