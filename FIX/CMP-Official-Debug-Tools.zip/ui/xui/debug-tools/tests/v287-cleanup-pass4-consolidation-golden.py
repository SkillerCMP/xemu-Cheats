#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 4: behavior-neutral consolidation/dead-code guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    trace = (debug / "addons/memory-tools/execution-trace.cc").read_text(encoding="utf-8")
    asm = (debug / "x86-cheat-assembler.cc").read_text(encoding="utf-8")
    asm_core = (debug / "x86-cheat-assembler-keystone.cc").read_text(encoding="utf-8")
    current = (debug / "current-game.cc").read_text(encoding="utf-8")
    binary = (debug / "binary-utils.hh").read_text(encoding="utf-8")
    xdk = (debug / "xdk-labels.cc").read_text(encoding="utf-8")
    rpc = (debug / "addons/hdd/kernel-rpc-utils.hh").read_text(encoding="utf-8")
    export = (debug / "addons/hdd/hdd-export-service.cc").read_text(encoding="utf-8")
    snapshot = (debug / "addons/hdd/hdd-snapshot-service.cc").read_text(encoding="utf-8")

    # Proven dead helper must not return.
    forbid(trace, "TraceBytesForEvents", "dead execution-trace byte-count helper")

    # The two old generated-line implementations were identical; keep exactly one.
    forbid(asm, "emit_temp_generated", "duplicate F0 generated-line emitter")
    if asm.count("static void emit_generated(") != 1:
        raise AssertionError("F0 frontend must own exactly one generated-line emitter")
    require(asm, "out.push_back(XemuCheatAsmLine{source_line, text});",
            "generated-line emitter behavior")

    # real_reg32_code duplicated the already-exported reg32 helper exactly.
    forbid(asm, "real_reg32_code", "duplicate 32-bit register parser")
    require(asm, "reg32(op)", "shared reg32 scratch-register scan")
    require(asm_core,
            "return parse_register(name, code, width) && width == 32 ? code : -1;",
            "authoritative reg32 implementation")

    # MAP/PDB keep their original byte limits and destination types but go directly
    # through the one shared bounded complete-file reader.
    for wrapper in ("read_local_binary_file", "read_local_text_file"):
        forbid(current, wrapper, "retired Current Game local-file forwarding wrapper")
    if current.count("static bool read_local_file(") != 1:
        raise AssertionError("Current Game must own exactly one shared local-file reader")
    require(current, "read_local_file(path, 64ull * 1024ull * 1024ull,",
            "64 MiB MAP import limit")
    require(current, "read_local_file(path, 512ull * 1024ull * 1024ull,",
            "512 MiB PDB import limit")
    require(current, "std::fread(out.data(), 1, out.size(), fp) == out.size();",
            "complete local-file read check")
    require(current, "const bool close_ok = std::fclose(fp) == 0;",
            "local-file close result check")

    # One authoritative LE64 decoder now backs both call paths.
    require(binary, "inline uint64_t read_le64(const uint8_t *p)",
            "shared LE64 helper")
    require(binary,
            "return (uint64_t)read_le32(p) | ((uint64_t)read_le32(p + 4) << 32);",
            "shared LE64 arithmetic")
    forbid(xdk, "static uint64_t read_le64(", "local XDK-label LE64 duplicate")
    require(xdk, "using XemuDebugBinaryUtils::read_le64;", "XDK-label shared LE64 use")
    require(rpc, "result.end_of_file = XemuDebugBinaryUtils::read_le64(data + 40u);",
            "Kernel RPC shared LE64 use")

    # FATX services pass the authoritative read-only disc callback directly.
    for source, label in ((export, "HDD export"), (snapshot, "HDD snapshot")):
        forbid(source, "ReadHddBlock", f"duplicate {label} read adapter")
        require(source, "xemu_disc_block_pread", f"{label} direct block-read callback")
    require(export, "XemuFatxHdd::StreamFile(xemu_disc_block_pread, hdd, length, partition,",
            "HDD export direct stream callback")
    require(snapshot, "XemuFatxHdd::BuildSnapshot(xemu_disc_block_pread, hdd.Get(), length, snapshot);",
            "HDD snapshot direct callback")

    # The only script edits in this pass are trailing-space removal.
    for name in ("build-keystone.sh", "build-capstone.sh"):
        data = (debug / "tools" / name).read_text(encoding="utf-8")
        for lineno, line in enumerate(data.splitlines(), 1):
            if line.endswith((" ", "\t")):
                raise AssertionError(f"{name}:{lineno}: trailing whitespace returned")

    print("PASS: Cleanup Pass 4 behavior-neutral consolidation/dead-code invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
