#!/usr/bin/env python3
"""Current manifest-v3, effective-disc ownership and reset/read lifetime guard."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[4]);args=p.parse_args()
root=args.root;dt=root/'ui/xui/debug-tools';a=dt/'addons/file-replace'
manager=(a/'file-replace.cc').read_text();compiler=(a/'file-replace-compiler.cc').read_text();plan=(a/'file-replace-disc-overlay.cc').read_text();bridge=(a/'file-replace-block.c').read_text();atapi=(root/'hw/ide/atapi.c').read_text();ide=(root/'hw/ide/core.c').read_text();ui=(a/'file-replace-ui.cc').read_text();meson=(dt/'meson.build').read_text()
def need(text,token):
 if token not in text:raise SystemExit('FAIL missing '+token)
need(manager,'manifest_version != 3 && manifest_version != 4');need(manager,'Manifest v3 requires boolean size_change')
need(manager,'source_type == "file"');need(manager,'source_type == "disc_range"')
need(manager,'previous snapshot preserved');need(manager,'active->RequiresReset()')
need(manager,'owning manifest retained');need(manager,'xemu_disc_block_get_length(disc.Get()) !=')
need(compiler,'FindKnownSizeFixer');need(compiler,'CompileOverlay');need(compiler,'file.directory_entry + 4')
need(compiler,'vf.image.size');need(compiler,'Active File Replace ranges overlap')
need(plan,'std::atomic_load_explicit');need(plan,'plan->snapshot = snapshot');need(plan,'plan.release()')
need(bridge,'acb->plan = plan');need(bridge,'blk_inc_in_flight');need(bridge,'blk_dec_in_flight')
need(bridge,'qemu_iovec_from_buf');need(bridge,'xemu_file_replace_plan_release')
need(bridge,'acb->returned = true');need(bridge,'replay_bh_schedule_oneshot_event')
need(ui,'!active_snapshot->RequiresReset()');need(ui,'Resizable Range');need(ui,'Known File Size Fixer')
assert atapi.count('xemu_file_replace_pread(')==2
assert atapi.count('xemu_file_replace_disc_overlay_apply(')==0
need(ide,'xemu_file_replace_aio_preadv(');need(ide,'s->drive_kind == IDE_CD')
need(atapi,'xemu_file_replace_disc_sectors');need(atapi,'nb_sectors > INT32_MAX / 2352')
for name in ['file-replace-block.c','file-replace-image.cc','file-replace-compiler.cc','file-replace-olk.cc','known-size-fixers.cc']:need(meson,'addons/file-replace/'+name)
for name in ['xemu_file_replace_plan_create','xemu_file_replace_plan_release','xemu_file_replace_disc_sectors']:need((dt/'addons/stubs/file-replace-disc-overlay-stub.c').read_text(),name)
assert json.loads((a/'file-replace-v3.schema.json').read_text())['properties']['version']=={'const':3}
# All production implementation must be game-independent. Tests/docs/examples
# may identify their external fixtures; runtime implementation must not.
production='\n'.join(f.read_text() for pattern in ['*.c','*.cc','*.hh','*.h'] for f in a.glob(pattern))
for bad in ['NM0003','Soulcalibur','Heihachi','28B62000','root.olk','blk_pwrite(','std::ofstream']:
 assert bad not in production,bad
print('PASS: v3.16 manifest v3 compatibility, three modes, generic fixer ownership, atomic plans and reset safeguards')
