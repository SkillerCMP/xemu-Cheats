#include "../addons/game-library/game-library-menu-hook.h"

#include <cassert>
#include <cstring>

int main()
{
    assert(!xemu_debug_tools_game_library_menu_available());
    xemu_debug_tools_game_library_menu_prepare();
    assert(xemu_debug_tools_game_library_menu_count() == 0);
    char label[8] = "dirty";
    assert(!xemu_debug_tools_game_library_menu_get_label(0, label, sizeof(label)));
    assert(label[0] == '\0');
    assert(!xemu_debug_tools_game_library_menu_launch(0));
    assert(!xemu_debug_tools_game_library_menu_scanning());
    xemu_debug_tools_game_library_menu_open_full();
    xemu_debug_tools_game_library_menu_refresh();
    return 0;
}
