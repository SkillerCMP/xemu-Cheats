#!/usr/bin/env python3
# v3.14k Linux AppImage writable Debug Tools root regression.
"""Guard portable Debug Tools paths against the read-only AppImage mount."""
from __future__ import annotations

import argparse
import pathlib

from v287_source_test_utils import extract_function


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    memory = (debug / "cheat-engine-memory.c").read_text(encoding="utf-8")
    helper = extract_function(memory, "int xemu_cheat_get_executable_dir(")

    required = (
        "#if defined(__linux__)",
        'g_getenv("APPIMAGE")',
        "g_canonicalize_filename(appimage, NULL)",
        "g_path_get_dirname(absolute_appimage)",
        "if (path == NULL)",
        "get_relocated_path(CONFIG_BINDIR)",
    )
    for needle in required:
        if needle not in helper:
            raise AssertionError(f"v3.14k AppImage path invariant missing: {needle}")

    # The AppImage branch must precede the normal relocated CONFIG_BINDIR path;
    # otherwise /tmp/.mount_*/usr/bin remains the selected root.
    appimage_pos = helper.find('g_getenv("APPIMAGE")')
    relocated_pos = helper.find("get_relocated_path(CONFIG_BINDIR)")
    if appimage_pos < 0 or relocated_pos < 0 or appimage_pos > relocated_pos:
        raise AssertionError("APPIMAGE must be preferred before CONFIG_BINDIR on Linux")

    # Portable Debug Tools consumers should continue to derive their roots from
    # this shared helper instead of independently resolving /proc/self/exe.
    consumers = {
        "Cheats": debug / "cheat-engine-source.cc",
        "DEBUG outputs": debug / "debug-output-paths.hh",
        "Labels": debug / "current-game.cc",
        "File Replace": debug / "addons/file-replace/file-replace.cc",
    }
    for label, path in consumers.items():
        text = path.read_text(encoding="utf-8")
        if "xemu_cheat_get_executable_dir" not in text:
            raise AssertionError(f"{label} no longer uses the shared portable root helper")

    output_paths = (debug / "debug-output-paths.hh").read_text(encoding="utf-8")
    for folder in ('"DEBUG"', 'case Folder::RamDumps: return "Ram-Dumps";',
                   'case Folder::TraceDumps: return "Trace-Dumps";',
                   'case Folder::Snapshots: return "Snapshots";'):
        if folder not in output_paths:
            raise AssertionError(f"Debug output path contract changed unexpectedly: {folder}")

    # Existing addon-specific portable paths already use APPIMAGE. Keep those
    # behaviors intact while centralizing the remaining Debug Tools paths.
    folder_hdd = (debug / "addons/Folder-HDD/folder-hdd.c").read_text(encoding="utf-8")
    video = (debug / "addons/Video-Recorder/video-recorder.cc").read_text(encoding="utf-8")
    if 'g_getenv("APPIMAGE")' not in folder_hdd:
        raise AssertionError("Folder-HDD AppImage root handling regressed")
    if 'g_getenv("APPIMAGE")' not in video:
        raise AssertionError("Video Recorder AppImage root handling regressed")

    print("PASS: v3.14k Linux AppImage paths use the writable real AppImage directory")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
