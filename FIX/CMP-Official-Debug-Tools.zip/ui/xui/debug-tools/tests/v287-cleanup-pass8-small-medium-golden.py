#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 8 small/medium behavior-neutral consolidation guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    tests = debug / "tests"

    output = (debug / "debug-output-paths.hh").read_text(encoding="utf-8")
    internal = (debug / "addons/memory-tools/memory-tools-internal.hh").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-dump.cc").read_text(encoding="utf-8")

    require(output, 'Timestamp(const char *fallback = "unknown-time")',
            "shared timestamp fallback parameter")
    require(output, 'fallback ? fallback : "unknown-time"',
            "null-safe timestamp fallback")
    forbid(internal, "make_dump_timestamp", "duplicate Memory Tools timestamp helper")
    forbid(internal, "#include <glib.h>", "timestamp-only Memory Tools GLib include")
    require(dump, 'XemuDebugOutput::Timestamp("00000000-000000")',
            "Memory Tools historical timestamp failure fallback")

    shared_result = (debug / "host-export-result.hh").read_text(encoding="utf-8")
    xdvdfs = (debug / "xdvdfs-export-service.hh").read_text(encoding="utf-8")
    hdd = (debug / "addons/hdd/hdd-export-service.hh").read_text(encoding="utf-8")
    for token in (
        "std::string host_path;",
        "uint64_t byte_count = 0;",
        "uint32_t file_count = 0;",
        "uint32_t directory_count = 0;",
        "bool directory = false;",
    ):
        require(shared_result, token, "shared host export result field")
    require(xdvdfs, "using Result = XemuHostExport::Result;",
            "XDVDFS export result alias")
    require(hdd, "using Result = XemuHostExport::Result;",
            "FATX export result alias")
    forbid(xdvdfs, "struct Result {", "duplicate XDVDFS export Result")
    forbid(hdd, "struct Result {", "duplicate FATX export Result")

    cheat_memory = (debug / "cheat-engine-memory.c").read_text(encoding="utf-8")
    require(cheat_memory,
            "/* Info: Page decoding may start between x86 instructions; reject",
            "present-tense disassembly synchronization note")
    forbid(cheat_memory, "previous path did", "stale path-history wording")

    # Historical whole-file fingerprint normalizers were retired with the
    # obsolete snapshot tests; this guard now protects production cleanup only.

    # Production comment convention retained from Cleanup Pass 1.
    production_suffixes = {".c", ".cc", ".cpp", ".h", ".hh", ".hpp"}
    for path in debug.rglob("*"):
        if not path.is_file() or "tests" in path.parts or path.suffix not in production_suffixes:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if "/* Note:" in text or "// Note:" in text:
            raise AssertionError(f"noncanonical Note comment returned: {path.relative_to(debug)}")

    print("PASS: Cleanup Pass 8 consolidates only small/medium behavior-neutral helpers and notes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
