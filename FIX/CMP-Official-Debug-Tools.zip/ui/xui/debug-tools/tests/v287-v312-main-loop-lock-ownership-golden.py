#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.12 qemu_main_loop_lock ownership/latency tracking integration guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = Path(args.root)
    dt = root / "ui/xui/debug-tools"
    diag = dt / "addons/diagnostics"

    required_files = (
        diag / "main-loop-lock-trace-hook.h",
        diag / "main-loop-lock-trace.h",
        diag / "main-loop-lock-trace.c",
        diag / "lock-trace-common.h",
        diag / "lock-trace-common.c",
        dt / "addons/stubs/main-loop-lock-trace-stub.c",
    )
    for path in required_files:
        if not path.is_file():
            raise AssertionError(f"missing main-loop lock tracking file: {path.relative_to(root)}")

    meson = (dt / "meson.build").read_text(encoding="utf-8")
    backend_h = (diag / "diagnostics-backend.h").read_text(encoding="utf-8")
    backend_c = (diag / "diagnostics-backend.c").read_text(encoding="utf-8")
    trace_h = (diag / "main-loop-lock-trace.h").read_text(encoding="utf-8")
    trace_c = (diag / "main-loop-lock-trace.c").read_text(encoding="utf-8")
    common_h = (diag / "lock-trace-common.h").read_text(encoding="utf-8")
    common_c = (diag / "lock-trace-common.c").read_text(encoding="utf-8")
    bql_c = (diag / "bql-trace.c").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    main_loop_h = (root / "include/qemu/main-loop.h").read_text(encoding="utf-8")
    main_loop_c = (root / "util/main-loop.c").read_text(encoding="utf-8")

    require(meson, "'addons/diagnostics/lock-trace-common.c',",
            "Full-profile shared lock recorder core")
    require(meson, "'addons/diagnostics/main-loop-lock-trace.c',",
            "Full-profile main-loop lock recorder facade")
    require(meson, "'addons/stubs/main-loop-lock-trace-stub.c',",
            "non-Full main-loop lock stub")

    # Preserve every pre-existing buffer ID by appending this recorder at the end.
    require(backend_h,
            "XEMU_DIAG_BUFFER_CONTROLLER_XID,\n    XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK,\n    XEMU_DIAG_BUFFER_COUNT,",
            "append-only diagnostics buffer ID")
    require(backend_c, "XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_CAPACITY",
            "buffer capacity bridge")

    # Caller file/line must be captured at each qemu_mutex_lock_main_loop() callsite,
    # while the underlying lock/unlock operation and ordering stay unchanged.
    require(main_loop_h,
            "#define qemu_mutex_lock_main_loop() \\\n    qemu_mutex_lock_main_loop_impl(__FILE__, __LINE__)",
            "source callsite capture macro")
    require(main_loop_c,
            "xemu_debug_tools_main_loop_lock_trace_lock_attempt(file, line);\n    qemu_mutex_lock(&qemu_main_loop_lock);\n    xemu_debug_tools_main_loop_lock_trace_lock_acquired(file, line);",
            "lock attempt/acquire instrumentation order")
    require(main_loop_c,
            "xemu_debug_tools_main_loop_lock_trace_unlock_begin();\n    qemu_mutex_unlock(&qemu_main_loop_lock);\n    xemu_debug_tools_main_loop_lock_trace_unlock_end();",
            "unlock instrumentation order")
    if main_loop_c.count("qemu_mutex_lock(&qemu_main_loop_lock);") != 1:
        raise AssertionError("central main-loop mutex must still have exactly one raw lock site")
    if main_loop_c.count("qemu_mutex_unlock(&qemu_main_loop_lock);") != 1:
        raise AssertionError("central main-loop mutex must still have exactly one raw unlock site")

    # Pass 11 centralizes the recorder mechanics without changing the established
    # 1 ms retention threshold, ownership fields, or main-loop disabled fast path.
    require(trace_h,
            "XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_LONG_NS \\\n    XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS",
            "main-loop threshold alias")
    require(common_h, "XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS (1000 * 1000LL)",
            "1 ms retention threshold")
    for field in ("owner_thread_id", "owner_held_at_attempt_ns",
                  "owner_caller_file", "owner_context",
                  "owner_stage_at_attempt", "guest_pc_start"):
        require(common_h, field, f"main-loop ownership field {field}")
    require(common_c, "XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_WAIT",
            "long-wait recording")
    require(common_c, "XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_HOLD",
            "long-hold recording")
    require(common_c,
            ".observe_acquire_when_disabled = 0,",
            "main-loop disabled acquire policy")
    acquired = common_c[common_c.index("void xemu_debug_tools_lock_trace_core_lock_acquired"):
                        common_c.index("void xemu_debug_tools_lock_trace_core_unlock_begin")]
    if acquired.index("!policy->observe_acquire_when_disabled") > acquired.index("qemu_clock_get_ns(QEMU_CLOCK_HOST)"):
        raise AssertionError("disabled main-loop acquire path must return before reading host clock")
    require(trace_c,
            "XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, file, line);",
            "main-loop acquire facade forwarding")

    # Reuse the established UI/BQL labels without consuming the BQL TLS context.
    require(bql_c, "xemu_debug_tools_main_loop_lock_trace_set_next_context(context);",
            "main-loop context propagation")
    require(bql_c, "xemu_debug_tools_main_loop_lock_trace_owner_stage_begin(stage);",
            "main-loop stage begin propagation")
    require(bql_c, "xemu_debug_tools_main_loop_lock_trace_owner_stage_end();",
            "main-loop stage end propagation")

    # QEMU timer flight recording should automatically arm the new companion.
    require(ui, "xemu_diagnostics_main_loop_lock_trace_set_enabled(1);",
            "QEMU timer auto-arm")
    require(ui, "QEMU Main Loop Lock Ownership Trace",
            "live/snapshot section")
    require(ui, "Worst qemu_main_loop_lock wait ns:",
            "snapshot worst-wait analysis")
    require(ui, "Blocking owner context:",
            "snapshot owner context")
    require(ui, "Owner acquisition callsite:",
            "snapshot owner callsite")

    # This feature is observer-only: no trylock, timeout, forced unlock, sleep,
    # yield, or lock bypass may be introduced into the central wrapper.
    wrapper = main_loop_c[main_loop_c.index("void qemu_mutex_lock_main_loop_impl"):
                          main_loop_c.index("#endif", main_loop_c.index("void qemu_mutex_lock_main_loop_impl"))]
    for forbidden in ("trylock", "SDL_Delay", "g_usleep", "qemu_thread_yield",
                      "timedlock", "force", "bypass"):
        forbid(wrapper, forbidden, f"behavior-changing wrapper token {forbidden}")

    print("PASS: v3.12 qemu_main_loop_lock ownership tracking is centralized and observation-only")


if __name__ == "__main__":
    main()
