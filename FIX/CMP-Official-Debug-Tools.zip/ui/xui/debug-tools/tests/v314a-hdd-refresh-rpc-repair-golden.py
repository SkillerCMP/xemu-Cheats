#!/usr/bin/env python3
"""v3.14a HDD refresh/RPC repair ownership and safety guard."""
from __future__ import annotations
import argparse
import pathlib
import re


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    d = root / "ui/xui/debug-tools"
    hdd_cc = (d / "addons/hdd/hdd-directory.cc").read_text(encoding="utf-8")
    hdd_hh = (d / "addons/hdd/hdd-directory.hh").read_text(encoding="utf-8")
    hdd_ui = (d / "addons/hdd/hdd-directory-ui.cc").read_text(encoding="utf-8")
    svc = (d / "addons/hdd/hdd-snapshot-service.cc").read_text(encoding="utf-8")
    svc_h = (d / "addons/hdd/hdd-snapshot-service.hh").read_text(encoding="utf-8")
    rpc = (d / "addons/hdd/guest-kernel-rpc.cc").read_text(encoding="utf-8")
    pause_h = (d / "guest-pause-guard.hh").read_text(encoding="utf-8")
    folder_c = (d / "addons/Folder-HDD/folder-hdd.c").read_text(encoding="utf-8")
    folder_sync = (d / "addons/Folder-HDD/folder-hdd-sync.cc").read_text(encoding="utf-8")
    folder_h = (d / "addons/Folder-HDD/folder-hdd.h").read_text(encoding="utf-8")

    # Failed display refreshes must keep the previous snapshot and latch the
    # failure instead of automatically retrying from each visible frame.
    require(hdd_hh, "bool m_refresh_failed_latched = false;", "refresh failure latch")
    require(hdd_cc, "XemuFatxHdd::Snapshot next_snapshot;", "temporary display snapshot")
    require(hdd_cc, "m_snapshot = std::move(next_snapshot);", "commit-on-success snapshot swap")
    require(hdd_cc, "m_refresh_failed_latched = true;", "failure latch set")
    require(hdd_cc,
            "guest_kernel_rpc_manager.OperationBusy() || m_refresh_failed_latched",
            "automatic retry suppression")
    if "m_has_snapshot =\n        hdd_snapshot_service.BuildDisplaySnapshot" in hdd_cc:
        raise AssertionError("failed refresh still destroys last-good snapshot")
    if hdd_ui.count("m_refresh_failed_latched = false;") < 2:
        raise AssertionError("both explicit REFRESH buttons must re-arm one retry")
    require(hdd_ui, "Showing the last successful HDD snapshot.", "stale display status")

    # Counter semantics distinguish attempts from actual successful captures.
    for token in ("display_successes", "display_failures"):
        require(svc_h, token, f"display counter {token}")
        require(svc, f"m_stats.{token}", f"display counter update {token}")
    require(hdd_ui, "Display snapshot attempts:", "attempt/success/failure UI")

    # The pause guard must expose enough outcome data to explain post-pause
    # vm_stop errors without changing its resume ownership behavior.
    for token in ("WasRunning() const", "GuestStopped() const", "StopResult() const"):
        require(pause_h, token, f"pause guard outcome {token}")
    require(svc, "PauseFailureStatus", "HDD pause failure formatter")
    require(svc, "cmp_folder_hdd_get_last_sync_error", "Folder-HDD error surfacing")

    # Kernel RPC transitions may be initiated by detached/unlocked UI. Every
    # vm_stop/vm_start in this TU must flow through the conditional BQL wrappers.
    require(rpc, "int StopVmSynchronized(RunState state)", "RPC synchronized stop wrapper")
    require(rpc, "void StartVmSynchronized()", "RPC synchronized start wrapper")
    require(rpc, "class RpcBqlGuard", "RPC conditional BQL guard")
    if rpc.count("RpcBqlGuard guard(__FILE__, __LINE__);") != 2:
        raise AssertionError("RPC stop/start wrappers are not conditionally BQL guarded")
    call_stop = [m.start() for m in re.finditer(r"\bvm_stop\s*\(", rpc)]
    call_start = [m.start() for m in re.finditer(r"\bvm_start\s*\(", rpc)]
    if len(call_stop) != 1 or len(call_start) != 1:
        raise AssertionError(
            f"direct RPC vm transitions remain outside wrappers: stop={len(call_stop)} start={len(call_start)}")
    require(rpc, "the Xbox was resumed and the test was not started", "IRQL partial-stop cleanup")
    require(rpc, "the Xbox was resumed.", "safe-point partial-stop cleanup")

    # RF is transient resume/debug state. All other EFLAGS bits remain exact.
    require(rpc, "kEflagsResumeFlag = 0x00010000u", "RF bit definition")
    require(rpc, "kStableEflagsMask = ~kEflagsResumeFlag", "stable EFLAGS mask")
    if rpc.count('SameMaskedField("eflags"') != 2:
        raise AssertionError("both RPC preserved-state checks must use the RF-only mask")
    require(rpc, "transient RF ignored", "IRQL result explanation")

    # Folder-HDD conflict protection itself remains intact; v3.14a only exposes
    # the current reason for diagnostics. The whole-tree merge redesign is not
    # part of this repair pass.
    require(folder_sync, "HostWritebackAllowsAdditionsOnly",
            "host conflict compatibility guard")
    require(folder_sync, "host path changed while Xbox writes were pending",
            "existing host modification safeguard")
    require(folder_sync, "host/Xbox file-addition conflict",
            "new-file collision safeguard")
    require(folder_h, "cmp_folder_hdd_get_last_sync_error", "last sync error API")
    require(folder_c, "cmp_set_last_sync_error_locked", "last sync error storage")

    print("PASS: v3.14a HDD refresh/RPC repair guard")


if __name__ == "__main__":
    main()
