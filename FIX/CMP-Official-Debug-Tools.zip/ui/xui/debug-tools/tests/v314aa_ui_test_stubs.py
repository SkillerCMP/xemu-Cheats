"""Dependency stubs for isolated UI syntax checks, NOT a full XEMU/ImGui build.
Actual diagnostics.cc, diagnostics.hh and backend event layouts are unchanged.
"""
from pathlib import Path
import shutil,re
def prepare(root, temp):
    root=Path(root);temp=Path(temp);temp.mkdir(exist_ok=True)
    shutil.copytree(root/'ui/xui/debug-tools',temp/'ui/xui/debug-tools',dirs_exist_ok=True,ignore=shutil.ignore_patterns('tests','Codetypes'))
    shutil.copyfile(root/'ui/xemu-notifications.h',temp/'ui/xemu-notifications.h')
    s=(root/'ui/xui/debug-tools/addons/diagnostics/diagnostics.cc').read_text()
    constants=sorted(set(re.findall(r'\bImGui(?:WindowFlags|TableFlags|TableColumnFlags|InputTextFlags|DataType|Cond|Key|Col)_[A-Za-z0-9_]+',s+(root/'ui/xui/debug-tools/tab-style.hh').read_text())))
    stub='''#pragma once
    #include <cstdint>
    #include <cstddef>
    #include <string>
    #include <array>
    struct ImVec2 {float x=0,y=0;ImVec2()=default;ImVec2(float a,float b):x(a),y(b){}};
    struct ImVec4 {float x=0,y=0,z=0,w=0;ImVec4()=default;ImVec4(float a,float b,float c,float d):x(a),y(b),z(c),w(d){}};
    using ImGuiWindowFlags=int;using ImGuiInputTextFlags=int;using ImGuiKey=int;
    struct ImGuiIO {ImVec2 DisplaySize;bool KeyCtrl=false,KeyShift=false,KeyAlt=false,WantTextInput=false,KeySuper=false;};
    '''+''.join('constexpr int '+c+'='+str(1<<(i%20))+';\n' for i,c in enumerate(constants))+'''namespace ImGui {
    inline ImGuiIO &GetIO(){static ImGuiIO io;return io;}
    inline void *GetCurrentContext(){return nullptr;}
    inline ImVec4 GetStyleColorVec4(int){return {};}
    '''
    for f in sorted(set(re.findall(r'ImGui::(\w+)\(',s))|{'PushStyleColor','PopStyleColor'}):
     if f in ['GetIO','GetCurrentContext']:continue
     stub+='template<class... A> inline bool '+f+'(A...){return false;}\n'
    stub+='}\n#define IM_ARRAYSIZE(a) (sizeof(a) / sizeof((a)[0]))\n';(temp/'imgui.h').write_text(stub)
    (temp/'ui/xui/common.hh').write_text('#pragma once\n#include <imgui.h>\n#include <SDL3/SDL.h>\n')
    (temp/'ui/xui/misc.hh').write_text('#pragma once\n#include "common.hh"\n')
    (temp/'SDL3').mkdir(exist_ok=True)
    (temp/'SDL3/SDL.h').write_text('''#pragma once
    #include <cstdint>
    struct SDL_Window;struct SDL_Event;using SDL_WindowID=uint32_t;
    inline uint64_t SDL_GetTicks(){return 1000;}
    inline bool SDL_SetClipboardText(const char *){return true;}
    inline const char *SDL_GetError(){return "stub";}
    inline bool SDL_OpenURL(const char *){return false;}
    ''')
    (temp/'glib').mkdir(exist_ok=True)
    (temp/'glib.h').write_text('''#pragma once
    #include <cstddef>
    #include <cstdio>
    using gchar=char;struct GDateTime;struct GError {const char *message;};
    constexpr int G_FILE_TEST_EXISTS=1;
    char *g_build_filename(const char *,...);void g_free(void *);int g_mkdir_with_parents(const char *,int);
    GDateTime *g_date_time_new_now_local();char *g_date_time_format(GDateTime *,const char *);void g_date_time_unref(GDateTime *);
    bool g_file_test(const char *,int);char *g_filename_to_uri(const char *,const char *,GError **);void g_error_free(GError *);
    char *g_canonicalize_filename(const char *,const char *);
char *g_path_get_dirname(const char *);FILE *g_fopen(const char *,const char *);int g_remove(const char *);int g_rename(const char *,const char *);
    ''')
    (temp/'glib/gstdio.h').write_text('#pragma once\n#include <glib.h>\n')
