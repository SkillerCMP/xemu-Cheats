#!/usr/bin/env python3
"""Compile all actual Diagnostics C++ against platform header stubs; exercise actual menus.
No real SDL/ImGui rendering, emulator or GPU is executed.
"""
from __future__ import annotations
import argparse, pathlib, subprocess, tempfile, re
from v314y_vulkan_observer_test_utils import function
from v314aa_ui_test_stubs import prepare

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--compiler',default='g++');a=ap.parse_args()
    root=pathlib.Path(a.root);d=root/'ui/xui/debug-tools/addons/diagnostics'
    ui=(d/'diagnostics.cc').read_text();hh=(d/'diagnostics.hh').read_text()
    exports=re.findall(r'bool (m_export_\w+) = true;',hh)
    with tempfile.TemporaryDirectory(prefix='xemu-diagnostics-view-') as tempdir:
        temp=pathlib.Path(tempdir);prepare(root,temp)
        actual=temp/'ui/xui/debug-tools/addons/diagnostics/diagnostics.cc'
        subprocess.run([a.compiler,'-std=c++17','-fsyntax-only','-Wall','-Wextra','-Werror','-I',str(temp),str(actual)],check=True)
        cpp=r'''#include <array>
#include <cstdint>
#include <deque>
#include <string>
#include <vector>
#include <cassert>
#include <set>
#include <iostream>
#define private public
#include "ui/xui/debug-tools/addons/diagnostics/diagnostics.hh"
#undef private
namespace ImGui {
static std::string clicked;
static std::set<std::string> seen;
bool BeginMenu(const char *) { return true; }
void EndMenu() {}
void TextDisabled(const char *) {}
void Separator() {}
void SameLine() {}
bool Button(const char *label) {
    seen.insert(label);
    if (clicked != label) return false;
    clicked.clear();
    return true;
}
bool Checkbox(const char *label, bool *checked) {
    seen.insert(label);
    if (clicked != label) return false;
    clicked.clear();
    if (checked) *checked = !*checked;
    return true;
}
}
'''+function(ui,'void DiagnosticsWindow::DrawViewMenu()')+'\n'+r'''
int main() {
    using namespace XemuDiagnosticsView;
    DiagnosticsWindow w;
'''

        cpp+=r'''
    ImGui::clicked="Uncheck All";w.DrawViewMenu();
    for (bool b:w.m_view.checked) assert(!b);
'''+r'''
    std::set<std::string> labels;
    for (std::size_t i=0;i<kSections.size();i++) {
        const auto &section=kSections[i];
        assert(static_cast<std::size_t>(section.id)==i);
        assert(labels.insert(section.label).second);
        assert(ImGui::seen.count(section.label)==1);
        ImGui::clicked=section.label;w.DrawViewMenu();
        assert(w.m_view.IsVisible(section.id));
        assert(w.m_view.Any(section.group));
        for (std::size_t j=0;j<kSections.size();j++) assert(w.m_view.checked[j]==(i==j));
        ImGui::clicked=section.label;w.DrawViewMenu();
        for (bool b:w.m_view.checked) assert(!b);
    }
    assert(!w.m_view.IsVisible(Section::Count));
    ImGui::clicked="Check All";w.DrawViewMenu();
    for (bool b:w.m_view.checked) assert(b);
'''+r'''
    std::cout << "PASS: persistent View menu: all 40 entries reachable/toggle independently; check/uncheck-all; shared View selection\n";
}
'''
        p=temp/'menus.cpp';p.write_text(cpp);exe=temp/'menus'
        subprocess.run([a.compiler,'-std=c++17','-O2','-Wall','-Wextra','-Werror','-I',str(root),str(p),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True)
    from v314ab_report_test_utils import test_report
    test_report(root, a.compiler)
    print('PASS: entire actual Diagnostics translation unit syntax with dependency-header stubs (not a full GUI build)')
    return 0
if __name__=='__main__':raise SystemExit(main())
