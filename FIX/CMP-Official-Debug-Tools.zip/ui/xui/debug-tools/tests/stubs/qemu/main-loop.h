#ifndef XEMU_DEBUG_TOOLS_TEST_STUB_QEMU_MAIN_LOOP_H
#define XEMU_DEBUG_TOOLS_TEST_STUB_QEMU_MAIN_LOOP_H

/* Native model stub: pause-guard tests exercise run-state ownership only. */
#define BQL_LOCK_GUARD() do { } while (0)

#endif
