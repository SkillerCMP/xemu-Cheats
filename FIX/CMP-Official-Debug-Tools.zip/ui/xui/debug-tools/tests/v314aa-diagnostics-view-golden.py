#!/usr/bin/env python3
"""v3.14ab supersedes aa's independent export flags with one tested View mask."""
import argparse, pathlib, re
from v314y_vulkan_observer_test_utils import function, token_hash
EXPECTED = {'BuildSnapshotText': '716ED388DC36E815DADA33D1F6A5D9325E3FDE802DBFA69026A14953B20F46A0', 'DrawViewMenu': '6C0D2DF8C706D4825762B6C0B77FD6CF6359AD13E97BA1514D26ADA25D9611AE', 'DrawCpuTiming': '934988E338B60FBF255EE16A6C9A629A2B1F1625E775CF5E8AC11AC385BE99B9', 'DrawNv2a': 'EA5452EF1F2A8A6DD52813176089EA76B7381869C42AFEAD916D9E7EED12FD2E', 'DrawAudio': 'D03C93CCBBB9A0F4EF7527E006FA619A9A8053BAA5748ECE16F5C8FED4FDDAD5'}
def validate(ui, hh, registry):
    entries=re.findall(r'\{Section::(\w+), Group::(\w+), "([^"]+)"\}',registry)
    assert len(entries)==40 and len({e[0] for e in entries})==40
    assert 'm_export_' not in ui+hh and 'DrawExportMenu' not in ui+hh
    assert 'Snapshot Export' not in ui
    view=function(ui,'void DiagnosticsWindow::DrawViewMenu()')
    assert '"Check All"' in view and '"Uncheck All"' in view
    assert 'm_view.SetAll(true)' in view and 'm_view.SetAll(false)' in view
    assert 'xemu_' not in view and 'SetAllRecordingOptionsEnabled' not in view
    assert 'm_view' not in function(ui,'void DiagnosticsWindow::SetAllRecordingOptionsEnabled(bool enabled)')
    snap=function(ui,'std::string DiagnosticsWindow::BuildSnapshotText() const')
    for name,group,label in entries:
        assert 'DiagnosticSection::'+name in snap, 'missing report owner: '+name
        if group in ('Cpu','Nv2a','Audio'):
            target={'Cpu':'DrawCpuTiming','Nv2a':'DrawNv2a','Audio':'DrawAudio'}[group]
            assert 'DiagnosticSection::'+name in function(ui,'void DiagnosticsWindow::'+target+'()')
    for name,h in EXPECTED.items():
        sig='std::string DiagnosticsWindow::BuildSnapshotText() const' if name=='BuildSnapshotText' else 'void DiagnosticsWindow::'+name+'()'
        assert token_hash(function(ui,sig))==h,'approved UI/report operations changed: '+name
    draw=function(ui,'void DiagnosticsWindow::Draw(bool detached)')
    for group in ['Overview','Cpu','Nv2a','Audio','Watches','History']:
        assert 'm_view.Any(XemuDiagnosticsView::Group::'+group+')' in draw
    assert 'DrawRecordingControls();' in draw

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);a=ap.parse_args()
    d=pathlib.Path(a.root)/'ui/xui/debug-tools/addons/diagnostics'
    ui=(d/'diagnostics.cc').read_text();hh=(d/'diagnostics.hh').read_text();reg=(d/'diagnostics-view-sections.h').read_text()
    validate(ui,hh,reg)
    for old,new in [('m_view.SetAll(false);','SetAllRecordingOptionsEnabled(false);'),
                    ('m_view.IsVisible(DiagnosticSection::MethodBreakdown)','true'),
                    ('m_view.IsVisible(DiagnosticSection::AvSync)','true')]:
        try:validate(ui.replace(old,new),hh,reg)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('unsafe selection change accepted')
    print('PASS: all 40 panels own report selections; single View mask; frozen UI/report; three negative controls')
if __name__=='__main__':main()
