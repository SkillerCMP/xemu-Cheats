#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--root', required=True)
args = ap.parse_args()
root = Path(args.root)
dbg = root / 'ui/xui/debug-tools'

required = [
    dbg / 'addons/diagnostics/av-sync-trace-hook.h',
    dbg / 'addons/diagnostics/av-sync-trace.h',
    dbg / 'addons/diagnostics/av-sync-trace.c',
    dbg / 'addons/stubs/av-sync-trace-stub.c',
]
for path in required:
    if not path.is_file():
        raise SystemExit(f'FAIL: missing A/V sync trace file: {path}')

meson = (dbg / 'meson.build').read_text(encoding='utf-8')
for token in ("'addons/diagnostics/av-sync-trace.c'",
              "'addons/stubs/av-sync-trace-stub.c'"):
    if token not in meson:
        raise SystemExit(f'FAIL: missing A/V sync Meson ownership: {token}')

trace_h = (dbg / 'addons/diagnostics/av-sync-trace.h').read_text(encoding='utf-8')
trace_c = (dbg / 'addons/diagnostics/av-sync-trace.c').read_text(encoding='utf-8')
for token in ('XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY 8192',
              'XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_RATE 48000ULL',
              'audio_host_drift_ns', 'video_host_drift_ns',
              'av_host_drift_ns', 'av_virtual_drift_ns'):
    if token not in trace_h:
        raise SystemExit(f'FAIL: missing A/V sync trace contract: {token}')
for token in ('SDL_GetAudioStreamQueued', 'QEMU_CLOCK_VIRTUAL',
              'QEMU_CLOCK_HOST', 'samples * 1000000000ULL',
              'video_expected_ns += interval_ns'):
    if token not in trace_c:
        raise SystemExit(f'FAIL: missing A/V sync recorder behavior: {token}')

monitor = (root / 'hw/xbox/mcpx/apu/monitor.c').read_text(encoding='utf-8')
xemu = (root / 'ui/xemu.c').read_text(encoding='utf-8')
if 'xemu_debug_tools_av_sync_trace_note_audio_batch' not in monitor:
    raise SystemExit('FAIL: MCPX monitor does not feed A/V audio batches')
if 'ARRAY_SIZE(d->monitor.frame_buf)' not in monitor:
    raise SystemExit('FAIL: A/V audio hook must use the 256-sample monitor buffer')
if 'xemu_debug_tools_av_sync_trace_note_vblank(vblank_interval_ns)' not in xemu:
    raise SystemExit('FAIL: VBlank path does not feed configured interval to A/V trace')

diag = (dbg / 'addons/diagnostics/diagnostics.cc').read_text(encoding='utf-8')
for token in ('Audio / Video Sync Trace', 'Record A/V cadence',
              'XEMU_DIAG_BUFFER_AV_SYNC', 'm_view.IsVisible(DiagnosticSection::AvSync)',
              'xemu_diagnostics_av_sync_trace_set_enabled(value)',
              'A/V host / virtual cadence drift ns'):
    if token not in diag:
        raise SystemExit(f'FAIL: missing A/V Diagnostics UI/export integration: {token}')

print('PASS: v3.14q A/V sync trace records 256-sample 48 kHz audio batches and VBlank cadence with host/virtual drift')
