#!/usr/bin/env python3
"""v3.09a: Branch/Functions tab removed while conditional Branch Breaks remain."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def ordered(text: str, first: str, second: str, label: str) -> None:
    a = text.find(first)
    b = text.find(second)
    if a < 0 or b < 0 or b <= a:
        raise AssertionError(f"bad ordering for {label}: {first!r} -> {second!r}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    memory = debug / "addons/memory-tools"

    hh = (memory / "memory-tools.hh").read_text(encoding="utf-8")
    tabs = (memory / "memory-tools.cc").read_text(encoding="utf-8")
    debugger = (memory / "memory-tools-debugger.cc").read_text(encoding="utf-8")
    debugger_ui = (memory / "memory-tools-debugger-ui.cc").read_text(encoding="utf-8")
    inject_ui = (memory / "memory-tools-inject-ui.cc").read_text(encoding="utf-8")
    trace = (memory / "execution-trace.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")

    # v3.09a deliberately removes the standalone finder/watcher UI and its
    # continuous-single-step/static-scan implementation.
    forbid(tabs, 'ImGui::BeginTabItem("Branch / Functions")', "Branch / Functions tab")
    forbid(tabs, "DrawBranchFunctionWatcher", "watcher draw call")
    forbid(hh, "ControlWatcherMode", "watcher mode/state")
    forbid(hh, "BranchWatcherRow", "watcher branch rows")
    forbid(hh, "FunctionWatcherRow", "watcher function rows")
    forbid(hh, "StartControlWatcher", "watcher start API")
    forbid(hh, "ScanPhysicalControlFlow", "watcher physical scan API")
    forbid(meson, "branch-function-watcher.cc", "watcher source ownership")
    forbid(meson, "physical-control-flow-scan.c", "physical scan source ownership")
    if (memory / "branch-function-watcher.cc").exists():
        raise AssertionError("branch-function-watcher.cc should be removed")
    if (memory / "physical-control-flow-scan.c").exists():
        raise AssertionError("physical-control-flow-scan.c should be removed")
    if (memory / "physical-control-flow-scan.h").exists():
        raise AssertionError("physical-control-flow-scan.h should be removed")
    forbid(trace, "TickControlWatcher", "watcher lifecycle coupling")
    forbid(trace, "m_control_watcher_running", "trace/watcher mutual exclusion")

    # Keep Branch Breaks as an extension of the established execute-breakpoint
    # system and expose them only on conditional branch rows.
    require(hh, "enum class BranchBreakMode", "branch-break mode enum")
    require(hh, "BranchBreakMode branch_mode", "branch predicate on ExecuteBreakpoint")
    require(hh, "bool branch_one_shot", "one-shot state on ExecuteBreakpoint")
    require(debugger, "AddBranchBreakpoint", "shared branch-breakpoint creator")
    require(debugger, "EvaluateConditionalBranch", "architectural branch evaluator")
    require(debugger, "ContinueFilteredExecuteBreakpoint(regs.pc)",
            "backend-shared mismatch continuation")
    require(debugger, "accepted_branch_one_shot && branch_result_valid",
            "one-shot only after requested branch result")
    require(debugger_ui, "BranchBreakpointTypeText(bp)",
            "normal breakpoint list branch type display")

    require(inject_ui, 'ImGui::BeginMenu("Break Point")', "existing Break Point menu")
    require(inject_ui, "flow.kind == DebugFlowKind::ConditionalJump",
            "conditional-only Branch Breaks gate")
    require(inject_ui, 'ImGui::BeginMenu("Branch Breaks")', "nested Branch Breaks menu")
    ordered(inject_ui, 'ImGui::BeginMenu("Break Point")',
            'ImGui::BeginMenu("Branch Breaks")', "Branch Breaks remains nested")
    for item in (
        "Break when Taken",
        "Break when Not Taken",
        "Break on Next Taken",
        "Break on Next Not Taken",
    ):
        require(inject_ui, item, f"branch breakpoint menu item {item}")

    # Preserve the Jcc/loop evaluator used by those breakpoint predicates.
    for token in (
        'mnemonic == "je" || mnemonic == "jz"',
        'mnemonic == "jne" || mnemonic == "jnz"',
        'mnemonic == "ja" || mnemonic == "jnbe"',
        'mnemonic == "jg" || mnemonic == "jnle"',
        'mnemonic == "jl" || mnemonic == "jnge"',
        'mnemonic == "jecxz"',
        'mnemonic == "loop"',
        "regs.eflags",
        "regs.ecx",
    ):
        require(debugger, token, f"branch evaluator {token}")

    print("PASS: Branch/Functions tab and watcher removed; established conditional Branch Breaks preserved")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
