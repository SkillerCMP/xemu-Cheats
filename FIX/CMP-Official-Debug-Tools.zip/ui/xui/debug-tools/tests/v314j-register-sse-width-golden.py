#!/usr/bin/env python3
# v3.14j SSE register pane width regression.
"""Guard enough Current/Last BP width for four complete 32-bit SSE lanes."""
from __future__ import annotations

import argparse
import pathlib

from v287_source_test_utils import extract_function, read_memory_tools_implementation


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    implementation = read_memory_tools_implementation(debug)
    draw_debugger = extract_function(
        implementation, "void MemoryToolsWindow::DrawDebugger()")
    draw_extra = extract_function(
        implementation, "void MemoryToolsWindow::DrawExtraRegisterTable(")

    for needle in (
        "constexpr float kRegisterPaneWidth = 350.0f;",
        "constexpr float kRegisterWorkspaceWidth = 720.0f;",
        'ImGui::TableSetupColumn("Current Registers",',
        'ImGui::TableSetupColumn("Last BP",',
    ):
        if needle not in draw_debugger:
            raise AssertionError(f"v3.14j widened register-pane invariant missing: {needle}")

    if draw_debugger.count("kRegisterPaneWidth);") < 2:
        raise AssertionError("Current Registers and Last BP must both use widened pane width")
    if "kRegisterWorkspaceWidth);" not in draw_debugger:
        raise AssertionError("register workspace must expand with the widened paired panes")

    # Ensure SSE remains rendered as all four 32-bit values; the width fix must
    # expose the whole row rather than shortening/reformatting register data.
    if 'ImGui::Text("%08X %08X %08X %08X",' not in draw_extra:
        raise AssertionError("SSE XMM rows no longer expose all four 32-bit lanes")

    print("PASS: v3.14j register panes are wide enough for complete SSE XMM rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
