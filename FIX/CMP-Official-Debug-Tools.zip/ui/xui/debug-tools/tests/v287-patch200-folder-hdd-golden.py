#!/usr/bin/env python3
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[4]
dt = root / "ui/xui/debug-tools"
folder_dir = dt / "addons/Folder-HDD"
errors = []

def require(path, needle):
    text = path.read_text(encoding="utf-8")
    if needle not in text:
        errors.append(f"{path.relative_to(root)} missing {needle!r}")

def forbid(path, needle):
    text = path.read_text(encoding="utf-8")
    if needle in text:
        errors.append(f"{path.relative_to(root)} unexpectedly contains {needle!r}")

folder = folder_dir / "folder-hdd.c"
header = folder_dir / "folder-hdd.h"
sync_helper = folder_dir / "folder-hdd-sync.cc"
sync_header = folder_dir / "folder-hdd-sync.h"
folder_ui = folder_dir / "folder-hdd-ui.cc"
folder_ui_h = folder_dir / "folder-hdd-ui.hh"
for p in (folder, header, sync_helper, sync_header, folder_ui, folder_ui_h,
          folder_dir / "README.md", dt / "addons/stubs/debug-tools-core-stub.cc",
          dt / "addons/stubs/folder-hdd-stub.c"):
    if not p.exists():
        errors.append(f"missing {p.relative_to(root)}")

require(dt / "tools" / "read-build-profile.py", '"folder-hdd"')
require(dt / "meson.build", "debug_tools_profile == 'folder-hdd'")
require(dt / "meson.build", "addons/Folder-HDD/folder-hdd.c")
require(dt / "meson.build", "addons/Folder-HDD/folder-hdd-sync.cc")
require(dt / "meson.build", "addons/Folder-HDD/folder-hdd-ui.cc")
require(dt / "meson.build", "if not debug_tools_with_hdd")
require(dt / "meson.build", "addons/stubs/folder-hdd-stub.c")
require(root / "config_spec.yml", "hdd_folder_path: string")
require(root / "config_spec.yml", "values: [image, folder]")

# Upstream menu is only a hook; the complete Folder-HDD settings UI is addon-owned.
require(root / "ui/xui/main-menu.cc", "cmp_folder_hdd_draw_settings(&m_dirty)")
forbid(root / "ui/xui/main-menu.cc", "Folder Backed FATX (CMP)")
require(folder_ui, "Folder Backed FATX (CMP)")
require(folder_ui, "cmp_folder_hdd_is_configured()")
require(folder_ui, "cmp_folder_hdd_get_default_root")
require(folder_ui, "cmp_folder_hdd_ensure_layout")
require(folder_ui, "XEMU-HDD created:")
require(folder_ui, "Folder HDD Root")

require(root / "system/vl.c", "cmp_folder_hdd_make_uri")
require(root / "system/vl.c", "xemu_queue_error_message_with_action")
require(root / "system/vl.c", '"Make Folders"')
require(root / "system/vl.c", "cmp_folder_hdd_make_folders_action")
require(folder_ui, "cmp_folder_hdd_make_folders_action")
require(root / "ui/xui/notifications.cc", "QueueErrorWithAction")
require(root / "ui/xui/notifications.cc", "entry.action_label")
require(root / "system/vl.c", '"index=0,media=disk,file=%s,locked=on"')
forbid(root / "system/vl.c", 'file=%s,readonly=on')

require(folder, '.protocol_name = "fatxdir"')
forbid(folder, 'return -EROFS;')
require(folder, "CMP_OVERLAY_PAGE_SIZE 4096u")
require(folder, "cmp_overlay_write")
require(folder, "cmp_overlay_apply")
require(folder, "cmp_folder_hdd_rescan_active")
require(folder, "cmp_rebuild_partitions_locked")
require(folder, "cmp_collect_allocation_hints")
require(folder, "previous_high_water")
require(folder, "Do not reuse deleted clusters during a live session.")
require(folder, "CMP_AUTO_RESCAN_INTERVAL_US")
require(folder, "CMP_AUTO_WRITEBACK_IDLE_US")
require(folder, "cmp_auto_writeback_worker")
require(folder, "cmp_auto_writeback_schedule_locked")
require(folder, "g_cond_wait_until")
require(folder, "g_thread_try_new")
require(folder, "cmp_folder_hdd_maybe_auto_rescan_locked")
require(folder, "cmp_writeback_pending_locked")
require(folder, "cmp_try_collapse_persisted_overlay")
require(folder, "cmp_folder_hdd_sync_guest_to_host")
require(header, "cmp_folder_hdd_is_active")
require(header, "cmp_folder_hdd_rescan_active")
require(header, "cmp_folder_hdd_get_default_root")
require(header, "cmp_folder_hdd_ensure_layout")
require(folder, 'g_getenv("APPIMAGE")')
require(folder, 'g_build_filename(exe_dir, "XEMU-HDD", NULL)')
for part in ('"C"', '"E"'):
    require(folder, part)
require(folder, 'CMP_CACHE_DIRECTORY "Cache"')
require(folder, 'CMP_CACHE_FILENAME "xbox_cache.img"')
require(folder, 'cmp_cache_prepare')
require(folder, 'cmp_cache_mark_sparse')
require(folder, '#include <winioctl.h>')
require(folder, 'cmp_cache_format_partition')
require(folder, 'cmp_cache_read')
require(folder, 'cmp_cache_write')
require(folder, 'CMP_CACHE_DISK_START 0x00080000ULL')
require(folder, 'CMP_CACHE_DISK_END   0x8CA80000ULL')
require(folder, "g_hash_table_remove_all(s->overlay_pages)")
require(folder, "host_overlay_written")
require(folder, "s->overlay_dirty = true")
require(folder, "g_hash_table_new_full(g_int64_hash, g_int64_equal")
require(folder, ".bdrv_co_pwritev = cmp_folder_hdd_co_pwritev")
require(folder, ".bdrv_co_flush_to_disk = cmp_folder_hdd_co_flush_to_disk")
require(folder, "0x8CA80000ULL")
require(folder, "0xABE80000ULL")
require(folder, "0x00080000ULL")
require(folder, "0x2EE80000ULL")
require(folder, "0x5DC80000ULL")
require(folder, "CMP_MAX_FILENAME 42u")
require(folder, "CMP_SECTORS_PER_CLUSTER")
require(folder, "block_init(cmp_folder_hdd_register)")

text = folder.read_text(encoding="utf-8")
read_order = [text.find("ret = cmp_disk_read"),
              text.find("cmp_overlay_apply", text.find("ret = cmp_disk_read")),
              text.find("qemu_iovec_from_buf", text.find("ret = cmp_disk_read"))]
if -1 in read_order or read_order != sorted(read_order):
    errors.append("Folder-HDD read path does not apply volatile overlay after base read")
write_start = text.find("cmp_folder_hdd_co_pwritev")
write_body = text[write_start:text.find("cmp_folder_hdd_co_flush_to_disk", write_start)] if write_start >= 0 else ""
for needle in ("qemu_iovec_to_buf", "cmp_disk_write", "cmp_auto_writeback_schedule_locked"):
    if needle not in write_body:
        errors.append(f"Folder-HDD write path missing {needle}")
for forbidden in ("g_fopen", "fwrite", "g_file_set_contents"):
    if forbidden in write_body:
        errors.append(f"Folder-HDD volatile write path must not touch host files ({forbidden})")

require(sync_helper, "XemuFatxHdd::BuildPartitionSnapshot")
require(sync_helper, "BuildPersistentSnapshot")
require(sync_helper, "XemuFatxHdd::ReadFileRangeSequential")
require(sync_helper, "SameManifest(baseline, current)")
require(sync_helper, "host write-back was deferred")
require(sync_helper, ".cmp-folder-hdd-tmp")
require(sync_helper, "txn-XXXXXX")
require(sync_helper, "RollbackHostChanges")
require(sync_helper, "Host changes from this commit were rolled back")
require(sync_helper, "cmp_folder_hdd_sync_refresh_baseline")
require(sync_header, "cmp_folder_hdd_sync_effective_read")
require(sync_header, "cmp_folder_hdd_sync_guest_to_host")

hdd_dir = dt / "addons/hdd/hdd-directory.cc"
hdd_ui = dt / "addons/hdd/hdd-directory-ui.cc"
snapshot_service = dt / "addons/hdd/hdd-snapshot-service.cc"
snapshot_header = dt / "addons/hdd/hdd-snapshot-service.hh"
require(hdd_dir, "m_host_rescan_requested")
require(hdd_dir, "hdd_snapshot_service.RescanFolderHdd")
require(hdd_ui, "m_host_rescan_requested = true")
require(snapshot_service, "bool HddSnapshotService::RescanFolderHdd")
require(snapshot_service, "XemuDebugGuestPauseGuard pause")
require(snapshot_service, "cmp_folder_hdd_rescan_active")
require(snapshot_header, "RescanFolderHdd")

# The active build stack owns addon implementations in the overlay and keeps
# numbered patches as ordered upstream-hook layers.
fix = root.parent / "FIX"
if fix.exists():
    def natural_key(name):
        return [int(x) if x.isdigit() else x.lower()
                for x in re.split(r"([0-9]+)", name)]
    names = sorted((p.name for p in fix.glob("*.patch")), key=natural_key)
    expected = [n for n in (
        "10-XID-Cached-Input-Cleanup.patch",
        "20-NV2A-PGRAPH-Livelock-Cleanup.patch",
        "30-VBlank-APU-Lock-Convoy-Fix.patch",
        "200-CMP-Folder-HDD.patch",
        "210-CMP-Video-Recorder.patch",
        "300-CMP-PATCH-ADDITION.patch",
    ) if n in names]
    actual = [n for n in names if n in expected]
    if actual != expected:
        errors.append(f"unexpected active patch order: {actual!r}")

if errors:
    print("FAIL: Patch 200 Folder-HDD golden")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("PASS: Patch 200 Folder-HDD golden")
