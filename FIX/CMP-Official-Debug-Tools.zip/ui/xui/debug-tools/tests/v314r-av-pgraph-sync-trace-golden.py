#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--root', required=True)
args = ap.parse_args()
root = Path(args.root)
dbg = root / 'ui/xui/debug-tools'

trace_h = (dbg / 'addons/diagnostics/av-sync-trace.h').read_text(encoding='utf-8')
trace_hook = (dbg / 'addons/diagnostics/av-sync-trace-hook.h').read_text(encoding='utf-8')
trace_c = (dbg / 'addons/diagnostics/av-sync-trace.c').read_text(encoding='utf-8')
stub = (dbg / 'addons/stubs/av-sync-trace-stub.c').read_text(encoding='utf-8')
pgraph = (root / 'hw/xbox/nv2a/pgraph/pgraph.c').read_text(encoding='utf-8')
diag = (dbg / 'addons/diagnostics/diagnostics.cc').read_text(encoding='utf-8')

for token in (
    'XEMU_DEBUG_TOOLS_AV_SYNC_PGRAPH_FLIP',
    'pgraph_last_virtual_interval_ns',
    'pgraph_max_virtual_interval_ns',
    'audio_since_pgraph_ns',
    'vblank_since_pgraph_ns',
):
    if token not in trace_h:
        raise SystemExit(f'FAIL: missing A/V/PGRAPH trace contract: {token}')

for text, where in (
    ('xemu_debug_tools_av_sync_trace_note_pgraph_flip', trace_hook),
    ('xemu_debug_tools_av_sync_trace_note_pgraph_flip', stub),
    ('pgraph_baseline_valid', trace_c),
    ('last_pgraph_audio_samples', trace_c),
    ('last_pgraph_video_expected_ns', trace_c),
    ('max_pgraph_virtual_interval_ns', trace_c),
    ('audio_since_pgraph_ns', trace_c),
    ('vblank_since_pgraph_ns', trace_c),
):
    if text not in where:
        raise SystemExit(f'FAIL: missing A/V/PGRAPH recorder behavior: {text}')

if 'xemu_debug_tools_av_sync_trace_note_pgraph_flip(pg->frame_time)' not in pgraph:
    raise SystemExit('FAIL: guest FLIP_STALL does not feed the A/V/PGRAPH trace')
if pgraph.index('nv2a_profile_flip_stall();') > pgraph.index('xemu_debug_tools_av_sync_trace_note_pgraph_flip(pg->frame_time)'):
    raise SystemExit('FAIL: PGRAPH sync event must follow the GPU frame-count boundary')

for token in (
    'PGRAPH FLIP_STALL frames',
    'Last PGRAPH flip gap',
    'Worst PGRAPH flip gap',
    'Since last PGRAPH flip',
    'PGRAPH_FLIP',
    'pgraph_last_virtual_interval_ns',
    'audio_since_pgraph_ns',
    'vblank_since_pgraph_ns',
    'no target FPS is assumed',
):
    if token not in diag:
        raise SystemExit(f'FAIL: missing A/V/PGRAPH UI/export integration: {token}')

print('PASS: v3.14r A/V trace adds guest PGRAPH FLIP_STALL cadence without assuming a target FPS')
