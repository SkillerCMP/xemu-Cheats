#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


header = (DIAG / "ptimer-late-capture.h").read_text(encoding="utf-8")
source = (DIAG / "ptimer-late-capture.c").read_text(encoding="utf-8")
qtimer = (DIAG / "qemu-timer-trace.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
ui_h = (DIAG / "diagnostics.hh").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")

# One-shot pinned forensic contract.
require(header, "XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS (5 * 1000 * 1000LL)", "5 ms trigger")
for name in (
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_QTIMER_EVENTS",
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_BQL_EVENTS",
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_MAIN_LOOP_LOCK_EVENTS",
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_PGRAPH_EVENTS",
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_SCHEDULER_EVENTS",
    "XEMU_DEBUG_TOOLS_PTIMER_LATE_GUEST_TIMER_EVENTS",
):
    require(header, name, f"pinned tail {name}")
require(source, "g_ptimer_late_capture.latched", "latched one-shot state")
require(source, "capture_duration_host_ns", "observer perturbation measurement")
require(source, "xemu_debug_tools_qemu_timer_trace_snapshot", "QEMU timer/main-loop tail")
require(source, "xemu_debug_tools_bql_trace_snapshot", "BQL tail")
require(source, "xemu_debug_tools_main_loop_lock_trace_snapshot", "main-loop lock tail")
require(source, "xemu_debug_tools_pgraph_lock_trace_snapshot", "PGRAPH tail")
require(source, "xemu_debug_tools_scheduler_trace_snapshot", "scheduler tail")
require(source, "xemu_debug_tools_guest_timer_deadline_trace_snapshot", "guest timer tail")
require(source, "Arm the generic source recorders", "explicit dependency behavior")
forbid(source, "cpu_memory_rw_debug", "guest memory access")
forbid(source, "vm_stop", "guest pause")
forbid(source, "timer_mod", "timer policy modification")

# Trigger is detected only after dispatch lateness is calculated and after qtimer lock release.
require(qtimer, '#include "ptimer-late-capture.h"', "late capture integration")
require(qtimer, "event.dispatch_late_ns >=", "lateness gate")
require(qtimer, "qemu_mutex_unlock(&qtimer_trace.lock);\n\n    /* Trigger only after dropping", "no recursive qtimer lock")
require(qtimer, "xemu_debug_tools_ptimer_late_capture_note_dispatch(&event);", "one-shot trigger")

# Diagnostics build/bridge/UI/export integration.
require(meson, "'addons/diagnostics/ptimer-late-capture.c'", "full diagnostics source")
require(backend_h, "XemuDiagnosticsPtimerLateCaptureSnapshot", "backend snapshot alias")
require(backend_c, "xemu_diagnostics_get_ptimer_late_capture", "backend capture bridge")
require(ui_h, "XemuDiagnosticsView::State m_view", "export toggle")
require(ui, "PTIMER Late Callback Capture (pinned one-shot)", "UI/export title")
require(ui, "Arm PTIMER >= 5 ms late-callback forensic capture", "arm checkbox")
require(ui, "Clear / Re-arm PTIMER Late Capture", "re-arm control")
require(ui, "Pinned QEMU Timer / Main-Loop Events", "pinned qtimer export")
require(ui, "Pinned BQL Events", "pinned BQL export")
require(ui, "Pinned QEMU Main Loop Lock Events", "pinned main-loop lock export")
require(ui, "Pinned PGRAPH Lock Events", "pinned PGRAPH export")
require(ui, "Pinned Scheduler / CPU Events", "pinned scheduler export")
require(ui, "Pinned Guest Timer / Deadline Events", "pinned guest timer export")
require(ui, "xemu_diagnostics_ptimer_late_capture_set_enabled(value);", "Check All integration")
require(ui, "xemu_diagnostics_ptimer_late_capture_clear();", "Clear All integration")

print("PASS: Patch 304 PTIMER late-callback pinned forensic capture")
