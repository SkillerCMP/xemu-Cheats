#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[4]
dt = root / "ui/xui/debug-tools"
errors = []

def need(path, needle):
    text = path.read_text(encoding="utf-8")
    if needle not in text:
        errors.append(f"{path.relative_to(root)} missing {needle!r}")

meson = dt / "meson.build"
need(meson, "debug_tools_with_main = (debug_tools_profile != 'folder-hdd')")
need(meson, "debug_tools_profile == 'folder-hdd'")
need(meson, "addons/Folder-HDD/folder-hdd.c")
need(meson, "addons/Folder-HDD/folder-hdd-sync.cc")
need(meson, "addons/Video-Recorder/video-recorder.cc")
need(meson, "addons/Video-Recorder/video-recorder-ui.cc")
need(meson, "debug_tools_with_diagnostics = (debug_tools_profile == 'full')")
need(meson, "debug_tools_profile == 'main+hdd'")
need(meson, "debug_tools_profile == 'main+memory'")

# These implementation sources must remain addon-owned, never reintroduced at ui/xui root.
for name in ("video-recorder.cc", "video-recorder.hh", "folder-hdd.c", "folder-hdd.h"):
    if (root / "ui/xui" / name).exists():
        errors.append(f"addon implementation leaked into ui/xui/{name}")

# The old BAT menu is retired. Protect the source-side profile contract here;
# Build-XemuMatrix.ps1 retains the user-facing option 4/5 menu in the package.
reader = dt / "tools/read-build-profile.py"
need(reader, '"full"')
need(reader, '"folder-hdd"')

if errors:
    print("FAIL: v3.07c addon-only profile golden")
    for error in errors:
        print(" -", error)
    sys.exit(1)
print("PASS: v3.07c addon-only profile golden")
