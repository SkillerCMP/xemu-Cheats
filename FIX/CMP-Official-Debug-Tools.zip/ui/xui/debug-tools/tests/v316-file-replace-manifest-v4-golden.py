#!/usr/bin/env python3
"""Compact File Replace manifest-v4 compatibility/source guard."""
from pathlib import Path
import argparse, json
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[4]);args=p.parse_args()
root=args.root;dt=root/'ui/xui/debug-tools';a=dt/'addons/file-replace'
manager=(a/'file-replace.cc').read_text(encoding='utf-8')

def need(token):
    if token not in manager: raise SystemExit('FAIL missing '+token)

for token in [
    'manifest_version != 3 && manifest_version != 4',
    'if (manifest_version == 4)',
    'Manifest v4 requires game as a Game ID string.',
    'Manifest v4 requires non-empty source.',
    'group.id = group_it.key()',
    'option.id = option_it.key()',
    'HumanizeId',
    'must contain exactly [offset, size, replacement].',
    'Manifest v4 whole must be [source_file, replacement_file]',
    'entry.source_type = SourceType::WholeFile',
    'entry.disc_file = source_file;',
    'entry.size_change = true',
    'GetBool(range_item, "resize", false, entry.size_change)',
    'FindKnownSizeFixer(entry.fix_size)',
    'SafeRelativeHostPath(replacement_file, replacement_relative)',
    'Compact manifest v4 loaded for exact executable identity.'
]: need(token)

schema=json.loads((a/'file-replace-v4.schema.json').read_text(encoding='utf-8'))
assert schema['properties']['version']=={'const':4}
whole_schema=schema['$defs']['option']['properties']['whole']
assert whole_schema['type']=='array' and whole_schema['minItems']==2 and whole_schema['maxItems']==2
example=json.loads((a/'examples/compact-v4.json').read_text(encoding='utf-8'))
assert example['version']==4 and example['game']=='AB1234' and example['source']=='root.olk'
assert example['groups']['replace_character']['single'] is True
ranges=example['groups']['replace_character']['options']['alternate']['ranges']
assert ranges[0]==['0x1000','0x20','table.bin']
assert ranges[2]['resize'] is True and ranges[2]['fix_size']=='olk'
assert example['groups']['whole_file_mod']['options']['on']['whole']==['other.olk','replacement.olk']

# v3 stays supported and its schema remains unchanged.
assert json.loads((a/'file-replace-v3.schema.json').read_text(encoding='utf-8'))['properties']['version']=={'const':3}
print('PASS: compact manifest v4 accepted alongside unchanged v3, with explicit [source,replacement] Whole File and inline fixed/resizable forms')
