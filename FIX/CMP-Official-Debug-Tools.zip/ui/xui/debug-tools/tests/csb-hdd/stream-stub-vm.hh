// TEST ONLY: strict interpreter for the exact small opcode subset emitted by
// kernel-rpc-stream.hh. Not a full x86 CPU, actual Xbox kernel or runtime test.
#pragma once
#include <array>
#include <cassert>
#include <functional>
#include <stdexcept>
#include <vector>
struct StreamStubVm {
    std::array<uint32_t,8> r{}; // eax,ecx,edx,ebx,esp,ebp,esi,edi
    uint32_t flags=0x202,pc=0,base=0,completion=0;
    uint8_t *arena=nullptr;size_t arena_size=0;
    std::array<uint8_t,0x20000> stack{};
    std::function<void(StreamStubVm&,uint32_t)> syscall;
    uint8_t *Ptr(uint32_t a,size_t n){
        if(a>=base&&uint64_t(a-base)+n<=arena_size)return arena+(a-base);
        if(a>=0x10000&&uint64_t(a-0x10000)+n<=stack.size())return stack.data()+a-0x10000;
        throw std::runtime_error("Unmapped instruction-simulator memory");
    }
    uint8_t B(uint32_t a){return *Ptr(a,1);}
    uint32_t D(uint32_t a){return XemuKernelRpc::Le32(Ptr(a,4));}
    void D(uint32_t a,uint32_t v){XemuKernelRpc::StoreLe32(Ptr(a,4),v);}
    void Push(uint32_t v){r[4]-=4;D(r[4],v);}
    uint32_t Pop(){uint32_t v=D(r[4]);r[4]+=4;return v;}
    void Logic(uint32_t v){flags=(flags&~0x8c1u)|(v==0?0x40u:0u)|(v&0x80000000u?0x80u:0u);}
    std::vector<uint32_t> Args(size_t n){std::vector<uint32_t>a;for(size_t i=0;i<n;++i)a.push_back(D(r[4]+4+4*i));return a;}
    void Return(uint32_t status,size_t n){uint32_t ret=Pop();r[4]+=static_cast<uint32_t>(n*4);r[0]=status;r[1]=0xeeee1234;r[2]=0xdddd1234;pc=ret;}
    void Run(){
        for(unsigned steps=0;steps<512;++steps){
            if(pc==completion){assert(B(pc)==0xeb&&B(pc+1)==0xfe);return;}
            uint8_t op=B(pc++);
            switch(op){
            case 0x9c:Push(flags);break;
            case 0x9d:flags=Pop();break;
            case 0x60:{uint32_t esp=r[4];for(unsigned i=0;i<8;++i)Push(i==4?esp:r[i]);break;}
            case 0x61:for(int i=7;i>=0;--i){uint32_t v=Pop();if(i!=4)r[i]=v;}break;
            case 0xe8:{uint32_t rel=D(pc);pc+=4;uint32_t target=pc+rel;Push(pc);syscall(*this,target);break;}
            case 0x68:{uint32_t v=D(pc);pc+=4;Push(v);break;}
            case 0xa3:{uint32_t a=D(pc);pc+=4;D(a,r[0]);break;}
            case 0xa1:{uint32_t a=D(pc);pc+=4;r[0]=D(a);break;}
            case 0xc7:{assert(B(pc++)==0x05);uint32_t a=D(pc);pc+=4;uint32_t v=D(pc);pc+=4;D(a,v);break;}
            case 0x85:assert(B(pc++)==0xc0);Logic(r[0]);break;
            case 0x3d:{uint32_t v=D(pc);pc+=4;Logic(r[0]-v);break;}
            case 0x83:{assert(B(pc++)==0x0d);uint32_t a=D(pc);pc+=4;uint32_t v=B(pc++);D(a,D(a)|v);Logic(D(a));break;}
            case 0xff:{assert(B(pc++)==0x35);uint32_t a=D(pc);pc+=4;Push(D(a));break;}
            case 0x0f:{uint8_t cc=B(pc++);if(cc==0xb6){assert(B(pc++)==0xc0);r[0]&=0xff;break;}
                assert(cc==0x84||cc==0x85);uint32_t rel=D(pc);pc+=4;
                bool zero=(flags&0x40)!=0;if(zero==(cc==0x84))pc+=rel;break;}
            default:throw std::runtime_error("Unknown generated stream instruction "+std::to_string(op));
            }
        }
        throw std::runtime_error("Stream stub never reached completion");
    }
};
