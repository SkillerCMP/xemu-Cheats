#!/usr/bin/env python3
"""Strict CSB UI syntax with declaration facades, NOT a full platform build."""
from pathlib import Path
import argparse,shutil,subprocess,tempfile
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--compiler',default='g++');a=ap.parse_args()
dt=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='csb-ui-syntax-') as td:
    root=Path(td);d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
    (d.parent/'common.hh').write_text('#pragma once\n#include <imgui.h>\n')
    # The declaration deliberately lives only in misc.hh, matching xemu. A
    # missing include therefore reproduces TEST1's original compiler error.
    (d.parent/'misc.hh').write_text('''#pragma once
#include <SDL3/SDL.h>
#include <functional>
using FileDialogCallback=std::function<void(const char*)>;
void ShowOpenFileDialog(const SDL_DialogFileFilter*,int,const char*,FileDialogCallback);
''')
    src=d/'addons/custom-soundtrack-builder/custom-soundtrack-builder.cc'
    cmd=[a.compiler,'-std=c++17','-Wall','-Wextra','-Werror','-fsyntax-only','-I'+str(d/'tests/csb-hdd/stubs'),'-I'+str(d)]
    subprocess.run([*cmd,str(src)],check=True)
    print('PASS: complete CSB UI / POSIX FFmpeg branch (declaration-facade syntax)')
    # Exercise the unchanged Win32 process-launch branch without falsely
    # defining the host standard library itself as a Windows build.
    src.write_text(src.read_text().replace('#ifdef _WIN32','#ifdef CSB_TEST_WIN32_BRANCH'))
    subprocess.run([*cmd,'-DCSB_TEST_WIN32_BRANCH',str(src)],check=True)
    print('PASS: complete CSB UI / Win32 FFmpeg branch (declaration-facade syntax, not MinGW)')
