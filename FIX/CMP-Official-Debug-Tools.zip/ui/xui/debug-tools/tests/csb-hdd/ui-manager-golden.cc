// TEST9: execute production CSB controller/Draw with scripted ImGui/SDL/HDD facades.
// This is not a renderer, a real mouse event backend, or an Xbox kernel test.
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <vector>
#include <stdexcept>
#define private public
#include "addons/custom-soundtrack-builder/custom-soundtrack-builder.hh"
#undef private
#include "debug-tools.hh"
#include "debug-tools-module.hh"
#include "detached-tools.hh"
#include <imgui.h>
#include <glib.h>
using namespace XemuCsb;
using Builder = CustomSoundtrackBuilder;
static int checks = 0;
#define CHECK(x) do { ++checks; if (!(x)) throw std::runtime_error(std::string("FAIL line ") + std::to_string(__LINE__) + ": " #x); } while (0)
namespace Fake {
uint64_t ticks=100;
int queued=0, opened_output=0, ffmpeg_lookups=0, reads=0;
HddDestination destination;
HddMusicCatalog catalog;
std::vector<int> ids;
std::vector<bool> disabled;
std::vector<std::string> table_stack,child_stack;
std::map<std::string,std::vector<std::string>> columns;
std::vector<std::string> menus, menu_items, children;
std::set<std::string> popups;
std::string active_popup;
std::string click,select_table,context_table,drop_table,edit_label,edit_text;
int select_id=-1,context_id=-1,drop_id=-1,edit_id=-1;
bool end_drop=false, double_click=false;
ImGuiPayload payload;
std::string payload_type;
ImGuiIO io;
ImDrawList drawlist;
bool blocked(){return std::find(disabled.begin(),disabled.end(),true)!=disabled.end();}
bool activate(const char *s,bool enabled=true){if(enabled&&!blocked()&&click==s){click.clear();return true;}return false;}
const std::string &table(){ static std::string empty;return table_stack.empty()?empty:table_stack.back(); }
int id(){return ids.empty()?-1:ids.back();}
void reset_frame(){
 columns.clear();menus.clear();menu_items.clear();children.clear();ids.clear();disabled.clear();table_stack.clear();child_stack.clear();
 click.clear();select_table.clear();context_table.clear();drop_table.clear();edit_label.clear();edit_text.clear();select_id=context_id=drop_id=edit_id=-1;end_drop=false;double_click=false;payload={};payload_type.clear();
 io.DisplaySize={1480,820};io.MousePos={100,0};io.DeltaTime=1.0f/60;
}
}
namespace ImGui {
ImGuiIO& GetIO(){return Fake::io;} ImVec2 GetContentRegionAvail(){return {600,600};}
bool Begin(const char*,bool*,ImGuiWindowFlags){return true;} void End(){}
void SetNextWindowPos(const ImVec2&,ImGuiCond,const ImVec2&){} void SetNextWindowSize(const ImVec2&,ImGuiCond){}
void SetNextWindowSizeConstraints(const ImVec2&,const ImVec2&,void*,void*){}
void BeginDisabled(bool b){Fake::disabled.push_back(b);}void EndDisabled(){CHECK(!Fake::disabled.empty());Fake::disabled.pop_back();}
bool Button(const char*s,const ImVec2&){return Fake::activate(s);} bool SmallButton(const char*s){return Fake::activate(s);}
bool Combo(const char*,int*,const char*,int){return false;}bool Checkbox(const char*,bool*){return false;}
void SameLine(float,float){}void Text(const char*,...){}void TextDisabled(const char*,...){}void TextWrapped(const char*,...){}
void TextUnformatted(const char*,const char*){}void SetTooltip(const char*,...){}void Separator(){}void SetNextItemWidth(float){}
bool IsItemHovered(int){return false;}void PushID(int id){Fake::ids.push_back(id);}void PopID(){CHECK(!Fake::ids.empty());Fake::ids.pop_back();}
void ProgressBar(float,const ImVec2&,const char*){}
bool InputText(const char*label,char*text,size_t n,ImGuiInputTextFlags,void*,void*){
 if(!Fake::blocked()&&Fake::edit_label==label){std::snprintf(text,n,"%s",Fake::edit_text.c_str());Fake::edit_label.clear();return true;}return false;
}
bool InputInt(const char*label,int*v,int,int,ImGuiInputTextFlags){if(!Fake::blocked()&&Fake::edit_label==label){*v=Fake::edit_id;Fake::edit_label.clear();return true;}return false;}
bool BeginTable(const char*s,int,ImGuiTableFlags,const ImVec2&,float){Fake::table_stack.emplace_back(s);return true;}
void EndTable(){CHECK(!Fake::table_stack.empty());Fake::table_stack.pop_back();}
void TableSetupColumn(const char*s,ImGuiTableColumnFlags,float,unsigned){Fake::columns[Fake::table()].emplace_back(s);}
void TableHeadersRow(){}void TableNextRow(int,float){}bool TableSetColumnIndex(int){return true;}void TableSetupScrollFreeze(int,int){}
float GetFontSize(){return 13;}float GetFrameHeight(){return 21;}
bool BeginChild(const char*s,const ImVec2&,ImGuiChildFlags,ImGuiWindowFlags){Fake::child_stack.emplace_back(s);Fake::children.emplace_back(s);return true;}
void EndChild(){CHECK(!Fake::child_stack.empty());Fake::child_stack.pop_back();}
bool BeginMenuBar(){return true;}void EndMenuBar(){}bool BeginMenu(const char*s,bool enabled){Fake::menus.emplace_back(s);return enabled&&!Fake::blocked();}void EndMenu(){}
bool MenuItem(const char*s,const char*,bool,bool enabled){Fake::menu_items.emplace_back(s);return Fake::activate(s,enabled);}
bool CollapsingHeader(const char*,int){return false;}
bool Selectable(const char*,bool,ImGuiSelectableFlags,const ImVec2&){if(Fake::table()==Fake::select_table&&Fake::id()==Fake::select_id&&!Fake::blocked()){Fake::select_id=-1;return true;}return false;}
bool IsMouseDoubleClicked(int){return Fake::double_click;}
ImVec2 GetItemRectMin(){return {0,0};}ImVec2 GetItemRectMax(){return {600,20};}ImVec2 GetWindowPos(){return {0,0};}ImVec2 GetWindowSize(){return {600,600};}
ImDrawList*GetWindowDrawList(){return &Fake::drawlist;}unsigned GetColorU32(int,float){return 0xffffffffu;}
bool BeginDragDropSource(ImGuiDragDropFlags){return false;}void EndDragDropSource(){}
bool BeginDragDropTarget(){return Fake::table()==Fake::drop_table&&Fake::id()==Fake::drop_id;}
void EndDragDropTarget(){}
bool SetDragDropPayload(const char*,const void*,size_t,ImGuiCond){return false;}
const ImGuiPayload*AcceptDragDropPayload(const char*s,ImGuiDragDropFlags){return Fake::payload_type==s?&Fake::payload:nullptr;}
const ImGuiPayload*GetDragDropPayload(){return Fake::payload.Data?&Fake::payload:nullptr;}
bool BeginPopupContextItem(const char*,ImGuiPopupFlags){return Fake::table()==Fake::context_table&&Fake::id()==Fake::context_id;}
void OpenPopup(const char*s,ImGuiPopupFlags){Fake::popups.insert(s);}
bool BeginPopupModal(const char*s,bool*,ImGuiWindowFlags){if(Fake::popups.count(s)){Fake::active_popup=s;return true;}return false;}
void EndPopup(){}void CloseCurrentPopup(){Fake::popups.erase(Fake::active_popup);}
bool IsWindowHovered(ImGuiHoveredFlags){return false;}float GetScrollY(){return 0;}float GetScrollMaxY(){return 1000;}void SetScrollY(float){}
}
bool ImGuiPayload::IsDataType(const char*s)const{return Fake::payload_type==s;}
void ImDrawList::AddLine(const ImVec2&,const ImVec2&,unsigned,float){}
uint64_t SDL_GetTicks(){return Fake::ticks;}
const char*SDL_GetBasePath(){return "/nonexistent-csb-test/";}
bool SDL_AddEventWatch(SDL_EventFilter,void*){return true;}void SDL_RemoveEventWatch(SDL_EventFilter,void*){}
bool SDL_OpenURL(const char*){++Fake::opened_output;return true;}const char*SDL_GetError(){return "scripted error";}
extern "C" gchar*g_find_program_in_path(const gchar*){++Fake::ffmpeg_lookups;return g_strdup("/usr/bin/ffmpeg");}
void ShowOpenFileDialog(const SDL_DialogFileFilter*,int,const char*,std::function<void(const char*)> cb){cb(nullptr);}
void debug_tools_register_menu_item(int,const char*,bool*){}void debug_tools_register_tick(int,DebugToolsCallback){}
void debug_tools_register_cleanup(int,DebugToolsCallback){}void debug_tools_register_reset(int,DebugToolsCallback){}
void debug_tools_register_deferred_action(int,DebugToolsCallback){}void detached_tools_register(const DetachedToolRegistration&){}
bool debug_tools_queue_background_job(DebugToolsBackgroundJobCallback,void*,DebugToolsBackgroundJobCallback,bool){++Fake::queued;return true;}
namespace XemuCsb {
struct HddSoundtrackInstaller::Impl{};
HddSoundtrackInstaller::HddSoundtrackInstaller():m_impl(new Impl){}HddSoundtrackInstaller::~HddSoundtrackInstaller()=default;
HddDestination DetectCsbHddDestination(){return Fake::destination;}
bool SameCsbHddDestination(const HddDestination&a,const HddDestination&b){return a.available&&b.available&&a.source==b.source&&a.identity==b.identity&&a.selected_path==b.selected_path&&a.mounted_path==b.mounted_path;}
bool CsbHddReady(std::string&){return true;}void OpenCsbHddDirectory(){++Fake::opened_output;}
bool ReadCsbHddMusicCatalog(const HddDestination&,HddMusicCatalog&c,std::string&){++Fake::reads;c=Fake::catalog;return true;}
bool HddSoundtrackInstaller::Start(const HddDestination&,const std::string&,const HddSoundtrackEdit&,std::string&){return true;}
void HddSoundtrackInstaller::Tick(){}void HddSoundtrackInstaller::Cancel(const std::string&,bool){}void HddSoundtrackInstaller::Shutdown(){}
bool HddSoundtrackInstaller::Busy()const{return false;}bool HddSoundtrackInstaller::Succeeded()const{return true;}float HddSoundtrackInstaller::Progress()const{return 0;}
const std::string&HddSoundtrackInstaller::Status()const{static const std::string s="mock status";return s;}
const std::string&HddSoundtrackInstaller::TransferSummary()const{static const std::string s;return s;}
std::string HddSoundtrackInstaller::OutputPath()const{return "/mock/E/music";}
}
static HddMusicCatalog SampleCatalog(){
 HddMusicCatalog c;c.music_exists=c.database_exists=c.database_valid=true;
 c.next_soundtrack_id=2;c.next_song_id=12;c.soundtrack_id_index_consistent=true;
 c.fingerprint.music_exists=c.fingerprint.database_exists=true;c.fingerprint.database_hash=42;c.fingerprint.tree_identity_hash=567;
 for(uint16_t id: {0,1,3}){HddExistingSoundtrack s;s.soundtrack_id=id;s.name="Soundtrack "+std::to_string(id);s.folder_present=true;s.listed_in_database=id!=3;s.folder_bytes=12*1024*1024;
 for(uint16_t n: {7,2,11}){HddExistingTrack t;t.song_id=n;t.title="Track "+std::to_string(n);t.duration_ms=123000;t.file_name=XboxSoundtrackFileName(id,n);t.file_present=true;t.file_size=4*1024*1024;s.tracks.push_back(t);}c.soundtracks.push_back(s);}return c;
}
static void Init(Builder&b){b.is_open=true;b.m_destination={HddSource::Image,"test.qcow2","test.qcow2",123,true,{}};b.m_catalog=SampleCatalog();b.m_catalog_loaded=true;
 Fake::destination=b.m_destination;Fake::catalog=b.m_catalog;b.StartNewSoundtrack();Fake::reset_frame();Fake::popups.clear();}
static std::vector<uint16_t>Ids(const Builder&b){std::vector<uint16_t>v;for(auto&t:b.m_tracks)v.push_back(t.song_id);return v;}
static void CleanJob(Builder&b){delete b.m_active_job;b.m_active_job=nullptr;b.m_build_requested=false;b.m_delete_requested=false;}
int main(int argc,char**argv){try{
 CHECK(argc==2);std::filesystem::create_directories(argv[1]);const std::string dir=argv[1];
 Builder b;Init(b);CHECK(b.m_soundtrack_id==2);CHECK(!b.m_editor_dirty);CHECK(b.m_stream_chunk_index==3);
 b.Draw(true);CHECK(Fake::columns["##csb_existing"]==std::vector<std::string>({"ID","Sound Track Name","Songs Count","Size"}));
 CHECK(Fake::columns["##csb_tracks"]==std::vector<std::string>({"#","Track Name","Xbox File","Duration","Source"}));
 CHECK(Fake::children==std::vector<std::string>({"##csb_editor_panel","##csb_catalog_panel","##csb_track_panel","##csb_status"}));
 CHECK(Fake::menus==std::vector<std::string>({"File","Options","Maximum Write Chunk"}));
 CHECK(Fake::ffmpeg_lookups==0);CHECK(Fake::reads==0); // Rendering does not probe disk/FFmpeg.
 CHECK(std::find(Fake::menu_items.begin(),Fake::menu_items.end(),"Open Last Output")!=Fake::menu_items.end());
 CHECK(std::find(Fake::menu_items.begin(),Fake::menu_items.end(),"Add File")!=Fake::menu_items.end());
 CHECK(std::find(Fake::menu_items.begin(),Fake::menu_items.end(),"Clear Editor")!=Fake::menu_items.end());
 // Single-click the HDD table; no EDIT button required.
 Fake::reset_frame();Fake::select_table="##csb_existing";Fake::select_id=0;b.Draw(true);CHECK(b.m_editing_existing_id==0);CHECK(Ids(b)==std::vector<uint16_t>({7,2,11}));CHECK(!b.m_editor_dirty);
 // Complete-row insertion semantics, NOT swap and NOT ID renumbering.
 auto original=b.m_tracks;CHECK(b.ReorderTrack(7,3,b.m_editor_revision));CHECK(Ids(b)==std::vector<uint16_t>({2,11,7}));
 CHECK(b.m_tracks.back().output_name==original[0].output_name);CHECK(b.m_tracks.back().source_path==original[0].source_path);CHECK(b.m_tracks.back().duration_ms==original[0].duration_ms);
 CHECK(!b.ReorderTrack(7,0,b.m_editor_revision-1));CHECK(!b.ReorderTrack(99,0,b.m_editor_revision));CHECK(!b.ReorderTrack(7,99,b.m_editor_revision));CHECK(!b.ReorderTrack(7,3,b.m_editor_revision));
 CHECK(b.ReorderTrack(7,0,b.m_editor_revision));CHECK(Ids(b)==std::vector<uint16_t>({7,2,11}));
 // Exhaust every move of a larger list against an independent erase/insert oracle.
 for(size_t n=1;n<=30;++n)for(size_t from=0;from<n;++from)for(size_t insertion=0;insertion<=n;++insertion){
  b.m_tracks.clear();for(size_t j=0;j<n;++j){Builder::Track t;t.song_id=static_cast<uint16_t>(j*3+1);t.title=std::to_string(j);t.output_name=std::to_string(j)+".WMA";t.source_path="original/"+t.title;t.duration_ms=static_cast<uint32_t>(j);t.from_hdd=(j%2==0);t.hdd_present=true;b.m_tracks.push_back(t);}
  auto expected=b.m_tracks;auto moving=expected[from];expected.erase(expected.begin()+from);auto to=insertion>from?insertion-1:insertion;expected.insert(expected.begin()+to,moving);b.m_editor_dirty=false;
  CHECK(b.ReorderTrack(static_cast<uint16_t>(from*3+1),insertion,b.m_editor_revision)==(to!=from));CHECK(b.m_editor_dirty==(to!=from));
  for(size_t j=0;j<n;++j){CHECK(b.m_tracks[j].song_id==expected[j].song_id);CHECK(b.m_tracks[j].source_path==expected[j].source_path);CHECK(b.m_tracks[j].output_name==expected[j].output_name);CHECK(b.m_tracks[j].duration_ms==expected[j].duration_ms);CHECK(b.m_tracks[j].from_hdd==expected[j].from_hdd);}
 }
 // The full supported 504-row playlist also preserves IDs at its extreme boundaries.
 b.m_tracks.clear();for(uint16_t i=0;i<504;++i){Builder::Track t;t.song_id=i;t.title=std::to_string(i);t.output_name=XboxSoundtrackFileName(0,i);b.m_tracks.push_back(t);}
 CHECK(b.ReorderTrack(0,504,b.m_editor_revision));CHECK(b.m_tracks.back().song_id==0);CHECK(b.m_tracks.front().song_id==1);
 CHECK(b.ReorderTrack(0,0,b.m_editor_revision));CHECK(b.m_tracks.front().song_id==0);CHECK(b.m_tracks.back().song_id==503);
 b.LoadExistingSoundtrack(0);
 // The actual Draw drop branch inserts above or below a row, only on delivery.
 struct Drag {uint64_t revision;uint16_t song_id;};Drag d{};d.revision=b.m_editor_revision;d.song_id=7;
 Fake::reset_frame();Fake::drop_table="##csb_tracks";Fake::drop_id=11;Fake::payload={&d,sizeof(d),false};Fake::payload_type="XEMU_CSB_TRACK_ORDER";Fake::io.MousePos.y=19;b.DrawTrackTable();CHECK(Ids(b)==std::vector<uint16_t>({7,2,11}));
 Fake::payload.Delivery=true;Fake::payload.DataSize=1;b.DrawTrackTable();CHECK(Ids(b)==std::vector<uint16_t>({7,2,11}));
 Fake::payload.DataSize=sizeof(d);b.DrawTrackTable();CHECK(Ids(b)==std::vector<uint16_t>({2,11,7}));CHECK(b.m_editor_dirty);
 auto after=Ids(b);b.DrawTrackTable();CHECK(Ids(b)==after); // Stale drag cannot repeat.
 d.revision=b.m_editor_revision;Fake::drop_id=2;Fake::io.MousePos.y=0;b.DrawTrackTable();CHECK(Ids(b)==std::vector<uint16_t>({7,2,11}));
 d.revision=b.m_editor_revision;Fake::drop_id=-1;b.DrawTrackTable();CHECK(Ids(b)==after); // Dedicated end-of-list drop target.
 // Dirty switching retains the old editor until user explicitly discards.
 b.RequestEditorAction(Builder::EditorAction::Select,1);CHECK(b.m_pending_action==Builder::EditorAction::Select);CHECK(b.m_editing_existing_id==0);
 Fake::reset_frame();Fake::click="KEEP EDITING";b.DrawDialogs();CHECK(b.m_pending_action==Builder::EditorAction::None);CHECK(b.m_editing_existing_id==0);CHECK(b.m_editor_dirty);
 b.RequestEditorAction(Builder::EditorAction::Select,0);CHECK(b.m_pending_action==Builder::EditorAction::None);CHECK(Ids(b)==after);
 b.RequestEditorAction(Builder::EditorAction::Select,1);Fake::click="DISCARD CHANGES";b.DrawDialogs();CHECK(b.m_editing_existing_id==1);CHECK(!b.m_editor_dirty);
 // Refresh/source drift during confirmation does not discard or retarget edits.
 b.RemoveTrack(0);auto kept=Ids(b);b.RequestEditorAction(Builder::EditorAction::New);b.m_catalog.fingerprint.database_hash++;
 Fake::click="DISCARD CHANGES";b.DrawDialogs();CHECK(Ids(b)==kept);CHECK(b.m_editor_dirty);CHECK(b.m_status.find("kept")!=std::string::npos);
 // New, Clear and right-click removal remain pending; no filesystem job is queued.
 b.StartNewSoundtrack();const std::string wav=dir+"/sample.wav";{std::ofstream f(wav);f<<"test fixture";}
 b.AddTrack(wav);CHECK(b.m_tracks.size()==1);CHECK(b.m_editor_dirty);CHECK(b.m_tracks[0].song_id==12);
 Fake::reset_frame();Fake::edit_label="##soundtrack_id";Fake::edit_id=5;b.DrawEditorPanel();CHECK(b.m_soundtrack_id==5);CHECK(b.m_tracks[0].output_name=="0005000C.WMA");
 b.RequestEditorAction(Builder::EditorAction::Clear);CHECK(b.m_tracks.size()==1);Fake::click="KEEP EDITING";b.DrawDialogs();CHECK(b.m_tracks.size()==1);
 b.RequestEditorAction(Builder::EditorAction::Clear);Fake::click="CLEAR EDITOR";b.DrawDialogs();CHECK(b.m_tracks.empty());CHECK(b.m_editor_dirty);CHECK(Fake::queued==0);
 b.LoadExistingSoundtrack(0);Fake::reset_frame();Fake::context_table="##csb_tracks";Fake::context_id=2;Fake::click="Delete";b.DrawTrackTable();CHECK(Ids(b)==std::vector<uint16_t>({7,11}));CHECK(b.m_editor_dirty);CHECK(Fake::queued==0);
 CHECK(b.FindExisting(0)->tracks.size()==3); // Actual cached installed catalog unchanged.
 // Double-click/context Rename retains inline-edit capability without a permanently active textbox.
 b.RequestTrackRename(7);CHECK(b.m_rename_song_id==7);Fake::reset_frame();Fake::edit_label="##rename_track";Fake::edit_text="Renamed song";Fake::click="APPLY NAME";b.DrawDialogs();CHECK(b.m_tracks[0].title=="Renamed song");CHECK(b.m_rename_song_id==-1);
 // Orphan inspection is read-only and never invents a DB record.
 b.LoadExistingSoundtrack(3);CHECK(b.m_viewing_orphan);CHECK(b.m_tracks.size()==3);CHECK(b.m_selected_soundtrack_id==3);CHECK(b.EditorReadOnly());b.RemoveTrack(0);CHECK(b.m_tracks.size()==3);CHECK(!b.ReorderTrack(7,3,b.m_editor_revision));b.AddTrack(wav);CHECK(b.m_tracks.size()==3);
 std::string error;CHECK(!b.ValidateBeforeBuild(error));CHECK(b.CatalogAsStDb().size()==2);
 // Soundtrack right-click Delete needs an explicit modal confirmation; then freezes the source/catalog.
 Fake::reset_frame();Fake::context_table="##csb_existing";Fake::context_id=3;Fake::click="Delete";b.DrawExistingCatalog();CHECK(b.m_pending_delete_id==3);CHECK(Fake::queued==0);
 Fake::click="CANCEL DELETE";b.DrawDialogs();CHECK(b.m_pending_delete_id==-1);CHECK(Fake::queued==0);
 b.RequestEditorAction(Builder::EditorAction::Delete,3);b.m_catalog.fingerprint.tree_identity_hash++;b.StartDelete(3);CHECK(b.m_active_job==nullptr);CHECK(Fake::queued==0);CHECK(b.m_status.find("changed after")!=std::string::npos);b.m_pending_delete_id=-1;
 b.RequestEditorAction(Builder::EditorAction::Delete,3);b.StartDelete(3);CHECK(b.m_active_job!=nullptr);CHECK(b.m_active_job->edit.fast_stream);CHECK(b.m_active_job->edit.stream_chunk_bytes==4194304);CHECK(b.m_active_job->edit.delete_soundtrack);CHECK(b.m_active_job->db_write_options.minimum_next_song_id==12);CHECK(b.m_active_job->db_write_options.minimum_next_soundtrack_id==2);CleanJob(b);b.m_pending_delete_id=-1;
 // Selection/drag/menu mutations cannot run while SAVE is queued (before active_job exists).
 b.LoadExistingSoundtrack(0);b.m_build_requested=true;auto frozen=Ids(b);b.RemoveTrack(0);CHECK(Ids(b)==frozen);CHECK(!b.ReorderTrack(7,3,b.m_editor_revision));b.StartNewSoundtrack();CHECK(b.m_editing_existing_id==0);
 Fake::reset_frame();Fake::click="512 KiB";b.DrawMenuBar();CHECK(b.m_stream_chunk_index==3);b.m_build_requested=false;
 // A clean loaded soundtrack does not offer a redundant HDD republish, unless
 // the dashboard soundtrackIds[] index is known to need a one-time repair.
 b.LoadExistingSoundtrack(0);Fake::reset_frame();Fake::click=b.m_destination.ButtonLabel();b.DrawEditorPanel();CHECK(!b.m_build_requested);
 b.m_catalog.soundtrack_id_index_consistent=false;Fake::reset_frame();Fake::click=b.m_destination.ButtonLabel();b.DrawEditorPanel();CHECK(b.m_build_requested);b.m_build_requested=false;b.m_catalog.soundtrack_id_index_consistent=true;
 b.MarkEditorChanged();Fake::click=b.m_destination.ButtonLabel();b.DrawEditorPanel();CHECK(b.m_build_requested);b.m_build_requested=false;
 // Chunk selection and both build paths always lease Fast Stream and freeze selection.
 for(int i=0;i<4;++i){static const char*labels[]={"512 KiB","1 MiB","2 MiB","4 MiB (default)"};Fake::reset_frame();Fake::click=labels[i];b.DrawMenuBar();CHECK(b.m_stream_chunk_index==i);b.StartBuild();CHECK(b.m_active_job!=nullptr);CHECK(b.m_active_job->edit.fast_stream);CHECK(b.m_active_job->edit.stream_chunk_bytes==kCsbStreamChunks[i]);
  Fake::reset_frame();Fake::click=labels[(i+1)%4];b.DrawMenuBar();CHECK(b.m_stream_chunk_index==i);CleanJob(b);
 }
 // Reordered stable IDs round-trip through the REAL multi-track ST.DB writer/parser.
 b.ReorderTrack(7,3,b.m_editor_revision);b.StartBuild();CHECK(b.m_active_job!=nullptr);CHECK(b.m_active_job->tracks[0].song_id==2);
 auto db=b.CatalogAsStDb();db[0].tracks.clear();for(const auto&t:b.m_active_job->tracks)db[0].tracks.push_back({t.song_id,t.duration_ms,t.title});
 CHECK(WriteStDb(dir+"/ST.DB",db,error));std::vector<StDbSoundtrack>roundtrip;CHECK(ReadStDbFile(dir+"/ST.DB",roundtrip,error));CHECK(roundtrip[0].tracks[0].song_id==2);CHECK(roundtrip[0].tracks[2].song_id==7);CHECK(roundtrip[1].tracks[0].song_id==7);CleanJob(b);
 // Open Last Output stays a deferred navigation action.
 b.m_last_output="E:/TDATA/fffe0000/music";b.m_last_destination=b.m_destination;Fake::reset_frame();Fake::click="Open Last Output";b.DrawMenuBar();CHECK(b.m_open_output_requested);CHECK(Fake::opened_output==0);
 b.m_next_destination_refresh=b.m_next_catalog_refresh=100000;b.m_catalog_refresh_requested=false;b.ProcessDeferredActions();CHECK(Fake::opened_output==1);CHECK(!b.m_open_output_requested);
 // Reset invalidates drag/rename and dismisses modal intents without deleting pending rows.
 b.RequestEditorAction(Builder::EditorAction::New);b.DrawDialogs();CHECK(!Fake::popups.empty());auto old_revision=b.m_editor_revision;b.OnReset();b.DrawDialogs();CHECK(Fake::popups.empty());CHECK(b.m_editor_revision>old_revision);CHECK(!b.m_tracks.empty());
 // Keep a full UTF-8 encoding of a valid 63-unit ST.DB name during a reorder/save.
 Builder utf;Init(utf);std::string long_name;for(int i=0;i<63;++i)long_name+="\xE6\xAD\x8C";
 utf.m_catalog.soundtracks[0].name=long_name;utf.LoadExistingSoundtrack(0);CHECK(std::string(utf.m_soundtrack_name)==long_name);
 CHECK(utf.ReorderTrack(7,3,utf.m_editor_revision));utf.StartBuild();CHECK(utf.m_active_job!=nullptr);CHECK(utf.m_active_job->soundtrack_name==long_name);
 auto names=utf.CatalogAsStDb();CHECK(WriteStDb(dir+"/unicode-ST.DB",names,error));CHECK(ReadStDbFile(dir+"/unicode-ST.DB",roundtrip,error));CHECK(roundtrip[0].name==long_name);CleanJob(utf);
 // Local clear/new remain usable without an available HDD; they cannot perform writes.
 Builder offline;Init(offline);offline.m_destination={};offline.m_catalog={};offline.m_catalog_loaded=false;
 offline.AddTrack(wav);CHECK(offline.m_tracks.size()==1);offline.RequestEditorAction(Builder::EditorAction::Clear);
 Fake::reset_frame();Fake::click="CLEAR EDITOR";offline.DrawDialogs();CHECK(offline.m_tracks.empty());
 CHECK(offline.m_editor_dirty);CHECK(!offline.ValidateBeforeBuild(error));
 CHECK(Fake::ids.empty());CHECK(Fake::disabled.empty());CHECK(Fake::table_stack.empty());CHECK(Fake::child_stack.empty());
 std::printf("PASS: TEST12 production UI/controller scripted facade (%d checks; no real ImGui renderer or Xbox execution)\n",checks);return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
