# CSB TEST12 dashboard-format fix + TEST11 recovery / TEST8 stream tests

Run from this directory or provide each script's full path. These tests create
isolated temporary trees and synthetic files; they do not mutate user HDDs.
They are not full XEMU builds.

```sh
python3 run-ui.py --compiler g++
python3 run-ui.py --compiler clang++
python3 run-ui.py --compiler clang++ --sanitizers
python3 run.py --compiler g++
python3 run.py --compiler clang++
python3 run.py --compiler clang++ --sanitizers
python3 run-rpc.py --compiler g++
python3 run-rpc.py --compiler clang++
python3 run-rpc.py --compiler clang++ --sanitizers
python3 run-stream.py --compiler g++
python3 run-stream.py --compiler clang++
python3 run-stream.py --compiler clang++ --sanitizers
python3 run-lowlevel.py --compiler g++
python3 run-lowlevel.py --compiler clang++
python3 run-lowlevel.py --compiler clang++ --sanitizers
python3 run-syntax.py --compiler g++
python3 run-syntax.py --compiler clang++
python3 run-ffmpeg.py --compiler g++ --ffmpeg ffmpeg
```

`run-ui.py` links the actual production CSB controller and Draw code plus the
ST.DB core to scripted ImGui/SDL/HDD facades. It tests the exact table headings,
menus, single-click selection, dirty-state confirmations, read-only orphan
inspection, queued-job locks, frozen delete confirmation, deferred navigation,
track rename/delete, delivered/stale drag payloads and maximum chunk policy.
It exhausts 9,920 insertion cases (list sizes 1..30), checking every resulting
row against an independent erase/insert oracle. Stable Xbox IDs, source paths,
filenames, durations and source kinds must travel with the row. A reordered
playlist also round-trips through the real ST.DB writer/parser. Its assertion
count includes per-row properties and UI-stack balance checks; it is NOT a count
of independent real-world scenarios. This is not a real ImGui renderer or SDL
mouse event test and does not prove visual layout or real drag/drop behavior.

`run.py` compiles the production catalog, TEST11 isolated-recovery installer,
TEST12 ST.DB reader/writer/allocation changes, HDD planning/sequence entry points,
FATX parser and source streaming/hash code. `hdd-install-golden.cc` simulates Xbox execution, block
source/settings and snapshots. It checks incremental add/edit/delete, data/cluster
preservation, the `TDATA/CSBBACKUP/CSB-<token>` transaction layout,
`database.new`/`database.bak` naming, selected-folder-only backup, database-last
publication, fresh installed readback, guarded rollback, legacy recovery
preservation, low space, source changes, cancellation, cleanup retention and
Folder-HDD synchronization failure. It also runs the ST.DB golden covering `soundtrackIds[100]`, packed 32-bit song
IDs, database-wide `nextSongId`, monotonic next-ID floors and malformed-index
detection, plus the reduced-profile backend linkage test.

`run-rpc.py` is a separate executor test: it compiles the **real production**
`guest-kernel-rpc.cc`, `guest-kernel-rpc-completion.cc` and
`guest-kernel-rpc-filesystem.cc`, with their planner/stream dependencies.
`rpc-scheduler-golden.cc` explicitly simulates CPU registers, time, VM stop/start,
BQL, arena mapping, breakpoints and kernel return values. Production code emits
actual stub bytes but those x86 bytes are not executed. This distinguishes
scheduling/completion testing from real Xbox/FATX kernel execution. It covers
long safe-point waits, cancellation ownership, paused/title-changed states,
IRQL rejection, bounded continuation, restored context and fail-closed timeout.

`run-stream.py` adds the actual TEST8 scheduler, stream completion handler and
protocol emitter. `stream-stub-vm.hh` is a test-only interpreter for the exact
emitted instruction subset, with simulated Xbox stdcall handlers. Unknown
instructions and unexpected argument/buffer access fail the test. It is NOT a
complete x86 emulator or real Xbox kernel. Its 853 checks run after the 42
legacy scheduler checks, covering chunk boundaries through 64 MiB, one-handle
lifetime, exclusive create, exact writes, delayed completion, cancellation,
short/pending/failed calls, source changes, final readback rejection and unsafe
ownership retention. Both host-file and retained-FATX streams are covered.
TEST8 runs each supported 512 KiB / 1 MiB / 2 MiB / 4 MiB policy through empty,
one-byte, exact/adjacent chunk, multi-chunk and 64 MiB transfers. It rejects invalid
sizes, checks the sequence policy is frozen, validates real host-buffer reuse and
nonsequential offsets, and injects large-write cancellation/short/pending/timeouts.

`run-lowlevel.py` compiles the production C arena implementation with QEMU
platform bindings simulated, testing size limits, PTE/PDE mapping, translations,
BQL ownership and failed-release retention (287 checks). It also compiles the real
FATX parser and snapshot service against sparse FATX byte fixtures (27 checks),
including a single coherent readback, short/corrupt/looping data and pause/error
handling. A Windows close/read/write macro facade compiles the public stream
header at all four payload sizes and rejects overflowing addresses; this is not
a Windows SDK test. Arena tests include an independent page walker over the
production-emitted PDE/PTE bytes, a complete 4 MiB two-span refill crossing the
PDE boundary, occupied adjacent PDEs, original nonpresent PDE restoration, and
errors both before and after mutation of either PDE during installation/release.
Refills reject invalid spans before touching any bytes; successful two-span
refills perform one notification/translation synchronization. Partial release
cannot resume or reuse the mapping; a verified cleanup retry remains possible.

The high-level installer now has 171 scenario checks. It retains TEST11 cases for
a deliberately corrupted post-publication WMA, guarded rollback, preservation of
old `music.CSB-*` recovery folders, unrelated/manual `CSBBACKUP` retention,
database-last move ordering, temporary-DB naming, staged-database mutation,
cleanup failure and Folder-HDD sync failure. TEST12 adds malformed
`soundtrackIds[]` detection and a no-content-change SAVE repair case that must
rewrite the dashboard index through the same isolated transaction while preserving
the soundtrack files/records and next-ID counters.
Platform/executor simulation remains explicit; fixtures are not measurements of
actual emulator throughput.

`--keep` retains the isolated test tree. `--sanitizers` enables AddressSanitizer
and UndefinedBehaviorSanitizer. The scheduler test's private-state inspection is
test-only and never added to the production class interface.

`run-syntax.py` checks both FFmpeg process branches in the complete CSB UI using
SDL/ImGui/Win32 declaration facades. This is not a MinGW/Windows SDK build or GUI
runtime test. `run-ffmpeg.py` uses the real host FFmpeg with synthetic silence,
checking production WMA2/duration/ST.DB parsing and rejection cases. No FFmpeg
binary or audio collection is bundled.

All facades live under `tests/csb-hdd/stubs/` and are excluded from production
Meson sources. See `VALIDATION.md` for results and remaining acceptance work.
