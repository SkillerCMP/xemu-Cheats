// Real FATX bytes/parser + real production final-readback service. Only the
// mounted block interface and pause/Folder-HDD platform bindings are simulated.
#define main ExistingFatxGolden
#include "../fatx-hdd-golden.cpp"
#undef main
#include "addons/hdd/hdd-snapshot-service.hh"
#include "addons/hdd/kernel-rpc-filesystem.hh"
#include "disc-block-io.h"
#include "guest-pause-guard.hh"
static SparseImage mounted_image;
static bool available=true,vm_running=true,allow_pause=true,fail_data_read=false;
static unsigned ref_count=0,pause_calls=0,resume_calls=0,super_reads=0;
static uint64_t data_read_bytes=0;
static const uint64_t e_data=DataOffset(kEOffset,kESize);
extern "C" {
XemuDiscBlockHandle xemu_disc_block_acquire_by_name(const char *name){assert(!std::strcmp(name,"ide0-hd0"));++ref_count;return &mounted_image;}
void xemu_disc_block_release(XemuDiscBlockHandle){assert(ref_count);--ref_count;}
bool xemu_disc_block_is_available(XemuDiscBlockHandle){return available;}
int64_t xemu_disc_block_get_length(XemuDiscBlockHandle){return kRetailDiskSize;}
bool xemu_disc_block_pread(XemuDiscBlockHandle h,uint64_t off,void *out,size_t n){
 assert(!vm_running&&ref_count==1);
 if(off==kEOffset)++super_reads;
 if(off>=e_data+kClusterSize){data_read_bytes+=n;if(fail_data_read)return false;}
 return SparseRead(h,off,out,n);
}
bool cmp_folder_hdd_is_active(void){return false;}
bool cmp_folder_hdd_rescan_active(char**){return false;}
char *cmp_folder_hdd_get_last_sync_error(void){return nullptr;}
}
XemuDebugGuestPauseGuard::XemuDebugGuestPauseGuard(){m_was_running=vm_running;m_valid=allow_pause;if(m_valid){if(vm_running){++pause_calls;vm_running=false;m_resume=true;}m_stopped=true;}}
XemuDebugGuestPauseGuard::~XemuDebugGuestPauseGuard(){Resume();}
void XemuDebugGuestPauseGuard::Resume(){if(m_resume){vm_running=true;++resume_calls;m_resume=false;}}
static std::vector<uint8_t> Prepare(uint32_t size){
 mounted_image={};available=vm_running=allow_pause=true;fail_data_read=false;assert(ref_count==0);
 pause_calls=resume_calls=super_reads=0;data_read_bytes=0;
 AddPartitionSuperblock(mounted_image,kEOffset,0x11223344,1);
 std::vector<uint8_t> root(kClusterSize,0xff);AddEntry(root,0,"track.wma",0x20,2,size,1,2);
 mounted_image.chunks[e_data]=root;SetFatEntry(mounted_image,kEOffset,kESize,1,0xffffffffu);
 std::vector<uint8_t> data(size);for(size_t i=0;i<data.size();++i)data[i]=static_cast<uint8_t>((i*71+i/457)%256);
 mounted_image.chunks[e_data+kClusterSize]=data;
 const uint32_t clusters=(size+kClusterSize-1)/kClusterSize;
 for(uint32_t n=0;n<clusters;++n)SetFatEntry(mounted_image,kEOffset,kESize,n+2,n+1==clusters?0xffffffffu:n+3);
 return data;
}
int main(){
 ExistingFatxGolden();unsigned checks=0;std::string error;auto check=[&](bool b){if(!b)std::cerr<<"Readback failure "<<checks+1<<": "<<error<<" super="<<super_reads<<" data="<<data_read_bytes<<" pause="<<pause_calls<<" resume="<<resume_calls<<" refs="<<ref_count<<"\n";assert(b);++checks;};
 for(uint32_t n:{0u,1u,524288u,524289u,4194341u}){
   auto data=Prepare(n);uint64_t hash=XemuKernelFs::UpdateContentHash(XemuKernelFs::kContentHashBasis,data.data(),data.size());
   check(hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},n,hash,error));
   check(super_reads==1&&data_read_bytes==n&&pause_calls==1&&resume_calls==1&&ref_count==0);
   vm_running=false;check(hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},n,hash,error)&&!vm_running&&ref_count==0);
   check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},n,hash^1,error)&&!vm_running);
 }
 auto data=Prepare(524289);auto hash=XemuKernelFs::UpdateContentHash(XemuKernelFs::kContentHashBasis,data.data(),data.size());
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"missing"},data.size(),hash,error)&&vm_running&&ref_count==0);
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size()-1,hash,error));
 mounted_image.chunks[e_data+kClusterSize].back()^=0x80;
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size(),hash,error));
 Prepare(524289);SetFatEntry(mounted_image,kEOffset,kESize,2,2); // looping allocation chain
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size(),hash,error));
 Prepare(524289);fail_data_read=true;
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size(),hash,error));
 Prepare(524289);allow_pause=false;
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size(),hash,error)&&super_reads==0&&ref_count==0);
 Prepare(524289);available=false;
 check(!hdd_snapshot_service.VerifyFatxFileHash('E',{"track.wma"},data.size(),hash,error)&&super_reads==0&&ref_count==0);
 std::cout<<"PASS: production coherent readback on sparse FATX bytes ("<<checks<<" checks); block/pause bindings simulated\n";
}
