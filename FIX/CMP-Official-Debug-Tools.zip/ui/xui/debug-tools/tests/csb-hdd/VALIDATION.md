# CSB TEST12 — Dashboard ST.DB Format Fix

## Baseline and scope

TEST12 is built directly from the completed TEST11 isolated-recovery package:

- `xemu-Cheats-CSB-TEST11-isolated-recovery.zip`
- SHA-256 `0C5D7B7766D15AD10DD03AADC81225C6B9E607DE88E8E8B18D04762A659B7DC4`

TEST11 itself was built from the exact TEST9 side-by-side-manager baseline
(SHA-256 `A0B29D3CEC24DF8944C02EBC692657480BA26D87689BBE6D2A3C279F8C253A38`).
TEST12 retains TEST11's isolated `E:/TDATA/CSBBACKUP` transaction and guarded
rollback. It also retains TEST9's side-by-side manager, drag/drop behavior,
context menus and external-FFmpeg conversion behavior plus TEST8's 4 MiB Fast
Stream/RPC/arena path. TEST10 audio preview/player, WMA passthrough and internal
FFmpeg integration are not reintroduced.

The production change is narrowly targeted at ST.DB header/index/counter
compatibility and the controller plumbing needed to repair an existing malformed
header with the normal guarded SAVE path.

## Real Xbox dashboard capture used as the format oracle

The user's dashboard created a copy of soundtrack `222bblk{` as soundtrack ID
`0004`. The captured title-data tree is external test input and is not bundled:

- `fffe0000.zip`: SHA-256
  `41FC2862B229FB4C3DA62FF3D2507E85CE34967A4B3BAEFE3FC55F7F3D939A2B`
- captured post-copy `music/ST.DB`: 58,368 bytes, SHA-256
  `825CD9D162787C649C5A3E62816ABF2C3CF78B3E2928979CDEC9B7D18FED007F`

The capture demonstrates these concrete properties:

- four soundtrack records exist with IDs `0, 1, 3, 4`;
- the inherited malformed main-header `soundtrackIds[]` entries are
  `[3, 0, 0, 4]`, because the dashboard appended ID 4 but did not repair the
  older CSB-written entries;
- `nextSoundtrackId` is 5;
- the dashboard-created ID `0004` consumes song serials 31 through 44 and advances
  `nextSongId` from 31 to 45;
- its physical files are `0004001F.WMA` through `0004002C.WMA` in folder `0004`;
- the song-group table continues to store packed 32-bit song IDs in the form
  `(soundtrackId << 16) | songSerial`, with up to six entries per metadata group.

The user's dashboard-created `Soundtrack 1` has a real title only for its first
track; the remaining title fields in the captured ST.DB are blank. The dashboard's
`Track 2`, `Track 3`, etc. labels are therefore fallback display text. TEST12 does
not fabricate names for those blank records.

## Implemented format/allocation fixes

### Correct `soundtrackIds[100]` header index

Previous CSB writers stored only the maximum soundtrack ID at offset `0x000C`.
TEST12 writes every active soundtrack record ID into the corresponding 32-bit
header slot and validates the header index against the record table when reading.
A mismatch is surfaced as a catalog warning rather than being silently accepted.

### Dashboard-compatible song allocation

Existing packed song values remain unchanged. For a new local track, TEST12 now
starts at ST.DB `nextSongId` and checks the candidate serial against every listed
soundtrack plus the current editor before allocating it. It no longer starts the
low 16-bit serial again inside each XEMU-created soundtrack.

New soundtrack IDs similarly start at the existing `nextSoundtrackId` and skip
listed/orphan collisions. Existing song IDs remain stable during reorder/retain.

### Monotonic next-ID counters

The writer accepts minimum/floor values from the source catalog for both
`nextSoundtrackId` and `nextSongId`. Delete/edit therefore cannot move the
counters backward just because the current highest ID disappeared.

### Guarded repair SAVE

Normally an unchanged loaded soundtrack keeps SAVE disabled. If the catalog's
`soundtrackIds[]` index does not match its soundtrack records, TEST12 enables SAVE
for a listed existing soundtrack even with no track edits. That operation preserves
its current songs/files while rebuilding ST.DB through TEST11's same staged,
verified, database-last transaction.

## Capture rewrite oracle

The production TEST12 reader/writer was run against the captured 58,368-byte
post-dashboard-copy ST.DB with its original counter values supplied as floors.
The result:

- remained exactly 58,368 bytes;
- retained `nextSoundtrackId = 5`;
- retained `nextSongId = 45`;
- changed `soundtrackIds[]` from `[3, 0, 0, 4]` to `[0, 1, 3, 4]`;
- was byte-for-byte identical from offset `0x200` through EOF;
- differed at only three bytes in the header (`0x0C`, `0x10`, `0x14`);
- resulting SHA-256:
  `B0EBD676B1313AAA9C6C4F85ACB9E7268EDA549CE71FF5BE0D9B55A788B1AC2C`.

This is strong authoring-side evidence that the repair targets only the malformed
header index in this capture. It is not a substitute for testing the result in the
real Xbox dashboard under XEMU.

## TEST11 recovery behavior retained

Every save/delete still uses one transaction outside `fffe0000`:

```text
E:/TDATA/CSBBACKUP/CSB-<16-hex>/
  stage/
    <selected ID>/...
    database.new
  backup/
    <selected ID>/...
    database.bak
```

Only the selected soundtrack and existing database are backed up. New files and
`database.new` are staged and verified first. The selected soundtrack is published
before `music/ST.DB`; the database is published last. A fresh installed-file and
ST.DB verification follows. Folder-HDD sync follows that verification. Only then
may the current transaction be removed. Legacy `music.CSB-stage-*` and
`music.CSB-backup-*` siblings are not automatically deleted.

Failures still use guarded rollback. Ambiguous move results, unsafe restore paths,
source changes, cancellation and uncertain cleanup retain recovery data and report
its exact paths.

## Executed checks

- Production TEST12 catalog/installer/core: **171 scenario checks**, passed GCC and
  Clang AddressSanitizer/UndefinedBehaviorSanitizer.
- TEST12 ST.DB golden: header ID array, packed 32-bit song IDs, database-wide
  `nextSongId`, monotonic next-ID floors and malformed-index detection passed.
- Guarded no-content-change header repair scenario passed through the production
  TEST11 transaction/verification path.
- Production CSB UI/controller: **1,148,482 scripted checks**, passed GCC and Clang
  ASan/UBSan. The 9,920 reorder matrix and 504-row boundary coverage remain.
- Complete CSB declaration syntax: POSIX and Win32 process branches passed GCC and
  Clang declaration-facade compilation.
- CSB integration static guards: **106 checks**.
- TEST8 Fast Stream/emitted-instruction interpreter: **853 checks** plus **42 RPC
  scheduler checks**, passed GCC and Clang ASan/UBSan.
- Production C arena: **287 checks**; coherent FATX readback: **27 checks**; passed
  GCC and Clang ASan/UBSan.
- Real host external FFmpeg fixture: **7 checks** for WMA2/duration/ST.DB plus
  rejection fixtures.
- File Replace v3.16 native core: **6,572 assertions**; isolated C bridge:
  **166 assertions / 41 physical-span reads**; legacy overlay/XDVDFS/syntax passed.
- Compact Manifest v4 golden passed.

Expected failure diagnostics from installer negative cases are deliberately
injected failure/cancellation/recovery paths, not unexplained runtime failures.
The executor/kernel/FATX behavior is simulated where the individual test suite
states so; no user HDD is mutated by these tests.

## Exact TEST11 -> TEST12 boundary

Production files changed:

```text
addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc
addons/custom-soundtrack-builder/custom-soundtrack-builder-core.hh
addons/custom-soundtrack-builder/custom-soundtrack-builder.cc
addons/custom-soundtrack-builder/custom-soundtrack-builder.hh
addons/custom-soundtrack-builder/custom-soundtrack-hdd.cc
addons/custom-soundtrack-builder/custom-soundtrack-hdd.hh
```

Test coverage changed:

```text
tests/csb-core-golden.cpp
tests/csb-hdd/hdd-install-golden.cc
tests/csb-hdd/ui-manager-golden.cc
tests/v316-csb-integration-golden.py
```

Documentation changed:

```text
addons/custom-soundtrack-builder/README.md
tests/csb-hdd/README.md
tests/csb-hdd/VALIDATION.md
```

TEST11's recovery transaction implementation remains in the same HDD orchestrator;
its recovery paths/publication ordering were not redesigned by TEST12. Shared
Fast Stream/RPC/arena, HDD Directory, Folder-HDD, external FFmpeg conversion,
File Replace, CheatDB, official XEMU source, patches and build drivers are not
modified by this update.

## Runtime acceptance still required

No complete Windows XEMU executable or live Xbox-dashboard write is executed by
this authoring environment. Use a backed-up/test HDD image and the normal Windows
builder with the same external `ffmpeg.exe` arrangement as TEST9/TEST11.

For the user's currently malformed collection, select a normal ST.DB-listed
soundtrack (for example `222bblk{`) after Refresh. TEST12 should show the dashboard
index warning and allow SAVE even with no track edit. After the guarded SAVE and a
clean dashboard refresh/restart, verify soundtrack names, track names, durations
and playback. Then create a new small soundtrack and verify its filenames begin at
or above the current global `nextSongId` rather than restarting at zero.

`Soundtrack 1` tracks 2-14 are expected to remain generic/blank until their actual
ST.DB title fields are renamed; TEST12 intentionally does not invent metadata.
