#!/usr/bin/env python3
"""Execute real RPC scheduling/completion code with simulated CPU/arena/FATX.
Includes a small emitted-instruction interpreter with simulated syscalls, not an actual Xbox or full xemu build. No host HDD images are modified.
"""
from pathlib import Path
import argparse, shutil, subprocess, tempfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true');p.add_argument('--keep',default='');a=p.parse_args()
dt=Path(__file__).resolve().parents[2]
def run(root):
 d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
 (d/'current-game.hh').write_text('''#pragma once
#include <cstdint>
class CurrentGameManager { public:
struct GameInfo { bool valid=true; uint32_t title_id=1, xbe_image_size=0x100000, xbe_base=0x10000; };
GameInfo info; const GameInfo &Get() const { return info; }
}; extern CurrentGameManager current_game_manager;
''')
 stubs=d/'tests/csb-hdd/stubs'
 (stubs/'system/runstate.h').write_text('''#pragma once
enum RunState { RUN_STATE_PAUSED = 0 };
bool runstate_is_running(void); void vm_start(void); int vm_stop(RunState);
''')
 cmd=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-I'+str(stubs),'-I'+str(d)]
 if a.sanitizers:cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
 sources=[d/'tests/csb-hdd/rpc-stream-golden.cc',*[d/'addons/hdd'/s for s in ('guest-kernel-rpc.cc','guest-kernel-rpc-completion.cc','guest-kernel-rpc-filesystem.cc','guest-kernel-rpc-stream.cc','kernel-rpc-filesystem.cc','kernel-rpc-filesystem-stream.cc','fatx-hdd.cc')]]
 exe=root/'rpc-stream-golden';cmd+=[*map(str,sources),'-o',str(exe)]
 print('+',' '.join(cmd),flush=True);subprocess.run(cmd,check=True)
 subprocess.run([str(exe),str(root/'track.bin')],check=True)
if a.keep:
 root=Path(a.keep);root.mkdir(parents=True,exist_ok=False);run(root)
else:
 with tempfile.TemporaryDirectory(prefix='csb-rpc-test-') as t:run(Path(t))
