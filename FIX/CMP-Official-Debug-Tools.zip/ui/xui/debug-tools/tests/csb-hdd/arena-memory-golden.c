// Compiles the production C arena implementation against a small QEMU-memory
// facade. Exercises actual bounds/page ownership/BQL code, NOT a real machine.
#include <test-qemu.h>
#include "addons/hdd/guest-kernel-rpc-memory.c"
static uint8_t pd_ram[65536];
static XemuCheatX86Registers test_regs;
static MachineState machine;
MachineState *current_machine=&machine;
AddressSpace address_space_memory;
static MemoryRegion root;
static bool held,blocked,init_fail,read_fail,write_fail,register_fail;
static unsigned flush_failures,flush_calls,lock_calls,unlock_calls;
static unsigned write_calls,fail_on_write,patch_calls,dirty_calls;
static bool mutate_then_fail;
TestGuard test_lock(void){TestGuard g={!held};if(g.own){held=true;++lock_calls;}return g;}
void test_unlock(TestGuard *g){if(g->own){assert(held);held=false;++unlock_calls;}}
MemoryRegion *get_system_memory(void){return &root;}
MemoryRegionSection memory_region_find(MemoryRegion *r,hwaddr a,uint64_t n){(void)r;(void)a;(void)n;return (MemoryRegionSection){blocked?&root:NULL};}
void memory_region_unref(MemoryRegion *r){assert(r);}
bool memory_region_init_ram(MemoryRegion *r,void *o,const char *name,uint64_t n,Error **err){(void)o;(void)name;(void)err;if(init_fail)return false;r->ram=calloc(1,n);r->size=n;return r->ram!=NULL;}
void memory_region_add_subregion_overlap(MemoryRegion *r,hwaddr a,MemoryRegion *sub,int priority){(void)r;(void)a;(void)sub;(void)priority;assert(held);}
void *memory_region_get_ram_ptr(MemoryRegion *r){return r->ram;}
void memory_region_set_dirty(MemoryRegion *r,hwaddr a,uint64_t n){assert(held&&a+n<=r->size);++dirty_calls;}
int address_space_read(AddressSpace *a,hwaddr addr,int attrs,void *out,size_t n){(void)a;(void)attrs;assert(held);if(read_fail||addr+n>sizeof(pd_ram))return 1;memcpy(out,pd_ram+addr,n);return MEMTX_OK;}
int address_space_write(AddressSpace *a,hwaddr addr,int attrs,const void *in,size_t n){
 (void)a;(void)attrs;assert(held);++write_calls;
 if(write_fail||addr+n>sizeof(pd_ram))return 1;
 if(write_calls==fail_on_write){if(mutate_then_fail)memcpy(pd_ram+addr,in,n);return 1;}
 memcpy(pd_ram+addr,in,n);return MEMTX_OK;
}
void error_report_err(Error *e){(void)e;}
int xemu_dbg_flush_guest_translation(void){assert(held);++flush_calls;if(flush_failures){--flush_failures;return 0;}return 1;}
int xemu_cheat_get_x86_registers(XemuCheatX86Registers *out){if(register_fail)return 0;*out=test_regs;return 1;}
void xemu_cheat_notify_code_patch(void){assert(held);++patch_calls;}
static void reset(void){
 free(xemu_rpc_region.ram);memset(&xemu_rpc_region,0,sizeof(xemu_rpc_region));
 xemu_rpc_region_initialized=xemu_rpc_mapping_active=false;
 xemu_rpc_phys_base=xemu_rpc_virtual_base=xemu_rpc_mapped_cr3=xemu_rpc_active_size=0;
 memset(xemu_rpc_pde_phys,0,sizeof(xemu_rpc_pde_phys));memset(xemu_rpc_wanted_pde,0,sizeof(xemu_rpc_wanted_pde));memset(xemu_rpc_original_pde,0,sizeof(xemu_rpc_original_pde));
 xemu_rpc_pde_count=xemu_rpc_attempted_pdes=0;xemu_rpc_mapping_ready=false;
 write_calls=fail_on_write=patch_calls=dirty_calls=0;mutate_then_fail=false;
 xemu_rpc_error=NULL;memset(pd_ram,0,sizeof(pd_ram));memset(&test_regs,0,sizeof(test_regs));
 test_regs.cr0=1u<<31;test_regs.cr3=0x4000;machine.ram_size=64u<<20;
 held=blocked=init_fail=read_fail=write_fail=register_fail=false;flush_failures=flush_calls=lock_calls=unlock_calls=0;
}
static unsigned checks;
#define CHECK(c) do{if(!(c)){fprintf(stderr,"Arena check %u failed: %s\n",checks+1,#c);abort();}++checks;}while(0)
static bool walk(uint32_t address, uint64_t *physical){
 uint32_t pd=(test_regs.cr3&0xfffff000u)+(address>>22)*4u;
 if(pd+4>sizeof(pd_ram))return false;
 uint32_t pde=ldl_le_p(pd_ram+pd);
 if(!(pde&1u)||(pde&0x80u))return false;
 uint64_t table=pde&0xfffff000u;
 if(table<xemu_rpc_phys_base||table+4096>xemu_rpc_phys_base+xemu_rpc_region.size)return false;
 const uint8_t *ram=xemu_rpc_region.ram;
 uint32_t pte=ldl_le_p(ram+(table-xemu_rpc_phys_base)+((address>>12)&1023u)*4u);
 if(!(pte&1u))return false;
 *physical=(pte&0xfffff000u)+(address&4095u);return true;
}
static uint32_t pde_address(uint32_t virtual_address){return (test_regs.cr3&0xfffff000u)+(virtual_address>>22)*4u;}
int main(void){
 XemuGuestRpcArenaInfo a;uint8_t v=0x5a,out=0;
 const uint32_t sizes[]={1,4095,4096,65536,0x82000,0x100000,0x102000,0x202000,0x3ff000,0x400000,0x401000,0x402000};
 for(size_t i=0;i<sizeof(sizes)/sizeof(sizes[0]);++i){
   reset();CHECK(xemu_guest_rpc_arena_acquire_sized(sizes[i],&a));
   CHECK(a.size==((sizes[i]+4095u)&~4095u)&&xemu_guest_rpc_arena_validate());
   CHECK(!xemu_guest_rpc_arena_acquire(&a));
   CHECK(xemu_guest_rpc_arena_write(a.size-1,&v,1)&&xemu_guest_rpc_arena_read(a.size-1,&out,1)&&out==v);
   CHECK(!xemu_guest_rpc_arena_write(a.size,&v,1)&&!xemu_guest_rpc_arena_read(a.size,&out,1));
   CHECK(!xemu_guest_rpc_arena_write(UINT32_MAX,&v,SIZE_MAX));
   CHECK(!xemu_guest_rpc_arena_write(0,NULL,1)&&!xemu_guest_rpc_arena_read(0,NULL,1));
   uint32_t *pt=xemu_rpc_region.ram;
   CHECK(ldl_le_p(&pt[a.size/4096])==0); // no accidental extra guest mapping
   CHECK(xemu_guest_rpc_arena_release()&&!xemu_guest_rpc_arena_active()&&!held&&lock_calls==unlock_calls);
   CHECK(!xemu_guest_rpc_arena_read(0,&out,1));
 }
 reset();CHECK(xemu_guest_rpc_arena_acquire(&a)&&a.size==65536);CHECK(xemu_guest_rpc_arena_release());
 reset();CHECK(!xemu_guest_rpc_arena_acquire_sized(0,&a));CHECK(!xemu_guest_rpc_arena_acquire_sized(0x402001,&a));CHECK(!xemu_guest_rpc_arena_acquire_sized(UINT32_MAX,&a));CHECK(!xemu_guest_rpc_arena_acquire(NULL));
 reset();blocked=true;CHECK(!xemu_guest_rpc_arena_acquire(&a)&&!xemu_guest_rpc_arena_active());
 reset();init_fail=true;CHECK(!xemu_guest_rpc_arena_acquire(&a));
 reset();test_regs.cr0=0;CHECK(!xemu_guest_rpc_arena_acquire(&a));
 reset();test_regs.cr4=1u<<5;CHECK(!xemu_guest_rpc_arena_acquire(&a));
 reset();read_fail=true;CHECK(!xemu_guest_rpc_arena_acquire(&a));
 reset();write_fail=true;CHECK(!xemu_guest_rpc_arena_acquire(&a));
 reset();flush_failures=1;CHECK(!xemu_guest_rpc_arena_acquire(&a)&&!xemu_guest_rpc_arena_active()&&!held&&lock_calls==unlock_calls);
 reset();CHECK(xemu_guest_rpc_arena_acquire_sized(0x82000,&a));
 uint32_t original=ldl_le_p(pd_ram+xemu_rpc_pde_phys[0]);
 stl_le_p(pd_ram+xemu_rpc_pde_phys[0],original|0x60);CHECK(xemu_guest_rpc_arena_validate()); // CPU A/D bits allowed
 uint32_t *pt=xemu_rpc_region.ram;uint32_t expected=ldl_le_p(pt+100);
 stl_le_p(pt+100,expected^0x1000);CHECK(!xemu_guest_rpc_arena_validate());stl_le_p(pt+100,expected);
 test_regs.cr3^=0x1000;CHECK(!xemu_guest_rpc_arena_validate()&&!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());test_regs.cr3^=0x1000;
 stl_le_p(pd_ram+xemu_rpc_pde_phys[0],original^0x1000);CHECK(!xemu_guest_rpc_arena_validate()&&!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());stl_le_p(pd_ram+xemu_rpc_pde_phys[0],original);
 write_fail=true;CHECK(!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());write_fail=false;
 // A failed release permanently disables reuse until cleanup completes.
 CHECK(!xemu_guest_rpc_arena_validate()&&xemu_guest_rpc_arena_release());
 reset();held=true;CHECK(xemu_guest_rpc_arena_acquire(&a)&&held&&lock_calls==0);CHECK(xemu_guest_rpc_arena_validate()&&held);CHECK(xemu_guest_rpc_arena_release()&&held&&unlock_calls==0);held=false;
 // Independent page walks across the second PDE for each supported size.
 for(size_t i=0;i<sizeof(sizes)/sizeof(sizes[0]);++i){
   reset();CHECK(xemu_guest_rpc_arena_acquire_sized(sizes[i],&a));
   bool exact=true;uint64_t physical=0;
   for(uint32_t offset=0;offset<a.size;offset+=4096){
     if(!walk(a.virtual_base+offset,&physical)||physical!=a.physical_base+offset){exact=false;break;}
     if(!walk(a.virtual_base+offset+4095,&physical)||physical!=a.physical_base+offset+4095){exact=false;break;}
   }
   CHECK(exact);CHECK(!walk(a.virtual_base+a.size,&physical));
   CHECK(xemu_rpc_pde_count==(a.size+0x3fffffu)/0x400000u);
   CHECK(xemu_guest_rpc_arena_release());CHECK(!walk(a.virtual_base,&physical));
 }
 // Full payload refilled directly from source in two spans: only one sync,
 // content on both sides of 4 MiB, no accidental mapping past the final page.
 reset();CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a));
 uint8_t header[8192];memset(header,0x77,sizeof(header));
 uint8_t *source=malloc(0x400000);CHECK(source!=NULL);
 for(uint32_t j=0;j<0x400000;++j)source[j]=(uint8_t)(j*19u+j/4096u);
 XemuGuestRpcArenaWritePart spans[3]={{0,header,sizeof(header)},{8192,source,0x400000},{0,&v,1}};
 unsigned flush_before=flush_calls,patch_before=patch_calls;
 CHECK(xemu_guest_rpc_arena_writev(spans,2));
 CHECK(flush_calls==flush_before+1&&patch_calls==patch_before+1);
 bool same=true;uint64_t physical=0;
 for(uint32_t offset=0;offset<0x402000;offset+=4096){
   if(!walk(a.virtual_base+offset,&physical)){same=false;break;}
   const uint8_t *expected_bytes=offset<8192?header+offset:source+offset-8192;
   if(memcmp((uint8_t*)xemu_rpc_region.ram+physical-xemu_rpc_phys_base,expected_bytes,4096)){same=false;break;}
 }
 CHECK(same);CHECK(!walk(a.virtual_base+0x402000,&physical));
 flush_before=flush_calls;unsigned dirty_before=dirty_calls;
 CHECK(!xemu_guest_rpc_arena_writev(NULL,1));CHECK(!xemu_guest_rpc_arena_writev(spans,0));CHECK(!xemu_guest_rpc_arena_writev(spans,3));
 header[0]=0x66;spans[1].size=0x400001;
 CHECK(!xemu_guest_rpc_arena_writev(spans,2));
 CHECK(xemu_guest_rpc_arena_read(0,&out,1)&&out==0x77&&dirty_calls==dirty_before&&flush_calls==flush_before);
 spans[1].size=1;spans[1].offset=8191;CHECK(!xemu_guest_rpc_arena_writev(spans,2));
 spans[1].offset=8192;spans[1].data=NULL;CHECK(!xemu_guest_rpc_arena_writev(spans,2));
 CHECK(xemu_guest_rpc_arena_release());free(source);
 // Exact nonpresent PDE bytes are restored, rather than silently zeroed.
 reset();uint32_t first=pde_address(xemu_rpc_virtual_candidates[0]);
 stl_le_p(pd_ram+first,0x600u);stl_le_p(pd_ram+first+4,0xa00u);
 CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a)&&xemu_rpc_pde_count==2);
 for(uint32_t n=0;n<2;++n)stl_le_p(pd_ram+xemu_rpc_pde_phys[n],xemu_rpc_wanted_pde[n]|0x60u);
 CHECK(xemu_guest_rpc_arena_validate());
 uint32_t saved_second=ldl_le_p(pd_ram+first+4);
 stl_le_p(pd_ram+first+4,saved_second^0x1000u);
 CHECK(!xemu_guest_rpc_arena_validate()&&!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());
 CHECK(ldl_le_p(pd_ram+first)==(xemu_rpc_wanted_pde[0]|0x60u)); // first untouched
 stl_le_p(pd_ram+first+4,saved_second);
 uint8_t *tables=xemu_rpc_region.ram;uint32_t last=ldl_le_p(tables+1025*4);
 stl_le_p(tables+1025*4,last^0x1000u);CHECK(!xemu_guest_rpc_arena_validate());stl_le_p(tables+1025*4,last);
 stl_le_p(tables+1026*4,7);CHECK(!xemu_guest_rpc_arena_validate());stl_le_p(tables+1026*4,0);
 CHECK(xemu_guest_rpc_arena_validate()&&xemu_guest_rpc_arena_release());
 CHECK(ldl_le_p(pd_ram+first)==0x600u&&ldl_le_p(pd_ram+first+4)==0xa00u);
 // Second PDE occupied: skip BOTH conflicting candidate pairs, preserve it.
 reset();first=pde_address(xemu_rpc_virtual_candidates[0]);stl_le_p(pd_ram+first+4,0x12345007u);
 CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a)&&a.virtual_base==xemu_rpc_virtual_candidates[2]);
 CHECK(xemu_guest_rpc_arena_release()&&ldl_le_p(pd_ram+first+4)==0x12345007u);
 reset();for(size_t i=0;i<G_N_ELEMENTS(xemu_rpc_virtual_candidates);++i)stl_le_p(pd_ram+pde_address(xemu_rpc_virtual_candidates[i])+4,0x12345007u);
 CHECK(!xemu_guest_rpc_arena_acquire_sized(0x402000,&a)&&!xemu_guest_rpc_arena_active()&&write_calls==0);
 // A failure in EITHER PDE write, before or after mutation, rolls back the
 // exact attempted set and never leaks the first installed mapping.
 for(unsigned failing=1;failing<=2;++failing)for(int after=0;after<2;++after){
   reset();first=pde_address(xemu_rpc_virtual_candidates[0]);
   stl_le_p(pd_ram+first,0x600);stl_le_p(pd_ram+first+4,0xa00);
   fail_on_write=failing;mutate_then_fail=after;
   CHECK(!xemu_guest_rpc_arena_acquire_sized(0x402000,&a));
   CHECK(!xemu_guest_rpc_arena_active()&&ldl_le_p(pd_ram+first)==0x600&&ldl_le_p(pd_ram+first+4)==0xa00);
   CHECK(!held&&lock_calls==unlock_calls);
 }
 // Partial restore: retained ownership survives and a proven retry can finish.
 for(unsigned failing=3;failing<=4;++failing)for(int after=0;after<2;++after){
   reset();first=pde_address(xemu_rpc_virtual_candidates[0]);
   CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a));fail_on_write=failing;mutate_then_fail=after;
   CHECK(!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());
   CHECK(!xemu_guest_rpc_arena_validate()&&!xemu_guest_rpc_arena_write(0,&v,1));
   CHECK(!xemu_guest_rpc_arena_acquire(&a));
   CHECK(xemu_guest_rpc_arena_release()&&!xemu_guest_rpc_arena_active());
   CHECK(ldl_le_p(pd_ram+first)==0&&ldl_le_p(pd_ram+first+4)==0);
 }
 reset();flush_failures=2;CHECK(!xemu_guest_rpc_arena_acquire_sized(0x402000,&a)&&xemu_guest_rpc_arena_active());
 CHECK(!xemu_guest_rpc_arena_validate());CHECK(xemu_guest_rpc_arena_release()&&!xemu_guest_rpc_arena_active());
 reset();CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a));flush_failures=1;
 CHECK(!xemu_guest_rpc_arena_release()&&xemu_guest_rpc_arena_active());
 CHECK(xemu_guest_rpc_arena_release()&&!xemu_guest_rpc_arena_active());
 reset();init_fail=true;CHECK(!xemu_guest_rpc_arena_acquire(&a));init_fail=false;blocked=true;
 CHECK(!xemu_guest_rpc_arena_acquire(&a)&&!xemu_rpc_region_initialized); // no stale physical aperture
 reset();held=true;CHECK(xemu_guest_rpc_arena_acquire_sized(0x402000,&a)&&held&&lock_calls==0);
 CHECK(xemu_guest_rpc_arena_validate()&&held);CHECK(xemu_guest_rpc_arena_release()&&held&&unlock_calls==0);held=false;
 reset();printf("PASS: production C arena with QEMU facade (%u checks)\n",checks);
}
