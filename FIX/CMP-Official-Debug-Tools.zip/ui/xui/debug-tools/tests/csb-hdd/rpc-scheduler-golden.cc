// Real scheduling, stub building, completion verification and cancellation.
// CPU execution/results/arena mapping/block snapshots are simulated explicitly.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <new>
#include <string>
#include <vector>
#include "addons/hdd/kernel-rpc-utils.hh"
#include "addons/hdd/kernel-rpc-filesystem.hh"
// Test-only inspection/injection of executor state; never used in production.
#define private public
#include "addons/hdd/guest-kernel-rpc.hh"
#undef private
#include "addons/hdd/guest-kernel-rpc-status.hh"
#include "addons/hdd/hdd-snapshot-service.hh"
#include "current-game.hh"
extern "C" {
#include "system/runstate.h"
}
namespace fs=std::filesystem;
CurrentGameManager current_game_manager;
HddSnapshotService hdd_snapshot_service;
static uint64_t clock_ms=10;
static bool running=true, arena_active=false, bp=false, bql=false;
static int pauses=0, resumes=0, acquires=0, releases=0, guest_calls=0;
static int stop_result=0;
static uint32_t visible_size=0;
static bool visible_file=false;
static std::array<uint8_t,0x402000> arena{};
static XemuCheatX86Registers regs{};
static const int owner=123, other_owner=456;
static std::string input_path;
static uintptr_t mounted_id=1;
static bool valid_mapping=true,mounted_available=true,mounted_readonly=false;
static bool stream_open=false,verify_corrupt=false,fail_acquire=false,fail_arena_write=false,fail_close_breakpoint=false;
static uint32_t actual_arena_size=0;
static uint64_t hash_verifications=0,copy_verifications=0,snapshot_calls=0;
static std::vector<uint8_t> output_bytes,copy_source;
static bool use_fatx_source=false;
static uint64_t source_reads=0;
static uint64_t arena_refills=0,refill_payload_bytes=0;
uint64_t SDL_GetTicks(){return clock_ms;}
extern "C" {
bool bql_locked(void){return bql;}
void bql_lock_impl(const char*,int){assert(!bql);bql=true;}
void bql_unlock(void){assert(bql);bql=false;}
bool runstate_is_running(void){return running;}
int vm_stop(RunState){assert(bql);++pauses;running=false;return stop_result;}
void vm_start(void){assert(bql);++resumes;running=true;}
int xemu_guest_rpc_arena_active(void){return arena_active;}
int xemu_guest_rpc_arena_validate(void){return arena_active&&valid_mapping;}
int xemu_guest_rpc_arena_acquire(XemuGuestRpcArenaInfo *out){assert(!arena_active);arena_active=true;actual_arena_size=65536;++acquires;*out={0x01000000,0x04000000,65536};arena.fill(0);return 1;}
int xemu_guest_rpc_arena_acquire_sized(uint32_t n,XemuGuestRpcArenaInfo *out){if(fail_acquire)return 0;assert(n<=arena.size());int ok=xemu_guest_rpc_arena_acquire(out);out->size=n;actual_arena_size=n;return ok;}
void *xemu_disc_block_acquire_by_name(const char*){return reinterpret_cast<void*>(1);}
void xemu_disc_block_release(void*){}
bool xemu_disc_block_is_available(void*){return mounted_available;}
bool xemu_disc_block_is_read_only(void*){return mounted_readonly;}
uintptr_t xemu_disc_block_identity(void*){return mounted_id;}
int xemu_guest_rpc_arena_release(void){assert(arena_active);arena_active=false;++releases;return 1;}
int xemu_guest_rpc_arena_write(uint32_t offset,const void *data,size_t size){if(fail_arena_write)return 0;assert(arena_active&&offset+size<=actual_arena_size);std::memcpy(arena.data()+offset,data,size);return 1;}
int xemu_guest_rpc_arena_writev(const XemuGuestRpcArenaWritePart *parts,size_t count){
 if(fail_arena_write)return 0;
 assert(arena_active&&parts&&count>=1&&count<=2);size_t previous=0;
 for(size_t i=0;i<count;++i){assert(parts[i].data&&parts[i].offset>=previous&&parts[i].offset<=actual_arena_size&&parts[i].size<=actual_arena_size-parts[i].offset);previous=parts[i].offset+parts[i].size;}
 ++arena_refills;if(count==2)refill_payload_bytes+=parts[1].size;
 for(size_t i=0;i<count;++i)std::memcpy(arena.data()+parts[i].offset,parts[i].data,parts[i].size);
 return 1;
}
int xemu_guest_rpc_arena_read(uint32_t offset,void *data,size_t size){assert(arena_active&&offset+size<=actual_arena_size);std::memcpy(data,arena.data()+offset,size);return 1;}
const char *xemu_guest_rpc_arena_last_error(void){return "test arena error";}
int xemu_cheat_memory_read(int,uint32_t,void*,size_t){return 0;} // export resolution is explicitly seeded below
uint64_t xemu_cheat_ram_size(void){return 64u<<20;}
int xemu_cheat_prepare_virtual_map(void){return 1;}
int xemu_cheat_virtual_to_physical(uint32_t addr,uint64_t *out){*out=addr;return 1;}
int xemu_cheat_get_x86_registers(XemuCheatX86Registers *out){*out=regs;return 1;}
int xemu_cheat_set_x86_register(const char *name,uint32_t value){
#define SET(field) if(!std::strcmp(name,#field)){regs.field=value;return 1;}
 SET(eax);SET(ebx);SET(ecx);SET(edx);SET(esi);SET(edi);SET(esp);SET(ebp);SET(eflags);
#undef SET
 if(!std::strcmp(name,"eip")){regs.eip=regs.pc=value;return 1;} return 0;
}
int xemu_cheat_breakpoint_insert(uint32_t){assert(!bp);bp=true;return 1;}
int xemu_cheat_breakpoint_remove(uint32_t){if(fail_close_breakpoint)return 0;assert(bp);bp=false;return 1;}
}
static XemuFatxHdd::Snapshot Snapshot(){
 ++snapshot_calls;
 XemuFatxHdd::Snapshot s;s.hdd_available=true;XemuFatxHdd::Partition p;p.letter='E';p.available=true;p.bytes_per_cluster=16384;
 if(visible_file){XemuFatxHdd::Entry e;e.name=e.display_name=fs::path(input_path).filename().string();e.first_cluster=20;e.file_size=visible_size;e.attributes=0x20;e.directory=false;p.entries.push_back(e);}
 if(use_fatx_source){
   p.entries.clear();XemuFatxHdd::Entry src;src.name=src.display_name="source.wma";src.attributes=0x20;src.file_size=copy_source.size();src.first_cluster=30;src.directory_entry_offset=1920;src.modified_time=7;src.modified_date=8;src.directory=false;
   p.entries.push_back(src);XemuFatxHdd::Entry dir;dir.name=dir.display_name="stage";dir.directory=true;dir.attributes=0x10;dir.first_cluster=10;
   if(visible_file){src.first_cluster=20;src.file_size=visible_size;dir.children.push_back(src);}p.entries.push_back(dir);
 }
 s.partitions.push_back(p);return s;
}
bool HddSnapshotService::BuildRawSnapshot(XemuFatxHdd::Snapshot &out,std::string&)const{out=Snapshot();return true;}
bool HddSnapshotService::BuildRawPartitionSnapshot(char part,XemuFatxHdd::Snapshot &out,std::string&)const{assert(part=='E');out=Snapshot();return true;}
bool HddSnapshotService::BuildRawPartitionSetSnapshot(const std::vector<char>&,XemuFatxHdd::Snapshot &out,std::string&)const{out=Snapshot();return true;}
bool HddSnapshotService::QueryPartitionCapacity(char,CapacityInfo &out,std::string&)const{out.bytes_per_cluster=16384;out.free_bytes=128u<<20;return true;}
bool HddSnapshotService::ReadFatxFileChunk(char part,const std::vector<std::string>&path,uint64_t entry,uint32_t cluster,uint16_t time,uint16_t date,uint8_t attrs,uint64_t size,uint64_t offset,size_t count,std::vector<uint8_t>&out,std::string&)const{
 if(!use_fatx_source)return false;
 assert(part=='E'&&path==std::vector<std::string>{"source.wma"}&&entry==1920&&cluster==30&&time==7&&date==8&&attrs==0x20&&size==copy_source.size());
 ++source_reads;++snapshot_calls;clock_ms+=3;
 if(offset>size)return false;
 out.assign(copy_source.begin()+offset,copy_source.begin()+offset+std::min<uint64_t>(count,size-offset));return true;
}
bool HddSnapshotService::VerifyFatxCopyContents(const std::vector<FatxCompareItem>&items,std::string&)const{
 if(!use_fatx_source)return false;
 assert(items.size()==1&&!stream_open&&!running&&arena_active);const auto &i=items.front();
 assert(i.source_partition=='E'&&i.destination_partition=='E'&&i.source_components==std::vector<std::string>{"source.wma"});
 assert((i.destination_components==std::vector<std::string>{"stage","source.wma"}));
 assert(i.source_directory_entry_offset==1920&&i.source_first_cluster==30&&i.source_modified_time==7&&i.source_modified_date==8&&i.source_attributes==0x20&&i.file_size==copy_source.size()&&!i.directory);
 ++copy_verifications;clock_ms+=9;return !verify_corrupt&&copy_source==output_bytes;
}
bool HddSnapshotService::VerifyFatxFileHash(char part,const std::vector<std::string>&path,uint64_t size,uint64_t hash,std::string &error) const {
 assert(part=='E'&&!path.empty()&&!stream_open&&!running&&arena_active);++hash_verifications;clock_ms+=7;
 const bool ok=!verify_corrupt&&output_bytes.size()==size&&XemuKernelFs::UpdateContentHash(XemuKernelFs::kContentHashBasis,output_bytes.data(),output_bytes.size())==hash;
 if(!ok) error="injected/mismatched final hash";
 return ok;
}
static void Reset(){
 mounted_id=1;valid_mapping=true;mounted_available=true;mounted_readonly=false;
 stream_open=verify_corrupt=fail_acquire=fail_arena_write=fail_close_breakpoint=false;
 arena_refills=refill_payload_bytes=0;actual_arena_size=0;hash_verifications=copy_verifications=snapshot_calls=source_reads=0;output_bytes.clear();copy_source.clear();use_fatx_source=false;
 // Explicit simulated Xbox reset, including any fail-closed owned mapping.
 guest_kernel_rpc_manager.~GuestKernelRpcManager();new(&guest_kernel_rpc_manager)GuestKernelRpcManager;
 clock_ms=10;running=true;arena_active=bp=bql=false;pauses=resumes=acquires=releases=guest_calls=0;stop_result=0;visible_file=false;visible_size=0;
 current_game_manager.info={true,1,0x100000,0x10000};regs={};regs.esp=0x20000;regs.eflags=0x202;regs.eip=regs.pc=0x80010000;
}
static void Arm(bool wait=true){
 std::string e;assert(guest_kernel_rpc_manager.ClaimFilesystemSequence(&owner,e,wait));
 XemuKernelFs::ImportPlan plan;assert(guest_kernel_rpc_manager.PrepareHddImport(input_path,false,'E',{},plan,e));
 assert(guest_kernel_rpc_manager.StartHddImport(plan,&owner));
 auto &m=guest_kernel_rpc_manager;
 m.m_export_address=0x80010000;m.m_import_create_export_address=0x80011000;m.m_import_write_export_address=0x80012000;m.m_import_flush_export_address=0x80013000;m.m_import_close_export_address=0x80014000;
}
static void SafeSample(){regs.eip=regs.pc=0x11000;clock_ms+=50;guest_kernel_rpc_manager.Tick();assert(arena_active&&running&&bp);}
static void CompleteImport(uint32_t irql=0,uint64_t elapsed=1){
 auto &m=guest_kernel_rpc_manager;assert(arena_active&&bp&&m.m_state==GuestKernelRpcManager::State::RunningFsQuery);
 const uint32_t values[]={irql,0,0,0,0,irql?0u:1u,irql?0u:m.m_import_current_chunk_bytes};
 for(size_t i=0;i<7;++i)XemuKernelRpc::StoreLe32(arena.data()+0x1000+4*i,values[i]);
 if(irql==0){++guest_calls;visible_file=true;visible_size=static_cast<uint32_t>(m.m_expected_file_size);}
 regs=m.m_saved;regs.eip=regs.pc=m.m_completion_address;running=false;clock_ms+=elapsed;m.Tick();
}
int main(int argc,char **argv){
 assert(argc==2);input_path=argv[1];std::ofstream f(input_path,std::ios::binary);std::vector<char> bytes(XemuKernelFs::kImportChunkBytes*10,'x');f.write(bytes.data(),bytes.size());f.close();
 unsigned checks=0;auto check=[&](bool value){if(!value)std::cerr<<"FAIL rpc check "<<checks+1<<": "<<guest_kernel_rpc_manager.Status()<<"\n";assert(value);++checks;};
 auto &m=guest_kernel_rpc_manager;using State=GuestKernelRpcManager::State;
 Reset();Arm();for(int n=0;n<600;++n){clock_ms+=100;m.Tick();}
 check(m.FilesystemOperationRunning()&&m.m_safe_point_attempts==600&&acquires==0&&guest_calls==0);
 check(m.Status().find("WAITING FOR SAFE HDD WRITE")!=std::string::npos);
 check(!m.CancelFilesystemOperation(&other_owner,"wrong owner")&&m.FilesystemOperationRunning());
 check(m.CancelFilesystemOperation(&owner,"cancel long wait")&&!m.FilesystemOperationRunning()&&!arena_active&&running);
 m.ReleaseFilesystemSequence(&owner);check(!m.OperationBusy());
 Reset();Arm(false);clock_ms+=5001;m.Tick();check(!m.FilesystemOperationRunning()&&m.Status().find("within 5 seconds")!=std::string::npos&&guest_calls==0);
 Reset();Arm();running=false;clock_ms+=60000;m.Tick();check(m.FilesystemOperationRunning()&&m.Status().find("paused")!=std::string::npos&&pauses==0);
 m.CancelFilesystemOperation(&owner,"cancel paused");check(!m.FilesystemOperationRunning()&&!running&&resumes==0);
 Reset();Arm();current_game_manager.info.title_id=2;clock_ms+=6000;m.Tick();check(!m.FilesystemOperationRunning()&&acquires==0);
 // Same exact IRQL gate remains: an elevated-IRQL stub does not write.
 Reset();Arm();SafeSample();CompleteImport(2);check(m.m_state==State::WaitingSafePoint&&guest_calls==0&&!arena_active&&running);
 m.CancelFilesystemOperation(&owner,"cancel skipped probe");check(!m.FilesystemOperationRunning());
 // Four-call / 50 ms continuation is bounded and still uses four separately
 // checked stubs and four clean arena lifetimes, then yields to the title.
 Reset();Arm();SafeSample();const int initial_pauses=pauses;
 for(int n=1;n<=4;++n){CompleteImport();if(n<4)check(m.m_state==State::RunningFsQuery&&acquires==n+1);}
 check(m.m_state==State::WaitingSafePoint&&!arena_active&&running&&guest_calls==4&&pauses==initial_pauses&&releases==4);
 check(regs.eip==0x11000&&regs.esp==0x20000&&regs.eflags==0x202);
 while(m.FilesystemOperationRunning()){if(m.m_state==State::WaitingSafePoint){clock_ms+=50;m.Tick();}else CompleteImport();}
 check(m.LastFilesystemOperationSucceeded()&&guest_calls==10&&visible_size==bytes.size()&&!arena_active&&!bp&&running);
 Reset();Arm();SafeSample();CompleteImport(0,51);check(m.m_state==State::WaitingSafePoint&&guest_calls==1&&acquires==1&&!arena_active);
 // Cancel during a live call owns its mapping until verified return.
 Reset();Arm();SafeSample();check(m.CancelFilesystemOperation(&owner,"cancel live")&&m.FilesystemOperationRunning()&&arena_active&&bp&&releases==0);
 CompleteImport();check(!m.FilesystemOperationRunning()&&!m.LastFilesystemOperationSucceeded()&&!arena_active&&!bp&&guest_calls==1&&running);
 // Cancel also prevents an IRQL-rejected call from being retried.
 Reset();Arm();SafeSample();m.CancelFilesystemOperation(&owner,"cancel live probe");CompleteImport(2);
 check(!m.FilesystemOperationRunning()&&!arena_active&&guest_calls==0);
 // A genuinely stuck in-flight syscall retains the ORIGINAL fail-closed
 // three-second timeout. Do not turn this into a cancellable stack unwind.
 Reset();Arm();SafeSample();clock_ms+=3001;m.Tick();
 check(m.m_state==State::Failed&&arena_active&&bp&&!running&&releases==0&&m.Status().find("exceeded 3 seconds")!=std::string::npos);
 check(!m.CancelFilesystemOperation(&owner,"unsafe cancellation")&&arena_active&&bp);
 Reset();Arm();SafeSample();regs.eip=regs.pc=0x80011001;running=false;m.Tick();
 check(m.m_state==State::Failed&&arena_active&&bp&&releases==0&&m.Status().find("unexpectedly")!=std::string::npos);
 Reset();Arm();stop_result=-1;clock_ms+=50;m.Tick();check(m.m_state==State::Failed&&!arena_active&&running);
 for(unsigned n=0;n<16;++n)check(XemuGuestKernelRpcStatus::CsbSafePointSampleDelay(n)>=17&&XemuGuestKernelRpcStatus::CsbSafePointSampleDelay(n)<=41);
 check(!XemuGuestKernelRpcStatus::CsbImportBurstMayContinue(4,0)&&!XemuGuestKernelRpcStatus::CsbImportBurstMayContinue(1,50));
 Reset();std::cout<<"PASS: real RPC scheduler/completion with simulated Xbox ("<<checks<<" checks)\n";return 0;
}
