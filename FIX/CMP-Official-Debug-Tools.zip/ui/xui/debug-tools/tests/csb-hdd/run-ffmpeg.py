#!/usr/bin/env python3
"""Real host FFmpeg fixtures validated by the unchanged production CSB core."""
from pathlib import Path
import argparse,subprocess,tempfile
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--compiler',default='g++');ap.add_argument('--ffmpeg',default='ffmpeg');a=ap.parse_args()
dt=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='csb-audio-test-') as t:
    root=Path(t)/'audio with spaces';root.mkdir()
    for name,codec,rate,channels in [('good','wmav2',44100,2),('wrong-codec','wmav1',44100,2),('wrong-rate','wmav2',22050,2),('mono','wmav2',44100,1)]:
        subprocess.run([a.ffmpeg,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','anullsrc=r=44100:cl=stereo','-t','1.2','-vn','-ac',str(channels),'-ar',str(rate),'-c:a',codec,'-b:a','128k',str(root/(name+'.wma'))],check=True)
    (root/'truncated.wma').write_bytes((root/'good.wma').read_bytes()[:20])
    main=root/'probe.cc';main.write_text('''#include "addons/custom-soundtrack-builder/custom-soundtrack-builder-core.hh"
#include <cassert>
#include <iostream>
int main(int argc,char**argv){assert(argc==2);std::string p=argv[1],e;uint32_t ms=0;
assert(XemuCsb::ValidateWma2XboxProfile(p+"/good.wma",e));
assert(XemuCsb::ReadAsfDurationMs(p+"/good.wma",ms,e)&&ms>0);
for(const auto *n:{"wrong-codec","wrong-rate","mono","truncated"}) assert(!XemuCsb::ValidateWma2XboxProfile(p+"/"+n+".wma",e));
assert(XemuCsb::WriteStDbOneSoundtrack(p+"/ST.DB",0,"Audio Fixture",{{0,ms,"Silence"}},e));
std::cout<<"PASS: real FFmpeg WMA2 output/duration/ST.DB; rejected WMA1, wrong rate, mono and truncated ASF (7 checks)\\n";}
''')
    exe=root/'probe'
    subprocess.run([a.compiler,'-std=c++17','-Wall','-Wextra','-Werror','-I'+str(dt),str(main),str(dt/'addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc'),'-o',str(exe)],check=True)
    subprocess.run([str(exe),str(root)],check=True)
