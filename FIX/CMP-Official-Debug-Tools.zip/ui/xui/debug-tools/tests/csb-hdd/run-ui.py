#!/usr/bin/env python3
"""Execute the production CSB controller/Draw with scripted UI/platform facades.
Not a real ImGui renderer, SDL event loop, Windows SDK build, or HDD writer test.
"""
from pathlib import Path
import argparse
import shutil
import subprocess
import tempfile
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--compiler', default='g++')
ap.add_argument('--sanitizers', action='store_true')
a = ap.parse_args()
dt = Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='csb9-ui-') as td:
    root = Path(td)
    d = root / 'ui/xui/debug-tools'
    shutil.copytree(dt, d)
    (d.parent / 'common.hh').write_text('#pragma once\n#include <imgui.h>\n')
    (d.parent / 'misc.hh').write_text('''#pragma once
#include <SDL3/SDL.h>
#include <functional>
using FileDialogCallback=std::function<void(const char*)>;
void ShowOpenFileDialog(const SDL_DialogFileFilter*,int,const char*,FileDialogCallback);
''')
    cmd = [a.compiler, '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
           '-I' + str(d/'tests/csb-hdd/stubs'), '-I' + str(d)]
    if a.sanitizers:
        cmd += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer']
    cmd += [str(d/'tests/csb-hdd/ui-manager-golden.cc'),
            str(d/'addons/custom-soundtrack-builder/custom-soundtrack-builder.cc'),
            str(d/'addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc'),
            '-l:libglib-2.0.so.0', '-o', str(root/'csb9-ui')]
    subprocess.run(cmd, check=True)
    subprocess.run([str(root/'csb9-ui'), str(root/'fixtures')], check=True)
