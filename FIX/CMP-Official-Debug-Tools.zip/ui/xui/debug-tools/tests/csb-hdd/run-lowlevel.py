#!/usr/bin/env python3
"""Production C arena and FATX readback service, with mocked platform bindings."""
from pathlib import Path
import argparse,subprocess,tempfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default='g++');p.add_argument('--sanitizers',action='store_true');a=p.parse_args()
d=Path(__file__).resolve().parents[2]
cc='clang' if 'clang' in a.compiler else 'gcc'
with tempfile.TemporaryDirectory(prefix='csb-lowlevel-') as td:
 r=Path(td); st=r/'stubs'; st.mkdir()
 (st/'test-qemu.h').write_text('''#pragma once
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define G_STATIC_ASSERT(x) _Static_assert(x,#x)
#define G_N_ELEMENTS(x) (sizeof(x)/sizeof((x)[0]))
typedef uint64_t hwaddr;
typedef struct Error {int unused;} Error;
typedef struct MemoryRegion {void *ram;uint64_t size;} MemoryRegion;
typedef struct MemoryRegionSection {MemoryRegion *mr;} MemoryRegionSection;
typedef struct MachineState {uint64_t ram_size;} MachineState;
typedef struct AddressSpace {int unused;} AddressSpace;
extern MachineState *current_machine;extern AddressSpace address_space_memory;
typedef struct TestGuard {bool own;} TestGuard;
TestGuard test_lock(void);void test_unlock(TestGuard *g);
#define BQL_LOCK_GUARD() TestGuard test_guard __attribute__((cleanup(test_unlock)))=test_lock()
#define MEMTX_OK 0
#define MEMTXATTRS_UNSPECIFIED 0
static inline uint32_t ldl_le_p(const void *p){const uint8_t *b=p;return b[0]|(uint32_t)b[1]<<8|(uint32_t)b[2]<<16|(uint32_t)b[3]<<24;}
static inline void stl_le_p(void *p,uint32_t v){uint8_t *b=p;b[0]=v;b[1]=v>>8;b[2]=v>>16;b[3]=v>>24;}
#define cpu_to_le32(x) (x)
MemoryRegion *get_system_memory(void);
MemoryRegionSection memory_region_find(MemoryRegion*,hwaddr,uint64_t);
void memory_region_unref(MemoryRegion*);
bool memory_region_init_ram(MemoryRegion*,void*,const char*,uint64_t,Error**);
void memory_region_add_subregion_overlap(MemoryRegion*,hwaddr,MemoryRegion*,int);
void *memory_region_get_ram_ptr(MemoryRegion*);
void memory_region_set_dirty(MemoryRegion*,hwaddr,uint64_t);
int address_space_read(AddressSpace*,hwaddr,int,void*,size_t);
int address_space_write(AddressSpace*,hwaddr,int,const void*,size_t);
void error_report_err(Error*);
''')
 for f in ['qemu/osdep.h','qemu/error-report.h','qemu/main-loop.h','qemu/bswap.h','qapi/error.h','hw/boards.h','system/address-spaces.h','system/memory.h']:
  q=st/f;q.parent.mkdir(parents=True,exist_ok=True);q.write_text('#include <test-qemu.h>\n')
 san=['-fsanitize=address,undefined','-fno-omit-frame-pointer'] if a.sanitizers else []
 cmd=[cc,'-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror',*san,'-I'+str(st),'-I'+str(d),str(d/'tests/csb-hdd/arena-memory-golden.c'),'-o',str(r/'arena')]
 print('+',' '.join(cmd),flush=True);subprocess.run(cmd,check=True);subprocess.run([str(r/'arena')],check=True)
 # Use only the small GLib declarations for C++; never leak fake QEMU types
 # into the production public snapshot/pause interfaces.
 exe=r/'readback'
 cmd=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror',*san,
      '-I'+str(d/'tests/csb-hdd/stubs'),'-I'+str(d),
      str(d/'tests/csb-hdd/readback-golden.cc'),str(d/'addons/hdd/hdd-snapshot-service.cc'),
      str(d/'addons/hdd/fatx-hdd.cc'),str(d/'addons/hdd/kernel-rpc-filesystem.cc'),
      '-l:libglib-2.0.so.0','-o',str(exe)]
 print('+',' '.join(cmd),flush=True);subprocess.run(cmd,check=True);subprocess.run([str(exe)],check=True)

 # Public protocol header must remain usable after QEMU's Windows token macros.
 macro=r/'windows-macros.cc'
 macro.write_text("""#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#define close qemu_close
#define write qemu_write
#define read qemu_read
#include \"addons/hdd/kernel-rpc-stream.hh\"
int main() {
 XemuKernelStream::Exports e{1,2,3,4,5};
 XemuKernelStream::Stub s; std::string error;
 for (uint32_t chunk : {524288u,1048576u,2097152u,4194304u}) {
  if(!XemuKernelStream::BuildStub(0x68400000u,e,XemuKernelStream::Action::OpenWrite,chunk,s,error)) return 1;
  if(XemuKernelStream::ArenaBytesForFile(chunk,chunk)!=chunk+8192u) return 3;
 }
 if(XemuKernelStream::BuildStub(0xffc00000u,e,XemuKernelStream::Action::Write,4194304u,s,error)) return 4;
 XemuKernelStream::Result r; r.close_status=0; r.write_status=0;
 if(e.close_fn!=5 || r.close_status || r.write_status) return 2;
 std::puts(\"PASS: stream protocol header with QEMU Windows close/read/write macro facade\");
}
""")
 cmd=[a.compiler,'-std=c++17','-Wall','-Wextra','-Werror','-I'+str(d),str(macro),'-o',str(r/'macros')]
 subprocess.run(cmd,check=True);subprocess.run([str(r/'macros')],check=True)
