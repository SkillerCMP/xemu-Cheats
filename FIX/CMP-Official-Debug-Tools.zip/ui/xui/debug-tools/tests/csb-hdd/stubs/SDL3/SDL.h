// TEST ONLY: SDL declarations; no SDL window is created by these tests.
#pragma once
#include <cstdint>
using SDL_WindowID = uint32_t;
struct SDL_Window;
struct SDL_DialogFileFilter { const char *name; const char *pattern; };
struct SDL_DropEvent { uint32_t type; const char *data; };
struct SDL_Event { uint32_t type; SDL_DropEvent drop; };
#define SDLCALL
constexpr uint32_t SDL_EVENT_DROP_FILE = 0x1000;
using SDL_EventFilter = bool (*)(void *, SDL_Event *);
bool SDL_AddEventWatch(SDL_EventFilter, void *);
void SDL_RemoveEventWatch(SDL_EventFilter, void *);
uint64_t SDL_GetTicks();
const char *SDL_GetBasePath();
bool SDL_OpenURL(const char *);
const char *SDL_GetError();
