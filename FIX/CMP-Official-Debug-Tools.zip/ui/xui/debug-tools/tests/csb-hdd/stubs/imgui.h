// TEST ONLY: explicit Dear ImGui declarations; no ImGui runtime/rendering.
#pragma once
#include <cstddef>
using ImGuiWindowFlags=int; using ImGuiCond=int; using ImGuiTableFlags=int;
using ImGuiTableColumnFlags=int; using ImGuiInputTextFlags=int;
struct ImVec2 { float x,y; ImVec2(float a=0,float b=0):x(a),y(b){} };
struct ImGuiIO { ImVec2 DisplaySize, MousePos; float DeltaTime = 1.0f/60.0f; };
constexpr int ImGuiCond_Always=1, ImGuiCond_FirstUseEver=2;
constexpr int ImGuiWindowFlags_NoCollapse=1,ImGuiWindowFlags_NoTitleBar=2,ImGuiWindowFlags_NoResize=4,ImGuiWindowFlags_NoMove=8,ImGuiWindowFlags_NoSavedSettings=16;
constexpr int ImGuiTableFlags_Borders=1,ImGuiTableFlags_RowBg=2,ImGuiTableFlags_Resizable=4,ImGuiTableFlags_ScrollY=8;
constexpr int ImGuiTableColumnFlags_WidthFixed=1,ImGuiTableColumnFlags_WidthStretch=2;
namespace ImGui {
ImGuiIO& GetIO(); ImVec2 GetContentRegionAvail();
bool Begin(const char*,bool* = nullptr,ImGuiWindowFlags=0); void End();
void SetNextWindowPos(const ImVec2&,ImGuiCond=0,const ImVec2& = ImVec2(0,0));
void SetNextWindowSize(const ImVec2&,ImGuiCond=0);
void BeginDisabled(bool=true); void EndDisabled();
bool Button(const char*,const ImVec2& = ImVec2(0,0)); bool SmallButton(const char*);
bool Combo(const char*,int*,const char*,int=-1);
bool Checkbox(const char*,bool*); void SameLine(float=0,float=-1);
void Text(const char*,...); void TextDisabled(const char*,...); void TextWrapped(const char*,...);
void TextUnformatted(const char*,const char* = nullptr); void SetTooltip(const char*,...);
void Separator(); void SetNextItemWidth(float); bool IsItemHovered(int=0);
void PushID(int); void PopID(); void ProgressBar(float,const ImVec2& = ImVec2(-1,0),const char* = nullptr);
bool InputText(const char*,char*,size_t,ImGuiInputTextFlags=0,void* = nullptr,void* = nullptr);
bool InputInt(const char*,int*,int=1,int=100,ImGuiInputTextFlags=0);
bool BeginTable(const char*,int,ImGuiTableFlags=0,const ImVec2& = ImVec2(0,0),float=0);
void EndTable(); void TableSetupColumn(const char*,ImGuiTableColumnFlags=0,float=0,unsigned=0);
void TableHeadersRow(); void TableNextRow(int=0,float=0); bool TableSetColumnIndex(int);
}

using ImGuiSelectableFlags=int; using ImGuiDragDropFlags=int; using ImGuiPopupFlags=int;
using ImGuiChildFlags=int; using ImGuiHoveredFlags=int;
constexpr int ImGuiCond_Appearing=4;
constexpr int ImGuiWindowFlags_MenuBar=32, ImGuiWindowFlags_AlwaysAutoResize=64;
constexpr int ImGuiTableFlags_ScrollX=16, ImGuiTableFlags_SizingFixedFit=32, ImGuiTableFlags_BordersInnerV=64;
constexpr int ImGuiSelectableFlags_SpanAllColumns=1, ImGuiSelectableFlags_AllowDoubleClick=2;
constexpr int ImGuiDragDropFlags_AcceptBeforeDelivery=1;
constexpr int ImGuiChildFlags_Borders=1, ImGuiHoveredFlags_AllowWhenBlockedByActiveItem=1;
constexpr int ImGuiCol_DragDropTarget=0;
struct ImGuiPayload { void *Data=nullptr; int DataSize=0; bool Delivery=false; bool IsDelivery() const { return Delivery; } bool IsDataType(const char*) const; };
struct ImDrawList { void AddLine(const ImVec2&,const ImVec2&,unsigned int,float=1.0f); };
namespace ImGui {
float GetFontSize(); float GetFrameHeight();
bool BeginChild(const char*,const ImVec2& = ImVec2(0,0),ImGuiChildFlags=0,ImGuiWindowFlags=0); void EndChild();
void SetNextWindowSizeConstraints(const ImVec2&,const ImVec2&,void* = nullptr,void* = nullptr);
bool BeginMenuBar(); void EndMenuBar(); bool BeginMenu(const char*,bool=true); void EndMenu();
bool MenuItem(const char*,const char* = nullptr,bool=false,bool=true);
bool CollapsingHeader(const char*,int=0);
bool Selectable(const char*,bool=false,ImGuiSelectableFlags=0,const ImVec2& = ImVec2(0,0));
bool IsMouseDoubleClicked(int);
ImVec2 GetItemRectMin(); ImVec2 GetItemRectMax(); ImVec2 GetWindowPos(); ImVec2 GetWindowSize();
ImDrawList* GetWindowDrawList(); unsigned int GetColorU32(int,float=1.0f);
bool BeginDragDropSource(ImGuiDragDropFlags=0); void EndDragDropSource();
bool BeginDragDropTarget(); void EndDragDropTarget();
bool SetDragDropPayload(const char*,const void*,size_t,ImGuiCond=0);
const ImGuiPayload* AcceptDragDropPayload(const char*,ImGuiDragDropFlags=0); const ImGuiPayload* GetDragDropPayload();
bool BeginPopupContextItem(const char* = nullptr,ImGuiPopupFlags=1);
void OpenPopup(const char*,ImGuiPopupFlags=0);
bool BeginPopupModal(const char*,bool* = nullptr,ImGuiWindowFlags=0); void EndPopup(); void CloseCurrentPopup();
void TableSetupScrollFreeze(int,int);
bool IsWindowHovered(ImGuiHoveredFlags=0); float GetScrollY(); float GetScrollMaxY(); void SetScrollY(float);
}
