// TEST ONLY: production filesystem entry points do not need QEMU internals.
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstdio>
