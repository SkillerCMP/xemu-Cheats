// TEST ONLY: Win32 declaration facade for the CreateProcessW branch. This is
// neither a Windows SDK nor a real Windows cross-build/runtime test.
#pragma once
#include <cstdint>
using DWORD=uint32_t; using BOOL=int; using HANDLE=void*;
constexpr BOOL TRUE=1;
constexpr DWORD CP_UTF8=65001,MB_ERR_INVALID_CHARS=8,HANDLE_FLAG_INHERIT=1;
constexpr DWORD GENERIC_READ=0x80000000,GENERIC_WRITE=0x40000000,FILE_SHARE_READ=1,FILE_SHARE_WRITE=2,OPEN_EXISTING=3,FILE_ATTRIBUTE_NORMAL=0x80;
constexpr DWORD STARTF_USESTDHANDLES=0x100,CREATE_NO_WINDOW=0x08000000,ERROR_SUCCESS=0,INFINITE=0xffffffff;
constexpr DWORD STD_INPUT_HANDLE=static_cast<DWORD>(-10),STD_OUTPUT_HANDLE=static_cast<DWORD>(-11);
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
struct SECURITY_ATTRIBUTES {DWORD nLength;void* lpSecurityDescriptor;BOOL bInheritHandle;};
struct STARTUPINFOW {DWORD cb;wchar_t *lpReserved,*lpDesktop,*lpTitle;DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags;uint16_t wShowWindow,cbReserved2;unsigned char *lpReserved2;HANDLE hStdInput,hStdOutput,hStdError;};
struct PROCESS_INFORMATION {HANDLE hProcess,hThread;DWORD dwProcessId,dwThreadId;};
int MultiByteToWideChar(unsigned,DWORD,const char*,int,wchar_t*,int);
BOOL CreatePipe(HANDLE*,HANDLE*,SECURITY_ATTRIBUTES*,DWORD);
BOOL SetHandleInformation(HANDLE,DWORD,DWORD);DWORD GetLastError();
HANDLE CreateFileW(const wchar_t*,DWORD,DWORD,SECURITY_ATTRIBUTES*,DWORD,DWORD,HANDLE);
HANDLE GetStdHandle(DWORD);BOOL CloseHandle(HANDLE);
BOOL CreateProcessW(const wchar_t*,wchar_t*,SECURITY_ATTRIBUTES*,SECURITY_ATTRIBUTES*,BOOL,DWORD,void*,const wchar_t*,STARTUPINFOW*,PROCESS_INFORMATION*);
BOOL ReadFile(HANDLE,void*,DWORD,DWORD*,void*);DWORD WaitForSingleObject(HANDLE,DWORD);
BOOL GetExitCodeProcess(HANDLE,DWORD*);
