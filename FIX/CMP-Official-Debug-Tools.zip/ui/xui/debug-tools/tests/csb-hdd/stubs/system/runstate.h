#pragma once
bool runstate_is_running(void);
