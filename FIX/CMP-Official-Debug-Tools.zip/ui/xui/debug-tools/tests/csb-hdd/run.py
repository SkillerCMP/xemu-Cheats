#!/usr/bin/env python3
"""Production CSB/HDD controller tests with a mock Xbox, not a full xemu build."""
from pathlib import Path
import argparse, shutil, subprocess, tempfile
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--compiler',default='g++')
ap.add_argument('--keep',default='')
ap.add_argument('--sanitizers',action='store_true')
a=ap.parse_args()
dt=Path(__file__).resolve().parents[2]

def run(root):
    d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
    stubs=d/'tests/csb-hdd/stubs'
    (d/'current-game.hh').write_text('''#pragma once
#include <cstdint>
class CurrentGameManager { public:
 struct GameInfo { bool valid=true; uint32_t title_id=1; uint32_t xbe_image_size=0x1000; };
 GameInfo info; const GameInfo &Get() const { return info; }
};
extern CurrentGameManager current_game_manager;
''')
    (root/'ui/xemu-settings.h').write_text('''#pragma once
#define CONFIG_SYS_FILES_HDD_TYPE_IMAGE 0
#define CONFIG_SYS_FILES_HDD_TYPE_FOLDER 1
struct config { struct { struct { int hdd_type=0; char *hdd_path=nullptr; char *hdd_folder_path=nullptr; } files; } sys; };
extern struct config g_config;
''')
    includes=['-I'+str(stubs),'-I'+str(d),'-I'+str(root/'ui')]
    common=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror',*includes]
    if a.sanitizers: common += ['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    sources=[d/'tests/csb-hdd/hdd-install-golden.cc',d/'addons/custom-soundtrack-builder/custom-soundtrack-hdd.cc',
        d/'addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc',
        d/'addons/hdd/guest-kernel-rpc-filesystem.cc',d/'addons/hdd/kernel-rpc-filesystem.cc',
        d/'addons/hdd/kernel-rpc-filesystem-stream.cc',d/'addons/hdd/fatx-hdd.cc']
    exe=root/'csb-hdd-golden'
    cmd=[*common,*map(str,sources),'-l:libglib-2.0.so.0','-o',str(exe)]
    print('+',' '.join(cmd),flush=True);subprocess.run(cmd,check=True)
    subprocess.run([str(exe),str(root/'fixtures')],check=True)
    exe2=root/'csb-core-golden'
    subprocess.run([*common,str(d/'tests/csb-core-golden.cpp'),str(d/'addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc'),'-o',str(exe2)],check=True)
    subprocess.run([str(exe2),str(root/'test-ST.DB')],check=True)
    # Reduced profiles get the real stub and do not link HDD services at all.
    stub_main=root/'stub-main.cc';stub_main.write_text('''#include "addons/custom-soundtrack-builder/custom-soundtrack-hdd.hh"
#include <cassert>
int main(){ using namespace XemuCsb; HddSoundtrackInstaller i; auto d=DetectCsbHddDestination(); std::string e;
HddMusicCatalog c; HddSoundtrackEdit edit; assert(!d.available);assert(!CsbHddReady(e));assert(!ReadCsbHddMusicCatalog(d,c,e));assert(!i.Start(d,"",edit,e));assert(!i.Busy());assert(!i.Succeeded());i.Tick();i.Shutdown();}
''')
    exe3=root/'csb-no-hdd'
    subprocess.run([*common,str(stub_main),str(d/'addons/custom-soundtrack-builder/custom-soundtrack-hdd-stub.cc'),'-o',str(exe3)],check=True)
    subprocess.run([str(exe3)],check=True)
    print('PASS: reduced-profile CSB backend links without HDD symbols',flush=True)
if a.keep:
    root=Path(a.keep).resolve();root.mkdir(parents=True,exist_ok=False);run(root)
else:
    with tempfile.TemporaryDirectory(prefix='csb-hdd-test-') as td:run(Path(td))
