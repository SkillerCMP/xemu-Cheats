#define main LegacyChecks
#include "rpc-scheduler-golden.cc"
#undef main
#include "stream-stub-vm.hh"
namespace S=XemuKernelStream;
static uint64_t calls_create=0,calls_write=0,calls_flush=0,calls_close=0;
static uint32_t create_status=0,write_status=0,flush_status=0,close_status=0;
static uint32_t write_iosb_status=0,other_iosb_status=0,test_irql=0;
static bool force_short=false;
static constexpr uint32_t mock_handle=0x13579u;
static void StreamSyscall(StreamStubVm &vm,uint32_t target){
 auto &m=guest_kernel_rpc_manager;
 if(target==m.m_export_address){vm.Return(0xabcdef00u|test_irql,0);return;}
 if(target==m.m_import_create_export_address){
   auto a=vm.Args(9);++calls_create;assert(!stream_open);
   assert(a[0]==vm.base+S::kHandle);
   assert(a[1]==(XemuKernelRpc::kSynchronizeAccess|XemuKernelRpc::kFileWriteDataAccess));
   assert(a[2]==vm.base+S::kObjects&&a[3]==vm.base+S::kIoStatus&&a[4]==0);
   assert(a[5]==XemuKernelRpc::kFileAttributeNormal&&a[6]==0&&a[7]==XemuKernelRpc::kFileCreate);
   assert(a[8]==(XemuKernelRpc::kFileNonDirectoryFile|XemuKernelRpc::kFileSynchronousIoNonAlert|XemuKernelRpc::kFileOpenForBackupIntent));
   if(create_status==0){stream_open=true;output_bytes.clear();vm.D(a[0],mock_handle);}
   vm.D(a[3],other_iosb_status);vm.D(a[3]+4,1);vm.Return(create_status,9);return;
 }
 if(target==m.m_import_write_export_address){
   auto a=vm.Args(8);++calls_write;assert(stream_open&&a[0]==mock_handle);
   assert(a[1]==0&&a[2]==0&&a[3]==0&&a[4]==vm.base+S::kIoStatus);
   assert(a[5]==vm.base+S::kData&&a[6]<=m.m_stream_metrics.chunk_bytes&&a[6]<=S::kMaxChunkBytes&&a[6]>0&&a[7]==vm.base+S::kByteOffset);
   uint64_t off=vm.D(a[7])|(uint64_t(vm.D(a[7]+4))<<32);assert(off==output_bytes.size());
   uint32_t count=force_short?a[6]-1:a[6];
   if(write_status==0&&write_iosb_status==0)output_bytes.insert(output_bytes.end(),vm.Ptr(a[5],count),vm.Ptr(a[5],count)+count);
   vm.D(a[4],write_iosb_status);vm.D(a[4]+4,count);vm.Return(write_status,8);return;
 }
 if(target==m.m_import_flush_export_address){
   auto a=vm.Args(2);++calls_flush;assert(stream_open&&a[0]==mock_handle&&a[1]==vm.base+S::kIoStatus);
   vm.D(a[1],other_iosb_status);vm.D(a[1]+4,0);vm.Return(flush_status,2);return;
 }
 if(target==m.m_import_close_export_address){
   auto a=vm.Args(1);++calls_close;assert(stream_open&&a[0]==mock_handle);
   if(close_status==0){stream_open=false;visible_file=true;visible_size=static_cast<uint32_t>(output_bytes.size());}
   vm.Return(close_status,1);return;
 }
 throw std::runtime_error("Unknown simulated kernel export");
}
static void ExecuteStream(uint64_t elapsed=2){
 auto &m=guest_kernel_rpc_manager;
 assert(m.m_state==GuestKernelRpcManager::State::RunningFsQuery&&running&&arena_active&&bp);
 StreamStubVm vm;vm.arena=arena.data();vm.arena_size=actual_arena_size;
 vm.base=m.m_arena.virtual_base;vm.pc=m.m_stub_address;vm.completion=m.m_completion_address;
 vm.r={m.m_saved.eax,m.m_saved.ecx,m.m_saved.edx,m.m_saved.ebx,m.m_saved.esp,m.m_saved.ebp,m.m_saved.esi,m.m_saved.edi};
 auto before=vm.r;auto flags=m.m_saved.eflags;vm.flags=flags;vm.syscall=StreamSyscall;vm.Run();
 assert(vm.r==before&&vm.flags==flags);
 regs=m.m_saved;regs.eip=regs.pc=vm.pc;running=false;clock_ms+=elapsed;m.Tick();
}
static void Fixture(uint64_t n){
 Reset();calls_create=calls_write=calls_flush=calls_close=0;
 create_status=write_status=flush_status=close_status=write_iosb_status=other_iosb_status=test_irql=0;force_short=false;
 std::ofstream f(input_path,std::ios::binary|std::ios::trunc);std::vector<char>b(65536);
 for(size_t i=0;i<b.size();++i)b[i]=char((i*43+i/251)%256);
 while(n){auto k=std::min<uint64_t>(n,b.size());f.write(b.data(),k);n-=k;}f.close();assert(f.good());
 regs.eax=0x111;regs.ebx=0x222;regs.ecx=0x333;regs.edx=0x444;regs.esi=0x555;regs.edi=0x666;regs.ebp=0x777;
}
static void ArmFast(uint32_t chunk=S::kChunkBytes){
 std::string e;auto &m=guest_kernel_rpc_manager;
 assert(m.ClaimFilesystemSequence(&owner,e,true,true,chunk));
 XemuKernelFs::ImportPlan plan;assert(m.PrepareHddImport(input_path,false,'E',{},plan,e));
 assert(m.StartHddImport(plan,&owner)&&m.m_import_fast_stream);
 m.m_export_address=0x80010000;m.m_import_create_export_address=0x80011000;m.m_import_write_export_address=0x80012000;m.m_import_flush_export_address=0x80013000;m.m_import_close_export_address=0x80014000;
}
static void Pump(){
 auto &m=guest_kernel_rpc_manager;unsigned limit=0;
 while(m.FilesystemOperationRunning()){
   assert(++limit<300);
   if(m.m_state==GuestKernelRpcManager::State::WaitingSafePoint)SafeSample();
   else if(m.m_state==GuestKernelRpcManager::State::VerifyingImport)m.Tick();else ExecuteStream();
 }
}
int main(int argc,char **argv){
 LegacyChecks(argc,argv);
 unsigned checks=0;auto &m=guest_kernel_rpc_manager;using State=GuestKernelRpcManager::State;
 auto check=[&](bool value){if(!value)std::cerr<<"FAIL stream check "<<checks+1<<": "<<m.Status()<<"\n";assert(value);++checks;};
 for(uint64_t size:{0ull,1ull,524287ull,524288ull,524289ull,2097275ull,67108864ull}){
   Fixture(size);ArmFast();uint64_t snapshots=snapshot_calls;SafeSample();
   check(actual_arena_size==S::ArenaBytesForFile(size,S::kChunkBytes)&&acquires==1&&m.m_safe_point_attempts==1);
   while(m.m_state==State::RunningFsQuery){ExecuteStream();check(snapshot_calls==snapshots&&acquires==1&&releases==0);}
   check(m.m_state==State::VerifyingImport&&!stream_open&&!running&&hash_verifications==0);
   m.Tick();uint64_t chunks=(size+S::kChunkBytes-1)/S::kChunkBytes;
   check(m.LastFilesystemOperationSucceeded()&&m.LastImportContentsVerified()&&output_bytes.size()==size);
   check(calls_create==1&&calls_write==chunks&&calls_flush==1&&calls_close==1&&hash_verifications==1);
   check(!arena_active&&!bp&&running&&releases==1&&regs.eip==0x11000&&regs.esp==0x20000);
   auto stats=m.GetHddOperationProgress();
   check(stats.fast_stream&&stats.chunk_bytes==S::kChunkBytes&&stats.completed_bytes==size&&stats.write_calls==chunks&&stats.verify_ms==7);
   check(stats.open_calls==1&&stats.flush_calls==1&&stats.close_calls==1&&stats.rpc_calls==S::OperationCount(size));
 }
 Fixture(10);ArmFast();for(unsigned i=0;i<600;++i){clock_ms+=100;m.Tick();}
 check(m.FilesystemOperationRunning()&&acquires==0&&calls_create==0);
 m.CancelFilesystemOperation(&owner,"cancel waiting");check(!m.FilesystemOperationRunning()&&!arena_active&&running);
 Fixture(10);ArmFast();SafeSample();test_irql=2;ExecuteStream();
 check(m.m_state==State::WaitingSafePoint&&!stream_open&&!arena_active&&calls_create==0);
 test_irql=0;SafeSample();Pump();check(m.LastImportContentsVerified()&&calls_create==1);
 Fixture(S::kChunkBytes*3+1);ArmFast();SafeSample();ExecuteStream(1000);ExecuteStream(1000);ExecuteStream(1000);Pump();
 check(m.LastImportContentsVerified()&&m.m_safe_point_attempts==1&&acquires==1&&calls_create==1&&calls_write==4);
 for(int n=0;n<3;++n){
   Fixture(S::kChunkBytes*3+1);ArmFast();SafeSample();for(int i=0;i<n;++i)ExecuteStream();
   check(m.CancelFilesystemOperation(&owner,"cancel")&&m.FilesystemOperationRunning()&&arena_active);
   ExecuteStream();check(m.m_stream_action==S::Action::CloseOnly&&stream_open);
   ExecuteStream();check(!m.LastImportContentsVerified()&&!stream_open&&!arena_active&&running&&hash_verifications==0&&calls_close==1&&calls_flush==0);
 }
 Fixture(10);ArmFast();SafeSample();ExecuteStream();ExecuteStream();check(m.m_state==State::VerifyingImport);
 m.CancelFilesystemOperation(&owner,"cancel readback");m.Tick();check(!m.LastImportContentsVerified()&&hash_verifications==0&&!arena_active&&running);
 for(int failure=0;failure<3;++failure){
   Fixture(S::kChunkBytes+1);ArmFast();SafeSample();force_short=failure==0;write_status=failure==1?0xc0000001:0;write_iosb_status=failure==2?0xc0000001:0;
   ExecuteStream();check(m.m_stream_action==S::Action::CloseOnly&&stream_open);ExecuteStream();
   check(!m.LastImportContentsVerified()&&!stream_open&&!arena_active&&running&&calls_close==1&&hash_verifications==0);
 }
 for(int failure=0;failure<7;++failure){
   Fixture(10);ArmFast();SafeSample();
   if(failure==0)create_status=S::kPending;
   if(failure==1)other_iosb_status=S::kPending;
   if(failure==2)write_status=S::kPending;
   if(failure==3)write_iosb_status=S::kPending;
   ExecuteStream();
   if(failure>=4){if(failure==4)flush_status=S::kPending;
   if(failure==5)other_iosb_status=S::kPending;
   if(failure==6)close_status=S::kPending;
     ExecuteStream();}
   check(m.m_state==State::Failed&&arena_active&&bp&&!running&&releases==0&&hash_verifications==0);
   check(m.Status().find("pending")!=std::string::npos&&calls_close==(failure==6?1u:0u));
   check(!m.CancelFilesystemOperation(&owner,"unsafe cancel")&&arena_active);
 }
 Fixture(10);ArmFast();SafeSample();create_status=0xc0000035;ExecuteStream();
 check(!m.LastFilesystemOperationSucceeded()&&!arena_active&&!stream_open&&calls_write==0&&calls_close==0&&running);
 Fixture(10);ArmFast();SafeSample();ExecuteStream();flush_status=0xc0000001;ExecuteStream();
 check(!m.LastImportContentsVerified()&&!stream_open&&!arena_active&&calls_close==1&&hash_verifications==0);
 Fixture(10);ArmFast();SafeSample();ExecuteStream();close_status=0xc0000001;ExecuteStream();
 check(m.m_state==State::Failed&&stream_open&&arena_active&&!running&&releases==0);
 Fixture(S::kChunkBytes+1);ArmFast();SafeSample();ExecuteStream();test_irql=2;ExecuteStream();
 check(m.m_state==State::Failed&&stream_open&&arena_active&&calls_close==0&&!running);
 Fixture(10);ArmFast();SafeSample();verify_corrupt=true;Pump();
 check(!m.LastImportContentsVerified()&&hash_verifications==1&&!arena_active&&!stream_open&&running);
 Fixture(10);ArmFast();mounted_id=2;regs.eip=regs.pc=0x11000;clock_ms+=50;m.Tick();
 check(m.m_state==State::Failed&&calls_create==0&&!arena_active);
 for(int failure=0;failure<7;++failure){
   Fixture(S::kChunkBytes*2+1);ArmFast();SafeSample();ExecuteStream();
   if(failure==0)mounted_id=2;
   if(failure==1)mounted_available=false;
   if(failure==2)mounted_readonly=true;
   if(failure==3)current_game_manager.info.title_id=2;
   if(failure==4)valid_mapping=false;
   if(failure==5){running=false;regs.eip=regs.pc=0x80011001;}if(failure==6)clock_ms+=3001;
   if(failure==4)ExecuteStream();else m.Tick();
   check(m.m_state==State::Failed&&arena_active&&stream_open&&!running&&releases==0&&calls_close==0);
 }
 for(int failure=0;failure<2;++failure){
   Fixture(S::kChunkBytes*3+1);ArmFast();SafeSample();ExecuteStream();
   if(failure==0)fail_arena_write=true;else fail_close_breakpoint=true;
   ExecuteStream();check(m.m_state==State::Failed&&stream_open&&arena_active&&!running&&calls_close==0);
 }
 Fixture(10);ArmFast();fail_acquire=true;regs.eip=regs.pc=0x11000;clock_ms+=50;m.Tick();
 check(m.m_state==State::Failed&&!arena_active&&calls_create==0&&running);
 Fixture(S::kChunkBytes*3+1);ArmFast();SafeSample();ExecuteStream();{std::ofstream f(input_path,std::ios::trunc);f<<"changed";}
 ExecuteStream();check(m.m_stream_action==S::Action::CloseOnly);ExecuteStream();check(!m.LastImportContentsVerified()&&!arena_active&&!stream_open&&hash_verifications==0);
 // Retained FATX source files take the same stream path but compare against
 // one unchanged source identity in their final full content verification.
 for(bool corrupt:{false,true}){
   Fixture(S::kChunkBytes*2+17);use_fatx_source=true;copy_source.assign(S::kChunkBytes*2+17,0x5a);
   std::string why;XemuKernelFs::ImportPlan plan;
   check(m.ClaimFilesystemSequence(&owner,why,true,true));
   check(m.PrepareHddCopy('E',{"source.wma"},false,'E',{"stage"},false,plan,why));
   check(m.StartHddImport(plan,&owner)&&m.m_import_fast_stream);
   m.m_export_address=0x80010000;m.m_import_create_export_address=0x80011000;m.m_import_write_export_address=0x80012000;m.m_import_flush_export_address=0x80013000;m.m_import_close_export_address=0x80014000;
   verify_corrupt=corrupt;SafeSample();Pump();
   check(m.LastImportContentsVerified()!=corrupt&&output_bytes==copy_source&&copy_verifications==1&&hash_verifications==0);
   check(source_reads==3&&calls_create==1&&calls_write==3&&calls_flush==1&&calls_close==1&&!stream_open&&!arena_active);
 }
 S::Stub stub;std::string e;S::Exports exports{1,2,3,4,5};
 check(!S::BuildStub(0xfff80000,exports,S::Action::OpenWrite,S::kChunkBytes,stub,e));
 check(!S::BuildStub(0x1000000,exports,S::Action::Write,0,stub,e));
 check(!S::BuildStub(0x1000000,exports,S::Action::FlushClose,1,stub,e));
 check(!S::BuildStub(0x1000000,exports,S::Action::OpenWrite,S::kMaxChunkBytes+1,stub,e));
 // TEST8: every selectable policy, including the exact 4 MiB payload and
 // both sides of its payload boundary. Real stub bytes run in the test VM;
 // production page tables are tested independently in arena-memory-golden.c.
 for(uint32_t chunk:{S::kChunkBytes,1048576u,2097152u,S::kMaxChunkBytes}) {
   for(uint64_t size:{0ull,1ull,(unsigned long long)chunk-1,
       (unsigned long long)chunk,(unsigned long long)chunk+1,
       (unsigned long long)chunk*2+123,67108864ull}) {
     Fixture(size);ArmFast(chunk);
     const uint64_t snapshots=snapshot_calls;SafeSample();
     check(actual_arena_size==S::ArenaBytesForFile(size,chunk));
     check(actual_arena_size<=0x402000&&m.m_stream_metrics.chunk_bytes==chunk);
     check(!m.ClaimFilesystemSequence(&other_owner,e,true,true,S::kChunkBytes));
     while(m.m_state==State::RunningFsQuery) {
       ExecuteStream();check(snapshot_calls==snapshots&&acquires==1&&releases==0);
     }
     check(m.m_state==State::VerifyingImport&&calls_close==1&&!stream_open);
     m.Tick();const uint64_t writes=size/chunk+(size%chunk!=0);
     check(m.LastImportContentsVerified()&&output_bytes.size()==size&&calls_write==writes);
     check(calls_create==1&&calls_flush==1&&calls_close==1&&hash_verifications==1);
     check(arena_refills==S::OperationCount(size,chunk)&&refill_payload_bytes==size);
     check(m.GetHddOperationProgress().chunk_bytes==chunk&&!bp&&!arena_active&&running);
   }
 }
 // Invalid sizes never claim the sequence or open a staging handle.
 for(uint32_t chunk:{0u,1u,524289u,4194305u,8388608u,UINT32_MAX}) {
   Fixture(10);check(!m.ClaimFilesystemSequence(&owner,e,true,true,chunk));
   check(!m.OperationBusy()&&calls_create==0&&!arena_active);
   check(S::OperationCount(10,chunk)==0&&S::ArenaBytesForFile(10,chunk)==0);
 }
 // 4 MiB short/error/pending/cancel/timeout paths retain exactly the same
 // ownership rules as the conservative and TEST7 paths.
 for(int mode=0;mode<6;++mode) {
   Fixture(S::kMaxChunkBytes+1ull);ArmFast(S::kMaxChunkBytes);SafeSample();
   if(mode==0)force_short=true;
   if(mode==1)write_status=0xc0000001u;
   if(mode==2)write_iosb_status=S::kPending;
   if(mode==3)check(m.CancelFilesystemOperation(&owner,"cancel 4 MiB"));
   if(mode==4){clock_ms+=3001;m.Tick();}
   else ExecuteStream();
   if(mode==5){valid_mapping=false;ExecuteStream();}
   if(mode==2||mode==4||mode==5) {
     check(m.m_state==State::Failed&&arena_active&&bp&&!running&&hash_verifications==0);
   } else {
     check(m.m_stream_action==S::Action::CloseOnly);ExecuteStream();
     check(!m.LastImportContentsVerified()&&!arena_active&&!stream_open&&running&&hash_verifications==0);
   }
 }
 // Retained FATX source: a full 4 MiB chunk plus a short tail, verified once.
 Fixture(S::kMaxChunkBytes+17ull);use_fatx_source=true;copy_source.assign(S::kMaxChunkBytes+17ull,0x5a);
 XemuKernelFs::ImportPlan copy_plan;
 check(m.ClaimFilesystemSequence(&owner,e,true,true,S::kMaxChunkBytes));
 check(m.PrepareHddCopy('E',{"source.wma"},false,'E',{"stage"},false,copy_plan,e));
 check(m.StartHddImport(copy_plan,&owner));
 m.m_export_address=0x80010000;m.m_import_create_export_address=0x80011000;m.m_import_write_export_address=0x80012000;m.m_import_flush_export_address=0x80013000;m.m_import_close_export_address=0x80014000;
 SafeSample();Pump();check(m.LastImportContentsVerified()&&output_bytes==copy_source&&calls_write==2&&copy_verifications==1&&source_reads==2);
 // Sequential-buffer reuse and nonsequential host seeks, with real file I/O.
 Fixture(S::kMaxChunkBytes*2ull+31);
 XemuKernelFs::ImportPlan host_plan;check(m.PrepareHddImport(input_path,false,'E',{},host_plan,e));
 const auto entry=host_plan.entries.front();XemuKernelFs::ImportHostStream cache;
 std::vector<uint8_t> buffer;uint32_t bytes=0;uint64_t expected=0;
 auto pattern=[](uint64_t off){off%=65536;return uint8_t((off*43+off/251)%256);};
 uint8_t *first=nullptr;
 for(uint64_t offset:{0ull,4194304ull,13ull,0ull,8388608ull}) {
   check(XemuKernelFs::LoadImportFileChunk(cache,entry,offset,buffer,bytes,expected,e,S::kMaxChunkBytes));
   check(bytes==std::min<uint64_t>(S::kMaxChunkBytes,entry.file_size-offset)&&expected==offset+bytes);
   bool identical=true;for(size_t j=0;j<buffer.size();++j)if(buffer[j]!=pattern(offset+j)){identical=false;break;}
   check(identical);
   if(!first)first=buffer.data();else check(buffer.data()==first);
 }
 check(!XemuKernelFs::LoadImportFileChunk(cache,entry,entry.file_size+1,buffer,bytes,expected,e,S::kMaxChunkBytes)&&buffer.empty()&&bytes==0);
 check(!XemuKernelFs::LoadImportFileChunk(cache,entry,0,buffer,bytes,expected,e,S::kMaxChunkBytes+1)&&buffer.empty());
 Fixture(1);ArmFast();check(m.m_stream_metrics.chunk_bytes==S::kChunkBytes); // old caller default
 Reset();std::cout<<"PASS: TEST8 stream scheduler + emitted-instruction interpreter / MOCK Xbox syscalls ("<<checks<<" checks). Not actual Xbox execution.\n";
}
