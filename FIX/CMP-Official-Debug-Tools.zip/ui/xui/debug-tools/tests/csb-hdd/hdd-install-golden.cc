// Production CSB TEST12 dashboard-format + TEST11 isolated-transaction installer harness.
// Xbox execution, block source and snapshots are mocked; production planners,
// catalog parser and installer orchestration are linked unchanged.
#include "addons/custom-soundtrack-builder/custom-soundtrack-hdd.hh"
#include "addons/custom-soundtrack-builder/custom-soundtrack-builder-core.hh"
#include "addons/hdd/guest-kernel-rpc.hh"
#include "addons/hdd/hdd-snapshot-service.hh"
#include "addons/hdd/hdd-directory.hh"
#include "disc-block-io.h"
#include "current-game.hh"
#include "xemu-settings.h"
#include <glib.h>
#include <algorithm>
#include <cassert>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using Path = std::vector<std::string>;
namespace fs = std::filesystem;
struct config g_config{};
CurrentGameManager current_game_manager;
GuestKernelRpcManager guest_kernel_rpc_manager;
HddSnapshotService hdd_snapshot_service;
HddDirectoryWindow hdd_directory_window;

struct Node { bool dir; uint32_t cluster; std::vector<uint8_t> data; Path raw; };
static std::map<std::string, Node> disk;
static std::vector<std::string> operations;
static bool mounted=true,readonly_disk=false,folder=false,running=true;
static bool fail_copy=false,corrupt_read=false,fail_publish=false,fail_restore=false,fail_sync=false,fail_snapshot=false;
static bool hold_rpc=false, enter_inflight=false, fail_after_move=false, fail_cleanup=false;
static int fail_move_at=0, move_attempts=0;
static bool simulate_fast_proof=false;
static unsigned fast_proofs=0;
static std::vector<uint32_t> observed_stream_chunks;
static std::vector<std::string> data_reads;
static uintptr_t identity=1; static uint32_t next_cluster=10; static uint64_t free_bytes=256ull<<20;
static unsigned sync_count=0,read_count=0; static std::string active_path="/tmp/test.qcow2";
static std::string Key(const Path &path){std::string k;for(auto part:path){std::transform(part.begin(),part.end(),part.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});if(!k.empty())k+='/';k+=part;}return k;}
static Path Split(const std::string &key){Path p;size_t s=0;while(s<key.size()){size_t n=key.find('/',s);p.push_back(key.substr(s,n-s));if(n==std::string::npos)break;s=n+1;}return p;}
static std::vector<uint8_t> Read(const std::string &path){std::ifstream f(fs::u8path(path),std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
static void Write(const fs::path &path,const std::vector<uint8_t>&b){fs::create_directories(path.parent_path());std::ofstream f(path,std::ios::binary|std::ios::trunc);f.write((const char*)b.data(),(std::streamsize)b.size());assert(f.good());}
static void WriteText(const fs::path &path,const std::string&s){Write(path,{s.begin(),s.end()});}
static void Put(const std::string &path,bool dir,std::vector<uint8_t> bytes={},Path raw={}){assert(!disk.count(path));disk.emplace(path,Node{dir,next_cluster++,std::move(bytes),raw.empty()?Split(path):std::move(raw)});}
static bool Exists(const std::string &path){return disk.count(path)!=0;}
static bool HasPrefix(const std::string &prefix){return std::any_of(disk.begin(),disk.end(),[&](const auto&e){return e.first.rfind(prefix,0)==0;});}
static void Move(const std::string &from,const std::string &to,const Path &raw_to){std::vector<std::pair<std::string,Node>> moved;for(auto it=disk.begin();it!=disk.end();){if(it->first==from||it->first.rfind(from+"/",0)==0){Path raw=raw_to;size_t prefix=Split(from).size();raw.insert(raw.end(),it->second.raw.begin()+prefix,it->second.raw.end());it->second.raw=std::move(raw);moved.emplace_back(to+it->first.substr(from.size()),std::move(it->second));it=disk.erase(it);}else ++it;}for(auto&p:moved)disk.emplace(std::move(p));}
static XemuFatxHdd::Snapshot MakeSnapshot(){XemuFatxHdd::Snapshot s;s.hdd_available=true;s.image_size=8ull<<30;XemuFatxHdd::Partition p;p.letter='E';p.available=true;p.bytes_per_cluster=16384;for(const auto&kv:disk){Path path=kv.second.raw;auto*children=&p.entries;for(size_t i=0;i<path.size();++i){auto it=std::find_if(children->begin(),children->end(),[&](const auto&e){return XemuKernelFs::EqualsNoCase(e.name,path[i]);});if(it==children->end()){XemuFatxHdd::Entry e;e.name=path[i];e.display_name=path[i];e.directory=true;children->push_back(e);it=children->end()-1;}if(i+1==path.size()){it->directory=kv.second.dir;it->attributes=kv.second.dir?0x10:0x20;it->file_size=(uint32_t)kv.second.data.size();it->first_cluster=kv.second.cluster;it->directory_entry_offset=(uint64_t)kv.second.cluster*64;it->modified_time=1;it->modified_date=1;}children=&it->children;}}s.partitions.push_back(std::move(p));return s;}
extern "C" {
XemuDiscBlockHandle xemu_disc_block_acquire_by_name(const char *name){assert(!std::strcmp(name,"ide0-hd0"));return mounted?reinterpret_cast<void*>(1):nullptr;}
void xemu_disc_block_release(XemuDiscBlockHandle){} bool xemu_disc_block_is_available(XemuDiscBlockHandle){return mounted;}
uintptr_t xemu_disc_block_identity(XemuDiscBlockHandle){return identity;} char*xemu_disc_block_source_path(XemuDiscBlockHandle){return g_strdup(active_path.c_str());}
bool xemu_disc_block_is_read_only(XemuDiscBlockHandle){return readonly_disk;} bool cmp_folder_hdd_is_active(void){return folder;}
char*cmp_folder_hdd_get_active_root(void){return folder?g_strdup(active_path.c_str()):nullptr;} bool runstate_is_running(void){return running;} int xemu_guest_rpc_arena_active(void){return 0;}
}
void detached_tools_open_or_focus(bool *open){*open=true;} uint64_t SDL_GetTicks(){static uint64_t t=10;return ++t;}
bool HddSnapshotService::BuildRawPartitionSnapshot(char part,XemuFatxHdd::Snapshot &out,std::string &error)const{assert(part=='E');if(fail_snapshot){error="injected snapshot failure";return false;}out=MakeSnapshot();return true;}
bool HddSnapshotService::BuildRawPartitionSetSnapshot(const std::vector<char>&parts,XemuFatxHdd::Snapshot&out,std::string&error)const{assert(!parts.empty());return BuildRawPartitionSnapshot('E',out,error);}
bool HddSnapshotService::QueryPartitionCapacity(char part,CapacityInfo&out,std::string&)const{assert(part=='E');out.partition='E';out.bytes_per_cluster=16384;out.free_bytes=free_bytes;return true;}
bool HddSnapshotService::RescanFolderHdd(std::string&error)const{++sync_count;if(fail_sync){error="injected mirror conflict";return false;}return true;}
bool HddSnapshotService::ReadFatxFileChunk(char part,const Path&path,uint64_t off,uint32_t cluster,uint16_t time,uint16_t date,uint8_t attrs,uint64_t size,uint64_t pos,size_t count,std::vector<uint8_t>&out,std::string&error)const{++read_count;data_reads.push_back(Key(path));assert(part=='E');auto it=disk.find(Key(path));if(it==disk.end()||it->second.dir||it->second.data.size()!=size||it->second.cluster!=cluster||off!=(uint64_t)cluster*64||time!=1||date!=1||attrs!=0x20||pos>=size){error="fake FATX identity mismatch";return false;}auto end=pos+std::min<uint64_t>(size-pos,count);out.assign(it->second.data.begin()+pos,it->second.data.begin()+end);if(corrupt_read&&!out.empty())out[0]^=0x80;return true;}

bool GuestKernelRpcManager::IsBusy()const{return m_state==State::Running||m_state==State::WaitingSafePoint||m_state==State::RunningFsQuery;}
bool GuestKernelRpcManager::LoadKernelImportOperation(std::string&){return true;} bool GuestKernelRpcManager::LoadRecursiveDeleteEntry(size_t,std::string&){return true;}
void GuestKernelRpcManager::Tick()
{
    if(!IsBusy() || CancelAtSafeBoundary()) return;
    if(enter_inflight) { m_state=State::RunningFsQuery; enter_inflight=false; hold_rpc=true; }
    if(hold_rpc) return;
    bool ok=true;
    if(m_fs_test_mode==FsTestMode::KernelImportFolder) {
        for(const auto&entry:m_import_preflight.entries) {
            const std::string key=Key(entry.components);
            operations.push_back((entry.source_from_fatx?"copy:":"import:")+key);
            if(Exists(key)){ok=false;break;}
            if(fail_copy&&!entry.directory){Put(key,false,{0},entry.components);ok=false;break;}
            if(entry.directory){Put(key,true,{},entry.components);continue;}
            std::vector<uint8_t> bytes;
            if(entry.source_from_fatx){auto src=disk.find(Key(entry.source_components));if(src==disk.end()||src->second.dir){ok=false;break;}bytes=src->second.data;}
            else bytes=Read(entry.host_path);
            Put(key,false,std::move(bytes),entry.components);
        }
    } else if(m_fs_test_mode==FsTestMode::KernelRelocate) {
        const auto from=Key(m_relocate_plan.source_components),to=Key(m_relocate_plan.destination_components);
        operations.push_back("rename:"+from+"->"+to);
        const bool recovery=from.rfind("tdata/csbbackup/csb-",0)==0;
        const bool stage=recovery&&from.find("/stage/")!=std::string::npos;
        const bool backup=recovery&&from.find("/backup/")!=std::string::npos;
        ++move_attempts;
        if((fail_publish&&stage)||(fail_restore&&backup)||Exists(to)||!Exists(from))ok=false;
        else if (fail_move_at==move_attempts) {
            if(fail_after_move) Move(from,to,m_relocate_plan.destination_components);
            ok=false;
        } else Move(from,to,m_relocate_plan.destination_components);
    } else if(m_fs_test_mode==FsTestMode::KernelDeleteRecursiveFolder) {
        for(const auto &entry:m_recursive_delete_plan) {
            const auto key=Key(entry.components);operations.push_back("delete:"+key);
            auto it=disk.find(key);
            if(fail_cleanup||it==disk.end()||(it->second.dir&&HasPrefix(key+"/"))){ok=false;break;}
            disk.erase(it);
        }
    } else assert(false);
    if(ok&&simulate_fast_proof&&m_import_fast_stream&&m_fs_test_mode==FsTestMode::KernelImportFolder) {
        assert(m_import_preflight.entries.size()==1);const auto &e=m_import_preflight.entries.front();
        const auto &bytes=disk.at(Key(e.components)).data;
        ok=e.source_from_fatx?bytes==disk.at(Key(e.source_components)).data:
            XemuKernelFs::UpdateContentHash(XemuKernelFs::kContentHashBasis,bytes.data(),bytes.size())==e.host_content_hash;
        if(ok){observed_stream_chunks.push_back(m_stream_metrics.chunk_bytes);m_stream_contents_verified=true;++fast_proofs;m_import_written_bytes=e.file_size;
            m_stream_metrics.open_calls=m_stream_metrics.flush_calls=m_stream_metrics.close_calls=1;
            m_stream_metrics.write_calls=(e.file_size+XemuKernelStream::kChunkBytes-1)/XemuKernelStream::kChunkBytes;
            m_stream_metrics.rpc_calls=m_stream_metrics.write_calls+1;
            m_stream_metrics.verify_ms=1;}
    }
    m_state=ok?State::Passed:State::Failed;
    m_status=ok?"fake kernel complete":"injected kernel failure";
}


static std::vector<uint8_t> MakeDb(const fs::path&tmp,std::vector<XemuCsb::StDbSoundtrack> sets){std::string error;assert(XemuCsb::WriteStDb(tmp.u8string(),sets,error));auto b=Read(tmp.u8string());fs::remove(tmp);return b;}
static void PutBaseDirs(){Put("tdata",true,{}, {"TDATA"});Put("tdata/fffe0000",true,{}, {"TDATA","fffe0000"});Put("tdata/fffe0000/music",true,{}, {"TDATA","fffe0000","music"});}
static void Reset(bool use_folder=false){assert(!guest_kernel_rpc_manager.OperationBusy());mounted=true;readonly_disk=false;running=true;folder=use_folder;identity=1;free_bytes=256ull<<20;fail_copy=corrupt_read=fail_publish=fail_restore=fail_sync=fail_snapshot=false;hold_rpc=enter_inflight=fail_after_move=fail_cleanup=false;fail_move_at=move_attempts=0;simulate_fast_proof=false;fast_proofs=0;observed_stream_chunks.clear();data_reads.clear();sync_count=read_count=0;disk.clear();operations.clear();next_cluster=10;active_path=use_folder?"/tmp/Xemu HDD":"/tmp/test.qcow2";g_config.sys.files.hdd_type=use_folder?CONFIG_SYS_FILES_HDD_TYPE_FOLDER:CONFIG_SYS_FILES_HDD_TYPE_IMAGE;g_config.sys.files.hdd_path=const_cast<char*>("/tmp/test.qcow2");g_config.sys.files.hdd_folder_path=const_cast<char*>("/tmp/Xemu HDD");current_game_manager.info={true,0x4d530064,0x100000};}
static void PutCollection(const fs::path&tmp,bool second=false,bool orphan=false){PutBaseDirs();std::vector<XemuCsb::StDbSoundtrack> sets={{0,"Existing Zero",{{0,5000,"Old A"}}}};if(second)sets.push_back({1,"Existing One",{{0,6000,"Old B"}}});Put("tdata/fffe0000/music/st.db",false,MakeDb(tmp,sets),{"TDATA","fffe0000","music","ST.DB"});Put("tdata/fffe0000/music/0000",true,{}, {"TDATA","fffe0000","music","0000"});Put("tdata/fffe0000/music/0000/00000000.wma",false,{1,2,3,4},{"TDATA","fffe0000","music","0000","00000000.WMA"});if(second){Put("tdata/fffe0000/music/0001",true,{}, {"TDATA","fffe0000","music","0001"});Put("tdata/fffe0000/music/0001/00010000.wma",false,{5,6,7},{"TDATA","fffe0000","music","0001","00010000.WMA"});}if(orphan){Put("tdata/fffe0000/music/0002",true,{}, {"TDATA","fffe0000","music","0002"});Put("tdata/fffe0000/music/0002/00020000.wma",false,{8,9},{"TDATA","fffe0000","music","0002","00020000.WMA"});}}
static void Pump(XemuCsb::HddSoundtrackInstaller&i){for(unsigned n=0;n<4000&&i.Busy();++n){guest_kernel_rpc_manager.Tick();i.Tick();}assert(!i.Busy());assert(!guest_kernel_rpc_manager.OperationBusy());if(!i.Succeeded())std::cerr<<"pump: "<<i.Status()<<"\n";}

int main(int argc,char**argv){assert(argc==2);fs::path base=fs::u8path(argv[1]);fs::create_directories(base);fs::path local=base/"local"/"music";fs::create_directories(local);std::string error;unsigned scenarios=0;using namespace XemuCsb;auto check=[&](bool v){if(!v)std::cerr<<"FAILED scenario "<<scenarios+1<<" error="<<error<<"\n";assert(v);++scenarios;};
    Reset();auto d=DetectCsbHddDestination();check(d.available&&d.source==HddSource::Image&&std::string(d.ButtonLabel())=="SAVE TO MOUNTED HDD IMAGE");
    Reset(true);d=DetectCsbHddDestination();check(d.available&&d.source==HddSource::Folder&&std::string(d.ButtonLabel())=="SAVE TO FOLDER HDD");
    Reset();g_config.sys.files.hdd_path=const_cast<char*>("");check(!DetectCsbHddDestination().available);

    // Catalog parses ST.DB and also surfaces an unlisted four-hex folder.
    Reset();PutCollection(base/"dbtmp",true,true);HddMusicCatalog cat;check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error)&&cat.database_valid&&cat.next_soundtrack_id==2&&cat.next_song_id==1&&cat.soundtrack_id_index_consistent&&cat.soundtracks.size()==3&&cat.soundtracks[2].soundtrack_id==2&&!cat.soundtracks[2].listed_in_database);

    // A TEST11-style malformed soundtrackIds[] header remains readable and is
    // explicitly flagged for repair instead of being mistaken for track corruption.
    Reset();PutCollection(base/"dbtmp",true,false);
    { auto &db=disk.at("tdata/fffe0000/music/st.db").data; db[0x0C]=1;db[0x0D]=db[0x0E]=db[0x0F]=0;db[0x10]=db[0x11]=db[0x12]=db[0x13]=0; }
    check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error)&&cat.database_valid&&!cat.soundtrack_id_index_consistent&&
          std::any_of(cat.warnings.begin(),cat.warnings.end(),[](const auto&w){return w.find("soundtrackIds[]")!=std::string::npos;}));

    // A no-content-change SAVE of an existing soundtrack may repair that index
    // through the same TEST11 guarded selected-folder/database transaction.
    fs::remove_all(local);fs::create_directories(local);
    Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"Existing One",{{0,6000,"Old B"}}}}));
    { HddSoundtrackEdit repair;repair.soundtrack_id=0;repair.target_existed=true;repair.retained_song_ids={0};repair.expected_fingerprint=cat.fingerprint;
      HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),repair,error));Pump(i);check(i.Succeeded());
      StDbMetadata repaired_meta;std::vector<StDbSoundtrack> repaired_sets;
      check(ReadStDb(disk.at("tdata/fffe0000/music/st.db").data,repaired_sets,error,&repaired_meta)&&repaired_meta.soundtrack_id_index_matches_records&&
            repaired_meta.header_soundtrack_ids==std::vector<uint16_t>({0,1})); }

    // Add ID 1 to existing ID 0; ID 0 stays in place, without ANY FATX copy.
    Reset();PutCollection(base/"dbtmp");fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","new-one");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"New One",{{0,7000,"New Track"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));HddSoundtrackEdit edit;edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};HddSoundtrackInstaller add;check(add.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(add);check(add.Succeeded()&&Exists("tdata/fffe0000/music/0000/00000000.wma")&&Exists("tdata/fffe0000/music/0001/00010000.wma")&&!HasPrefix("tdata/csbbackup")&&std::find_if(operations.begin(),operations.end(),[](const auto&s){return s.rfind("copy:",0)==0;})==operations.end());

    // Legacy TEST6-TEST9 recovery siblings under fffe0000 are never guessed
    // safe or auto-deleted by the isolated transaction design.
    Reset();PutCollection(base/"dbtmp");
    Put("tdata/fffe0000/music.csb-backup-old",true,{}, {"TDATA","fffe0000","music.CSB-backup-OLD"});
    Put("tdata/fffe0000/music.csb-backup-old/st.db",false,{0x11,0x22},{"TDATA","fffe0000","music.CSB-backup-OLD","ST.DB"});
    Put("tdata/fffe0000/music.csb-stage-old",true,{}, {"TDATA","fffe0000","music.CSB-stage-OLD"});
    Put("tdata/fffe0000/music.csb-stage-old/st.db",false,{0x33,0x44},{"TDATA","fffe0000","music.CSB-stage-OLD","ST.DB"});
    fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","legacy-safe");
    Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"Legacy Safe",{{0,7000,"Track"}}}}));
    check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};
    {HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);
     check(i.Succeeded()&&Exists("tdata/fffe0000/music.csb-backup-old/st.db")&&Exists("tdata/fffe0000/music.csb-stage-old/st.db")&&!HasPrefix("tdata/csbbackup"));}

    // If CSBBACKUP already contains unrelated/manual recovery material, only
    // this transaction is removed and the nonempty root is left in place.
    Reset();PutCollection(base/"dbtmp");
    Put("tdata/csbbackup",true,{}, {"TDATA","CSBBACKUP"});
    Put("tdata/csbbackup/manual-recovery",true,{}, {"TDATA","CSBBACKUP","manual-recovery"});
    Put("tdata/csbbackup/manual-recovery/database.bak",false,{0x55},{"TDATA","CSBBACKUP","manual-recovery","database.bak"});
    fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","root-safe");
    Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"Root Safe",{{0,7000,"Track"}}}}));
    check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};
    {HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);
     check(i.Succeeded()&&Exists("tdata/csbbackup/manual-recovery/database.bak")&&!HasPrefix("tdata/csbbackup/csb-"));}

    // Edit ID 0: retain old song 0 and add song 1; unrelated ID 1 is preserved.
    Reset();PutCollection(base/"dbtmp",true);fs::remove_all(local);fs::create_directories(local/"0000");WriteText(local/"0000/00000001.WMA","new-two");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Edited Zero",{{0,5000,"Old A"},{1,8000,"New B"}}},{1,"Existing One",{{0,6000,"Old B"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.target_existed=true;edit.expected_fingerprint=cat.fingerprint;edit.retained_song_ids={0};edit.local_song_ids={1};HddSoundtrackInstaller update;check(update.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(update);check(update.Succeeded()&&Exists("tdata/fffe0000/music/0000/00000000.wma")&&Exists("tdata/fffe0000/music/0000/00000001.wma")&&Exists("tdata/fffe0000/music/0001/00010000.wma"));

    // Delete ID 0 while preserving ID 1.
    Reset();PutCollection(base/"dbtmp",true);fs::remove_all(local);fs::create_directories(local);Write(local/"ST.DB",MakeDb(base/"dbtmp",{{1,"Existing One",{{0,6000,"Old B"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.delete_soundtrack=true;edit.target_existed=true;edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller del;check(del.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(del);check(del.Succeeded()&&!HasPrefix("tdata/fffe0000/music/0000/")&&Exists("tdata/fffe0000/music/0001/00010000.wma"));

    // Delete orphan ID 2 without changing ST.DB records.
    Reset();PutCollection(base/"dbtmp",false,true);fs::remove_all(local);fs::create_directories(local);Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=2;edit.delete_soundtrack=true;edit.target_existed=true;edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller odel;check(odel.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(odel);check(odel.Succeeded()&&!HasPrefix("tdata/fffe0000/music/0002/")&&Exists("tdata/fffe0000/music/0000/00000000.wma"));

    // Orphan-only music with no ST.DB can be deleted without inventing/overwriting a database.
    Reset();PutBaseDirs();Put("tdata/fffe0000/music/0002",true,{}, {"TDATA","fffe0000","music","0002"});Put("tdata/fffe0000/music/0002/00020000.wma",false,{8,9},{"TDATA","fffe0000","music","0002","00020000.WMA"});fs::remove_all(local);fs::create_directories(local);WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error)&&!cat.database_exists&&cat.soundtracks.size()==1);edit={};edit.soundtrack_id=2;edit.delete_soundtrack=true;edit.target_existed=true;edit.preserve_database=true;edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller orphanonly;check(orphanonly.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(orphanonly);check(orphanonly.Succeeded()&&!HasPrefix("tdata/fffe0000/music/0002/")&&!Exists("tdata/fffe0000/music/st.db"));

    // Accidental ID collision is rejected.
    Reset();PutCollection(base/"dbtmp");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.target_existed=false;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};HddSoundtrackInstaller collision;check(!collision.Start(DetectCsbHddDestination(),local.u8string(),edit,error));

    // Fingerprint changes are rejected before writes.
    Reset();PutCollection(base/"dbtmp");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));disk.at("tdata/fffe0000/music/st.db").data.push_back(0);edit={};edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};HddSoundtrackInstaller stale;check(!stale.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());

    // Folder-HDD synchronizes on catalog read and after successful publish.
    Reset(true);PutCollection(base/"dbtmp");fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","folder-new");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"Folder New",{{0,7000,"New"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};unsigned before=sync_count;HddSoundtrackInstaller fi;check(fi.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(fi);check(fi.Succeeded()&&sync_count>before);

    // Publish failure restores the original collection.
    Reset();PutCollection(base/"dbtmp");fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","x");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"Fail",{{0,1,"x"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=1;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};HddSoundtrackInstaller restore;check(restore.Start(DetectCsbHddDestination(),local.u8string(),edit,error));fail_publish=true;Pump(restore);check(!restore.Succeeded()&&Exists("tdata/fffe0000/music/0000/00000000.wma"));

    // Source change after start prevents publication.
    Reset();fs::remove_all(local);fs::create_directories(local/"0000");WriteText(local/"0000/00000000.WMA","fresh");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Fresh",{{0,1,"fresh"}}}}));WriteText(local/"CSB-BUILD.json","{}");check(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.expected_fingerprint=cat.fingerprint;edit.local_song_ids={0};HddSoundtrackInstaller source;check(source.Start(DetectCsbHddDestination(),local.u8string(),edit,error));identity=2;Pump(source);check(!source.Succeeded());


    // Reusable fixture for failure/cancellation tests. Only ID 0 changes;
    // unrelated ID 1 must keep bytes AND allocation identity.
    auto prepare_update = [&]() {
        Reset(); PutCollection(base/"dbtmp",true);
        fs::remove_all(local); fs::create_directories(local/"0000");
        WriteText(local/"0000/00000001.WMA","replacement-track");
        Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Changed",{{0,5000,"Old A"},{1,1000,"Added"}}},{1,"Existing One",{{0,6000,"Old B"}}}}));
        assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));
        edit={};edit.soundtrack_id=0;edit.target_existed=true;edit.expected_fingerprint=cat.fingerprint;
        edit.retained_song_ids={0};edit.local_song_ids={1};
    };
    auto live_collection = [&]() {
        std::map<std::string,std::pair<uint32_t,std::vector<uint8_t>>> out;
        for(const auto &kv:disk) if(kv.first.rfind("tdata/fffe0000/music/",0)==0)
            out.emplace(kv.first,std::make_pair(kv.second.cluster,kv.second.data));
        return out;
    };
    // The isolated transaction stages outside fffe0000, never creates a
    // temporary ST.DB, backs up only ID 0 + the old DB, and publishes ST.DB last.
    prepare_update();{
        HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        for(int n=0;n<4000&&move_attempts<4;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<4)i.Tick();}
        assert(move_attempts==4);
        check(Exists("tdata/fffe0000/music/0000/00000001.wma")&&HasPrefix("tdata/csbbackup/csb-"));
        bool saw_new_db=false,saw_temp_stdb=false,saw_unrelated_backup=false;
        for(const auto &kv:disk){
            if(kv.first.rfind("tdata/csbbackup/csb-",0)!=0)continue;
            if(kv.first.find("/stage/database.new")!=std::string::npos)saw_new_db=true;
            if(kv.first.size()>=6&&kv.first.substr(kv.first.size()-6)=="/st.db")saw_temp_stdb=true;
            if(kv.first.find("/backup/0001")!=std::string::npos)saw_unrelated_backup=true;
        }
        std::vector<std::string> renames;for(const auto &op:operations)if(op.rfind("rename:",0)==0)renames.push_back(op);
        check(saw_new_db==false&&!saw_temp_stdb&&!saw_unrelated_backup&&renames.size()==4&&
            renames[0].find("tdata/fffe0000/music/0000->tdata/csbbackup/csb-")!=std::string::npos&&
            renames[1].find("/stage/0000->tdata/fffe0000/music/0000")!=std::string::npos&&
            renames[2].find("tdata/fffe0000/music/st.db->tdata/csbbackup/csb-")!=std::string::npos&&renames[2].find("/backup/database.bak")!=std::string::npos&&
            renames[3].find("/stage/database.new->tdata/fffe0000/music/st.db")!=std::string::npos);
        Pump(i);check(i.Succeeded()&&!HasPrefix("tdata/csbbackup"));
    }

    // Corrupt an installed WMA after all four publication renames but before
    // PublishedCheck. Fresh FATX verification must detect it and guarded
    // rollback must restore the exact original live collection.
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        for(int n=0;n<4000&&move_attempts<4;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<4)i.Tick();}
        assert(move_attempts==4&&Exists("tdata/fffe0000/music/0000/00000001.wma"));
        disk.at("tdata/fffe0000/music/0000/00000001.wma").data[0]^=0x40;
        Pump(i);check(!i.Succeeded()&&live_collection()==original&&HasPrefix("tdata/csbbackup/csb-")&&i.Status().find("Fresh publication verification failed")!=std::string::npos);
    }

    // All four publication moves fail both before and AFTER mutation. The
    // production controller observes both names and rolls back in reverse.
    for(int at=1;at<=4;++at) for(bool after:{false,true}) {
        prepare_update();const auto original=live_collection();
        HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        fail_move_at=at;fail_after_move=after;Pump(i);
        check(!i.Succeeded()&&live_collection()==original);
    }
    // Cancel immediately, while waiting, after each committed move, and with
    // an RPC still in flight. The latter must wait for completion, not unwind.
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        i.Cancel("user cancel before staging");Pump(i);check(live_collection()==original&&operations.empty());
    }
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        for(int n=0;n<40&&!guest_kernel_rpc_manager.FilesystemOperationRunning();++n)i.Tick();
        hold_rpc=true;i.Cancel("user cancel waiting");Pump(i);
        check(live_collection()==original&&operations.empty());hold_rpc=false;
    }
    for(int at=1;at<=4;++at) {
        prepare_update();const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        for(int n=0;n<4000&&move_attempts<at;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<at)i.Tick();}
        assert(move_attempts==at);i.Cancel("user cancel during publication");Pump(i);
        check(!i.Succeeded()&&live_collection()==original);
    }
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        for(int n=0;n<40&&!guest_kernel_rpc_manager.FilesystemOperationRunning();++n)i.Tick();
        enter_inflight=true;guest_kernel_rpc_manager.Tick();i.Cancel("user cancel in flight");i.Tick();
        check(i.Busy()&&guest_kernel_rpc_manager.FilesystemOperationRunning());
        hold_rpc=false;Pump(i);check(!i.Succeeded()&&live_collection()==original);
    }
    // Freeze the validated merge: local or staged DB replacement cannot be
    // laundered through a fresh import hash / publication identity snapshot.
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        auto changed=Read((local/"ST.DB").u8string());changed[0]^=1;Write(local/"ST.DB",changed);
        Pump(i);check(!i.Succeeded()&&live_collection()==original&&move_attempts==0);
    }
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;
        check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        std::string staged_db;
        for(int n=0;n<4000&&staged_db.empty();++n){
            guest_kernel_rpc_manager.Tick();
            for(const auto &kv:disk) if(kv.first.rfind("tdata/csbbackup/csb-",0)==0&&
                kv.first.size()>=19&&kv.first.substr(kv.first.size()-19)=="/stage/database.new") { staged_db=kv.first; break; }
            if(staged_db.empty())i.Tick();
        }
        assert(!staged_db.empty()&&move_attempts==0);
        disk.at(staged_db).data[0]^=1;
        Pump(i);check(!i.Succeeded()&&live_collection()==original&&move_attempts==0);
    }
    // Partial staging writes cannot replace an existing soundtrack.
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        fail_copy=true;Pump(i);check(!i.Succeeded()&&live_collection()==original&&HasPrefix("tdata/csbbackup/csb-"));
    }
    // Metadata changes without any ST.DB byte change also invalidate edits.
    prepare_update();{
        Put("tdata/fffe0000/music/0009",true);HddSoundtrackInstaller i;
        check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());
    }
    // Stage can be ready for several ticks; a late old-DB change is refused.
    prepare_update();{
        const auto original=live_collection();HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        bool changed=false;
        for(int n=0;n<4000&&i.Busy();++n){
            guest_kernel_rpc_manager.Tick();
            if(!changed&&std::any_of(operations.begin(),operations.end(),[](const auto &op){return op.rfind("import:",0)==0&&op.find("/database.new")!=std::string::npos;})) {
                disk.at("tdata/fffe0000/music/st.db").data[4]^=1;changed=true;
            }
            i.Tick();
        }
        check(changed&&!i.Busy()&&!i.Succeeded()&&move_attempts==0&&disk.at("tdata/fffe0000/music/0000/00000000.wma").data==original.at("tdata/fffe0000/music/0000/00000000.wma").second);
    }
    // Refuse a malicious/corrupt local DB that changes an unrelated record.
    prepare_update();{
        Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Changed",{{0,5000,"Old A"},{1,1000,"Added"}}},{1,"Unexpected rename",{{0,6000,"Old B"}}}}));
        HddSoundtrackInstaller i;check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());
    }
    // Adding one tiny soundtrack with a 65 MiB unrelated file needs only
    // the new bytes/DB. No copy-limit rejection or unrelated data reads.
    Reset();PutCollection(base/"dbtmp");disk.at("tdata/fffe0000/music/0000/00000000.wma").data.resize(65u<<20,0xA5);
    { const auto old_cluster=disk.at("tdata/fffe0000/music/0000/00000000.wma").cluster;
      fs::remove_all(local);fs::create_directories(local/"0001");WriteText(local/"0001/00010000.WMA","tiny");
      Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"Existing Zero",{{0,5000,"Old A"}}},{1,"New",{{0,1000,"tiny"}}}}));
      assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=1;edit.local_song_ids={0};edit.expected_fingerprint=cat.fingerprint;
      free_bytes=2u<<20;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);
      check(i.Succeeded()&&disk.at("tdata/fffe0000/music/0000/00000000.wma").cluster==old_cluster&&
        std::none_of(operations.begin(),operations.end(),[](const auto &op){return op.rfind("copy:",0)==0;})&&
        std::none_of(data_reads.begin(),data_reads.end(),[](const auto &path){return path=="tdata/fffe0000/music/0000/00000000.wma";}));
      std::cout<<"PERF fixture: adding 4 audio bytes beside 65 MiB of existing WMA: zero unrelated WMA reads/copies.\n";
    }
    // Successful publication with cleanup failure reports retained staging,
    // not a failed/rolled-back soundtrack install.
    prepare_update();{HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));fail_cleanup=true;Pump(i);check(i.Succeeded()&&i.Status().find("retained")!=std::string::npos&&HasPrefix("tdata/csbbackup/csb-"));}
    // Folder mirror failure is explicit AFTER publication; data stays in E:.
    prepare_update();folder=true;active_path="/tmp/Xemu HDD";g_config.sys.files.hdd_type=CONFIG_SYS_FILES_HDD_TYPE_FOLDER;
    {HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));fail_sync=true;Pump(i);check(!i.Succeeded()&&i.Status().find("already published")!=std::string::npos&&Exists("tdata/fffe0000/music/0000/00000001.wma")&&HasPrefix("tdata/csbbackup/csb-"));}
    // Mixed-case raw FATX tokens must survive both publication and rollback.
    prepare_update();for(auto &kv:disk){for(auto &part:kv.second.raw){if(part=="TDATA")part="tDaTa";else if(part=="music")part="MuSiC";else if(part=="ST.DB")part="st.Db";}}
    {assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);check(i.Succeeded());}
    // No writes to a newly selected/mounted source, even while queued.
    prepare_update();{const auto original=live_collection();HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));for(int n=0;n<40&&!guest_kernel_rpc_manager.FilesystemOperationRunning();++n)i.Tick();identity=7;i.Tick();Pump(i);check(!i.Succeeded()&&live_collection()==original&&operations.empty());}
    // An empty music directory from an interrupted first install is reusable.
    Reset();PutBaseDirs();fs::remove_all(local);fs::create_directories(local/"0000");WriteText(local/"0000/00000000.WMA","first");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"First",{{0,1000,"first"}}}}));
    {assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.local_song_ids={0};edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);check(i.Succeeded());}
    // Read-only, capacity and pause preflight remain fail-closed.
    prepare_update();readonly_disk=true;{HddSoundtrackInstaller i;check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());}
    prepare_update();free_bytes=1;{HddSoundtrackInstaller i;check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());}
    prepare_update();running=false;{HddSoundtrackInstaller i;check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty());}

    // Recovery may fail. Never overwrite a newly occupied restore path.
    prepare_update();{HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
      for(int n=0;n<4000&&move_attempts<1;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<1)i.Tick();}
      assert(move_attempts==1);Put("tdata/fffe0000/music/0000",true,{}, {"TDATA","fffe0000","music","0000"});
      Put("tdata/fffe0000/music/0000/foreign.wma",false,{99},{"TDATA","fffe0000","music","0000","foreign.wma"});
      i.Cancel("cancel but destination was occupied");Pump(i);
      check(!i.Succeeded()&&Exists("tdata/fffe0000/music/0000/foreign.wma")&&HasPrefix("tdata/csbbackup/csb-"));
    }
    prepare_update();{HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));fail_move_at=4;fail_restore=true;Pump(i);check(!i.Succeeded()&&i.Status().find("Recovery stopped")!=std::string::npos&&HasPrefix("tdata/csbbackup/csb-"));}
    // An Xbox reset must NOT recover into a new execution session even if the
    // selected HDD path happens to have stayed the same.
    prepare_update();{HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
      for(int n=0;n<4000&&move_attempts<1;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<1)i.Tick();}
      assert(move_attempts==1);i.Cancel("simulated Xbox reset",false);Pump(i);check(!i.Succeeded()&&move_attempts==1&&HasPrefix("tdata/csbbackup/csb-"));
    }
    // No readable snapshot means no blind reversal of a possibly-applied move.
    prepare_update();{HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
      for(int n=0;n<4000&&move_attempts<1;++n){guest_kernel_rpc_manager.Tick();if(move_attempts<1)i.Tick();}
      fail_snapshot=true;Pump(i);check(!i.Succeeded()&&move_attempts==1&&HasPrefix("tdata/csbbackup/csb-"));
    }
    // First install when TDATA/music do not exist; no collection-sized backup.
    Reset();fs::remove_all(local);fs::create_directories(local/"0000");WriteText(local/"0000/00000000.WMA","first");Write(local/"ST.DB",MakeDb(base/"dbtmp",{{0,"First",{{0,1000,"first"}}}}));
    {assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.local_song_ids={0};edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);check(i.Succeeded()&&!HasPrefix("tdata/csbbackup"));}
    // Delete the final listed ID and preserve a valid empty database.
    Reset();PutCollection(base/"dbtmp");fs::remove_all(local);fs::create_directories(local);Write(local/"ST.DB",MakeDb(base/"dbtmp",{}));
    {assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=0;edit.delete_soundtrack=edit.target_existed=true;edit.expected_fingerprint=cat.fingerprint;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);check(i.Succeeded()&&ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error)&&cat.database_valid&&cat.soundtracks.empty());}
    // An orphan deletion preserves an invalid ST.DB byte-for-byte.
    Reset();PutBaseDirs();Put("tdata/fffe0000/music/0002",true,{}, {"TDATA","fffe0000","music","0002"});Put("tdata/fffe0000/music/st.db",false,{1,2,3},{"TDATA","fffe0000","music","ST.DB"});
    fs::remove_all(local);fs::create_directories(local);
    {assert(ReadCsbHddMusicCatalog(DetectCsbHddDestination(),cat,error));edit={};edit.soundtrack_id=2;edit.delete_soundtrack=edit.target_existed=edit.preserve_database=true;edit.expected_fingerprint=cat.fingerprint;const auto db_cluster=disk.at("tdata/fffe0000/music/st.db").cluster;HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);check(i.Succeeded()&&disk.at("tdata/fffe0000/music/st.db").cluster==db_cluster&&disk.at("tdata/fffe0000/music/st.db").data==std::vector<uint8_t>({1,2,3}));}
    // Fast verified host imports use the TEST9 backend proof; retained FATX
    // copies still get an explicit stage readback against their pre-stage hash.
    for(bool fast:{true,false}){
        prepare_update();edit.fast_stream=fast;simulate_fast_proof=true;
        HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));Pump(i);
        check(i.Succeeded()&&(fast?(fast_proofs>=2):(fast_proofs==0)));
        const bool staged_retained_read=std::any_of(data_reads.begin(),data_reads.end(),[](const auto &path){return path.rfind("tdata/csbbackup/csb-",0)==0&&path.find("/stage/0000/00000000.wma")!=std::string::npos;});
        check(staged_retained_read);
        check(i.TransferSummary().find(fast?"FAST STREAM (4 MiB max)":"Conservative (52 KiB")!=std::string::npos);
    }
    // TEST9 4 MiB policy remains unchanged through the owned sequence and the
    // current/last summary, for both mounted image and Folder-HDD modes.
    check(HddSoundtrackEdit{}.stream_chunk_bytes==4194304u);
    for(bool backed:{false,true})for(uint32_t chunk:{524288u,1048576u,2097152u,4194304u}) {
        prepare_update();edit.stream_chunk_bytes=chunk;simulate_fast_proof=true;
        if(backed){folder=true;active_path="/tmp/Xemu HDD";g_config.sys.files.hdd_type=CONFIG_SYS_FILES_HDD_TYPE_FOLDER;}
        HddSoundtrackInstaller i;check(i.Start(DetectCsbHddDestination(),local.u8string(),edit,error));
        check(guest_kernel_rpc_manager.OperationBusy());
        edit.stream_chunk_bytes=524288u; // caller/editor cannot change an active job
        Pump(i);check(i.Succeeded()&&i.TransferSummary().find(std::string("FAST STREAM (")+XemuKernelStream::ChunkLabel(chunk)+" max)")!=std::string::npos);
        check(i.TransferSummary().find("Refill ")!=std::string::npos);
        check(!observed_stream_chunks.empty()&&std::all_of(observed_stream_chunks.begin(),observed_stream_chunks.end(),[&](uint32_t value){return value==chunk;}));
    }
    for(uint32_t invalid:{0u,1048575u,4194305u,UINT32_MAX}) {
        prepare_update();edit.stream_chunk_bytes=invalid;HddSoundtrackInstaller i;
        check(!i.Start(DetectCsbHddDestination(),local.u8string(),edit,error)&&operations.empty()&&!guest_kernel_rpc_manager.OperationBusy());
    }
    std::cout<<"PASS: CSB TEST12 dashboard-format / isolated-transaction soundtrack installer ("<<scenarios<<" scenario checks)\n";
}
