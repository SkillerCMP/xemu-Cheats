#!/usr/bin/env python3
"""v3.15 CheatDB C++17 JSON integration guard.

The real XEMU C++ build uses -std=c++17, not GNU++17. QEMU's QOBJECT(),
qobject_unref(), qdict_put(), and qlist_append() convenience macros use GNU
`typeof`, so CheatDB C++ sources must not use those macros. XEMU already uses
nlohmann/json.hpp in its C++ UI code, so CheatDB uses the same C++ JSON layer.
"""
from __future__ import annotations
import argparse
from pathlib import Path


def need(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    args = ap.parse_args()
    cc = (args.root.resolve() / "ui/xui/debug-tools/addons/cheat-db/cheat-db.cc").read_text(encoding="utf-8")

    need(cc, "#include <nlohmann/json.hpp>", "XEMU-native C++ JSON dependency")
    need(cc, "using json = nlohmann::json;", "C++ JSON alias")
    need(cc, "const json root = json::parse(text);", "C++ manifest/state parser")
    need(cc, 'root["files"] = json::array();', "C++ state serializer")

    for token in ("qobject_unref(", "qdict_put(", "qlist_append(", "QOBJECT("):
        forbid(cc, token, "GNU typeof QObject convenience macro in C++17 CheatDB")

    # Networking still uses XEMU/QEMU's existing HTTP layer; only JSON ownership changed.
    need(cc, '#include "qemu/http.h"', "existing XEMU HTTP helper")
    need(cc, "http_get(url.c_str()", "CheatDB HTTP GET")

    print("PASS: v3.15 CheatDB avoids GNU typeof QObject macros and uses XEMU's C++ JSON path")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
