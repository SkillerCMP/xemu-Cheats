"""Explicit optional-core-patch prerequisites for source regression tests.

Default to the complete numbered stack, preserving the existing strict test
contract. Never infer that a patch is absent merely because its expected code
is missing: that could hide a regression. The main runner exports the user's
--optional-patches declaration to child tests through this test-only variable.
"""
from __future__ import annotations

import os

OPTIONAL_PATCHES = frozenset({10, 20, 30, 40, 50, 60})
ENVIRONMENT_KEY = "XEMU_TEST_OPTIONAL_PATCHES"


def parse_optional_patches(value: str) -> frozenset[int]:
    value = value.strip().lower()
    if value == "all":
        return OPTIONAL_PATCHES
    if value == "none":
        return frozenset()
    try:
        parts = value.split(",")
        if any(not part.strip().isdigit() for part in parts):
            raise ValueError
        patches = frozenset(int(part.strip()) for part in parts)
    except ValueError as exc:
        raise ValueError("use all, none, or comma-separated optional patch numbers") from exc
    if not patches or not patches <= OPTIONAL_PATCHES:
        raise ValueError("optional patches are 10,20,30,40,50,60; 300 is the required foundation")
    return patches


def optional_patch_enabled(number: int) -> bool:
    if number not in OPTIONAL_PATCHES:
        raise ValueError(f"unknown optional patch: {number}")
    selected = parse_optional_patches(os.environ.get(ENVIRONMENT_KEY, "all"))
    if number in selected:
        return True
    print(f"SKIP: Patch {number}-specific assertions (not declared in optional patch stack)",
          flush=True)
    return False
