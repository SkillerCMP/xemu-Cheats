#!/usr/bin/env python3
# v2.87 current regression ownership.
import argparse, pathlib

def req(text, token, label):
    if token not in text: raise AssertionError(f"missing {label}: {token}")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); root=pathlib.Path(ap.parse_args().root).resolve()
    addon=root/'ui/xui/debug-tools/addons/diagnostics'
    hook=(addon/'pgraph-ptimer-latency-trace-hook.h').read_text()
    types=(addon/'pgraph-ptimer-latency-trace-types.h').read_text()
    impl=(addon/'pgraph-ptimer-latency-trace.c').read_text()
    ui=(addon/'diagnostics.cc').read_text()
    backend=(addon/'diagnostics-backend.c').read_text()
    pg=(root/'hw/xbox/nv2a/pgraph/pgraph.c').read_text()
    pt=(root/'hw/xbox/nv2a/ptimer.c').read_text()
    meson=(root/'ui/xui/debug-tools/meson.build').read_text()
    for tok in ['surface_lock_wait_ns','surface_update_ns','pfifo_kick_ns','bql_reacquire_wait_ns']:
        req(types,tok,'PGRAPH stage ABI')
    req(hook,'#include "qemu/osdep.h"','PGRAPH profiler QEMU include prerequisite')
    req(hook,'#include "pgraph-ptimer-latency-trace-types.h"','shared latency record include')
    osdep_include = hook.find('#include "qemu/osdep.h"')
    types_include = hook.find('#include "pgraph-ptimer-latency-trace-types.h"')
    if osdep_include < 0 or types_include < 0 or osdep_include > types_include:
        raise AssertionError('PGRAPH profiler hook must establish qemu/osdep.h before shared latency records')
    req(pg,'xemu_debug_tools_pgraph_increment_trace_threshold_ns()','PGRAPH fast enable gate')
    req(pg,'trace.surface_lock_wait_ns','surface lock wait timing')
    req(pg,'trace.pfifo_kick_ns','PFIFO kick timing')
    req(pg,'trace.bql_reacquire_wait_ns','BQL reacquire timing')
    req(pt,'xemu_debug_tools_ptimer_irq_latency_note_set(d);','PTIMER IRQ set hook')
    req(pt,'xemu_debug_tools_ptimer_irq_latency_note_clear(d, (uint32_t)val);','PTIMER IRQ clear hook')
    req(impl,'e.service_latency_ns','IRQ service latency calculation')
    req(impl,'clear_guest_pc','clear guest PC capture')
    req(ui,'XEMU Diagnostics Snapshot v3.14ab','v3.09 snapshot')
    req(ui,'PGRAPH Increment Stage Trace','PGRAPH snapshot section')
    req(ui,'PTIMER IRQ Service Latency Trace','PTIMER latency snapshot section')
    req(backend,'xemu_diagnostics_get_pgraph_increment_trace','PGRAPH backend bridge')
    req(backend,'xemu_diagnostics_get_ptimer_irq_latency_trace','PTIMER backend bridge')
    req(meson,"'addons/diagnostics/pgraph-ptimer-latency-trace.c',",'full profiler source')
    req(meson,"'addons/stubs/pgraph-ptimer-latency-trace-stub.c',",'non-full profiler stub')
    print('PASS: v3.05 PGRAPH increment + PTIMER IRQ service latency profiler invariants')
    return 0
if __name__=='__main__': raise SystemExit(main())
