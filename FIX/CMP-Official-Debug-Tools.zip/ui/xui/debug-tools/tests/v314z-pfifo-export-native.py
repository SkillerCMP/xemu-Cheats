#!/usr/bin/env python3
"""Compile the actual new C++ export block and UI stage-name mapping in isolation."""
from __future__ import annotations
import argparse, pathlib, re, subprocess, tempfile
from v314y_vulkan_observer_test_utils import function

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--compiler',default='g++');a=ap.parse_args()
    root=pathlib.Path(a.root);d=root/'ui/xui/debug-tools/addons/diagnostics'
    ui=(d/'diagnostics.cc').read_text();bh=(d/'diagnostics-backend.h').read_text()
    enum=re.search(r'typedef enum XemuDiagnosticsPgraphDrawTraceStage \{.*?\} XemuDiagnosticsPgraphDrawTraceStage;',bh,re.S)[0]
    name=function(ui,'const char *PgraphDrawTraceStageName(uint32_t stage)')
    begin=ui.index('                os << "  DRAW_SUMMARY completed="')
    end=ui.index('                for (uint32_t rank = 0;',begin)
    block=ui[begin:end]
    src='''#include <cassert>
#include <iostream>
#include <sstream>
#include <string>
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace.h"
'''+enum+'\n'+name+'''
std::string actual_export(const XemuDebugToolsPgraphPusherMethodBreakdownEvent &e) {
    std::ostringstream os;
'''+block+'''    return os.str();
}
int main() {
    XemuDebugToolsPgraphPusherMethodBreakdownEvent event{};
    event.draw.completed_draws=189;event.draw.sub5ms_draws=188;
    event.draw.fast_reuse=100;event.draw.cache_hits=80;event.draw.cache_misses=9;
    for(unsigned stage=1;stage<XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT;stage++) {
        event.draw.stages[stage]={123456,4567,8999,189};
        assert(std::string(PgraphDrawTraceStageName(stage))!="UNKNOWN");
    }
    const std::string result=actual_export(event);
    assert(result.find("DRAW_SUMMARY completed=189 sub5ms=188 fast_reuse=100 cache_hit=80 cache_miss=9 dropped=0 invalid=0 saturated=0")!=std::string::npos);
    unsigned count=0;size_t pos=0;
    while((pos=result.find("DRAW_STAGE ",pos))!=std::string::npos){count++;pos++;}
    assert(count==XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT-1);
    assert(result.find("DRAW_STAGE VK_PIPELINE_CREATE total_ns=123456 self_ns=4567 calls=189 max_ns=8999")!=std::string::npos);
    std::cout<<"PASS: actual C++ aggregate export block and all declared stage names/enum IDs\\n";
}
'''
    with tempfile.TemporaryDirectory(prefix='xemu-export-native-') as temp:
        p=pathlib.Path(temp)/'test.cpp';p.write_text(src);exe=pathlib.Path(temp)/'test'
        subprocess.run([a.compiler,'-x','c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I',str(root),str(p),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True)
    return 0
if __name__=='__main__':raise SystemExit(main())
