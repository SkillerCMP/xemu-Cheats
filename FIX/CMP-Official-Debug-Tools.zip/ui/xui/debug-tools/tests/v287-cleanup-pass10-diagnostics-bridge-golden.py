#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 10 Diagnostics bridge-forwarding guard."""
from __future__ import annotations

import argparse
import hashlib
import pathlib

from v287_source_test_utils import extract_function


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(text: str) -> str:
    return " ".join(text.split())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    diag = root / "ui/xui/debug-tools/addons/diagnostics"
    backend = (diag / "diagnostics-backend.c").read_text(encoding="utf-8")

    families = (
        ("ptimer_trace", "ptimer_trace"),
        ("qemu_timer_trace", "qemu_timer_trace"),
        ("slow_timer_trace", "slow_timer_trace"),
        ("ohci_slow_frame_trace", "ohci_slow_frame_trace"),
        ("pgraph_increment_trace", "pgraph_increment_trace"),
        ("ptimer_irq_latency_trace", "ptimer_irq_latency_trace"),
        ("controller_input_poll_trace", "controller_input_poll_trace"),
        ("bql_trace", "bql_trace"),
        ("main_loop_lock_trace", "main_loop_lock_trace"),
        ("mmio_trace", "mmio_trace"),
        ("pgraph_lock_trace", "pgraph_lock_trace"),
        ("flip_stall_trace", "flip_stall_trace"),
        ("scheduler_trace", "scheduler_trace"),
        ("pgraph_draw_trace", "pgraph_draw_trace"),
        ("controller_xid_trace", "controller_xid_trace"),
    )

    for diagnostic, recorder in families:
        status_name = f"xemu_diagnostics_get_{diagnostic}_status"
        snapshot_name = f"xemu_diagnostics_get_{diagnostic}"
        status = extract_function(backend, f"int {status_name}(")
        snapshot = extract_function(backend, f"size_t {snapshot_name}(")
        status_c = compact(status)
        snapshot_c = compact(snapshot)

        require(status_c, "if (status == NULL) { return 0; }",
                f"{diagnostic} status null contract")
        require(status_c, f"xemu_debug_tools_{recorder}_get_status(status);",
                f"{diagnostic} direct status forwarding")
        require(status_c, "return 1;", f"{diagnostic} status success contract")

        require(snapshot_c, "if (events == NULL || capacity == 0) { return 0; }",
                f"{diagnostic} snapshot null/capacity contract")
        require(snapshot_c,
                f"return xemu_debug_tools_{recorder}_snapshot(events, capacity);",
                f"{diagnostic} direct snapshot forwarding")

        for stale in ("core_status", "core_events", "g_new0", "g_free", "memcpy", "g_strlcpy"):
            forbid(status + snapshot, stale, f"{diagnostic} retired bridge copy surface")

    for stale in (
        "diagnostics_copy_pgraph_method",
        "diagnostics_copy_pgraph_state",
        "g_new0(XemuDebugTools",
        "g_free(core_events)",
    ):
        forbid(backend, stale, "retired Diagnostics bridge conversion helper")

    # Pass 11 owns the lock-recorder implementation separately. Pass 10 continues
    # to own only the Diagnostics bridge forwarding surface above.
    common = diag / "lock-trace-common.c"
    if not common.is_file():
        raise AssertionError("missing separately guarded Pass 11 lock-trace common core")

    print("PASS: Cleanup Pass 10 forwards canonical Diagnostics trace records without conversion buffers/copies")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
