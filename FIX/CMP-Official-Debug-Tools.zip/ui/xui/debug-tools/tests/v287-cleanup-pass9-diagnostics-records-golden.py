#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 9 Diagnostics trace-record ownership guard."""
from __future__ import annotations

import argparse
import hashlib
import pathlib
import re


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    diag = root / "ui/xui/debug-tools/addons/diagnostics"

    backend_h = (diag / "diagnostics-backend.h").read_text(encoding="utf-8")
    backend_c = diag / "diagnostics-backend.c"

    aliases = {
        "XemuDiagnosticsPtimerTraceEvent": "XemuDebugToolsPtimerTraceEvent",
        "XemuDiagnosticsPtimerTraceStatus": "XemuDebugToolsPtimerTraceStatus",
        "XemuDiagnosticsQemuTimerTraceEvent": "XemuDebugToolsQemuTimerTraceEvent",
        "XemuDiagnosticsQemuTimerTraceStatus": "XemuDebugToolsQemuTimerTraceStatus",
        "XemuDiagnosticsSlowTimerTraceEvent": "XemuDebugToolsSlowTimerTraceEvent",
        "XemuDiagnosticsSlowTimerTraceStatus": "XemuDebugToolsSlowTimerTraceStatus",
        "XemuDiagnosticsOhciSlowFrameEvent": "XemuDebugToolsOhciSlowFrameEvent",
        "XemuDiagnosticsOhciSlowFrameStatus": "XemuDebugToolsOhciSlowFrameStatus",
        "XemuDiagnosticsControllerInputPollEvent": "XemuDebugToolsControllerInputPollEvent",
        "XemuDiagnosticsControllerInputPollStatus": "XemuDebugToolsControllerInputPollStatus",
        "XemuDiagnosticsPgraphIncrementEvent": "XemuDebugToolsPgraphIncrementEvent",
        "XemuDiagnosticsPtimerIrqLatencyEvent": "XemuDebugToolsPtimerIrqLatencyEvent",
        "XemuDiagnosticsLatencyTraceStatus": "XemuDebugToolsLatencyTraceStatus",
        "XemuDiagnosticsBqlTraceEvent": "XemuDebugToolsBqlTraceEvent",
        "XemuDiagnosticsBqlTraceStatus": "XemuDebugToolsBqlTraceStatus",
        "XemuDiagnosticsMainLoopLockTraceEvent": "XemuDebugToolsMainLoopLockTraceEvent",
        "XemuDiagnosticsMainLoopLockTraceStatus": "XemuDebugToolsMainLoopLockTraceStatus",
        "XemuDiagnosticsMmioTraceEvent": "XemuDebugToolsMmioTraceEvent",
        "XemuDiagnosticsMmioTraceStatus": "XemuDebugToolsMmioTraceStatus",
        "XemuDiagnosticsPgraphLockMethodContext": "XemuDebugToolsPgraphLockMethodContext",
        "XemuDiagnosticsPgraphLockStateContext": "XemuDebugToolsPgraphLockStateContext",
        "XemuDiagnosticsPgraphLockTraceEvent": "XemuDebugToolsPgraphLockTraceEvent",
        "XemuDiagnosticsPgraphLockTraceStatus": "XemuDebugToolsPgraphLockTraceStatus",
        "XemuDiagnosticsFlipStallEvent": "XemuDebugToolsFlipStallTraceEvent",
        "XemuDiagnosticsFlipStallStatus": "XemuDebugToolsFlipStallTraceStatus",
        "XemuDiagnosticsSchedulerTraceEvent": "XemuDebugToolsSchedulerTraceEvent",
        "XemuDiagnosticsSchedulerTraceStatus": "XemuDebugToolsSchedulerTraceStatus",
        "XemuDiagnosticsPgraphDrawTraceEvent": "XemuDebugToolsPgraphDrawTraceEvent",
        "XemuDiagnosticsPgraphDrawTraceStatus": "XemuDebugToolsPgraphDrawTraceStatus",
        "XemuDiagnosticsControllerXidTraceEvent": "XemuDebugToolsControllerXidTraceEvent",
        "XemuDiagnosticsControllerXidTraceStatus": "XemuDebugToolsControllerXidTraceStatus",
    }
    for diagnostic, recorder in aliases.items():
        require(backend_h, f"typedef {recorder} {diagnostic};",
                f"shared trace record alias {diagnostic}")
        forbid(backend_h, f"typedef struct {diagnostic} {{",
               f"duplicate Diagnostics trace layout {diagnostic}")

    remaining = re.findall(r"typedef struct (XemuDiagnostics\w+) \{", backend_h)
    expected_remaining = {
        "XemuDiagnosticsBufferInfo",
        "XemuDiagnosticsTimingSnapshot",
        "XemuDiagnosticsDeviceSnapshot",
    }
    if set(remaining) != expected_remaining or len(remaining) != 3:
        raise AssertionError(f"unexpected Diagnostics-owned struct set: {remaining}")

    for header in (
        "bql-trace.h",
        "controller-input-poll-trace-hook.h",
        "controller-xid-trace.h",
        "flip-stall-trace.h",
        "main-loop-lock-trace.h",
        "mmio-trace.h",
        "ohci-slow-frame-trace-hook.h",
        "pgraph-draw-trace.h",
        "pgraph-lock-trace.h",
        "pgraph-ptimer-latency-trace-types.h",
        "ptimer-trace.h",
        "qemu-timer-trace.h",
        "scheduler-trace.h",
        "slow-timer-trace.h",
    ):
        require(backend_h, f'#include "{header}"', f"recorder type owner include {header}")

    latency_types = (diag / "pgraph-ptimer-latency-trace-types.h").read_text(encoding="utf-8")
    latency_hook = (diag / "pgraph-ptimer-latency-trace-hook.h").read_text(encoding="utf-8")
    for name in (
        "XemuDebugToolsPgraphIncrementEvent",
        "XemuDebugToolsPtimerIrqLatencyEvent",
        "XemuDebugToolsLatencyTraceStatus",
    ):
        require(latency_types, f"typedef struct {name} {{", f"neutral latency type {name}")
        forbid(latency_hook, f"typedef struct {name} {{", f"duplicate latency hook type {name}")
    require(latency_hook, '#include "qemu/osdep.h"', "latency hook QEMU prerequisite")
    require(latency_hook, '#include "pgraph-ptimer-latency-trace-types.h"',
            "latency hook neutral record include")
    if latency_hook.index('#include "qemu/osdep.h"') > latency_hook.index(
            '#include "pgraph-ptimer-latency-trace-types.h"'):
        raise AssertionError("latency hook must retain qemu/osdep.h ordering prerequisite")
    forbid(latency_types, "qemu/osdep.h", "QEMU platform dependency in neutral trace records")

    # Pass 10 owns diagnostics-backend.c bridge forwarding and Pass 11 now
    # owns the lock-recorder implementation. Pass 9 continues to guard only
    # canonical Diagnostics trace-record ownership.
    if not (diag / "lock-trace-common.h").is_file():
        raise AssertionError("missing separately guarded Pass 11 lock-trace common types")

    print("PASS: Cleanup Pass 9 canonical Diagnostics trace-record ownership remains intact")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
