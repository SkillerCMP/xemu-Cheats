#!/usr/bin/env python3
"""XEMU-CHEATDB File Replacement download integration guards."""
from __future__ import annotations
import argparse
from pathlib import Path


def need(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    args = ap.parse_args()
    dt = args.root.resolve() / "ui/xui/debug-tools"
    cc = (dt / "addons/cheat-db/cheat-db.cc").read_text(encoding="utf-8")
    fr_hh = (dt / "addons/file-replace/file-replace.hh").read_text(encoding="utf-8")
    fr_cc = (dt / "addons/file-replace/file-replace.cc").read_text(encoding="utf-8")
    source = (dt / "cheat-engine-source.cc").read_text(encoding="utf-8")
    readme = (dt / "addons/cheat-db/README.md").read_text(encoding="utf-8")

    # Additive manifest contract: legacy cheat `files` remains separate.
    for token in ("file_replacement_root", "file_replacements", "game_id",
                  "game_relative_path", "executable_identity", "role"):
        need(cc, token, f"manifest field {token}")
    need(cc, 'parsed.schema_version != 1', "schema-v1 compatibility")
    need(cc, 'root.find("file_replacements")', "additive replacement array parser")
    need(cc, 'Upper(file.role) == "VERSION_PAYLOAD"', "version-payload classifier")
    need(cc, 'Upper(file.executable_identity) == Upper(game.executable_identity)',
         "exact XBE identity filter")

    # Local installation is fixed under Cheats/File-Replacements, which is the
    # same subtree the File Replace addon already owns.
    need(cc, 'JoinFile(cheat_dir, "File-Replacements")', "CheatDB local replacement root")
    need(fr_cc, 'JoinPath(JoinPath(ExecutableDirectory(), "Cheats"),',
         "File Replace executable-side Cheats root")
    need(fr_cc, '"File-Replacements"', "File Replace reserved subtree")
    need(source, 'g_ascii_strcasecmp(filename.c_str(), "File-Replacements") == 0',
         "normal cheat scan exclusion")
    need(readme, 'Cheats/File-Replacements/<GameID>/', "documented local layout")

    # Preserve remote directory hierarchy and reject traversal/absolute paths.
    need(cc, "bool IsSafeRelativePath", "relative-path validation")
    need(cc, 'value != "." && value != ".."', "dot-segment rejection")
    need(cc, "path.find(':')", "drive/URI rejection")
    need(cc, "ReplacementLocalPath", "hierarchy-preserving destination")

    # Binary payloads are SHA-256 verified and local/unowned edits are not clobbered.
    need(cc, "kMaxFileReplacementBytes", "replacement size bound")
    need(cc, "Upper(Sha256(data)) != Upper(remote.sha256)", "download hash verification")
    need(cc, "Existing but unowned/edited content is never overwritten automatically.",
         "local-modification preservation")
    need(cc, "BackupReplacementFile", "replacement backup")
    need(cc, '"Backup"), "File-Replacements"', "replacement backup subtree")
    need(cc, 'root["file_replacements"] = json::array();', "replacement ownership state")

    # Work stays on the existing background worker. File Replace refresh is deferred
    # through its synchronized Tick instead of directly reloading from detached draw.
    need(cc, "void FileReplacementWork(void *opaque)", "replacement worker")
    need(cc, "debug_tools_queue_background_job(FileReplacementWork", "background queue")
    need(cc, '"Download / Update File Replacements"', "current-game UI action")
    need(fr_hh, "void RequestManifestReload();", "File Replace reload request API")
    need(fr_cc, "m_manifest_reload_requested", "deferred File Replace reload flag")
    tick = cc[cc.index("void CheatDbManager::Tick()") :]
    need(tick, "file_replace_manager.RequestManifestReload();", "post-download refresh request")
    draw = cc[cc.index("void CheatDbManager::DrawDetached()") :]
    forbid(draw, "http_get(", "network access from detached UI draw")

    print("PASS: CheatDB File Replacements install under Cheats/File-Replacements with Game ID + exact XBE identity filtering")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
