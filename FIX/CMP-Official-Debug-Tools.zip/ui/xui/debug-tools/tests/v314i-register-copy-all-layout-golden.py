#!/usr/bin/env python3
# v3.14i current-register layout ownership.
"""Guard COPY ALL as a header-row control without narrowing register contents."""
from __future__ import annotations

import argparse
import pathlib

from v287_source_test_utils import extract_function, read_memory_tools_implementation


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    implementation = read_memory_tools_implementation(debug)
    registers = extract_function(
        implementation, "void MemoryToolsWindow::DrawRegisters(")

    header_start = registers.find(
        'ImGui::BeginTable("current_register_tabs_row", 2')
    if header_start < 0:
        raise AssertionError("current register tab/COPY ALL header row is missing")

    header_end = registers.find("ImGui::EndTable();", header_start)
    if header_end < 0:
        raise AssertionError("current register tab/COPY ALL header table is unterminated")

    header = registers[header_start:header_end]
    for needle in (
        'ImGui::BeginTabBar("current_register_tabs")',
        'ImGui::Button("COPY ALL", ImVec2(-FLT_MIN, 0.0f))',
        'ImGui::TableSetupColumn("Copy", ImGuiTableColumnFlags_WidthFixed',
    ):
        if needle not in header:
            raise AssertionError(f"COPY ALL header-row invariant missing: {needle}")

    # Regression: v3.14h rendered the selected register table while still inside
    # the two-column Tabs/COPY ALL table.  That restricted the register data to
    # the Tabs column and clipped the right-hand register/value pair.
    for forbidden in (
        "DrawGeneralRegisterTable(r, false);",
        "DrawExtraRegisterTable(m_extra_registers,",
    ):
        if forbidden in header:
            raise AssertionError(
                "register contents are still being drawn inside the COPY ALL header column")

    general_draw = registers.find("DrawGeneralRegisterTable(r, false);")
    extra_draw = registers.find("DrawExtraRegisterTable(m_extra_registers,", header_end)
    if general_draw <= header_end or extra_draw <= header_end:
        raise AssertionError(
            "selected register contents must render after the header table at full pane width")

    if "if (m_register_view == 0)" not in registers[header_end:general_draw + 64]:
        raise AssertionError("full-width register-view dispatch is missing")

    print(
        "PASS: v3.14i COPY ALL stays in tab row while register tables use full pane width")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
