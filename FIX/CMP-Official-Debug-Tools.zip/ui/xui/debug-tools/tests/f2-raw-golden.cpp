// v3.15 Patch 302: Type-F2 raw-byte/label assembler semantic coverage.
#include "../x86-cheat-assembler.hh"
#include "../x86-cheat-assembler-internal.hh"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
#include <string>
#include <unordered_map>
#include <vector>

/* The production F2 frontend lives beside F0 in x86-cheat-assembler.cc, whose
 * normal internal helpers are supplied by the Keystone backend. This native
 * test intentionally links without Keystone, so provide the small helper
 * contract needed by F2 and inert stubs for F0-only helpers. */
namespace xemu_cheat_assembler_internal {

std::string trim(const std::string &s)
{
    size_t first = 0;
    while (first < s.size() && std::isspace((unsigned char)s[first])) ++first;
    size_t last = s.size();
    while (last > first && std::isspace((unsigned char)s[last - 1])) --last;
    return s.substr(first, last - first);
}

std::string upper(std::string s)
{
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return (char)std::toupper(c);
    });
    return s;
}

std::string strip_comment(const std::string &s)
{
    size_t cut = s.size();
    for (const char *marker : {";", "//", "#"}) {
        const size_t pos = s.find(marker);
        if (pos != std::string::npos) cut = std::min(cut, pos);
    }
    return trim(s.substr(0, cut));
}

bool valid_label(const std::string &name)
{
    if (name.empty() ||
        !(std::isalpha((unsigned char)name.front()) || name.front() == '_')) {
        return false;
    }
    for (char c : name) {
        if (!(std::isalnum((unsigned char)c) || c == '_')) return false;
    }
    return true;
}

bool parse_number(const std::string &text, int64_t &value)
{
    std::string s = trim(text);
    if (s.empty()) return false;
    bool negative = false;
    const char *p = s.c_str();
    if (*p == '-') {
        negative = true;
        ++p;
    }
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) p += 2;
    char *end = nullptr;
    const unsigned long long parsed = std::strtoull(p, &end, 16);
    if (end == p || *end != '\0') return false;
    value = negative ? -(int64_t)parsed : (int64_t)parsed;
    return true;
}

std::vector<std::string> split_operands(const std::string &s)
{
    std::vector<std::string> out;
    size_t start = 0;
    for (size_t i = 0; i <= s.size(); ++i) {
        if (i == s.size() || s[i] == ',') {
            out.push_back(trim(s.substr(start, i - start)));
            start = i + 1;
        }
    }
    return out;
}

void emit_u32(std::vector<uint8_t> &out, uint32_t value)
{
    out.push_back((uint8_t)(value & 0xFFu));
    out.push_back((uint8_t)((value >> 8) & 0xFFu));
    out.push_back((uint8_t)((value >> 16) & 0xFFu));
    out.push_back((uint8_t)((value >> 24) & 0xFFu));
}

bool parse_register(const std::string &, int &, int &) { return false; }
int reg32(const std::string &) { return -1; }
bool condition_code(const std::string &, uint8_t &) { return false; }
bool encode_instruction(const std::string &, size_t,
                        const std::unordered_map<std::string, size_t> *,
                        uint32_t, std::vector<uint8_t> &, std::string &)
{
    return false;
}

} // namespace xemu_cheat_assembler_internal

namespace {

std::vector<XemuCheatAsmLine> source(std::initializer_list<const char *> text)
{
    std::vector<XemuCheatAsmLine> out;
    int line = 1;
    for (const char *item : text) out.push_back({line++, item});
    return out;
}

bool check_car_list_layout()
{
    const uint32_t base = 0x68020000u;
    XemuCheatAsmResult result;
    if (!xemu_cheat_assemble_f2_raw_at(
            source({
                "$9C // pushfd", "$52", "$53", "$BA CarList",
                "$CheckCar:", "$8B1A", "$85DB", "$0F84 Original",
                "$39D8", "$0F84 Success", "$83C204", "$E9 CheckCar",
                "$Success:", "$5B", "$5A", "$9D", "$B801000000",
                "$8B4D08", "$8901", "$5E", "$5D", "$C20800",
                "$Original:", "$5B", "$5A", "$9D", "$8A0D84D74600",
                "$CarList:", "$dd 01D28710 // 997tt", "$dd 8B80C5FC",
                "$dd E3BDE8CB", "$dd 0001308E", "$dd 60D6890E",
                "$dd 0689441B", "$dd 00000000",
            }),
            base, result)) {
        std::fprintf(stderr, "FAIL f2_car_list: line=%d %s\n",
                     result.error_line, result.error.c_str());
        return false;
    }

    const std::vector<uint8_t> expected_data = {
        0x10, 0x87, 0xD2, 0x01, 0xFC, 0xC5, 0x80, 0x8B,
        0xCB, 0xE8, 0xBD, 0xE3, 0x8E, 0x30, 0x01, 0x00,
        0x0E, 0x89, 0xD6, 0x60, 0x1B, 0x44, 0x89, 0x06,
        0x00, 0x00, 0x00, 0x00,
    };
    if (result.data != expected_data || result.bytes.size() != 61u) {
        std::fprintf(stderr, "FAIL f2_car_list size/data code=%zu data=%zu\n",
                     result.bytes.size(), result.data.size());
        return false;
    }

    /* CarList is after 61 executable bytes + the generated 5-byte DEADCODE JMP. */
    const uint32_t car_list = base + 66u;
    if (result.bytes[3] != 0xBAu || result.bytes[4] != (car_list & 0xFFu) ||
        result.bytes[5] != ((car_list >> 8) & 0xFFu) ||
        result.bytes[6] != ((car_list >> 16) & 0xFFu) ||
        result.bytes[7] != ((car_list >> 24) & 0xFFu)) {
        std::fprintf(stderr, "FAIL f2_car_list absolute label fixup\n");
        return false;
    }

    /* CheckCar starts immediately after pushfd/push/push/MOV EDX,imm32 (8 bytes). */
    if (result.bytes[29] != 0xE9u || result.bytes[30] != 0xE6u ||
        result.bytes[31] != 0xFFu || result.bytes[32] != 0xFFu ||
        result.bytes[33] != 0xFFu) {
        std::fprintf(stderr, "FAIL f2_car_list backward rel32 fixup\n");
        return false;
    }
    return true;
}

bool check_literal_and_short_labels()
{
    XemuCheatAsmResult result;
    if (!xemu_cheat_assemble_f2_raw_at(
            source({"Start:", "75 Next", "90", "Next:", "EB Start"}),
            0x68010000u, result) ||
        result.bytes != std::vector<uint8_t>({0x75, 0x01, 0x90, 0xEB, 0xFB})) {
        std::fprintf(stderr, "FAIL f2_short_labels: %s\n", result.error.c_str());
        return false;
    }

    /* A fully literal branch remains literal; hex-looking FE is not a label. */
    if (!xemu_cheat_assemble_f2_raw_at(source({"75 FE"}), 0x68010000u, result) ||
        result.bytes != std::vector<uint8_t>({0x75, 0xFE})) {
        std::fprintf(stderr, "FAIL f2_literal_branch: %s\n", result.error.c_str());
        return false;
    }

    /* DD uses the exact F0 hexadecimal-first 32-bit parser/cast semantics. */
    if (!xemu_cheat_assemble_f2_raw_at(source({"90", "Data:", "DD -1"}),
                                       0x68010000u, result) ||
        result.data != std::vector<uint8_t>({0xFF, 0xFF, 0xFF, 0xFF})) {
        std::fprintf(stderr, "FAIL f2_dd_f0_semantics: %s\n", result.error.c_str());
        return false;
    }
    return true;
}

bool check_errors()
{
    XemuCheatAsmResult result;
    std::vector<XemuCheatAsmLine> far = source({"75 Far"});
    for (int i = 0; i < 129; ++i) far.push_back({2 + i, "90"});
    far.push_back({200, "Far:"});
    if (xemu_cheat_assemble_f2_raw_at(far, 0x68010000u, result) ||
        result.error.find("outside rel8 range") == std::string::npos) {
        std::fprintf(stderr, "FAIL f2_rel8_range: %s\n", result.error.c_str());
        return false;
    }

    if (xemu_cheat_assemble_f2_raw_at(source({"90 Missing"}), 0x68010000u, result) ||
        result.error.find("not supported for opcode") == std::string::npos) {
        std::fprintf(stderr, "FAIL f2_unsupported_label_opcode: %s\n",
                     result.error.c_str());
        return false;
    }

    if (xemu_cheat_assemble_f2_raw_at(source({"E9 Missing"}), 0x68010000u, result) ||
        result.error.find("unknown Type-F2 label") == std::string::npos) {
        std::fprintf(stderr, "FAIL f2_unknown_label: %s\n", result.error.c_str());
        return false;
    }
    return true;
}

} // namespace

int main()
{
    if (!check_car_list_layout() || !check_literal_and_short_labels() ||
        !check_errors()) {
        return 1;
    }
    std::printf("PASS: Type-F2 exact raw bytes + labels/relocations + little-endian DD data\n");
    return 0;
}
