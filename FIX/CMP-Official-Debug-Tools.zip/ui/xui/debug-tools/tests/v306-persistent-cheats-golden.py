#!/usr/bin/env python3
from pathlib import Path
import argparse
import re

parser = argparse.ArgumentParser()
parser.add_argument("--root", default=str(Path(__file__).resolve().parents[4]))
root = Path(parser.parse_args().root).resolve()

def text(rel):
    return (root / rel).read_text(encoding="utf-8")

def require(rel, needle):
    data = text(rel)
    if needle not in data:
        raise AssertionError(f"missing {needle!r} in {rel}")

require("ui/xui/debug-tools/meson.build", "'cheat-engine-persistence.cc'")
require("ui/xui/debug-tools/cheat-engine-ui.cc", 'MenuItem("Persistent Cheats"')
require("ui/xui/debug-tools/cheat-engine-ui.cc", 'const char *window_name = "Cheat Engine"')
require("ui/xui/debug-tools/debug-tools.cc", '"xemu - Cheat Engine"')
require("ui/xui/debug-tools/cheat-engine-source.cc", "RestorePersistentState();")
require("ui/xui/debug-tools/cheat-engine-persistence.cc", '"Saved"')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", '"Persistent.enabled"')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", '".persist.json"')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", 'game.disc_xbe_sha256.empty()')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", 'PersistentIdentityHash')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", 'PersistentContentHash')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", 'entry.identity == identity && entry.content == content')
require("ui/xui/debug-tools/cheat-engine-persistence.cc", 'm_live_cheats_enabled = true;')
# Keep the persistence parser compatible with both the older json.wrap pin and
# the newer upstream nlohmann_json.wrap layout.  The production code deliberately
# uses find/end field checks, which are valid across both dependency revisions.
legacy_wrap = root / "subprojects/json.wrap"
current_wrap = root / "subprojects/nlohmann_json.wrap"
if legacy_wrap.exists():
    require("subprojects/json.wrap", "nlohmann_json = nlohmann_json_dep")
elif current_wrap.exists():
    require("subprojects/nlohmann_json.wrap", "nlohmann_json = nlohmann_json_dep")
else:
    raise AssertionError("missing nlohmann JSON Meson wrap")
persistence = text("ui/xui/debug-tools/cheat-engine-persistence.cc")
if re.search(r"\.\s*contains\s*\(", persistence):
    raise AssertionError("persistent cheat parsing must retain find/end compatibility")
for obj, key in (("root", "codes"), ("root", "title_id"),
                 ("root", "xbe_sha256"), ("entry", "identity_sha256"),
                 ("entry", "content_sha256")):
    require("ui/xui/debug-tools/cheat-engine-persistence.cc",
            f'{obj}.find("{key}") == {obj}.end()')
print("persistent cheats golden: PASS")
