#!/usr/bin/env python3
"""Test actual source-file replacement using native GLib (Linux host).

The existing test-only GLib C ABI declarations are used because the lightweight
harness does not require SDL/QEMU or GLib development headers. File operations
are real libglib calls. This does not simulate or prove Windows/macOS behavior.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import tempfile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", default="g++")
    parser.add_argument("--sanitizers", action="store_true")
    args = parser.parse_args()
    debug = Path(__file__).resolve().parents[2]
    flags = [args.compiler, "-std=c++17", "-O1", "-g", "-Wall", "-Wextra", "-Werror",
             "-I" + str(debug), "-I" + str(debug / "tests/v316b/stubs")]
    if args.sanitizers:
        flags += ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    with tempfile.TemporaryDirectory(prefix="xemu-v316e-source-file-") as tmp:
        temp = Path(tmp)
        exe = temp / "source-file-golden"
        command = flags + [str(debug / "tests/v316e/source-file-golden.cc"),
                           str(debug / "cheat-source-file.cc"),
                           "-Wl,--wrap=g_file_set_contents_full", "-l:libglib-2.0.so.0",
                           "-o", str(exe)]
        print("+", " ".join(command), flush=True)
        subprocess.run(command, check=True)
        subprocess.run([str(exe), str(temp / "cheats")], check=True)


if __name__ == "__main__":
    main()
