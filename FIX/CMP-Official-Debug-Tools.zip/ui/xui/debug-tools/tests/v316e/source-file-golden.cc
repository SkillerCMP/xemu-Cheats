// Tests the production no-backup source transaction with a real GLib runtime.
// No guest access or XEMU process is involved. Test-only link wrapping injects
// one write failure before the real GLib call, never replacing a production API.
#include "cheat-source-file.hh"
#include <glib.h>
#include <sys/stat.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>

namespace fs = std::filesystem;
static unsigned assertions = 0;
static unsigned writes = 0;
static bool fail_next_write = false;

static void check(bool condition, const char *message)
{
    ++assertions;
    if (!condition) throw std::runtime_error(message);
}

extern "C" gboolean __real_g_file_set_contents_full(
    const gchar *, const gchar *, gssize, GFileSetContentsFlags, int, GError **);
extern "C" gboolean __wrap_g_file_set_contents_full(
    const gchar *path, const gchar *contents, gssize length,
    GFileSetContentsFlags flags, int mode, GError **error)
{
    ++writes;
    check((flags & G_FILE_SET_CONTENTS_CONSISTENT) != 0, "consistent flag missing");
    check((flags & G_FILE_SET_CONTENTS_DURABLE) != 0, "durable flag missing");
    if (fail_next_write) {
        fail_next_write = false;
        return false;
    }
    return __real_g_file_set_contents_full(path, contents, length, flags, mode, error);
}

static std::string read(const fs::path &path)
{
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("test read failed");
    return std::string(std::istreambuf_iterator<char>(stream), {});
}

static void put(const fs::path &path, const std::string &bytes)
{
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("test fixture create failed");
    stream.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    stream.close();
    if (!stream) throw std::runtime_error("test fixture write failed");
}

static mode_t file_mode(const fs::path &path)
{
    struct stat st{};
    if (stat(path.c_str(), &st) != 0) throw std::runtime_error("test stat failed");
    return st.st_mode & 0777;
}

static void only_file(const fs::path &dir, const fs::path &path)
{
    size_t count = 0;
    for (const auto &entry : fs::directory_iterator(dir)) {
        check(entry.path() == path, "backup/temp/unexpected entry left in source directory");
        ++count;
    }
    check(count == 1, "source directory entry count differs");
}

struct UmaskGuard {
    mode_t old = umask(0022);
    ~UmaskGuard() { umask(old); }
};

int main(int argc, char **argv)
{
    try {
        if (argc != 2) throw std::runtime_error("usage: source-file-golden EMPTY_TEST_DIRECTORY");
        const fs::path dir(argv[1]);
        fs::create_directories(dir);
        check(fs::is_empty(dir), "test directory must be empty");
        const fs::path path = dir / "NM0003-test.txt";
        const std::string before = "!Folder:\r\n+Keep\r\n$20000100 00000001\r\n+Delete\r\n$20000104 00000002\r\n!!\r\n";
        const std::string after = "!Folder:\r\n+Keep\r\n$20000100 00000001\r\n!!\r\n";
        std::string error;
        UmaskGuard restore_umask;
        for (mode_t mask : {0022, 0077}) {
            umask(mask);
            for (mode_t mode : {0600, 0640, 0644, 0660, 0664, 0700}) {
                put(path, before);
                check(chmod(path.c_str(), mode) == 0, "fixture chmod failed");
                check(XemuCheatSource::Replace(path.string(), before, after, error), "replacement failed");
                check(error.empty(), "successful replacement retained an error");
                check(read(path) == after, "exact content/line endings not preserved");
                check(file_mode(path) == mode, "existing Unix permission mode changed");
                only_file(dir, path);
                const unsigned calls = writes;
                check(!XemuCheatSource::Replace(path.string(), before, "WRONG", error), "stale source accepted");
                check(!error.empty(), "stale source has no diagnostic");
                check(writes == calls, "stale refusal reached GLib write");
                check(read(path) == after, "stale refusal altered contents");
                check(file_mode(path) == mode, "stale refusal altered permissions");
                only_file(dir, path);
            }
        }
        // Replacement of the last bytes is legal, but must retain permissions.
        put(path, before);
        check(chmod(path.c_str(), 0600) == 0, "fixture chmod failed");
        check(XemuCheatSource::Replace(path.string(), before, "", error), "empty replacement failed");
        check(read(path).empty() && file_mode(path) == 0600, "empty replacement changed mode/content");
        only_file(dir, path);
        check(XemuCheatSource::Replace(path.string(), "", after, error), "empty source replacement failed");
        check(read(path) == after && file_mode(path) == 0600, "empty source changed mode/content");
        only_file(dir, path);
        // Injected write failure keeps the source and leaves no backup artifact.
        fail_next_write = true;
        check(!XemuCheatSource::Replace(path.string(), after, before, error), "injected write failure accepted");
        check(!error.empty() && !fail_next_write, "write failure was not reached/reported");
        check(read(path) == after && file_mode(path) == 0600, "write failure altered original");
        only_file(dir, path);
        const unsigned calls = writes;
        check(chmod(path.c_str(), 0400) == 0, "read-only fixture failed");
        check(!XemuCheatSource::Replace(path.string(), after, before, error), "read-only source accepted");
        check(read(path) == after && file_mode(path) == 0400, "read-only refusal altered file");
        check(writes == calls, "read-only refusal reached write");
        check(chmod(path.c_str(), 0600) == 0, "fixture restore failed");
        check(!XemuCheatSource::Replace("", "", before, error), "empty path accepted");
        check(!XemuCheatSource::Replace(dir.string(), "", before, error), "directory accepted");
        check(!XemuCheatSource::Replace((dir/"missing.txt").string(), "", before, error), "missing source accepted");
        check(!fs::exists(dir/"missing.txt"), "missing source was created");
        const fs::path link = dir / "alias.txt";
        fs::create_symlink(path.filename(), link);
        check(!XemuCheatSource::Replace(link.string(), after, before, error), "symlink accepted");
        check(fs::is_symlink(link) && read(path) == after, "symlink refusal altered source");
        fs::remove(link);
        check(writes == calls, "invalid source refusal reached write");
        only_file(dir, path);
        std::cout << "PASS: production source-file transaction: " << assertions
                  << " assertions; Unix modes, exact writes, refusals and no backup artifacts\n";
    } catch (const std::exception &error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
