#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Generic patch 30 VBlank/APU lock-convoy fix integration guard."""
from __future__ import annotations

import argparse
from pathlib import Path
from optional_patch_contract import optional_patch_enabled


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = Path(args.root)

    xemu_c = (root / "ui/xemu.c").read_text(encoding="utf-8")
    vp_c = (root / "hw/xbox/mcpx/apu/vp/vp.c").read_text(encoding="utf-8")

    # Keep the global UI helper's established main-loop -> BQL order untouched.
    require(
        xemu_c,
        "void xemu_main_loop_lock(void)\n{\n    qemu_mutex_lock_main_loop();\n    bql_lock();",
        "global xemu main-loop/BQL acquisition order",
    )
    require(
        xemu_c,
        "    bql_unlock();\n    qemu_mutex_unlock_main_loop();\n}",
        "global xemu BQL/main-loop release order",
    )

    if not optional_patch_enabled(30):
        print("PASS: global main-loop lock invariant; Patch 30 assertions not requested")
        return

    # Only the dedicated threaded VBlank path bypasses the custom main-loop
    # mutex. process_vblank() itself must still execute entirely with BQL held.
    vblank_start = xemu_c.index("static void *vblank_timer_thread")
    vblank_end = xemu_c.index("#if DEBUG_XEMU_C", vblank_start)
    vblank = xemu_c[vblank_start:vblank_end]
    require(vblank, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_VBLANK", "VBlank trace context")
    require(
        vblank,
        "bql_lock();\n            process_vblank(scon);\n            bql_unlock();",
        "VBlank direct-BQL critical section",
    )
    forbid(vblank, "xemu_main_loop_lock();", "threaded VBlank main-loop acquisition")
    forbid(vblank, "xemu_main_loop_unlock();", "threaded VBlank main-loop release")

    process_start = xemu_c.index("static void process_vblank")
    process_end = xemu_c.index("static void vblank_timer_callback", process_start)
    process = xemu_c[process_start:process_end]
    require(process, "assert(bql_locked());", "process_vblank BQL invariant")
    forbid(process, "bql_unlock();", "process_vblank BQL release")

    # Patch 305.3 supersedes Patch 30's BQL-drop workaround for VOICE_LOCK.
    # The guest MMIO method must now remain synchronous in effect without
    # blocking the vCPU on d->lock: voice_locked[] is already consumed through
    # qatomic_read(), so the producer uses matching atomic bit operations and
    # keeps the existing APU condition wake.
    voice_start = vp_c.index("static void voice_lock")
    voice_end = vp_c.index("static bool is_voice_locked", voice_start)
    voice = vp_c[voice_start:voice_end]
    for needle, label in (
        ("qatomic_or(&d->vp.voice_locked[v / 64], mask);", "atomic voice-lock set"),
        ("qatomic_and(&d->vp.voice_locked[v / 64], ~mask);", "atomic voice-lock clear"),
        ("qemu_cond_signal(&d->cond);", "APU condition signal"),
    ):
        require(voice, needle, label)

    forbid(voice, "qemu_mutex_lock(&d->lock);", "vCPU wait on APU frame mutex")
    forbid(voice, "bql_unlock();", "obsolete Patch-30 BQL-drop workaround")
    forbid(voice, "bql_lock();", "obsolete Patch-30 BQL-reacquire workaround")
    forbid(voice, "trylock", "voice-lock trylock bypass")

    print("PASS: Patch 30 VBlank fix retained; Patch 305.3 VOICE_LOCK no longer blocks the vCPU")


if __name__ == "__main__":
    main()
