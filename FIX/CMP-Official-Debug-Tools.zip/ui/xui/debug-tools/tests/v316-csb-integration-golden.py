#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
module = (root / "debug-tools-module.hh").read_text()
core = (root / "debug-tools.cc").read_text()
meson = (root / "meson.build").read_text()
csb = (root / "addons/custom-soundtrack-builder/custom-soundtrack-builder.cc").read_text()
stdb = (root / "addons/custom-soundtrack-builder/custom-soundtrack-builder-core.cc").read_text()

hdd = (root / "addons/custom-soundtrack-builder/custom-soundtrack-hdd.cc").read_text()
hdd_header = (root / "addons/custom-soundtrack-builder/custom-soundtrack-hdd.hh").read_text()
rpc = (root / "addons/hdd/guest-kernel-rpc-filesystem.cc").read_text()
rpc_scheduler = (root / "addons/hdd/guest-kernel-rpc.cc").read_text()
rpc_completion = (root / "addons/hdd/guest-kernel-rpc-completion.cc").read_text()
rpc_status = (root / "addons/hdd/guest-kernel-rpc-status.hh").read_text()
rpc_header = (root / "addons/hdd/guest-kernel-rpc.hh").read_text()
stream = (root / "addons/hdd/guest-kernel-rpc-stream.cc").read_text()
protocol = (root / "addons/hdd/kernel-rpc-stream.hh").read_text()
arena = (root / "addons/hdd/guest-kernel-rpc-memory.c").read_text()
readback = (root / "addons/hdd/hdd-snapshot-service.cc").read_text()
worker = csb.split("void CustomSoundtrackBuilder::BuildWorker(void *opaque)", 1)[1].split("void CustomSoundtrackBuilder::BuildComplete", 1)[0]
checks = {
    "module declaration": "debug_tools_register_csb_addition" in module,
    "module registration": "debug_tools_register_csb_addition();" in core,
    "debug menu label": 'debug_tools_register_menu_item(250, "CSB"' in csb,
    "detached title": 'xemu - Custom Soundtrack Builder' in csb,
    "drag drop": "SDL_EVENT_DROP_FILE" in csb and "SDL_AddEventWatch" in csb,
    "xemu file dialog declarations": '#include "../../../misc.hh"' in csb,
    "windows direct ffmpeg spawn": "CreateProcessW" in csb and "gspawn-win64-helper.exe" in csb,
    "ffmpeg wmav2": '"-c:a", "wmav2"' in csb,
    "ffmpeg 44100": '"-ar", "44100"' in csb,
    "ffmpeg stereo": '"-ac", "2"' in csb,
    "ffmpeg 128k": '"-b:a", "128k"' in csb,
    "xbox music path": '"fffe0000"' in hdd and '"music"' in hdd,
    "source-aware button": "m_destination.ButtonLabel()" in csb and "SAVE TO FOLDER HDD" in hdd_header and "SAVE TO MOUNTED HDD IMAGE" in hdd_header,
    "no duplicate HDD selector": "USE FOLDER-HDD ROOT" not in csb and "BrowseOutputRoot" not in csb,
    "isolated recovery transaction": 'const Path kRecoveryParent = {"TDATA", "CSBBACKUP"}' in hdd and '"database.new"' in hdd and '"database.bak"' in hdd and "PrepareHddCopy" in hdd,
    "ST.DB header magic": "PutU32(db, 0x0000, 1)" in stdb,
    "soundtrack magic": "0x00021371" in stdb,
    "song group magic": "0x00031073" in stdb,
    "six-song groups": "kSongsPerGroup = 6" in stdb,
    "active image identity": "xemu_disc_block_source_path" in hdd and "xemu_disc_block_identity" in hdd and "SameSource()" in hdd,
    "active Folder-HDD root": "cmp_folder_hdd_get_active_root" in hdd,
    "read-only rejection": "xemu_disc_block_is_read_only" in hdd,
    "existing kernel import/copy path": "PrepareHddImport" in hdd and "PrepareHddCopy" in hdd and "StartHddImport(plan, this)" in hdd,
    "existing kernel rename path": "StartHddRelocate(plan, this)" in hdd and "BuildRelocatePlan" in hdd,
    "serialized frontend sequence": "ClaimFilesystemSequence" in hdd and "ReleaseFilesystemSequence" in hdd and "SequenceAllows(sequence_owner)" in rpc,
    "verified bytes before publish": "ReadFatxFileChunk" in hdd and "verify_hash != file.hash" in hdd and "FingerprintStillMatches" in hdd,
    "case-correct FATX tokens": "FindChildNoCase" in hdd and "resolved_music" in hdd,
    "retains HDD safety limits": "kImportMaxTotalBytes" in hdd and "QueryPartitionCapacity" in hdd,
    "Folder-HDD mirror sync": hdd.count("RescanFolderHdd(error)") >= 2,
    "publish failure restore": "TryRestore" in hdd and "Publication/backup identity changed" in hdd,
    "no temporary ST.DB in recovery tree": 'database_new_path = Append(next->stage_path, "database.new")' in hdd and 'database_backup_path = Append(next->backup_path, "database.bak")' in hdd,
    "database published last": 'append(database_new_path, Append(music_path, "ST.DB"), true)' in hdd and r'the selected soundtrack is published before music\\ST.DB' in hdd,
    "fresh installed verification": "VerifyPublishedInstall" in hdd and "Published soundtrack file failed fresh FATX readback verification" in hdd and r"Published music\\ST.DB failed fresh FATX readback verification" in hdd,
    "current transaction cleanup only": "TransactionSafeToDelete" in hdd and "PrepareHddDelete('E', transaction_path, true" in hdd and "PrepareHddDelete('E', recovery_parent, true" in hdd,
    "legacy recovery untouched": "Legacy music.CSB-stage-* and" in hdd and "music.CSB-backup-* siblings under fffe0000 are deliberately ignored" in hdd,
    "deferred guest writes": "debug_tools_register_deferred_action(225, ProcessCsbDeferred)" in csb,
    "private conversion staging": "g_dir_make_tmp" in worker and "m_installer" not in worker and "guest_kernel_rpc_manager" not in worker and "RescanFolderHdd" not in worker,
    "reset cancels remaining work": "debug_tools_register_reset(225, ResetCsb)" in csb and "cancel_requested.store(true)" in csb,
    "existing soundtrack catalog": "ReadCsbHddMusicCatalog" in hdd and "DrawExistingCatalog" in csb,
    "multi soundtrack ST.DB": "ReadStDb(" in stdb and "WriteStDb(" in stdb and "kSoundtrackSlots = 100" in stdb,
    "safe ID collision handling": "already exists. Click that soundtrack" in csb and "orphan folder" in csb,
    "delete soundtrack action": "CONFIRM DELETE SOUNDTRACK" in csb and "delete_soundtrack" in hdd_header,
    "retained existing tracks": "retained_song_ids" in hdd_header and "PrepareHddCopy" in hdd,
    "reduced-profile backend": "custom-soundtrack-hdd-stub.cc" in meson and "custom-soundtrack-hdd.cc" in meson,
    "incremental selected soundtrack": "Only the selected ID and database are ever moved" in hdd and "BuildCommitMoves" in hdd,
    "metadata-only catalog fingerprint": "tree_identity_hash" in hdd_header and "TreeIdentityHash" in hdd,
    "existing record merge validation": "Local ST.DB would change an unrelated soundtrack" in hdd,
    "cancellable owned sequence opt-in": "ClaimFilesystemSequence(next.get(), error, true, edit.fast_stream, edit.stream_chunk_bytes)" in hdd and "bool cancellable_wait = false" in rpc_header,
    "preserves legacy safe-point timeout": "!m_sequence_cancellable_wait" in rpc_scheduler and "kSafePointTimeoutMs" in rpc_scheduler,
    "safe-boundary cancellation only": "CancelAtSafeBoundary" in rpc and "State::WaitingSafePoint" in rpc and "xemu_guest_rpc_arena_active()" in rpc,
    "real pending wait progress": "WAITING FOR SAFE HDD WRITE" in rpc_scheduler and "CsbSafePointSampleDelay" in rpc_scheduler,
    "bounded verified import continuation": "CsbImportBurstMayContinue" in rpc_completion and "operations < 4" in rpc_status and "elapsed_ms < 50" in rpc_status,
    "continuation context revalidation": "ValidateCapturedContext" in rpc_scheduler.split("void GuestKernelRpcManager::ContinueImportBurst()", 1)[1].split("bool GuestKernelRpcManager::BeginReadOnlyFsAttempt",1)[0],
    "in-flight safety timeout retained": "SDL_GetTicks() - m_started_ms > 3000u" in rpc_scheduler and "State::Failed" in rpc_scheduler and "Xbox left paused with the RPC mapping owned; reset before retrying." in rpc_scheduler,
    "publication result reconciliation": "ReconcileMove" in hdd and "Ambiguous publication result" in hdd,
    "no blind recovery overwrite": "Refusing to overwrite an occupied publication/recovery path" in hdd,
    "persistent local recovery receipt": "CSB-INSTALL-RECOVERY.txt" in hdd and "Completed publication moves" in hdd,
    "cancellable UI": "CANCEL CSB OPERATION" in csb and "m_cancel_requested" in csb,
    "frozen editor catalog baseline": "m_editor_fingerprint" in csb and "m_editor_destination" in csb,
    "converted tracks become HDD entries": "track.from_hdd = true" in csb,
    "fast stream source compiled": "guest-kernel-rpc-stream.cc" in meson,
    "fast lease is opt-in": "bool fast_stream = false" in rpc_header,
    "512 KiB bounded payload": "kChunkBytes=512u*1024u" in protocol and "kArenaBytes=kData+kChunkBytes" in protocol,
    "legacy arena preserved": "#define XEMU_RPC_ARENA_SIZE      0x00010000u" in arena,
    "bounded sized arena": "min_size > XEMU_RPC_ARENA_MAX_SIZE" in arena and "size / XEMU_RPC_PAGE_SIZE" in arena,
    "page mapping checked on continuation": "xemu_guest_rpc_arena_validate()" in stream and "xemu_rpc_active_size / XEMU_RPC_PAGE_SIZE" in arena,
    "file context stays pinned": "SAME original borrowed thread/stack" in stream and "!StreamCompletionContext(error)" in stream,
    "unexpected pending status fails closed": "S::HasPending(r)" in stream and "void GuestKernelRpcManager::FailStreamUnsafe" in stream,
    "no per-chunk destination snapshot": "BuildRawPartitionSetSnapshot" not in stream and "ReadFatxFileChunk" not in stream,
    "stream final full readback": "VerifyFatxFileHash" in stream and "VerifyFatxCopyContents" in stream and "m_stream_contents_verified=true" in stream,
    "no duplicate CSB verification after proof": "guest_kernel_rpc_manager.LastImportContentsVerified()" in hdd,
    "completion proof requires passed state": "m_state == State::Passed && m_stream_contents_verified" in rpc_header,
    "separate final verification state": "State::VerifyingImport" in rpc_scheduler and "VerifyFastImport()" in stream,
    "cancelled stream closes at checked boundary": "Action::CloseOnly" in stream and "m_filesystem_cancel_requested" in stream,
    "coherent readback helper": "bool HddSnapshotService::VerifyFatxFileHash" in readback and "UpdateContentHash" in readback,
    "macro-safe protocol fields": "close_fn" in protocol and "write_status" in protocol and "close_status" in protocol,
    "CSB fast streaming always enabled": csb.count("job->edit.fast_stream = true;") == 2 and "m_fast_stream" not in csb,
    "actual transfer statistics": "TransferSummary()" in csb and "UpdateTransferSummary" in hdd and "rpc_ms" in hdd,
    "4 MiB stream protocol bound": "kMaxChunkBytes=4u*1024u*1024u" in protocol and "length>kMaxChunkBytes" in protocol,
    "4 MiB plus overhead arena": "0x00402000u" in arena and "XEMU_RPC_MAX_PDES        2u" in arena,
    "all PDEs checked and restored": "xemu_rpc_original_pde[n]" in arena and "n < xemu_rpc_pde_count" in arena and "n < xemu_rpc_attempted_pdes" in arena,
    "failed install write ownership": "xemu_rpc_attempted_pdes = n + 1u" in arena,
    "no stream-size changes mid-operation": "m_sequence_stream_chunk_bytes" in rpc and "m_stream_metrics.chunk_bytes=m_sequence_stream_chunk_bytes" in rpc,
    "explicit supported chunk policy": "SupportedChunkBytes(stream_chunk_bytes)" in rpc and "SupportedChunkBytes(edit.stream_chunk_bytes)" in hdd,
    "right-sized small file arena": "ArenaBytesForFile(" in stream and "n < chunk ? n : chunk" in protocol,
    "direct two-span refill": "xemu_guest_rpc_arena_writev(spans,count?2u:1u)" in stream and "std::array<uint8_t,S::kData> payload{}" in stream and "payload.begin()+S::kData" not in stream,
    "bounded atomic validation before refill": "count > 2" in arena and "parts[n].offset < previous_end" in arena,
    "4 MiB UI default and comparison sizes": "kCsbDefaultStreamChunkIndex = 3" in hdd_header and "Maximum Write Chunk" in csb and "4 MiB (default)" in csb,
    "refill statistics": "refill_ms" in stream and "Refill %.3f s" in hdd,
    "dashboard soundtrack ID index array": "0x000C + slot * 4" in stdb and "soundtrack_id_index_matches_records" in stdb,
    "dashboard packed 32-bit song IDs": "packed_song_id" in stdb and "soundtrack.soundtrack_id) << 16" in stdb and "PutU32(db, g + 0x010 + item * 4, packed_song_id)" in stdb,
    "dashboard nextSongId allocation": "m_catalog.next_song_id" in csb and "for (const auto &soundtrack : m_catalog.soundtracks)" in csb and "if (track.song_id == candidate) return true" in csb,
    "dashboard monotonic counter floors": "minimum_next_soundtrack_id" in stdb and "minimum_next_song_id" in stdb and "job->db_write_options.minimum_next_song_id = m_catalog.next_song_id" in csb,
    "guarded dashboard index repair SAVE": "!m_catalog.soundtrack_id_index_consistent" in csb and "ST.DB dashboard soundtrack index needs repair" in csb,
    "side-by-side scrollable workspace": 'BeginTable("##csb_workspace", 3' in csb and 'BeginChild("##csb_editor_panel"' in csb and 'BeginChild("##csb_catalog_panel"' in csb and 'BeginChild("##csb_track_panel"' in csb,
    "four column HDD table": 'BeginTable("##csb_existing", 4' in csb and '"Songs Count"' in csb and '"Sound Track Name"' in csb,
    "five column tracks table": 'BeginTable("##csb_tracks", 5' in csb and '"Xbox File"' in csb,
    "File and Options menus": 'BeginMenu("File")' in csb and 'BeginMenu("Options")' in csb and 'MenuItem("Open Last Output"' in csb and 'MenuItem("Add File"' in csb and 'MenuItem("Clear Editor"' in csb,
    "single click selection": 'ImGuiSelectableFlags_SpanAllColumns' in csb and 'RequestEditorAction(EditorAction::Select, select_id)' in csb,
    "stable-ID insertion drag": 'ReorderTrack(dropped.song_id, insertion, dropped.revision)' in csb and 'revision != m_editor_revision' in csb and 'std::rotate' in csb and 'payload->IsDelivery()' in csb,
    "unsaved edit protection": 'Unsaved soundtrack changes' in csb and 'KEEP EDITING' in csb and 'm_pending_action_fingerprint' in csb,
    "frozen deletion confirmation": 'm_delete_fingerprint == m_catalog.fingerprint' in csb and 'SameCsbHddDestination(m_delete_destination, m_destination)' in csb,
    "orphan view stays read only": 'm_viewing_orphan = !soundtrack->listed_in_database' in csb and 'EditorReadOnly()' in csb,
    "menu output navigation deferred": 'm_open_output_requested = true' in csb and 'if (m_open_output_requested)' in csb,
    "cached FFmpeg display": 'm_ffmpeg_display = FindFfmpeg()' in csb and 'm_next_ffmpeg_refresh = now + 2000' in csb,
    "meson source": "custom-soundtrack-builder.cc" in meson and "custom-soundtrack-builder-core.cc" in meson,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit("FAIL: " + ", ".join(failed))
print(f"PASS: CSB integration static guards ({len(checks)} checks)")
