#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Regression guard for v1.94 OPT Pass 9 audit/pruning cleanup."""
from __future__ import annotations

import argparse
import hashlib
import pathlib

from v287_source_test_utils import (
    restore_cleanup_pass6_external_le32, restore_cleanup_pass7_historical_runtime,
    strip_preentry_cheat_header_additions,
)


PROTECTED_V193_SHA256 = {
    "cheat-engine.hh": "68b92ae21c2b0aca187aa38e79449fb60f5f936195cc31a11dd0e662a28c4817",
    "cheat-engine-memory.c": "3baca8753b0aa7bbdae4693545e87d058d00d28795cf5f6a3682738afaf89460",
    "cheat-engine-memory.h": "e47bb779c456cc58bc3bd6e7852c1f72332af4c35d8d82f6195eb1e62bc79d90",
    "external-code-memory.c": "1c4be7e4aa84cce48137b73d9baf015e23be41e587e1fa2e45d6a0a187aac3a2",
    "addons/memory-tools/memory-tools.hh": "42df7062c462dd16bccd64fcaa7fe9b39de5808b6898ea89a975be84bfbeb847",
    "addons/memory-tools/memory-tools.cc": "e0dfa3ab88e71cc4bc3f4b2879dc2c898c5987b39b87fe79c5e72cb5ac968a5c",
    "addons/memory-tools/memory-tools-memory.cc": "cc342f973e9ecbc2f667b147f41686fd56063aa558a68035583d4f12e5987cda",
    "addons/memory-tools/memory-tools-search.cc": "95bf09f34ed0e15525deeb6ff5524cc39ce26f760f9e5ed9bf23c378df799636",
    "addons/memory-tools/memory-tools-inject.cc": "07ca236adbe9b879b69b0557cd11189e1deaa50e0509fb7525a82d418d9d4609",
    "backend/xemu-dbg.c": "0fff339f0c480f2654d8d8805820fae462cff11b85a1c7e11a23ca074429c1ef",
    "backend/whpx-debug.c": "7ba0d7e6d5efacf298ff07520c6bb40df7a947e925b8ef9c05f7e8cac8b66368",
    "x86-cheat-assembler.cc": "b921bce1fb3cbd9183a40351452960c3661b6010d4220ccb6544f82cf5a96f43",
    "x86-cheat-assembler.hh": "863e65c3b20d635f186bd3a047cce4a4ee0e29eaff95711d984eab0bcdbe27cc",
    "xbe-labels.cc": "84b4357567de9b78ba09b00059290f75fc21874aa14020dde363a6f75b0314ee",
    "xbe-labels.hh": "9317ff5514dbd63d41d22111ec9a6d7faed40c27a298953095e10fcdf066ab7b",
    "label-packs.cc": "221fac334e614a4e900cf9383d27c6862be3ad2e17841aa8b0bd4688fc2be126",
    "label-packs.hh": "e09a4c21522bcdbe6648fd8de5da150ea475ed8984f7ed64a989cb8f249d55da",
    "xdk-labels.cc": "cdece8af036195fa32d2ae9d834ab5b363822e8ff65e052ae254333e264cf47c",
    "xdk-labels.hh": "ba221587593588412c5d21485fea4e96ecbc67c2f216d20fbcb284791edcc73e",
    "xdvdfs-disc.cc": "9546c72a5918b3aedb50ce713a53a7e6ee604f9f5b050b5c56e58c50dbce8b85",
    "xdvdfs-disc.hh": "eb859f9b28f47278098df89702d91db3567f6fd55b1d6b29bb4e3e83f028e24b",
}


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    tests = debug / "tests"

    # Behavior-sensitive runtime paths outside the explicitly audited label
    # parser/dead API files, later Pass-10 lifecycle ownership files, and the
    # separately guarded v1.97 detached-window playback fix, v1.98 register-copy
    # UI path, and v2.04 BlockBackend FATX delete bridge remain byte-identical
    # to v1.93. Later guards fingerprint their explicitly allowed files.
    later_scoped_runtime = {
        # v3.15 Patch 302 Type-F2 extends the shared Type-F header and is
        # guarded by the current F0/F2 and native F2 regression tests.
        "cheat-engine.hh",
        # v3.15 self-synchronizing detached guest-access bridge.
        "cheat-engine-memory.c",
        "cheat-engine-memory.h",  # v2.86 removes only a stale orphan comment.
        # v2.83 Combined Phase 8 owns the split Inject UI and x86 assembler files.
        "addons/memory-tools/memory-tools-inject.cc", "addons/memory-tools/memory-tools-inject-ui.cc",
        "x86-cheat-assembler.cc", "x86-cheat-assembler-keystone.cc",
        "x86-cheat-assembler-internal.hh", "x86-cheat-assembler.hh",
        "xdvdfs-disc.cc", "xdvdfs-disc.hh",
        # v2.73 consolidates duplicate parser helpers; its dedicated guard
        # freezes the exact replacement and both parsers remain native-tested.
        "xbe-labels.cc", "xdk-labels.cc",
        "label-packs.cc",  # v2.86 reuses shared ASCII uppercase helper.
        # v2.74 Inject Restore / Change crash fix is separately fingerprinted.
        "addons/memory-tools/memory-tools.hh", "addons/memory-tools/memory-tools-inject.cc",
        # v2.79 Memory Viewer UI/core ownership split.
        "addons/memory-tools/memory-tools-memory.cc",
        # v2.91.9 Execution Trace is separately guarded and intentionally
        # extends the Memory Tools facade plus target-specific debug bridges.
        "addons/memory-tools/memory-tools.cc",
        "backend/xemu-dbg.c", "backend/whpx-debug.c",
        # v2.82 Combined Phase 7 Search UI ownership split.
        "addons/memory-tools/memory-tools-search.cc",
    }
    for rel, expected in PROTECTED_V193_SHA256.items():
        if rel in later_scoped_runtime:
            continue
        if rel == "external-code-memory.c":
            data = (debug / rel).read_text(encoding="utf-8")
            actual = hashlib.sha256(restore_cleanup_pass6_external_le32(data).encode("utf-8")).hexdigest()
        elif rel == "cheat-engine.hh":
            data = (debug / rel).read_text(encoding="utf-8")
            actual = hashlib.sha256(
                strip_preentry_cheat_header_additions(data).encode("utf-8")
            ).hexdigest()
        elif rel == "addons/memory-tools/memory-tools.cc":
            data = (debug / rel).read_text(encoding="utf-8")
            include = '#include "tab-style.hh"\n'
            if data.count(include) != 1:
                raise AssertionError("Debug Tools memory-tools tab-style include changed unexpectedly")
            data = data.replace(include, "", 1)
            scoped = '    XemuDebugUi::ScopedTabStyle tab_style;\n'
            restore = '    tab_style.Restore();\n'
            push = '    XemuDebugUi::PushTabStyle();\n'
            pop = '    XemuDebugUi::PopTabStyle();\n'
            if data.count(scoped) == 1 and push not in data and pop not in data:
                data = data.replace(scoped, "", 1)
                if data.count(restore) == 1:
                    data = data.replace(restore, "", 1)
            elif data.count(push) == 1 and data.count(pop) == 1 and scoped not in data:
                data = data.replace(push, "", 1).replace(pop, "", 1)
            else:
                raise AssertionError("Debug Tools memory-tools tab-style ownership changed unexpectedly")
            actual = hashlib.sha256(data.encode("utf-8")).hexdigest()
        elif rel == "xbe-labels.hh":
            data = restore_cleanup_pass7_historical_runtime(rel, (debug / rel).read_bytes())
            actual = hashlib.sha256(data).hexdigest()
        elif rel != "external-code-memory.c":
            actual = sha256(debug / rel)
        if actual != expected:
            raise AssertionError(f"protected v1.93 runtime file changed: {rel}")

    shared = (debug / "label-symbol-utils.hh").read_text(encoding="utf-8")
    map_cc = (debug / "map-labels.cc").read_text(encoding="utf-8")
    pdb_cc = (debug / "pdb-labels.cc").read_text(encoding="utf-8")
    bp_cc = (debug / "addons/memory-tools/breakpoint-conditions.cc").read_text(encoding="utf-8")
    bp_hh = (debug / "addons/memory-tools/breakpoint-conditions.hh").read_text(encoding="utf-8")

    for helper in ("all_digits", "clean_c_symbol", "split_at", "simple_msvc_name",
                   "compiler_internal_symbol", "display_microsoft_symbol"):
        if f"inline " not in shared or f"{helper}(" not in shared:
            raise AssertionError(f"shared Microsoft symbol helper missing: {helper}")

    if "XemuLabelSymbolUtils::display_microsoft_symbol(symbol.name)" not in map_cc:
        raise AssertionError("MAP parser is not using shared Microsoft display helper")
    if "XemuLabelSymbolUtils::display_microsoft_symbol(name)" not in pdb_cc:
        raise AssertionError("PDB parser is not using shared Microsoft display helper")
    for cc, label in ((map_cc, "MAP"), (pdb_cc, "PDB")):
        if "static bool compiler_internal_symbol(" in cc:
            raise AssertionError(f"{label} parser still owns duplicate compiler filter")

    # MAP and PDB intentionally retain distinct compiler-internal filters.
    if 'name.rfind("___@@_PchSym_", 0)' in map_cc or 'name.rfind("??_C@", 0)' in map_cc:
        raise AssertionError("PDB-only internal-symbol filters leaked into MAP behavior")
    for needle in ('name.rfind("___@@_PchSym_", 0)', 'name.rfind("??_C@", 0)'):
        if needle not in pdb_cc:
            raise AssertionError(f"PDB internal-symbol filter changed: {needle}")

    # This exported register-name helper had no source caller in v1.93. Pass 9
    # removes the dead declaration/definition without touching parse/evaluate.
    dead_api = "xemu_breakpoint_condition_register_name"
    if dead_api in bp_cc or dead_api in bp_hh:
        raise AssertionError("dead breakpoint-condition register-name API returned")
    for live_api in ("xemu_breakpoint_conditions_parse", "xemu_breakpoint_conditions_evaluate"):
        if live_api not in bp_cc or live_api not in bp_hh:
            raise AssertionError(f"live breakpoint-condition API missing: {live_api}")

    source_utils = (tests / "v287_source_test_utils.py").read_text(encoding="utf-8")
    if "def extract_member_functions(text: str, class_name: str)" not in source_utils:
        raise AssertionError("shared class-member source-test extractor missing")
    for name in (
        "v287-memory-tools-structural-refactor-golden.py",
        "v287-runtime-xbe-polling-golden.py",
        "v287-debugger-steady-state-render-golden.py",
        "v287-display-label-cache-golden.py",
        "v287-table-list-render-golden.py",
    ):
        text = (tests / name).read_text(encoding="utf-8")
        if "def member_functions(" in text:
            raise AssertionError(f"duplicated member-function extractor returned: {name}")
        if "extract_member_functions" not in text:
            raise AssertionError(f"shared member extractor not used: {name}")

    print("PASS: v1.94 Pass-9 audit/pruning/technical-debt invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
