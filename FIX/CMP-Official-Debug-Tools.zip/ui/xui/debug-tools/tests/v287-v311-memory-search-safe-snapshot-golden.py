#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.11 Memory Search safe snapshot + live RAM dump ownership guard."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from v287_source_test_utils import extract_function


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    dbg = root / "ui/xui/debug-tools"
    mem = dbg / "addons/memory-tools"

    header = (mem / "memory-tools.hh").read_text(encoding="utf-8")
    core = (mem / "memory-tools.cc").read_text(encoding="utf-8")
    search = (mem / "memory-tools-search.cc").read_text(encoding="utf-8")
    search_ui = (mem / "memory-tools-search-ui.cc").read_text(encoding="utf-8")
    dump = (mem / "memory-tools-dump.cc").read_text(encoding="utf-8")
    dump_ui = (mem / "memory-tools-dump-ui.cc").read_text(encoding="utf-8")
    addon = (mem / "debug-tools-memory-tools-addon.cc").read_text(encoding="utf-8")
    reset_ui = (mem / "memory-tools-debugger-ui.cc").read_text(encoding="utf-8")

    # Hidden/precreated window and prewarmed normal Xbox working set.
    require(addon, "DrawMemoryToolsDetached,\n        400,\n        true,",
            "hidden detached Memory Tools precreation")
    for token in (
        "m_snapshot.resize(kSearchPrewarmBytes);",
        "m_capture_snapshot.resize(kSearchPrewarmBytes);",
        "m_dump_snapshot.resize(kSearchPrewarmBytes);",
    ):
        require(core, token, "64 MB prewarmed host buffer")
    require(core, "kSearchPrewarmBytes = 64u * 1024u * 1024u",
            "normal Xbox 64 MB prewarm size")

    # Search: coherent guest capture only, worker operates on host copies.
    capture = extract_function(search, "bool MemoryToolsWindow::CaptureSnapshotInto(")
    require(capture, "XemuDebugGuestPauseGuard guest_pause;",
            "scoped automatic guest pause")
    require(capture, "guest_pause.Resume();", "immediate resume after capture")
    require(capture, "whole_range_ok = Read(m_search_space, m_scan_start,",
            "bulk physical snapshot fast path")
    require(capture, "for (size_t page = 0; page < page_count; ++page)",
            "page fallback for holes/virtual ranges")

    worker = extract_function(search, "void MemoryToolsWindow::RunSearchJob(")
    require(worker, "job->current_snapshot", "worker-owned current snapshot")
    require(worker, "job->previous_snapshot", "worker-owned previous snapshot")
    require(worker, "Stable in-place compaction", "result allocation reuse")
    forbid(worker, "Read(", "live guest read from Search worker")
    forbid(worker, "ReadRaw(", "per-result live guest read from Search worker")
    forbid(worker, "xemu_cheat_memory_read", "guest-memory bridge in Search worker")

    first = extract_function(search, "void MemoryToolsWindow::FirstScan(")
    next_scan = extract_function(search, "void MemoryToolsWindow::NextScan(")
    for body, label in ((first, "First Scan"), (next_scan, "Next Scan")):
        require(body, "CaptureSnapshotInto(", f"{label} safe capture")
        require(body, "QueueSearchJob(job)", f"{label} background filtering")
    require(search, "debug_tools_queue_background_job(&MemoryToolsWindow::RunSearchJob",
            "shared Debug Tools worker routing")
    require(search_ui, "ImGui::BeginDisabled(m_search_busy);",
            "Search controls locked only while worker job is active")
    require(search_ui, "The guest has already resumed.",
            "live-search user feedback")
    require(search_ui, "Last safe capture:", "Search pause/capture/worker timing")

    # Full RAM dump: one coherent physical snapshot, immediate resume, then
    # disk/virtual-region reconstruction exclusively on the worker.
    dump_ram = extract_function(dump, "void MemoryToolsWindow::DumpRam(")
    require(dump_ram, "XemuDebugGuestPauseGuard guest_pause;",
            "RAM dump automatic guest pause")
    require(dump_ram, "CollectRamVirtualPages(ram_size, job->virtual_pages",
            "virtual map captured in same paused state")
    require(dump_ram, "Read(AddressSpace::Physical, 0x00000000u,",
            "single coherent physical RAM source")
    require(dump_ram, "guest_pause.Resume();", "RAM dump immediate guest resume")
    require(dump_ram, "QueueDumpJob(job)", "RAM dump background file write")

    dump_worker = extract_function(dump, "void MemoryToolsWindow::RunDumpJob(")
    require(dump_worker, "job->physical_snapshot.data()",
            "background write from host physical snapshot")
    require(dump_worker, "mapping.physical_page",
            "virtual regions rebuilt from captured physical page mapping")
    forbid(dump_worker, "Read(", "live guest read from RAM dump worker")
    forbid(dump_worker, "DumpRange(", "legacy paused guest dump path on worker")
    require(dump_ui, "resume the guest immediately, then write files in the background",
            "live RAM dump UI contract")
    require(dump_ui, "ImGui::BeginDisabled(m_dump_busy);",
            "single in-flight dump UI guard")
    require(dump_ui, "Guest is running; dump files are being written in the background.",
            "live RAM dump status")

    # Game reset must invalidate in-flight search results while allowing an
    # already captured dump to finish as a coherent pre-reset artifact.
    require(reset_ui, "memory_tools_window.NotifySearchGameReset();",
            "Search reset generation invalidation")
    require(reset_ui, "memory_tools_window.NotifyDumpGameReset();",
            "RAM dump reset generation tracking")
    require(header, "bool m_search_busy = false;", "Search job state")
    require(header, "bool m_dump_busy = false;", "RAM dump job state")

    print("PASS: v3.11 Memory Search safe snapshot/live RAM dump ownership and worker isolation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
