#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 11 BQL/main-loop lock-trace common-core guard."""
from __future__ import annotations

import argparse
from pathlib import Path

from v287_source_test_utils import extract_function


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root).resolve()
    dt = root / "ui/xui/debug-tools"
    diag = dt / "addons/diagnostics"

    common_h = (diag / "lock-trace-common.h").read_text(encoding="utf-8")
    common_c = (diag / "lock-trace-common.c").read_text(encoding="utf-8")
    bql_h = (diag / "bql-trace.h").read_text(encoding="utf-8")
    bql_c = (diag / "bql-trace.c").read_text(encoding="utf-8")
    main_h = (diag / "main-loop-lock-trace.h").read_text(encoding="utf-8")
    main_c = (diag / "main-loop-lock-trace.c").read_text(encoding="utf-8")
    meson = (dt / "meson.build").read_text(encoding="utf-8")

    require(meson, "'addons/diagnostics/lock-trace-common.c',",
            "shared lock-trace core build ownership")

    # One authoritative event/status layout is shared by both recorder ABIs.
    require(common_h, "typedef struct XemuDebugToolsLockTraceEvent {",
            "shared event record")
    require(common_h, "typedef struct XemuDebugToolsLockTraceStatus {",
            "shared status record")
    require(bql_h, "typedef XemuDebugToolsLockTraceEvent XemuDebugToolsBqlTraceEvent;",
            "BQL event alias")
    require(bql_h, "typedef XemuDebugToolsLockTraceStatus XemuDebugToolsBqlTraceStatus;",
            "BQL status alias")
    require(main_h,
            "typedef XemuDebugToolsLockTraceEvent XemuDebugToolsMainLoopLockTraceEvent;",
            "main-loop event alias")
    require(main_h,
            "typedef XemuDebugToolsLockTraceStatus XemuDebugToolsMainLoopLockTraceStatus;",
            "main-loop status alias")
    for header, label in ((bql_h, "BQL"), (main_h, "main-loop")):
        forbid(header, "uint64_t sequence;", f"duplicate {label} event layout")
        forbid(header, "uint64_t total_events;", f"duplicate {label} status layout")

    # Ring/owner/TLS mechanics live only in the common core.
    for token, label in (
        ("committed_sequence_plus_one", "lock-free ring commit"),
        ("lock_trace_attempt_tls", "attempt TLS"),
        ("lock_trace_next_context_tls", "next-context TLS"),
        ("owner_longest_stage_ns", "longest owner-stage timing"),
        ("xemu_debug_tools_diagnostics_current_cpu_context", "CPU-context capture"),
        ("XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE", "buffer allocation"),
        ("XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO", "buffer clearing"),
    ):
        require(common_c, token, label)
        forbid(bql_c, token, f"duplicated BQL {label}")
        forbid(main_c, token, f"duplicated main-loop {label}")

    # Preserve the intentional disabled-state differences instead of normalizing them.
    bql_policy = '''[XEMU_DEBUG_TOOLS_LOCK_TRACE_BQL] = {
            .clear_full_attempt_when_disabled = 1,
            .observe_acquire_when_disabled = 1,
            .clear_owner_when_disabled = 1,'''
    main_policy = '''[XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP] = {
            .clear_full_attempt_when_disabled = 0,
            .observe_acquire_when_disabled = 0,
            .clear_owner_when_disabled = 0,'''
    require(common_c, bql_policy, "BQL disabled-state policy")
    require(common_c, main_policy, "main-loop disabled-state policy")

    acquired = extract_function(
        common_c, "void xemu_debug_tools_lock_trace_core_lock_acquired(")
    if acquired.index("!policy->observe_acquire_when_disabled") > acquired.index(
        "qemu_clock_get_ns(QEMU_CLOCK_HOST)"):
        raise AssertionError("main-loop disabled acquire must return before host-clock read")
    require(acquired, "qatomic_set(&trace->owner_thread_id, tid);",
            "owner publication")
    require(acquired, "smp_wmb();", "owner metadata publication barrier")

    unlock_end = extract_function(
        common_c, "void xemu_debug_tools_lock_trace_core_unlock_end(")
    require(unlock_end, "!policy->clear_owner_when_disabled",
            "disabled unlock policy")
    require(unlock_end, "lock_trace_clear_owner(trace, qemu_get_thread_id());",
            "shared owner clear")

    # Public APIs remain separate thin facades, including BQL -> main-loop context/stage propagation.
    require(bql_c,
            "xemu_debug_tools_main_loop_lock_trace_set_next_context(context);",
            "BQL context propagation")
    require(bql_c,
            "xemu_debug_tools_main_loop_lock_trace_owner_stage_begin(stage);",
            "BQL stage-begin propagation")
    require(bql_c,
            "xemu_debug_tools_main_loop_lock_trace_owner_stage_end();",
            "BQL stage-end propagation")
    for source, kind, label in (
        (bql_c, "XEMU_DEBUG_TOOLS_LOCK_TRACE_BQL", "BQL"),
        (main_c, "XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP", "main-loop"),
    ):
        for api in (
            "lock_attempt", "lock_acquired", "unlock_begin", "unlock_end",
            "set_enabled", "set_buffer_multiplier", "get_buffer_multiplier",
            "get_buffer_capacity", "clear", "get_status", "snapshot",
        ):
            require(source, f"xemu_debug_tools_lock_trace_core_{api}",
                    f"{label} {api} core forwarding")
        require(source, kind, f"{label} recorder identity")

    # Keep the facade files small so the duplicated implementation cannot creep back.
    if len(bql_c.splitlines()) > 120:
        raise AssertionError("BQL facade regrew duplicated recorder implementation")
    if len(main_c.splitlines()) > 120:
        raise AssertionError("main-loop facade regrew duplicated recorder implementation")

    print("PASS: Cleanup Pass 11 shares BQL/main-loop lock-trace mechanics while preserving recorder-specific policies")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
