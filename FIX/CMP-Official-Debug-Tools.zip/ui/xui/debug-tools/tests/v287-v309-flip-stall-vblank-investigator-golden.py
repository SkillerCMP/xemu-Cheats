#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.09 FLIP_STALL/VBlank investigator ownership + integration guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    diag = debug / "addons/diagnostics"

    for rel in (
        "flip-stall-trace-hook.h",
        "flip-stall-trace.h",
        "flip-stall-trace.c",
    ):
        if not (diag / rel).is_file():
            raise AssertionError(f"missing v3.09 Diagnostics file: {rel}")
    stub = debug / "addons/stubs/flip-stall-trace-stub.c"
    if not stub.is_file():
        raise AssertionError("missing v3.09 disabled-profile stub")

    hook_files = set()
    for top in (root / "hw", root / "ui"):
        for path in top.rglob("*"):
            if not path.is_file() or "debug-tools" in path.parts:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if "flip-stall-trace-hook.h" in text or "xemu_debug_tools_flip_stall_trace_" in text:
                hook_files.add(path.relative_to(root).as_posix())
    expected_hooks = {
        "hw/xbox/nv2a/nv2a.c",
        "hw/xbox/nv2a/pfifo.c",
        "hw/xbox/nv2a/pgraph/pgraph.c",
        "hw/xbox/nv2a/pgraph/vk/draw.c",
    }
    if hook_files != expected_hooks:
        raise AssertionError(
            f"FLIP_STALL external hook surface changed: {sorted(hook_files)}"
        )

    hook = (diag / "flip-stall-trace-hook.h").read_text(encoding="utf-8")
    impl = (diag / "flip-stall-trace.c").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    backend_h = (diag / "diagnostics-backend.h").read_text(encoding="utf-8")
    pgraph = (root / "hw/xbox/nv2a/pgraph/pgraph.c").read_text(encoding="utf-8")
    pfifo = (root / "hw/xbox/nv2a/pfifo.c").read_text(encoding="utf-8")
    nv2a = (root / "hw/xbox/nv2a/nv2a.c").read_text(encoding="utf-8")
    vk_draw = (root / "hw/xbox/nv2a/pgraph/vk/draw.c").read_text(encoding="utf-8")

    for event in (
        "XEMU_DEBUG_TOOLS_FLIP_SET_READ",
        "XEMU_DEBUG_TOOLS_FLIP_SET_WRITE",
        "XEMU_DEBUG_TOOLS_FLIP_SET_MODULO",
        "XEMU_DEBUG_TOOLS_FLIP_INCREMENT_WRITE",
        "XEMU_DEBUG_TOOLS_FLIP_STALL_BEGIN",
        "XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_BEGIN",
        "XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_END",
        "XEMU_DEBUG_TOOLS_FLIP_WAITING_SET",
        "XEMU_DEBUG_TOOLS_FLIP_VBLANK_IRQ",
        "XEMU_DEBUG_TOOLS_FLIP_VBLANK_READ_INCREMENT",
        "XEMU_DEBUG_TOOLS_FLIP_PFIFO_CHECK_STALL",
        "XEMU_DEBUG_TOOLS_FLIP_PFIFO_RELEASE",
    ):
        require(hook, event, f"flip event {event}")
    forbid(hook, "QemuMutex", "recorder state in hook contract")

    require(impl, "XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY", "bounded flip ring")
    require(impl, "active_stall_start_host_ns", "cross-thread active stall timing")
    require(impl, "cpu->cc->get_pc(cpu)", "guest PC capture")
    require(impl, "NV_PGRAPH_SURFACE_READ_3D", "READ_3D snapshot")
    require(impl, "NV_PGRAPH_SURFACE_WRITE_3D", "WRITE_3D snapshot")
    require(impl, "NV_PGRAPH_SURFACE_MODULO_3D", "MODULO_3D snapshot")

    for method, event in (
        ("DEF_METHOD(NV097, SET_FLIP_READ)", "XEMU_DEBUG_TOOLS_FLIP_SET_READ"),
        ("DEF_METHOD(NV097, SET_FLIP_WRITE)", "XEMU_DEBUG_TOOLS_FLIP_SET_WRITE"),
        ("DEF_METHOD(NV097, SET_FLIP_MODULO)", "XEMU_DEBUG_TOOLS_FLIP_SET_MODULO"),
        ("DEF_METHOD(NV097, FLIP_INCREMENT_WRITE)", "XEMU_DEBUG_TOOLS_FLIP_INCREMENT_WRITE"),
        ("DEF_METHOD(NV097, FLIP_STALL)", "xemu_debug_tools_flip_stall_trace_begin(pg)"),
    ):
        require(pgraph, method, f"Xbox D3D/NV097 method {method}")
        require(pgraph, event, f"observation for {method}")
    require(pgraph, "XEMU_DEBUG_TOOLS_FLIP_VBLANK_READ_INCREMENT", "READ_3D increment observation")
    require(nv2a, "XEMU_DEBUG_TOOLS_FLIP_VBLANK_IRQ", "actual PCRTC VBlank observation")
    require(pfifo, "XEMU_DEBUG_TOOLS_FLIP_PFIFO_CHECK_STALL", "PFIFO stalled check")
    require(pfifo, "xemu_debug_tools_flip_stall_trace_end(&d->pgraph);", "PFIFO release observation")
    require(vk_draw, "finish_reason == VK_FINISH_REASON_FLIP_STALL", "Vulkan flip-finish filter")
    require(vk_draw, "XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_BEGIN", "Vulkan finish begin")
    require(vk_draw, "XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_END", "Vulkan finish end")

    for core in (pgraph, pfifo, nv2a, vk_draw):
        for leaked in ("FlipStallTraceRing", "overwritten_events", "active_stall_start_host_ns"):
            forbid(core, leaked, "Diagnostics recorder implementation in NV2A core")

    require(meson, "'addons/diagnostics/flip-stall-trace.c',", "full-profile flip recorder")
    require(meson, "'addons/stubs/flip-stall-trace-stub.c',", "non-full flip stub")
    require(backend_h, "XemuDiagnosticsFlipStallEvent", "frontend-safe flip ABI")
    require(ui, '"FLIP_STALL / VBlank Investigator"', "live investigator UI")
    require(ui, '"FLIP_STALL / VBlank Trace\\n', "snapshot trace section")
    require(ui, "XEMU Diagnostics Snapshot v3.09", "v3.09 snapshot format")
    require(ui, 'AddEvent(now_ms, "FLIP", os.str());', "flip Recent Events")
    require(ui, "kActiveWarningNs = 100ULL", "100 ms active stall warning")

    stub_text = stub.read_text(encoding="utf-8")
    require(stub_text, "xemu_debug_tools_flip_stall_trace_record", "disabled-profile record stub")
    require(stub_text, "xemu_debug_tools_flip_stall_trace_begin", "disabled-profile begin stub")
    require(stub_text, "xemu_debug_tools_flip_stall_trace_end", "disabled-profile end stub")
    forbid(stub_text, "qemu_", "runtime dependency in disabled-profile flip stub")

    print("PASS: v3.09 FLIP_STALL/VBlank investigator ownership and instrumentation contract")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
