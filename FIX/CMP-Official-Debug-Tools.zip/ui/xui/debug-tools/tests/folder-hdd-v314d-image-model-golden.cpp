#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace {
constexpr std::uint64_t kCStart = 0x8CA80000ULL;
constexpr std::uint64_t kCSize  = 0x01F400000ULL;
constexpr std::uint64_t kEStart = 0xABE80000ULL;
constexpr std::uint64_t kESize  = 0x1312D6000ULL;
constexpr std::uint64_t kCacheStart = 0x00080000ULL;
constexpr std::uint64_t kCacheEnd   = 0x8CA80000ULL;
constexpr std::size_t kSector = 512;

struct RouteCounts {
    std::size_t c = 0;
    std::size_t e = 0;
    std::size_t cache = 0;
    std::size_t residual_overlay = 0;
};

RouteCounts RouteWrite(std::uint64_t offset, std::size_t bytes) {
    RouteCounts r;
    std::uint64_t pos = offset;
    const std::uint64_t end = offset + bytes;
    while (pos < end) {
        if (pos >= kCStart && pos < kCStart + kCSize) {
            auto n = static_cast<std::size_t>(std::min<std::uint64_t>(end - pos, kCStart + kCSize - pos));
            r.c += n; pos += n; continue;
        }
        if (pos >= kEStart && pos < kEStart + kESize) {
            auto n = static_cast<std::size_t>(std::min<std::uint64_t>(end - pos, kEStart + kESize - pos));
            r.e += n; pos += n; continue;
        }
        if (pos >= kCacheStart && pos < kCacheEnd) {
            auto n = static_cast<std::size_t>(std::min<std::uint64_t>(end - pos, kCacheEnd - pos));
            r.cache += n; pos += n; continue;
        }
        std::uint64_t next = end;
        if (pos < kCacheStart) next = std::min(next, kCacheStart);
        if (pos < kCStart) next = std::min(next, kCStart);
        const auto n = static_cast<std::size_t>(next - pos);
        assert(n != 0);
        r.residual_overlay += n; pos += n;
    }
    return r;
}

struct PersistentState {
    bool manifest = false;
    bool host_changed = false;
    bool image_dirty = false;
};

enum class RecoveryAction { FirstCreate, Clean, ExportImage, ImportHost, Conflict, UnsafePair };
RecoveryAction DecideOpen(const PersistentState &s, unsigned created_mask) {
    if (!s.manifest) return created_mask == 3u ? RecoveryAction::FirstCreate : RecoveryAction::UnsafePair;
    if (s.image_dirty && s.host_changed) return RecoveryAction::Conflict;
    if (s.image_dirty) return RecoveryAction::ExportImage;
    if (s.host_changed) return RecoveryAction::ImportHost;
    return RecoveryAction::Clean;
}

struct Hint { std::uint32_t first; std::uint32_t count; bool dir; };
std::pair<std::uint32_t,std::uint32_t> Assign(std::uint32_t needed, bool dir,
                                               const Hint *hint,
                                               std::uint32_t &next) {
    if (!needed) return {0,0};
    if (hint && hint->dir == dir && hint->first > 0 && hint->count >= needed) {
        next = std::max(next, hint->first + hint->count);
        return {hint->first, hint->count};
    }
    const auto first = std::max<std::uint32_t>(1, next);
    next = first + needed;
    return {first, needed};
}

struct MirrorPair {
    std::map<std::string,std::string> image;
    std::map<std::string,std::string> host;
    std::map<std::string,std::string> baseline;
    bool dirty = false;

    void xbox_write(const std::string &p, std::string v) { image[p] = std::move(v); dirty = true; }
    bool export_to_host() {
        // Existing baseline paths modified independently on host remain a conflict.
        for (const auto &[p, oldv] : baseline) {
            auto h = host.find(p);
            if (h == host.end() || h->second != oldv) return false;
        }
        // Preserve host-only additions, then export image values.
        auto additions = host;
        for (const auto &[p,v] : image) host[p] = v;
        for (const auto &[p,v] : additions) if (!baseline.count(p) && !image.count(p)) host[p] = v;
        // Import preserved host additions into image before convergence.
        for (const auto &[p,v] : host) if (!image.count(p)) image[p] = v;
        baseline = host;
        dirty = false;
        return true;
    }
};
}

int main() {
    // Exact partition routing: C/E go to their images, X/Y/Z range stays cache,
    // and only non-partition residual disk sectors use the session overlay.
    {
        auto r = RouteWrite(kCStart, 4 * kSector);
        assert(r.c == 4 * kSector && r.e == 0 && r.cache == 0 && r.residual_overlay == 0);
        r = RouteWrite(kEStart + 7*kSector, 3*kSector);
        assert(r.e == 3*kSector && r.c == 0 && r.cache == 0 && r.residual_overlay == 0);
        r = RouteWrite(kCacheStart, 2*kSector);
        assert(r.cache == 2*kSector && r.c == 0 && r.e == 0 && r.residual_overlay == 0);
        r = RouteWrite(0, kSector);
        assert(r.residual_overlay == kSector);
    }

    // Cross-session decision table must never silently choose a side when both
    // image and mirror changed after the last convergence.
    assert(DecideOpen({false,false,false}, 3u) == RecoveryAction::FirstCreate);
    assert(DecideOpen({false,false,false}, 0u) == RecoveryAction::UnsafePair);
    assert(DecideOpen({true,false,false}, 0u) == RecoveryAction::Clean);
    assert(DecideOpen({true,false,true}, 0u) == RecoveryAction::ExportImage);
    assert(DecideOpen({true,true,false}, 0u) == RecoveryAction::ImportHost);
    assert(DecideOpen({true,true,true}, 0u) == RecoveryAction::Conflict);

    // Rebuilds preserve an existing allocation when the old chain still fits.
    {
        std::uint32_t next = 100;
        Hint h{20, 4, false};
        auto [first,count] = Assign(3, false, &h, next);
        assert(first == 20 && count == 4 && next == 100);
        auto grown = Assign(5, false, &h, next);
        assert(grown.first == 100 && grown.second == 5 && next == 105);
    }

    // Unrelated PC additions survive Xbox->host export and are folded back into
    // the authoritative image before the state is called converged.
    {
        MirrorPair m;
        m.image = m.host = m.baseline = {{"E/Save.dat", "A"}};
        m.xbox_write("E/Save.dat", "B");
        m.host["E/New.ini"] = "PC";
        assert(m.export_to_host());
        assert(m.host.at("E/Save.dat") == "B");
        assert(m.host.at("E/New.ini") == "PC");
        assert(m.image.at("E/New.ini") == "PC");
        assert(!m.dirty && m.baseline == m.host);
    }

    // Existing-file simultaneous edits remain protected.
    {
        MirrorPair m;
        m.image = m.host = m.baseline = {{"E/Save.dat", "A"}};
        m.xbox_write("E/Save.dat", "Xbox");
        m.host["E/Save.dat"] = "PC";
        assert(!m.export_to_host());
        assert(m.host.at("E/Save.dat") == "PC");
        assert(m.image.at("E/Save.dat") == "Xbox");
        assert(m.dirty);
    }

    std::cout << "PASS: v3.14d image-backed C/E synchronization model\n";
    return 0;
}
