#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.10 Xbox scheduler / thread-wake investigator integration guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    diag = debug / "addons/diagnostics"

    for rel in (
        "scheduler-trace-hook.h",
        "scheduler-trace.h",
        "scheduler-trace.c",
    ):
        if not (diag / rel).is_file():
            raise AssertionError(f"missing v3.10 Diagnostics file: {rel}")
    stub = debug / "addons/stubs/scheduler-trace-stub.c"
    if not stub.is_file():
        raise AssertionError("missing v3.10 disabled-profile scheduler stub")

    hook_files = set()
    for top in (root / "hw", root / "ui"):
        for path in top.rglob("*"):
            if not path.is_file() or "debug-tools" in path.parts:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if ("scheduler-trace-hook.h" in text or
                    "xemu_debug_tools_scheduler_trace_note_irq" in text):
                hook_files.add(path.relative_to(root).as_posix())
    expected_hooks = {
        "hw/usb/hcd-ohci.c",
        "hw/xbox/nv2a/nv2a.c",
        "hw/xbox/nv2a/ptimer.c",
    }
    if hook_files != expected_hooks:
        raise AssertionError(
            f"scheduler wake external hook surface changed: {sorted(hook_files)}"
        )

    hook = (diag / "scheduler-trace-hook.h").read_text(encoding="utf-8")
    impl = (diag / "scheduler-trace.c").read_text(encoding="utf-8")
    api = (diag / "scheduler-trace.h").read_text(encoding="utf-8")
    backend_h = (diag / "diagnostics-backend.h").read_text(encoding="utf-8")
    ui = (diag / "diagnostics.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    nv2a = (root / "hw/xbox/nv2a/nv2a.c").read_text(encoding="utf-8")
    ptimer = (root / "hw/xbox/nv2a/ptimer.c").read_text(encoding="utf-8")
    ohci = (root / "hw/usb/hcd-ohci.c").read_text(encoding="utf-8")

    for source in (
        "XEMU_DEBUG_TOOLS_SCHED_WAKE_PCRTC_VBLANK",
        "XEMU_DEBUG_TOOLS_SCHED_WAKE_PTIMER",
        "XEMU_DEBUG_TOOLS_SCHED_WAKE_PGRAPH",
        "XEMU_DEBUG_TOOLS_SCHED_WAKE_PFIFO",
        "XEMU_DEBUG_TOOLS_SCHED_WAKE_OHCI",
    ):
        require(hook, source, f"wake source {source}")
    forbid(hook, "QemuMutex", "recorder implementation in minimal hook contract")
    forbid(hook, "CPUState", "CPU implementation in minimal hook contract")

    require(api, "XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_START 0x8001B02Eu",
            "KiIdleLoop start")
    require(api, "XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_END   0x8001B04Fu",
            "KiIdleLoop end")
    require(api, "XEMU_DEBUG_TOOLS_SCHED_IDLE_CHECKPOINT",
            "idle checkpoint event")
    require(api, "XEMU_DEBUG_TOOLS_SCHED_TITLE_RETURN",
            "title return event")
    require(impl, "cpu->cc->get_pc(cpu)", "lightweight guest-PC sampling")
    require(impl, "host_ns - g_scheduler_trace.last_sample_host_ns < 5000000ULL",
            "sample rate limiter")
    require(impl, '#include "system/hw_accel.h"',
            "cpu_synchronize_state declaration")
    require(impl, "cpu_synchronize_state(cpu);",
            "retained-event architectural sync")
    require(impl, "event->ebx + 0x28u", "KiIdleLoop EBX+28 scheduler slot")
    require(impl, "event->ebx + 0x2Cu", "KiIdleLoop EBX+2C scheduler slot")
    require(impl, "100000000ULL", "100 ms idle checkpoint")
    require(impl, "250000000ULL", "250 ms idle checkpoint")
    require(impl, "500000000ULL", "500 ms idle checkpoint")
    require(impl, "1000000000ULL", "1 second idle checkpoint")
    require(impl, "idle_vblank_count", "VBlank activity count")
    require(impl, "idle_ptimer_count", "PTIMER activity count")
    require(impl, "idle_ohci_count", "OHCI activity count")

    require(nv2a, "XEMU_DEBUG_TOOLS_SCHED_WAKE_PCRTC_VBLANK",
            "PCRTC VBlank wake observation")
    require(nv2a, "XEMU_DEBUG_TOOLS_SCHED_WAKE_PGRAPH",
            "PGRAPH wake observation")
    require(nv2a, "XEMU_DEBUG_TOOLS_SCHED_WAKE_PFIFO",
            "PFIFO wake observation")
    require(ptimer, "XEMU_DEBUG_TOOLS_SCHED_WAKE_PTIMER",
            "PTIMER alarm wake observation")
    require(ohci, "XEMU_DEBUG_TOOLS_SCHED_WAKE_OHCI",
            "OHCI wake observation")
    for core in (nv2a, ptimer, ohci):
        forbid(core, "XemuDebugToolsSchedulerTraceRing",
               "Diagnostics scheduler storage in emulator core")
        forbid(core, "IDLE_CHECKPOINT", "scheduler policy in emulator core")

    require(meson, "'addons/diagnostics/scheduler-trace.c',",
            "full-profile scheduler recorder")
    require(meson, "'addons/stubs/scheduler-trace-stub.c',",
            "non-full scheduler stub")
    require(backend_h, "XemuDiagnosticsSchedulerTraceEvent",
            "frontend-safe scheduler ABI")
    require(ui, '"Xbox Scheduler / Thread Wake Investigator"',
            "live scheduler investigator UI")
    require(ui, '"Xbox Scheduler / Thread Wake Trace\\n',
            "scheduler snapshot section")
    require(ui, "XEMU Diagnostics Snapshot v3.09", "v3.09 snapshot format")
    require(ui, "xemu_diagnostics_scheduler_trace_sample();",
            "per-Debug-Tools-tick lightweight sample")
    tick_pos = ui.index("xemu_diagnostics_scheduler_trace_sample();")
    early_return_pos = ui.index("if (!is_open && !m_auto_save", tick_pos)
    if tick_pos > early_return_pos:
        raise AssertionError("scheduler sample must run before closed-window early return")
    require(ui, 'AddEvent(now_ms, "Scheduler", os.str());',
            "scheduler Recent Events")
    require(ui, "kIdleWarningNs = 1000ULL", ">=1 second idle warning")

    stub_text = stub.read_text(encoding="utf-8")
    require(stub_text, "xemu_debug_tools_scheduler_trace_note_irq",
            "disabled-profile scheduler hook stub")
    forbid(stub_text, "qemu_", "runtime dependency in disabled-profile scheduler stub")

    print("PASS: v3.10 Xbox scheduler/thread-wake investigator ownership and instrumentation contract")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
