#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[4]
dt = root / "ui/xui/debug-tools"
vr = dt / "addons/Video-Recorder"
errors = []

def require(path, needle):
    text = path.read_text(encoding="utf-8")
    if needle not in text:
        errors.append(f"{path.relative_to(root)} missing {needle!r}")

def forbid(path, needle):
    text = path.read_text(encoding="utf-8")
    if needle in text:
        errors.append(f"{path.relative_to(root)} unexpectedly contains {needle!r}")

for name in ("README.md", "video-recorder-c.h", "video-recorder.hh",
             "video-recorder.cc", "video-recorder-ui.hh", "video-recorder-ui.cc",
             "video-recorder-platform.h", "video-recorder-linux.cc",
             "video-recorder-macos.m"):
    if not (vr / name).exists():
        errors.append(f"missing {(vr / name).relative_to(root)}")

# Complete implementation belongs to the addon, not ui/xui root.
for name in ("video-recorder-c.h", "video-recorder.hh", "video-recorder.cc",
             "video-recorder-platform.h", "video-recorder-linux.cc",
             "video-recorder-macos.m"):
    if (root / "ui/xui" / name).exists():
        errors.append(f"legacy root implementation still present: ui/xui/{name}")

require(dt / "meson.build", "addons/Video-Recorder/video-recorder.cc")
require(dt / "meson.build", "addons/Video-Recorder/video-recorder-ui.cc")
require(dt / "meson.build", "addons/Video-Recorder/video-recorder-linux.cc")
require(dt / "meson.build", "addons/Video-Recorder/video-recorder-macos.m")
require(dt / "meson.build", "libavcodec")
require(dt / "meson.build", "AVFoundation")

ui = vr / "video-recorder-ui.cc"
require(ui, "Video Recording")
require(ui, "Start Recording")
require(ui, "Format / Quality")
for label in ("H.264 - High Quality", "H.264 - Standard",
              "H.264 - Small File", "Lossless AVI/PNG"):
    require(ui, label)
require(ui, "Add Active Codes Panel")
require(ui, "Code Panel Position")
require(ui, '"Right\\0Left\\0"')
require(ui, "Recording Audio Volume")
require(root / "ui/xui/main-menu.cc", "cmp_video_recorder_draw_settings()")
forbid(root / "ui/xui/main-menu.cc", 'SectionTitle("Video Recording")')

cc = vr / "video-recorder.cc"
require(cc, 'MFCreateSinkWriterFromURL')
require(cc, 'MFVideoFormat_H264')
require(cc, 'MFAudioFormat_AAC')
require(cc, 'WriteFourCC(m_file, "MPNG")')
require(cc, 'WriteFourCC(m_file, "01wb")')
require(cc, 'WriteFourCC(m_file, "idx1")')
require(cc, '"ACTIVE CODES"')
require(cc, '"Credits: "')
require(cc, "std::vector<std::string> groups")
require(cc, 'g_build_filename(base_dir, "Videos", nullptr)')
require(cc, "g_mkdir_with_parents")
require(cc, "SDL_GetBasePath")
require(cc, "xemu_video_recorder_capture")
require(vr / "video-recorder-c.h", "xemu_video_recorder_toggle")
require(vr / "video-recorder-c.h", "xemu_video_recorder_submit_audio")
require(vr / "video-recorder-c.h", "xemu_video_recorder_capture")
require(vr / "video-recorder-platform.h", "xemu_platform_video_recorder_create")
require(vr / "video-recorder-linux.cc", 'avcodec_find_encoder_by_name("libx264")')
require(vr / "video-recorder-linux.cc", "AV_CODEC_ID_AAC")
require(vr / "video-recorder-macos.m", "AVAssetWriter")
require(vr / "video-recorder-macos.m", "AVVideoCodecTypeH264")
require(root / "ui/xemu.c", "SDL_SCANCODE_F9")
require(root / "ui/xemu.c", "xemu_video_recorder_toggle")
require(root / "hw/xbox/mcpx/apu/monitor.c", "xemu_video_recorder_submit_audio")
require(root / "hw/xbox/mcpx/apu/monitor.c", "video_recording.audio_gain")
require(root / "ui/xui/main.cc", "xemu_video_recorder_capture")
require(root / "config_spec.yml", "video_recording:")
require(root / "config_spec.yml", "audio_gain:")
require(root / "debian/control", "libavcodec-dev")
require(dt / "debug-tools.hh", "debug_tools_get_active_cheat_details")
require(dt / "addons/stubs/debug-tools-core-stub.cc", "debug_tools_cheat_overlay_available() { return false; }")

if errors:
    print("FAIL: Video Recorder addon golden")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("PASS: Video Recorder addon golden")
