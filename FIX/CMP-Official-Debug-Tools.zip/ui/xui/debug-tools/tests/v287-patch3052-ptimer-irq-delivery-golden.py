#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")

header = (DIAG / "ptimer-irq-delivery-trace.h").read_text(encoding="utf-8")
source = (DIAG / "ptimer-irq-delivery-trace.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
guest = (DIAG / "guest-timer-deadline-trace.c").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")
stub = (DT / "addons/stubs/ptimer-irq-delivery-trace-stub.c").read_text(encoding="utf-8")
ptimer = (ROOT / "hw/xbox/nv2a/ptimer.c").read_text(encoding="utf-8")
nv2a = (ROOT / "hw/xbox/nv2a/nv2a.c").read_text(encoding="utf-8")
pci = (ROOT / "hw/xbox/xbox_pci.c").read_text(encoding="utf-8")
x86 = (ROOT / "hw/i386/x86-cpu.c").read_text(encoding="utf-8")
tcg = (ROOT / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")
seg = (ROOT / "target/i386/tcg/system/seg_helper.c").read_text(encoding="utf-8")

require(header, "PTIMER_IRQ_DELIVERY_SLOW_NS (2 * 1000 * 1000ULL)", "2 ms capture threshold")
require(header, "PTIMER_IRQ_DELIVERY_OVERDUE_NS (5 * 1000 * 1000ULL)", "5 ms overdue marker")
require(header, "PTIMER_IRQ_DELIVERY_SAMPLE_NS (50 * 1000ULL)", "50 us TCG sample interval")
require(header, "PTIMER_IRQ_DELIVERY_CAPTURE_COUNT 4", "four pinned slow windows")
for name in ("GUEST_IF_MASKED", "IRQ_INHIBITED", "CPU_HARD_MISSING", "TCG_NOT_TAKEN", "HARD_TAKEN_DURING_WINDOW"):
    require(header, name, f"classification {name}")
require(source, "CPU_INTERRUPT_HARD", "CPU HARD observation")
require(source, "env->eflags & IF_MASK", "guest IF observation")
require(source, "HF_INHIBIT_IRQ_MASK", "interrupt inhibition observation")
require(source, "CF_NOIRQ", "TCG noirq observation")
require(source, "hard_eligible", "hard interrupt eligibility")
require(source, "XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_BUDGET", "bounded sampling")
require(source, "delivery_classify", "classification logic")
require(backend_h, "XemuDiagnosticsPtimerIrqDeliverySnapshot", "backend snapshot type")
require(backend_c, "xemu_debug_tools_ptimer_irq_delivery_trace_snapshot", "backend snapshot bridge")
require(meson, "addons/diagnostics/ptimer-irq-delivery-trace.c", "full diagnostics source")
require(meson, "addons/stubs/ptimer-irq-delivery-trace-stub.c", "non-diagnostics stub")
require(stub, "xemu_debug_tools_ptimer_irq_delivery_trace_active", "stub active API")

require(ptimer, "xemu_debug_tools_ptimer_irq_delivery_note_set", "PTIMER assertion hook")
require(ptimer, "xemu_debug_tools_ptimer_irq_delivery_note_clear", "PTIMER service hook")
require(nv2a, "xemu_debug_tools_ptimer_irq_delivery_note_nv2a_line", "NV2A PCI line hook")
require(pci, "xemu_debug_tools_ptimer_irq_delivery_note_pci_route", "Xbox PCI/PIC route hook")
require(x86, "xemu_debug_tools_ptimer_irq_delivery_note_pic_cpu_line", "PIC-to-CPU line hook")
require(tcg, "xemu_debug_tools_ptimer_irq_delivery_note_tcg_check(cpu);", "TCG interrupt-check hook")
require(seg, "xemu_debug_tools_ptimer_irq_delivery_note_tcg_take", "TCG hard-take hook")

require(guest, "!xemu_debug_tools_ptimer_irq_delivery_trace_active()", "305.1 dispatcher single-step suppression")
require(ui, "PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)", "new diagnostics section")
require(ui, "Record PTIMER -> PIC -> TCG interrupt delivery", "new recording toggle")
require(ui, "Patch3051 dispatcher single-step suppressed", "snapshot disclosure")
require(ui, "xemu_diagnostics_ptimer_irq_delivery_trace_set_enabled(value);", "Check All includes 305.2")
require(ui, "xemu_diagnostics_ptimer_irq_latency_trace_set_enabled(value);", "Check All includes legacy PTIMER IRQ latency")
require(ui, "xemu_diagnostics_pgraph_increment_trace_set_enabled(value);", "Check All includes PGRAPH increment")
require(ui, "m_view.SetAll(true);", "Select All includes 305.2 export")

forbid(source, "timer_mod(", "timer modification")
forbid(source, "cpu_interrupt(", "interrupt injection")
forbid(source, "cpu_reset_interrupt(", "interrupt reset")
forbid(source, "cpu_memory_rw_debug", "guest memory access")
forbid(source, "vm_stop", "guest pause")

print("PASS: Patch 305.2 PTIMER IRQ delivery / interrupt-mask trace")
