#!/usr/bin/env python3
"""v3.14u universal merged-label guest-PC resolver/source guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"forbidden {label}: {needle}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = pathlib.Path(args.root)
    debug = root / "ui/xui/debug-tools"

    labels_h = (debug / "xbe-labels.hh").read_text(encoding="utf-8")
    labels_cc = (debug / "xbe-labels.cc").read_text(encoding="utf-8")
    diag = (debug / "addons/diagnostics/diagnostics.cc").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-labels.cc").read_text(encoding="utf-8")

    require(labels_h, "struct ResolvedAddress", "shared resolved-address model")
    require(labels_h, "bool ResolveAddress(const Database &database, uint32_t address,",
            "shared address resolver declaration")
    require(labels_h, "std::string FormatAddress(const Database &database, uint32_t address,",
            "shared address formatter declaration")
    require(labels_cc, "static uint32_t max_offset_for_label(const Label &label)",
            "source/type-aware function-offset resolution")
    require(labels_cc, "constexpr uint32_t kMaxTrustedOffset = 0x2000u;",
            "bounded backward resolver scan")
    require(labels_cc, "same_section_for_address(db, *it, address)",
            "same-section function-offset guard")
    require(labels_cc, "label.type == Type::Function",
            "function offset source/type policy")
    require(labels_cc, "const int candidate_type = type_priority(candidate.type);",
            "resolver reuses existing label type priority")
    require(labels_cc, "case Type::Symbol: return 2;",
            "exact symbol fallback support")

    require(diag, "XemuXbeLabels::FormatAddress(current_game_manager.Labels(),",
            "Diagnostics uses active merged label database")
    require(diag, "FormatGuestPc(last.hot_pc[rank])",
            "latest PGRAPH hotspot label resolution")
    require(diag, "FormatGuestPc(e.hot_pc[0])",
            "PGRAPH hotspot table label resolution")
    require(diag, "Resolved hot PC labels:",
            "snapshot resolved-hot-PC dictionary")
    require(diag, "Recorder hooks and raw event columns remain address-only.",
            "raw recorder/export ownership contract")
    require(diag, "Guest-PC label database:",
            "snapshot label database status")
    require(diag, "XDK label status: build ",
            "snapshot XDK match status")
    require(diag, "Guest-PC labels            %zu total | XDK %zu exact%s",
            "live Diagnostics label status")

    # v3.14u must remain a consumer of the existing label pipeline.  It must not
    # grow a title-specific/XDK-specific address table in Diagnostics.
    helper_start = diag.index("std::string FormatGuestPc(uint64_t pc)")
    helper_end = diag.index("size_t DiagnosticsBufferCapacity", helper_start)
    helpers = diag[helper_start:helper_end]
    forbid(helpers, "45410049", "Def Jam Title ID in resolver helpers")
    forbid(helpers, "0x0021", "Def Jam address in resolver helpers")
    forbid(helpers, "XemuXdkLabels::Process", "XDK importer inside Diagnostics")

    # The established standalone LABELS.txt exporter format is deliberately
    # untouched. It still exports the same seven columns in the same order.
    require(dump,
            'VIRTUAL    PHYSICAL   TYPE       SOURCE   CONFIDENCE  LOCATION                 LABEL\\n',
            "existing label dump header")
    require(dump,
            '"%08X   %08llX   %-10s %-8s %-11s %-24s %s\\n"',
            "existing mapped label row format")
    require(dump,
            '"%08X   UNMAPPED   %-10s %-8s %-11s %-24s %s\\n"',
            "existing unmapped label row format")

    print("PASS: v3.14u universal Diagnostics label resolver source guard")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
