#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.15 all-detached Debug Tools UI lock-isolation guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


def between(text: str, start: str, end: str) -> str:
    a = text.index(start)
    b = text.index(end, a)
    return text[a:b]


def function_tail(text: str, signature: str, next_signature: str | None = None) -> str:
    a = text.index(signature)
    if next_signature is None:
        return text[a:]
    b = text.index(next_signature, a)
    return text[a:b]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root)
    dt = root / "ui/xui/debug-tools"

    xemu_c = (root / "ui/xemu.c").read_text(encoding="utf-8")
    main_cc = (root / "ui/xui/main.cc").read_text(encoding="utf-8")
    detached_h = (dt / "detached-tools.hh").read_text(encoding="utf-8")
    detached_cc = (dt / "detached-tools.cc").read_text(encoding="utf-8")
    facade_h = (dt / "debug-tools.hh").read_text(encoding="utf-8")
    facade_cc = (dt / "debug-tools.cc").read_text(encoding="utf-8")
    memory = (dt / "cheat-engine-memory.c").read_text(encoding="utf-8")
    current_h = (dt / "current-game.hh").read_text(encoding="utf-8")
    current_cc = (dt / "current-game.cc").read_text(encoding="utf-8")
    current_ui = (dt / "current-game-ui.cc").read_text(encoding="utf-8")
    hdd_h = (dt / "addons/hdd/hdd-directory.hh").read_text(encoding="utf-8")
    hdd_cc = (dt / "addons/hdd/hdd-directory.cc").read_text(encoding="utf-8")
    hdd_ui = (dt / "addons/hdd/hdd-directory-ui.cc").read_text(encoding="utf-8")
    hdd_addon = (dt / "addons/hdd/debug-tools-hdd-addon.cc").read_text(encoding="utf-8")
    block_h = (dt / "disc-block-io.h").read_text(encoding="utf-8")
    block_c = (dt / "disc-block-io.c").read_text(encoding="utf-8")
    block_ref = (dt / "disc-block-ref.hh").read_text(encoding="utf-8")
    pause = (dt / "guest-pause-guard.cc").read_text(encoding="utf-8")
    hdd_snapshot = (dt / "addons/hdd/hdd-snapshot-service.cc").read_text(encoding="utf-8")
    hdd_export = (dt / "addons/hdd/hdd-export-service.cc").read_text(encoding="utf-8")
    disc_export = (dt / "xdvdfs-export-service.cc").read_text(encoding="utf-8")

    # All detached frame construction is after xemu_main_loop_unlock(), with no
    # legacy locked frame facade left in the synchronized HUD update.
    render = between(
        xemu_c,
        "static void gl_render_frame_common(struct xemu_console *scon, bool playback_only)",
        "static void gl_render_frame(struct xemu_console *scon)",
    )
    require(render, "xemu_main_loop_unlock();", "HUD lock release")
    require(render, "xemu_hud_build_detached_frames_unlocked();", "unlocked detached build")
    require(render, "xemu_hud_render();", "HUD render")
    if not (render.index("xemu_main_loop_unlock();") <
            render.index("xemu_hud_build_detached_frames_unlocked();") <
            render.index("xemu_hud_render();")):
        raise AssertionError("detached frames are not built after unlock and before render")
    forbid(main_cc, "debug_tools_build_locked_detached_frames", "locked detached build route")
    require(main_cc, "debug_tools_build_unlocked_detached_frames();", "single detached build route")
    forbid(facade_h, "debug_tools_build_locked_detached_frames", "locked facade declaration")
    forbid(facade_cc, "debug_tools_build_locked_detached_frames", "locked facade implementation")

    # v3.14's per-tool build lock policy is retired: every registered tool goes
    # through the same unlocked builder, while precreate remains an independent
    # first-open resource policy.
    forbid(detached_h, "build_outside_emulator_lock", "per-tool lock policy")
    forbid(detached_h, "trace_stage", "obsolete locked-build trace field")
    forbid(detached_cc, "ScopedLockedDetachedStage", "locked detached trace scope")
    forbid(detached_cc, "detached_tools_build_locked_frames", "locked detached host builder")
    unlocked = function_tail(detached_cc, "void detached_tools_build_unlocked_frames()",
                             "void detached_tools_render_frames()")
    require(unlocked, "for (DetachedToolWindow &tool : g_tools)", "all-tool unlocked loop")
    require(unlocked, "BuildToolFrame(tool);", "all-tool unlocked frame build")

    for title in (
        '"xemu - Current Game"',
        '"xemu - RAW Cheat Engine"',
        '"xemu - Xbox HDD Directory"',
        '"xemu - Memory Viewer / Search / x86 Debugger"',
        '"xemu - Diagnostics"',
    ):
        corpus = facade_cc + hdd_addon + (dt / "addons/memory-tools/debug-tools-memory-tools-addon.cc").read_text(encoding="utf-8") + (dt / "addons/diagnostics/debug-tools-diagnostics-addon.cc").read_text(encoding="utf-8")
        require(corpus, title, f"detached registration {title}")

    # Live guest access is self-synchronized at the bridge boundary instead of
    # relying on the complete ImGui frame to arrive with BQL already held.
    require(memory, '#include "qemu/main-loop.h"', "BQL bridge include")
    guarded_apis = (
        "xemu_cheat_cpu_available", "xemu_cheat_memory_read",
        "xemu_cheat_memory_write", "xemu_cheat_patch_virtual",
        "xemu_cheat_ram_size", "xemu_cheat_prepare_virtual_map",
        "xemu_cheat_virtual_to_physical", "xemu_cheat_collect_ram_virtual_mappings",
        "xemu_cheat_set_x86_register", "xemu_cheat_get_x86_registers",
        "xemu_cheat_get_x86_extra_registers", "xemu_cheat_breakpoint_insert",
        "xemu_cheat_breakpoint_remove", "xemu_cheat_watchpoint_insert",
        "xemu_cheat_watchpoint_remove", "xemu_cheat_single_step",
        "xemu_cheat_start_single_step",
    )
    for name in guarded_apis:
        pos = memory.index(name + "(")
        window = memory[pos:pos + 700]
        require(window, "BQL_LOCK_GUARD();", f"short BQL transaction in {name}")

    # Capstone formatting/decoding consumes a private page snapshot after the
    # snapshot helper's BQL scope has ended.
    snap = function_tail(memory, "static int xemu_cheat_snapshot_virtual_page(",
                         "int xemu_cheat_virtual_to_physical(")
    require(snap, "BQL_LOCK_GUARD();", "virtual page snapshot BQL guard")
    require(snap, "cpu_memory_rw_debug", "virtual page snapshot copy")
    paired = function_tail(memory, "int xemu_cheat_disassemble_paired(",
                           "int xemu_cheat_disassemble_page(")
    forbid(paired, "BQL_LOCK_GUARD();", "BQL held during paired Capstone decode")
    forbid(paired, "cpu_synchronize_state", "CPU sync during paired Capstone decode")
    page = function_tail(memory, "int xemu_cheat_disassemble_page(")
    require(page, "xemu_cheat_snapshot_virtual_page(", "page disassembly snapshot")
    forbid(page, "BQL_LOCK_GUARD();", "BQL held during page Capstone decode")

    # Current Game manual refresh is a request only; the synchronized tick owns
    # the actual Refresh() call.
    require(current_h, "void Tick();", "Current Game synchronized tick API")
    require(current_h, "void RequestRefresh();", "Current Game refresh request API")
    refresh_button = between(current_ui, 'if (ImGui::Button("Refresh Now"))', "ImGui::SameLine();")
    require(refresh_button, "RequestRefresh();", "queued Current Game refresh button")
    forbid(refresh_button, "Refresh(true);", "live Current Game refresh in detached draw")
    tick = function_tail(current_cc, "void CurrentGameManager::Tick()",
                         "void CurrentGameManager::RefreshRunningXbe")
    require(tick, "m_manual_refresh_requested", "Current Game request consume")
    require(tick, "Refresh(force);", "Current Game synchronized refresh")
    require(facade_cc, "current_game_manager.Tick();", "Current Game tick registration bridge")

    # HDD display refresh is deferred post-present. Long FATX/XDVDFS reads own a
    # retained BlockBackend and use QEMU's thread-safe block I/O API without BQL.
    require(hdd_h, "void ProcessDeferredActions();", "HDD deferred refresh API")
    stale = function_tail(hdd_cc, "void HddDirectoryWindow::RefreshIfStale()",
                          "void HddDirectoryWindow::ProcessDeferredActions()")
    require(stale, "m_refresh_requested = true;", "stale HDD refresh request")
    forbid(stale, "Refresh();", "HDD snapshot from draw stale check")
    deferred = function_tail(hdd_cc, "void HddDirectoryWindow::ProcessDeferredActions()",
                             "void HddDirectoryWindow::RequestExport")
    require(deferred, "Refresh();", "deferred HDD snapshot refresh")
    require(hdd_addon, "debug_tools_register_deferred_action(200, ProcessHddDeferredActions);",
            "HDD post-present deferred registration")
    for label in ('if (ImGui::Button("REFRESH HDD"))', 'if (ImGui::Button("REFRESH"))'):
        a = hdd_ui.index(label)
        button = hdd_ui[a:a + 140]
        require(button, "m_refresh_requested = true;", f"queued {label} action")
        forbid(button, "Refresh();", f"direct {label} snapshot")

    require(block_h, "xemu_disc_block_acquire_by_name", "retained BlockBackend acquire API")
    require(block_h, "xemu_disc_block_release", "retained BlockBackend release API")
    acquire = function_tail(block_c, "XemuDiscBlockHandle xemu_disc_block_acquire_by_name",
                            "void xemu_disc_block_release")
    require(acquire, "BQL_LOCK_GUARD();", "BlockBackend lookup/ref BQL guard")
    require(acquire, "blk_ref(blk);", "BlockBackend retained reference")
    release = function_tail(block_c, "void xemu_disc_block_release",
                            "bool xemu_disc_block_is_available")
    require(release, "BQL_LOCK_GUARD();", "BlockBackend unref BQL guard")
    require(release, "blk_unref", "BlockBackend release")
    require(block_ref, "class XemuDiscBlockRef", "BlockBackend RAII owner")
    for service, name in ((hdd_snapshot, "HDD snapshot"),
                          (hdd_export, "HDD export"),
                          (disc_export, "XDVDFS export")):
        require(service, "XemuDiscBlockRef", f"retained BlockBackend in {name}")

    # Pausing a guest for coherent snapshots no longer keeps BQL across the
    # caller's potentially long host-side copy/read work.
    ctor = function_tail(pause, "XemuDebugGuestPauseGuard::XemuDebugGuestPauseGuard()",
                         "XemuDebugGuestPauseGuard::~XemuDebugGuestPauseGuard()")
    require(ctor, "BQL_LOCK_GUARD();", "pause transition BQL guard")
    resume = function_tail(pause, "void XemuDebugGuestPauseGuard::Resume()")
    require(resume, "BQL_LOCK_GUARD();", "resume transition BQL guard")

    print("PASS: v3.15 all detached Debug Tools frames build unlocked with short synchronized guest transactions")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
