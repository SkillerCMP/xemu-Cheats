#!/usr/bin/env python3
"""v3.14ah Home -> Games library ownership, cleanup, and safety guards."""
from __future__ import annotations
import argparse
from pathlib import Path


def need(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    dt = root / "ui/xui/debug-tools"
    addon = dt / "addons/game-library"

    cc = (addon / "game-library.cc").read_text(encoding="utf-8")
    hh = (addon / "game-library.hh").read_text(encoding="utf-8")
    hook = (addon / "game-library-menu-hook.cc").read_text(encoding="utf-8")
    hook_h = (addon / "game-library-menu-hook.h").read_text(encoding="utf-8")
    stub = (dt / "addons/stubs/game-library-menu-hook-stub.cc").read_text(encoding="utf-8")
    meson = (dt / "meson.build").read_text(encoding="utf-8")
    core = (dt / "debug-tools.cc").read_text(encoding="utf-8")
    popup = (root / "ui/xui/popup-menu.cc").read_text(encoding="utf-8")
    vl = (root / "system/vl.c").read_text(encoding="utf-8")

    # Retired v3.14ae/af startup experiment must be physically gone.
    for retired in (
        addon / "game-library-boot-hook.cc",
        addon / "game-library-boot-hook.h",
        dt / "addons/stubs/game-library-boot-hook-stub.c",
        dt / "tests/game-library-boot-hook-golden.cpp",
    ):
        if retired.exists():
            raise AssertionError(f"retired startup-hook file still packaged: {retired}")
    for text, where in ((cc, "game-library.cc"), (hh, "game-library.hh"),
                        (meson, "meson.build"), (vl, "system/vl.c")):
        for token in ("StartupMode", "startup_mode", "startup_game",
                      "XEMU_GAME_LIBRARY_STARTUP",
                      "xemu_debug_tools_game_library_boot_dvd_path"):
            forbid(text, token, f"retired startup behavior in {where}")
    for token in ("Set as Startup Game", "Auto Boot Last Played Game",
                  "Auto Boot Selected Game", "Stock XEMU Configured Disc"):
        forbid(cc, token, "retired startup UI")

    # Full profile owns the implementation; all other profiles retain stock
    # Home -> Games behavior through a false-returning stub.
    need(meson, "debug_tools_with_game_library = (debug_tools_profile == 'full')",
         "full-profile selector")
    for name in (
        "addons/game-library/debug-tools-game-library-addon.cc",
        "addons/game-library/game-library.cc",
        "addons/game-library/game-library-menu-hook.cc",
        "addons/stubs/debug-tools-game-library-addon-stub.cc",
        "addons/stubs/game-library-menu-hook-stub.cc",
    ):
        need(meson, name, f"meson ownership {name}")
    need(core, "debug_tools_register_game_library_addition();", "module registration")
    need(stub, "return false;", "stock-profile availability fallback")

    # Patch 300 surface is now the existing Home -> Games popup only. XEMU's
    # startup/configured DVD path is untouched.
    include = '#include "debug-tools/addons/game-library/game-library-menu-hook.h"'
    if popup.count(include) != 1:
        raise AssertionError("popup-menu.cc must contain exactly one Game Library hook include")
    for token in (
        "xemu_debug_tools_game_library_menu_prepare()",
        "xemu_debug_tools_game_library_menu_count()",
        "xemu_debug_tools_game_library_menu_get_label(",
        "xemu_debug_tools_game_library_menu_launch(",
        "xemu_debug_tools_game_library_menu_open_full()",
        "xemu_debug_tools_game_library_menu_refresh()",
    ):
        need(popup, token, f"Home -> Games hook {token}")
    need(popup, "PopulateGameList();", "stock Games fallback")
    need(popup, "ActionLoadDiscFile(file_path.c_str());", "stock Games launch fallback")
    for token in ("game-library", "GameLibrary", "game_library"):
        forbid(vl, token, "Game Library startup hook in system/vl.c")

    # C ABI keeps popup-menu independent of the C++ library internals.
    for token in (
        "xemu_debug_tools_game_library_menu_available",
        "xemu_debug_tools_game_library_menu_prepare",
        "xemu_debug_tools_game_library_menu_count",
        "xemu_debug_tools_game_library_menu_get_label",
        "xemu_debug_tools_game_library_menu_launch",
        "xemu_debug_tools_game_library_menu_scanning",
        "xemu_debug_tools_game_library_menu_open_full",
        "xemu_debug_tools_game_library_menu_refresh",
    ):
        need(hook_h, token, f"menu hook ABI {token}")
        need(hook, token, f"full hook implementation {token}")

    # Register must not scan, read preferences, alter configured media, pause,
    # or open a UI at startup. Work begins only from an explicit menu/open action.
    register = cc[cc.index("void GameLibraryManager::Register()"):
                  cc.index("void GameLibraryManager::RequestScan()")]
    need(register, "is_open = false;", "closed startup state")
    need(register, "m_scan_requested = false;", "idle startup scan state")
    for token in ("LoadPreferences", "RequestScan", "xemu_load_disc", "vm_stop",
                  "xemu_settings_set_string"):
        forbid(register, token, "startup side effect")
    need(cc, "void GameLibraryManager::PrepareQuickMenu()", "Home menu prepare")
    need(cc, "void GameLibraryManager::OpenFullLibrary()", "full browser entry")
    need(cc, "void GameLibraryManager::Refresh()", "explicit refresh")

    # Scanning remains host-only and background queued.
    need(cc, "debug_tools_queue_background_job(", "background scan queue")
    need(cc, "ScanLibrary(*static_cast<ScanJob *>(opaque));", "worker scan")
    need(cc, "ApplyScanResult(", "scan completion")
    for token in ("xemu_main_loop_lock", "qemu_mutex_lock", "pgraph_vk_finish",
                  "vkWaitForFences"):
        forbid(cc, token, "emulator/GPU synchronization in Game Library addon")

    # Quick list prioritizes Favorites then Recent and is bounded for the popup.
    need(cc, "void GameLibraryManager::RebuildQuickMenu()", "quick menu cache")
    need(cc, "m_preferences.favorites.count(game.path)", "favorite priority")
    need(cc, "m_preferences.last_played_us.find(game.path)", "recent priority")
    need(cc, "kQuickMenuLimit = 12", "bounded Home menu")
    need(cc, 'label += "  [Favorite]";', "favorite quick label")

    # Recursive host discovery and read-only XDVDFS/default.xbe metadata.
    need(cc, "std::filesystem::recursive_directory_iterator", "recursive discovery")
    need(cc, 'ext == ".iso" || ext == ".xiso"', "disc extensions")
    need(cc, 'XemuXdvdfs::FindRootFile(disc, "default.xbe")', "default.xbe lookup")
    need(cc, '"XEMU-XBE-CODE-IDENTITY-V1"', "normalized executable identity domain")
    need(cc, "kMaxDiscImages = 8192", "bounded image scan")
    need(cc, "kMaxXbeHeaders = 4 * 1024 * 1024", "bounded XBE header read")

    # Full browser features remain, but no docking-branch-only ImGui API.
    forbid(cc, "ImGuiWindowFlags_NoDocking", "docking-only ImGui flag")
    for token in ('"All"', '"Favorites"', '"Recent"',
                  '"Search title / ID / path"', '"Add Library Root..."',
                  'name == "cover" || name == "folder" || name == stem_lower'):
        need(cc, token, f"library feature {token}")

    # Normal disc/reset path and pause only when the full browser explicitly opens.
    need(cc, "xemu_load_disc(game.path.c_str(), &error);", "normal disc mount")
    need(cc, "ActionReset();", "normal Xbox reset")
    open_block = cc[cc.index("void GameLibraryManager::OpenIfNeeded()"):
                    cc.index("void GameLibraryManager::Close(")]
    need(open_block, "vm_stop(RUN_STATE_PAUSED);", "full-browser pause")
    need(cc, "vm_start();", "resume/launch")

    # Legacy LastPlayed is migration-only; new saves no longer recreate Startup.
    need(cc, 'GetKeyString(key_file, "Startup", "LastPlayed")', "legacy history migration")
    need(cc, 'g_key_file_set_string(key_file, "History", "LastPlayed"',
         "new history persistence")
    forbid(cc, 'g_key_file_set_string(key_file, "Startup"', "recreating retired startup keys")

    print("PASS: v3.14ah Home -> Games library integration, startup cleanup and ownership guards")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
