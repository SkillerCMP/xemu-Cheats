#!/usr/bin/env python3
"""v3.14f generic File Replace / DVD overlay ownership and hook guard."""
from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[4])
args = parser.parse_args()
root = args.root.resolve()
addon = root / "ui/xui/debug-tools/addons/file-replace"
atapi = (root / "hw/ide/atapi.c").read_text(encoding="utf-8")
meson = (root / "ui/xui/debug-tools/meson.build").read_text(encoding="utf-8")
ui = (root / "ui/xui/debug-tools/cheat-engine-ui.cc").read_text(encoding="utf-8")
fr_ui = (addon / "file-replace-ui.cc").read_text(encoding="utf-8")
core = (addon / "file-replace.cc").read_text(encoding="utf-8")
overlay = (addon / "file-replace-disc-overlay.cc").read_text(encoding="utf-8")
overlay_hh = (addon / "file-replace-disc-overlay.hh").read_text(encoding="utf-8")

def need(text, token, label):
    if token not in text:
        raise SystemExit(f"FAIL: missing {label}: {token}")

def forbid(text, token, label):
    if token in text:
        raise SystemExit(f"FAIL: forbidden {label}: {token}")

for rel in (
    "file-replace.hh", "file-replace.cc", "file-replace-ui.cc",
    "file-replace-disc-overlay.h", "file-replace-disc-overlay.hh",
    "file-replace-disc-overlay.cc", "README.md",
):
    if not (addon / rel).is_file():
        raise SystemExit(f"FAIL: missing File Replace addon file: {rel}")

need(atapi, "file-replace-disc-overlay.h", "minimal ATAPI hook include")
if atapi.count("xemu_file_replace_pread(") != 2 or "xemu_file_replace_aio_preadv(" not in (root / "hw/ide/core.c").read_text():
    raise SystemExit("FAIL: ATAPI must cover both synchronous formats and IDE buffered asynchronous reads")
need(atapi, "(uintptr_t)blk_bs(s->blk)", "disc backend identity gate")
need(atapi, "(int64_t)s->lba << ATAPI_SECTOR_BITS", "absolute DVD byte offset")
need(meson, "addons/file-replace/file-replace.cc", "addon build ownership")
need(meson, "addons/stubs/file-replace-disc-overlay-stub.c", "non-main hook stub")
need(ui, 'ImGui::BeginTabItem("File Replace")', "Cheat Engine File Replace tab")
need(core, 'JoinPath(JoinPath(ExecutableDirectory(), "Cheats"),', "Cheats-owned runtime root")
need(core, '"File-Replacements"', "reserved File Replace subtree")
need(core, 'JoinPath(JoinPath(game_dir, "Files"), m_game_identity)', "exact identity folder")
need(core, 'return "UNAVAILABLE";', "exact-identity unavailable state")
need(core, 'entry.host_size > entry.reserved_size', "replacement size guard")
need((addon / "file-replace-compiler.cc").read_text(), '"Active File Replace ranges overlap:', "overlap rejection")
need(core, 'XemuXdvdfs::FindEntry', "existing XDVDFS resolver reuse")
need(core, 'xemu_disc_block_pread', "raw mounted-disc resolver reads")
need(overlay, "std::atomic_load_explicit", "immutable snapshot read path")
need(overlay, "PaddingMode::Zero", "zero fill")
need(overlay_hh, "Original", "original remainder support")

# The implementation must remain generic. Game-specific data belongs in manifests.
all_impl = "\n".join(p.read_text(encoding="utf-8") for p in addon.glob("*.cc"))
all_impl += "\n" + "\n".join(p.read_text(encoding="utf-8") for p in addon.glob("*.hh"))
for token in ("Soulcalibur", "root.olk", "2911D800", "NM0003", "Link-File972"):
    forbid(all_impl, token, "game-specific File Replace implementation")
    forbid(atapi, token, "game-specific upstream hook")

print("PASS: v3.14f generic File Replace / disc overlay ownership and hook guard")
