#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


header = (DIAG / "guest-timer-deadline-trace.h").read_text(encoding="utf-8")
source = (DIAG / "guest-timer-deadline-trace.c").read_text(encoding="utf-8")
capture_h = (DIAG / "d3d-callback-capture.h").read_text(encoding="utf-8")
capture_c = (DIAG / "d3d-callback-capture.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
ui_h = (DIAG / "diagnostics.hh").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")
cpu_exec = (ROOT / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")

# InputBuffer-linked callback lifecycle: keep Patch 303's exact-PC hook and
# add observation of D3D return, callback entry/return, and overdue detection.
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET 0x000D7EA0u", "D7EA0 callback target")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_GRACE_NS (5 * 1000 * 1000LL)", "5 ms overdue grace")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN", "schedule return event")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY", "callback entry event")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN", "callback return event")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE", "callback overdue event")
require(source, "event.ebp == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET", "schedule target comes from EBP")
require(source, "guest_timer_cycles_to_ns", "relative cycles to virtual due time")
require(source, "callback_schedule_return_pending", "D3D schedule return tracking")
require(source, "guest_pc >= 0x00216478u && guest_pc <= 0x0021647Fu", "schedule return landing window")
require(source, "guest_timer_read_u32(\n            cpu, event.esp, &callback_return_candidate)", "learn callback return PC from stack")
require(source, "guest_pc == callback_return_pc", "dynamic callback return observation")
require(source, "callback_overdue_fire_pending", "non-breaking watchdog handoff")
require(source, "xemu_debug_tools_d3d_callback_capture_note_overdue", "pinned overdue capture trigger")
require(source, "XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_LINK_MAX_AGE_NS", "InputBuffer schedule correlation gate")
forbid(source, "cpu_breakpoint", "breakpoint use")
forbid(source, "vm_stop", "guest pause")
forbid(source, "cpu_memory_rw_debug(cpu, address, bytes, sizeof(bytes), true)", "guest memory write")

# Patch 305 deliberately reuses Patch 303's TCG hook rather than adding another
# stock-xemu hook surface.
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_should_single_step", "existing Patch 303 TCG query")
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_note_pc", "existing Patch 303 exact-PC callback")

# Dedicated pinned forensic capture retains the exact callback-overdue context.
require(capture_h, "XEMU_DEBUG_TOOLS_D3D_CALLBACK_GRACE_NS XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_GRACE_NS", "shared grace constant")
for name in (
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_QTIMER_EVENTS",
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_BQL_EVENTS",
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_MAIN_LOOP_LOCK_EVENTS",
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_PGRAPH_EVENTS",
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_SCHEDULER_EVENTS",
    "XEMU_DEBUG_TOOLS_D3D_CALLBACK_GUEST_TIMER_EVENTS",
):
    require(capture_h, name, f"pinned tail {name}")
require(capture_c, "xemu_debug_tools_qemu_timer_trace_snapshot", "QEMU timer tail")
require(capture_c, "xemu_debug_tools_bql_trace_snapshot", "BQL tail")
require(capture_c, "xemu_debug_tools_main_loop_lock_trace_snapshot", "main-loop tail")
require(capture_c, "xemu_debug_tools_pgraph_lock_trace_snapshot", "PGRAPH tail")
require(capture_c, "xemu_debug_tools_scheduler_trace_snapshot", "scheduler tail")
require(capture_c, "xemu_debug_tools_guest_timer_deadline_trace_snapshot", "guest lifecycle tail")
require(capture_c, "capture_duration_host_ns", "observer-cost measurement")
forbid(capture_c, "vm_stop", "capture guest pause")
forbid(capture_c, "timer_mod", "timer behavior change")

# Build/backend/UI/export/check-all integration.
require(meson, "'addons/diagnostics/d3d-callback-capture.c'", "full diagnostics source")
require(backend_h, "XemuDiagnosticsD3dCallbackCaptureSnapshot", "backend capture alias")
require(backend_c, "xemu_diagnostics_get_d3d_callback_capture", "backend snapshot bridge")
require(ui_h, "m_export_d3d_callback_capture = true", "export toggle")
require(ui, "D3D InputBuffer Callback Dispatch Capture (pinned one-shot)", "UI/export title")
require(ui, "Arm D3D InputBuffer callback watchdog (+5 ms grace)", "watchdog checkbox")
require(ui, "Clear / Re-arm D3D Callback Capture", "re-arm control")
require(ui, "D7EA0 schedule / return", "lifecycle UI counters")
require(ui, "CALLBACK_OVERDUE", "event-name export")
require(ui, "Pinned Guest Timer / Deadline / Callback Events", "pinned lifecycle export")
require(ui, "xemu_diagnostics_d3d_callback_capture_set_enabled(value);", "Check All integration")
require(ui, "xemu_diagnostics_d3d_callback_capture_clear();", "Clear All integration")
require(ui, "D3D schedule return observed/raw EAX", "raw result export without semantic guess")

print("PASS: Patch 305 D3D InputBuffer callback dispatch watchdog")
