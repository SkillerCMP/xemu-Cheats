#!/usr/bin/env python3
"""v3.09 normalized Current Game identity + expanded XBE info guard."""
import argparse
import hashlib
import pathlib
import re


def require(text: str, needle: str, what: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {what}: {needle}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    current = (debug / "current-game.cc").read_text(encoding="utf-8")
    header = (debug / "current-game.hh").read_text(encoding="utf-8")
    ui = (debug / "current-game-ui.cc").read_text(encoding="utf-8")
    cheat = (debug / "cheat-engine-source.cc").read_text(encoding="utf-8")
    persist = (debug / "cheat-engine-persistence.cc").read_text(encoding="utf-8")
    labels_h = (debug / "label-packs.hh").read_text(encoding="utf-8")
    labels_cc = (debug / "label-packs.cc").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-dump.cc").read_text(encoding="utf-8")

    # Canonical identity must normalize both directly editable metadata fields,
    # plus the RSA signature that cryptographically depends on those bytes.
    for needle, what in (
        ("std::toupper(c)", "uppercase SHA-256 canonicalization"),
        ("0123456789ABCDEF", "uppercase XBE section SHA-1 formatting"),
        ("sha256_legacy_identity_headers", "legacy normalized identity helper"),
        ("offsetof(struct xbe_header, m_digsig)", "digital-signature normalization"),
        ("offsetof(struct xbe_certificate, m_title_name)", "Title Name normalization"),
        ("offsetof(struct xbe_certificate, m_game_region)", "Region normalization"),
        ("next.raw_header_sha256 = sha256_raw_headers(xbe);", "raw forensic hash"),
        ("next.legacy_header_sha256 = sha256_legacy_identity_headers(xbe);", "legacy normalized identity assignment"),
        ("next.header_sha256 = sha256_executable_identity(xbe);", "executable identity assignment"),
    ):
        require(current, needle, what)

    require(header, "std::string legacy_header_sha256;", "v3.09-v3.14d normalized hash storage")
    require(header, "std::string raw_header_sha256;", "legacy/raw hash storage")
    require(header, "std::vector<XbeSectionInfo> sections;", "section metadata")
    require(header, "std::vector<XbeLibraryInfo> libraries;", "library metadata")
    require(header, "uint32_t certificate_timestamp", "certificate metadata")
    require(header, "uint32_t entry_point", "decoded entry point")

    # Synthetic proof of the intended normalization relationship: changing
    # signature/title/region cannot change identity; changing Version still can.
    cert = 0x180
    base = bytearray((i * 37 + 11) & 0xFF for i in range(0x400))
    def normalized(src: bytearray) -> str:
        b = bytearray(src)
        b[0x004:0x104] = b"\0" * 0x100
        b[cert + 0x0C:cert + 0x5C] = b"\0" * 0x50
        b[cert + 0xA0:cert + 0xA4] = b"\0" * 4
        return hashlib.sha256(b).hexdigest().upper()
    variant = bytearray(base)
    variant[0x004:0x104] = bytes((x ^ 0xA5) for x in variant[0x004:0x104])
    variant[cert + 0x0C:cert + 0x5C] = b"N\0e\0w\0" + b"\0" * (0x50 - 6)
    variant[cert + 0xA0:cert + 0xA4] = (7).to_bytes(4, "little")
    if normalized(base) != normalized(variant):
        raise AssertionError("Title/Region/signature normalization is not invariant")
    revision = bytearray(variant)
    revision[cert + 0xAC:cert + 0xB0] = (2).to_bytes(4, "little")
    if normalized(base) == normalized(revision):
        raise AssertionError("Version/revision changes must remain identity-visible")

    # All advanced Current Game sections intentionally start collapsed: no
    # ImGuiTreeNodeFlags_DefaultOpen may be attached to these headers.
    for name in ("XBE", "Certificate", "Sections", "XDK", "Identity / Hashes", "Labels / Symbols"):
        require(ui, f'ImGui::CollapsingHeader("{name}")', f"collapsed {name} section")
    if "ImGuiTreeNodeFlags_DefaultOpen" in ui:
        raise AssertionError("Current Game advanced sections must be collapsed by default")
    for needle in (
        'ImGui::TextWrapped("Identity SHA-256',
        'ImGui::TextWrapped("Raw Header SHA-256',
        'ImGui::TableSetupColumn("SHA-1"',
        'ImGui::TableSetupColumn("Library"',
        'FormatAllowedMedia',
        'FormatSectionFlags',
    ):
        require(ui, needle, "expanded Current Game information")

    # The v3.09 normalized identity remains a read-only compatibility input
    # beneath the newer executable identity. Raw-header hashes remain older
    # compatibility input as well.
    require(cheat, "identity_hash_matches(header)", "canonical cheat matcher")
    require(cheat, "legacy_header_hash_matches(header)", "v3.09-v3.14d cheat compatibility")
    require(cheat, "legacy_raw_hash_matches(header)", "legacy raw cheat compatibility")
    require(cheat, "score += 512;", "canonical cheat preference")
    require(persist, "std::string identity_hash = game.header_sha256;", "canonical persistence filename")
    require(persist, 'root["version"] = 3;', "persistence identity version")
    require(persist, 'root["legacy_header_sha256"]', "persistence legacy normalized hash")
    require(persist, 'root["raw_header_sha256"]', "persistence forensic raw hash")
    require(persist, "LegacyNormalizedPersistencePath()", "normalized persistence restore")
    require(persist, "LegacyPersistencePath()", "older persistence restore")

    require(labels_h, "std::string legacy_header_sha256;", "normalized label-pack compatibility identity")
    require(labels_h, "std::string raw_header_sha256;", "legacy label-pack identity")
    require(labels_cc, "legacy_header_match", "normalized label-pack compatibility")
    require(labels_cc, "legacy_raw_match", "legacy raw label-pack compatibility")
    if "default.xbe SHA-256 does not match this revision" in labels_cc:
        raise AssertionError("full default.xbe hash still gates normalized label identity")

    require(dump, "game.header_sha256", "normalized dump filename")
    require(dump, "XBE Identity SHA-256", "dump canonical identity metadata")
    require(dump, "XBE Raw Header SHA-256", "dump raw forensic metadata")

    print("PASS: v3.09 normalized identity preserved as compatibility + Current Game detail guard")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
