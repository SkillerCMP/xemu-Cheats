#!/usr/bin/env python3
"""v3.14w PFIFO method-time breakdown observation-only source guard."""
from __future__ import annotations
import argparse, pathlib

def req(t,n,l):
    if n not in t: raise AssertionError(f"missing {l}: {n}")
def forbid(t,n,l):
    if n in t: raise AssertionError(f"forbidden {l}: {n}")
def between(t,a,b,l):
    try: return t[t.index(a):t.index(b,t.index(a)+len(a))]
    except ValueError as e: raise AssertionError(f"missing {l} bounds") from e

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); a=ap.parse_args()
    root=pathlib.Path(a.root); dbg=root/'ui/xui/debug-tools'; d=dbg/'addons/diagnostics'
    hook=(d/'pgraph-pusher-progress-trace-hook.h').read_text()
    h=(d/'pgraph-pusher-progress-trace.h').read_text()
    c=(d/'pgraph-pusher-progress-trace.c').read_text()
    stub=(dbg/'addons/stubs/pgraph-pusher-progress-trace-stub.c').read_text()
    ui=(d/'diagnostics.cc').read_text()
    pfifo=(root/'hw/xbox/nv2a/pfifo.c').read_text()
    pgraph=(root/'hw/xbox/nv2a/pgraph/pgraph.c').read_text()
    req(h,'XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT 8','top-8 contract')
    req(h,'XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS 5000000ULL','5ms long-run gate')
    req(h,'puller_dispatch_ns','puller bucket'); req(h,'parser_other_ns','parser bucket')
    req(h,'top_methods[XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT]','top method array')
    req(hook,'XemuDebugToolsPgraphPusherPullerScope','puller timing scope')
    req(hook,'xemu_debug_tools_pgraph_pusher_method_breakdown_note_method','method identity hook')
    req(c,'XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_WORK_CAPACITY 128','fixed working set')
    req(c,'g_method_work.pending_graphics_class != 0x97u','NV097 aggregation gate')
    req(c,'pusher_method_insert_top','top ranking')
    req(c,'event.parser_other_ns = event.duration_ns > event.puller_dispatch_ns','non-overlap bucket')
    req(stub,'xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin','non-diagnostics stub')
    req(ui,'Record PFIFO method-time breakdown','UI control')
    req(ui,'PFIFO Method-Time Breakdown','UI/export section')
    req(ui,'TOP ','exported top methods')
    # Integration: one pair around the existing puller call, identity-only in pgraph.
    pull=between(pfifo,'XemuDebugToolsPgraphPusherPullerScope','if (num_words_processed < 0)', 'puller timing block')
    req(pull,'xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin','puller begin')
    req(pull,'pfifo_run_puller(d, method_entry, word, word_ptr,','original puller call')
    req(pull,'xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end','puller end')
    if not (pull.index('puller_begin') < pull.index('pfifo_run_puller') < pull.index('puller_end')):
        raise AssertionError('puller timing must wrap existing call')
    meth=between(pgraph,'uint32_t graphics_class =','if (subchannel != 0)', 'pgraph identity block')
    req(meth,'pgraph_kelvin_methods','existing Kelvin method table')
    req(meth,'xemu_debug_tools_pgraph_pusher_method_breakdown_note_method','identity observation')
    forbid(meth,'qemu_clock_get_ns','pgraph identity hook must not add timer calls')
    universal='\n'.join([hook,h,c,stub,pull,meth])
    for x in ('45410049','0021ED87','0021EA70','81399000'):
        forbid(universal,x,'Def Jam-specific constant')
    print('PASS: v3.14w PFIFO method-time breakdown source guard')
    return 0
if __name__=='__main__': raise SystemExit(main())
