#!/usr/bin/env python3
"""Reject behavioral changes disguised as Vulkan draw-stage observation hooks."""
from __future__ import annotations
import argparse
import pathlib
from v314y_vulkan_observer_test_utils import (
    DRAW_PATH, EXPECTED_PRE_DRAW, check_vk_observation_only, function,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    source = (pathlib.Path(args.root) / DRAW_PATH).read_text()
    check_vk_observation_only(source)

    # Negative controls: the guard must reject the actual v3.14x ordering defect,
    # an assertion bypass, duplicate rendering, and side effects inside hooks.
    pre = function(source, 'static void begin_pre_draw(PGRAPHState *pg)')
    descriptor = '    if (!pg->clearing) {\n        pgraph_vk_update_descriptor_sets(pg);\n    }\n'
    fallback = '    if (r->framebuffer_index == 0) {\n        create_frame_buffer(pg);\n    }\n'
    assert descriptor + fallback in EXPECTED_PRE_DRAW
    wrong_order = EXPECTED_PRE_DRAW.replace(descriptor + fallback, fallback + descriptor)
    mutations = {
        'v3.14x descriptor/framebuffer reorder': source.replace(pre, wrong_order),
        'assertion bypass': source.replace('assert(r->framebuffer_index > 0);', ';'),
        'duplicate flush': source.replace('    pgraph_vk_flush_draw(d);',
                                         '    pgraph_vk_flush_draw(d); pgraph_vk_flush_draw(d);', 1),
        'side-effecting hook': source.replace(
            'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PRE_DRAW, pg, 0, 0',
            'XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PRE_DRAW, pg, r->framebuffer_index++, 0', 1),
    }
    for label, mutated in mutations.items():
        if mutated == source:
            raise AssertionError('Negative control did not mutate source: ' + label)
        try:
            check_vk_observation_only(mutated)
        except AssertionError:
            continue
        raise AssertionError('Guard incorrectly accepted: ' + label)
    print('PASS: v3.14y whole-file Vulkan renderer operation/token parity with v3.14w; '
          'four unsafe mutations rejected')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
