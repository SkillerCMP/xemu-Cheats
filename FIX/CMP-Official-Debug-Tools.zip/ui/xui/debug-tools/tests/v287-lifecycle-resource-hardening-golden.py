#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Regression guard for v1.95 OPT Pass 10 lifecycle/resource hardening."""
from __future__ import annotations

import argparse
import hashlib
import pathlib

from v287_source_test_utils import (
    V311_MEMORY_TOOLS_MUTABLE_METHODS,
    extract_function, extract_member_functions, read_cheat_engine_implementation,
    strip_preentry_cheat_header_additions, restore_cleanup_pass6_external_le32,
    restore_cleanup_pass8_memory_tools_timestamp_call,
)


PROTECTED_V194_FILES = {
    "cheat-engine-memory.c": "3baca8753b0aa7bbdae4693545e87d058d00d28795cf5f6a3682738afaf89460",
    "cheat-engine-memory.h": "e47bb779c456cc58bc3bd6e7852c1f72332af4c35d8d82f6195eb1e62bc79d90",
    "external-code-memory.c": "1c4be7e4aa84cce48137b73d9baf015e23be41e587e1fa2e45d6a0a187aac3a2",
    "addons/memory-tools/memory-tools.hh": "42df7062c462dd16bccd64fcaa7fe9b39de5808b6898ea89a975be84bfbeb847",
    "addons/memory-tools/memory-tools-inject.cc": "07ca236adbe9b879b69b0557cd11189e1deaa50e0509fb7525a82d418d9d4609",
    "backend/xemu-dbg.c": "0fff339f0c480f2654d8d8805820fae462cff11b85a1c7e11a23ca074429c1ef",
    "backend/whpx-debug.c": "7ba0d7e6d5efacf298ff07520c6bb40df7a947e925b8ef9c05f7e8cac8b66368",
}
CHEAT_HEADER_V194_SHA256 = "68b92ae21c2b0aca187aa38e79449fb60f5f936195cc31a11dd0e662a28c4817"
XEMU_XBE_V194_SHA256 = "ee4e589c703e0b0125e0837205245dda82ec5c37c7f027c30d71b1b0f6c16685"
CHEAT_REMAINING_V194_SHA256 = "2af60c9455c44228615b8ece7aea50684a665d4dead4bfe9e683ddf8a576a044"
MEMORY_REMAINING_V194_SHA256 = "f1c0753bb0e2de21efbfb64e9c7c205a5b873d149b27a45db3918a486b1019eb"

PREENTRY_SCOPED_CHEAT_METHODS = {
    "MaybeAutoLoadCurrentGame",
    "NotifyGameResetRequested",
    "ObserveRequestedGameReset",
    "BlockIdentityKey",
    "PreEntrySelectionKey",
    "IsPreEntrySelected",
    "RememberPreEntrySelection",
    "ApplySelectedPreEntryPatches",
    "ConsumePreEntryPrefix",
    "ParseSource",
    "LoadMatchingCurrentGameFile",
    "SetGroupSelected",
    "SetPatchGroupSelected",
    "DisableAllCheats",
    "DeactivateLiveFHooks",
    "ForgetFHookOwnershipForNewGuest",
    "CountGroupSelection",
    "CountPatchGroupSelection",
    "DrawCheat",
    "DrawPatch",
    "DrawGroup",
    "DrawPatchGroup",
    "Tick",
    "DrawMenuBar",
    "Draw",
}


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def member_digest(texts: list[str], class_name: str, excluded: set[str]) -> tuple[str, int]:
    digest = hashlib.sha256()
    count = 0
    for text in texts:
        for name, body in extract_member_functions(text, class_name):
            if name in excluded:
                continue
            digest.update(name.encode("utf-8"))
            digest.update(b"\0")
            digest.update(body.encode("utf-8"))
            digest.update(b"\0")
            count += 1
    return digest.hexdigest(), count



def member_digest_sorted(texts: list[str], class_name: str, excluded: set[str]) -> tuple[str, int]:
    records: list[tuple[str, str]] = []
    for text in texts:
        for name, body in extract_member_functions(text, class_name):
            if name in excluded:
                continue
            records.append((name, body))
    records.sort(key=lambda item: (item[0], item[1]))
    digest = hashlib.sha256()
    for name, body in records:
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(body.encode("utf-8"))
        digest.update(b"\0")
    return digest.hexdigest(), len(records)

def require(text: str, needle: str, what: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {what}: {needle}")



def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    root = pathlib.Path(parser.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    # The behavior-bearing bridges and every explicitly protected prior-pass
    # runtime file remain byte-identical to v1.94. The v2.74 Inject pair is
    # delegated to its exact dedicated fingerprint guard.
    v274_scoped_files = {
        "addons/memory-tools/memory-tools.hh", "addons/memory-tools/memory-tools-inject.cc",
        "cheat-engine-memory.h",  # v2.86 removes only a stale orphan comment.
    }
    v2919_trace_scoped_files = {
        "backend/xemu-dbg.c", "backend/whpx-debug.c",
    }
    v315_lock_isolation_scoped_files = {
        "cheat-engine-memory.c",
    }
    for rel, expected in PROTECTED_V194_FILES.items():
        if rel in v274_scoped_files or rel in v2919_trace_scoped_files or rel in v315_lock_isolation_scoped_files:
            continue
        if rel == "external-code-memory.c":
            data = (debug / rel).read_text(encoding="utf-8")
            actual = hashlib.sha256(restore_cleanup_pass6_external_le32(data).encode("utf-8")).hexdigest()
        else:
            actual = sha256(debug / rel)
        if actual != expected:
            raise AssertionError(f"protected v1.94 runtime file changed: {rel}")
    if sha256(root / "xemu-xbe.c") != XEMU_XBE_V194_SHA256:
        raise AssertionError("v1.90 XBE polling/scratch behavior changed")

    cheat_hh = (debug / "cheat-engine.hh").read_text(encoding="utf-8")
    stripped_hh = strip_preentry_cheat_header_additions(cheat_hh)
    if hashlib.sha256(stripped_hh.encode("utf-8")).hexdigest() != CHEAT_HEADER_V194_SHA256:
        raise AssertionError(
            "cheat-engine.hh changed outside the separately guarded PREENTRY/Patch scope"
        )

    cheat = read_cheat_engine_implementation(debug)
    guard = (debug / "guest-pause-guard.hh").read_text(encoding="utf-8")
    guard += "\n" + (debug / "guest-pause-guard.cc").read_text(encoding="utf-8")
    dump = (debug / "addons/memory-tools/memory-tools-dump.cc").read_text(encoding="utf-8")
    labels = (debug / "addons/memory-tools/memory-tools-labels.cc").read_text(encoding="utf-8")

    # Shared pause ownership: only the guard owns transactional start/stop
    # symmetry. It resumes exactly once and never resumes a guest that was
    # already stopped when the transaction began.
    for needle in (
        "m_was_running = runstate_is_running();",
        "const int stop_result = vm_stop(RUN_STATE_PAUSED);",
        "const bool stopped = !runstate_is_running();",
        "m_resume = stopped;",
        "m_valid = stop_result == 0 && stopped;",
        "~XemuDebugGuestPauseGuard()",
        "Resume();",
        "vm_start();",
        "m_resume = false;",
    ):
        require(guard, needle, "scoped guest pause contract")
    require(guard, "bool IsValid() const", "coherent-read pause validity API")
    require(guard, "BQL_LOCK_GUARD();", "v3.15 short pause/resume BQL synchronization")
    if "class TypeFGuestPauseGuard" in cheat:
        raise AssertionError("duplicate Type-F-only pause guard implementation returned")
    require(cheat, "using TypeFGuestPauseGuard = XemuDebugGuestPauseGuard;",
            "Type-F compatibility alias to shared pause owner")

    install = extract_function(cheat, "bool CheatEngineWindow::InstallFHook(")
    require(install, "auto cleanup_failed_install = [&]()", "single failed-install cleanup helper")
    require(install, "state.retired_may_be_referenced = false;", "never-reachable failed install marker")
    require(install, "ReleaseFHookCaveIfSafe(state);", "failed install resource release")
    # v2.90 can grow a not-yet-reachable Keystone cave before installation, so
    # exact failure-path counts are intentionally no longer frozen. Every
    # post-allocation Keystone/private-state/payload failure must still use the
    # single rollback owner.
    for token in (
        "could not allocate private preservation frames.",
        "could not allocate private T0-T7/TFLAGS bank.",
        "Type-F0 Keystone assembler error",
        "final Keystone assembly changed F0 private-state metadata.",
        "Keystone assembly exceeds the 64 KiB cave limit.",
        "could not grow the pre-install Keystone cave allocation.",
        "could not grow the Keystone-assembled executable cave.",
        "Keystone layout did not fit after repeated cave allocation passes.",
        "failed to write code/DEADCODE/DD payload to external memory.",
    ):
        pos = install.find(token)
        if pos < 0:
            raise AssertionError(f"F0 failure path missing: {token}")
        tail = install[pos:pos + 900]
        if "cleanup_failed_install();" not in tail:
            raise AssertionError(f"F0 failure path does not use shared rollback: {token}")
    if install.count("cleanup_failed_install();") < 9:
        raise AssertionError("F0 post-allocation rollback coverage unexpectedly shrank")

    release = extract_function(cheat, "bool CheatEngineWindow::ReleaseFHookCaveIfSafe(FHookState &state)")
    deactivate = extract_function(cheat, "void CheatEngineWindow::DeactivateFHook(uint64_t key)")
    for name, fn in (("ReleaseFHookCaveIfSafe", release), ("DeactivateFHook", deactivate)):
        require(fn, "TypeFGuestPauseGuard guest_pause;", f"{name} scoped pause")
        if "const bool was_running = runstate_is_running();" in fn or "vm_start();" in fn:
            raise AssertionError(f"{name} still owns manual resume/error-path bookkeeping")

    # Every other CheatEngineWindow method remains exact v1.94 code. Use a sorted
    # digest so translation-unit ownership changes do not change the behavior freeze.
    # This protects
    # F0/F1 lifecycle, Tick ordering, debugger CodeCave ownership, UI, and code
    # execution semantics outside the explicitly hardened ownership methods.
    digest, count = member_digest_sorted(
        [cheat], "CheatEngineWindow",
        {"InstallFHook", "ReleaseFHookCaveIfSafe", "DeactivateFHook"}
        | PREENTRY_SCOPED_CHEAT_METHODS,
    )
    if (digest, count) != (CHEAT_REMAINING_V194_SHA256, 57):
        raise AssertionError("unscoped CheatEngineWindow method changed from v1.94")

    dump_page = extract_function(dump, "void MemoryToolsWindow::DumpCurrentPage(")
    require(dump_page, "XemuDebugGuestPauseGuard guest_pause;", "page-dump scoped pause")
    if "vm_start();" in dump_page or "const bool was_running" in dump_page:
        raise AssertionError("page dump still owns manual early-return resume paths")

    dump_labels = extract_function(labels, "void MemoryToolsWindow::DumpLabels()")
    require(dump_labels, "XemuDebugGuestPauseGuard guest_pause;", "label-dump scoped pause")
    require(dump_labels, "guest_pause.Resume();", "historical label-dump resume boundary")
    close_pos = dump_labels.index("std::fclose(fp)")
    resume_pos = dump_labels.index("guest_pause.Resume();")
    status_pos = dump_labels.index("char status[640]")
    if not (close_pos < resume_pos < status_pos):
        raise AssertionError("label dump resume boundary moved from v1.94")

    # v3.11 deliberately replaces the historical leave-paused full-RAM dump
    # with the same scoped coherent-snapshot ownership used by Memory Search.
    # The dedicated v3.11 guard protects the worker/snapshot details; this older
    # lifecycle test verifies that pause ownership stays symmetric.
    dump_ram = extract_function(dump, "void MemoryToolsWindow::DumpRam(")
    require(dump_ram, "XemuDebugGuestPauseGuard guest_pause;", "full dump scoped pause")
    require(dump_ram, "guest_pause.Resume();", "full dump immediate resume boundary")
    require(dump_ram, "QueueDumpJob(job)", "full dump background write handoff")
    if "vm_stop(RUN_STATE_PAUSED);" in dump_ram or "const bool was_running" in dump_ram:
        raise AssertionError("v3.11 full RAM dump regained manual pause/resume bookkeeping")

    memory_texts = [
        (debug / name).read_text(encoding="utf-8")
        for name in (
            "addons/memory-tools/memory-tools.cc", "addons/memory-tools/memory-tools-memory.cc",
            "addons/memory-tools/memory-tools-memory-ui.cc", "addons/memory-tools/memory-tools-search.cc",
            "addons/memory-tools/memory-tools-search-ui.cc",
            "addons/memory-tools/memory-tools-debugger.cc", "addons/memory-tools/memory-tools-debugger-ui.cc",
            "addons/memory-tools/memory-tools-inject.cc",
            "addons/memory-tools/memory-tools-labels.cc", "addons/memory-tools/memory-tools-labels-ui.cc", "addons/memory-tools/memory-tools-dump.cc",
            "addons/memory-tools/memory-tools-dump-ui.cc",
        )
    ]
    memory_texts = [
        restore_cleanup_pass8_memory_tools_timestamp_call(text)
        if 'XemuDebugOutput::Timestamp("00000000-000000")' in text else text
        for text in memory_texts
    ]
    digest, count = member_digest_sorted(
        memory_texts, "MemoryToolsWindow", ({
            "DumpCurrentPage", "DumpLabels", "DrawRegisters", "Draw",
            "InjectNop", "OpenInstructionChanger", "ApplyInstructionChange",
            "RestoreInstructionChange", "RestoreTrackedInstructionPatch",
            "DrawInstructionChanger", "DrawCodeCaveBuilder", "DrawAddressContextMenu",
            "DrawDebugger", "DrawBreakpoints", "DrawBreakpointContents", "DrawChanges",
            "RecordCodeCaveChange", "ClearCodeCaveChange",
            # v2.94 changes only generated-output locations; these two helpers
            # are separately guarded by the v2.94 DEBUG output-layout test.
            "DumpDirectory", "DrawDumpRam", "ExecutionTraceDirectory",
        } | set(V311_MEMORY_TOOLS_MUTABLE_METHODS))
    )
    if (digest, count) != (MEMORY_REMAINING_V194_SHA256, 74):
        raise AssertionError("unscoped MemoryToolsWindow method changed from v1.94")

    print("PASS: v1.95 Pass-10 lifecycle/resource/error-path hardening invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
