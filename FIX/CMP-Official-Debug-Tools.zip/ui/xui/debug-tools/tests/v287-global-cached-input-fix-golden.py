#!/usr/bin/env python3
# v2.87 current regression ownership.
"""XEMU cached host-input/BQL isolation regression guard (through v3.14)."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def ordered(text: str, tokens: list[str], label: str) -> None:
    pos = -1
    for token in tokens:
        nxt = text.find(token, pos + 1)
        if nxt < 0:
            raise AssertionError(f"missing {label}: {token}")
        if nxt <= pos:
            raise AssertionError(f"out-of-order {label}: {token}")
        pos = nxt


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root)

    xid = (root / "hw/xbox/xid.c").read_text(encoding="utf-8")
    input_c = (root / "ui/xemu-input.c").read_text(encoding="utf-8")
    input_h = (root / "ui/xemu-input.h").read_text(encoding="utf-8")
    xemu_c = (root / "ui/xemu.c").read_text(encoding="utf-8")

    # Guest XID interrupt-IN must consume the already committed cache. It may
    # not synchronously refresh SDL while OHCI/BQL owns the USB transaction.
    forbid(xid, "xemu_input_update_controller(state);",
           "synchronous SDL refresh from XID")
    require(xid, "Host SDL state is refreshed by the UI thread outside the BQL",
            "cached-input XID ownership comment")
    require(xid, "xemu_debug_tools_controller_input_poll_trace_set_update_result(\n            0, state->connected ? 0 : 1, 0);",
            "input-poll profiler cached-read marker")

    # The UI loop prepares and samples host-only SDL state without pinning the
    # emulator-global locks, then re-acquires only to validate/commit the
    # completed values and update guest-facing controller caches.
    ordered(xemu_c, [
        "xemu_input_host_poll_prepare();",
        "xemu_input_host_poll_sample(host_input_batch);",
        "xemu_main_loop_lock();\n    xemu_input_host_poll_commit(host_input_batch);",
        "xemu_input_update_controllers();\n    xemu_main_loop_unlock();",
        "xemu_input_host_poll_free(host_input_batch);",
    ], "prepare/sample/commit BQL split")
    poll_start = xemu_c.index("static void poll_events(struct xemu_console *scon)")
    poll_end = xemu_c.index("static void display_very_early_init", poll_start)
    poll = xemu_c[poll_start:poll_end]
    prep = poll.index("xemu_input_host_poll_prepare();")
    sample = poll.index("xemu_input_host_poll_sample(host_input_batch);")
    if "xemu_main_loop_lock();" in poll[max(0, prep - 350):sample]:
        raise AssertionError("host-poll prepare/sample unexpectedly reacquired emulator lock")

    require(input_h, "typedef struct XemuInputHostPollBatch XemuInputHostPollBatch;",
            "opaque host-poll batch API")
    require(input_h, "void xemu_input_host_poll_sample(XemuInputHostPollBatch *batch);",
            "unlocked host-poll sample API")
    require(input_c, "XemuInputHostPollBatch *xemu_input_host_poll_prepare(void)",
            "host-poll prepare implementation")
    require(input_c, "void xemu_input_host_poll_sample(XemuInputHostPollBatch *batch)",
            "host-poll sample implementation")
    require(input_c, "void xemu_input_host_poll_commit(XemuInputHostPollBatch *batch)",
            "host-poll commit implementation")
    require(input_c, "const bool value = SDL_GetGamepadButton(gamepad, button);",
            "profiled SDL button getter")
    require(input_c, "const Sint16 value = SDL_GetGamepadAxis(gamepad, axis);",
            "profiled SDL axis getter")
    sample_start = input_c.index(
        "void xemu_input_host_poll_sample(XemuInputHostPollBatch *batch)")
    sample_end = input_c.index(
        "static ControllerState *xemu_input_host_poll_find_live_state",
        sample_start)
    sample = input_c[sample_start:sample_end]
    require(sample, "xemu_input_profiled_gamepad_button(",
            "SDL buttons sampled into detached batch")
    require(sample, "xemu_input_profiled_gamepad_axis(",
            "SDL axes sampled into detached batch")
    updater_start = input_c.index("void xemu_input_update_controller(ControllerState *state)")
    updater_end = input_c.index("void xemu_input_update_controllers(void)", updater_start)
    updater = input_c[updater_start:updater_end]
    require(updater, "if (state->type == INPUT_DEVICE_SDL_GAMEPAD)",
            "cache-only gamepad generic updater")
    forbid(updater, "xemu_input_update_sdl_controller_state(state);",
           "SDL gamepad query from generic updater")

    require(input_c, "state->buttons = entry->buttons;",
            "cached button commit")
    require(input_c, "memcpy(state->axis, entry->axis, sizeof(state->axis));",
            "cached axis commit")
    require(input_c, "iter->sdl_gamepad != entry->sdl_gamepad",
            "stale SDL handle rejection")
    require(input_c, "iter->sdl_joystick_id != entry->sdl_joystick_id",
            "stale joystick generation rejection")

    # The normal under-BQL updater now owns keyboard + output only; it must not
    # re-enter SDL gamepad input sampling after the cache has been committed.
    start = input_c.index("void xemu_input_update_controllers(void)")
    end = input_c.index("void xemu_input_update_sdl_kbd_controller_state", start)
    update_all = input_c[start:end]
    require(update_all, "if (iter->type == INPUT_DEVICE_SDL_KEYBOARD)",
            "keyboard-only under-BQL input refresh")
    forbid(update_all, "xemu_input_update_sdl_controller_state",
           "gamepad SDL sampling under normal BQL updater")

    # No title/game-specific workaround belongs in the generic fix.
    for path, text in (("hw/xbox/xid.c", xid), ("ui/xemu-input.c", input_c),
                       ("ui/xemu.c", xemu_c)):
        forbid(text, "Def Jam", f"game-specific name in {path}")
        forbid(text, "45410049", f"game-specific title ID in {path}")

    print("PASS: cached host-input prepare/sample stays outside emulator locks while commit revalidates generic state")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
