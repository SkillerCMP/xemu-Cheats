#!/usr/bin/env python3
"""v3.14b Guest Kernel RPC arena BQL ownership guard."""
from __future__ import annotations
import argparse
import pathlib
import re


def extract_function(text: str, signature: str) -> str:
    start = text.find(signature)
    if start < 0:
        raise AssertionError(f"missing function: {signature}")
    brace = text.find("{", start)
    if brace < 0:
        raise AssertionError(f"missing function body: {signature}")
    depth = 0
    for i in range(brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise AssertionError(f"unterminated function: {signature}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    path = root / "ui/xui/debug-tools/addons/hdd/guest-kernel-rpc-memory.c"
    text = path.read_text(encoding="utf-8")

    if '#include "qemu/main-loop.h"' not in text:
        raise AssertionError("RPC arena must include qemu/main-loop.h for conditional BQL ownership")

    signatures = (
        "int xemu_guest_rpc_arena_acquire(XemuGuestRpcArenaInfo *info)",
        "int xemu_guest_rpc_arena_write(uint32_t offset, const void *data, size_t size)",
        "int xemu_guest_rpc_arena_read(uint32_t offset, void *data, size_t size)",
        "int xemu_guest_rpc_arena_release(void)",
    )
    for signature in signatures:
        body = extract_function(text, signature)
        if body.count("BQL_LOCK_GUARD();") != 1:
            raise AssertionError(f"{signature} must own one conditional BQL guard")
        guard = body.find("BQL_LOCK_GUARD();")
        first_effect = min(
            [p for p in (
                body.find("xemu_rpc_error", body.find("{") + 1),
                body.find("xemu_rpc_mapping_active", body.find("{") + 1),
                body.find("memory_region_", body.find("{") + 1),
            ) if p >= 0],
            default=len(body),
        )
        if guard < 0 or guard > first_effect:
            raise AssertionError(f"{signature} touches arena/QEMU state before taking BQL")

    acquire = extract_function(text, signatures[0])
    if "xemu_rpc_install_mapping()" not in acquire:
        raise AssertionError("arena acquire no longer owns mapping installation")
    if "xemu_guest_rpc_arena_release()" not in acquire:
        raise AssertionError("arena acquire rollback no longer uses guarded release")

    init = extract_function(text, "static int xemu_rpc_init_region(void)")
    if "memory_region_add_subregion_overlap" not in init:
        raise AssertionError("expected first-use MemoryRegion mapping boundary disappeared")

    # The arena guard is conditional. Do not introduce broad unconditional
    # bql_lock()/bql_unlock() calls into this implementation.
    stripped = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    stripped = re.sub(r"//.*", "", stripped)
    if re.search(r"\bbql_lock\s*\(", stripped) or re.search(r"\bbql_unlock\s*\(", stripped):
        raise AssertionError("RPC arena must use conditional BQL_LOCK_GUARD, not raw broad lock/unlock")

    print("PASS: v3.14b Guest Kernel RPC arena owns conditional BQL at all memory/mapping entries")


if __name__ == "__main__":
    main()
