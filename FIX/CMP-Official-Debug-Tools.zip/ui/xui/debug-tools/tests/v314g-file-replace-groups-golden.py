#!/usr/bin/env python3
"""v3.14g grouped File Replace UI/path/recorder integration guard."""
from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[4])
args = parser.parse_args()
root = args.root.resolve()
dt = root / "ui/xui/debug-tools"
addon = dt / "addons/file-replace"
core = (addon / "file-replace.cc").read_text(encoding="utf-8")
hdr = (addon / "file-replace.hh").read_text(encoding="utf-8")
ui = (addon / "file-replace-ui.cc").read_text(encoding="utf-8")
cheats = (dt / "cheat-engine-source.cc").read_text(encoding="utf-8")
facade = (dt / "debug-tools.cc").read_text(encoding="utf-8")
recorder = (dt / "addons/Video-Recorder/video-recorder.cc").read_text(encoding="utf-8")


def need(text, token, label):
    if token not in text:
        raise SystemExit(f"FAIL: missing {label}: {token}")


def forbid(text, token, label):
    if token in text:
        raise SystemExit(f"FAIL: forbidden {label}: {token}")

need(core, 'JoinPath(JoinPath(ExecutableDirectory(), "Cheats"),', "Cheats/File-Replacements root")
need(cheats, 'g_ascii_strcasecmp(filename.c_str(), "File-Replacements") == 0', "normal cheat scanner exclusion")
need(hdr, "struct ReplacementGroup", "group model")
need(hdr, "struct ReplacementOption", "option model")
need(hdr, "GroupSelection::Multiple", "group selection model")
need(core, 'manifest_version != 3 && manifest_version != 4', "manifest v3/v4 version gate")
need(core, 'group.selection = GroupSelection::Single', "exclusive group parser")
need(core, 'group.selection = GroupSelection::Multiple', "multi-select group parser")
need(core, 'original.name = "Original / Retail"', "automatic retail choice")
need(core, '"NEEDS RESET"', "needs-reset state")
need(core, '"UNAVAILABLE"', "unavailable exact-identity state")
need(core, '"ERROR"', "option error state")
need(core, '"ACTIVE"', "active option state")
need(ui, "ImGui::CollapsingHeader", "collapsed-by-default group UI")
for forbidden in ("ImGuiTreeNodeFlags_DefaultOpen", "ImGuiTreeNodeFlags_DefaultOpen"):
    forbid(ui, forbidden, "default-open File Replace group")
need(ui, "ImGui::RadioButton", "single-choice radio UI")
need(ui, "ImGui::Checkbox", "multi-choice checkbox UI")
need(ui, 'ImGui::SmallButton("i")', "information button")
need(ui, "ImGui::BeginPopupContextItem", "right-click information")
need(ui, 'ImGui::Text("Status: %s", OptionStatus(option).c_str())', "info status")
need(facade, "AppendActiveRecordingDetails", "recorder File Replace integration")
need(core, "groups.push_back(group.name)", "recorder group label")
need(core, "names.push_back(option.name)", "recorder option label")
need(core, "credits.push_back(OptionCredits(option))", "recorder optional credits")
need(recorder, 'fit_line("Credits: " + credits[i]', "existing recorder credits rendering")
need(core, "DesiredEntryIndices", "group-to-operation expansion")
need((addon / "file-replace-compiler.cc").read_text(), "Active File Replace ranges overlap", "active-set overlap protection")

# v3.16 DVD read hooks remain generic and retain grouped UI/reset behavior.
atapi = (root / "hw/ide/atapi.c").read_text(encoding="utf-8")
if atapi.count("xemu_file_replace_pread(") != 2 or "xemu_file_replace_aio_preadv(" not in (root / "hw/ide/core.c").read_text():
    raise SystemExit("FAIL: missing v3.16 synchronous/buffered ATAPI coverage")

print("PASS: v3.14g grouped File Replace/path/recorder integration guard")
