#!/usr/bin/env python3
# v2.87 current regression ownership.
"""v3.06 Diagnostics + PTIMER/QEMU timer/slow-timer/OHCI/input-poll/BQL/MMIO/PGRAPH trace build/isolation guard."""
from __future__ import annotations

import argparse
import hashlib
import pathlib
import re

from v287_source_test_utils import (
    extract_function, restore_cleanup_pass7_historical_runtime,
)


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    addon = debug / "addons/diagnostics"

    required = (
        "debug-tools-diagnostics-addon.cc",
        "diagnostics.hh",
        "diagnostics.cc",
        "diagnostics-backend.h",
        "diagnostics-backend.c",
        "diagnostics-cpu-context.h",
        "diagnostics-ptimer-utils.h",
        "ptimer-trace-hook.h",
        "ptimer-trace.h",
        "ptimer-trace.c",
        "qemu-timer-trace-hook.h",
        "qemu-timer-trace.h",
        "qemu-timer-trace.c",
        "slow-timer-trace-hook.h",
        "slow-timer-trace.h",
        "slow-timer-trace.c",
        "ohci-slow-frame-trace-hook.h",
        "ohci-slow-frame-trace.c",
        "controller-input-poll-trace-hook.h",
        "controller-input-poll-trace.c",
        "bql-trace-hook.h",
        "bql-trace.h",
        "bql-trace.c",
        "mmio-trace-hook.h",
        "mmio-trace.h",
        "mmio-trace.c",
        "pgraph-lock-trace-hook.h",
        "pgraph-lock-trace.h",
        "pgraph-lock-trace.c",
        "pgraph-draw-trace-hook.h",
        "pgraph-draw-trace.h",
        "pgraph-draw-trace.c",
        "flip-stall-trace-hook.h",
        "flip-stall-trace.h",
        "flip-stall-trace.c",
        "scheduler-trace-hook.h",
        "scheduler-trace.h",
        "scheduler-trace.c",
    )
    for name in required:
        if not (addon / name).is_file():
            raise AssertionError(f"missing Diagnostics add-on file: {name}")
    if not (debug / "addons/stubs/debug-tools-diagnostics-addon-stub.cc").is_file():
        raise AssertionError("missing Diagnostics disabled-profile stub")
    if not (debug / "addons/stubs/ptimer-trace-stub.c").is_file():
        raise AssertionError("missing PTIMER trace disabled-profile hook stub")
    if not (debug / "addons/stubs/qemu-timer-trace-stub.c").is_file():
        raise AssertionError("missing QEMU timer trace disabled-profile hook stub")
    if not (debug / "addons/stubs/ohci-slow-frame-trace-stub.c").is_file():
        raise AssertionError("missing OHCI slow-frame disabled-profile hook stub")
    if not (debug / "addons/stubs/controller-input-poll-trace-stub.c").is_file():
        raise AssertionError("missing controller input-poll disabled-profile hook stub")
    if not (debug / "addons/stubs/bql-trace-stub.c").is_file():
        raise AssertionError("missing BQL trace disabled-profile hook stub")
    if not (debug / "addons/stubs/mmio-trace-stub.c").is_file():
        raise AssertionError("missing MMIO trace disabled-profile hook stub")
    if not (debug / "addons/stubs/pgraph-lock-trace-stub.c").is_file():
        raise AssertionError("missing PGRAPH lock trace disabled-profile hook stub")
    if not (debug / "addons/stubs/pgraph-draw-trace-stub.c").is_file():
        raise AssertionError("missing PGRAPH draw trace disabled-profile hook stub")
    if not (debug / "addons/stubs/flip-stall-trace-stub.c").is_file():
        raise AssertionError("missing FLIP_STALL trace disabled-profile hook stub")
    if not (debug / "addons/stubs/scheduler-trace-stub.c").is_file():
        raise AssertionError("missing scheduler trace disabled-profile hook stub")

    # Physical add-on isolation: no Diagnostics implementation may leak back to
    # the shared Debug Tools root.
    for name in ("diagnostics.hh", "diagnostics.cc", "diagnostics-backend.h",
                 "diagnostics-backend.c", "ptimer-trace-hook.h",
                 "ptimer-trace.h", "ptimer-trace.c",
                 "qemu-timer-trace-hook.h", "qemu-timer-trace.h",
                 "qemu-timer-trace.c", "slow-timer-trace-hook.h",
                 "slow-timer-trace.h", "slow-timer-trace.c",
                 "ohci-slow-frame-trace-hook.h", "ohci-slow-frame-trace.c",
                 "controller-input-poll-trace-hook.h",
                 "controller-input-poll-trace.c",
                 "pgraph-ptimer-latency-trace-types.h",
                 "bql-trace-hook.h", "bql-trace.h",
                 "bql-trace.c", "mmio-trace-hook.h", "mmio-trace.h", "mmio-trace.c",
                 "pgraph-lock-trace-hook.h", "pgraph-lock-trace.h",
                 "pgraph-lock-trace.c", "pgraph-draw-trace-hook.h",
                 "pgraph-draw-trace.h", "pgraph-draw-trace.c",
                 "flip-stall-trace-hook.h", "flip-stall-trace.h",
                 "flip-stall-trace.c", "scheduler-trace-hook.h",
                 "scheduler-trace.h", "scheduler-trace.c"):
        if (debug / name).exists():
            raise AssertionError(f"Diagnostics implementation leaked into root: {name}")

    meson = (debug / "meson.build").read_text(encoding="utf-8")
    module_h = (debug / "debug-tools-module.hh").read_text(encoding="utf-8")
    facade = (debug / "debug-tools.cc").read_text(encoding="utf-8")
    registration = (addon / "debug-tools-diagnostics-addon.cc").read_text(encoding="utf-8")
    ui = (addon / "diagnostics.cc").read_text(encoding="utf-8")
    hh = (addon / "diagnostics.hh").read_text(encoding="utf-8")
    facade_h = (debug / "debug-tools.hh").read_text(encoding="utf-8")
    detached_h = (debug / "detached-tools.hh").read_text(encoding="utf-8")
    detached = (debug / "detached-tools.cc").read_text(encoding="utf-8")
    main_cc = (root / "ui/xui/main.cc").read_text(encoding="utf-8")
    hud_h = (root / "ui/xui/xemu-hud.h").read_text(encoding="utf-8")
    xemu_c = (root / "ui/xemu.c").read_text(encoding="utf-8")
    backend_h = (addon / "diagnostics-backend.h").read_text(encoding="utf-8")
    backend = (addon / "diagnostics-backend.c").read_text(encoding="utf-8")
    cpu_context = (addon / "diagnostics-cpu-context.h").read_text(encoding="utf-8")
    ptimer_utils = (addon / "diagnostics-ptimer-utils.h").read_text(encoding="utf-8")
    trace_hook_h = (addon / "ptimer-trace-hook.h").read_text(encoding="utf-8")
    trace_h = (addon / "ptimer-trace.h").read_text(encoding="utf-8")
    trace = (addon / "ptimer-trace.c").read_text(encoding="utf-8")
    trace_stub = (debug / "addons/stubs/ptimer-trace-stub.c").read_text(encoding="utf-8")
    slow_hook = (addon / "slow-timer-trace-hook.h").read_text(encoding="utf-8")
    slow_h = (addon / "slow-timer-trace.h").read_text(encoding="utf-8")
    slow_trace = (addon / "slow-timer-trace.c").read_text(encoding="utf-8")
    ohci_slow_hook = (addon / "ohci-slow-frame-trace-hook.h").read_text(encoding="utf-8")
    ohci_slow_trace = (addon / "ohci-slow-frame-trace.c").read_text(encoding="utf-8")
    ohci_slow_stub = (debug / "addons/stubs/ohci-slow-frame-trace-stub.c").read_text(encoding="utf-8")
    input_poll_hook = (addon / "controller-input-poll-trace-hook.h").read_text(encoding="utf-8")
    input_poll_trace = (addon / "controller-input-poll-trace.c").read_text(encoding="utf-8")
    input_poll_stub = (debug / "addons/stubs/controller-input-poll-trace-stub.c").read_text(encoding="utf-8")
    xid_c = (root / "hw/xbox/xid.c").read_text(encoding="utf-8")
    xid_gamepad_c = (root / "hw/xbox/xid-gamepad.c").read_text(encoding="utf-8")
    input_c = (root / "ui/xemu-input.c").read_text(encoding="utf-8")
    ohci_c = (root / "hw/usb/hcd-ohci.c").read_text(encoding="utf-8")
    qemu_timer_c = (root / "util/qemu-timer.c").read_text(encoding="utf-8")
    timer_h = (root / "include/qemu/timer.h").read_text(encoding="utf-8")
    bql = (addon / "bql-trace.c").read_text(encoding="utf-8")
    bql_h = (addon / "bql-trace.h").read_text(encoding="utf-8")
    lock_common = (addon / "lock-trace-common.c").read_text(encoding="utf-8")
    lock_common_h = (addon / "lock-trace-common.h").read_text(encoding="utf-8")
    bql_hook = (addon / "bql-trace-hook.h").read_text(encoding="utf-8")
    bql_stub = (debug / "addons/stubs/bql-trace-stub.c").read_text(encoding="utf-8")
    mmio = (addon / "mmio-trace.c").read_text(encoding="utf-8")
    mmio_hook = (addon / "mmio-trace-hook.h").read_text(encoding="utf-8")
    mmio_stub = (debug / "addons/stubs/mmio-trace-stub.c").read_text(encoding="utf-8")
    pgraph_lock = (addon / "pgraph-lock-trace.c").read_text(encoding="utf-8")
    pgraph_lock_hook = (addon / "pgraph-lock-trace-hook.h").read_text(encoding="utf-8")
    pgraph_lock_stub = (debug / "addons/stubs/pgraph-lock-trace-stub.c").read_text(encoding="utf-8")
    pgraph_draw = (addon / "pgraph-draw-trace.c").read_text(encoding="utf-8")
    pgraph_draw_hook = (addon / "pgraph-draw-trace-hook.h").read_text(encoding="utf-8")
    pgraph_draw_stub = (debug / "addons/stubs/pgraph-draw-trace-stub.c").read_text(encoding="utf-8")
    cputlb = (root / "accel/tcg/cputlb.c").read_text(encoding="utf-8")
    pgraph_h = (root / "hw/xbox/nv2a/pgraph/pgraph.h").read_text(encoding="utf-8")
    pgraph_c = (root / "hw/xbox/nv2a/pgraph/pgraph.c").read_text(encoding="utf-8")
    pgraph_gl_draw = (root / "hw/xbox/nv2a/pgraph/gl/draw.c").read_text(encoding="utf-8")
    pfifo_c = (root / "hw/xbox/nv2a/pfifo.c").read_text(encoding="utf-8")
    cpus = (root / "system/cpus.c").read_text(encoding="utf-8")
    docker = (debug / "docker-build-windows.sh").read_text(encoding="utf-8")
    ptimer_path = root / "hw/xbox/nv2a/ptimer.c"
    ptimer = ptimer_path.read_text(encoding="utf-8")
    if (root / "hw/xbox/nv2a/ptimer-debug.h").exists():
        raise AssertionError("PTIMER trace implementation/API leaked into hw/xbox/nv2a")

    # Existing four profile names remain stable; only full owns Diagnostics.
    require(meson, "debug_tools_with_diagnostics = (debug_tools_profile == 'full')",
            "full-only Diagnostics profile gate")
    require(meson, "if debug_tools_with_diagnostics", "Diagnostics Meson gate")
    require(meson, "addons/diagnostics/debug-tools-diagnostics-addon.cc",
            "Diagnostics registration source")
    require(meson, "addons/diagnostics/diagnostics.cc", "Diagnostics UI source")
    require(meson, "specific_ss.add(files(\n    'addons/diagnostics/diagnostics-backend.c'",
            "target-specific Diagnostics backend source set")
    require(meson, "'addons/diagnostics/ptimer-trace.c',",
            "Diagnostics-owned PTIMER trace implementation")
    require(meson, "'addons/diagnostics/qemu-timer-trace.c',",
            "Diagnostics-owned QEMU timer trace implementation")
    require(meson, "'addons/diagnostics/slow-timer-trace.c',",
            "Diagnostics-owned slow timer callback recorder")
    require(meson, "'addons/diagnostics/ohci-slow-frame-trace.c',",
            "Diagnostics-owned OHCI slow-frame recorder")
    require(meson, "addons/stubs/ohci-slow-frame-trace-stub.c",
            "disabled-profile OHCI slow-frame hook stub")
    require(meson, "'addons/diagnostics/bql-trace.c',",
            "Diagnostics-owned BQL trace implementation")
    require(meson, "addons/stubs/debug-tools-diagnostics-addon-stub.cc",
            "disabled Diagnostics stub")
    require(meson, "addons/stubs/ptimer-trace-stub.c",
            "disabled-profile PTIMER hook stub")
    require(meson, "addons/stubs/qemu-timer-trace-stub.c",
            "disabled-profile QEMU timer hook stub")
    require(meson, "addons/stubs/bql-trace-stub.c",
            "disabled-profile BQL hook stub")
    require(meson, "'addons/diagnostics/mmio-trace.c',",
            "Diagnostics-owned MMIO trace implementation")
    require(meson, "addons/stubs/mmio-trace-stub.c",
            "disabled-profile MMIO hook stub")
    require(meson, "'addons/diagnostics/pgraph-lock-trace.c',",
            "Diagnostics-owned PGRAPH lock trace implementation")
    require(meson, "addons/stubs/pgraph-lock-trace-stub.c",
            "disabled-profile PGRAPH lock hook stub")
    require(meson, "'addons/diagnostics/pgraph-draw-trace.c',",
            "Diagnostics-owned PGRAPH draw trace implementation")
    require(meson, "addons/stubs/pgraph-draw-trace-stub.c",
            "disabled-profile PGRAPH draw hook stub")
    require(meson, "'addons/diagnostics/flip-stall-trace.c',",
            "Diagnostics-owned FLIP_STALL/VBlank recorder")
    require(meson, "addons/stubs/flip-stall-trace-stub.c",
            "disabled-profile FLIP_STALL hook stub")
    require(meson, "'addons/diagnostics/scheduler-trace.c',",
            "Diagnostics-owned scheduler/thread-wake recorder")
    require(meson, "addons/stubs/scheduler-trace-stub.c",
            "disabled-profile scheduler wake hook stub")
    forbid(meson, "xemu_ss.add(files(\n    'addons/diagnostics/diagnostics-backend.c'",
           "generic source-set ownership for target backend")

    require(module_h, "void debug_tools_register_diagnostics_addition();",
            "Diagnostics module entry point")
    require(facade, "debug_tools_register_diagnostics_addition();",
            "facade Diagnostics registration call")
    forbid(facade, '#include "diagnostics.hh"', "facade implementation dependency")
    require(registration, 'debug_tools_register_menu_item(500, "Diagnostics"',
            "Diagnostics menu registration")
    require(registration, "debug_tools_register_tick(500, TickDiagnostics);",
            "Diagnostics tick registration")
    require(registration, "debug_tools_register_reset(300, NotifyDiagnosticsReset);",
            "Diagnostics reset registration")
    require(registration, '"xemu - Diagnostics"', "detached Diagnostics window")

    # Keep the existing debugger/WHPX bridges byte-identical to 2.91.9. The
    # failed first implementation modified these shared backends unnecessarily.
    expected_shared_backend = {
        "backend/xemu-dbg.c": "ab118fd0771fc3850213c4b4740263b6888c45a24dedc16389a2415a2c8ff531",
        "backend/xemu-dbg.h": "46f4b58af31822ee491b59efb01cb9c59f5fb7835a86893bee2907edf997e253",
        "backend/whpx-debug.c": "59dab42ded910a7c099a92c3f9f308fd70c5077f6ee3c4e0009b2fa02d60c718",
        "backend/whpx-debug.h": "c95e33434713fe2cd81b5679a69ab86ac7ad9d08b182a07788fa165e68035069",
    }
    for rel, expected in expected_shared_backend.items():
        path = debug / rel
        data = restore_cleanup_pass7_historical_runtime(rel, path.read_bytes())
        actual = hashlib.sha256(data).hexdigest()
        if actual != expected:
            raise AssertionError(
                f"2.91.9 shared debugger backend changed: {rel} "
                f"(expected {expected}, got {actual})"
            )

    # UI-side host I/O deliberately avoids <fstream>. QEMU's Windows headers
    # macro-map close -> qemu_close_wrap; allowing that macro into std::filebuf
    # caused the earlier final-LTO undefined reference.
    require(ui, "#include <glib.h>", "explicit GLib declarations")
    require(ui, "#include <glib/gstdio.h>", "GLib stdio declarations")
    require(ui, "g_fopen(", "snapshot g_fopen")
    require(ui, "std::fwrite(", "snapshot fwrite")
    require(ui, "std::fclose(", "snapshot fclose")
    require(ui, "g_mkdir_with_parents(", "snapshot directory creation")
    require(ui, "g_rename(", "rolling snapshot rename")
    forbid(ui, "#include <fstream>", "C++ fstream dependency")
    forbid(ui, "std::ofstream", "C++ ofstream")
    forbid(ui, "std::basic_filebuf", "C++ filebuf")
    forbid(ui, "std::filesystem", "C++ filesystem in QEMU-facing UI unit")

    # Custom watches must remain passive. They start disabled while the user
    # edits an address, resolve virtual addresses to physical RAM, reject
    # PCI/MMIO/unmapped destinations, and perform only validated RAM reads.
    require(hh, "bool enabled = false;", "disabled-by-default custom watch")
    require(hh, "bool physical_valid = false;", "custom watch physical resolution state")
    require(ui, "bool ReadWatchRamOnly(", "RAM-only custom watch reader")
    require(ui, "physical >= ram_size", "custom watch installed-RAM range guard")
    require(ui, "xemu_cheat_virtual_to_physical(current, &physical)",
            "custom watch virtual-to-physical translation")
    require(ui, "xemu_cheat_memory_read(0, (uint32_t)physical, out, amount)",
            "custom watch validated physical RAM read")
    require(ui, 'ImGui::TableSetupColumn("Active"',
            "explicit custom watch activation control")
    require(ui, 'ImGui::TableSetupColumn("Resolved P"',
            "custom watch resolved physical display")
    require(ui, "watch.enabled = false;", "watch edit auto-disable safety")
    require(ui, '"RAM-only. Editing Space, Address, or Type disables the watch; "',
            "RAM-only watch UI guidance")
    forbid(ui, "watch.virtual_address ? 1 : 0, watch.address",
           "direct generic virtual/MMIO read from SampleWatches")

    # Target-only details remain behind a plain-C snapshot bridge.
    require(hh, '#include "diagnostics-backend.h"', "Diagnostics C bridge header")
    require(backend_h, "typedef struct XemuDiagnosticsTimingSnapshot",
            "timing snapshot ABI")
    require(backend_h, "typedef struct XemuDiagnosticsDeviceSnapshot",
            "device snapshot ABI")
    require(backend, '#include "cpu.h"', "target/i386 CPU header")
    require(backend, "nv2a_int.h", "NV2A internal telemetry")
    require(backend, "apu_int.h", "APU internal telemetry")
    require(backend, "#ifdef CONFIG_WHPX", "WHPX compile guard")
    require(backend, "WHvX64RegisterTsc", "guest-visible WHPX TSC read")
    require(backend, "run_on_cpu(cpu, diagnostics_whpx_read_tsc",
            "vCPU-context WHPX register read")
    require(backend, "WHvCapabilityCodeProcessorClockFrequency",
            "WHPX processor clock capability")
    require(backend, "WHvCapabilityCodeInterruptClockFrequency",
            "WHPX interrupt clock capability")

    # Patch 305.2 adds only the focused PTIMER IRQ-delivery observation calls
    # to the previously audited minimal PTIMER hook surface. Timer programming,
    # alarm advancement and IRQ semantics remain pinned by this final-source hash.
    expected_ptimer_sha = "03309138307bd59362bb883c2db990e40fb2af284878b0627c703a13bcf803a3"
    if sha256(ptimer_path) != expected_ptimer_sha:
        raise AssertionError("Patch 305.2 audited PTIMER observation surface changed")

    require(trace_hook_h, "XemuDebugToolsPtimerTraceHookEvent",
            "minimal PTIMER hook event contract")
    require(trace_hook_h, "xemu_debug_tools_ptimer_trace_init",
            "minimal PTIMER trace init hook")
    require(trace_hook_h, "xemu_debug_tools_ptimer_trace_record",
            "minimal PTIMER event hook")
    forbid(trace_hook_h, "QemuMutex", "trace storage in minimal hook header")
    forbid(trace_hook_h, "rdtsc_reference", "trace data ABI in minimal hook header")

    require(trace_h, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY 4096",
            "4096-event PTIMER trace ring")
    require(trace_h, "callback_lateness_ns",
            "PTIMER callback lateness field")
    require(trace_h, "guest_pc_valid",
            "vCPU-context guest PC validity field")
    require(trace_h, "rdtsc_reference_valid",
            "vCPU-context RDTSC reference validity field")
    require(trace_h, "qemu_timer_expire_ns",
            "QEMU timer expiry field")

    require(ptimer, "ptimer-trace-hook.h", "Debug Tools PTIMER hook include")
    require(ptimer, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_ALARM_WRITE",
            "alarm-write observation hook")
    require(ptimer, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_INTR_EN_WRITE",
            "interrupt-enable observation hook")
    require(ptimer, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_CALLBACK",
            "timer callback observation hook")
    require(ptimer, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_IRQ_SET",
            "IRQ-set observation hook")
    require(ptimer, "XEMU_DEBUG_TOOLS_PTIMER_TRACE_IRQ_CLEAR",
            "IRQ-clear observation hook")
    # Official master now owns the no-storm PTIMER epoch fix with a single
    # 61-bit register-time alarm. Keep that implementation and only observe it.
    require(ptimer, "static inline uint64_t advance_alarm_epoch(uint64_t reg_time)",
            "official PTIMER next-epoch helper")
    require(ptimer, "return (reg_time + (1ULL << 32)) & PTIMER_REG_TIME_MASK;",
            "official PTIMER next-epoch wrap")
    require(ptimer,
            "d->ptimer.alarm_time = advance_alarm_epoch(d->ptimer.alarm_time);",
            "official recurring-alarm next-epoch rearm")
    forbid(ptimer, "alarm_time_high",
           "obsolete split alarm epoch representation")
    require(ptimer, "if (val_low <= (now_low & ALARM_MASK))",
            "official PTIMER alarm-write rollover comparison")
    require(ptimer, "target = advance_alarm_epoch(target);",
            "official PTIMER alarm-write rollover increment")
    reg_mask = ((0x1FFFFFFF << 32) | 0xFFFFFFE0)
    for current in (0, 1 << 32, (0x1FFFFFFE << 32), (0x1FFFFFFF << 32)):
        got = (current + (1 << 32)) & reg_mask
        expected = 0 if current == (0x1FFFFFFF << 32) else current + (1 << 32)
        if got != expected:
            raise AssertionError(
                f"official PTIMER next-epoch wrap arithmetic changed: "
                f"current={current:#x} got={got:#x} expected={expected:#x}"
            )
    for token, label in (
        ("QemuMutex", "trace lock"),
        ("XemuDebugToolsPtimerTraceEvent", "trace event storage"),
        ("last_scheduled_expire_ns", "trace schedule state"),
        ("qemu_clock_get_ns(QEMU_CLOCK_HOST)", "host timing capture"),
        ("current_cpu", "vCPU trace capture"),
        ("cpu_get_tsc", "RDTSC trace capture"),
        ("timer_expire_time_ns", "trace expiry capture"),
    ):
        forbid(ptimer, token, f"{label} in real PTIMER implementation")
    forbid(ptimer, "g_fopen(", "PTIMER-path host file I/O")
    forbid(ptimer, "fwrite(", "PTIMER-path fwrite")
    forbid(ptimer, "fprintf(", "PTIMER-path fprintf")

    require(trace, "QemuMutex lock", "Diagnostics-owned trace lock")
    require(trace, "last_scheduled_expire_ns",
            "Diagnostics-owned callback scheduling reference")
    require(trace, "qemu_clock_get_ns(QEMU_CLOCK_HOST)",
            "Diagnostics-owned host timing sample")
    require(trace, "cpu = current_cpu;",
            "Diagnostics-owned vCPU-context source")
    require(trace, "cpu->cc->get_pc(cpu)",
            "Diagnostics-owned generic guest PC capture")
    require(trace, "cpu_get_tsc(env) + env->tsc_offset",
            "Diagnostics-owned Xbox RDTSC reference capture")
    require(trace, "timer_expire_time_ns(&d->ptimer.timer)",
            "Diagnostics-owned scheduled expiry capture")
    forbid(trace, "g_fopen(", "PTIMER trace host file I/O")
    forbid(trace, "fwrite(", "PTIMER trace fwrite")
    forbid(trace, "fprintf(", "PTIMER trace fprintf")

    require(trace_stub, "xemu_debug_tools_ptimer_trace_record",
            "disabled-profile no-op PTIMER hook")
    forbid(trace_stub, "QemuMutex", "trace state in disabled-profile stub")

    require(backend, 'ptimer-trace.h', "Diagnostics PTIMER trace bridge")
    require(backend, "xemu_debug_tools_ptimer_trace_snapshot",
            "PTIMER trace snapshot bridge")
    require(backend_h, "typedef XemuDebugToolsPtimerTraceEvent XemuDiagnosticsPtimerTraceEvent;",
            "frontend-safe PTIMER trace ABI alias")
    require(ui, '"Record detailed PTIMER events"', "PTIMER trace enable control")
    require(ui, '"Clear PTIMER Trace"', "PTIMER trace clear control")
    require(ui, '"PTIMER Detailed Timing Trace\\n', "snapshot PTIMER trace section")
    require(ui, "callback_late_ns", "snapshot callback lateness column")
    require(ui, "guest_pc_valid", "snapshot guest PC validity column")
    require(ui, "rdtsc_ref_valid", "snapshot RDTSC reference validity column")
    require(ui, '"RDTSC Ref"', "live RDTSC reference column")


    # Slow QEMU Timer Callback detector: central timer code owns only the tiny
    # timing bridge. Threshold filtering happens before the Diagnostics recorder
    # lock, and the retained ring stays under the physical Diagnostics add-on.
    require(slow_hook, "XemuDebugToolsSlowTimerObserver",
            "slow timer callback observation contract")
    forbid(slow_hook, "QemuMutex",
           "slow timer recorder state in minimal hook contract")
    require(slow_h, "XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY 128",
            "128-event slow timer ring")
    require(slow_h, "XEMU_DEBUG_TOOLS_SLOW_TIMER_DEFAULT_THRESHOLD_NS 1000000ULL",
            "1 ms default slow timer threshold")
    require(slow_trace, "slow_timer_trace_reset_locked",
            "slow timer recorder reset")
    require(slow_trace, "xemu_debug_tools_slow_timer_hook_install(slow_timer_observer)",
            "slow timer observer installation")
    require(slow_trace, "slow_timer_trace.threshold_ns != clamped",
            "threshold change detection")
    require(qemu_timer_c, "slow-timer-trace-hook.h",
            "central timer slow callback hook include")
    require(qemu_timer_c, "qemu_clock_get_ns(QEMU_CLOCK_REALTIME)",
            "host-monotonic slow callback timing")
    require(qemu_timer_c, "host_end_ns - host_start_ns >= threshold_ns",
            "pre-recorder slow callback threshold filter")
    require(qemu_timer_c, "(uintptr_t)cb",
            "slow callback function address capture")
    require(qemu_timer_c, "bql_held_before",
            "slow callback BQL state capture")
    require(backend, 'slow-timer-trace.h',
            "Diagnostics slow timer trace bridge")
    require(backend_h, "XemuDiagnosticsSlowTimerTraceEvent",
            "frontend-safe slow timer trace ABI")
    require(ui, '"Record slow QEMU timer callbacks"',
            "slow timer enable control")
    require(ui, '"Threshold (ms)"',
            "editable millisecond threshold")
    require(ui, '"1 = 1 ms, 5 = 5 ms, 100 = 100 ms"',
            "threshold unit guidance")
    require(ui, '"Slow QEMU Timer Callback Trace\\n',
            "snapshot slow timer trace section")
    require(ui, "Worst callback duration ns",
            "slow timer snapshot worst-callback summary")
    require(ui, "Worst callback name",
            "slow timer snapshot callback name")
    require(ui, "Worst callback source",
            "slow timer snapshot source location")
    require(timer_h, "xemu_debug_cb_name",
            "QEMUTimer callback source-name metadata")
    require(timer_h, "#cb, __FILE__, __LINE__",
            "timer helper callback call-site identity capture")

    # v3.03 OHCI slow-frame profiler: hcd-ohci only samples while the
    # Diagnostics-owned threshold query is non-zero. Ring storage and UI remain
    # under the Diagnostics add-on, with a no-op non-full profile stub.
    require(ohci_slow_hook, "XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY 128",
            "128-event OHCI slow-frame ring contract")
    require(ohci_slow_hook, "XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_DEFAULT_THRESHOLD_NS 1000000ULL",
            "1 ms OHCI slow-frame default")
    forbid(ohci_slow_hook, "QemuMutex", "OHCI hook contract recorder state")
    require(ohci_slow_trace, "ohci_slow_frame_trace_reset_locked",
            "OHCI slow-frame recorder reset")
    require(ohci_slow_trace, "source->host_duration_ns < source->threshold_ns",
            "OHCI pre-lock slow-frame threshold filter")
    require(ohci_slow_stub, "xemu_debug_tools_ohci_slow_frame_trace_threshold_ns",
            "disabled-profile OHCI threshold stub")
    forbid(ohci_slow_stub, "QemuMutex", "OHCI state in disabled-profile stub")
    require(ohci_c, "ohci-slow-frame-trace-hook.h", "OHCI profiler hook include")
    require(ohci_c, "xemu_debug_tools_ohci_slow_frame_trace_threshold_ns()",
            "OHCI profiler enable/threshold query")
    require(ohci_c, "profile->periodic_list_ns", "OHCI periodic-list timing")
    require(ohci_c, "profile->control_list_ns", "OHCI control-list timing")
    require(ohci_c, "profile->bulk_list_ns", "OHCI bulk-list timing")
    require(ohci_c, "profile->usb_handle_packet_ns", "OHCI USB packet timing")
    require(ohci_c, "profile->dma_to_device_ns", "OHCI DMA-to-device timing")
    require(ohci_c, "profile->dma_from_device_ns", "OHCI DMA-from-device timing")
    require(backend_h, "XemuDiagnosticsOhciSlowFrameEvent",
            "frontend-safe OHCI slow-frame ABI")
    require(ui, '"Record OHCI slow frame stages"', "OHCI stage profiler control")
    require(ui, '"OHCI Threshold (ms)"', "OHCI stage editable threshold")
    require(ui, '"OHCI Slow Frame Stage Trace\\n', "OHCI stage snapshot section")
    require(ui, "Worst leaf:", "OHCI snapshot worst-leaf summary")
    require(ui, "XEMU Diagnostics Snapshot v3.09", "v3.09 snapshot format")

    # v3.04 targeted controller input-poll profiler: only XID interrupt-IN polls
    # arm the TLS context. The normal input path contributes stage observations,
    # while threshold policy/ring storage/UI remain Diagnostics-owned.
    require(input_poll_hook, "XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY 128",
            "128-event controller input-poll ring contract")
    require(input_poll_hook, "XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_DEFAULT_THRESHOLD_NS 1000000ULL",
            "1 ms controller input-poll default")
    forbid(input_poll_hook, "QemuMutex", "controller input-poll hook contract state")
    require(input_poll_trace, "static __thread XemuDebugToolsControllerInputPollTls",
            "controller input-poll TLS staging")
    require(input_poll_trace, "event.host_duration_ns < event.threshold_ns",
            "controller input-poll pre-lock threshold filter")
    require(input_poll_stub, "xemu_debug_tools_controller_input_poll_trace_begin",
            "disabled-profile controller input-poll stub")
    require(xid_gamepad_c, "xemu_debug_tools_controller_input_poll_trace_begin(",
            "XID interrupt-IN poll profiler begin")
    require(xid_gamepad_c, "XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_USB_PACKET_COPY",
            "XID USB packet-copy timing")
    require(xid_c, "XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_GET_BOUND",
            "XID bound-controller timing")
    forbid(xid_c, "xemu_input_update_controller(state);",
           "synchronous host-controller refresh from XID")
    require(xid_c, "Host SDL state is refreshed by the UI thread outside the BQL",
            "XID cached-input handoff")
    require(input_c, "xemu_input_profiled_gamepad_button",
            "individual SDL button timing")
    require(input_c, "xemu_input_profiled_gamepad_axis",
            "individual SDL axis timing")
    require(input_c, "XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_RIGHT_Y",
            "all SDL axes covered")
    require(backend_h, "XemuDiagnosticsControllerInputPollEvent",
            "frontend-safe controller input-poll ABI")
    require(ui, '"Record slow controller input polls"',
            "controller input-poll profiler control")
    require(ui, '"Input Poll Threshold (ms)"',
            "controller input-poll editable threshold")
    require(ui, '"Controller Input Poll Stage Trace\\n',
            "controller input-poll snapshot section")
    require(ui, "Worst SDL getter:",
            "controller input-poll worst-getter summary")

    # v2.97 BQL ownership trace: system/cpus.c owns only four tiny observation
    # calls. Owner state, lock-free ring storage, timing, guest PC capture and
    # snapshot/UI plumbing remain inside Diagnostics.
    require(cpus, "bql-trace-hook.h", "BQL observation hook include")
    require(cpus, "xemu_debug_tools_bql_trace_lock_attempt(file, line);",
            "BQL acquire-attempt hook")
    require(cpus, "xemu_debug_tools_bql_trace_lock_acquired(file, line);",
            "BQL acquired hook")
    require(cpus, "xemu_debug_tools_bql_trace_unlock_begin();",
            "BQL unlock begin hook")
    require(cpus, "xemu_debug_tools_bql_trace_unlock_end();",
            "BQL unlock end hook")
    require(lock_common, "committed_sequence_plus_one", "lock-free BQL ring commit")
    require(lock_common_h, "XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS", "long BQL threshold")
    require(lock_common, '#include "diagnostics-cpu-context.h"',
            "BQL shared CPU-context helper include")
    require(lock_common, "xemu_debug_tools_diagnostics_current_cpu_context(",
            "BQL shared CPU-context helper use")
    require(cpu_context, "cpu->cc->get_pc(cpu)",
            "shared Diagnostics guest PC capture")
    forbid(bql_hook, "QemuMutex", "BQL trace state in hook contract")
    require(bql_stub, "xemu_debug_tools_bql_trace_lock_attempt",
            "disabled-profile BQL no-op hook")
    require(backend, 'bql-trace.h', "Diagnostics BQL trace bridge")
    require(backend, "xemu_debug_tools_bql_trace_snapshot",
            "BQL trace snapshot bridge")
    require(backend_h, "XemuDiagnosticsBqlTraceEvent",
            "frontend-safe BQL trace ABI")
    require(ui, '"Record BQL ownership"', "BQL trace enable control")
    require(ui, '"Clear BQL Trace"', "BQL trace clear control")
    require(ui, '"BQL Ownership Trace\\n', "snapshot BQL trace section")

    # v3.06/307 UI-side BQL owner attribution. The generic xemu.c lock wrapper
    # remains the low-level BQL callsite, while the UI paths label the next
    # acquisition and HUD/Debug Tools code records the active owner substage.
    require(bql_hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_HUD_UPDATE",
            "UI BQL context enum")
    require(bql_hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_TICK",
            "Debug Tools BQL substage enum")
    require(lock_common, "lock_trace_next_context_tls", "thread-local next BQL context")
    require(lock_common, "owner_longest_stage_ns", "longest BQL owner stage timing")
    require(lock_common_h, "owner_stage_elapsed_at_attempt_ns",
            "canonical BQL owner-stage timing ABI")
    require(ui, "BqlTraceContextName", "BQL context presentation")
    require(ui, "BqlTraceStageName", "BQL stage presentation")
    require(ui, "kRecentEventThresholdNs = 25ULL",
            "25 ms BQL Recent Events threshold")
    require(ui, 'AddEvent(now_ms, "BQL", os.str());',
            "BQL Recent Events reporting")
    for tag in (
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_VBLANK",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_CREATE",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_HUD_UPDATE",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_DESTROY",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_SDL_EVENT",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_COMMIT",
        "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_INIT",
    ):
        require(xemu_c, tag, f"xemu.c BQL context tag {tag}")
    # Host-poll preparation is lock-free and no longer has a trace context.
    # Surviving context IDs retain their prior numeric values.
    forbid(bql_hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_PREPARE",
           "retired input-prepare trace context")
    require(bql_hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_COMMIT = 7",
            "stable input-commit context ID")
    require(bql_hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_INIT = 8",
            "stable input-init context ID")
    for stage in (
        "XEMU_DEBUG_TOOLS_BQL_STAGE_HUD_CORE",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_TICK",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT",
    ):
        require(main_cc, stage, f"main.cc BQL owner stage {stage}")
    detached_cc = (debug / "detached-tools.cc").read_text(encoding="utf-8")
    # Detached frames no longer own BQL, so their historical owner-stage IDs are
    # retired. The active SDL-event stage retains its previous numeric value.
    forbid(detached_cc, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_DETACHED_BUILD",
           "obsolete detached-frame BQL acquisition stage")
    for dead_stage in (
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_DETACHED_BUILD",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CURRENT_GAME",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_HDD_DIRECTORY",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CHEAT_ENGINE",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_MEMORY_TOOLS",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_DIAGNOSTICS",
    ):
        forbid(bql_hook, dead_stage, f"retired detached BQL stage {dead_stage}")
    require(bql_hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT = 4",
            "stable Debug Tools SDL-event stage ID")


    # v2.98 MMIO Dispatch Trace: only tiny begin/end observations live in the
    # TCG CPU MMIO helpers. Region resolution, timing threshold, ring storage
    # and snapshot/UI analysis remain under Diagnostics.
    require(cputlb, "mmio-trace-hook.h", "MMIO observation hook include")
    if cputlb.count("xemu_debug_tools_mmio_trace_begin(") != 4:
        raise AssertionError("expected four CPU MMIO trace begin hooks")
    if cputlb.count("xemu_debug_tools_mmio_trace_end(&mmio_trace_scope);") != 4:
        raise AssertionError("expected four CPU MMIO trace end hooks")
    require(cputlb, "XEMU_DEBUG_TOOLS_MMIO_ACCESS_READ", "MMIO read observation")
    require(cputlb, "XEMU_DEBUG_TOOLS_MMIO_ACCESS_WRITE", "MMIO write observation")
    for token in ("XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY", "committed_sequence_plus_one",
                  "memory_region_name(", "object_get_typename("):
        forbid(cputlb, token, "MMIO trace implementation in accel/tcg/cputlb.c")
    require(mmio, "XEMU_DEBUG_TOOLS_MMIO_TRACE_LONG_NS", "long MMIO threshold")
    require(mmio, "committed_sequence_plus_one", "lock-free MMIO ring commit")
    require(mmio, "while (mr != NULL && mr->alias != NULL)", "MMIO alias resolution")
    require(mmio, "memory_region_name(mr)", "MemoryRegion name capture")
    require(mmio, "object_get_typename(OBJECT(mr->owner))", "MemoryRegion owner type capture")
    require(mmio, "cpu->cc->get_pc", "MMIO guest PC capture")
    forbid(mmio_hook, "QemuMutex", "MMIO trace state in hook contract")
    require(mmio_stub, "xemu_debug_tools_mmio_trace_begin",
            "disabled-profile MMIO no-op hook")
    require(backend, 'mmio-trace.h', "Diagnostics MMIO trace bridge")
    require(backend, "xemu_debug_tools_mmio_trace_snapshot",
            "MMIO trace snapshot bridge")
    require(backend_h, "XemuDiagnosticsMmioTraceEvent",
            "frontend-safe MMIO trace ABI")
    require(ui, '"Record long MMIO dispatches"', "MMIO trace enable control")
    require(ui, '"Clear MMIO Trace"', "MMIO trace clear control")
    require(ui, '"MMIO Dispatch Trace\\n', "snapshot MMIO trace section")
    require(ui, "Worst MMIO MemoryRegion", "MMIO region analysis export")
    require(ui, "Worst MMIO guest VA/PA", "MMIO address analysis export")
    require(ui, "xemu_diagnostics_mmio_trace_set_enabled(1);",
            "QEMU dispatch auto-arms MMIO trace")

    # v2.99 PGRAPH Lock Ownership Trace: every active d->pgraph.lock/pg->lock
    # acquisition goes through the tiny observed wrapper, while owner state,
    # method context, ring storage, analysis and UI remain under Diagnostics.
    require(pgraph_h, "pgraph-lock-trace-hook.h", "PGRAPH lock hook include")
    require(pgraph_h, "PGRAPH_LOCK(pg)", "PGRAPH observed lock macro")
    require(pgraph_h, "PGRAPH_UNLOCK(pg)", "PGRAPH observed unlock macro")
    require(pgraph_h, "xemu_debug_tools_pgraph_lock_trace_lock_attempt",
            "PGRAPH attempt observation")
    require(pgraph_h, "xemu_debug_tools_pgraph_lock_trace_unlock_begin",
            "PGRAPH release observation")
    require(pgraph_c, "xemu_debug_tools_pgraph_lock_trace_method_enter",
            "PGRAPH method context enter observation")
    require(pgraph_c, "xemu_debug_tools_pgraph_lock_trace_method_exit",
            "PGRAPH method context exit observation")
    require(pfifo_c, "PGRAPH_LOCK(&d->pgraph);",
            "PFIFO PGRAPH lock observed")

    # All active users of the primary PGRAPH mutex must go through the observed
    # wrapper. Ignore comments so the preserved historical commented-out raw
    # mutex examples do not count as active lock operations. renderer_lock is a
    # separate mutex and intentionally remains outside this trace.
    pgraph_mutex_users = (
        "hw/xbox/nv2a/nv2a.c",
        "hw/xbox/nv2a/pfifo.c",
        "hw/xbox/nv2a/pgraph/pgraph.c",
        "hw/xbox/nv2a/pgraph/gl/renderer.c",
        "hw/xbox/nv2a/pgraph/gl/surface.c",
        "hw/xbox/nv2a/pgraph/null/renderer.c",
        "hw/xbox/nv2a/pgraph/vk/renderer.c",
        "hw/xbox/nv2a/pgraph/vk/surface.c",
    )
    raw_primary_lock = re.compile(
        r"qemu_mutex_(?:lock|unlock)\s*\(\s*&(?:d->pgraph\.lock|pg->lock)\s*\)"
    )
    for rel in pgraph_mutex_users:
        text = (root / rel).read_text(encoding="utf-8")
        no_block_comments = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
        active_text = "\n".join(line.split("//", 1)[0] for line in no_block_comments.splitlines())
        if raw_primary_lock.search(active_text):
            raise AssertionError(
                f"active primary PGRAPH mutex bypasses observed wrapper in {rel}"
            )

    pgraph_h_no_comments = re.sub(r"/\*.*?\*/", "", pgraph_h, flags=re.S)
    pgraph_h_active = "\n".join(
        line.split("//", 1)[0] for line in pgraph_h_no_comments.splitlines()
    )
    if pgraph_h_active.count("qemu_mutex_lock(&pg->lock);") != 1 or \
       pgraph_h_active.count("qemu_mutex_unlock(&pg->lock);") != 1:
        raise AssertionError(
            "primary PGRAPH raw mutex boundary must exist exactly once inside the observed wrapper"
        )
    require(pgraph_lock, "XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS",
            "long PGRAPH wait/hold threshold")
    require(pgraph_lock, "committed_sequence_plus_one",
            "lock-free PGRAPH trace ring")
    require(pgraph_lock, "owner_method_graphics_class",
            "PGRAPH method/class owner context")
    require(pgraph_lock, "pgraph_lock_trace_capture_state",
            "PGRAPH renderer/wait-state capture")
    forbid(pgraph_lock_hook, "QemuMutex",
           "PGRAPH trace state in hook contract")
    require(pgraph_lock_stub, "xemu_debug_tools_pgraph_lock_trace_lock_attempt",
            "disabled-profile PGRAPH lock no-op hook")
    require(backend, 'pgraph-lock-trace.h',
            "Diagnostics PGRAPH lock trace bridge")
    require(backend, "xemu_debug_tools_pgraph_lock_trace_snapshot",
            "PGRAPH lock trace snapshot bridge")
    require(backend_h, "XemuDiagnosticsPgraphLockTraceEvent",
            "frontend-safe PGRAPH lock trace ABI")
    require(ui, '"Record PGRAPH lock ownership"',
            "PGRAPH lock trace enable control")
    require(ui, '"Clear PGRAPH Lock Trace"',
            "PGRAPH lock trace clear control")
    require(ui, '"PGRAPH Lock Ownership Trace',
            "snapshot PGRAPH lock trace section")
    require(ui, "Worst PGRAPH lock hold ns",
            "PGRAPH lock analysis export")
    require(ui, "Owner method at wait attempt",
            "PGRAPH method context analysis export")
    require(ui, "xemu_diagnostics_pgraph_lock_trace_set_enabled(1);",
            "QEMU dispatch auto-arms PGRAPH lock trace")

    # v3.00 PGRAPH Draw-End Stage Trace: core code emits only stage
    # boundaries; TLS buffering, >=5 ms filtering, ring storage and analysis
    # remain physically under Diagnostics.
    require(pgraph_c, "pgraph-draw-trace-hook.h",
            "PGRAPH draw trace generic-method hook include")
    require(pgraph_gl_draw, "pgraph-draw-trace-hook.h",
            "PGRAPH draw trace OpenGL hook include")
    require(pgraph_c, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL",
            "SET_BEGIN_END total draw stage")
    require(pgraph_gl_draw, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_GL_FLUSH_DRAW",
            "OpenGL flush-draw stage")
    require(pgraph_gl_draw, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_GL_MULTI_DRAW_ARRAYS",
            "OpenGL multi-draw stage")
    require(pgraph_gl_draw, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_GL_DRAW_ELEMENTS",
            "OpenGL draw-elements stage")
    require(pgraph_gl_draw, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_GL_DRAW_ARRAYS",
            "OpenGL draw-arrays stage")
    require(pgraph_draw, "XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS",
            "long draw threshold")
    require(pgraph_draw, "PGRAPH_DRAW_TRACE_TLS_EVENTS",
            "per-draw TLS stage buffer")
    require(pgraph_draw, "committed_sequence_plus_one",
            "lock-free PGRAPH draw trace ring")
    require(pgraph_draw, "total_ns >= XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS",
            "commit detailed stages only for long draws")
    forbid(pgraph_draw_hook, "QemuMutex",
           "PGRAPH draw trace state in hook contract")
    require(pgraph_draw_stub, "xemu_debug_tools_pgraph_draw_trace_stage_begin",
            "disabled-profile PGRAPH draw no-op hook")
    require(backend, 'pgraph-draw-trace.h',
            "Diagnostics PGRAPH draw trace bridge")
    require(backend_h, "XemuDiagnosticsPgraphDrawTraceEvent",
            "frontend-safe PGRAPH draw trace ABI")
    require(ui, '"Record long PGRAPH draw-end stages"',
            "PGRAPH draw trace enable control")
    require(ui, '"PGRAPH Draw-End Stage Trace\\n',
            "snapshot PGRAPH draw trace section")
    require(ui, "Worst draw stage breakdown",
            "PGRAPH draw stage analysis export")
    require(ui, "xemu_diagnostics_pgraph_draw_trace_set_enabled(1);",
            "QEMU dispatch auto-arms PGRAPH draw trace")

    # Global Diagnostics capture hotkeys and first-open safety. F3 mirrors the
    # existing Check All recorder set and F4 queues a fresh timestamped snapshot.
    # Snapshot serialization/file I/O is performed only by a post-present callback,
    # while the detached Diagnostics GL/ImGui resources are precreated at startup.
    for token in (
        "ImGuiKey_F3", "ImGuiKey_F4", "HandleHotkeys(now_ms);",
        "ImGui::GetCurrentContext() == nullptr",
        "AllRecordingOptionsEnabled()", "SetAllRecordingOptionsEnabled(enable)",
        "QueueSnapshotSave(now_ms, true)", "m_save_snapshot_requested = true;",
        "void DiagnosticsWindow::ProcessDeferredActions()",
        "Global hotkeys: F3 toggles Check All Recording Options",
    ):
        require(ui, token, "Diagnostics global hotkey/deferred-save behavior")
    require(hh, "void ProcessDeferredActions();",
            "Diagnostics deferred-action public hook")
    require(registration, "debug_tools_register_deferred_action",
            "Diagnostics post-present callback registration")
    require(registration, "DrawDiagnosticsDetached,\n        500,\n        true,",
            "startup Diagnostics detached-window precreate opt-in")
    require(module_h, "debug_tools_register_deferred_action",
            "generic Debug Tools deferred callback API")
    require(facade, "g_deferred_callbacks",
            "generic Debug Tools deferred callback storage")
    require(facade, "void debug_tools_process_deferred_actions()",
            "generic Debug Tools deferred callback runner")
    require(facade_h, "debug_tools_precreate_detached_windows",
            "detached precreate facade")
    require(detached_h, "bool precreate = false;",
            "detached registration precreate flag")
    require(detached, "void detached_tools_precreate_windows()",
            "detached startup precreate implementation")
    require(detached, "CreateToolWindow(tool)",
            "startup detached resource creation")
    forbid(main_cc, "InitializeStyle();\n    debug_tools_precreate_detached_windows();",
           "detached-window precreate from QEMU display-init thread")
    require(main_cc, "static bool detached_windows_precreated = false;",
            "one-time UI-thread detached precreate guard")
    require(main_cc, "debug_tools_precreate_detached_windows();\n        detached_windows_precreated = true;",
            "post-present UI-thread Diagnostics precreate")
    require(main_cc, "void xemu_hud_process_deferred_actions()",
            "xui post-present bridge")
    require(hud_h, "xemu_hud_process_deferred_actions",
            "C-facing post-present bridge declaration")
    require(xemu_c, "if (!playback_only) {",
            "modal playback-only deferred-work guard")
    require(xemu_c, "xemu_hud_process_deferred_actions();",
            "post-present deferred Debug Tools call")

    maybe_auto = re.search(
        r"void DiagnosticsWindow::MaybeAutoSave\([^)]*\)\s*\{(?P<body>.*?)\n\}",
        ui, re.S,
    )
    if not maybe_auto:
        raise AssertionError("missing DiagnosticsWindow::MaybeAutoSave body")
    require(maybe_auto.group("body"), "m_auto_save_requested = true;",
            "rolling save deferred request")
    forbid(maybe_auto.group("body"), "SaveSnapshotToPath",
           "rolling snapshot file I/O while HUD/BQL is held")

    # 306 introduced the generic worker/input lease. 308 moves the entire
    # Open Snapshots Folder request out of the BQL-held detached Draw() path:
    # Draw only sets a pending flag, ProcessDeferredActions() consumes it
    # post-present, and the worker owns directory creation/file-manager launch.
    # The worker owns filesystem preparation, while the completion callback
    # restores the proven SDL_OpenURL folder launch on its required UI thread.
    require(facade_h, "debug_tools_queue_background_job",
            "generic Debug Tools background-job API")
    require(facade_h, "preserve_gamepad_input_while_unfocused",
            "background input-preservation job option")
    require(facade, 'g_thread_try_new(\n        "xemu-debug-worker"',
            "long-lived Debug Tools worker thread")
    require(facade, "ProcessBackgroundCompletions();",
            "UI-thread worker completion dispatch")
    require(facade, "SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS",
            "temporary external-action gamepad lease")
    require(facade, "SDL_EVENT_WINDOW_FOCUS_LOST",
            "external-action focus-loss observation")
    require(facade, "SDL_EVENT_WINDOW_FOCUS_GAINED",
            "external-action focus-return restoration")
    require(ui, "OpenSnapshotsFolderWorker",
            "Diagnostics background folder worker")
    completion = extract_function(
        ui, "void DiagnosticsWindow::OpenSnapshotsFolderComplete(void *opaque)")
    require(completion, "XemuDebugOutput::OpenDirectory(",
            "post-present main-thread SDL folder launch")
    require(ui, "debug_tools_queue_background_job(",
            "Diagnostics folder job queueing")
    require(ui, "m_open_snapshots_folder_requested = true;",
            "BQL-held Draw only queues folder-open request")
    deferred = extract_function(ui, "void DiagnosticsWindow::ProcessDeferredActions()")
    require(deferred, "if (m_open_snapshots_folder_requested)",
            "post-present folder request consumption")
    require(deferred, "OpenSnapshotsFolder();",
            "post-present folder job start")
    draw = extract_function(ui, "void DiagnosticsWindow::Draw(bool detached)")
    forbid(draw, "OpenSnapshotsFolder();",
           "folder open start from BQL-held detached Draw path")
    worker = extract_function(ui, "void DiagnosticsWindow::OpenSnapshotsFolderWorker(void *opaque)")
    require(worker, "EnsureDirectory(",
            "worker-owned Snapshots directory creation")
    require(ui, "Open Snapshots Folder status:",
            "snapshot-exported folder launch result")
    require(ui, "external input lease: %s",
            "Diagnostics worker/input-lease status display")
    paths = (debug / "debug-output-paths.hh").read_text(encoding="utf-8")
    require(paths, "SDL_OpenURL(uri)",
            "main-thread SDL folder launch")
    forbid(worker, "SDL_OpenURL(",
           "main-thread-only SDL URL launch from worker")
    forbid(extract_function(ui, "void DiagnosticsWindow::OpenSnapshotsFolder()"),
           "SDL_OpenURL", "main-thread-only SDL URL launch from Diagnostics folder path")

    # The latest reported failure was Meson clock skew caused by a Windows ZIP
    # timestamp appearing in the future inside Linux. Clamp only future mtimes
    # in the disposable Docker source copy before source packaging/build setup.
    require(docker, "Source timestamp normalization:", "timestamp clamp log")
    require(docker, "if stat.st_mtime > now + 1.0:", "future-only timestamp clamp")
    require(docker, "os.utime(path", "timestamp clamp operation")
    require(docker, "$OUT/logs/source-timestamp-normalization.txt",
            "timestamp normalization build artifact")

    # Core/UI source may include the reviewed tiny BQL observation contract, but
    # no Diagnostics implementation/state may leak outside the add-on.
    bql_hook_include = '#include "xui/debug-tools/addons/diagnostics/bql-trace-hook.h"'
    main_bql_hook_include = '#include "debug-tools/addons/diagnostics/bql-trace-hook.h"'
    for rel in ("ui/xemu.c", "ui/xui/main.cc", "ui/xui/menubar.cc", "ui/xui/actions.cc"):
        text = (root / rel).read_text(encoding="utf-8")
        text = text.replace(bql_hook_include, "").replace(main_bql_hook_include, "")
        forbid(text, "diagnostics", f"Diagnostics implementation leak into {rel}")

    print("PASS: v3.04 Diagnostics physical add-on + PTIMER/QEMU timer/slow-timer/OHCI/input-poll/BQL/MMIO/PGRAPH trace isolation invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
