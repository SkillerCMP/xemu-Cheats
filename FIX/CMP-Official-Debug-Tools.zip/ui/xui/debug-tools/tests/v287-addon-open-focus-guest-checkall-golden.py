#!/usr/bin/env python3
"""Regression guard for add-on Open/Focus menu semantics and Guest Input Check All."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, needle: str, message: str) -> None:
    if needle not in text:
        raise AssertionError(message)


def forbid(text: str, needle: str, message: str) -> None:
    if needle in text:
        raise AssertionError(message)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    facade = (debug / "debug-tools.cc").read_text(encoding="utf-8")
    detached_hh = (debug / "detached-tools.hh").read_text(encoding="utf-8")
    detached = (debug / "detached-tools.cc").read_text(encoding="utf-8")
    diagnostics = (debug / "addons/diagnostics/diagnostics.cc").read_text(
        encoding="utf-8"
    )

    # All five top-level registered add-ons use one open/focus menu behavior.
    require(facade, "detached_tools_open_or_focus(entry.open);",
            "Debug menu entries do not route through detached open/focus")
    require(facade, "ImGui::MenuItem(entry.label, nullptr, *entry.open)",
            "Debug menu does not use non-toggling selected-state MenuItem")
    forbid(facade, "ImGui::MenuItem(entry.label, nullptr, entry.open);",
           "legacy pointer MenuItem can still toggle-close detached add-ons")

    require(detached_hh, "void detached_tools_open_or_focus(bool *open);",
            "detached open/focus API declaration missing")
    for needle in (
        "*open = true;",
        "return entry.open == open;",
        "SDL_ShowWindow(tool->window);",
        "SDL_RestoreWindow(tool->window);",
        "SDL_RaiseWindow(tool->window);",
    ):
        require(detached, needle, f"detached open/focus behavior missing: {needle}")

    # Guest Input must participate in the live Check All state, setter and Clear All.
    require(diagnostics, "XemuDiagnosticsGuestInputConsumerTraceStatus guest_input_consumer{};",
            "Guest Input status missing from Check All")
    require(diagnostics, "guest_input_consumer.enabled",
            "Guest Input enabled state missing from Check All result")
    require(diagnostics, "xemu_diagnostics_guest_input_consumer_trace_set_enabled(value);",
            "Guest Input recorder missing from Check All setter")
    require(diagnostics, "xemu_diagnostics_guest_input_consumer_trace_clear();",
            "Guest Input recorder missing from Clear All")

    print("PASS: add-on menu Open/Focus + Guest Input Check All/Clear All")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
