#!/usr/bin/env python3
"""Compile actual RAW executor functions, verify guide examples, and compare Type 6
against the exact v3.12 reference. Memory/CPU IO is a deterministic test backend;
this is not an emulator/platform runtime test. F0/F2 assembly is tested separately.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

from v287_source_test_utils import extract_function

HARNESS = r'''
#include <algorithm>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <map>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

struct XemuCheatAsmLine { int source_line = 0; std::string text; };
class CheatEngineWindow {
public:
    enum class GuestAddressSpace { Physical, Virtual };
    struct RawCode {
        uint32_t command = 0, value = 0;
        int source_line = 0;
        std::string source;
        std::vector<XemuCheatAsmLine> f_body;
        uint8_t f_final_valid_bytes = 0;
    };
    struct CheatBlock { std::vector<RawCode> codes; };
    struct AddressContext {
        GuestAddressSpace space = GuestAddressSpace::Virtual;
        uint32_t base = 0, remaining = 0;
        bool until_end = false;
    };
    struct SwitchState { bool previous_condition = false, on = false; };
    struct FHookState { size_t owner_block = 0; bool installed = false; };
    struct Access {
        bool write; GuestAddressSpace space; uint32_t address; size_t size;
        std::vector<uint8_t> bytes;
        bool operator==(const Access &o) const {
            return std::tie(write, space, address, size, bytes) ==
                   std::tie(o.write, o.space, o.address, o.size, o.bytes);
        }
    };
    std::string m_last_runtime_message;
    bool m_code_aware_skip = false;
    std::map<uint64_t, SwitchState> m_switches;
    std::map<uint64_t, FHookState> m_f_hooks;
    std::vector<AddressContext> m_address_context_scratch;
    std::vector<uint64_t> m_active_f_hooks_scratch;
    std::map<uint64_t, uint8_t> memory;
    std::vector<Access> accesses;
    bool scripted_mode = false, fail_write = false;
    size_t read_number = 0, fail_read_at = size_t(-1);
    std::vector<uint32_t> scripted;

    static uint64_t Key(GuestAddressSpace space, uint32_t address) {
        return (uint64_t(space == GuestAddressSpace::Virtual) << 32) | address;
    }
    bool ReadGuest(GuestAddressSpace space, uint32_t address, void *buffer, size_t size) {
        accesses.push_back({false, space, address, size, {}});
        const size_t call = read_number++;
        if (call == fail_read_at) return false;
        auto *out = static_cast<uint8_t *>(buffer);
        if (scripted_mode) {
            if (size != 4 || call >= scripted.size())
                throw std::runtime_error("unexpected scripted read");
            for (size_t i = 0; i < size; ++i) out[i] = uint8_t(scripted[call] >> (i * 8));
        } else {
            for (size_t i = 0; i < size; ++i) {
                auto it = memory.find(Key(space, address + uint32_t(i)));
                out[i] = it == memory.end() ? 0 : it->second;
            }
        }
        return true;
    }
    bool WriteGuest(GuestAddressSpace space, uint32_t address, const void *buffer, size_t size) {
        const auto *in = static_cast<const uint8_t *>(buffer);
        accesses.push_back({true, space, address, size, std::vector<uint8_t>(in, in + size)});
        if (fail_write) return false;
        for (size_t i = 0; i < size; ++i) memory[Key(space, address + uint32_t(i))] = in[i];
        return true;
    }
    bool ExecuteTypeF(size_t, size_t, const RawCode &, GuestAddressSpace,
                      uint32_t, std::vector<uint64_t> &) {
        throw std::runtime_error("Type-F hook runtime is outside this isolated RAW test");
    }
    void DeactivateFHook(uint64_t) {
        throw std::runtime_error("unexpected F-hook in isolated RAW test");
    }
    // DECLARATIONS
};
using Engine = CheatEngineWindow;
using Space = Engine::GuestAddressSpace;
using Block = Engine::CheatBlock;
using Raw = Engine::RawCode;
static size_t compared = 0, examples = 0;
static void Check(bool good, const std::string &what) {
    if (!good) throw std::runtime_error(what);
}
static Raw Code(uint32_t command, uint32_t value, int line = 1) {
    Raw r; r.command = command; r.value = value; r.source_line = line; return r;
}
static std::vector<uint8_t> Hex(const std::string &text) {
    Check(text.size() % 2 == 0, "odd test hex length");
    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < text.size(); i += 2)
        bytes.push_back(uint8_t(std::stoul(text.substr(i, 2), nullptr, 16)));
    return bytes;
}
static void Set(Engine &e, Space s, uint32_t a, const std::string &hex) {
    auto bytes = Hex(hex);
    for (size_t i = 0; i < bytes.size(); ++i) e.memory[Engine::Key(s, a + uint32_t(i))] = bytes[i];
}
static void Expect(Engine &e, Space s, uint32_t a, const std::string &hex, const char *id) {
    auto bytes = Hex(hex);
    for (size_t i = 0; i < bytes.size(); ++i) {
        auto it = e.memory.find(Engine::Key(s, a + uint32_t(i)));
        const uint8_t actual = it == e.memory.end() ? 0 : it->second;
        Check(actual == bytes[i], std::string("example memory mismatch: ") + id);
    }
}
static Block Parse(Engine &e, const std::string &text) {
    Block b; std::istringstream input(text); std::string line; int n = 0;
    while (std::getline(input, line)) {
        Raw r;
        Check(e.ParseCodeLine(line, r, ++n), "guide code pair failed actual parser: " + line);
        b.codes.push_back(std::move(r));
    }
    return b;
}
'''

DIFFERENTIAL = r'''
static void ComparePointer(const Block &block, size_t index, Space space,
                           uint32_t base, const std::vector<uint32_t> &reads,
                           size_t fail_at = size_t(-1), bool fail_write = false) {
    Engine current, reference;
    current.scripted_mode = reference.scripted_mode = true;
    current.scripted = reference.scripted = reads;
    current.fail_read_at = reference.fail_read_at = fail_at;
    current.fail_write = reference.fail_write = fail_write;
    current.m_last_runtime_message = reference.m_last_runtime_message = "unchanged";
    size_t current_next = index + 1, reference_next = index + 1;
    const bool a = current.ExecutePointer(block, index, space, base, current_next);
    const bool b = reference.ExecutePointerReference(block, index, space, base, reference_next);
    Check(a == b && current_next == reference_next &&
          current.m_last_runtime_message == reference.m_last_runtime_message &&
          current.memory == reference.memory && current.accesses == reference.accesses &&
          current.read_number == reference.read_number,
          "Type-6 v3.12 equivalence failed at case " + std::to_string(compared));
    ++compared;
}
static void PointerCases() {
    std::mt19937 random(0xC0313u);
    for (uint32_t count = 0; count <= 256; ++count) {
        const uint32_t real_count = count == 0 ? 1 : count;
        for (uint32_t size = 0; size < 3; ++size) {
            for (Space space : {Space::Virtual, Space::Physical}) {
                const size_t index = random() % 5;
                Block b;
                for (size_t n = 0; n < index; ++n) b.codes.push_back(Code(random(), random()));
                b.codes.push_back(Code(0x60000000u | (random() & 0x0FFFFFFFu), random(), 37));
                b.codes.push_back(Code((size << 16) | count, random(), 38));
                for (size_t n = 0; n < real_count / 2; ++n)
                    b.codes.push_back(Code(random(), random(), int(39 + n)));
                std::vector<uint32_t> reads(real_count);
                for (auto &v : reads) v = uint32_t(random()) | 0x80000000u;
                const uint32_t base = random();
                ComparePointer(b, index, space, base, reads);
                ComparePointer(b, index, space, base, reads, size_t(-1), true);
                for (size_t at : {size_t(0), size_t(real_count / 2), size_t(real_count - 1)}) {
                    ComparePointer(b, index, space, base, reads, at);
                    auto zero = reads; zero[at] = 0;
                    ComparePointer(b, index, space, base, zero);
                }
                auto truncated = b;
                truncated.codes.pop_back();
                ComparePointer(truncated, index, space, base, reads);
                auto invalid = b;
                invalid.codes[index + 1].command = ((3 + random() % 13) << 16) | count;
                ComparePointer(invalid, index, space, base, reads);
            }
        }
    }
    for (uint32_t count : {257u, 258u, 32768u, 65535u}) {
        for (Space space : {Space::Virtual, Space::Physical}) {
            Block b;
            b.codes = {Code(0x6FFFFFFFu, 0xFFFFFFFFu), Code(0x00020000u | count, 0xFFFFFFFFu)};
            ComparePointer(b, 0, space, 0xFFFFFFFFu, {});
        }
    }
    // Explicit overflow, odd/even packed offsets, and exact final write sizes.
    for (uint32_t size = 0; size < 3; ++size) {
        Block b;
        b.codes = {Code(0x6FFFFFFFu, 0xDEADBEEFu), Code((size << 16) | 3u, 0xFFFFFFFFu),
                   Code(0x80000000u, 0x7FFFFFFFu)};
        ComparePointer(b, 0, Space::Virtual, 0xFFFFFFFEu,
                       {0xFFFFFFFFu, 0x80000000u, 0xFFFFFFFFu});
    }
}
static void F1AndParserCases() {
    Engine e; Raw raw;
    Check(e.ParseCodeLine("$20001020 000003E7 // inline comment", raw, 1), "RAW // comment");
    Check(!e.ParseCodeLine("$20001020 000003E7 ; not an inline RAW comment", raw, 1), "RAW semicolon rule");
    raw.f_final_valid_bytes = 5;
    raw.f_body = {{1, "$B8E70300 00000000"}};
    std::vector<uint8_t> bytes; std::string error; int line = 0;
    Check(e.ParseFRawHex(raw, bytes, error, line), "F1 guide example parse");
    Check(bytes == Hex("B8E7030000"), "F1 guide example bytes");
    raw.f_body = {{1, "$B8E70300 00010000"}};
    Check(!e.ParseFRawHex(raw, bytes, error, line), "F1 nonzero tail rejection");
    uint8_t tail = 0;
    Check(e.ParseDeadcodeCount("00000005", tail) && tail == 5, "F1 tail parse");
    Check(!e.ParseDeadcodeCount("00000000", tail) && !e.ParseDeadcodeCount("00000009", tail),
          "F1 tail range rejection");
}
'''


def cpp_string(value: str) -> str:
    return json.dumps(value)


def memory_lines(items: list[dict], action: str, ident: str = '') -> list[str]:
    out = []
    for item in items:
        space = 'Virtual' if item['space'] == 'V' else 'Physical'
        args = f'e, Space::{space}, 0x{item["address"]}u, {cpp_string(item["bytes"])}'
        if action == 'Expect':
            args += ', ' + cpp_string(ident)
        out.append(f'    {action}({args});')
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='.')
    parser.add_argument('--compiler', default='g++')
    parser.add_argument('--sanitizers', action='store_true')
    args = parser.parse_args()
    dt = Path(args.root).resolve() / 'ui/xui/debug-tools'
    tests = dt / 'tests'
    source = '\n'.join((dt / name).read_text() for name in
                       ['cheat-engine-execute.cc', 'cheat-engine-source.cc', 'cheat-engine-fhooks.cc'])
    names = ['ReadValue', 'WriteValue', 'Type9Count', 'LogicalSpan', 'SkipLogicalCommands',
             'ExecuteBasicWrite', 'ExecuteArithmetic', 'ExecuteSerial', 'ExecuteCopy',
             'ExecutePointer', 'ExecuteBitwise', 'PrepareAddressContext', 'ExecuteRawBytes',
             'ExecuteConditional', 'ExecuteBlock', 'Trim', 'ParseCodeLine', 'ParseFRawHex',
             'ParseDeadcodeCount']
    functions = []
    for name in names:
        # Start from the actual definition, not a call or prototype.
        import re
        match = re.search(r'(?m)^([^\n]*\bCheatEngineWindow::' + name + r'\()', source)
        if not match:
            raise AssertionError(f'missing production definition: {name}')
        functions.append(extract_function(source, match.group(1)))
    reference = (tests / 'fixtures/v312-pointer-reference.inc').read_text().strip()
    if hashlib.sha256(reference.encode()).hexdigest() != 'f7d62f80b068698b4ea2b4ef8da3014c8bcd2e2fefd48d24aa57bbea556842a0':
        raise AssertionError('v3.12 Type-6 reference was changed')
    functions.append(reference.replace('::ExecutePointer(', '::ExecutePointerReference(', 1))
    declarations = '\n'.join(f.split('{', 1)[0].replace('CheatEngineWindow::', '').strip() + ';'
                             for f in functions)
    declarations = declarations.replace('uint32_t Type9Count(', 'static uint32_t Type9Count(')
    current = next(f for f in functions if '::ExecutePointer(' in f)
    if 'std::vector<uint32_t> offsets' in current or 'offsets.push_back' in current:
        raise AssertionError('per-execution pointer offset allocation returned')
    cpp = HARNESS.replace('// DECLARATIONS', declarations) + '\n' + '\n\n'.join(functions) + DIFFERENTIAL
    examples = json.loads((tests / 'fixtures/codetypes-examples.json').read_text())
    chunks = ['static void GuideExamples() {']
    for case in examples:
        ident = case['id']
        chunks += ['  { Engine e;', f'    auto b = Parse(e, {cpp_string(case["code"])});',
                   f'    e.m_code_aware_skip = {str(case.get("code_aware", False)).lower()};']
        chunks += memory_lines(case['initial'], 'Set')
        steps = case.get('steps', [{'before': [], 'expected': case['expected']}])
        for step in steps:
            chunks += memory_lines(step['before'], 'Set')
            chunks += ['    e.m_last_runtime_message.clear();', '    e.ExecuteBlock(0, b);']
            if 'error_contains' in case:
                chunks.append(f'    Check(e.m_last_runtime_message.find({cpp_string(case["error_contains"])}) != std::string::npos, {cpp_string(ident + " error")});')
            else:
                chunks.append(f'    Check(e.m_last_runtime_message.empty(), {cpp_string(ident + " runtime error")});')
            chunks += memory_lines(step['expected'], 'Expect', ident)
        chunks += ['    ++examples;', '  }']
    chunks += ['}', r'''
int main() {
    try {
        GuideExamples();
        F1AndParserCases();
        PointerCases();
        std::cout << "PASS: " << examples << " actual RAW-parser/executor guide and edge cases; "
                  << compared << " exact-v3.12 Type-6 differential cases; F1 bytes/tail and comment checks\n";
    } catch (const std::exception &e) {
        std::cerr << "FAIL: " << e.what() << '\n'; return 1;
    }
}
''']
    cpp += '\n'.join(chunks)
    with tempfile.TemporaryDirectory(prefix='xemu-v313-raw-semantics-') as tmp:
        path = Path(tmp) / 'test.cc'; exe = Path(tmp) / 'test'
        path.write_text(cpp)
        flags = ['-std=c++17', '-Wall', '-Wextra', '-Werror', '-O2']
        if args.sanitizers:
            flags += ['-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer']
        subprocess.run([args.compiler, *flags, str(path), '-o', str(exe)], check=True)
        subprocess.run([str(exe)], check=True)


if __name__ == '__main__':
    main()
