#!/usr/bin/env python3
"""v3.14c Folder-HDD overlay-first read and conservative host-addition merge guard."""
from __future__ import annotations
import argparse
from pathlib import Path


def req(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    d = root / "ui/xui/debug-tools/addons/Folder-HDD"
    c = (d / "folder-hdd.c").read_text(encoding="utf-8")
    sync = (d / "folder-hdd-sync.cc").read_text(encoding="utf-8")
    hdr = (d / "folder-hdd-sync.h").read_text(encoding="utf-8")

    # Effective reads must resolve complete Xbox-owned sectors before any host
    # backing read. The old base-read-then-overlay helper is intentionally gone.
    req(c, "static int cmp_effective_disk_read", "overlay-first effective reader")
    req(c, "Walk contiguous covered/uncovered runs instead of allocating", "allocation-free overlay/base run walk")
    req(c, "if (this_covered != covered)", "overlay/base run boundary")
    req(c, "cmp_disk_read(s, offset + first * CMP_SECTOR_SIZE", "gap base reader")
    if "cmp_overlay_apply" in c:
        raise AssertionError("dead base-read-then-overlay helper was retained")

    pread = c[c.index("cmp_folder_hdd_co_preadv"):c.index("cmp_folder_hdd_co_pwritev")]
    req(pread, "cmp_effective_disk_read", "guest block read uses effective reader")
    if "cmp_disk_read(s," in pread:
        raise AssertionError("guest block read still directly reads base before overlay")

    eff = c[c.index("bool cmp_folder_hdd_sync_effective_read"):c.index("static const char *const cmp_strong_runtime_opts")]
    req(eff, "cmp_effective_disk_read", "writeback FATX reader uses effective reader")
    req(eff, "cmp_effective_read_error_key", "thread-local detailed read error")
    req(c, "Folder-HDD could not %s host backing file", "host backing path/error detail")
    req(hdr, "cmp_folder_hdd_sync_effective_read_error", "detailed read-error bridge")
    req(sync, "cmp_folder_hdd_sync_effective_read_error", "staging consumes detailed read error")

    # Host-only additions may coexist with pending Xbox writes, but changes or
    # removals of baseline paths still block writeback. Same-path new files with
    # different bytes are also a conflict.
    req(sync, "HostWritebackAllowsAdditionsOnly", "addition-only compatibility check")
    req(sync, "return a.directory || (a.size == b.size && a.mtime == b.mtime);",
        "directory mtime false-conflict suppression")
    req(sync, "host path was removed while Xbox writes were pending", "host removal protection")
    req(sync, "host path changed while Xbox writes were pending", "host modification protection")
    req(sync, "host/Xbox file-addition conflict", "same-path addition protection")
    req(sync, "host-only addition%s preserved", "writeback status for preserved additions")

    # v3.14d supersedes the old C/E host-backed overlay layout with stable C/E
    # images. Keep the v3.14c conservative addition/conflict behavior while
    # ensuring the obsolete retained-C/E-overlay rescan guard is gone.
    req(c, 'CMP_C_IMAGE_FILENAME "C.img"', "image-backed C partition")
    req(c, 'CMP_E_IMAGE_FILENAME "E.img"', "image-backed E partition")
    if "committed guest FATX overlay must remain active" in c:
        raise AssertionError("obsolete host-backed C/E retained-layout guard survived v3.14d")

    print("PASS: v3.14c behavior retained under v3.14d image-backed C/E")


if __name__ == "__main__":
    main()
