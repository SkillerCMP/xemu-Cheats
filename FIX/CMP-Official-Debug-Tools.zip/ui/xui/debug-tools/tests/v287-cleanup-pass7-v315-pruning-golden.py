#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 7: v3.15 dead trace/API pruning guard."""
from __future__ import annotations

import argparse
from pathlib import Path


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root).resolve()
    dt = root / "ui/xui/debug-tools"

    hook = (dt / "addons/diagnostics/bql-trace-hook.h").read_text(encoding="utf-8")
    diag = (dt / "addons/diagnostics/diagnostics.cc").read_text(encoding="utf-8")
    xbe_h = (dt / "xbe-labels.hh").read_text(encoding="utf-8")
    xbe_cc = (dt / "xbe-labels.cc").read_text(encoding="utf-8")
    block_ref = (dt / "disc-block-ref.hh").read_text(encoding="utf-8")
    dbg_h = (dt / "backend/xemu-dbg.h").read_text(encoding="utf-8")
    cheat_h = (dt / "cheat-engine-memory.h").read_text(encoding="utf-8")

    # v3.15 removed every locked detached-frame build route. The BQL owner-stage
    # IDs that could only be emitted by those routes are dead and stay retired.
    dead_stages = (
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_DETACHED_BUILD",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CURRENT_GAME",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_HDD_DIRECTORY",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_CHEAT_ENGINE",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_MEMORY_TOOLS",
        "XEMU_DEBUG_TOOLS_BQL_STAGE_DETACHED_DIAGNOSTICS",
    )
    for token in dead_stages:
        forbid(hook, token, f"dead BQL stage {token}")
        forbid(diag, token, f"dead BQL stage presentation {token}")

    # Preserve the numeric values of the surviving IDs so cleanup is trace-ABI
    # neutral for all events that can still be emitted.
    require(hook, "XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT = 4",
            "stable SDL-event stage ID")
    forbid(hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_PREPARE",
           "dead host-input prepare context")
    require(hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_COMMIT = 7",
            "stable input-commit context ID")
    require(hook, "XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_INIT = 8",
            "stable input-init context ID")
    forbid(diag, 'return "UI_INPUT_PREPARE";', "dead input-prepare presentation")

    # PrimaryAt had no production caller after the display-label cursor cleanup.
    # Sorted label ordering remains authoritative and the tests model the same
    # exact-address first-label semantics directly.
    forbid(xbe_h, "PrimaryAt(", "dead XBE label lookup declaration")
    forbid(xbe_cc, "PrimaryAt(", "dead XBE label lookup implementation")
    require(xbe_cc, "void SortAndUnique(Database &db)", "authoritative label ordering")
    require(xbe_cc, "void Merge(Database &db, const std::vector<Label> &labels)",
            "authoritative label merge")

    # The retained BlockBackend owner exposes Get() and explicit truth testing;
    # the unused implicit raw-handle conversion must not return.
    require(block_ref, "XemuDiscBlockHandle Get() const", "explicit retained handle access")
    require(block_ref, "explicit operator bool() const", "explicit retained handle validity")
    forbid(block_ref, "operator XemuDiscBlockHandle() const",
           "unused implicit retained-handle conversion")

    # Backend READ/WRITE bits are authoritative. Its unused aggregate alias is
    # removed; the frontend's separately used access aggregate remains intact.
    require(dbg_h, "XEMU_DBG_WATCH_READ = 0x01", "backend watch read bit")
    require(dbg_h, "XEMU_DBG_WATCH_WRITE = 0x02", "backend watch write bit")
    forbid(dbg_h, "XEMU_DBG_WATCH_ACCESS", "unused backend watch aggregate")
    require(cheat_h, "XEMU_CHEAT_WATCH_ACCESS = XEMU_CHEAT_WATCH_READ | XEMU_CHEAT_WATCH_WRITE",
            "used frontend watch aggregate")

    print("PASS: Cleanup Pass 7 prunes v3.15-dead trace/API surface without changing live IDs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
