#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")

header = (DIAG / "guest-timer-deadline-trace.h").read_text(encoding="utf-8")
source = (DIAG / "guest-timer-deadline-trace.c").read_text(encoding="utf-8")
capture_h = (DIAG / "d3d-callback-capture.h").read_text(encoding="utf-8")
capture_c = (DIAG / "d3d-callback-capture.c").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
cpu_exec = (ROOT / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")

require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PAGE 0x00223000u", "dispatcher page")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC", "dispatcher event")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PRE_NS (2 * 1000 * 1000ULL)", "2 ms pre-due gate")
require(source, "now + XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PRE_NS >= due", "near-due dispatcher gate")
require(source, "page == XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PAGE", "conditional exact-PC split")
require(source, "qatomic_read(&g_guest_timer_deadline.callback_watch_armed)", "outstanding callback gate")
require(source, "dispatcher_current_pc_events", "per-attempt dispatcher PC count")
require(source, "dispatcher_last_good_pc_events", "good path summary")
require(source, "dispatcher_last_overdue_pc_events", "overdue path summary")
require(source, "dispatcher_last_recovered_pc_events", "recovered path summary")
require(source, "xemu_debug_tools_d3d_callback_capture_note_recovered", "transient auto-rearm notification")
require(capture_h, "transient_recoveries", "transient counter")
require(capture_c, "g_d3d_callback_capture.latched = 0;", "release transient one-shot")
require(capture_c, "snapshot.status.trigger.input_sequence", "recovery sequence match")
require(ui, 'return "D3D_DISPATCH_PC";', "dispatcher event export name")
require(ui, "D3D dispatcher good / overdue / recovered-overdue", "dispatcher summary export")
require(ui, "Transient auto-rearms", "auto-rearm UI/export")
require(ui, "00223000", "dispatcher watched-page disclosure")
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_should_single_step", "existing Patch 303 hook reused")
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_note_pc", "existing Patch 303 recorder hook reused")
forbid(source, "cpu_breakpoint", "breakpoint use")
forbid(source, "vm_stop", "guest pause")
forbid(source, "timer_mod", "timer modification")
forbid(source, "cpu_memory_rw_debug(cpu, address, bytes, sizeof(bytes), true)", "guest memory write")

print("PASS: Patch 305.1 D3D PTIMER ISR / callback dispatcher trace")
