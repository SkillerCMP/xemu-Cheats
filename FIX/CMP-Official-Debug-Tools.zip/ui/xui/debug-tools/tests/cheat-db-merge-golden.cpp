#include "../addons/cheat-db/cheat-db-format.hh"

#include <cassert>
#include <string>
#include <unordered_set>

using namespace XemuCheatDbFormat;

int main()
{
    const std::string local =
        "^1 = Hash: ABCDEF0123456789\r\n"
        "^2 = GameID: EA0049\r\n"
        "^3 = NAME: Def Jam Test\r\n\r\n"
        "!Player Codes:\r\n"
        "+Infinite Health\r\n"
        "%Credits: Local Copy\r\n"
        "$20001000 00000001\r\n\r\n"
        "+My Local Only Code\r\n"
        "$20001004 DEADBEEF\r\n"
        "!!\r\n";

    const std::string remote =
        "^1 = Hash: ABCDEF0123456789\n"
        "^2 = GameID: EA0049\n"
        "^3 = NAME: Def Jam Test\n\n"
        "!Player Codes:\n"
        "+Infinite Health\n"
        "%Credits: CheatDB\n"
        "$20001000 000003E7\n\n"
        "+Infinite Special\n"
        "$20001008 00000064\n"
        "!!\n"
        "!Unlocks:\n"
        "+:PREENTRY:Unlock Everything\n"
        "$20002000 00000001\n"
        "!!\n";

    Document l = ParseDocument(local);
    Document r = ParseDocument(remote);
    assert(l.header.title_id_valid);
    assert(l.header.title_id == 0x45410049u);
    assert(l.newline == "\r\n");
    assert(l.blocks.size() == 2);
    assert(r.blocks.size() == 3);
    assert(r.blocks[2].name == "Unlock Everything");

    std::unordered_set<std::string> selected;
    selected.insert(BlockIdentity(r.blocks[0]));
    selected.insert(BlockIdentity(r.blocks[1]));
    selected.insert(BlockIdentity(r.blocks[2]));
    const MergeResult merged = MergeSelected(l, r, selected);

    assert(merged.replaced == 1);
    assert(merged.added == 2);
    assert(merged.text.find("My Local Only Code") != std::string::npos);
    assert(merged.text.find("000003E7") != std::string::npos);
    assert(merged.text.find("Infinite Special") != std::string::npos);
    assert(merged.text.find("!Unlocks:") != std::string::npos);
    assert(merged.text.find("Unlock Everything") != std::string::npos);
    assert(merged.text.find("\r\n") != std::string::npos);

    Document final_doc = ParseDocument(merged.text);
    assert(final_doc.blocks.size() == 4);

    const std::string duplicates =
        "!Group:\n"
        "+Same Name\n$20000000 1\n"
        "+Same Name\n$20000004 2\n"
        "!!\n";
    Document d = ParseDocument(duplicates);
    assert(d.blocks.size() == 2);
    assert(d.blocks[0].ordinal == 0);
    assert(d.blocks[1].ordinal == 1);
    assert(BlockIdentity(d.blocks[0]) != BlockIdentity(d.blocks[1]));

    assert(ClassifyRemoteBlock(false, "", "REMOTE", "") == BlockCompareStatus::New);
    assert(ClassifyRemoteBlock(true, "SAME", "SAME", "") == BlockCompareStatus::Same);
    assert(ClassifyRemoteBlock(true, "OLD", "NEW", "OLD") == BlockCompareStatus::Updated);
    assert(ClassifyRemoteBlock(true, "LOCAL", "OLD", "OLD") == BlockCompareStatus::LocalModified);
    assert(ClassifyRemoteBlock(true, "LOCAL", "REMOTE", "OLD") == BlockCompareStatus::Conflict);
    assert(ClassifyRemoteBlock(true, "LOCAL", "REMOTE", "") == BlockCompareStatus::Conflict);
    return 0;
}
