#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DT = ROOT / "ui/xui/debug-tools"
DIAG = DT / "addons/diagnostics"
STUB = DT / "addons/stubs"


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise AssertionError(f"missing {label}: {needle}")


def forbid(text: str, needle: str, label: str) -> None:
    if needle in text:
        raise AssertionError(f"unexpected {label}: {needle}")


header = (DIAG / "guest-timer-deadline-trace.h").read_text(encoding="utf-8")
source = (DIAG / "guest-timer-deadline-trace.c").read_text(encoding="utf-8")
stub = (STUB / "guest-timer-deadline-trace-stub.c").read_text(encoding="utf-8")
backend_h = (DIAG / "diagnostics-backend.h").read_text(encoding="utf-8")
backend_c = (DIAG / "diagnostics-backend.c").read_text(encoding="utf-8")
ui_h = (DIAG / "diagnostics.hh").read_text(encoding="utf-8")
ui = (DIAG / "diagnostics.cc").read_text(encoding="utf-8")
meson = (DT / "meson.build").read_text(encoding="utf-8")
cpu_exec = (ROOT / "accel/tcg/cpu-exec.c").read_text(encoding="utf-8")

# Recorder contract: diagnostic-only, exact watched PCs, no guest patch writes.
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_PAGE 0x000D7000u", "InputBuffer watched page")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_PAGE   0x00216000u", "D3D watched page")
require(header, "XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TSC_HZ 733333333ULL", "Xbox TSC conversion")
for pc in ("0x000D7E53u", "0x000D7E5Bu", "0x000D7E5Du", "0x000D7E67u",
           "0x0021642Au", "0x0021643Du", "0x00216443u", "0x00216445u",
           "0x00216459u", "0x0021645Fu", "0x00216473u"):
    require(source, pc, f"watched PC {pc}")
require(source, "cpu_compute_eflags(env)", "architectural EFLAGS capture")
require(source, "cpu_memory_rw_debug", "targeted guest-memory capture")
require(source, "Keep instrumentation light enough not to create the timing failure", "low-perturbation memory sampling")
require(source, "guest_timer_signed_delta(requested, threshold)", "deadline delta calculation")
require(source, "event.relative_delay = ((uint64_t)event.esi << 32) | event.edi;", "relative delay capture")
forbid(source, "cpu_breakpoint", "breakpoint use")
forbid(source, "vm_stop", "guest pause")
forbid(source, "cpu_memory_rw_debug(cpu, address, bytes, sizeof(bytes), true)", "guest write")

# TCG integration: exact-PC capture is limited to watched pages and one-insn TBs.
require(cpu_exec, '#include "../../ui/xui/debug-tools/addons/diagnostics/guest-timer-deadline-trace.h"', "TCG hook include")
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_should_single_step", "watched-page single-step query")
require(cpu_exec, "s.cflags = (s.cflags & ~CF_COUNT_MASK) |", "one-instruction TB sizing")
require(cpu_exec, "CF_NO_GOTO_TB | CF_NO_GOTO_PTR | 1;", "no chaining + one instruction")
require(cpu_exec, "xemu_debug_tools_guest_timer_deadline_trace_note_pc", "exact-PC recorder call")

# Full/stub modular build coverage.
require(meson, "'addons/diagnostics/guest-timer-deadline-trace.c'", "full diagnostics source")
require(meson, "'addons/stubs/guest-timer-deadline-trace-stub.c'", "non-diagnostics stub")
require(stub, "xemu_debug_tools_guest_timer_deadline_trace_should_single_step", "stub single-step API")

# Preserve existing buffer IDs by appending the new recorder after Main Loop Lock.
require(backend_h,
        "XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER,\n    XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK,\n    XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE,",
        "append-only diagnostics buffer id")
require(backend_c, "XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE", "buffer bridge")
require(backend_c, "xemu_diagnostics_guest_timer_deadline_trace_set_enabled", "enable bridge")
require(backend_c, "xemu_diagnostics_get_guest_timer_deadline_trace", "snapshot bridge")

# UI/export/check-all integration.
require(ui_h, "XemuDiagnosticsView::State m_view", "export toggle")
require(ui, "Guest Timer / Deadline Correlation Trace (TCG)", "UI section")
require(ui, "Record InputBuffer -> D3D timer deadline correlation preset", "recorder checkbox")
require(ui, "Diagnostic only: does not patch timer behavior or pause the guest.", "no-fix warning")
require(ui, "xemu_diagnostics_guest_timer_deadline_trace_set_enabled(value);", "Check All integration")
require(ui, "xemu_diagnostics_guest_timer_deadline_trace_clear();", "Clear All integration")
require(ui, "Guest Timer / Deadline Correlation Trace (TCG, current research preset)", "snapshot export section")
require(ui, "deadline_delta_cycles", "exported deadline delta")
require(ui, "mem_1a80", "exported InputBuffer memory")
require(ui, "stack_20", "exported D3D stack argument")

print("PASS: Patch 303 guest timer/deadline correlation diagnostics")
