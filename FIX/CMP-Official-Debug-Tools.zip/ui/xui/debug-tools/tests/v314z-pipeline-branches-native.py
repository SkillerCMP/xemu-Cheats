#!/usr/bin/env python3
"""Compile actual pipeline cache-branch prefixes; Vulkan miss construction is stubbed.

The whole-file v3.14y frozen-token guard covers the remaining renderer code.
This isolated test checks observer pairing and branch/counter classification,
not Vulkan creation, GPU behavior or the game's audio/video synchronization.
"""
from __future__ import annotations
import argparse, pathlib, subprocess, tempfile
from v314y_vulkan_observer_test_utils import DRAW_PATH, function

# Frozen verbatim from the v3.14y baseline, never regenerated from the candidate.
BASELINE_PREFIXES = {'create_pipeline': 'static void create_pipeline(PGRAPHState *pg)\n{\n    NV2A_VK_DGROUP_BEGIN("Creating pipeline");\n\n    NV2AState *d = container_of(pg, NV2AState, pgraph);\n    PGRAPHVkState *r = pg->vk_renderer_state;\n\n    pgraph_vk_bind_textures(d);\n    pgraph_vk_bind_shaders(pg);\n\n    // FIXME: If nothing was dirty, don\'t even try creating the key or hashing.\n    //        Just use the same pipeline.\n    bool pipeline_dirty = check_pipeline_dirty(pg);\n\n    pgraph_clear_dirty_reg_map(pg);\n    // FIXME: We could clear less\n\n    if (r->pipeline_binding && !pipeline_dirty) {\n        NV2A_VK_DPRINTF("Cache hit");\n        NV2A_VK_DGROUP_END();\n        return;\n    }\n\n    PipelineKey key;\n    init_pipeline_key(pg, &key);\n    uint64_t hash = fast_hash((void *)&key, sizeof(key));\n\n    LruNode *node = lru_lookup(&r->pipeline_cache, hash, &key);\n    PipelineBinding *snode = container_of(node, PipelineBinding, node);\n    if (snode->pipeline != VK_NULL_HANDLE) {\n        NV2A_VK_DPRINTF("Cache hit");\n        r->pipeline_binding_changed = r->pipeline_binding != snode;\n        r->pipeline_binding = snode;\n        NV2A_VK_DGROUP_END();\n        return;\n    }\n\n', 'create_clear_pipeline': 'static void create_clear_pipeline(PGRAPHState *pg)\n{\n    PGRAPHVkState *r = pg->vk_renderer_state;\n\n    NV2A_VK_DGROUP_BEGIN("Creating clear pipeline");\n\n    PipelineKey key;\n    memset(&key, 0, sizeof(key));\n    key.clear = true;\n    init_render_pass_state(pg, &key.render_pass_state);\n\n    key.regs[0] = r->clear_parameter;\n\n    uint64_t hash = fast_hash((void *)&key, sizeof(key));\n    LruNode *node = lru_lookup(&r->pipeline_cache, hash, &key);\n    PipelineBinding *snode = container_of(node, PipelineBinding, node);\n\n    if (snode->pipeline != VK_NULL_HANDLE) {\n        NV2A_VK_DPRINTF("Cache hit");\n        r->pipeline_binding_changed = r->pipeline_binding != snode;\n        r->pipeline_binding = snode;\n        NV2A_VK_DGROUP_END();\n        return;\n    }\n\n'}

HARNESS=r'''
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-draw-trace-hook.h"
#define container_of(ptr,type,member) ((type *)((char *)(ptr)-offsetof(type,member)))
#define VK_NULL_HANDLE 0
#define NV2A_VK_DGROUP_BEGIN(...) ((void)0)
#define NV2A_VK_DGROUP_END() ((void)0)
#define NV2A_VK_DPRINTF(...) ((void)0)
typedef struct LruNode {int unused;} LruNode;
typedef struct RenderPassState {int value;} RenderPassState;
typedef struct PipelineKey {bool clear;RenderPassState render_pass_state;uint32_t regs[1];} PipelineKey;
typedef struct PipelineBinding {LruNode node;int pipeline;} PipelineBinding;
typedef struct PGRAPHVkState {PipelineBinding *pipeline_binding;int pipeline_cache;bool pipeline_binding_changed;uint32_t clear_parameter;} PGRAPHVkState;
typedef struct PGRAPHState {PGRAPHVkState *vk_renderer_state;} PGRAPHState;
typedef struct NV2AState {PGRAPHState pgraph;} NV2AState;
static unsigned ops[32],op_n,depth,trace_calls,outcomes[4],stage_counts[64];
static unsigned stack[32];static bool enabled,dirty;static PipelineBinding looked_up;
static void op(unsigned value){assert(op_n<32);ops[op_n++]=value;}
static void pgraph_vk_bind_textures(NV2AState *d){(void)d;op(1);}
static void pgraph_vk_bind_shaders(PGRAPHState *pg){(void)pg;op(2);}
static bool check_pipeline_dirty(PGRAPHState *pg){(void)pg;op(3);return dirty;}
static void pgraph_clear_dirty_reg_map(PGRAPHState *pg){(void)pg;op(4);}
static void init_pipeline_key(PGRAPHState *pg,PipelineKey *key){(void)pg;memset(key,0,sizeof(*key));op(5);}
static void init_render_pass_state(PGRAPHState *pg,RenderPassState *key){(void)pg;key->value=1;op(6);}
static uint64_t fast_hash(void *p,size_t size){(void)p;(void)size;op(7);return 42;}
static LruNode *lru_lookup(int *cache,uint64_t hash,PipelineKey *key){(void)cache;(void)hash;(void)key;op(8);return &looked_up.node;}
static void miss_path(void){op(9);}
void xemu_debug_tools_pgraph_draw_trace_stage_begin(unsigned stage,const void *pg,uint64_t v0,uint64_t v1){
    (void)pg;(void)v0;(void)v1;if(!enabled)return;assert(depth<32);stack[depth++]=stage;trace_calls++;stage_counts[stage]++;
}
void xemu_debug_tools_pgraph_draw_trace_stage_end(unsigned stage){if(!enabled)return;assert(depth && stack[--depth]==stage);trace_calls++;}
void xemu_debug_tools_pgraph_draw_trace_pipeline_cache(unsigned outcome){if(enabled){assert(outcome>0&&outcome<4);outcomes[outcome]++;}}
__FUNCTIONS__
int main(void){
    unsigned cases=0;
    for(int clear=0;clear<2;clear++)for(int mode=0;mode<3;mode++)for(int tracing=0;tracing<2;tracing++){
        if(clear && mode==0)continue;
        PipelineBinding existing={.pipeline=1};PGRAPHVkState r={.pipeline_binding=&existing};
        NV2AState d={.pgraph={.vk_renderer_state=&r}};
        dirty=mode!=0;looked_up.pipeline=mode==1?2:0;op_n=depth=trace_calls=0;enabled=tracing;
        memset(outcomes,0,sizeof(outcomes));memset(stage_counts,0,sizeof(stage_counts));
        if(clear)create_clear_pipeline_reference(&d.pgraph);else create_pipeline_reference(&d.pgraph);
        unsigned expected_ops[32],expected_n=op_n;memcpy(expected_ops,ops,sizeof(ops));
        PipelineBinding *expected_binding=r.pipeline_binding;bool expected_changed=r.pipeline_binding_changed;
        r.pipeline_binding=&existing;r.pipeline_binding_changed=false;op_n=0;
        if(clear)create_clear_pipeline(&d.pgraph);else create_pipeline(&d.pgraph);
        assert(op_n==expected_n && memcmp(expected_ops,ops,op_n*sizeof(*ops))==0);
        assert(r.pipeline_binding==expected_binding && r.pipeline_binding_changed==expected_changed);
        assert(depth==0);
        if(tracing){assert(outcomes[mode+1]==1);assert(outcomes[1]+outcomes[2]+outcomes[3]==1);
            assert(stage_counts[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PIPELINE_STATE_KEY]==1);
            assert(stage_counts[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PIPELINE_CACHE_LOOKUP]==(unsigned)(mode!=0));
            assert(stage_counts[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_TEXTURE_BIND]==(unsigned)!clear);
            assert(stage_counts[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_SHADER_BIND]==(unsigned)!clear);
        }else assert(trace_calls==0 && outcomes[1]+outcomes[2]+outcomes[3]==0);
        cases++;
    }
    printf("PASS: %u actual normal/clear cache-branch prefix cases; original operation/state parity and balanced observations (miss tail stubbed)\n",cases);
    return 0;
}
'''

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--compiler',default='gcc');a=p.parse_args()
    root=pathlib.Path(a.root);source=(root/DRAW_PATH).read_text();parts=[]
    for name,original in BASELINE_PREFIXES.items():
        prefix=function(source,f'static void {name}(PGRAPHState *pg)').split('    NV2A_VK_DPRINTF("Cache miss");')[0]
        parts.append(original.replace('void '+name+'(', 'void '+name+'_reference(')+'    miss_path();\n}\n')
        parts.append(prefix+'    xemu_debug_tools_pgraph_draw_trace_stage_end(XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_PIPELINE_BUILD_STATE);\n    miss_path();\n}\n')
    with tempfile.TemporaryDirectory(prefix='xemu-pipeline-prefix-') as temp:
        src=pathlib.Path(temp)/'test.c';src.write_text(HARNESS.replace('__FUNCTIONS__','\n'.join(parts)));exe=pathlib.Path(temp)/'test'
        subprocess.run([a.compiler,'-x','c','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-I',str(root),str(src),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True)
    return 0
if __name__=='__main__':raise SystemExit(main())
