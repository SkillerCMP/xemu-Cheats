#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 3: shared Diagnostics helper ownership guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    addon = root / "ui/xui/debug-tools/addons/diagnostics"

    cpu_h = (addon / "diagnostics-cpu-context.h").read_text(encoding="utf-8")
    ptimer_h = (addon / "diagnostics-ptimer-utils.h").read_text(encoding="utf-8")
    bql = (addon / "bql-trace.c").read_text(encoding="utf-8")
    lock_common = (addon / "lock-trace-common.c").read_text(encoding="utf-8")
    pgraph = (addon / "pgraph-lock-trace.c").read_text(encoding="utf-8")
    ptimer = (addon / "ptimer-trace.c").read_text(encoding="utf-8")
    backend = (addon / "diagnostics-backend.c").read_text(encoding="utf-8")

    # One authoritative current-CPU/guest-PC capture helper owns both lock traces.
    require(cpu_h, "CPUState *cpu = current_cpu;", "current CPU lookup")
    require(cpu_h, "*cpu_index = -1;", "no-CPU index fallback")
    require(cpu_h, "*guest_pc = 0;", "no-PC fallback")
    require(cpu_h, "*guest_pc_valid = 0;", "guest PC validity reset")
    require(cpu_h, "*cpu_index = cpu->cpu_index;", "CPU index capture")
    require(cpu_h, "cpu->cc != NULL && cpu->cc->get_pc != NULL",
            "safe guest PC callback check")
    require(cpu_h, "*guest_pc = cpu->cc->get_pc(cpu);", "guest PC capture")
    require(cpu_h, "*guest_pc_valid = 1;", "guest PC validity publish")

    for source, label, retired in (
        (lock_common, "BQL", "bql_trace_current_cpu"),
        (pgraph, "PGRAPH lock", "pgraph_lock_trace_current_cpu"),
    ):
        require(source, '#include "diagnostics-cpu-context.h"',
                f"{label} shared CPU helper include")
        require(source, "xemu_debug_tools_diagnostics_current_cpu_context(",
                f"{label} shared CPU helper call")
        forbid(source, retired, f"retired {label} duplicate CPU helper")
        forbid(source, "CPUState *cpu = current_cpu;",
               f"duplicate {label} current CPU implementation")
    forbid(bql, "xemu_debug_tools_diagnostics_current_cpu_context(",
           "duplicated BQL CPU capture in facade")

    # One authoritative PTIMER conversion implementation owns recorder/backend math.
    for token, label in (
        ("d->ptimer.numerator == 0 || d->pramdac.core_clock_freq == 0",
         "PTIMER absolute-clock zero guard"),
        ("muldiv64(muldiv64(virtual_ns, d->pramdac.core_clock_freq,",
         "PTIMER absolute-clock conversion"),
        ("((absolute + d->ptimer.time_offset) << 5) &",
         "PTIMER wrapped clock"),
        ("d->ptimer.denominator == 0 || d->pramdac.core_clock_freq == 0",
         "PTIMER ticks-to-ns zero guard"),
        ("gpu_ticks = muldiv64(ticks, d->ptimer.numerator,",
         "PTIMER tick ratio conversion"),
        ("return ns > INT64_MAX ? INT64_MAX : (int64_t)ns;",
         "positive alarm saturation"),
        ("return ns > INT64_MAX ? INT64_MIN : -(int64_t)ns;",
         "negative alarm saturation"),
    ):
        require(ptimer_h, token, label)

    for source, label in ((ptimer, "PTIMER recorder"), (backend, "Diagnostics backend")):
        require(source, '#include "diagnostics-ptimer-utils.h"',
                f"{label} shared PTIMER helper include")
        require(source, "xemu_debug_tools_ptimer_clock(",
                f"{label} shared PTIMER clock use")
        require(source, "xemu_debug_tools_ptimer_signed_alarm_delta_ns(",
                f"{label} shared PTIMER delta use")
        for retired in (
            "diagnostics_ptimer_absolute_clock",
            "diagnostics_ptimer_clock",
            "diagnostics_ptimer_ticks_to_ns",
            "diagnostics_signed_alarm_delta_ns",
        ):
            forbid(source, retired, f"retired {label} duplicate PTIMER helper {retired}")

    print("PASS: Cleanup Pass 3 shared Diagnostics CPU/PTIMER helper invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
