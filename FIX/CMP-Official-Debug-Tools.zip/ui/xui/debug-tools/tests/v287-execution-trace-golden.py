#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Execution Trace ownership / safety regression guard."""
from __future__ import annotations

import argparse
import pathlib


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = pathlib.Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"
    memory = debug / "addons/memory-tools"

    core = (memory / "execution-trace.cc").read_text(encoding="utf-8")
    ui = (memory / "execution-trace-ui.cc").read_text(encoding="utf-8")
    hh = (memory / "memory-tools.hh").read_text(encoding="utf-8")
    debugger_ui = (memory / "memory-tools-debugger-ui.cc").read_text(encoding="utf-8")
    addon = (memory / "debug-tools-memory-tools-addon.cc").read_text(encoding="utf-8")
    meson = (debug / "meson.build").read_text(encoding="utf-8")
    whpx_c = (debug / "backend/whpx-debug.c").read_text(encoding="utf-8")
    whpx_h = (debug / "backend/whpx-debug.h").read_text(encoding="utf-8")
    xdbg_c = (debug / "backend/xemu-dbg.c").read_text(encoding="utf-8")
    xdbg_h = (debug / "backend/xemu-dbg.h").read_text(encoding="utf-8")
    whpx_all = (root / "target/i386/whpx/whpx-all.c").read_text(encoding="utf-8")

    for rel in ("execution-trace.cc", "execution-trace-ui.cc"):
        if not (memory / rel).is_file():
            raise AssertionError(f"execution trace file missing from Memory add-on: {rel}")
    require(meson, "addons/memory-tools/execution-trace.cc", "trace core Meson ownership")
    require(meson, "addons/memory-tools/execution-trace-ui.cc", "trace UI Meson ownership")

    require(debugger_ui, 'ImGui::Button(m_trace_running ? "TRACE..." : "TRACE")',
            "TRACE button on x86 Debugger toolbar")
    reset_pos = debugger_ui.find('ImGui::Button("RESET UI")')
    trace_pos = debugger_ui.find('ImGui::Button(m_trace_running ? "TRACE..." : "TRACE")')
    if reset_pos < 0 or trace_pos <= reset_pos:
        raise AssertionError("TRACE button is not positioned after RESET UI")
    forbid(debugger_ui, 'BeginTabItem("Trace")', "separate Trace tab")

    require(ui, '"Sampled / Full"', "Sampled/Full mode")
    require(ui, '"Unique Addresses"', "Unique mode")
    require(ui, '"Basic Block / Control Flow"', "Control Flow mode")
    require(ui, '0 = every instruction', "zero interval semantics")
    require(ui, 'Full Instruction Trace Warning', "full trace warning")
    require(ui, 'Start Full Trace', "explicit warned full-trace start")
    require(ui, 'Maximum Size (MB)', "trace MB limit")
    require(ui, 'Stop at Address', "trace stop address")
    require(ui, 'Export TXT', "trace text export")
    require(ui, 'Export BIN', "trace binary export")

    require(addon, "debug_tools_register_tick(400, TickMemoryTools);",
            "Memory add-on trace tick")
    require(core, "g_get_monotonic_time()", "sample timer")
    require(core, "xemu_dbg_get_pc(&eip)", "lightweight sampled EIP read")
    require(core, "xemu_cheat_start_single_step()", "full trace WHPX startup")
    require(core, "XemuDebugOutput::Folder::TraceDumps", "trace output directory")
    require(core, '"XEMU-TRACE-V1"', "binary trace header")
    require(core, "eip != expected_fallthrough", "full control-flow filtering")

    require(xdbg_h, "xemu_dbg_get_pc", "target-specific lightweight PC API")
    require(xdbg_h, "xemu_dbg_trace_full_start", "target trace start API")
    require(xdbg_c, "xemu_whpx_trace_start", "WHPX trace delegation")
    require(whpx_h, "XemuWhpxTraceStatus", "WHPX trace status API")
    require(whpx_c, "xemu_whpx_trace_record", "WHPX EIP recorder")
    require(whpx_c, "xemu_whpx_trace_full_active();", "continuous step ownership")
    require(whpx_c, "return EXCP_INTERRUPT;", "trace traps continue guest")
    require(whpx_c, "XEMU_WHPX_TRACE_STOP_BREAKPOINT", "breakpoint trace stop")
    require(whpx_c, "cpu_single_step(cpu, 0);", "automatic full-trace step cleanup")

    # Full trace deliberately reuses the pre-existing WHPX user-step checks.
    # No additional direct master-side trace hook should be required.
    forbid(whpx_all, "xemu_whpx_trace_", "new trace-specific master WHPX hook")
    require(whpx_all, "xemu_whpx_user_step_pending()", "existing WHPX step bridge")

    require(hh, "NotifyExecutionTraceGameReset", "reset trace ownership")
    require(debugger_ui, "memory_tools_window.NotifyExecutionTraceGameReset();",
            "reset trace stop notification")

    print("PASS: Execution Trace modes / WHPX full-step / modular ownership invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
