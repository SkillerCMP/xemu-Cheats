#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--root', required=True)
args = ap.parse_args()
root = Path(args.root)
pg = (root / 'hw/xbox/nv2a/pgraph/pgraph.c').read_text(encoding='utf-8')
hook = (root / 'ui/xui/debug-tools/addons/diagnostics/pgraph-ptimer-latency-trace-hook.h').read_text(encoding='utf-8')
lat = '#include "ui/xui/debug-tools/addons/diagnostics/pgraph-ptimer-latency-trace-hook.h"'
flip = '#include "ui/xui/debug-tools/addons/diagnostics/flip-stall-trace-hook.h"'
timer = '#include "qemu/timer.h"'
for item in (lat, flip, timer):
    if item not in pg:
        raise SystemExit(f'FAIL: missing expected PGRAPH include: {item}')
if not (pg.index(lat) < pg.index(flip) < pg.index(timer)):
    raise SystemExit('FAIL: PGRAPH latency/flip hooks must initialize qemu/osdep before qemu/timer.h on Windows')
osdep = '#include "qemu/osdep.h"'
types = '#include "pgraph-ptimer-latency-trace-types.h"'
if osdep not in hook or types not in hook or hook.index(osdep) > hook.index(types):
    raise SystemExit('FAIL: PGRAPH latency hook must pull qemu/osdep before neutral latency types')
print('PASS: v3.14p universal PGRAPH diagnostics include ordering is Windows-safe with Patch 20 present or absent')
