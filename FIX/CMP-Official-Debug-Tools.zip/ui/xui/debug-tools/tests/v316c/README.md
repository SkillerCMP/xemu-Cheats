# v3.16c strict source regression

Run from any directory with GCC or Clang, Linux GLib runtime and Python:

```sh
python3 run-native.py --compiler g++
python3 run-native.py --compiler clang++ --sanitizers
python3 run-native.py --fixture /path/to/NM0003-66924760DA1C55DF-example.txt
```

The optional fixture is the user's exact 2,521-line, 11-entry, 12-F0 example.
It is not bundled and never modified. All deletion tests work on temporary
copies. Without it, synthetic tests still cover strict RAW/body/data prefixes,
all three F modes, four-folder boundaries, full-line and inline comments,
malformed/missing terminators, PREENTRY, +OFF, metadata, actual error gating,
F-looking multi-row literal payloads, pointer descriptor counts, the Debugger
Code Cave editor, invalid-only definitions and deletion/error-line remapping.

The parser, executor, F-hook manager and deletion sources are real; simulated
guest memory/allocator/pause and a generic assembler seam come from the existing
v3.16b test support. GLib performs real atomic disk IO. This is not an integrated
XEMU run or a Keystone encoding/timing test. Preserve that distinction in reports.

The unchanged v3.16b native/deletion/frontend, modal, recorder, syntax tests and
File Replace tests remain available. The v3.13 numeric-fixture adapter now
adds '$' to its historical fixture input; expected memory results are unchanged
and a direct production-parser assertion verifies bare RAW pairs are rejected.
