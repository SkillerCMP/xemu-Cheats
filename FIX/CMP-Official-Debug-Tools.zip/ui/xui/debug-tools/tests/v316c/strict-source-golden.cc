// Actual source parser/executor/deletion; simulated guest/assembler, real GLib IO.
#include <bits/stdc++.h>
#define private public
#include "cheat-engine.hh"
#undef private
#include <filesystem>
extern int probe_calls, final_calls, memory_writes, patch_calls;
static size_t checks = 0;
#define CHECK(x) do { ++checks; if (!(x)) { std::cerr << "FAIL line " << __LINE__ << ": " << #x << '\n'; std::exit(1); } } while (0)
using Engine = CheatEngineWindow;
static std::string read(const std::string &p) { std::ifstream f(p,std::ios::binary); return {std::istreambuf_iterator<char>(f),{}}; }
static void parse(Engine &e, const std::string &s) { e.m_source=s; e.ParseSource(false); }
static std::string f(unsigned mode, const std::string &name="hook") {
    return "+"+name+"\n$F"+std::to_string(mode)+"000000 00001000\n" +
        (mode==0 ? "$nop\n" : mode==1 ? "$90909090 90909090\n" : "$90\n") +
        (mode==1 ? "$DEADCODE 00000008\n" : "$DEADCODE\n");
}
static void blocked(Engine &e, size_t i=0) {
    CHECK(i<e.m_blocks.size()); auto &b=e.m_blocks[i]; CHECK(!b.parse_error.empty());
    const int probes=probe_calls, writes=memory_writes, patches=patch_calls, finals=final_calls;
    for (int n=0;n<3;++n) {
        b.enabled=true; b.selected=true; b.runtime_error.clear();
        e.ExecuteBlock(i,b);
        CHECK(!b.runtime_error.empty()); CHECK(!b.enabled); CHECK(!b.selected);
        CHECK(probe_calls==probes); CHECK(memory_writes==writes);
        CHECK(patch_calls==patches); CHECK(final_calls==finals);
    }
}
int main(int argc,char **argv) {
    CHECK(argc==3); std::filesystem::create_directories(argv[2]);
    const std::string path=std::string(argv[2])+"/codes.txt";
    {
        Engine::RawCode r;
        for (auto s : {"20000000 00000000", "F0000000 00001000", "!Unlock Codes:", "Label:", "// comment", "# comment", "; comment", ""})
            CHECK(!Engine::ParseCodeLine(s,r,1));
        for (auto s : {"$20000000 00000000", "  $20000000 00000000  ", "\t$20000000 00000000 // note", "$20000000 00000000 # note"})
            CHECK(Engine::ParseCodeLine(s,r,1));
        CHECK(!Engine::ParseCodeLine("$20000000 00000000 ; old RAW semicolon rule",r,1));
    }
    for (unsigned mode=0;mode<3;++mode) {
        for (const std::string &comment : std::initializer_list<std::string>{std::string("\n"), "// comment: ! + $ F0\n", "; comment: ! + $ F0\n", "# comment: ! + $ F0\n"}) {
            Engine e; parse(e,f(mode)+comment+"!Unlock Codes:\n+Unlock Everything\n%Credits: Tester\n$20000120 00000001 // keep\n+OFF\n$20000120 00000000 # keep\n!!\n");
            CHECK(e.m_parse_messages.empty()); CHECK(e.m_blocks.size()==3); CHECK(e.m_groups.size()==2);
            CHECK(e.m_groups[1].name=="Unlock Codes"); CHECK(e.m_blocks[1].group_path=="Unlock Codes");
            CHECK(e.m_blocks[2].group_path=="Unlock Codes"); CHECK(e.m_blocks[2].name=="OFF");
            CHECK(e.m_blocks[0].codes[0].f_body.size()==1);
            CHECK(e.m_blocks[0].source_end<=e.m_source.find("!Unlock Codes:"));
        }
    }
    for (unsigned mode : {0u,2u}) {
        Engine e;
        parse(e,f(mode)+"\n$Data: // valid label\n; comment\n$dd 12345678 # data\n$More: dd 00000000 ; data\n// next heading\n!Group:\n+Next\n$20000120 00000001\n!!\n");
        CHECK(e.m_parse_messages.empty()); CHECK(e.m_blocks.size()==2); CHECK(e.m_groups.size()==2);
        CHECK(e.m_blocks[0].codes[0].f_body.size()==4);
        CHECK(e.m_blocks[0].source_end==e.m_source.find("// next heading"));
        for (auto bad : {"Data:\n", "dd 12345678\n", "!not-a-label"}) {
            if (bad[0]=='!') continue; // valid group syntax, tested separately
            parse(e,f(mode)+bad+"+Next\n$20000120 00000001\n");
            CHECK(e.m_blocks.size()==2); blocked(e); CHECK(e.m_blocks[1].parse_error.empty());
        }
        parse(e,f(mode)+"$!Bad Label:\n+Next\n$20000120 00000001\n");
        blocked(e); CHECK(e.m_blocks[0].codes[0].f_body.size()==1);
    }
    for (auto body : {"nop\n", "Done:\n", "dd 12345678\n", "90909090 90909090\n", "DEADCODE\n"}) {
        Engine e; parse(e,"+Bad\n$20000120 00000001\n$F0000000 00001000\n"+std::string(body)+"$nop\n$DEADCODE\n+Good\n$20000124 00000002\n");
        CHECK(e.m_blocks.size()==2); blocked(e); CHECK(e.m_blocks[1].parse_error.empty());
    }
    for (auto line : {"20000120 00000001", "F0000000 00001000", "SomeLabel:", "$garbage", "$DEADCODE"}) {
        Engine e; parse(e,"+Bad\n"+std::string(line)+"\n$20000124 00000002\n+Good\n$20000128 00000003\n");
        CHECK(e.m_blocks.size()==2); blocked(e);
    }
    {
        Engine e; parse(e,"+Only invalid\n20000120 00000001\n+Good\n$20000128 00000003\n");
        CHECK(e.m_blocks.size()==2); CHECK(e.m_blocks[0].codes.empty()); blocked(e);
        parse(e,"+Bad startup\n:PREENTRY:\n20000120 00000001\n$20000124 00000002\n");
        CHECK(e.m_blocks[0].preentry); const int writes=memory_writes,probes=probe_calls;
        e.m_blocks[0].selected=true; e.ExecuteBlock(0,e.m_blocks[0]);
        CHECK(memory_writes==writes); CHECK(probe_calls==probes); CHECK(!e.m_blocks[0].runtime_error.empty());
    }
    for (const std::string &boundary : std::initializer_list<std::string>{std::string("!Folder:\n"),"!!\n","+Next:\n","^1 = Hash: 1234\n","%Credits:\n","{Description:}\n",":PREENTRY:\n"}) {
        Engine e; parse(e,"+Bad\n$F0000000 00001000\n$nop\n"+boundary+"+Good\n$20000124 00000002\n");
        CHECK(!e.m_blocks.empty()); CHECK(!e.m_blocks[0].codes[0].f_terminated);
        CHECK(e.m_blocks[0].codes[0].f_body.size()==1); blocked(e);
        for (const auto &b:e.m_blocks) for (const auto &c:b.codes) for (const auto &s:c.f_body)
            CHECK(s.text=="nop");
    }
    for (const std::string &tail : std::initializer_list<std::string>{std::string("%Credits: After\n"),"{Description:}\n","^3 = NAME: test\n"}) {
        Engine e; parse(e,f(0)+tail+"+Good\n$20000124 00000002\n");
        CHECK(e.m_parse_messages.empty()); CHECK(e.m_blocks[0].codes[0].f_body.size()==1);
    }
    for (const std::string &end : std::initializer_list<std::string>{std::string("$DEADCODE 00000001"),"$DEADCODE bogus"}) {
        Engine e; parse(e,"+Bad\n$F0000000 00001000\n$nop\n"+end+"\n"); blocked(e);
    }
    for (const std::string &count : std::initializer_list<std::string>{std::string("00000000"),"00000009","", "00000008 extra"}) {
        Engine e; parse(e,"+Bad\n$F1000000 00001000\n$90909090 90909090\n$DEADCODE "+count+"\n"); blocked(e);
    }
    // RAW multi-line operands must require '$' but are NEVER parsed as new hooks.
    for (const std::string &head : std::initializer_list<std::string>{std::string("A0000100 00000008"),"30400000 00000100","30500000 00000100","40000100 00010001","50000100 00000008","60000100 00000001"}) {
        Engine e; parse(e,"+Payload\n$"+head+"\n$F0000000 00000000\n+Next\n$20000124 00000002\n");
        CHECK(e.m_parse_messages.empty()); CHECK(e.m_blocks.size()==2); CHECK(e.m_blocks[0].codes.size()==2);
        CHECK(e.m_blocks[0].codes[1].f_body.empty()); CHECK(!e.m_blocks[0].codes[1].f_terminated);
        const int probes=probe_calls; CHECK(e.PrepareBlockTypeF(e.m_blocks[0])); CHECK(probe_calls==probes);
        parse(e,"+Bad\n$"+head+"\nF0000000 00000000\n+Good\n$20000124 00000002\n"); blocked(e);
        parse(e,"+Bad\n$"+head+"\n+Good\n$20000124 00000002\n"); blocked(e);
    }
    {
        Engine e; parse(e,"+Pointer\n$60000100 00000001\n$00000003 00000000\n$F0000000 00000000\n"+f(0,"Real hook"));
        CHECK(e.m_parse_messages.empty()); CHECK(e.m_blocks.size()==2); CHECK(e.m_blocks[0].codes.size()==3);
        CHECK(e.m_blocks[0].codes[2].f_body.empty()); CHECK(e.m_blocks[1].codes[0].f_body.size()==1);
    }
    {
        Engine e; Engine::RawCode c; std::string err;
        CHECK(e.ParseDebuggerF0Source(0x1000,"// comment\n$F0000000 00001000\n$nop // comment\n$DEADCODE\n$Data:\n$dd 12345678\n",c,err));
        CHECK(c.f_body.size()==3);
        for (auto bad : {"nop", "DEADCODE", "Data:", "dd 12345678", "!Unlock Codes:"}) {
            CHECK(!e.ParseDebuggerF0Source(0x1000,"$F0000000 00001000\n$nop\n$DEADCODE\n"+std::string(bad)+"\n",c,err));
            CHECK(err.find("must begin with '$'")!=std::string::npos);
        }
    }
    {
        Engine e; std::string s="+Delete me\r\n$20000120 00000001\r\n+Invalid survives\r\n20000124 00000002\r\n+Valid survives\r\n$20000128 00000003\r\n";
        {std::ofstream file(path,std::ios::binary);file<<s;} CHECK(e.LoadSourceFile(path));
        std::string error; CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));
        CHECK(e.m_blocks.size()==2); CHECK(e.m_blocks[0].parse_error_line==2); blocked(e);
        CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));
        CHECK(e.m_blocks.size()==1); CHECK(e.m_blocks[0].name=="Valid survives"); CHECK(e.m_parse_messages.empty());
    }
    if (std::string(argv[1])!="-") {
        Engine e;const std::string s=read(argv[1]);CHECK(!s.empty());const int probes=probe_calls;
        parse(e,s);CHECK(probe_calls==probes);CHECK(e.m_parse_messages.empty());
        CHECK(e.m_blocks.size()==11); CHECK(e.m_groups.size()==5);
        CHECK(e.m_groups[1].name=="Unlock Codes");CHECK(e.m_groups[4].name=="Spawn Replacement");
        CHECK(e.m_blocks[1].group_path=="Unlock Codes");CHECK(e.m_blocks.back().group_path=="Spawn Replacement");
        size_t hooks=0,body_lines=0;
        for(auto &b:e.m_blocks) {CHECK(b.parse_error.empty());for(auto &c:b.codes) {
            if(c.f_terminated) {++hooks;CHECK(!c.f_precompiled);for(auto &l:c.f_body) {
                ++body_lines;CHECK(!l.text.empty());CHECK(l.text[0]!='!');CHECK(l.text[0]!='%');CHECK(l.text[0]!='^');CHECK(l.text[0]!='+');
            }}
        }}
        CHECK(hooks==12);
        // Delete the first hook code and retain the folder it formerly swallowed.
        {std::ofstream file(path,std::ios::binary);file<<s;} CHECK(e.LoadSourceFile(path));
        std::string error;CHECK(e.DeleteCodeFromSource(0,e.m_source_revision,path,error));
        CHECK(e.m_groups[1].name=="Unlock Codes");CHECK(read(path).find("!Unlock Codes:")!=std::string::npos);
        while(!e.m_blocks.empty()) {const size_t i=e.m_blocks.size()/2; CHECK(e.DeleteCodeFromSource(i,e.m_source_revision,path,error));}
        CHECK(probe_calls==probes);
        std::cout<<"Exact user fixture: 11 entries, 12 F hooks, "<<body_lines<<" F-source lines; all 4 folders retained; ZERO assembly calls on load/deletion\n";
    }
    std::cout<<"PASS "<<checks<<" strict-source assertions (actual parser/executor/deletion, simulated guest/assembler)\n";
}
