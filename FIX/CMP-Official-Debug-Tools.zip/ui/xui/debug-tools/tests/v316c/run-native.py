#!/usr/bin/env python3
"""Strict cheat TXT regression. Actual parser/executor/hooks/deletion; guest and
assembler test seams, actual installed GLib. Not a full XEMU/Keystone build."""
from pathlib import Path
import argparse, shutil, subprocess, sys, tempfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default='g++')
p.add_argument('--sanitizers',action='store_true')
p.add_argument('--fixture',type=Path)
a=p.parse_args()
dt=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(dt/'tests'))
from v287_source_test_utils import extract_function
with tempfile.TemporaryDirectory(prefix='xemu-v316c-') as t:
    root=Path(t);d=root/'ui/xui/debug-tools';shutil.copytree(dt,d)
    (d.parent/'common.hh').write_text('#pragma once\n#include <cstddef>\n#include <cstdint>\n#include <string>\nbool SDL_OpenURL(const char*);const char* SDL_GetError();\n')
    for n in ('font-manager.hh','misc.hh'):(d.parent/n).write_text('#pragma once\n')
    flags=[a.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-ffunction-sections','-fdata-sections']
    if a.sanitizers:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    flags+=['-I'+str(d/'tests/v316b/stubs'),'-I'+str(d)]
    src=(d/'cheat-engine-persistence.cc').read_text()
    (root/'hash.cc').write_text('#include "cheat-engine.hh"\n#include <algorithm>\n#include <cctype>\n#include <cstdio>\n#include <glib.h>\n'+extract_function(src,'std::string Sha256Text(')+'\n'+extract_function(src,'std::string CheatEngineWindow::PersistentContentHash('))
    impl=[d/n for n in ('cheat-engine-source.cc','cheat-engine-execute.cc','cheat-engine-fhooks.cc','cheat-engine.cc','cheat-engine-delete.cc','cheat-source-file.cc')]
    cmd=flags+[d/'tests/v316c/strict-source-golden.cc',d/'tests/v316b/engine-shims.cc',*impl,root/'hash.cc','-Wl,--gc-sections','-Wl,--wrap=g_file_set_contents_full','-l:libglib-2.0.so.0','-o',root/'strict-source']
    print('+',' '.join(map(str,cmd)),flush=True);subprocess.run(list(map(str,cmd)),check=True,timeout=90)
    subprocess.run([str(root/'strict-source'),str(a.fixture.resolve()) if a.fixture else '-',str(root/'files')],check=True,timeout=30)
