#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Shared source-inspection helpers for Debug Tools golden tests."""
from __future__ import annotations

import re


def extract_function(text: str, signature: str) -> str:
    """Return a brace-balanced C/C++ function beginning at *signature*."""
    start = text.find(signature)
    if start < 0:
        raise AssertionError(f"missing function signature: {signature}")
    brace = text.find("{", start)
    if brace < 0:
        raise AssertionError(f"function opening brace missing: {signature}")
    depth = 0
    for pos in range(brace, len(text)):
        ch = text[pos]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : pos + 1]
    raise AssertionError(f"function closing brace missing: {signature}")


def extract_member_functions(text: str, class_name: str) -> list[tuple[str, str]]:
    """Return brace-balanced definitions for *class_name* member functions."""
    pattern = re.compile(
        rf"(?m)^([^\n]*?{re.escape(class_name)}::([A-Za-z_~][A-Za-z0-9_]*)"
        r"\s*\([^;]*?\)\s*(?:const\s*)?\n?\{)"
    )
    functions: list[tuple[str, str]] = []
    for match in pattern.finditer(text):
        brace = text.find("{", match.start())
        depth = 0
        for pos in range(brace, len(text)):
            if text[pos] == "{":
                depth += 1
            elif text[pos] == "}":
                depth -= 1
                if depth == 0:
                    functions.append((match.group(2), text[match.start() : pos + 1]))
                    break
        else:
            raise AssertionError(
                f"unterminated {class_name} function: {match.group(2)}"
            )
    return functions


CHEAT_ENGINE_IMPLEMENTATION_FILES = (
    "cheat-engine.cc",
    "cheat-engine-source.cc",
    "cheat-engine-fhooks.cc",
    "cheat-engine-execute.cc",
    "cheat-engine-ui.cc",
)


def read_cheat_engine_implementation(debug_dir) -> str:
    """Return the complete split CheatEngineWindow implementation as one view.

    Phase-2 moved UI/frontend methods into a dedicated translation unit; Phase-9
    further separates source/PREENTRY, F-hook lifecycle, and RAW execution while
    preserving method bodies byte-for-byte. Source-level golden tests should
    follow implementation ownership rather than assume an older monolith.
    """
    return "\n\n".join(
        (debug_dir / name).read_text(encoding="utf-8")
        for name in CHEAT_ENGINE_IMPLEMENTATION_FILES
    )


MEMORY_TOOLS_IMPLEMENTATION_FILES = (
    "addons/memory-tools/memory-tools-internal.hh",
    "addons/memory-tools/memory-tools.cc",
    "addons/memory-tools/memory-tools-memory.cc",
    "addons/memory-tools/memory-tools-memory-ui.cc",
    "addons/memory-tools/memory-tools-search.cc",
    "addons/memory-tools/memory-tools-search-ui.cc",
    "addons/memory-tools/memory-tools-debugger.cc",
    "addons/memory-tools/memory-tools-debugger-ui.cc",
    "addons/memory-tools/memory-tools-inject.cc",
    "addons/memory-tools/memory-tools-inject-ui.cc",
    "addons/memory-tools/memory-tools-labels.cc",
    "addons/memory-tools/memory-tools-labels-ui.cc",
    "addons/memory-tools/memory-tools-dump.cc",
    "addons/memory-tools/memory-tools-dump-ui.cc",
)


def read_memory_tools_implementation(debug_dir) -> str:
    """Return the complete split MemoryTools implementation as one source view.

    Source-level golden tests should validate behavior/ownership tokens rather
    than depend on which translation unit owns a moved method.
    """
    return "\n\n".join(
        (debug_dir / name).read_text(encoding="utf-8")
        for name in MEMORY_TOOLS_IMPLEMENTATION_FILES
    )

# PREENTRY/Patch intentionally adds state and declarations to the historical
# CheatEngine header. Older freeze tests remove these separately guarded
# additions semantically so harmless comments/formatting do not churn the
# historical fingerprints.
PREENTRY_CHEAT_HEADER_ADDITIONS = (
    "unordered_set include",
    "NotifyGameResetRequested declaration",
    "PreEntryLifecycle enum",
    "CheatBlock PREENTRY/identity fields",
    "PREENTRY window state",
    "PREENTRY helper declarations",
)


def _strip_once(text: str, pattern: str, description: str) -> str:
    text, count = re.subn(pattern, "", text, count=1, flags=re.MULTILINE | re.DOTALL)
    if count != 1:
        raise AssertionError(f"PREENTRY/Patch header scope changed unexpectedly: {description}")
    return text


def strip_preentry_cheat_header_additions(text: str) -> str:
    """Remove separately guarded PREENTRY/Patch header additions semantically."""
    text = _strip_once(text, r'^#include <unordered_set>\n', "unordered_set include")
    text = _strip_once(text, r'^    void NotifyGameResetRequested\(\);\n',
                       "NotifyGameResetRequested declaration")
    text = _strip_once(
        text,
        r'^    enum class PreEntryLifecycle \{\n.*?^    \};\n\n',
        "PreEntryLifecycle enum",
    )

    # Fields added to CheatBlock by PREENTRY and its duplicate-safe identity.
    for field in (
        "bool preentry = false;",
        "bool preentry_applied = false;",
        "std::string preentry_error;",
        "std::string group_path;",
        "uint32_t identity_ordinal = 0;",
    ):
        text = _strip_once(text, rf'^        {re.escape(field)}\n', field)

    for field in (
        "bool m_seen_game_valid = false;",
        "bool m_force_forget_f_hooks_on_next_game_observation = false;",
        "PreEntryLifecycle m_preentry_lifecycle = PreEntryLifecycle::Idle;",
        "std::string m_last_preentry_message;",
        "std::string m_seen_game_identity;",
    ):
        text = _strip_once(text, rf'^    {re.escape(field)}\n', field)

    text = _strip_once(
        text,
        r'^    /\* Only selected PREENTRY identities.*?^    std::unordered_set<std::string> m_selected_preentry_keys;\n',
        "selected PREENTRY session state",
    )

    declarations = (
        r'void ObserveRequestedGameReset\(\);',
        r'void ApplySelectedPreEntryPatches\(\);',
        r'std::string BlockIdentityKey\(const CheatBlock &block\) const;',
        r'std::string PreEntrySelectionKey\(const CheatBlock &block\) const;',
        r'bool IsPreEntrySelected\(const CheatBlock &block\) const;',
        r'void RememberPreEntrySelection\(CheatBlock &block\);',
        r'void DrawPatchGroup\(int group_index\);',
        r'void DeactivateLiveFHooks\(\);',
        r'static bool ConsumePreEntryPrefix\(std::string &spec\);',
        r'void ForgetFHookOwnershipForNewGuest\(\);',
        r'void DrawPatch\(size_t block_index\);',
        r'void SetPatchGroupSelected\(int group_index, bool selected\);',
    )
    for declaration in declarations:
        text = _strip_once(text, rf'^    {declaration}\n', declaration)
    text = _strip_once(
        text,
        r'^    void CountPatchGroupSelection\(int group_index, size_t &selected,\n'
        r'^                                  size_t &total\) const;\n',
        "CountPatchGroupSelection declaration",
    )
    return text

# v2.91.9 Execution Trace intentionally adds MemoryTools-owned state and
# declarations. Older structural/render golden tests strip these separately
# guarded additions so their historical ownership fingerprints remain useful.
def strip_execution_trace_memory_tools_header(text: str) -> str:
    additions = (
        '#include "backend/xemu-dbg.h"\n',
        '#include <unordered_map>\n',
        '    void TickExecutionTrace();\n',
        '    void NotifyExecutionTraceGameReset();\n',
        """    enum class ExecutionTraceMode {
        SampledFull = 0,
        UniqueAddresses,
        ControlFlow,
    };

    struct ExecutionTraceUniqueRow {
        uint32_t address = 0;
        uint64_t hits = 0;
        uint64_t first_event = 0;
        uint64_t last_event = 0;
    };

    struct ExecutionTraceFlowRow {
        uint32_t from = 0;
        uint32_t to = 0;
        uint64_t hits = 0;
        uint64_t first_event = 0;
        uint64_t last_event = 0;
    };

""",
        """    // Optional execution tracer. Interval 0 uses continuous WHPX single-step
    // and records every instruction; positive intervals are lightweight EIP
    // samples collected by the Memory Tools tick callback.
    bool m_trace_window_open = false;
    bool m_trace_focus_requested = false;
    bool m_trace_full_warning_open = false;
    bool m_trace_running = false;
    bool m_trace_full_backend = false;
    ExecutionTraceMode m_trace_mode = ExecutionTraceMode::SampledFull;
    int m_trace_interval_ms = 5;
    int m_trace_max_mb = 10;
    ExecutionTraceMode m_trace_capture_mode = ExecutionTraceMode::SampledFull;
    int m_trace_capture_interval_ms = 5;
    int m_trace_capture_max_mb = 10;
    uint32_t m_trace_capture_range_start = 0x00000000u;
    uint32_t m_trace_capture_range_end = 0xFFFFFFFFu;
    char m_trace_range_start_text[16] = "00000000";
    char m_trace_range_end_text[16] = "FFFFFFFF";
    bool m_trace_stop_address_enabled = false;
    char m_trace_stop_address_text[16] = "00000000";
    uint32_t m_trace_stop_address = 0;
    int64_t m_trace_next_sample_us = 0;
    uint64_t m_trace_event_count = 0;
    uint64_t m_trace_event_limit = 0;
    uint32_t m_trace_last_eip = 0;
    bool m_trace_have_previous = false;
    uint32_t m_trace_previous_eip = 0;
    int m_trace_stop_reason = XEMU_DBG_TRACE_STOP_NONE;
    std::string m_trace_status;
    std::string m_trace_export_status;
    std::vector<uint32_t> m_trace_samples;
    std::vector<ExecutionTraceUniqueRow> m_trace_unique_rows;
    std::unordered_map<uint32_t, size_t> m_trace_unique_index;
    std::vector<ExecutionTraceFlowRow> m_trace_flow_rows;
    std::unordered_map<uint64_t, size_t> m_trace_flow_index;

""",
        '    void DrawExecutionTraceWindow();\n',
        """    bool StartExecutionTrace();
    void StopExecutionTrace(bool manual_stop);
    void ClearExecutionTrace();
    void RecordExecutionTraceAddress(uint32_t eip);
    void FinalizeFullExecutionTrace();
    void RebuildExecutionTraceSummaryFromFullBackend();
    bool ExportExecutionTraceText();
    bool ExportExecutionTraceBinary();
    std::string ExecutionTraceDirectory() const;
    const char *ExecutionTraceStopReasonText(int reason) const;
""",
    )
    for addition in additions:
        if addition not in text:
            raise AssertionError(
                f"Execution Trace MemoryTools header scope changed unexpectedly: {addition.strip()}"
            )
        text = text.replace(addition, "", 1)
    return text

# v3.11 Memory Search / RAM Dump intentionally adds asynchronous snapshot state
# and changes only the listed MemoryTools methods. Older historical freeze tests
# use these helpers to keep protecting every unrelated member/header byte.
V311_MEMORY_TOOLS_MUTABLE_METHODS = frozenset({
    "MemoryToolsWindow",
    "ValueSizeForKind",
    "MatchTargetForKind",
    "MatchPreviousForKind",
    "ResetSearch", "NotifySearchGameReset",
    "CaptureSnapshot", "CaptureSnapshotInto", "QueueSearchJob", "RunSearchJob", "CompleteSearchJob",
    "FirstScan", "NextScan", "DrawSearch",
    "NotifyDumpGameReset", "RunDumpJob", "CompleteDumpJob",
    "WriteDumpVirtualMapIndex", "QueueDumpJob", "DumpRam", "DrawDumpRam",
})


def strip_v311_memory_tools_header_additions(text: str) -> str:
    """Remove the separately guarded v3.11 MemoryTools snapshot/dump surface.

    The result is byte-identical to the post-v3.10 header so older render/state
    fingerprints continue measuring their original ownership contracts.
    """
    additions = (
        "    void NotifySearchGameReset();\n    void NotifyDumpGameReset();\n",
        "    bool m_search_busy = false;\n"
        "    uint64_t m_search_serial = 0;\n"
        "    uint64_t m_search_last_pause_us = 0;\n"
        "    uint64_t m_search_last_capture_us = 0;\n"
        "    uint64_t m_search_last_worker_us = 0;\n"
        "    size_t m_search_last_snapshot_bytes = 0;\n"
        "    size_t m_search_last_unreadable_pages = 0;\n",
        "    // Second prewarmed buffer used to capture the live guest state while the\n"
        "    // previous Unknown Initial snapshot remains immutable for comparison.\n"
        "    std::vector<uint8_t> m_capture_snapshot;\n"
        "    std::vector<uint8_t> m_capture_valid_pages;\n\n"
        "    bool m_dump_busy = false;\n"
        "    uint64_t m_dump_serial = 0;\n"
        "    uint64_t m_dump_last_pause_us = 0;\n"
        "    uint64_t m_dump_last_capture_us = 0;\n"
        "    uint64_t m_dump_last_worker_us = 0;\n"
        "    size_t m_dump_last_snapshot_bytes = 0;\n"
        "    std::vector<uint8_t> m_dump_snapshot;\n"
        "    std::vector<uint8_t> m_dump_snapshot_valid_pages;\n",
        "    struct DumpJob;\n\n",
        "    static void RunDumpJob(void *opaque);\n"
        "    static void CompleteDumpJob(void *opaque);\n"
        "    static bool WriteDumpVirtualMapIndex(const DumpJob &job,\n"
        "                                         const std::string &path);\n"
        "    bool QueueDumpJob(DumpJob *job);\n",
        "    struct SearchJob;\n\n",
        "    bool QueueSearchJob(SearchJob *job);\n"
        "    static void RunSearchJob(void *opaque);\n"
        "    static void CompleteSearchJob(void *opaque);\n",
        "    static bool MatchTargetForKind(ValueKind kind, uint32_t raw,\n"
        "                                   uint32_t target, NextScanMode mode);\n"
        "    static bool MatchPreviousForKind(ValueKind kind, uint32_t current,\n"
        "                                     uint32_t previous, NextScanMode mode);\n"
        "    static size_t ValueSizeForKind(ValueKind kind);\n",
    )
    for addition in additions:
        if addition not in text:
            raise AssertionError(
                f"v3.11 MemoryTools header scope changed unexpectedly: {addition.splitlines()[0].strip()}"
            )
        text = text.replace(addition, "", 1)

    capture = (
        "    bool CaptureSnapshotInto(std::vector<uint8_t> &snapshot,\n"
        "                             std::vector<uint8_t> &valid_pages,\n"
        "                             uint64_t &pause_us, uint64_t &capture_us,\n"
        "                             size_t &unreadable_pages);\n"
    )
    if capture not in text:
        raise AssertionError("v3.11 CaptureSnapshotInto declaration changed unexpectedly")
    text = text.replace(capture, "    bool CaptureSnapshot();\n", 1)

    # Cleanup Pass 2 removes dead pre-v3.11 APIs. Restore them here because
    # this helper promises the exact post-v3.10 header for historical guards.
    restorations = (
        ("    bool RefreshMemoryMap();\n",
         "    bool ScanMappedVirtualRam(uint64_t ram_size,\n"
         "                              std::vector<VirtualDumpRegion> &regions,\n"
         "                              uint64_t &mapped_pages) const;\n"
         "    bool RefreshMemoryMap();\n"),
        ("    std::string DumpDirectory() const;\n",
         "    bool WriteVirtualMapIndex(const std::string &path, uint64_t ram_size,\n"
         "                              const std::vector<VirtualDumpRegion> &regions,\n"
         "                              uint64_t mapped_pages,\n"
         "                              const std::vector<std::string> &region_files) const;\n"
         "    std::string DumpDirectory() const;\n"),
        ("    bool Write(AddressSpace space, uint32_t address, const void *buffer, size_t size) const;\n\n"
         "    void ResetSearch();\n",
         "    bool Write(AddressSpace space, uint32_t address, const void *buffer, size_t size) const;\n"
         "    bool ReadRaw(AddressSpace space, uint32_t address, ValueKind kind,\n"
         "                 uint32_t &raw) const;\n\n"
         "    void ResetSearch();\n"),
        ("    bool ParseTarget(uint32_t &raw) const;\n",
         "    bool ParseTarget(uint32_t &raw) const;\n"
         "    bool MatchTarget(uint32_t raw, uint32_t target, NextScanMode mode) const;\n"
         "    bool MatchPrevious(uint32_t current, uint32_t previous, NextScanMode mode) const;\n"),
        ("    void FormatValue(char *dst, size_t dst_size, uint32_t raw,\n",
         "    size_t ValueSize(ValueKind kind) const;\n"
         "    void FormatValue(char *dst, size_t dst_size, uint32_t raw,\n"),
    )
    for marker, restored in restorations:
        if marker not in text:
            raise AssertionError(f"Cleanup Pass 2 header restoration anchor changed: {marker.strip()}")
        text = text.replace(marker, restored, 1)

    # The v3.11 capture/dump fields occupy the historical blank separator.
    marker = "    std::vector<uint8_t> m_snapshot_valid_pages;\n    std::string m_dump_status;"
    if marker not in text:
        raise AssertionError("v3.11 MemoryTools snapshot/dump separator changed unexpectedly")
    text = text.replace(
        marker,
        "    std::vector<uint8_t> m_snapshot_valid_pages;\n\n    std::string m_dump_status;",
        1,
    )
    return text


def restore_cleanup_pass8_memory_tools_timestamp_call(text: str) -> str:
    """Restore the Pass 7 DumpStem timestamp call for older method digests."""
    new = 'XemuDebugOutput::Timestamp("00000000-000000")'
    old = 'make_dump_timestamp()'
    if text.count(new) != 1 or old in text:
        raise AssertionError("Cleanup Pass 8 Memory Tools timestamp normalization changed")
    return text.replace(new, old, 1)

def restore_cleanup_pass8_memory_tools_timestamp(text: str) -> str:
    """Restore the complete pre-Pass-8 Memory Tools timestamp helper surface."""
    text = restore_cleanup_pass8_memory_tools_timestamp_call(text)

    include_anchor = "#include <string>\n\nnamespace xemu_memory_tools_internal {"
    if text.count(include_anchor) != 1:
        raise AssertionError("Cleanup Pass 8 Memory Tools GLib restoration anchor changed")
    text = text.replace(
        include_anchor,
        "#include <string>\n\n#include <glib.h>\n\nnamespace xemu_memory_tools_internal {",
        1,
    )

    namespace_end = "\n} // namespace xemu_memory_tools_internal"
    if text.count(namespace_end) != 1 or "static std::string make_dump_timestamp(" in text:
        raise AssertionError("Cleanup Pass 8 Memory Tools helper restoration anchor changed")
    helper = """
static std::string make_dump_timestamp()
{
    GDateTime *now = g_date_time_new_now_local();
    if (!now) {
        return "00000000-000000";
    }
    gchar *stamp = g_date_time_format(now, "%Y%m%d-%H%M%S");
    std::string result = stamp ? stamp : "00000000-000000";
    g_free(stamp);
    g_date_time_unref(now);
    return result;
}
"""
    return text.replace(namespace_end, "\n" + helper + namespace_end, 1)



def restore_cleanup_pass8_historical_runtime(rel: str, data: bytes) -> bytes:
    """Restore only Cleanup Pass 8 production text for older byte freezes."""
    text = data.decode("utf-8")

    if rel == "addons/memory-tools/memory-tools-internal.hh":
        include_anchor = "#include <string>\n\nnamespace xemu_memory_tools_internal {"
        if text.count(include_anchor) != 1 or "#include <glib.h>" in text:
            raise AssertionError("Cleanup Pass 8 Memory Tools internal include normalization changed")
        text = text.replace(
            include_anchor,
            "#include <string>\n\n#include <glib.h>\n\nnamespace xemu_memory_tools_internal {",
            1,
        )
        namespace_end = "\n} // namespace xemu_memory_tools_internal\n"
        if text.count(namespace_end) != 1 or "static std::string make_dump_timestamp(" in text:
            raise AssertionError("Cleanup Pass 8 Memory Tools internal helper normalization changed")
        helper = """
static std::string make_dump_timestamp()
{
    GDateTime *now = g_date_time_new_now_local();
    if (!now) {
        return \"00000000-000000\";
    }
    gchar *stamp = g_date_time_format(now, \"%Y%m%d-%H%M%S\");
    std::string result = stamp ? stamp : \"00000000-000000\";
    g_free(stamp);
    g_date_time_unref(now);
    return result;
}
"""
        return text.replace(namespace_end, helper + namespace_end, 1).encode("utf-8")

    if rel == "xdvdfs-export-service.hh":
        include = '#include "host-export-result.hh"\n\n'
        alias = 'using Result = XemuHostExport::Result;\n'
        restored = (
            'struct Result {\n'
            '    std::string host_path;\n'
            '    uint64_t byte_count = 0;\n'
            '    uint32_t file_count = 0;\n'
            '    uint32_t directory_count = 0;\n'
            '    bool directory = false;\n'
            '};\n'
        )
        if text.count(include) != 1 or text.count(alias) != 1 or 'struct Result {' in text:
            raise AssertionError("Cleanup Pass 8 XDVDFS Result normalization changed")
        text = text.replace(include, '', 1).replace(alias, restored, 1)
        return text.encode("utf-8")

    if rel == "addons/hdd/hdd-export-service.hh":
        include = '#include "../../host-export-result.hh"\n\n'
        alias = 'using Result = XemuHostExport::Result;\n'
        restored = (
            'struct Result {\n'
            '    std::string host_path;\n'
            '    uint64_t byte_count = 0;\n'
            '    uint32_t file_count = 0;\n'
            '    uint32_t directory_count = 0;\n'
            '    bool directory = false;\n'
            '};\n'
        )
        if text.count(include) != 1 or text.count(alias) != 1 or 'struct Result {' in text:
            raise AssertionError("Cleanup Pass 8 HDD Result normalization changed")
        text = text.replace(include, '', 1).replace(alias, restored, 1)
        return text.encode("utf-8")

    if rel == "cheat-engine-memory.c":
        current = (
            "            /* Info: Page decoding may start between x86 instructions; reject\n"
            "             * speculative decodes that cross the exact focus address. */\n"
        )
        historical = (
            "            /* The page start is not guaranteed to be an x86 instruction\n"
            "             * boundary. Never let a speculative decode cross the exact focus\n"
            "             * address; resynchronize there exactly as the previous path did. */\n"
        )
        if text.count(current) != 1 or historical in text:
            raise AssertionError("Cleanup Pass 8 disassembly comment normalization changed")
        return text.replace(current, historical, 1).encode("utf-8")

    return data


def restore_pass12_windows_build_fix_historical_runtime(rel: str, data: bytes) -> bytes:
    """Restore the pre-Windows-build-fix Pass 12 source for older byte freezes."""
    text = data.decode("utf-8")

    if rel == "guest-pause-guard.cc":
        start = '#include "guest-pause-guard.hh"\n\n'
        signature = 'XemuDebugGuestPauseGuard::XemuDebugGuestPauseGuard()\n'
        start_pos = text.find(start)
        signature_pos = text.find(signature)
        if start_pos < 0 or signature_pos < 0 or signature_pos <= start_pos:
            raise AssertionError("Pass 12 Windows guest-pause restoration anchors changed")
        current_block = text[start_pos:signature_pos]
        for token in (
            'bool bql_locked(void);',
            'void bql_lock_impl(const char *file, int line);',
            'void bql_unlock(void);',
            'class XemuDebugBqlGuard',
            '#define BQL_LOCK_GUARD()',
        ):
            if token not in current_block:
                raise AssertionError(
                    f"Pass 12 Windows guest-pause restoration token changed: {token}"
                )
        historical_block = (
            '#include "guest-pause-guard.hh"\n'
            '#include "qemu/main-loop.h"\n\n'
            'extern "C" {\n'
            '#include "system/runstate.h"\n'
            '}\n\n'
        )
        text = text[:start_pos] + historical_block + text[signature_pos:]
        trailer = '\n#undef BQL_LOCK_GUARD\n'
        if text.count(trailer) != 1:
            raise AssertionError("Pass 12 Windows guest-pause macro trailer changed")
        return text.replace(trailer, '', 1).encode("utf-8")

    if rel == "addons/hdd/hdd-export-service.cc":
        replacements = (
            (
                'ExportEntryRecursive(hdd, length, partition, child,',
                'ExportEntryRecursive(hdd.Get(), length, partition, child,',
            ),
            (
                'XemuFatxHdd::StreamFile(xemu_disc_block_pread, hdd, length, partition,',
                'XemuFatxHdd::StreamFile(xemu_disc_block_pread, hdd.Get(), length, partition,',
            ),
        )
        for current, historical in replacements:
            if text.count(current) != 1 or historical in text:
                raise AssertionError(
                    "Pass 12 Windows HDD raw-handle restoration anchor changed"
                )
            text = text.replace(current, historical, 1)
        return text.encode("utf-8")

    return data


def restore_cleanup_pass6_external_le32(text: str) -> str:
    """Restore the pre-Cleanup-Pass-6 External Code LE32 helpers for old hashes.

    Pass 6 replaces only these two hand-written endian helpers with QEMU's
    already-included ldl_le_p/stl_le_p primitives. Historical guards call this
    normalizer so they continue freezing every unrelated byte of the old file.
    """
    old_load = "current_pde = xemu_ext_le32_load(pde_bytes);"
    new_load = "current_pde = (uint32_t)ldl_le_p(pde_bytes);"
    old_store = "xemu_ext_le32_store(pde_bytes, wanted_pde);"
    new_store = "stl_le_p(pde_bytes, wanted_pde);"
    for old, new in ((old_load, new_load), (old_store, new_store)):
        if new not in text or old in text:
            raise AssertionError("Cleanup Pass 6 External Code endian normalization precondition changed")
        text = text.replace(new, old, 1)

    anchor = "static bool xemu_ext_phys_range_unused(hwaddr base, uint64_t size)\n"
    if text.count(anchor) != 1 or "static uint32_t xemu_ext_le32_load(" in text:
        raise AssertionError("Cleanup Pass 6 External Code helper restoration anchor changed")
    legacy = """static uint32_t xemu_ext_le32_load(const uint8_t bytes[4])
{
    return (uint32_t)bytes[0] |
           ((uint32_t)bytes[1] << 8) |
           ((uint32_t)bytes[2] << 16) |
           ((uint32_t)bytes[3] << 24);
}

static void xemu_ext_le32_store(uint8_t bytes[4], uint32_t value)
{
    bytes[0] = (uint8_t)(value & 0xffu);
    bytes[1] = (uint8_t)((value >> 8) & 0xffu);
    bytes[2] = (uint8_t)((value >> 16) & 0xffu);
    bytes[3] = (uint8_t)((value >> 24) & 0xffu);
}

"""
    return text.replace(anchor, legacy + anchor, 1)



def restore_cleanup_pass6_rpc_le32(text: str) -> str:
    """Restore the pre-Cleanup-Pass-6 Guest RPC LE32 helpers for old hashes."""
    replacements = (
        (
            "if (((uint32_t)ldl_le_p(pde_bytes) & 1u) == 0) {",
            "if ((xemu_rpc_le32_load(pde_bytes) & 1u) == 0) {",
        ),
        (
            "stl_le_p(pde_bytes, xemu_rpc_wanted_pde);",
            "xemu_rpc_le32_store(pde_bytes, xemu_rpc_wanted_pde);",
        ),
        (
            "((uint32_t)ldl_le_p(pde_bytes) & 0xfffff087u) ==",
            "(xemu_rpc_le32_load(pde_bytes) & 0xfffff087u) ==",
        ),
    )
    for new, old in replacements:
        if text.count(new) != 1 or old in text:
            raise AssertionError(
                "Cleanup Pass 6 Guest RPC endian normalization precondition changed"
            )
        text = text.replace(new, old, 1)

    anchor = "static bool xemu_rpc_phys_range_unused(hwaddr base, uint64_t size)\n"
    if text.count(anchor) != 1 or "static uint32_t xemu_rpc_le32_load(" in text:
        raise AssertionError("Cleanup Pass 6 Guest RPC helper restoration anchor changed")
    legacy = """static uint32_t xemu_rpc_le32_load(const uint8_t p[4])
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void xemu_rpc_le32_store(uint8_t p[4], uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

"""
    return text.replace(anchor, legacy + anchor, 1)
