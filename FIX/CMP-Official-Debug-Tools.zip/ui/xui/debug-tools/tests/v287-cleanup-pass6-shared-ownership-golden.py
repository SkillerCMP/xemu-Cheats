#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 6: shared helper ownership and proven-dead constant guard."""
from __future__ import annotations

import argparse
from pathlib import Path

from v287_source_test_utils import extract_function


def require(text: str, token: str, label: str) -> None:
    if token not in text:
        raise AssertionError(f"missing {label}: {token}")


def forbid(text: str, token: str, label: str) -> None:
    if token in text:
        raise AssertionError(f"unexpected {label}: {token}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    root = Path(ap.parse_args().root).resolve()
    debug = root / "ui/xui/debug-tools"

    diag = (debug / "addons/diagnostics/diagnostics-backend.h").read_text(encoding="utf-8")
    flip_h = (debug / "addons/diagnostics/flip-stall-trace.h").read_text(encoding="utf-8")
    sched_h = (debug / "addons/diagnostics/scheduler-trace.h").read_text(encoding="utf-8")
    external = (debug / "external-code-memory.c").read_text(encoding="utf-8")
    rpc_memory = (debug / "addons/hdd/guest-kernel-rpc-memory.c").read_text(encoding="utf-8")
    rpc_utils = (debug / "addons/hdd/kernel-rpc-utils.hh").read_text(encoding="utf-8")
    host = (debug / "host-export-utils.hh").read_text(encoding="utf-8")
    hdd = (debug / "addons/hdd/hdd-export-service.cc").read_text(encoding="utf-8")
    xdv = (debug / "xdvdfs-export-service.cc").read_text(encoding="utf-8")
    rpc_ui = (debug / "addons/hdd/guest-kernel-rpc-ui.cc").read_text(encoding="utf-8")
    rpc_hh = (debug / "addons/hdd/guest-kernel-rpc.hh").read_text(encoding="utf-8")

    # Four backend aliases had zero uses. Trace-owned constants remain authoritative.
    for dead in (
        "XEMU_DIAG_FLIP_STALL_TRACE_CAPACITY",
        "XEMU_DIAG_SCHEDULER_TRACE_CAPACITY",
        "XEMU_DIAG_KI_IDLE_LOOP_START",
        "XEMU_DIAG_KI_IDLE_LOOP_END",
    ):
        forbid(diag, dead, "dead Diagnostics constant alias")
    require(flip_h, "#define XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY 4096",
            "authoritative FLIP_STALL trace capacity")
    for token in (
        "#define XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY 4096",
        "#define XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_START 0x8001B02Eu",
        "#define XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_END   0x8001B04Fu",
    ):
        require(sched_h, token, "authoritative scheduler trace constant")

    # The two C memory owners already included qemu/bswap.h; use its LE32 primitives
    # rather than maintaining four private load/store implementations.
    for text, prefix, label in (
        (external, "xemu_ext", "External Code"),
        (rpc_memory, "xemu_rpc", "Guest Kernel RPC"),
    ):
        require(text, '#include "qemu/bswap.h"', f"{label} QEMU endian include")
        forbid(text, f"{prefix}_le32_load", f"{label} private LE32 loader")
        forbid(text, f"{prefix}_le32_store", f"{label} private LE32 store")
        require(text, "ldl_le_p(pde_bytes)", f"{label} QEMU LE32 load")
        require(text, "stl_le_p(pde_bytes,", f"{label} QEMU LE32 store")
    require(external, "xemu_ext_phys_range_unused", "unchanged External Code aperture helper")
    require(rpc_memory, "xemu_rpc_phys_range_unused", "unchanged RPC aperture helper")
    require(rpc_utils, "inline uint16_t Le16(", "retained widely-used Kernel RPC LE16 wrapper")
    require(rpc_utils, "inline uint32_t Le32(", "retained widely-used Kernel RPC LE32 wrapper")

    # One shared exclusive-claim mechanism now owns the identical HDD/XDVDFS loops.
    require(host, "constexpr unsigned kUniquePathAttempts = 10000;",
            "10,000-attempt unique-path bound")
    open_unique = extract_function(host, "inline bool OpenUniqueHostFile(")
    for token in ("O_CREAT | O_EXCL | O_WRONLY", "errno == EEXIST", "fdopen(fd, \"wb\")",
                  "g_close(fd, nullptr)", "g_remove(candidate.c_str())", "error = exhausted_error"):
        require(open_unique, token, f"shared unique-file behavior {token}")
    create_unique = extract_function(host, "inline bool CreateUniqueHostDirectory(")
    for token in ("fs::create_directory(candidate, ec)", "ec == std::errc::file_exists",
                  "error = exhausted_error"):
        require(create_unique, token, f"shared unique-directory behavior {token}")

    service_errors = {
        "HDD": (hdd, (
            "Unable to exclusively create export file: ",
            "Unable to open the exclusively-created export file: ",
            "Could not claim a unique host export filename after 10000 attempts.",
            "Unable to exclusively create export folder: ",
            "Could not claim a unique host export folder after 10000 attempts.",
        )),
        "XDVDFS": (xdv, (
            "Unable to exclusively create disc export file: ",
            "Unable to open the exclusively-created disc export file: ",
            "Could not claim a unique disc export filename after 10000 attempts.",
            "Unable to exclusively create disc export folder: ",
            "Could not claim a unique disc export folder after 10000 attempts.",
        )),
    }
    for label, (text, errors) in service_errors.items():
        for helper in ("OpenUniqueHostFile", "CreateUniqueHostDirectory"):
            require(text, f"using XemuHostExportUtils::{helper};", f"{label} shared {helper} ownership")
        for duplicate in ("bool OpenUniqueHostFile(", "bool CreateUniqueHostDirectory(",
                          "NumberedCandidate(", "O_EXCL", "g_open(", "fs::create_directory("):
            forbid(text, duplicate, f"{label} duplicate host-claim implementation")
        for error in errors:
            require(text, error, f"unchanged {label} export error text")

    # Cleanup comments describe current ownership, not the history of the cleanup pass.
    forbid(rpc_ui, "during the final", "development-history UI comment")
    forbid(rpc_ui, "production cleanup", "development-history UI comment")
    require(rpc_ui, "Diagnostic rendering stays in the UI translation unit;",
            "current Kernel RPC UI ownership comment")
    forbid(rpc_hh, "can reuse the same preflight/planning layer later",
           "obsolete future-tense filesystem ownership comment")
    require(rpc_hh, "HDD browser operations share the async PASSIVE_LEVEL executor.",
            "current async executor ownership comment")
    require(rpc_hh, "Filesystem plan entries are shared with the HDD browser preflight layer.",
            "current filesystem plan ownership comment")

    provenance_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in [*sorted(debug.rglob("*.md")),
                     debug / "addons/diagnostics/diagnostics.cc"]
    )
    reference_only_phrases = (
        "XDK-" + "matched",
        "identified from " + "XDK " + "5849",
    )
    for provenance in reference_only_phrases:
        if provenance in provenance_text:
            raise AssertionError(
                "reference-only XDK provenance must not appear in the packaged source/docs"
            )

    print("PASS: Cleanup Pass 6 shared ownership/dead-constant invariants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
