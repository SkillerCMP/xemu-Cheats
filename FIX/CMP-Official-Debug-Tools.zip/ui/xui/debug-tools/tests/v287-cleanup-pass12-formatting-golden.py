#!/usr/bin/env python3
# v2.87 current regression ownership.
"""Cleanup Pass 12 whitespace-only Diagnostics readability guard."""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

PASS11_NON_WHITESPACE_SHA256 = {
    "pgraph-ptimer-latency-trace.c":
        "b68f51f654404cba79b2311896898fe4636fe84fefe4b49917d114e27b7ff5dc",
    "diagnostics.cc":
        "5cb0470524ea3d2523f1d0bb17c41494ff197da756e87fc8b38f0de0886be582",
}


def non_whitespace_sha256(data: bytes) -> str:
    return hashlib.sha256(re.sub(rb"\s+", b"", data)).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    root = Path(ap.parse_args().root).resolve()
    diag = root / "ui/xui/debug-tools/addons/diagnostics"

    latency_path = diag / "pgraph-ptimer-latency-trace.c"
    diagnostics_path = diag / "diagnostics.cc"

    for path in (latency_path, diagnostics_path):
        expected = PASS11_NON_WHITESPACE_SHA256[path.name]
        actual = non_whitespace_sha256(path.read_bytes())
        if actual != expected:
            raise AssertionError(
                f"Pass 12 changed non-whitespace source in {path.name}: {actual}"
            )

    latency_lines = latency_path.read_text(encoding="utf-8").splitlines()
    if max(map(len, latency_lines), default=0) > 100:
        raise AssertionError("latency recorder regained compressed >100-column source lines")

    diagnostics = diagnostics_path.read_text(encoding="utf-8")
    if "; ImGui::" in diagnostics:
        raise AssertionError("Diagnostics UI regained same-line ImGui statements")
    if "; if (e.guest_pc_valid)" in diagnostics:
        raise AssertionError("Diagnostics UI regained compressed conditional table rendering")
    if max(map(len, diagnostics.splitlines()), default=0) > 500:
        raise AssertionError("Diagnostics UI regained an extreme >500-column source line")

    print(
        "PASS: Cleanup Pass 12 preserves Pass-11 non-whitespace source while "
        "normalizing Diagnostics readability"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
