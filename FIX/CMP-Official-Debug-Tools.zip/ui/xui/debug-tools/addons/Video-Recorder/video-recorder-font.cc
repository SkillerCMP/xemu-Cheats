// Build a PRIVATE CPU font atlas, then copy its antialiased glyph coverage.
// Never read ImGui::GetIO().Fonts: detached UI/DPI rebuilds own that atlas.
#include "video-recorder-text.hh"
#include <imgui.h>
#include "data/RobotoCondensed-Regular.ttf.h"
#include <algorithm>
#include <cmath>

namespace XemuRecorderText {
bool LoadFont(int height, Glyphs &glyphs)
{
    ImFontAtlas atlas;
    ImFontConfig config;
    config.FontDataOwnedByAtlas = false;
    config.SizePixels = (float)height;
    // Rasterize at the recording's native text size. No horizontal compression
    // or thresholded resizing. stb_truetype's coverage retains smooth edges.
    config.OversampleH = 1;
    config.OversampleV = 1;
    config.PixelSnapH = true;
    static const ImWchar ranges[] = {32, 126, 0};
    ImFont *font = atlas.AddFontFromMemoryTTF(
        (void *)RobotoCondensed_Regular_data, RobotoCondensed_Regular_size,
        (float)height, &config, ranges);
    if (!font || !atlas.Build()) return false;
    unsigned char *pixels = nullptr;
    int width = 0, bitmap_height = 0;
    atlas.GetTexDataAsAlpha8(&pixels, &width, &bitmap_height);
    if (!pixels || width <= 0 || bitmap_height <= 0) return false;
    for (size_t i = 0; i < glyphs.size(); ++i) {
        const ImFontGlyph *src = font->FindGlyph((ImWchar)(i + 32));
        if (!src) return false;
        auto &dst = glyphs[i];
        dst.advance = src->AdvanceX;
        dst.x = (int)std::floor(src->X0 + 0.5f);
        dst.y = (int)std::floor(src->Y0 + 0.5f);
        const int sx = (int)std::floor(src->U0 * width + 0.5f);
        const int sy = (int)std::floor(src->V0 * bitmap_height + 0.5f);
        dst.width = (int)std::floor((src->U1 - src->U0) * width + 0.5f);
        dst.height = (int)std::floor((src->V1 - src->V0) * bitmap_height + 0.5f);
        if (dst.width < 0 || dst.height < 0 || sx < 0 || sy < 0 ||
            sx + dst.width > width || sy + dst.height > bitmap_height) return false;
        dst.alpha.resize((size_t)dst.width * dst.height);
        if (dst.width == 0 || dst.height == 0) continue;
        for (int row = 0; row < dst.height; ++row)
            std::copy_n(pixels + (size_t)(sy + row) * width + sx, dst.width,
                        dst.alpha.data() + (size_t)row * dst.width);
    }
    return true;
}
}
