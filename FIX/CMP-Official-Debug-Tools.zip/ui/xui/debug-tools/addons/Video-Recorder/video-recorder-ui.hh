#pragma once

/* Draw the Video Recording section inside xemu's General settings view. */
void cmp_video_recorder_draw_settings();
