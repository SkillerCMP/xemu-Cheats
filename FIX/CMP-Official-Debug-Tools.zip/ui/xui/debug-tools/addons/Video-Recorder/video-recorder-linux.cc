//
// Linux H.264/AAC recorder backend (FFmpeg/libav)
//

#include "video-recorder-platform.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/error.h>
#include <libavutil/opt.h>
#include <libavutil/version.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

namespace {

static constexpr int kAudioRate = 48000;
static constexpr int kAudioChannels = 2;

struct LinuxRecorder {
    AVFormatContext *format = nullptr;
    AVStream *video_stream = nullptr;
    AVStream *audio_stream = nullptr;
    AVCodecContext *video_codec = nullptr;
    AVCodecContext *audio_codec = nullptr;
    AVFrame *video_frame = nullptr;
    AVFrame *audio_frame = nullptr;
    AVPacket *packet = nullptr;
    SwsContext *sws = nullptr;
    SwrContext *swr = nullptr;
    std::vector<int16_t> audio_queue;
    int width = 0;
    int height = 0;
    int fps = 0;
    int audio_frame_size = 1024;
    int64_t audio_pts = 0;
    bool header_written = false;
    bool trailer_written = false;
};

static void SetError(char *error, size_t error_size, const std::string &text)
{
    if (!error || error_size == 0) {
        return;
    }
    snprintf(error, error_size, "%s", text.c_str());
}

static void SetAvError(char *error, size_t error_size, const char *where, int code)
{
    char detail[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(code, detail, sizeof(detail));
    std::string text = where;
    text += " failed: ";
    text += detail;
    SetError(error, error_size, text);
}

static void SetStereoLayout(AVCodecContext *ctx)
{
#if LIBAVUTIL_VERSION_MAJOR >= 57
    av_channel_layout_default(&ctx->ch_layout, kAudioChannels);
#else
    ctx->channel_layout = AV_CH_LAYOUT_STEREO;
    ctx->channels = kAudioChannels;
#endif
}

static void SetStereoLayout(AVFrame *frame)
{
#if LIBAVUTIL_VERSION_MAJOR >= 57
    av_channel_layout_default(&frame->ch_layout, kAudioChannels);
#else
    frame->channel_layout = AV_CH_LAYOUT_STEREO;
    frame->channels = kAudioChannels;
#endif
}

static bool WritePackets(LinuxRecorder *r, AVCodecContext *codec,
                         AVStream *stream, char *error, size_t error_size)
{
    for (;;) {
        const int ret = avcodec_receive_packet(codec, r->packet);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) {
            return true;
        }
        if (ret < 0) {
            SetAvError(error, error_size, "avcodec_receive_packet", ret);
            return false;
        }
        av_packet_rescale_ts(r->packet, codec->time_base, stream->time_base);
        r->packet->stream_index = stream->index;
        const int write_ret = av_interleaved_write_frame(r->format, r->packet);
        av_packet_unref(r->packet);
        if (write_ret < 0) {
            SetAvError(error, error_size, "av_interleaved_write_frame", write_ret);
            return false;
        }
    }
}

static bool SendFrame(LinuxRecorder *r, AVCodecContext *codec,
                      AVStream *stream, AVFrame *frame,
                      char *error, size_t error_size)
{
    const int ret = avcodec_send_frame(codec, frame);
    if (ret < 0) {
        SetAvError(error, error_size, "avcodec_send_frame", ret);
        return false;
    }
    return WritePackets(r, codec, stream, error, error_size);
}

static bool EncodeAudioBlock(LinuxRecorder *r, const int16_t *samples,
                             size_t frames, char *error, size_t error_size)
{
    if (!samples || frames == 0) {
        return true;
    }
    if (av_frame_make_writable(r->audio_frame) < 0) {
        SetError(error, error_size, "Could not prepare an AAC audio frame.");
        return false;
    }

    const uint8_t *input[1] = {
        reinterpret_cast<const uint8_t *>(samples),
    };
    const int converted = swr_convert(r->swr, r->audio_frame->data,
                                      r->audio_frame_size, input, (int)frames);
    if (converted < 0) {
        SetAvError(error, error_size, "swr_convert", converted);
        return false;
    }
    r->audio_frame->nb_samples = converted;
    r->audio_frame->pts = r->audio_pts;
    r->audio_pts += converted;
    return SendFrame(r, r->audio_codec, r->audio_stream, r->audio_frame,
                     error, error_size);
}

static bool DrainAudioQueue(LinuxRecorder *r, bool final,
                            char *error, size_t error_size)
{
    const size_t samples_per_block =
        (size_t)r->audio_frame_size * kAudioChannels;
    while (r->audio_queue.size() >= samples_per_block) {
        if (!EncodeAudioBlock(r, r->audio_queue.data(), r->audio_frame_size,
                              error, error_size)) {
            return false;
        }
        r->audio_queue.erase(r->audio_queue.begin(),
                             r->audio_queue.begin() + samples_per_block);
    }

    if (final && !r->audio_queue.empty()) {
        std::vector<int16_t> padded(samples_per_block, 0);
        std::copy(r->audio_queue.begin(), r->audio_queue.end(), padded.begin());
        r->audio_queue.clear();
        if (!EncodeAudioBlock(r, padded.data(), r->audio_frame_size,
                              error, error_size)) {
            return false;
        }
    }
    return true;
}

static void DestroyLinuxRecorder(LinuxRecorder *r)
{
    if (!r) {
        return;
    }
    if (r->format && r->format->pb) {
        avio_closep(&r->format->pb);
    }
    swr_free(&r->swr);
    if (r->sws) {
        sws_freeContext(r->sws);
    }
    av_packet_free(&r->packet);
    av_frame_free(&r->video_frame);
    av_frame_free(&r->audio_frame);
    avcodec_free_context(&r->video_codec);
    avcodec_free_context(&r->audio_codec);
    if (r->format) {
        avformat_free_context(r->format);
    }
    delete r;
}

} // namespace

extern "C" void *xemu_platform_video_recorder_create(
    const char *path, int width, int height, int fps, uint32_t video_bitrate,
    char *error, size_t error_size)
{
    if (!path || !path[0] || width <= 0 || height <= 0 || fps <= 0) {
        SetError(error, error_size, "Invalid Linux H.264 recorder parameters.");
        return nullptr;
    }

    LinuxRecorder *r = new LinuxRecorder();
    r->width = width;
    r->height = height;
    r->fps = fps;

    int ret = avformat_alloc_output_context2(&r->format, nullptr, "mp4", path);
    if (ret < 0 || !r->format) {
        SetAvError(error, error_size, "avformat_alloc_output_context2", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    const AVCodec *video_encoder = avcodec_find_encoder_by_name("libx264");
    if (!video_encoder) {
        video_encoder = avcodec_find_encoder(AV_CODEC_ID_H264);
    }
    if (!video_encoder) {
        SetError(error, error_size,
                 "No H.264 encoder is available in the installed FFmpeg libraries.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    r->video_stream = avformat_new_stream(r->format, nullptr);
    r->video_codec = avcodec_alloc_context3(video_encoder);
    if (!r->video_stream || !r->video_codec) {
        SetError(error, error_size, "Could not allocate the H.264 video stream.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->video_codec->codec_id = video_encoder->id;
    r->video_codec->codec_type = AVMEDIA_TYPE_VIDEO;
    r->video_codec->width = width;
    r->video_codec->height = height;
    r->video_codec->pix_fmt = AV_PIX_FMT_YUV420P;
    r->video_codec->time_base = AVRational{1, fps};
    r->video_codec->framerate = AVRational{fps, 1};
    r->video_codec->bit_rate = video_bitrate;
    r->video_codec->gop_size = fps * 2;
    r->video_codec->max_b_frames = 2;
    if (r->format->oformat->flags & AVFMT_GLOBALHEADER) {
        r->video_codec->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    }
    if (video_encoder->name && strcmp(video_encoder->name, "libx264") == 0) {
        av_opt_set(r->video_codec->priv_data, "preset", "veryfast", 0);
    }
    ret = avcodec_open2(r->video_codec, video_encoder, nullptr);
    if (ret < 0) {
        SetAvError(error, error_size, "avcodec_open2(H.264)", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->video_stream->time_base = r->video_codec->time_base;
    ret = avcodec_parameters_from_context(r->video_stream->codecpar, r->video_codec);
    if (ret < 0) {
        SetAvError(error, error_size, "avcodec_parameters_from_context(video)", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    const AVCodec *audio_encoder = avcodec_find_encoder(AV_CODEC_ID_AAC);
    if (!audio_encoder) {
        SetError(error, error_size,
                 "No AAC encoder is available in the installed FFmpeg libraries.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->audio_stream = avformat_new_stream(r->format, nullptr);
    r->audio_codec = avcodec_alloc_context3(audio_encoder);
    if (!r->audio_stream || !r->audio_codec) {
        SetError(error, error_size, "Could not allocate the AAC audio stream.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->audio_codec->codec_type = AVMEDIA_TYPE_AUDIO;
    r->audio_codec->codec_id = audio_encoder->id;
    r->audio_codec->sample_rate = kAudioRate;
    r->audio_codec->sample_fmt = audio_encoder->sample_fmts
                                     ? audio_encoder->sample_fmts[0]
                                     : AV_SAMPLE_FMT_FLTP;
    r->audio_codec->bit_rate = 192000;
    r->audio_codec->time_base = AVRational{1, kAudioRate};
    SetStereoLayout(r->audio_codec);
    if (r->format->oformat->flags & AVFMT_GLOBALHEADER) {
        r->audio_codec->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    }
    ret = avcodec_open2(r->audio_codec, audio_encoder, nullptr);
    if (ret < 0) {
        SetAvError(error, error_size, "avcodec_open2(AAC)", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->audio_stream->time_base = r->audio_codec->time_base;
    ret = avcodec_parameters_from_context(r->audio_stream->codecpar, r->audio_codec);
    if (ret < 0) {
        SetAvError(error, error_size, "avcodec_parameters_from_context(audio)", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    r->video_frame = av_frame_alloc();
    r->audio_frame = av_frame_alloc();
    r->packet = av_packet_alloc();
    if (!r->video_frame || !r->audio_frame || !r->packet) {
        SetError(error, error_size, "Could not allocate FFmpeg recording buffers.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    r->video_frame->format = r->video_codec->pix_fmt;
    r->video_frame->width = width;
    r->video_frame->height = height;
    if (av_frame_get_buffer(r->video_frame, 32) < 0) {
        SetError(error, error_size, "Could not allocate the H.264 video frame buffer.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    r->audio_frame_size = r->audio_codec->frame_size > 0
                              ? r->audio_codec->frame_size
                              : 1024;
    r->audio_frame->format = r->audio_codec->sample_fmt;
    r->audio_frame->sample_rate = kAudioRate;
    r->audio_frame->nb_samples = r->audio_frame_size;
    SetStereoLayout(r->audio_frame);
    if (av_frame_get_buffer(r->audio_frame, 0) < 0) {
        SetError(error, error_size, "Could not allocate the AAC audio frame buffer.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    r->sws = sws_getContext(width, height, AV_PIX_FMT_RGB24,
                            width, height, AV_PIX_FMT_YUV420P,
                            SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
    if (!r->sws) {
        SetError(error, error_size, "Could not create the FFmpeg RGB converter.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

#if LIBAVUTIL_VERSION_MAJOR >= 57
    AVChannelLayout input_layout = AV_CHANNEL_LAYOUT_STEREO;
    ret = swr_alloc_set_opts2(&r->swr, &r->audio_codec->ch_layout,
                              r->audio_codec->sample_fmt, kAudioRate,
                              &input_layout, AV_SAMPLE_FMT_S16, kAudioRate,
                              0, nullptr);
    av_channel_layout_uninit(&input_layout);
    if (ret < 0) {
        SetAvError(error, error_size, "swr_alloc_set_opts2", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }
#else
    r->swr = swr_alloc_set_opts(nullptr, AV_CH_LAYOUT_STEREO,
                                r->audio_codec->sample_fmt, kAudioRate,
                                AV_CH_LAYOUT_STEREO, AV_SAMPLE_FMT_S16,
                                kAudioRate, 0, nullptr);
#endif
    if (!r->swr || swr_init(r->swr) < 0) {
        SetError(error, error_size, "Could not initialize the FFmpeg audio converter.");
        DestroyLinuxRecorder(r);
        return nullptr;
    }

    ret = avio_open(&r->format->pb, path, AVIO_FLAG_WRITE);
    if (ret < 0) {
        SetAvError(error, error_size, "avio_open", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    ret = avformat_write_header(r->format, nullptr);
    if (ret < 0) {
        SetAvError(error, error_size, "avformat_write_header", ret);
        DestroyLinuxRecorder(r);
        return nullptr;
    }
    r->header_written = true;
    return r;
}

extern "C" bool xemu_platform_video_recorder_write_video(
    void *handle, const uint8_t *rgb, size_t rgb_size, uint64_t frame_index,
    char *error, size_t error_size)
{
    LinuxRecorder *r = static_cast<LinuxRecorder *>(handle);
    if (!r || !rgb || rgb_size != (size_t)r->width * r->height * 3) {
        SetError(error, error_size, "Invalid Linux H.264 video frame.");
        return false;
    }
    if (av_frame_make_writable(r->video_frame) < 0) {
        SetError(error, error_size, "Could not prepare an H.264 video frame.");
        return false;
    }
    const uint8_t *src[1] = {rgb};
    const int src_stride[1] = {r->width * 3};
    const int rows = sws_scale(r->sws, src, src_stride, 0, r->height,
                               r->video_frame->data, r->video_frame->linesize);
    if (rows != r->height) {
        SetError(error, error_size, "FFmpeg did not convert the complete video frame.");
        return false;
    }
    r->video_frame->pts = (int64_t)frame_index;
    return SendFrame(r, r->video_codec, r->video_stream, r->video_frame,
                     error, error_size);
}

extern "C" bool xemu_platform_video_recorder_write_audio(
    void *handle, const int16_t *samples, size_t frames,
    uint64_t audio_frame_index, char *error, size_t error_size)
{
    LinuxRecorder *r = static_cast<LinuxRecorder *>(handle);
    if (!r || !samples || frames == 0) {
        SetError(error, error_size, "Invalid Linux AAC audio block.");
        return false;
    }
    if (r->audio_queue.empty()) {
        r->audio_pts = (int64_t)audio_frame_index;
    }
    const size_t sample_count = frames * kAudioChannels;
    r->audio_queue.insert(r->audio_queue.end(), samples, samples + sample_count);
    return DrainAudioQueue(r, false, error, error_size);
}

extern "C" bool xemu_platform_video_recorder_finish(
    void *handle, char *error, size_t error_size)
{
    LinuxRecorder *r = static_cast<LinuxRecorder *>(handle);
    if (!r || !r->header_written) {
        SetError(error, error_size, "The Linux H.264 recorder was not initialized.");
        return false;
    }
    if (!DrainAudioQueue(r, true, error, error_size)) {
        return false;
    }
    if (!SendFrame(r, r->video_codec, r->video_stream, nullptr,
                   error, error_size) ||
        !SendFrame(r, r->audio_codec, r->audio_stream, nullptr,
                   error, error_size)) {
        return false;
    }
    const int ret = av_write_trailer(r->format);
    if (ret < 0) {
        SetAvError(error, error_size, "av_write_trailer", ret);
        return false;
    }
    r->trailer_written = true;
    return true;
}

extern "C" void xemu_platform_video_recorder_destroy(void *handle)
{
    DestroyLinuxRecorder(static_cast<LinuxRecorder *>(handle));
}
