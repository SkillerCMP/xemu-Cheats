# Video Recorder Addon

This directory owns the complete gameplay video recorder implementation.

Upstream xemu files should contain only the minimal integration hooks needed to:
- expose recording settings in the main menu;
- capture the rendered gameplay framebuffer;
- feed the Xbox audio mix to the recorder;
- handle the F9 record toggle;
- expose a raw-RGB framebuffer helper used by the addon;
- declare platform encoder dependencies.

Platform backends live here as well:
- Windows: Media Foundation
- Linux: FFmpeg/libav
- macOS: AVFoundation / VideoToolbox

## Build profiles

The recorder is independent of the Debug Tools windows. The internal `folder-hdd`
profile is the dedicated **XEMU + Folder-HDD / Video Recorder** build: it keeps
Folder-HDD and this recorder while excluding Current Game/Cheat Engine, HDD
Directory, Memory Tools, and Diagnostics. `full` builds all addons and Debug Tools.
