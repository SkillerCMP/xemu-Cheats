#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void xemu_video_recorder_toggle(void);
void xemu_video_recorder_capture(unsigned int tex, int flip);
void xemu_video_recorder_submit_audio(const int16_t *samples, size_t frames,
                                      float gain);

#ifdef __cplusplus
}
#endif
