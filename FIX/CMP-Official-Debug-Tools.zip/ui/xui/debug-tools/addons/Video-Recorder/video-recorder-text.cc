#include "video-recorder-text.hh"
#include <algorithm>
#include <cmath>
#include <limits>

namespace XemuRecorderText {
static size_t GlyphIndex(unsigned char c)
{
    return (c >= 32 && c <= 126 ? c : (unsigned char)'?') - 32;
}
bool Renderer::EnsureFont(int height)
{
    height = std::clamp(height, 8, 256);
    if (height == m_height) return true;
    Glyphs next;
    if (!LoadFont(height, next)) return false;
    m_glyphs.swap(next);
    m_height = height;
    return true;
}
float Renderer::Measure(const std::string &text) const
{
    float width = 0;
    for (unsigned char c : text) width += m_glyphs[GlyphIndex(c)].advance;
    return width;
}
std::vector<std::string> Renderer::Wrap(const std::string &text, int width) const
{
    std::vector<std::string> lines;
    const float limit = (float)std::max(1, width);
    size_t pos = 0;
    while (pos < text.size()) {
        float used = 0;
        size_t end = pos, space = std::string::npos;
        while (end < text.size()) {
            const float advance = m_glyphs[GlyphIndex((unsigned char)text[end])].advance;
            if (used + advance > limit && end > pos) break;
            used += advance;
            if (text[end] == ' ') space = end;
            ++end;
        }
        if (end < text.size() && space != std::string::npos && space > pos) end = space;
        size_t last = end;
        while (last > pos && text[last - 1] == ' ') --last;
        lines.push_back(text.substr(pos, last - pos));
        pos = end;
        while (pos < text.size() && text[pos] == ' ') ++pos;
    }
    if (lines.empty()) lines.emplace_back();
    return lines;
}
void Renderer::Draw(std::vector<uint8_t> &rgb, int width, int height,
                    int x, int y, int clip_width, const std::string &text,
                    uint8_t r, uint8_t g, uint8_t b) const
{
    if (!m_height || width <= 0 || height <= 0 || clip_width <= 0 ||
        (size_t)width > std::numeric_limits<size_t>::max() / 3u / (size_t)height ||
        rgb.size() < (size_t)width * (size_t)height * 3u) return;
    const int64_t right = std::min<int64_t>(width, (int64_t)x + clip_width);
    const uint8_t color[3] = {r, g, b};
    float cursor = (float)x;
    for (unsigned char c : text) {
        const auto &glyph = m_glyphs[GlyphIndex(c)];
        if (!std::isfinite(cursor) || cursor > (float)width + 256.0f) break;
        const int64_t gx = (int64_t)std::floor(cursor + 0.5f) + glyph.x;
        const int64_t gy = (int64_t)y + glyph.y;
        if (glyph.width > 0 && glyph.height > 0 &&
            glyph.alpha.size() >= (size_t)glyph.width * (size_t)glyph.height) {
            for (int py = 0; py < glyph.height; ++py) {
                if (gy + py < 0 || gy + py >= height) continue;
                for (int px = 0; px < glyph.width; ++px) {
                    if (gx + px < std::max(0, x) || gx + px >= right) continue;
                    const unsigned a = glyph.alpha[(size_t)py * glyph.width + px];
                    if (a == 0) continue;
                    const size_t offset = ((size_t)(gy + py) * width + (size_t)(gx + px)) * 3;
                    for (size_t k = 0; k < 3; ++k)
                        rgb[offset + k] = (uint8_t)((color[k] * a + rgb[offset + k] * (255u - a) + 127u) / 255u);
                }
            }
        }
        cursor += glyph.advance;
    }
}
}
