//
// xemu gameplay video recorder
//

#include "video-recorder.hh"
#include "video-recorder-c.h"
#if defined(__linux__) || defined(__APPLE__)
#include "video-recorder-platform.h"
#endif

#include <SDL3/SDL.h>
#include <fpng.h>
#include <glib.h>
#include <glib/gstdio.h>

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <limits>
#include <string>
#include <vector>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mfapi.h>
#include <mferror.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#endif

#include "../../../../vgafont.h"
#include "../../../../xemu-notifications.h"
#include "xemu-config.h"
#include "../../../../xemu-settings.h"

extern struct config g_config;

bool RenderFramebufferToRgb(unsigned int tex, bool flip,
                            std::vector<uint8_t> &pixels, int &width,
                            int &height, int max_width = 0,
                            int max_height = 0);
bool debug_tools_cheat_overlay_available();
void debug_tools_get_active_cheat_details(std::vector<std::string> &names,
                                          std::vector<std::string> &credits,
                                          std::vector<std::string> &groups);

VideoRecorder g_video_recorder;

namespace {

static constexpr uint32_t kAudioRate = 48000;
static constexpr uint16_t kAudioChannels = 2;
static constexpr uint16_t kAudioBits = 16;
static constexpr uint16_t kAudioBlockAlign =
    kAudioChannels * (kAudioBits / 8);
static constexpr uint32_t kAudioBytesPerSecond =
    kAudioRate * kAudioBlockAlign;

static uint64_t HostNowNs()
{
    return (uint64_t)SDL_GetTicks() * 1000000ULL;
}

static std::string DefaultVideoDirectory()
{
    char *base_dir = nullptr;

#if defined(__linux__)
    const char *appimage = g_getenv("APPIMAGE");
    if (appimage && appimage[0]) {
        char *absolute_appimage = g_canonicalize_filename(appimage, nullptr);
        if (absolute_appimage && absolute_appimage[0]) {
            base_dir = g_path_get_dirname(absolute_appimage);
        }
        g_free(absolute_appimage);
    }
#endif

    if (!base_dir) {
        const char *sdl_base = SDL_GetBasePath();
        if (sdl_base && sdl_base[0]) {
            base_dir = g_strdup(sdl_base);
        }
    }
    if (!base_dir || !base_dir[0]) {
        g_free(base_dir);
        return {};
    }

    char *videos = g_build_filename(base_dir, "Videos", nullptr);
    std::string result = videos ? videos : "";
    g_free(videos);
    g_free(base_dir);
    return result;
}

static bool EnsureVideoDirectory(const std::string &path)
{
    if (path.empty()) {
        return false;
    }
    if (g_file_test(path.c_str(), G_FILE_TEST_IS_DIR)) {
        return true;
    }
    if (g_file_test(path.c_str(), G_FILE_TEST_EXISTS)) {
        return false;
    }
    return g_mkdir_with_parents(path.c_str(), 0755) == 0;
}

static int64_t FileTell(FILE *file)
{
#ifdef _WIN32
    return _ftelli64(file);
#else
    return ftello(file);
#endif
}

static bool FileSeek(FILE *file, int64_t offset)
{
#ifdef _WIN32
    return _fseeki64(file, offset, SEEK_SET) == 0;
#else
    return fseeko(file, offset, SEEK_SET) == 0;
#endif
}

static void WriteFourCC(FILE *file, const char text[4])
{
    fwrite(text, 1, 4, file);
}

static void WriteU16(FILE *file, uint16_t value)
{
    uint8_t b[2] = {
        (uint8_t)(value & 0xFF),
        (uint8_t)((value >> 8) & 0xFF),
    };
    fwrite(b, 1, sizeof(b), file);
}

static void WriteU32(FILE *file, uint32_t value)
{
    uint8_t b[4] = {
        (uint8_t)(value & 0xFF),
        (uint8_t)((value >> 8) & 0xFF),
        (uint8_t)((value >> 16) & 0xFF),
        (uint8_t)((value >> 24) & 0xFF),
    };
    fwrite(b, 1, sizeof(b), file);
}

static bool PatchU32(FILE *file, int64_t position, uint32_t value)
{
    const int64_t current = FileTell(file);
    if (current < 0 || !FileSeek(file, position)) {
        return false;
    }
    WriteU32(file, value);
    return FileSeek(file, current);
}

static std::string SanitizeAscii(const std::string &text)
{
    std::string out;
    out.reserve(text.size());
    for (unsigned char c : text) {
        if (c >= 32 && c <= 126) {
            out.push_back((char)c);
        } else {
            out.push_back('?');
        }
    }
    return out;
}

static std::string TruncateText(const std::string &text, int max_chars)
{
    if (max_chars <= 0) {
        return {};
    }
    std::string out = SanitizeAscii(text);
    if ((int)out.size() <= max_chars) {
        return out;
    }
    if (max_chars <= 3) {
        out.resize((size_t)max_chars);
        return out;
    }
    out.resize((size_t)max_chars - 3);
    out += "...";
    return out;
}

static std::string ChooseOutputPath(const char *output_dir, bool h264)
{
    const char *extension = h264 ? ".mp4" : ".avi";
    char fname[160] = {};
    time_t t = time(nullptr);
    struct tm *tmp = localtime(&t);
    if (tmp) {
        char stamp[128] = {};
        strftime(stamp, sizeof(stamp), "xemu-%Y-%m-%d-%H-%M-%S", tmp);
        snprintf(fname, sizeof(fname), "%s%s", stamp, extension);
    } else {
        snprintf(fname, sizeof(fname), "xemu-video%s", extension);
    }

    char *candidate = g_build_filename(output_dir, fname, NULL);
    if (candidate && !g_file_test(candidate, G_FILE_TEST_EXISTS)) {
        std::string result = candidate;
        g_free(candidate);
        return result;
    }
    g_free(candidate);

    for (unsigned int i = 1; i < 1000; ++i) {
        snprintf(fname, sizeof(fname), "xemu-video-%03u%s", i, extension);
        candidate = g_build_filename(output_dir, fname, NULL);
        if (candidate && !g_file_test(candidate, G_FILE_TEST_EXISTS)) {
            std::string result = candidate;
            g_free(candidate);
            return result;
        }
        g_free(candidate);
    }
    return {};
}

static uint32_t H264BitrateForFormat(int format, int width, int height, int fps)
{
    const uint64_t pixels_per_second =
        (uint64_t)width * (uint64_t)height * (uint64_t)fps;
    uint64_t bitrate = 0;
    uint64_t minimum = 0;
    uint64_t maximum = 0;
    switch (format) {
    case 2: // Small File
        bitrate = pixels_per_second * 12 / 100;
        minimum = 2000000;
        maximum = 6000000;
        break;
    case 1: // Standard
        bitrate = pixels_per_second * 22 / 100;
        minimum = 4000000;
        maximum = 12000000;
        break;
    case 0: // High Quality
    default:
        bitrate = pixels_per_second * 35 / 100;
        minimum = 6000000;
        maximum = 20000000;
        break;
    }
    bitrate = std::max(minimum, std::min(maximum, bitrate));
    return (uint32_t)bitrate;
}

#ifdef _WIN32

template <typename T>
static void SafeRelease(T *&object)
{
    if (object) {
        object->Release();
        object = nullptr;
    }
}

static std::string MfFailure(const char *where, HRESULT hr)
{
    char text[192];
    snprintf(text, sizeof(text), "%s failed (HRESULT 0x%08lX).", where,
             (unsigned long)hr);
    return text;
}

static inline uint8_t ClampByte(int value)
{
    return (uint8_t)std::max(0, std::min(255, value));
}

static void RgbToNv12(const std::vector<uint8_t> &rgb, int width, int height,
                      std::vector<uint8_t> &nv12)
{
    const size_t y_size = (size_t)width * (size_t)height;
    nv12.resize(y_size + y_size / 2);
    uint8_t *y_plane = nv12.data();
    uint8_t *uv_plane = nv12.data() + y_size;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const size_t p = ((size_t)y * width + x) * 3;
            const int r = rgb[p + 0];
            const int g = rgb[p + 1];
            const int b = rgb[p + 2];
            y_plane[(size_t)y * width + x] =
                ClampByte(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
        }
    }

    for (int y = 0; y < height; y += 2) {
        for (int x = 0; x < width; x += 2) {
            int sum_u = 0;
            int sum_v = 0;
            for (int dy = 0; dy < 2; ++dy) {
                for (int dx = 0; dx < 2; ++dx) {
                    const size_t p =
                        ((size_t)(y + dy) * width + (x + dx)) * 3;
                    const int r = rgb[p + 0];
                    const int g = rgb[p + 1];
                    const int b = rgb[p + 2];
                    sum_u += ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                    sum_v += ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                }
            }
            const size_t uv = (size_t)(y / 2) * width + x;
            uv_plane[uv + 0] = ClampByte((sum_u + 2) / 4);
            uv_plane[uv + 1] = ClampByte((sum_v + 2) / 4);
        }
    }
}

#endif

} // namespace

VideoRecorder::VideoRecorder() = default;

VideoRecorder::~VideoRecorder()
{
    if (m_recording.load() || m_file
#ifdef _WIN32
        || m_sink_writer
#else
        || m_h264_backend
#endif
    ) {
        Stop();
    }
}

bool VideoRecorder::Start()
{
    if (m_recording.load()) {
        return true;
    }

    const char *configured_dir = g_config.general.video_recording.output_dir;
    const bool had_configured_dir = configured_dir && configured_dir[0];
    std::string fallback_dir;
    const char *output_dir = configured_dir;

    if (!had_configured_dir ||
        !g_file_test(configured_dir, G_FILE_TEST_EXISTS)) {
        fallback_dir = DefaultVideoDirectory();
        if (!EnsureVideoDirectory(fallback_dir)) {
            std::string error =
                "Could not create the default Videos folder beside the xemu executable: ";
            error += fallback_dir.empty() ? "<unknown>" : fallback_dir;
            xemu_queue_error_message(error.c_str());
            return false;
        }
        if (had_configured_dir) {
            xemu_queue_notification(
                "Configured video folder was missing. Using the xemu Videos folder.");
        }
        xemu_settings_set_string(&g_config.general.video_recording.output_dir,
                                 fallback_dir.c_str());
        output_dir = g_config.general.video_recording.output_dir;
    } else if (!g_file_test(configured_dir, G_FILE_TEST_IS_DIR)) {
        std::string error =
            "Video output path exists but is not a directory: ";
        error += configured_dir;
        xemu_queue_error_message(error.c_str());
        return false;
    }

    m_format = std::clamp((int)g_config.general.video_recording.format, 0, 3);
    m_h264 = m_format < 3;
    m_output_path = ChooseOutputPath(output_dir, m_h264);
    if (m_output_path.empty()) {
        xemu_queue_error_message("Could not choose a unique video output filename.");
        return false;
    }

    if (!m_h264) {
        m_file = g_fopen(m_output_path.c_str(), "wb+");
        if (!m_file) {
            std::string error = "Could not create video file '";
            error += m_output_path;
            error += "': ";
            error += g_strerror(errno);
            xemu_queue_error_message(error.c_str());
            m_output_path.clear();
            return false;
        }
    }

    m_fps = ((int)g_config.general.video_recording.fps == 1) ? 60 : 30;
    m_frame_interval_ns = 1000000000ULL / (uint64_t)m_fps;
    m_show_codes = g_config.general.video_recording.show_active_codes &&
                   debug_tools_cheat_overlay_available();
    m_panel_position = std::clamp((int)g_config.general.video_recording.panel_position,
                                  0, 1);
    m_next_frame_ns = 0;
    m_frames = 0;
    m_max_frame_size = 0;
    m_max_audio_chunk_size = 0;
    m_audio_frames_written = 0;
    m_width = 0;
    m_height = 0;
    m_header_written = false;
    m_index.clear();
    m_backend_error.clear();
    {
        std::lock_guard<std::mutex> lock(m_audio_mutex);
        m_audio_pending.clear();
    }
    m_recording.store(true);
    m_status = "Recording";
    xemu_queue_notification("Video recording started. Press F9 to stop.");
    return true;
}

void VideoRecorder::Toggle()
{
    if (m_recording.load()) {
        Stop();
    } else {
        Start();
    }
}

void VideoRecorder::Stop()
{
    if (!m_recording.exchange(false) && !m_file && !HasH264Backend()) {
        return;
    }

    bool saved = false;
    DrainPendingAudio();

    if (m_h264) {
        if (HasH264Backend() && m_frames > 0) {
            saved = FinalizeH264();
        }
        ReleaseH264();
    } else {
        if (m_file && m_header_written && m_frames > 0) {
            saved = FinalizeAvi();
        }
        if (m_file) {
            fclose(m_file);
            m_file = nullptr;
        }
    }

    if (!saved && !m_output_path.empty()) {
        g_remove(m_output_path.c_str());
    }

    const std::string saved_path = m_output_path;
    m_header_written = false;
    m_next_frame_ns = 0;
    m_status = saved ? "Saved" : "Stopped";
    m_index.clear();
    {
        std::lock_guard<std::mutex> lock(m_audio_mutex);
        m_audio_pending.clear();
    }

    if (saved) {
        std::string msg = "Video saved: ";
        msg += saved_path;
        xemu_queue_notification(msg.c_str());
    } else if (!saved_path.empty()) {
        if (!m_backend_error.empty()) {
            xemu_queue_error_message(m_backend_error.c_str());
        } else {
            xemu_queue_notification("Video recording stopped before a frame was saved.");
        }
    }
}

void VideoRecorder::Abort(const char *message)
{
    m_recording.store(false);
    ReleaseH264();
    if (m_file) {
        fclose(m_file);
        m_file = nullptr;
    }
    if (!m_output_path.empty()) {
        g_remove(m_output_path.c_str());
    }
    m_header_written = false;
    m_status = "Error";
    m_index.clear();
    {
        std::lock_guard<std::mutex> lock(m_audio_mutex);
        m_audio_pending.clear();
    }
    xemu_queue_error_message(message);
}

void VideoRecorder::SubmitAudio(const int16_t *samples, size_t frames,
                                float gain)
{
    if (!samples || frames == 0 || !m_recording.load()) {
        return;
    }

    const size_t sample_count = frames * kAudioChannels;
    std::lock_guard<std::mutex> lock(m_audio_mutex);
    if (!m_recording.load()) {
        return;
    }
    const size_t old_size = m_audio_pending.size();
    m_audio_pending.resize(old_size + sample_count);
    if (gain >= 0.999f && gain <= 1.001f) {
        memcpy(m_audio_pending.data() + old_size, samples,
               sample_count * sizeof(int16_t));
        return;
    }
    for (size_t i = 0; i < sample_count; ++i) {
        const int value = (int)((float)samples[i] * gain);
        m_audio_pending[old_size + i] =
            (int16_t)std::max(-32768, std::min(32767, value));
    }
}

void VideoRecorder::DrainPendingAudio()
{
    std::vector<int16_t> pending;
    {
        std::lock_guard<std::mutex> lock(m_audio_mutex);
        if (m_audio_pending.empty()) {
            return;
        }
        pending.swap(m_audio_pending);
    }

    const size_t frames = pending.size() / kAudioChannels;
    if (frames == 0) {
        return;
    }

    bool ok = true;
    if (m_h264) {
        if (HasH264Backend()) {
            ok = WriteH264Audio(pending.data(), frames);
        } else {
            std::lock_guard<std::mutex> lock(m_audio_mutex);
            m_audio_pending.insert(m_audio_pending.begin(), pending.begin(),
                                   pending.end());
            return;
        }
    } else if (m_header_written) {
        ok = WriteAudioPcm(pending.data(), frames);
    } else {
        std::lock_guard<std::mutex> lock(m_audio_mutex);
        m_audio_pending.insert(m_audio_pending.begin(), pending.begin(),
                               pending.end());
        return;
    }

    if (!ok && m_backend_error.empty()) {
        m_backend_error = "Video recording stopped because game audio could not be written.";
    }
}

bool VideoRecorder::BeginAvi(int width, int height)
{
    if (!m_file || width <= 0 || height <= 0) {
        return false;
    }

    m_width = width;
    m_height = height;

    WriteFourCC(m_file, "RIFF");
    m_riff_size_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteFourCC(m_file, "AVI ");

    WriteFourCC(m_file, "LIST");
    const int64_t hdrl_size_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteFourCC(m_file, "hdrl");

    WriteFourCC(m_file, "avih");
    WriteU32(m_file, 56);
    WriteU32(m_file, 1000000u / (uint32_t)m_fps);
    m_avih_max_bytes_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0x10); // AVIF_HASINDEX
    m_avih_total_frames_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 2);
    m_avih_suggested_buffer_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteU32(m_file, (uint32_t)width);
    WriteU32(m_file, (uint32_t)height);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);

    WriteFourCC(m_file, "LIST");
    const int64_t video_strl_size_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteFourCC(m_file, "strl");

    WriteFourCC(m_file, "strh");
    WriteU32(m_file, 56);
    WriteFourCC(m_file, "vids");
    WriteFourCC(m_file, "MPNG");
    WriteU32(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 1);
    WriteU32(m_file, (uint32_t)m_fps);
    WriteU32(m_file, 0);
    m_strh_length_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    m_strh_suggested_buffer_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0xFFFFFFFFu);
    WriteU32(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, (uint16_t)std::min(width, 32767));
    WriteU16(m_file, (uint16_t)std::min(height, 32767));

    WriteFourCC(m_file, "strf");
    WriteU32(m_file, 40);
    WriteU32(m_file, 40);
    WriteU32(m_file, (uint32_t)width);
    WriteU32(m_file, (uint32_t)height);
    WriteU16(m_file, 1);
    WriteU16(m_file, 24);
    WriteFourCC(m_file, "MPNG");
    WriteU32(m_file, (uint32_t)width * (uint32_t)height * 3u);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);

    const int64_t video_strl_end = FileTell(m_file);
    if (!PatchU32(m_file, video_strl_size_pos,
                  (uint32_t)(video_strl_end - (video_strl_size_pos + 4)))) {
        return false;
    }

    WriteFourCC(m_file, "LIST");
    const int64_t audio_strl_size_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteFourCC(m_file, "strl");

    WriteFourCC(m_file, "strh");
    WriteU32(m_file, 56);
    WriteFourCC(m_file, "auds");
    WriteU32(m_file, 0);
    WriteU32(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);
    WriteU32(m_file, 0);
    WriteU32(m_file, kAudioBlockAlign);
    WriteU32(m_file, kAudioBytesPerSecond);
    WriteU32(m_file, 0);
    m_audio_strh_length_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    m_audio_strh_suggested_buffer_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteU32(m_file, 0xFFFFFFFFu);
    WriteU32(m_file, kAudioBlockAlign);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);
    WriteU16(m_file, 0);

    WriteFourCC(m_file, "strf");
    WriteU32(m_file, 16);
    WriteU16(m_file, 1); // PCM
    WriteU16(m_file, kAudioChannels);
    WriteU32(m_file, kAudioRate);
    WriteU32(m_file, kAudioBytesPerSecond);
    WriteU16(m_file, kAudioBlockAlign);
    WriteU16(m_file, kAudioBits);

    const int64_t audio_strl_end = FileTell(m_file);
    if (!PatchU32(m_file, audio_strl_size_pos,
                  (uint32_t)(audio_strl_end - (audio_strl_size_pos + 4)))) {
        return false;
    }

    const int64_t hdrl_end = FileTell(m_file);
    if (!PatchU32(m_file, hdrl_size_pos,
                  (uint32_t)(hdrl_end - (hdrl_size_pos + 4)))) {
        return false;
    }

    m_movi_list_start = FileTell(m_file);
    WriteFourCC(m_file, "LIST");
    m_movi_size_pos = FileTell(m_file);
    WriteU32(m_file, 0);
    WriteFourCC(m_file, "movi");

    if (ferror(m_file)) {
        return false;
    }
    m_header_written = true;
    return true;
}

bool VideoRecorder::WriteFrame(const std::vector<uint8_t> &frame_data)
{
    if (!m_file || frame_data.empty() || frame_data.size() > UINT32_MAX) {
        return false;
    }

    const int64_t chunk_pos = FileTell(m_file);
    if (chunk_pos < 0 || chunk_pos > 0xE0000000LL) {
        return false;
    }

    WriteFourCC(m_file, "00dc");
    WriteU32(m_file, (uint32_t)frame_data.size());
    fwrite(frame_data.data(), 1, frame_data.size(), m_file);
    if (frame_data.size() & 1) {
        fputc(0, m_file);
    }
    if (ferror(m_file)) {
        return false;
    }

    IndexEntry entry;
    entry.audio = false;
    entry.offset = (uint32_t)(chunk_pos - (m_movi_list_start + 8));
    entry.size = (uint32_t)frame_data.size();
    m_index.push_back(entry);
    ++m_frames;
    m_max_frame_size = std::max(m_max_frame_size, entry.size);
    return true;
}

bool VideoRecorder::WriteAudioPcm(const int16_t *samples, size_t frames)
{
    if (!m_file || !samples || frames == 0) {
        return false;
    }
    const size_t bytes = frames * kAudioBlockAlign;
    if (bytes > UINT32_MAX) {
        return false;
    }

    const int64_t chunk_pos = FileTell(m_file);
    if (chunk_pos < 0 || chunk_pos > 0xE0000000LL) {
        return false;
    }

    WriteFourCC(m_file, "01wb");
    WriteU32(m_file, (uint32_t)bytes);
    fwrite(samples, 1, bytes, m_file);
    if (bytes & 1) {
        fputc(0, m_file);
    }
    if (ferror(m_file)) {
        return false;
    }

    IndexEntry entry;
    entry.audio = true;
    entry.offset = (uint32_t)(chunk_pos - (m_movi_list_start + 8));
    entry.size = (uint32_t)bytes;
    m_index.push_back(entry);
    m_audio_frames_written += frames;
    m_max_audio_chunk_size = std::max(m_max_audio_chunk_size, entry.size);
    return true;
}

bool VideoRecorder::FinalizeAvi()
{
    if (!m_file || !m_header_written) {
        return false;
    }

    const int64_t movi_end = FileTell(m_file);
    if (movi_end < 0 || movi_end > UINT32_MAX) {
        return false;
    }
    if (!PatchU32(m_file, m_movi_size_pos,
                  (uint32_t)(movi_end - (m_movi_size_pos + 4)))) {
        return false;
    }
    if (!FileSeek(m_file, movi_end)) {
        return false;
    }

    WriteFourCC(m_file, "idx1");
    WriteU32(m_file, (uint32_t)m_index.size() * 16u);
    for (const IndexEntry &entry : m_index) {
        WriteFourCC(m_file, entry.audio ? "01wb" : "00dc");
        WriteU32(m_file, 0x10);
        WriteU32(m_file, entry.offset);
        WriteU32(m_file, entry.size);
    }

    const int64_t end = FileTell(m_file);
    if (end < 8 || end > UINT32_MAX || ferror(m_file)) {
        return false;
    }

    uint64_t bytes_per_second =
        (uint64_t)m_max_frame_size * (uint64_t)m_fps + kAudioBytesPerSecond;
    bytes_per_second = std::min<uint64_t>(bytes_per_second, UINT32_MAX);
    const uint32_t suggested = std::max(m_max_frame_size, m_max_audio_chunk_size);
    if (!PatchU32(m_file, m_avih_max_bytes_pos, (uint32_t)bytes_per_second) ||
        !PatchU32(m_file, m_avih_total_frames_pos, m_frames) ||
        !PatchU32(m_file, m_avih_suggested_buffer_pos, suggested) ||
        !PatchU32(m_file, m_strh_length_pos, m_frames) ||
        !PatchU32(m_file, m_strh_suggested_buffer_pos, m_max_frame_size) ||
        !PatchU32(m_file, m_audio_strh_length_pos,
                  (uint32_t)std::min<uint64_t>(m_audio_frames_written, UINT32_MAX)) ||
        !PatchU32(m_file, m_audio_strh_suggested_buffer_pos,
                  m_max_audio_chunk_size) ||
        !PatchU32(m_file, m_riff_size_pos, (uint32_t)(end - 8))) {
        return false;
    }
    if (!FileSeek(m_file, end)) {
        return false;
    }
    return fflush(m_file) == 0;
}

#ifdef _WIN32

bool VideoRecorder::BeginH264(int width, int height)
{
    if (width <= 0 || height <= 0 || (width & 1) || (height & 1)) {
        m_backend_error = "H.264 recording requires an even frame size.";
        return false;
    }

    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (SUCCEEDED(hr)) {
        m_com_initialized = true;
    } else if (hr != RPC_E_CHANGED_MODE) {
        m_backend_error = MfFailure("CoInitializeEx", hr);
        return false;
    }

    hr = MFStartup(MF_VERSION, MFSTARTUP_FULL);
    if (FAILED(hr)) {
        m_backend_error = MfFailure("MFStartup", hr);
        return false;
    }
    m_mf_started = true;

    gunichar2 *wide_path = g_utf8_to_utf16(m_output_path.c_str(), -1,
                                            nullptr, nullptr, nullptr);
    if (!wide_path) {
        m_backend_error = "Could not convert the video output path for Media Foundation.";
        return false;
    }

    IMFSinkWriter *writer = nullptr;
    hr = MFCreateSinkWriterFromURL((LPCWSTR)wide_path, nullptr, nullptr, &writer);
    g_free(wide_path);
    if (FAILED(hr)) {
        m_backend_error = MfFailure("MFCreateSinkWriterFromURL", hr);
        return false;
    }
    m_sink_writer = writer;

    IMFMediaType *video_out = nullptr;
    IMFMediaType *video_in = nullptr;
    IMFMediaType *audio_out = nullptr;
    IMFMediaType *audio_in = nullptr;

    hr = MFCreateMediaType(&video_out);
    if (SUCCEEDED(hr)) hr = video_out->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    if (SUCCEEDED(hr)) hr = video_out->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
    if (SUCCEEDED(hr)) hr = video_out->SetUINT32(
        MF_MT_AVG_BITRATE, H264BitrateForFormat(m_format, width, height, m_fps));
    if (SUCCEEDED(hr)) hr = video_out->SetUINT32(
        MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
    if (SUCCEEDED(hr)) hr = MFSetAttributeSize(video_out, MF_MT_FRAME_SIZE,
                                               (UINT32)width, (UINT32)height);
    if (SUCCEEDED(hr)) hr = MFSetAttributeRatio(video_out, MF_MT_FRAME_RATE,
                                                (UINT32)m_fps, 1);
    if (SUCCEEDED(hr)) hr = MFSetAttributeRatio(video_out,
                                                MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
    if (SUCCEEDED(hr)) {
        DWORD stream = 0;
        hr = writer->AddStream(video_out, &stream);
        if (SUCCEEDED(hr)) {
            m_video_stream = (uint32_t)stream;
        }
    }

    if (SUCCEEDED(hr)) hr = MFCreateMediaType(&video_in);
    if (SUCCEEDED(hr)) hr = video_in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    if (SUCCEEDED(hr)) hr = video_in->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
    if (SUCCEEDED(hr)) hr = video_in->SetUINT32(
        MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
    if (SUCCEEDED(hr)) hr = MFSetAttributeSize(video_in, MF_MT_FRAME_SIZE,
                                               (UINT32)width, (UINT32)height);
    if (SUCCEEDED(hr)) hr = MFSetAttributeRatio(video_in, MF_MT_FRAME_RATE,
                                                (UINT32)m_fps, 1);
    if (SUCCEEDED(hr)) hr = MFSetAttributeRatio(video_in,
                                                MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
    if (SUCCEEDED(hr)) hr = writer->SetInputMediaType(m_video_stream, video_in,
                                                      nullptr);

    if (SUCCEEDED(hr)) hr = MFCreateMediaType(&audio_out);
    if (SUCCEEDED(hr)) hr = audio_out->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio);
    if (SUCCEEDED(hr)) hr = audio_out->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_AAC);
    if (SUCCEEDED(hr)) hr = audio_out->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,
                                                 kAudioChannels);
    if (SUCCEEDED(hr)) hr = audio_out->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,
                                                 kAudioRate);
    if (SUCCEEDED(hr)) hr = audio_out->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,
                                                 kAudioBits);
    if (SUCCEEDED(hr)) hr = audio_out->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,
                                                 24000);
    if (SUCCEEDED(hr)) hr = audio_out->SetUINT32(MF_MT_AUDIO_BLOCK_ALIGNMENT, 1);
    if (SUCCEEDED(hr)) {
        DWORD stream = 0;
        hr = writer->AddStream(audio_out, &stream);
        if (SUCCEEDED(hr)) {
            m_audio_stream = (uint32_t)stream;
        }
    }

    if (SUCCEEDED(hr)) hr = MFCreateMediaType(&audio_in);
    if (SUCCEEDED(hr)) hr = audio_in->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio);
    if (SUCCEEDED(hr)) hr = audio_in->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_PCM);
    if (SUCCEEDED(hr)) hr = audio_in->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,
                                                kAudioChannels);
    if (SUCCEEDED(hr)) hr = audio_in->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,
                                                kAudioRate);
    if (SUCCEEDED(hr)) hr = audio_in->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,
                                                kAudioBits);
    if (SUCCEEDED(hr)) hr = audio_in->SetUINT32(MF_MT_AUDIO_BLOCK_ALIGNMENT,
                                                kAudioBlockAlign);
    if (SUCCEEDED(hr)) hr = audio_in->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,
                                                kAudioBytesPerSecond);
    if (SUCCEEDED(hr)) hr = writer->SetInputMediaType(m_audio_stream, audio_in,
                                                      nullptr);

    if (SUCCEEDED(hr)) hr = writer->BeginWriting();

    SafeRelease(video_out);
    SafeRelease(video_in);
    SafeRelease(audio_out);
    SafeRelease(audio_in);

    if (FAILED(hr)) {
        m_backend_error = MfFailure("Media Foundation recorder setup", hr);
        return false;
    }

    m_width = width;
    m_height = height;
    m_header_written = true;
    return true;
}

bool VideoRecorder::WriteH264Frame(const std::vector<uint8_t> &rgb)
{
    IMFSinkWriter *writer = (IMFSinkWriter *)m_sink_writer;
    if (!writer || rgb.size() != (size_t)m_width * m_height * 3) {
        return false;
    }

    std::vector<uint8_t> nv12;
    RgbToNv12(rgb, m_width, m_height, nv12);

    IMFMediaBuffer *buffer = nullptr;
    IMFSample *sample = nullptr;
    HRESULT hr = MFCreateMemoryBuffer((DWORD)nv12.size(), &buffer);
    BYTE *data = nullptr;
    DWORD max_length = 0;
    DWORD current_length = 0;
    if (SUCCEEDED(hr)) hr = buffer->Lock(&data, &max_length, &current_length);
    if (SUCCEEDED(hr)) {
        memcpy(data, nv12.data(), nv12.size());
        hr = buffer->Unlock();
        data = nullptr;
    }
    if (SUCCEEDED(hr)) hr = buffer->SetCurrentLength((DWORD)nv12.size());
    if (SUCCEEDED(hr)) hr = MFCreateSample(&sample);
    if (SUCCEEDED(hr)) hr = sample->AddBuffer(buffer);

    const LONGLONG duration = 10000000LL / m_fps;
    const LONGLONG timestamp = (LONGLONG)m_frames * duration;
    if (SUCCEEDED(hr)) hr = sample->SetSampleTime(timestamp);
    if (SUCCEEDED(hr)) hr = sample->SetSampleDuration(duration);
    if (SUCCEEDED(hr)) hr = writer->WriteSample(m_video_stream, sample);

    if (data) {
        buffer->Unlock();
    }
    SafeRelease(sample);
    SafeRelease(buffer);

    if (FAILED(hr)) {
        m_backend_error = MfFailure("H.264 video frame write", hr);
        return false;
    }
    ++m_frames;
    return true;
}

bool VideoRecorder::WriteH264Audio(const int16_t *samples, size_t frames)
{
    IMFSinkWriter *writer = (IMFSinkWriter *)m_sink_writer;
    if (!writer || !samples || frames == 0) {
        return false;
    }
    const size_t bytes = frames * kAudioBlockAlign;
    if (bytes > (size_t)std::numeric_limits<DWORD>::max()) {
        return false;
    }

    IMFMediaBuffer *buffer = nullptr;
    IMFSample *sample = nullptr;
    HRESULT hr = MFCreateMemoryBuffer((DWORD)bytes, &buffer);
    BYTE *data = nullptr;
    DWORD max_length = 0;
    DWORD current_length = 0;
    if (SUCCEEDED(hr)) hr = buffer->Lock(&data, &max_length, &current_length);
    if (SUCCEEDED(hr)) {
        memcpy(data, samples, bytes);
        hr = buffer->Unlock();
        data = nullptr;
    }
    if (SUCCEEDED(hr)) hr = buffer->SetCurrentLength((DWORD)bytes);
    if (SUCCEEDED(hr)) hr = MFCreateSample(&sample);
    if (SUCCEEDED(hr)) hr = sample->AddBuffer(buffer);

    const LONGLONG timestamp =
        (LONGLONG)(m_audio_frames_written * 10000000ULL / kAudioRate);
    const LONGLONG duration =
        (LONGLONG)(frames * 10000000ULL / kAudioRate);
    if (SUCCEEDED(hr)) hr = sample->SetSampleTime(timestamp);
    if (SUCCEEDED(hr)) hr = sample->SetSampleDuration(duration);
    if (SUCCEEDED(hr)) hr = writer->WriteSample(m_audio_stream, sample);

    if (data) {
        buffer->Unlock();
    }
    SafeRelease(sample);
    SafeRelease(buffer);

    if (FAILED(hr)) {
        m_backend_error = MfFailure("H.264 audio write", hr);
        return false;
    }
    m_audio_frames_written += frames;
    return true;
}

bool VideoRecorder::FinalizeH264()
{
    IMFSinkWriter *writer = (IMFSinkWriter *)m_sink_writer;
    if (!writer) {
        return false;
    }
    HRESULT hr = writer->Finalize();
    if (FAILED(hr)) {
        m_backend_error = MfFailure("Media Foundation finalize", hr);
        return false;
    }
    return true;
}

void VideoRecorder::ReleaseH264()
{
    IMFSinkWriter *writer = (IMFSinkWriter *)m_sink_writer;
    SafeRelease(writer);
    m_sink_writer = nullptr;
    if (m_mf_started) {
        MFShutdown();
        m_mf_started = false;
    }
    if (m_com_initialized) {
        CoUninitialize();
        m_com_initialized = false;
    }
}

#else

bool VideoRecorder::BeginH264(int width, int height)
{
    if (width <= 0 || height <= 0 || (width & 1) || (height & 1)) {
        m_backend_error = "H.264 recording requires an even frame size.";
        return false;
    }
#if defined(__linux__) || defined(__APPLE__)
    char error[512] = {};
    m_h264_backend = xemu_platform_video_recorder_create(
        m_output_path.c_str(), width, height, m_fps,
        H264BitrateForFormat(m_format, width, height, m_fps),
        error, sizeof(error));
    if (!m_h264_backend) {
        m_backend_error = error[0] ? error : "Could not initialize the platform H.264 recorder.";
        return false;
    }
    m_width = width;
    m_height = height;
    m_header_written = true;
    return true;
#else
    m_backend_error = "H.264 recording is not available on this platform.";
    return false;
#endif
}

bool VideoRecorder::WriteH264Frame(const std::vector<uint8_t> &rgb)
{
#if defined(__linux__) || defined(__APPLE__)
    if (!m_h264_backend || rgb.size() != (size_t)m_width * m_height * 3) {
        return false;
    }
    char error[512] = {};
    if (!xemu_platform_video_recorder_write_video(
            m_h264_backend, rgb.data(), rgb.size(), m_frames,
            error, sizeof(error))) {
        m_backend_error = error[0] ? error : "Platform H.264 video frame write failed.";
        return false;
    }
    ++m_frames;
    return true;
#else
    (void)rgb;
    return false;
#endif
}

bool VideoRecorder::WriteH264Audio(const int16_t *samples, size_t frames)
{
#if defined(__linux__) || defined(__APPLE__)
    if (!m_h264_backend || !samples || frames == 0) {
        return false;
    }
    char error[512] = {};
    if (!xemu_platform_video_recorder_write_audio(
            m_h264_backend, samples, frames, m_audio_frames_written,
            error, sizeof(error))) {
        m_backend_error = error[0] ? error : "Platform AAC audio write failed.";
        return false;
    }
    m_audio_frames_written += frames;
    return true;
#else
    (void)samples;
    (void)frames;
    return false;
#endif
}

bool VideoRecorder::FinalizeH264()
{
#if defined(__linux__) || defined(__APPLE__)
    if (!m_h264_backend) {
        return false;
    }
    char error[512] = {};
    if (!xemu_platform_video_recorder_finish(m_h264_backend, error, sizeof(error))) {
        m_backend_error = error[0] ? error : "Platform H.264 recorder finalize failed.";
        return false;
    }
    return true;
#else
    return false;
#endif
}

void VideoRecorder::ReleaseH264()
{
#if defined(__linux__) || defined(__APPLE__)
    if (m_h264_backend) {
        xemu_platform_video_recorder_destroy(m_h264_backend);
        m_h264_backend = nullptr;
    }
#endif
}

#endif

bool VideoRecorder::HasH264Backend() const
{
#ifdef _WIN32
    return m_sink_writer != nullptr;
#else
    return m_h264_backend != nullptr;
#endif
}

void VideoRecorder::PutPixel(std::vector<uint8_t> &rgb, int width, int height,
                             int x, int y, uint8_t r, uint8_t g, uint8_t b)
{
    if (x < 0 || y < 0 || x >= width || y >= height) {
        return;
    }
    const size_t offset = ((size_t)y * (size_t)width + (size_t)x) * 3;
    rgb[offset + 0] = r;
    rgb[offset + 1] = g;
    rgb[offset + 2] = b;
}

void VideoRecorder::DrawBitmapText(std::vector<uint8_t> &rgb, int width,
                                   int height, int x, int y,
                                   int cell_width, int cell_height,
                                   const std::string &text,
                                   uint8_t r, uint8_t g, uint8_t b)
{
    cell_width = std::max(1, cell_width);
    cell_height = std::max(1, cell_height);
    int cursor_x = x;
    for (unsigned char ch : SanitizeAscii(text)) {
        if (ch == '\n') {
            cursor_x = x;
            y += cell_height + 1;
            continue;
        }
        const uint8_t *glyph = &vgafont16[(size_t)ch * 16];
        for (int py = 0; py < cell_height; ++py) {
            const int gy0 = std::min(15, py * 16 / cell_height);
            const int gy1 = std::min(
                16, std::max(gy0 + 1,
                             ((py + 1) * 16 + cell_height - 1) / cell_height));
            for (int px = 0; px < cell_width; ++px) {
                const int gx0 = std::min(7, px * 8 / cell_width);
                const int gx1 = std::min(
                    8, std::max(gx0 + 1,
                                ((px + 1) * 8 + cell_width - 1) / cell_width));
                bool covered = false;
                for (int gy = gy0; gy < gy1 && !covered; ++gy) {
                    const uint8_t bits = glyph[gy];
                    for (int gx = gx0; gx < gx1; ++gx) {
                        if (bits & (0x80u >> gx)) {
                            covered = true;
                            break;
                        }
                    }
                }
                if (covered) {
                    PutPixel(rgb, width, height, cursor_x + px, y + py,
                             r, g, b);
                }
            }
        }
        cursor_x += cell_width;
    }
}

void VideoRecorder::ComposeFrame(const std::vector<uint8_t> &game_rgb,
                                 int game_width, int game_height,
                                 std::vector<uint8_t> &frame_rgb,
                                 int &frame_width, int &frame_height)
{
    if (!m_show_codes) {
        frame_width = game_width;
        frame_height = game_height;
        frame_rgb = game_rgb;
        return;
    }

    const int font_scale = std::max(1, game_height / 720);
    const int side_width = 260 * font_scale;
    frame_width = game_width + side_width;
    frame_height = game_height;
    frame_rgb.assign((size_t)frame_width * (size_t)frame_height * 3, 24);

    int game_x = 0;
    int panel_x = game_width;
    if (m_panel_position == 1) { // Left
        game_x = side_width;
        panel_x = 0;
    }

    for (int y = 0; y < game_height; ++y) {
        const uint8_t *src = game_rgb.data() + (size_t)y * game_width * 3;
        uint8_t *dst = frame_rgb.data() +
                       ((size_t)y * frame_width + game_x) * 3;
        memcpy(dst, src, (size_t)game_width * 3);
    }

    std::vector<std::string> names;
    std::vector<std::string> credits;
    std::vector<std::string> groups;
    debug_tools_get_active_cheat_details(names, credits, groups);

    const int margin = 10 * font_scale;
    const int code_gap = 3 * font_scale;
    const int group_gap = 2 * font_scale;
    const int line_gap = std::max(1, font_scale);
    const int child_indent = 10 * font_scale;
    const int credit_indent = 18 * font_scale;
    const int panel_width = side_width;
    const int panel_height = game_height;
    const int available_width = std::max(8, panel_width - margin * 2);
    const int bottom = panel_height - margin;
    int text_x = panel_x + margin;
    int text_y = margin;

    struct LineLayout {
        std::vector<std::string> lines;
        int cell_width = 8;
        int cell_height = 16;

        int PixelHeight(int gap) const
        {
            if (lines.empty()) {
                return 0;
            }
            return (int)lines.size() * cell_height +
                   ((int)lines.size() - 1) * gap;
        }
    };

    auto wrap_line = [](const std::string &text, int max_chars) {
        std::vector<std::string> lines;
        if (text.empty()) {
            lines.push_back("");
            return lines;
        }
        size_t pos = 0;
        while (pos < text.size()) {
            const size_t remaining = text.size() - pos;
            if ((int)remaining <= max_chars) {
                lines.push_back(text.substr(pos));
                break;
            }

            size_t take = (size_t)max_chars;
            const size_t limit = pos + take;
            const size_t split = text.rfind(' ', limit);
            if (split != std::string::npos && split > pos) {
                take = split - pos;
            }
            std::string line = text.substr(pos, take);
            while (!line.empty() && line.back() == ' ') {
                line.pop_back();
            }
            lines.push_back(std::move(line));
            pos += take;
            while (pos < text.size() && text[pos] == ' ') {
                ++pos;
            }
        }
        return lines;
    };

    auto fit_line = [&](const std::string &raw, int indent) {
        LineLayout line;
        const std::string text = SanitizeAscii(raw);
        const int width = std::max(1, available_width - indent);
        const int max_cell_width = 8 * font_scale;
        const int min_cell_width = 6 * font_scale;
        const int count = std::max(1, (int)text.size());
        line.cell_width = std::clamp(width / count,
                                     min_cell_width, max_cell_width);
        line.cell_height = line.cell_width * 2;

        const int max_chars = std::max(1, width / line.cell_width);
        line.lines = wrap_line(text, max_chars);
        return line;
    };

    auto draw_line = [&](const LineLayout &line, int indent,
                         uint8_t r, uint8_t g, uint8_t b) {
        for (const std::string &part : line.lines) {
            DrawBitmapText(frame_rgb, frame_width, frame_height,
                           text_x + indent, text_y,
                           line.cell_width, line.cell_height,
                           part, r, g, b);
            text_y += line.cell_height + line_gap;
        }
    };

    auto group_display_name = [](std::string group) {
        size_t pos = 0;
        while ((pos = group.find('/', pos)) != std::string::npos) {
            group.replace(pos, 1, " / ");
            pos += 3;
        }
        return group;
    };

    const LineLayout header = fit_line("ACTIVE CODES", 0);
    draw_line(header, 0, 116, 214, 100);
    text_y += code_gap;

    if (names.empty()) {
        const LineLayout none = fit_line("No active codes", 0);
        draw_line(none, 0, 220, 220, 220);
        return;
    }

    size_t visible = 0;
    std::string last_group;
    for (size_t i = 0; i < names.size(); ++i) {
        const std::string group = i < groups.size() ? groups[i] : "";
        const bool has_group = !group.empty();
        const bool new_group = has_group && group != last_group;
        const bool has_credit = i < credits.size() && !credits[i].empty();
        const int code_indent = has_group ? child_indent : 0;
        const int credit_line_indent = has_group ? credit_indent : child_indent;

        LineLayout group_line;
        if (new_group) {
            group_line = fit_line(group_display_name(group), 0);
        }
        const LineLayout code_line = fit_line(names[i], code_indent);
        LineLayout credit_line;
        if (has_credit) {
            credit_line = fit_line("Credits: " + credits[i], credit_line_indent);
        }

        int needed = code_line.PixelHeight(line_gap) + line_gap + code_gap;
        if (new_group) {
            needed += group_line.PixelHeight(line_gap) + line_gap + group_gap;
        }
        if (has_credit) {
            needed += credit_line.PixelHeight(line_gap) + line_gap;
        }
        if (text_y + needed > bottom) {
            break;
        }

        if (new_group) {
            draw_line(group_line, 0, 115, 190, 255);
            text_y += group_gap;
        }
        draw_line(code_line, code_indent, 235, 235, 235);
        if (has_credit) {
            draw_line(credit_line, credit_line_indent, 116, 214, 100);
        }
        text_y += code_gap;
        last_group = group;
        ++visible;
    }

    if (visible < names.size()) {
        const std::string more_text =
            "+" + std::to_string(names.size() - visible) + " more";
        const LineLayout more = fit_line(more_text, 0);
        const int more_y = panel_height - margin - more.PixelHeight(line_gap);
        int saved_y = text_y;
        text_y = more_y;
        draw_line(more, 0, 180, 180, 180);
        text_y = saved_y;
    }
}

void VideoRecorder::PadFrameEven(std::vector<uint8_t> &rgb, int &width,
                                 int &height)
{
    const int padded_width = (width + 1) & ~1;
    const int padded_height = (height + 1) & ~1;
    if (padded_width == width && padded_height == height) {
        return;
    }

    std::vector<uint8_t> padded((size_t)padded_width * padded_height * 3, 0);
    for (int y = 0; y < height; ++y) {
        memcpy(padded.data() + (size_t)y * padded_width * 3,
               rgb.data() + (size_t)y * width * 3,
               (size_t)width * 3);
    }
    rgb.swap(padded);
    width = padded_width;
    height = padded_height;
}

void VideoRecorder::Capture(unsigned int tex, bool flip)
{
    if (!m_recording.load()) {
        return;
    }

    const uint64_t now = HostNowNs();
    if (m_next_frame_ns != 0 && now < m_next_frame_ns) {
        return;
    }

    uint64_t repeat = 1;
    if (m_next_frame_ns != 0 && now > m_next_frame_ns) {
        repeat += (now - m_next_frame_ns) / m_frame_interval_ns;
    }
    m_next_frame_ns = (m_next_frame_ns == 0 ? now : m_next_frame_ns) +
                      repeat * m_frame_interval_ns;

    std::vector<uint8_t> game_rgb;
    int game_width = 0;
    int game_height = 0;
    if (!RenderFramebufferToRgb(tex, flip, game_rgb, game_width, game_height)) {
        Abort("Video recording stopped because the gameplay framebuffer could not be captured.");
        return;
    }

    std::vector<uint8_t> frame_rgb;
    int frame_width = 0;
    int frame_height = 0;
    ComposeFrame(game_rgb, game_width, game_height,
                 frame_rgb, frame_width, frame_height);

    if (m_h264) {
        PadFrameEven(frame_rgb, frame_width, frame_height);
        if (!m_header_written && !BeginH264(frame_width, frame_height)) {
            const std::string error = m_backend_error.empty()
                ? "Video recording stopped because the H.264 encoder could not be started."
                : m_backend_error;
            Abort(error.c_str());
            return;
        }
    } else if (!m_header_written && !BeginAvi(frame_width, frame_height)) {
        Abort("Video recording stopped because the AVI header could not be created.");
        return;
    }

    if (frame_width != m_width || frame_height != m_height) {
        Abort("Video recording stopped because the recording frame size changed.");
        return;
    }

    bool ok = true;
    if (m_h264) {
        for (uint64_t i = 0; i < repeat && ok; ++i) {
            ok = WriteH264Frame(frame_rgb);
        }
    } else {
        std::vector<uint8_t> png;
        if (!fpng::fpng_encode_image_to_memory(frame_rgb.data(), frame_width,
                                                frame_height, 3, png)) {
            Abort("Video recording stopped because a frame could not be encoded.");
            return;
        }
        for (uint64_t i = 0; i < repeat && ok; ++i) {
            ok = WriteFrame(png);
        }
    }

    if (!ok) {
        const std::string error = m_backend_error.empty()
            ? "Video recording stopped because a frame could not be written."
            : m_backend_error;
        Abort(error.c_str());
        return;
    }

    DrainPendingAudio();
    if (!m_backend_error.empty()) {
        const std::string error = m_backend_error;
        Abort(error.c_str());
    }
}

extern "C" void xemu_video_recorder_toggle(void)
{
    g_video_recorder.Toggle();
}

extern "C" void xemu_video_recorder_capture(unsigned int tex, int flip)
{
    g_video_recorder.Capture(tex, flip != 0);
}

extern "C" void xemu_video_recorder_submit_audio(const int16_t *samples,
                                                   size_t frames, float gain)
{
    g_video_recorder.SubmitAudio(samples, frames, gain);
}
