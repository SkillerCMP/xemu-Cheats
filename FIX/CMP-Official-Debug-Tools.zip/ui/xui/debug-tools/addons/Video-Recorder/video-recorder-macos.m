//
// macOS H.264/AAC recorder backend (AVFoundation / VideoToolbox)
//

#include "video-recorder-platform.h"

#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct XemuMacRecorder {
    AVAssetWriter *writer;
    AVAssetWriterInput *video_input;
    AVAssetWriterInputPixelBufferAdaptor *video_adaptor;
    AVAssetWriterInput *audio_input;
    CMAudioFormatDescriptionRef audio_format;
    int width;
    int height;
    int fps;
} XemuMacRecorder;

static void SetError(char *error, size_t error_size, NSString *text)
{
    if (!error || error_size == 0) {
        return;
    }
    const char *utf8 = text ? [text UTF8String] : "Unknown macOS recorder error.";
    snprintf(error, error_size, "%s", utf8 ? utf8 : "Unknown macOS recorder error.");
}

static void SetWriterError(XemuMacRecorder *r, char *error, size_t error_size,
                           NSString *prefix)
{
    NSString *detail = r && r->writer.error
        ? r->writer.error.localizedDescription
        : @"Unknown AVFoundation error.";
    SetError(error, error_size,
             [NSString stringWithFormat:@"%@: %@", prefix, detail]);
}

static BOOL WaitUntilReady(AVAssetWriterInput *input)
{
    for (int i = 0; i < 2000; ++i) {
        if (input.readyForMoreMediaData) {
            return YES;
        }
        usleep(1000);
    }
    return input.readyForMoreMediaData;
}

void *xemu_platform_video_recorder_create(const char *path, int width, int height,
                                          int fps, uint32_t video_bitrate,
                                          char *error, size_t error_size)
{
    @autoreleasepool {
        if (!path || !path[0] || width <= 0 || height <= 0 || fps <= 0) {
            SetError(error, error_size, @"Invalid macOS H.264 recorder parameters.");
            return NULL;
        }

        XemuMacRecorder *r = calloc(1, sizeof(*r));
        if (!r) {
            SetError(error, error_size, @"Could not allocate the macOS recorder.");
            return NULL;
        }
        r->width = width;
        r->height = height;
        r->fps = fps;

        NSString *path_string = [NSString stringWithUTF8String:path];
        if (!path_string) {
            SetError(error, error_size, @"Could not convert the video output path.");
            free(r);
            return NULL;
        }
        NSURL *url = [NSURL fileURLWithPath:path_string];
        NSError *writer_error = nil;
        r->writer = [[AVAssetWriter alloc] initWithURL:url
                                              fileType:AVFileTypeMPEG4
                                                 error:&writer_error];
        if (!r->writer) {
            SetError(error, error_size,
                     writer_error ? writer_error.localizedDescription
                                  : @"Could not create the MP4 writer.");
            free(r);
            return NULL;
        }

        NSDictionary *compression = @{
            AVVideoAverageBitRateKey: @(video_bitrate),
            AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
            AVVideoExpectedSourceFrameRateKey: @(fps),
        };
        NSDictionary *video_settings = @{
            AVVideoCodecKey: AVVideoCodecTypeH264,
            AVVideoWidthKey: @(width),
            AVVideoHeightKey: @(height),
            AVVideoCompressionPropertiesKey: compression,
        };
        r->video_input = [[AVAssetWriterInput alloc]
            initWithMediaType:AVMediaTypeVideo outputSettings:video_settings];
        r->video_input.expectsMediaDataInRealTime = YES;

        NSDictionary *pixel_attributes = @{
            (id)kCVPixelBufferPixelFormatTypeKey: @(kCVPixelFormatType_32BGRA),
            (id)kCVPixelBufferWidthKey: @(width),
            (id)kCVPixelBufferHeightKey: @(height),
        };
        r->video_adaptor = [[AVAssetWriterInputPixelBufferAdaptor alloc]
            initWithAssetWriterInput:r->video_input
            sourcePixelBufferAttributes:pixel_attributes];

        AudioChannelLayout layout = {0};
        layout.mChannelLayoutTag = kAudioChannelLayoutTag_Stereo;
        NSData *layout_data = [NSData dataWithBytes:&layout length:sizeof(layout)];
        NSDictionary *audio_settings = @{
            AVFormatIDKey: @(kAudioFormatMPEG4AAC),
            AVSampleRateKey: @48000,
            AVNumberOfChannelsKey: @2,
            AVEncoderBitRateKey: @192000,
            AVChannelLayoutKey: layout_data,
        };
        r->audio_input = [[AVAssetWriterInput alloc]
            initWithMediaType:AVMediaTypeAudio outputSettings:audio_settings];
        r->audio_input.expectsMediaDataInRealTime = YES;

        if (![r->writer canAddInput:r->video_input] ||
            ![r->writer canAddInput:r->audio_input]) {
            SetError(error, error_size,
                     @"AVFoundation rejected the H.264/AAC recorder streams.");
            xemu_platform_video_recorder_destroy(r);
            return NULL;
        }
        [r->writer addInput:r->video_input];
        [r->writer addInput:r->audio_input];

        AudioStreamBasicDescription asbd = {0};
        asbd.mSampleRate = 48000.0;
        asbd.mFormatID = kAudioFormatLinearPCM;
        asbd.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger |
                            kLinearPCMFormatFlagIsPacked;
        asbd.mBytesPerPacket = 4;
        asbd.mFramesPerPacket = 1;
        asbd.mBytesPerFrame = 4;
        asbd.mChannelsPerFrame = 2;
        asbd.mBitsPerChannel = 16;
        OSStatus status = CMAudioFormatDescriptionCreate(
            kCFAllocatorDefault, &asbd, sizeof(layout), &layout, 0, NULL, NULL,
            &r->audio_format);
        if (status != noErr) {
            SetError(error, error_size,
                     @"Could not create the macOS PCM audio description.");
            xemu_platform_video_recorder_destroy(r);
            return NULL;
        }

        if (![r->writer startWriting]) {
            SetWriterError(r, error, error_size, @"AVAssetWriter startWriting");
            xemu_platform_video_recorder_destroy(r);
            return NULL;
        }
        [r->writer startSessionAtSourceTime:kCMTimeZero];
        return r;
    }
}

bool xemu_platform_video_recorder_write_video(void *handle, const uint8_t *rgb,
                                               size_t rgb_size,
                                               uint64_t frame_index,
                                               char *error, size_t error_size)
{
    @autoreleasepool {
        XemuMacRecorder *r = (XemuMacRecorder *)handle;
        if (!r || !rgb || rgb_size != (size_t)r->width * r->height * 3) {
            SetError(error, error_size, @"Invalid macOS H.264 video frame.");
            return false;
        }
        if (!WaitUntilReady(r->video_input)) {
            SetWriterError(r, error, error_size, @"AVFoundation video input");
            return false;
        }

        CVPixelBufferRef pixel = NULL;
        CVReturn cvret = CVPixelBufferPoolCreatePixelBuffer(
            kCFAllocatorDefault, r->video_adaptor.pixelBufferPool, &pixel);
        if (cvret != kCVReturnSuccess || !pixel) {
            SetError(error, error_size, @"Could not allocate a macOS video pixel buffer.");
            return false;
        }
        CVPixelBufferLockBaseAddress(pixel, 0);
        uint8_t *dst = CVPixelBufferGetBaseAddress(pixel);
        const size_t stride = CVPixelBufferGetBytesPerRow(pixel);
        for (int y = 0; y < r->height; ++y) {
            uint8_t *row = dst + (size_t)y * stride;
            const uint8_t *src = rgb + (size_t)y * r->width * 3;
            for (int x = 0; x < r->width; ++x) {
                row[x * 4 + 0] = src[x * 3 + 2];
                row[x * 4 + 1] = src[x * 3 + 1];
                row[x * 4 + 2] = src[x * 3 + 0];
                row[x * 4 + 3] = 255;
            }
        }
        CVPixelBufferUnlockBaseAddress(pixel, 0);

        const CMTime pts = CMTimeMake((int64_t)frame_index, r->fps);
        const BOOL ok = [r->video_adaptor appendPixelBuffer:pixel
                                      withPresentationTime:pts];
        CVPixelBufferRelease(pixel);
        if (!ok) {
            SetWriterError(r, error, error_size, @"AVFoundation H.264 frame write");
            return false;
        }
        return true;
    }
}

bool xemu_platform_video_recorder_write_audio(void *handle,
                                               const int16_t *samples,
                                               size_t frames,
                                               uint64_t audio_frame_index,
                                               char *error, size_t error_size)
{
    @autoreleasepool {
        XemuMacRecorder *r = (XemuMacRecorder *)handle;
        if (!r || !samples || frames == 0) {
            SetError(error, error_size, @"Invalid macOS AAC audio block.");
            return false;
        }
        if (!WaitUntilReady(r->audio_input)) {
            SetWriterError(r, error, error_size, @"AVFoundation audio input");
            return false;
        }

        const size_t bytes = frames * 2 * sizeof(int16_t);
        CMBlockBufferRef block = NULL;
        OSStatus status = CMBlockBufferCreateWithMemoryBlock(
            kCFAllocatorDefault, NULL, bytes, kCFAllocatorDefault, NULL,
            0, bytes, 0, &block);
        if (status != kCMBlockBufferNoErr || !block) {
            SetError(error, error_size, @"Could not allocate a macOS audio block.");
            return false;
        }
        status = CMBlockBufferReplaceDataBytes(samples, block, 0, bytes);
        if (status != kCMBlockBufferNoErr) {
            CFRelease(block);
            SetError(error, error_size, @"Could not fill the macOS audio block.");
            return false;
        }

        CMSampleTimingInfo timing = {
            .duration = CMTimeMake(1, 48000),
            .presentationTimeStamp = CMTimeMake((int64_t)audio_frame_index, 48000),
            .decodeTimeStamp = kCMTimeInvalid,
        };
        CMSampleBufferRef sample = NULL;
        status = CMSampleBufferCreateReady(
            kCFAllocatorDefault, block, r->audio_format, (CMItemCount)frames,
            1, &timing, 0, NULL, &sample);
        CFRelease(block);
        if (status != noErr || !sample) {
            SetError(error, error_size, @"Could not create the macOS audio sample.");
            return false;
        }
        const BOOL ok = [r->audio_input appendSampleBuffer:sample];
        CFRelease(sample);
        if (!ok) {
            SetWriterError(r, error, error_size, @"AVFoundation AAC audio write");
            return false;
        }
        return true;
    }
}

bool xemu_platform_video_recorder_finish(void *handle,
                                         char *error, size_t error_size)
{
    @autoreleasepool {
        XemuMacRecorder *r = (XemuMacRecorder *)handle;
        if (!r || !r->writer) {
            SetError(error, error_size, @"The macOS H.264 recorder was not initialized.");
            return false;
        }
        [r->video_input markAsFinished];
        [r->audio_input markAsFinished];

        dispatch_semaphore_t done = dispatch_semaphore_create(0);
        [r->writer finishWritingWithCompletionHandler:^{
            dispatch_semaphore_signal(done);
        }];
        dispatch_semaphore_wait(done, DISPATCH_TIME_FOREVER);
#if !OS_OBJECT_USE_OBJC
        dispatch_release(done);
#endif
        if (r->writer.status != AVAssetWriterStatusCompleted) {
            SetWriterError(r, error, error_size, @"AVAssetWriter finishWriting");
            return false;
        }
        return true;
    }
}

void xemu_platform_video_recorder_destroy(void *handle)
{
    @autoreleasepool {
        XemuMacRecorder *r = (XemuMacRecorder *)handle;
        if (!r) {
            return;
        }
        if (r->audio_format) {
            CFRelease(r->audio_format);
        }
        [r->video_adaptor release];
        [r->video_input release];
        [r->audio_input release];
        [r->writer release];
        free(r);
    }
}
