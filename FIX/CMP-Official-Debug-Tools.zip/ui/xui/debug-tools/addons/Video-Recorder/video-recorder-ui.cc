#include "video-recorder-ui.hh"

#include "video-recorder.hh"
#include "../../debug-tools.hh"
#include "../../../common.hh"
#include "../../../widgets.hh"
#include "../../../../xemu-settings.h"

#include <algorithm>

extern struct config g_config;

void cmp_video_recorder_draw_settings()
{
    SectionTitle("Video Recording");
    FilePicker("Video output directory",
               g_config.general.video_recording.output_dir,
               nullptr, 0, true, [](const char *path) {
                   xemu_settings_set_string(
                       &g_config.general.video_recording.output_dir, path);
               });

    const bool recording = g_video_recorder.IsRecording();
    ImGui::BeginDisabled(recording);
    ChevronCombo("Format / Quality", &g_config.general.video_recording.format,
                 "H.264 - High Quality\0"
                 "H.264 - Standard\0"
                 "H.264 - Small File\0"
                 "Lossless AVI/PNG\0",
                 "Choose recording compression and quality");
    ChevronCombo("Frame Rate", &g_config.general.video_recording.fps,
                 "30 FPS\0"
                 "60 FPS\0",
                 "Recording frame rate");

    float recording_audio_percent = std::clamp(
        (float)g_config.general.video_recording.audio_gain * 100.0f,
        0.0f, 200.0f);
    ImGui::SetNextItemWidth(ImGui::GetColumnWidth() * 0.4f);
    if (ImGui::SliderFloat("Recording Audio Volume", &recording_audio_percent,
                           0.0f, 200.0f, "%.0f%%")) {
        g_config.general.video_recording.audio_gain =
            recording_audio_percent / 100.0f;
    }
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip(
            "Independent of playback volume. 100%% records the Xbox mix at unity gain.");
    }

    if (debug_tools_cheat_overlay_available()) {
        Toggle("Add Active Codes Panel",
               &g_config.general.video_recording.show_active_codes,
               "Show the names of active Cheat Engine codes beside the gameplay video");
        if (g_config.general.video_recording.show_active_codes) {
            if (g_config.general.video_recording.panel_position < 0 ||
                g_config.general.video_recording.panel_position > 1) {
                g_config.general.video_recording.panel_position = 0;
            }
            ChevronCombo("Code Panel Position",
                         &g_config.general.video_recording.panel_position,
                         "Right\0Left\0",
                         "Choose which side of the video shows the Active Codes panel");
        }
    }
    ImGui::EndDisabled();
    ImGui::TextDisabled(
        "Game audio included at independent recording volume. Shortcut: F9");

    if (recording) {
        if (ImGui::Button("Stop Recording", ImVec2(180, 0))) {
            g_video_recorder.Stop();
        }
        if (!g_video_recorder.OutputPath().empty()) {
            ImGui::SameLine();
            ImGui::TextDisabled("Recording: %s",
                                g_video_recorder.OutputPath().c_str());
        }
    } else if (ImGui::Button("Start Recording", ImVec2(180, 0))) {
        g_video_recorder.Start();
    }
}
