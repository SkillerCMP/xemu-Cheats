//
// xemu platform H.264/AAC recorder bridge
//
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void *xemu_platform_video_recorder_create(const char *path, int width, int height,
                                          int fps, uint32_t video_bitrate,
                                          char *error, size_t error_size);
bool xemu_platform_video_recorder_write_video(void *handle, const uint8_t *rgb,
                                               size_t rgb_size,
                                               uint64_t frame_index,
                                               char *error, size_t error_size);
bool xemu_platform_video_recorder_write_audio(void *handle,
                                               const int16_t *samples,
                                               size_t frames,
                                               uint64_t audio_frame_index,
                                               char *error, size_t error_size);
bool xemu_platform_video_recorder_finish(void *handle,
                                         char *error, size_t error_size);
void xemu_platform_video_recorder_destroy(void *handle);

#ifdef __cplusplus
}
#endif
