//
// xemu gameplay video recorder
//
#pragma once

#include <stdint.h>
#include <stdio.h>

#include <atomic>
#include <mutex>
#include <string>
#include <vector>

class VideoRecorder
{
public:
    VideoRecorder();
    ~VideoRecorder();

    bool Start();
    void Stop();
    void Toggle();
    void Capture(unsigned int tex, bool flip);
    void SubmitAudio(const int16_t *samples, size_t frames, float gain);

    bool IsRecording() const { return m_recording.load(); }
    const std::string &OutputPath() const { return m_output_path; }
    const std::string &Status() const { return m_status; }

private:
    struct IndexEntry {
        bool audio = false;
        uint32_t offset = 0;
        uint32_t size = 0;
    };

    bool BeginAvi(int width, int height);
    bool WriteFrame(const std::vector<uint8_t> &frame_data);
    bool WriteAudioPcm(const int16_t *samples, size_t frames);
    bool FinalizeAvi();

    bool BeginH264(int width, int height);
    bool WriteH264Frame(const std::vector<uint8_t> &rgb);
    bool WriteH264Audio(const int16_t *samples, size_t frames);
    bool FinalizeH264();
    void ReleaseH264();
    bool HasH264Backend() const;

    void Abort(const char *message);
    void ComposeFrame(const std::vector<uint8_t> &game_rgb, int game_width,
                      int game_height, std::vector<uint8_t> &frame_rgb,
                      int &frame_width, int &frame_height);
    void DrainPendingAudio();
    void PadFrameEven(std::vector<uint8_t> &rgb, int &width, int &height);

    static void PutPixel(std::vector<uint8_t> &rgb, int width, int height,
                         int x, int y, uint8_t r, uint8_t g, uint8_t b);
    static void DrawBitmapText(std::vector<uint8_t> &rgb, int width, int height,
                               int x, int y, int cell_width, int cell_height,
                               const std::string &text,
                               uint8_t r, uint8_t g, uint8_t b);

    FILE *m_file = nullptr;
    std::atomic<bool> m_recording{false};
    bool m_header_written = false;
    bool m_show_codes = false;
    bool m_h264 = false;
    int m_panel_position = 0;
    int m_format = 0;
    int m_fps = 30;
    int m_width = 0;
    int m_height = 0;
    uint64_t m_next_frame_ns = 0;
    uint64_t m_frame_interval_ns = 0;
    uint32_t m_frames = 0;
    uint32_t m_max_frame_size = 0;
    uint32_t m_max_audio_chunk_size = 0;
    uint64_t m_audio_frames_written = 0;
    int64_t m_riff_size_pos = 0;
    int64_t m_avih_max_bytes_pos = 0;
    int64_t m_avih_total_frames_pos = 0;
    int64_t m_avih_suggested_buffer_pos = 0;
    int64_t m_strh_length_pos = 0;
    int64_t m_strh_suggested_buffer_pos = 0;
    int64_t m_audio_strh_length_pos = 0;
    int64_t m_audio_strh_suggested_buffer_pos = 0;
    int64_t m_movi_list_start = 0;
    int64_t m_movi_size_pos = 0;
    std::vector<IndexEntry> m_index;
    std::mutex m_audio_mutex;
    std::vector<int16_t> m_audio_pending;
    std::string m_output_path;
    std::string m_status;
    std::string m_backend_error;

#ifdef _WIN32
    void *m_sink_writer = nullptr;
    uint32_t m_video_stream = 0;
    uint32_t m_audio_stream = 0;
    bool m_mf_started = false;
    bool m_com_initialized = false;
#else
    void *m_h264_backend = nullptr;
#endif
};

extern VideoRecorder g_video_recorder;
