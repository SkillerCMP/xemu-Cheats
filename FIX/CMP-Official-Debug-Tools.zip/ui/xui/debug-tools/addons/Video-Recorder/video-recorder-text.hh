// Cached, native-pixel, antialiased RGB text for recorded frames.
// Owns coverage bytes: no pointers into the UI atlas and no guest/GPU access.
#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace XemuRecorderText {
struct Glyph {
    int x = 0, y = 0, width = 0, height = 0;
    float advance = 0;
    std::vector<uint8_t> alpha;
};
using Glyphs = std::array<Glyph, 95>;
// Font provider lives separately; uses the already shipped Roboto Condensed.
bool LoadFont(int height, Glyphs &glyphs);
class Renderer {
public:
    bool EnsureFont(int height);
    float Measure(const std::string &text) const;
    std::vector<std::string> Wrap(const std::string &text, int width) const;
    void Draw(std::vector<uint8_t> &rgb, int width, int height,
              int x, int y, int clip_width, const std::string &text,
              uint8_t r, uint8_t g, uint8_t b) const;
private:
    int m_height = 0;
    Glyphs m_glyphs;
};
}
