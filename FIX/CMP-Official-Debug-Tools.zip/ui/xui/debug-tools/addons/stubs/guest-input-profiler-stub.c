/* No-op Guest Input Investigator hook for builds without Memory Tools. */
#include "../memory-tools/guest-input-profiler-hook.h"

int xemu_debug_tools_guest_input_profiler_active(void)
{
    return 0;
}

void xemu_debug_tools_guest_input_profiler_record(uint32_t guest_pc)
{
    (void)guest_pc;
}

void xemu_debug_tools_guest_input_profiler_start(uint32_t range_start,
                                                 uint32_t range_end)
{
    (void)range_start;
    (void)range_end;
}

void xemu_debug_tools_guest_input_profiler_stop(void)
{
}

void xemu_debug_tools_guest_input_profiler_reset(void)
{
}

size_t xemu_debug_tools_guest_input_profiler_copy(
    XemuDebugToolsGuestInputProfileEntry *entries, size_t capacity)
{
    (void)entries;
    (void)capacity;
    return 0;
}

size_t xemu_debug_tools_guest_input_profiler_unique_count(void)
{
    return 0;
}

uint64_t xemu_debug_tools_guest_input_profiler_total_hits(void)
{
    return 0;
}

uint64_t xemu_debug_tools_guest_input_profiler_dropped(void)
{
    return 0;
}
