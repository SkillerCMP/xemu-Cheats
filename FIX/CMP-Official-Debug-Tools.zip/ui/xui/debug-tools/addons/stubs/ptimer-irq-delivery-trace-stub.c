#include "../diagnostics/ptimer-irq-delivery-trace.h"

int xemu_debug_tools_ptimer_irq_delivery_trace_active(void) { return 0; }
void xemu_debug_tools_ptimer_irq_delivery_trace_set_enabled(int enabled) { (void)enabled; }
void xemu_debug_tools_ptimer_irq_delivery_trace_clear(void) {}
void xemu_debug_tools_ptimer_irq_delivery_note_set(uint32_t a,uint32_t b,uint32_t c,uint32_t d){(void)a;(void)b;(void)c;(void)d;}
void xemu_debug_tools_ptimer_irq_delivery_note_nv2a_line(int l,uint32_t a,uint32_t b,uint32_t c,uint32_t d){(void)l;(void)a;(void)b;(void)c;(void)d;}
void xemu_debug_tools_ptimer_irq_delivery_note_pci_route(int p,int i,int l){(void)p;(void)i;(void)l;}
void xemu_debug_tools_ptimer_irq_delivery_note_pic_cpu_line(CPUState *c,int l,uint32_t b,uint32_t a,int p){(void)c;(void)l;(void)b;(void)a;(void)p;}
void xemu_debug_tools_ptimer_irq_delivery_note_tcg_check(CPUState *c){(void)c;}
void xemu_debug_tools_ptimer_irq_delivery_note_tcg_take(CPUState *c,int s,int v){(void)c;(void)s;(void)v;}
void xemu_debug_tools_ptimer_irq_delivery_note_clear(uint32_t v,uint32_t a,uint32_t b,uint32_t d,uint32_t e){(void)v;(void)a;(void)b;(void)d;(void)e;}
void xemu_debug_tools_ptimer_irq_delivery_trace_get_status(XemuDebugToolsPtimerIrqDeliveryStatus *s){if(s){*s=(XemuDebugToolsPtimerIrqDeliveryStatus){0};s->slow_threshold_ns=XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SLOW_NS;s->overdue_threshold_ns=XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_OVERDUE_NS;s->sample_interval_ns=XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_NS;}}
int xemu_debug_tools_ptimer_irq_delivery_trace_snapshot(XemuDebugToolsPtimerIrqDeliverySnapshot *s){if(s){*s=(XemuDebugToolsPtimerIrqDeliverySnapshot){0};}return 0;}
