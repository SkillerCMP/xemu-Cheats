/* xemu Debug Tools - no-op MMIO dispatch trace for non-full profiles. */
#include "../diagnostics/mmio-trace-hook.h"

void xemu_debug_tools_mmio_trace_begin(XemuDebugToolsMmioTraceScope *scope,
                                       const void *memory_region,
                                       uint64_t region_offset,
                                       uint64_t guest_vaddr,
                                       uint64_t guest_paddr,
                                       uint32_t size,
                                       uint32_t access_type)
{
    (void)memory_region;
    (void)region_offset;
    (void)guest_vaddr;
    (void)guest_paddr;
    (void)size;
    (void)access_type;
    if (scope) {
        scope->active = 0;
    }
}

void xemu_debug_tools_mmio_trace_end(XemuDebugToolsMmioTraceScope *scope)
{
    (void)scope;
}
