/* xemu Debug Tools - disabled-profile FLIP_STALL/VBlank observation stubs. */
#include "../diagnostics/flip-stall-trace-hook.h"

void xemu_debug_tools_flip_stall_trace_record(
    unsigned int event_type, const void *pgraph_state,
    uint32_t method, uint32_t parameter, uint32_t value0, uint32_t value1,
    uint64_t duration_ns)
{
    (void)event_type; (void)pgraph_state; (void)method; (void)parameter;
    (void)value0; (void)value1; (void)duration_ns;
}

void xemu_debug_tools_flip_stall_trace_begin(const void *pgraph_state)
{
    (void)pgraph_state;
}

void xemu_debug_tools_flip_stall_trace_end(const void *pgraph_state)
{
    (void)pgraph_state;
}
