#include "ui/xui/debug-tools/addons/file-replace/file-replace-disc-overlay.h"

size_t xemu_file_replace_disc_overlay_apply(uintptr_t disc_identity,
                                            uint64_t disc_offset,
                                            void *buffer, size_t size)
{
    (void)disc_identity;
    (void)disc_offset;
    (void)buffer;
    (void)size;
    return 0;
}

int xemu_file_replace_plan_create(uintptr_t identity, uint64_t offset, size_t size,
                                  XemuFileReplaceReadPlan **out)
{
    (void)identity; (void)offset; (void)size;
    if (out) *out = NULL;
    return 0;
}
size_t xemu_file_replace_plan_count(const XemuFileReplaceReadPlan *p) { (void)p; return 0; }
const XemuFileReplaceReadPiece *xemu_file_replace_plan_piece(const XemuFileReplaceReadPlan *p, size_t i)
{ (void)p; (void)i; return NULL; }
void xemu_file_replace_plan_release(XemuFileReplaceReadPlan *p) { (void)p; }
void xemu_file_replace_plan_completed(const XemuFileReplaceReadPlan *p) { (void)p; }
uint64_t xemu_file_replace_disc_sectors(uintptr_t identity, uint64_t physical)
{ (void)identity; return physical; }
