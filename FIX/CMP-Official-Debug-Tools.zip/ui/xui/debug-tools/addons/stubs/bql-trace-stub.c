/* xemu Debug Tools - no-op BQL ownership trace for non-full profiles. */
#include "../diagnostics/bql-trace-hook.h"


void xemu_debug_tools_bql_trace_set_next_context(uint32_t context)
{
    (void)context;
}

void xemu_debug_tools_bql_trace_owner_stage_begin(uint32_t stage)
{
    (void)stage;
}

void xemu_debug_tools_bql_trace_owner_stage_end(void)
{
}

void xemu_debug_tools_bql_trace_lock_attempt(const char *file, int line)
{
    (void)file;
    (void)line;
}

void xemu_debug_tools_bql_trace_lock_acquired(const char *file, int line)
{
    (void)file;
    (void)line;
}

void xemu_debug_tools_bql_trace_unlock_begin(void)
{
}

void xemu_debug_tools_bql_trace_unlock_end(void)
{
}
