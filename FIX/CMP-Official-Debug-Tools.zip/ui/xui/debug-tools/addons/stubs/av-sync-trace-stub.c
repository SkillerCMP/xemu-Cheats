#include "../diagnostics/av-sync-trace-hook.h"

void xemu_debug_tools_av_sync_trace_note_audio_batch(const void *apu_state,
                                                      uint32_t samples)
{
    (void)apu_state;
    (void)samples;
}

void xemu_debug_tools_av_sync_trace_note_vblank(uint64_t interval_ns)
{
    (void)interval_ns;
}

void xemu_debug_tools_av_sync_trace_note_pgraph_flip(uint32_t frame_time)
{
    (void)frame_time;
}
