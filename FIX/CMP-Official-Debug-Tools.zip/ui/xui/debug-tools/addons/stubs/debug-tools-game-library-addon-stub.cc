#include "../../debug-tools-module.hh"

void debug_tools_register_game_library_addition()
{
}
