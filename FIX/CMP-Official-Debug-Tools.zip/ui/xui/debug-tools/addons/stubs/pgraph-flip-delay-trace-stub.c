/* Non-Diagnostics build stub for the Patch 300 PFIFO observation hook. */
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-flip-delay-trace-hook.h"

void xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(
    const void *pgraph_state, uint32_t method, uint32_t parameter)
{
    (void)pgraph_state;
    (void)method;
    (void)parameter;
}

void xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(
    const void *pgraph_state, uint32_t renderer_kind)
{
    (void)pgraph_state;
    (void)renderer_kind;
}

void xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel(void)
{
}

int xemu_debug_tools_pgraph_flip_delay_guest_pc_sampler_active(void)
{
    return 0;
}

void xemu_debug_tools_pgraph_flip_delay_note_guest_pc(uint32_t guest_pc)
{
    (void)guest_pc;
}
