/* CMP Folder-HDD disabled-profile bridge stub. */
#include "../Folder-HDD/folder-hdd.h"

#include <glib.h>

bool cmp_folder_hdd_is_configured(void)
{
    return false;
}

bool cmp_folder_hdd_is_active(void)
{
    return false;
}

char *cmp_folder_hdd_make_uri(const char *root_path)
{
    (void)root_path;
    return NULL;
}

char *cmp_folder_hdd_get_default_root(void)
{
    return NULL;
}

bool cmp_folder_hdd_ensure_layout(const char *root_path, char **error_text)
{
    (void)root_path;
    if (error_text) {
        *error_text = g_strdup("Folder-HDD support is not included in this build profile.");
    }
    return false;
}

bool cmp_folder_hdd_root_is_usable(const char *root_path, char **error_text)
{
    (void)root_path;
    if (error_text) {
        *error_text = g_strdup("Folder-HDD support is not included in this build profile.");
    }
    return false;
}

bool cmp_folder_hdd_rescan_active(char **status_text)
{
    if (status_text) {
        *status_text = g_strdup("Folder-HDD support is not included in this build profile.");
    }
    return false;
}
