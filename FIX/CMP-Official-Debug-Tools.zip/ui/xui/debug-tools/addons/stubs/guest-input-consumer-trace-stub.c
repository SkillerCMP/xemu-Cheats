#include "../diagnostics/guest-input-consumer-trace.h"

#include <string.h>

int xemu_debug_tools_guest_input_consumer_trace_active(void) { return 0; }
int xemu_debug_tools_guest_input_consumer_trace_capture_active(void) { return 0; }
void xemu_debug_tools_guest_input_consumer_trace_note_report(
    uint32_t guest_address0, uint32_t guest_length0,
    uint32_t guest_address1, uint32_t guest_length1,
    const uint8_t *report, uint32_t report_length)
{
    (void)guest_address0; (void)guest_length0; (void)guest_address1;
    (void)guest_length1; (void)report; (void)report_length;
}
void xemu_debug_tools_guest_input_consumer_trace_note_title_tb(uint32_t guest_pc)
{ (void)guest_pc; }
void xemu_debug_tools_guest_input_consumer_trace_set_enabled(int enabled)
{ (void)enabled; }
void xemu_debug_tools_guest_input_consumer_trace_clear(void) {}
int xemu_debug_tools_guest_input_consumer_trace_set_buffer_multiplier(
    uint32_t multiplier)
{ (void)multiplier; return 1; }
uint32_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_multiplier(void)
{ return 1; }
size_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_capacity(void)
{ return XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY; }
void xemu_debug_tools_guest_input_consumer_trace_get_status(
    XemuDebugToolsGuestInputConsumerTraceStatus *status)
{
    if (status) {
        memset(status, 0, sizeof(*status));
    }
}
size_t xemu_debug_tools_guest_input_consumer_trace_snapshot(
    XemuDebugToolsGuestInputConsumerTraceEvent *events, size_t capacity)
{ (void)events; (void)capacity; return 0; }
