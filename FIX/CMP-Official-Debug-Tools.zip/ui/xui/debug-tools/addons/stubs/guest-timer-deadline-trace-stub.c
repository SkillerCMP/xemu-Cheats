#include "../diagnostics/guest-timer-deadline-trace.h"

int xemu_debug_tools_guest_timer_deadline_trace_active(void) { return 0; }
int xemu_debug_tools_guest_timer_deadline_trace_should_single_step(uint32_t guest_pc)
{
    (void)guest_pc;
    return 0;
}
void xemu_debug_tools_guest_timer_deadline_trace_note_pc(CPUState *cpu,
                                                          uint32_t guest_pc)
{
    (void)cpu;
    (void)guest_pc;
}
void xemu_debug_tools_guest_timer_deadline_trace_set_enabled(int enabled)
{
    (void)enabled;
}
void xemu_debug_tools_guest_timer_deadline_trace_clear(void) {}
int xemu_debug_tools_guest_timer_deadline_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    (void)multiplier;
    return 0;
}
uint32_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_multiplier(void)
{
    return 1;
}
size_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_capacity(void)
{
    return XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY;
}
void xemu_debug_tools_guest_timer_deadline_trace_get_status(
    XemuDebugToolsGuestTimerDeadlineTraceStatus *status)
{
    if (status != NULL) {
        *status = (XemuDebugToolsGuestTimerDeadlineTraceStatus){ 0 };
    }
}
size_t xemu_debug_tools_guest_timer_deadline_trace_snapshot(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *events, size_t capacity)
{
    (void)events;
    (void)capacity;
    return 0;
}
