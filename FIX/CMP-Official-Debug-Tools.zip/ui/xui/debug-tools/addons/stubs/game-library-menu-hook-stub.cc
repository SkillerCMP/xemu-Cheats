#include "../game-library/game-library-menu-hook.h"

bool xemu_debug_tools_game_library_menu_available(void) { return false; }
void xemu_debug_tools_game_library_menu_prepare(void) {}
size_t xemu_debug_tools_game_library_menu_count(void) { return 0; }
bool xemu_debug_tools_game_library_menu_get_label(size_t index, char *label,
                                                   size_t label_size)
{
    (void)index;
    if (label && label_size) {
        label[0] = '\0';
    }
    return false;
}
bool xemu_debug_tools_game_library_menu_launch(size_t index)
{
    (void)index;
    return false;
}
bool xemu_debug_tools_game_library_menu_scanning(void) { return false; }
void xemu_debug_tools_game_library_menu_open_full(void) {}
void xemu_debug_tools_game_library_menu_refresh(void) {}
