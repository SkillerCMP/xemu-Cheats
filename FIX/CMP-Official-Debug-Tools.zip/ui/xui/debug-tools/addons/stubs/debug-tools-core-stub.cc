#include "debug-tools.hh"

void debug_tools_init(SDL_Window *, void *) {}
void debug_tools_precreate_detached_windows() {}
void debug_tools_cleanup() {}
bool debug_tools_process_sdl_event(SDL_Event *) { return false; }
bool debug_tools_owns_window_id(SDL_WindowID) { return false; }
bool debug_tools_queue_background_job(DebugToolsBackgroundJobCallback, void *,
                                      DebugToolsBackgroundJobCallback, bool)
{
    return false;
}
bool debug_tools_background_worker_is_running() { return false; }
unsigned int debug_tools_background_worker_pending_jobs() { return 0; }
bool debug_tools_external_input_lease_active() { return false; }
void debug_tools_tick() {}
void debug_tools_draw_menu_items() {}
void debug_tools_build_unlocked_detached_frames() {}
void debug_tools_render_detached_frames() {}
void debug_tools_process_deferred_actions() {}
void debug_tools_notify_game_reset() {}


bool debug_tools_cheat_overlay_available() { return false; }
void debug_tools_get_active_cheat_details(std::vector<std::string> &names,
                                          std::vector<std::string> &credits,
                                          std::vector<std::string> &groups)
{
    names.clear();
    credits.clear();
    groups.clear();
}
