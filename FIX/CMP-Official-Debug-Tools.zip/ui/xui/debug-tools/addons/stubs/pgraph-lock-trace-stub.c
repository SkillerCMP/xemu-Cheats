/* xemu Debug Tools - disabled-profile PGRAPH lock observation stubs. */
#include "../diagnostics/pgraph-lock-trace-hook.h"

void xemu_debug_tools_pgraph_lock_trace_lock_attempt(const void *pgraph_state,
                                                      const char *file,
                                                      int line)
{
    (void)pgraph_state;
    (void)file;
    (void)line;
}

void xemu_debug_tools_pgraph_lock_trace_lock_acquired(const void *pgraph_state,
                                                       const char *file,
                                                       int line)
{
    (void)pgraph_state;
    (void)file;
    (void)line;
}

void xemu_debug_tools_pgraph_lock_trace_unlock_begin(const void *pgraph_state,
                                                      const char *file,
                                                      int line)
{
    (void)pgraph_state;
    (void)file;
    (void)line;
}

void xemu_debug_tools_pgraph_lock_trace_unlock_end(const void *pgraph_state)
{
    (void)pgraph_state;
}

void xemu_debug_tools_pgraph_lock_trace_method_enter(unsigned int subchannel,
                                                      unsigned int graphics_class,
                                                      unsigned int method,
                                                      uint32_t parameter)
{
    (void)subchannel;
    (void)graphics_class;
    (void)method;
    (void)parameter;
}

void xemu_debug_tools_pgraph_lock_trace_method_exit(void)
{
}
