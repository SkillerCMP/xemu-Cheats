/* No-op exact execution trace hook for builds without Memory Tools. */
#include "qemu/osdep.h"
#include "../memory-tools/exact-execution-trace.h"

int xemu_memory_tools_exact_trace_start(uint32_t initial_eip,
                                        uint32_t range_start,
                                        uint32_t range_end,
                                        uint64_t max_bytes,
                                        int stop_address_enabled,
                                        uint32_t stop_address)
{
    (void)initial_eip;
    (void)range_start;
    (void)range_end;
    (void)max_bytes;
    (void)stop_address_enabled;
    (void)stop_address;
    return 0;
}

void xemu_memory_tools_exact_trace_stop(void)
{
}

void xemu_memory_tools_exact_trace_get_status(XemuDbgTraceStatus *status)
{
    if (status != NULL) {
        memset(status, 0, sizeof(*status));
    }
}

uint64_t xemu_memory_tools_exact_trace_copy(uint64_t start_index,
                                            uint32_t *entries,
                                            uint64_t entry_capacity)
{
    (void)start_index;
    (void)entries;
    (void)entry_capacity;
    return 0;
}

int xemu_memory_tools_exact_trace_handle_guest_debug(CPUState *cpu)
{
    (void)cpu;
    return 0;
}
