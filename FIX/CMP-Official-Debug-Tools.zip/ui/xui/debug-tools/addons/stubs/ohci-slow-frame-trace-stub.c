/* xemu Debug Tools - no-op OHCI slow-frame diagnostics for non-full profiles. */
#include "../diagnostics/ohci-slow-frame-trace-hook.h"

uint64_t xemu_debug_tools_ohci_slow_frame_trace_threshold_ns(void)
{
    return 0;
}

void xemu_debug_tools_ohci_slow_frame_trace_record(
    const XemuDebugToolsOhciSlowFrameEvent *event)
{
    (void)event;
}
