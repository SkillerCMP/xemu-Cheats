/* xemu Debug Tools - disabled-profile PGRAPH draw stage observation stubs. */
#include "../diagnostics/pgraph-draw-trace-hook.h"

void xemu_debug_tools_pgraph_draw_trace_stage_begin(
    unsigned int stage, const void *pgraph_state, uint64_t value0,
    uint64_t value1)
{
    (void)stage;
    (void)pgraph_state;
    (void)value0;
    (void)value1;
}

void xemu_debug_tools_pgraph_draw_trace_metric(unsigned int metric, uint64_t value)
{
    (void)metric;
    (void)value;
}

void xemu_debug_tools_pgraph_draw_trace_pipeline_cache(unsigned int outcome)
{
    (void)outcome;
}

void xemu_debug_tools_pgraph_draw_trace_stage_end(unsigned int stage)
{
    (void)stage;
}
