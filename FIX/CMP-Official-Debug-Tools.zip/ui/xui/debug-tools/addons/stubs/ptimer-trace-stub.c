/*
 * xemu Debug Tools - no-op PTIMER trace hooks for profiles without Diagnostics.
 */
#include "../diagnostics/ptimer-trace-hook.h"

void xemu_debug_tools_ptimer_trace_init(void)
{
}

void xemu_debug_tools_ptimer_trace_record(
    void *nv2a_state,
    XemuDebugToolsPtimerTraceHookEvent event_type,
    uint32_t value,
    uint32_t previous_value)
{
    (void)nv2a_state;
    (void)event_type;
    (void)value;
    (void)previous_value;
}
