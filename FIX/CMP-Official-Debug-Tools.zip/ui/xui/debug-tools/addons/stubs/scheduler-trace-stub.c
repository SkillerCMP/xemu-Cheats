/* xemu Debug Tools - disabled-profile scheduler wake observation stub. */
#include "../diagnostics/scheduler-trace-hook.h"

void xemu_debug_tools_scheduler_trace_note_irq(
    unsigned int source, uint32_t pending, uint32_t enabled)
{
    (void)source;
    (void)pending;
    (void)enabled;
}
