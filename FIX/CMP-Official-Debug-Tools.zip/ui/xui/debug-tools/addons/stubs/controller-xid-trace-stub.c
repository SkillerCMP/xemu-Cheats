/*
 * xemu Debug Tools - no-op Controller / XID trace hooks for non-Full profiles.
 */
#include "../diagnostics/controller-xid-trace.h"

#include <string.h>

void xemu_debug_tools_controller_xid_trace_init(void)
{
}

void xemu_debug_tools_controller_xid_trace_host_lifecycle(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    uint32_t instance_id,
    int32_t save_binding,
    const char *name,
    const char *guid)
{
    (void)event_type;
    (void)port;
    (void)instance_id;
    (void)save_binding;
    (void)name;
    (void)guid;
}

void xemu_debug_tools_controller_xid_trace_host_state(
    int32_t port,
    uint32_t instance_id,
    uint32_t buttons,
    const int16_t axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT])
{
    (void)port;
    (void)instance_id;
    (void)buttons;
    (void)axis;
}

void xemu_debug_tools_controller_xid_trace_xid_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *xid_device,
    uint32_t value0,
    uint32_t value1)
{
    (void)event_type;
    (void)port;
    (void)xid_device;
    (void)value0;
    (void)value1;
}

void xemu_debug_tools_controller_xid_trace_usb_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3)
{
    (void)event_type;
    (void)port;
    (void)usb_device;
    (void)value0;
    (void)value1;
    (void)value2;
    (void)value3;
}

void xemu_debug_tools_controller_xid_trace_usb_event5(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3,
    uint32_t value4)
{
    (void)event_type;
    (void)port;
    (void)usb_device;
    (void)value0;
    (void)value1;
    (void)value2;
    (void)value3;
    (void)value4;
}

void xemu_debug_tools_controller_xid_trace_xid_packet_complete(
    int32_t port,
    const void *xid_device,
    int32_t packet_status,
    uint32_t actual_length,
    uint32_t requested_length,
    uint32_t endpoint,
    const uint8_t *report,
    uint32_t report_length)
{
    (void)port;
    (void)xid_device;
    (void)packet_status;
    (void)actual_length;
    (void)requested_length;
    (void)endpoint;
    (void)report;
    (void)report_length;
}


void xemu_debug_tools_controller_xid_trace_guest_input_write(
    const void *usb_device,
    uint32_t td_address,
    uint32_t guest_address0,
    uint32_t guest_length0,
    uint32_t guest_address1,
    uint32_t guest_length1,
    const uint8_t *report,
    uint32_t report_length)
{
    (void)usb_device;
    (void)td_address;
    (void)guest_address0;
    (void)guest_length0;
    (void)guest_address1;
    (void)guest_length1;
    (void)report;
    (void)report_length;
}

void xemu_debug_tools_controller_xid_trace_input_mode(
    int32_t enabled,
    int32_t nav_active,
    int32_t controller_activity,
    int32_t rebinding,
    int32_t navigating_with_controller)
{
    (void)enabled;
    (void)nav_active;
    (void)controller_activity;
    (void)rebinding;
    (void)navigating_with_controller;
}

void xemu_debug_tools_controller_xid_trace_xid_state(
    int32_t port,
    const void *xid_device,
    uint32_t host_buttons,
    const int16_t host_axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT],
    uint16_t xid_buttons,
    const uint8_t xid_analog[XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT],
    int16_t thumb_lx,
    int16_t thumb_ly,
    int16_t thumb_rx,
    int16_t thumb_ry)
{
    (void)port;
    (void)xid_device;
    (void)host_buttons;
    (void)host_axis;
    (void)xid_buttons;
    (void)xid_analog;
    (void)thumb_lx;
    (void)thumb_ly;
    (void)thumb_rx;
    (void)thumb_ry;
}


void xemu_debug_tools_controller_xid_trace_set_enabled(int enabled)
{
    (void)enabled;
}

void xemu_debug_tools_controller_xid_trace_clear(void)
{
}

void xemu_debug_tools_controller_xid_trace_get_status(
    XemuDebugToolsControllerXidTraceStatus *status)
{
    if (status) {
        memset(status, 0, sizeof(*status));
    }
}

size_t xemu_debug_tools_controller_xid_trace_snapshot(
    XemuDebugToolsControllerXidTraceEvent *events,
    size_t capacity)
{
    (void)events;
    (void)capacity;
    return 0;
}
