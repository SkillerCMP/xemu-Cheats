/* Non-Diagnostics stub for Patch 300 pusher/semaphore observation hooks. */
#include "ui/xui/debug-tools/addons/diagnostics/pgraph-pusher-progress-trace-hook.h"

int xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled(void) { return 0; }
void xemu_debug_tools_pgraph_pusher_progress_note_dma_put(uint32_t channel_id, uint32_t dma_get, uint32_t old_dma_put, uint32_t new_dma_put)
{ (void)channel_id; (void)dma_get; (void)old_dma_put; (void)new_dma_put; }
void xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t channel_id, uint32_t dma_get, uint32_t dma_put)
{ (void)channel_id; (void)dma_get; (void)dma_put; if (scope) scope->active = 0; }
void xemu_debug_tools_pgraph_pusher_progress_pfifo_end(XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t dma_get, uint32_t dma_put, uint32_t method_words_processed, uint32_t waiting_for_nop, uint32_t waiting_for_flip, uint32_t fifo_access)
{ (void)scope; (void)dma_get; (void)dma_put; (void)method_words_processed; (void)waiting_for_nop; (void)waiting_for_flip; (void)fifo_access; }
void xemu_debug_tools_pgraph_pusher_progress_semaphore_begin(XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t dma_instance, uint32_t semaphore_offset, uint32_t value)
{ (void)dma_instance; (void)semaphore_offset; (void)value; if (scope) scope->active = 0; }
void xemu_debug_tools_pgraph_pusher_progress_semaphore_target(XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t physical_address, uint32_t guest_virtual_address, uint32_t previous_value)
{ (void)scope; (void)physical_address; (void)guest_virtual_address; (void)previous_value; }
void xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite(XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t waiting_for_nop, uint32_t waiting_for_flip)
{ (void)scope; (void)waiting_for_nop; (void)waiting_for_flip; }

int xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled(void) { return 0; }
void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin(XemuDebugToolsPgraphPusherPullerScope *scope)
{ if (scope) scope->active = 0; }
void xemu_debug_tools_pgraph_pusher_method_breakdown_note_method(uint32_t subchannel, uint32_t graphics_class, uint32_t method, uint32_t method_base, uint32_t parameter, const char *method_name)
{ (void)subchannel; (void)graphics_class; (void)method; (void)method_base; (void)parameter; (void)method_name; }
void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end(XemuDebugToolsPgraphPusherPullerScope *scope, uint32_t words_processed)
{ (void)scope; (void)words_processed; }
