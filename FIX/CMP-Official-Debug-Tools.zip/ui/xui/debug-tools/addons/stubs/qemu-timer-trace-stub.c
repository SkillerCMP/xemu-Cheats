/* xemu Debug Tools - no-op QEMU timer trace watch for non-Diagnostics profiles. */
#include "../diagnostics/qemu-timer-trace-hook.h"

void xemu_debug_tools_qemu_timer_trace_init(void)
{
}

void xemu_debug_tools_qemu_timer_trace_watch(void *timer)
{
    (void)timer;
}
