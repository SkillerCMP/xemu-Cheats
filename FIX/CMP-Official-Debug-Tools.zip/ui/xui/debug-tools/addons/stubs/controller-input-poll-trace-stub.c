/* xemu Debug Tools - no-op Controller Input Poll profiler stub. */
#include "../diagnostics/controller-input-poll-trace-hook.h"

uint64_t xemu_debug_tools_controller_input_poll_trace_threshold_ns(void) { return 0; }
int xemu_debug_tools_controller_input_poll_trace_begin(int device_index, int pid,
                                                       uint32_t endpoint,
                                                       uint32_t requested_length)
{
    (void)device_index; (void)pid; (void)endpoint; (void)requested_length;
    return 0;
}
int xemu_debug_tools_controller_input_poll_trace_active(void) { return 0; }
uint64_t xemu_debug_tools_controller_input_poll_trace_stage_begin(void) { return 0; }
void xemu_debug_tools_controller_input_poll_trace_stage_end(uint32_t stage,
                                                            uint64_t host_start_ns)
{ (void)stage; (void)host_start_ns; }
void xemu_debug_tools_controller_input_poll_trace_getter_end(uint32_t getter,
                                                             uint64_t host_start_ns)
{ (void)getter; (void)host_start_ns; }
void xemu_debug_tools_controller_input_poll_trace_set_controller(
    int32_t sdl_joystick_id, uint32_t controller_type, uint32_t connected)
{ (void)sdl_joystick_id; (void)controller_type; (void)connected; }
void xemu_debug_tools_controller_input_poll_trace_set_update_result(
    uint32_t update_performed, uint32_t skipped_disconnected,
    uint32_t skipped_interval)
{ (void)update_performed; (void)skipped_disconnected; (void)skipped_interval; }
void xemu_debug_tools_controller_input_poll_trace_end(int packet_status,
                                                     uint32_t actual_length)
{ (void)packet_status; (void)actual_length; }
void xemu_debug_tools_controller_input_poll_trace_set_enabled(int enabled)
{ (void)enabled; }
void xemu_debug_tools_controller_input_poll_trace_set_threshold_ns(uint64_t threshold_ns)
{ (void)threshold_ns; }
void xemu_debug_tools_controller_input_poll_trace_clear(void) {}
void xemu_debug_tools_controller_input_poll_trace_get_status(
    XemuDebugToolsControllerInputPollStatus *status)
{
    if (status) {
        *status = (XemuDebugToolsControllerInputPollStatus){
            .threshold_ns = XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_DEFAULT_THRESHOLD_NS,
        };
    }
}
size_t xemu_debug_tools_controller_input_poll_trace_snapshot(
    XemuDebugToolsControllerInputPollEvent *events, size_t capacity)
{ (void)events; (void)capacity; return 0; }
