#include "cheat-db.hh"
#include "cheat-db-format.hh"

#include "../../cheat-engine.hh"
#include "../../current-game.hh"
#include "../../debug-tools.hh"
#include "../../debug-tools-module.hh"
#include "../../detached-tools.hh"

#include "../../../common.hh"

extern "C" {
#include "qapi/error.h"
#include "qemu/http.h"
}

#include <glib.h>
#include <glib/gstdio.h>

#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
#include <memory>
#include <map>
#include <set>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include <nlohmann/json.hpp>

namespace XemuCheatDb {

using json = nlohmann::json;

CheatDbManager cheat_db_manager;

namespace {

using XemuCheatDbFormat::Block;
using XemuCheatDbFormat::BlockCompareStatus;
using XemuCheatDbFormat::BlockIdentity;
using XemuCheatDbFormat::BlockText;
using XemuCheatDbFormat::ClassifyRemoteBlock;
using XemuCheatDbFormat::Document;
using XemuCheatDbFormat::Header;
using XemuCheatDbFormat::MergeSelected;
using XemuCheatDbFormat::ParseDocument;
using XemuCheatDbFormat::Trim;
using XemuCheatDbFormat::Upper;

constexpr const char *kManifestUrl =
    "https://raw.githubusercontent.com/SkillerCMP/XEMU-CHEATDB/main/cheatdb-manifest.json";
constexpr size_t kMaxManifestBytes = 8u * 1024u * 1024u;
constexpr size_t kMaxCheatFileBytes = 16u * 1024u * 1024u;
constexpr size_t kMaxManifestFiles = 10000u;

struct ManifestFile {
    std::string path;
    std::string relative_path;
    std::string sha256;
    std::string download_url;
    std::string group;
    uint64_t size = 0;
};

struct Manifest {
    int schema_version = 0;
    std::string repository;
    std::string branch;
    std::string source_commit;
    std::string source_commit_date;
    std::string cheat_root;
    std::vector<ManifestFile> files;
};

struct FileState {
    std::string remote_path;
    std::string local_file;
    std::string remote_file_sha256;
    std::string source_commit;
    std::unordered_map<std::string, std::string> block_hashes;
};

struct StateDb {
    std::unordered_map<std::string, FileState> files;
};

using ItemStatus = BlockCompareStatus;

struct ReviewItem {
    std::string identity;
    std::string group_path;
    std::string name;
    std::string local_hash;
    std::string remote_hash;
    ItemStatus status = ItemStatus::New;
    bool selected = false;
    bool has_remote = true;
};

struct ReviewModel {
    bool valid = false;
    GameRef game;
    ManifestFile remote_file;
    std::string source_commit;
    std::string local_path;
    std::string local_text;
    std::string local_file_sha256;
    std::string remote_text;
    Document local_doc;
    Document remote_doc;
    std::vector<ReviewItem> items;
    size_t new_count = 0;
    size_t updated_count = 0;
    size_t local_modified_count = 0;
    size_t conflict_count = 0;
    size_t local_only_count = 0;
    size_t same_count = 0;
};

std::string Sha256(const void *data, size_t size)
{
    GChecksum *checksum = g_checksum_new(G_CHECKSUM_SHA256);
    if (!checksum) {
        return {};
    }
    if (data && size) {
        g_checksum_update(checksum, static_cast<const guchar *>(data), size);
    }
    const gchar *text = g_checksum_get_string(checksum);
    std::string result = text ? Upper(text) : std::string();
    g_checksum_free(checksum);
    return result;
}

std::string Sha256(const std::string &text)
{
    return Sha256(text.data(), text.size());
}

std::string HashBlock(const Block &block)
{
    return Sha256(BlockText(block));
}

bool ReadTextFile(const std::string &path, std::string &out)
{
    gchar *contents = nullptr;
    gsize length = 0;
    GError *error = nullptr;
    const bool ok = g_file_get_contents(path.c_str(), &contents, &length, &error);
    if (!ok) {
        if (error) {
            g_error_free(error);
        }
        return false;
    }
    out.assign(contents, length);
    g_free(contents);
    return true;
}

bool WriteTextFile(const std::string &path, const std::string &text,
                   std::string &error_text)
{
    GError *error = nullptr;
    if (!g_file_set_contents(path.c_str(), text.data(), text.size(), &error)) {
        error_text = error ? error->message : "write failed";
        if (error) {
            g_error_free(error);
        }
        return false;
    }
    return true;
}

std::string FileSha256(const std::string &path)
{
    std::string text;
    return ReadTextFile(path, text) ? Sha256(text) : std::string();
}

std::string Basename(const std::string &path)
{
    gchar *base = g_path_get_basename(path.c_str());
    std::string result = base ? base : std::string();
    g_free(base);
    return result;
}

bool EndsWithTxt(const std::string &path)
{
    const std::string upper = Upper(path);
    return upper.size() >= 4 && upper.compare(upper.size() - 4, 4, ".TXT") == 0;
}

bool IsReservedCheatPath(const std::string &path)
{
    const std::string upper = Upper(path);
    return upper.find("FILE-REPLACEMENTS/") != std::string::npos ||
           upper.find("FILE-REPLACEMENTS\\") != std::string::npos ||
           upper.find("/BACKUP/") != std::string::npos ||
           upper.find("\\BACKUP\\") != std::string::npos;
}

std::string StatePath(const std::string &cheat_dir)
{
    gchar *path = g_build_filename(cheat_dir.c_str(), ".cheatdb-state.json", nullptr);
    std::string result = path ? path : ".cheatdb-state.json";
    g_free(path);
    return result;
}

std::string JsonString(const json &object, const char *key)
{
    auto it = object.find(key);
    return it != object.end() && it->is_string() ? it->get<std::string>()
                                                  : std::string();
}

bool ParseManifest(const std::string &text, Manifest &manifest,
                   std::string &error_text)
{
    try {
        const json root = json::parse(text);
        if (!root.is_object()) {
            error_text = "manifest root is not an object";
            return false;
        }

        Manifest parsed;
        parsed.schema_version = root.value("schema_version", 0);
        parsed.repository = JsonString(root, "repository");
        parsed.branch = JsonString(root, "branch");
        parsed.source_commit = JsonString(root, "source_commit");
        parsed.source_commit_date = JsonString(root, "source_commit_date");
        parsed.cheat_root = JsonString(root, "cheat_root");

        auto files_it = root.find("files");
        if (parsed.schema_version != 1 || files_it == root.end() ||
            !files_it->is_array()) {
            error_text = "unsupported or incomplete CheatDB manifest";
            return false;
        }
        if (files_it->size() > kMaxManifestFiles) {
            error_text = "CheatDB manifest contains too many files";
            return false;
        }

        for (const json &item : *files_it) {
            if (!item.is_object()) {
                continue;
            }
            ManifestFile file;
            file.path = JsonString(item, "path");
            file.relative_path = JsonString(item, "relative_path");
            file.sha256 = Upper(JsonString(item, "sha256"));
            file.download_url = JsonString(item, "download_url");
            file.group = JsonString(item, "group");
            auto size_it = item.find("size");
            if (size_it != item.end() && size_it->is_number_unsigned()) {
                file.size = size_it->get<uint64_t>();
            } else if (size_it != item.end() && size_it->is_number_integer()) {
                const int64_t size = size_it->get<int64_t>();
                file.size = size > 0 ? static_cast<uint64_t>(size) : 0;
            }
            if (file.path.empty() || file.relative_path.empty() ||
                file.sha256.empty() || file.download_url.empty()) {
                continue;
            }
            parsed.files.push_back(std::move(file));
        }

        manifest = std::move(parsed);
        return true;
    } catch (const json::exception &e) {
        error_text = std::string("invalid CheatDB JSON: ") + e.what();
        return false;
    }
}

StateDb LoadState(const std::string &cheat_dir)
{
    StateDb state;
    std::string text;
    if (!ReadTextFile(StatePath(cheat_dir), text)) {
        return state;
    }

    try {
        const json root = json::parse(text);
        if (!root.is_object()) {
            return state;
        }
        auto files_it = root.find("files");
        if (files_it == root.end() || !files_it->is_array()) {
            return state;
        }

        for (const json &item : *files_it) {
            if (!item.is_object()) {
                continue;
            }
            FileState file;
            file.remote_path = JsonString(item, "remote_path");
            file.local_file = JsonString(item, "local_file");
            file.remote_file_sha256 = Upper(JsonString(item, "remote_sha256"));
            file.source_commit = JsonString(item, "source_commit");

            auto blocks_it = item.find("blocks");
            if (blocks_it != item.end() && blocks_it->is_array()) {
                for (const json &block : *blocks_it) {
                    if (!block.is_object()) {
                        continue;
                    }
                    const std::string identity = JsonString(block, "identity");
                    const std::string hash = Upper(JsonString(block, "sha256"));
                    if (!identity.empty() && !hash.empty()) {
                        file.block_hashes[identity] = hash;
                    }
                }
            }
            if (!file.remote_path.empty()) {
                state.files[file.remote_path] = std::move(file);
            }
        }
    } catch (const json::exception &) {
        // Corrupt or older ownership state must never block cheat loading.
        return StateDb{};
    }
    return state;
}

bool SaveState(const std::string &cheat_dir, const StateDb &state,
               std::string &error_text)
{
    try {
        json root = json::object();
        root["schema_version"] = 1;
        root["files"] = json::array();

        std::vector<std::string> paths;
        paths.reserve(state.files.size());
        for (const auto &entry : state.files) {
            paths.push_back(entry.first);
        }
        std::sort(paths.begin(), paths.end());

        for (const std::string &path : paths) {
            const FileState &file = state.files.at(path);
            json item = {
                {"remote_path", file.remote_path},
                {"local_file", file.local_file},
                {"remote_sha256", file.remote_file_sha256},
                {"source_commit", file.source_commit},
                {"blocks", json::array()},
            };

            std::vector<std::string> identities;
            identities.reserve(file.block_hashes.size());
            for (const auto &block : file.block_hashes) {
                identities.push_back(block.first);
            }
            std::sort(identities.begin(), identities.end());
            for (const std::string &identity : identities) {
                item["blocks"].push_back({
                    {"identity", identity},
                    {"sha256", file.block_hashes.at(identity)},
                });
            }
            root["files"].push_back(std::move(item));
        }

        return WriteTextFile(StatePath(cheat_dir), root.dump(2) + "\n",
                             error_text);
    } catch (const json::exception &e) {
        error_text = std::string("could not serialize CheatDB state: ") + e.what();
        return false;
    }
}

std::string CurrentShortId(uint32_t title_id)
{
    return Upper(CurrentGameManager::FormatDatabaseGameId(title_id));
}

std::string FullId(uint32_t title_id)
{
    return Upper(CurrentGameManager::FormatTitleId(title_id));
}

bool PrefixHashMatches(const std::string &candidate, const std::string &full)
{
    std::string a = Upper(Trim(candidate));
    const std::string b = Upper(Trim(full));
    if (a.rfind("0X", 0) == 0) {
        a.erase(0, 2);
    }
    if (a.empty() || b.empty() || a.size() > b.size()) {
        return false;
    }
    for (char c : a) {
        if (!std::isxdigit((unsigned char)c)) {
            return false;
        }
    }
    return b.compare(0, a.size(), a) == 0;
}

bool HeaderMatchesGame(const Header &header, const GameRef &game)
{
    if (!header.title_id_valid || header.title_id != game.title_id) {
        return false;
    }
    return game.executable_identity.empty() || header.hash.empty() ||
           PrefixHashMatches(header.hash, game.executable_identity);
}

bool PathLooksLikeGame(const ManifestFile &file, const GameRef &game)
{
    const std::string short_id = CurrentShortId(game.title_id);
    const std::string full_id = FullId(game.title_id);
    const std::string path = Upper(file.relative_path);
    const std::string group = Upper(file.group);
    const std::string base = Upper(Basename(file.relative_path));
    return group == short_id || group == full_id ||
           base.rfind(short_id + "-", 0) == 0 ||
           base.rfind(full_id + "-", 0) == 0 ||
           path.find(short_id) != std::string::npos ||
           path.find(full_id) != std::string::npos;
}

std::vector<const ManifestFile *> CandidateFiles(const Manifest &manifest,
                                                  const GameRef &game,
                                                  bool fallback_all)
{
    std::vector<const ManifestFile *> preferred;
    std::vector<const ManifestFile *> fallback;
    for (const ManifestFile &file : manifest.files) {
        if (!EndsWithTxt(file.relative_path) || IsReservedCheatPath(file.relative_path)) {
            continue;
        }
        if (PathLooksLikeGame(file, game)) {
            preferred.push_back(&file);
        } else if (fallback_all) {
            fallback.push_back(&file);
        }
    }
    preferred.insert(preferred.end(), fallback.begin(), fallback.end());
    return preferred;
}

bool DownloadUrl(const std::string &url, size_t max_bytes, std::string &text,
                 std::string &error_text)
{
    g_autoptr(GByteArray) data = g_byte_array_new();
    Error *error = nullptr;
    const int status = http_get(url.c_str(), data, nullptr, &error);
    if (status != 200) {
        if (error) {
            error_text = error_get_pretty(error);
        } else {
            error_text = "HTTP " + std::to_string(status);
        }
        error_free(error);
        return false;
    }
    error_free(error);
    if (data->len > max_bytes) {
        error_text = "download exceeded safety size limit";
        return false;
    }
    text.assign(reinterpret_cast<const char *>(data->data), data->len);
    return true;
}

bool EnsureCheatDirectory(const std::string &dir, std::string &error_text)
{
    if (dir.empty()) {
        error_text = "Cheats directory is unavailable";
        return false;
    }
    if (g_mkdir_with_parents(dir.c_str(), 0755) != 0) {
        error_text = "could not create Cheats directory";
        return false;
    }
    return true;
}

std::string JoinFile(const std::string &dir, const std::string &name)
{
    gchar *path = g_build_filename(dir.c_str(), name.c_str(), nullptr);
    std::string result = path ? path : name;
    g_free(path);
    return result;
}

std::string FindLocalFile(const std::string &cheat_dir, const GameRef &game,
                          const std::string &preferred)
{
    if (!preferred.empty() && g_file_test(preferred.c_str(), G_FILE_TEST_IS_REGULAR)) {
        std::string text;
        if (ReadTextFile(preferred, text) && HeaderMatchesGame(ParseDocument(text).header, game)) {
            return preferred;
        }
    }

    GError *error = nullptr;
    GDir *dir = g_dir_open(cheat_dir.c_str(), 0, &error);
    if (!dir) {
        if (error) {
            g_error_free(error);
        }
        return {};
    }
    std::string best;
    const gchar *name = nullptr;
    while ((name = g_dir_read_name(dir)) != nullptr) {
        std::string filename(name);
        if (!EndsWithTxt(filename)) {
            continue;
        }
        const std::string path = JoinFile(cheat_dir, filename);
        std::string text;
        if (!ReadTextFile(path, text)) {
            continue;
        }
        if (HeaderMatchesGame(ParseDocument(text).header, game)) {
            best = path;
            break;
        }
    }
    g_dir_close(dir);
    return best;
}

std::string SuggestedDestination(const std::string &cheat_dir,
                                 const ManifestFile &remote,
                                 const Header &header)
{
    std::string name = Basename(remote.relative_path);
    if (name.empty() || !EndsWithTxt(name)) {
        const std::string game_id = header.game_id.empty()
                                        ? FullId(header.title_id)
                                        : Upper(header.game_id);
        const std::string hash = header.hash.size() >= 16
                                     ? Upper(header.hash.substr(0, 16))
                                     : Upper(header.hash);
        name = game_id + (hash.empty() ? "" : "-" + hash) + ".txt";
    }
    std::string path = JoinFile(cheat_dir, name);
    if (!g_file_test(path.c_str(), G_FILE_TEST_EXISTS)) {
        return path;
    }
    const std::string hash = header.hash.size() >= 16
                                 ? Upper(header.hash.substr(0, 16))
                                 : Upper(header.hash);
    const std::string game_id = header.game_id.empty()
                                    ? FullId(header.title_id)
                                    : Upper(header.game_id);
    const std::string stem = game_id + (hash.empty() ? "" : "-" + hash);
    path = JoinFile(cheat_dir, stem + ".txt");
    if (!g_file_test(path.c_str(), G_FILE_TEST_EXISTS)) {
        return path;
    }
    for (unsigned int suffix = 1; suffix < 1000; ++suffix) {
        const std::string candidate = JoinFile(
            cheat_dir, stem + "-db" + (suffix == 1 ? std::string()
                                                  : std::to_string(suffix)) +
                           ".txt");
        if (!g_file_test(candidate.c_str(), G_FILE_TEST_EXISTS)) {
            return candidate;
        }
    }
    return JoinFile(cheat_dir, stem + "-db-overflow.txt");
}

std::string BackupFile(const std::string &cheat_dir, const std::string &path,
                       std::string &error_text)
{
    if (!g_file_test(path.c_str(), G_FILE_TEST_IS_REGULAR)) {
        return {};
    }
    GDateTime *now = g_date_time_new_now_local();
    gchar *stamp = now ? g_date_time_format(now, "%Y%m%d-%H%M%S") : nullptr;
    const std::string stamp_text = stamp ? stamp : "backup";
    g_free(stamp);
    if (now) {
        g_date_time_unref(now);
    }
    const std::string backup_root = JoinFile(cheat_dir, "Backup");
    const std::string backup_dir = JoinFile(backup_root, stamp_text);
    if (g_mkdir_with_parents(backup_dir.c_str(), 0755) != 0) {
        error_text = "could not create Cheats/Backup directory";
        return {};
    }
    const std::string destination = JoinFile(backup_dir, Basename(path));
    std::string contents;
    if (!ReadTextFile(path, contents) || !WriteTextFile(destination, contents, error_text)) {
        if (error_text.empty()) {
            error_text = "could not back up local cheat file";
        }
        return {};
    }
    return destination;
}

FileState *FindFileState(StateDb &state, const std::string &remote_path)
{
    auto it = state.files.find(remote_path);
    return it == state.files.end() ? nullptr : &it->second;
}

const FileState *FindFileState(const StateDb &state, const std::string &remote_path)
{
    auto it = state.files.find(remote_path);
    return it == state.files.end() ? nullptr : &it->second;
}

ReviewModel BuildReview(const GameRef &game, const ManifestFile &remote,
                        const std::string &source_commit,
                        const std::string &remote_text,
                        const std::string &local_path,
                        const std::string &local_text,
                        const StateDb &state)
{
    ReviewModel review;
    review.valid = true;
    review.game = game;
    review.remote_file = remote;
    review.source_commit = source_commit;
    review.remote_text = remote_text;
    review.remote_doc = ParseDocument(remote_text);
    review.local_path = local_path;
    review.local_text = local_text;
    review.local_file_sha256 = local_text.empty() ? std::string() : Sha256(local_text);
    if (!local_text.empty()) {
        review.local_doc = ParseDocument(local_text);
    }

    std::unordered_map<std::string, const Block *> local_blocks;
    for (const Block &block : review.local_doc.blocks) {
        local_blocks[BlockIdentity(block)] = &block;
    }
    const FileState *file_state = FindFileState(state, remote.path);

    std::unordered_set<std::string> remote_identities;
    for (const Block &remote_block : review.remote_doc.blocks) {
        ReviewItem item;
        item.identity = BlockIdentity(remote_block);
        item.group_path = remote_block.group_path;
        item.name = remote_block.name;
        item.remote_hash = HashBlock(remote_block);
        remote_identities.insert(item.identity);
        auto local_it = local_blocks.find(item.identity);
        std::string previous;
        if (file_state) {
            auto previous_it = file_state->block_hashes.find(item.identity);
            if (previous_it != file_state->block_hashes.end()) {
                previous = previous_it->second;
            }
        }
        const bool has_local = local_it != local_blocks.end();
        if (has_local) {
            item.local_hash = HashBlock(*local_it->second);
        }
        item.status = ClassifyRemoteBlock(has_local, item.local_hash,
                                          item.remote_hash, previous);
        switch (item.status) {
        case ItemStatus::New:
            item.selected = true;
            ++review.new_count;
            break;
        case ItemStatus::Updated:
            item.selected = true;
            ++review.updated_count;
            break;
        case ItemStatus::Same:
            ++review.same_count;
            break;
        case ItemStatus::LocalModified:
            ++review.local_modified_count;
            break;
        case ItemStatus::Conflict:
            ++review.conflict_count;
            break;
        case ItemStatus::LocalOnly:
            break;
        }
        review.items.push_back(std::move(item));
    }

    for (const Block &local_block : review.local_doc.blocks) {
        const std::string identity = BlockIdentity(local_block);
        if (remote_identities.find(identity) != remote_identities.end()) {
            continue;
        }
        ReviewItem item;
        item.identity = identity;
        item.group_path = local_block.group_path;
        item.name = local_block.name;
        item.local_hash = HashBlock(local_block);
        item.status = ItemStatus::LocalOnly;
        item.has_remote = false;
        ++review.local_only_count;
        review.items.push_back(std::move(item));
    }
    return review;
}

void UpdateStateAfterMerge(StateDb &state, const ReviewModel &review,
                           const std::unordered_set<std::string> &applied,
                           bool direct_download)
{
    FileState &file = state.files[review.remote_file.path];
    file.remote_path = review.remote_file.path;
    file.local_file = Basename(review.local_path);
    file.remote_file_sha256 = review.remote_file.sha256;
    file.source_commit = review.source_commit;

    std::unordered_map<std::string, const ReviewItem *> items;
    for (const ReviewItem &item : review.items) {
        if (item.has_remote) {
            items[item.identity] = &item;
        }
    }
    for (const Block &block : review.remote_doc.blocks) {
        const std::string identity = BlockIdentity(block);
        const std::string hash = HashBlock(block);
        auto it = items.find(identity);
        if (direct_download || applied.find(identity) != applied.end() ||
            (it != items.end() && it->second->status == ItemStatus::Same)) {
            file.block_hashes[identity] = hash;
        }
    }
}

struct ManifestJob {
    CheatDbManager *owner = nullptr;
    Manifest manifest;
    std::string error;
};

struct ReviewJob {
    CheatDbManager *owner = nullptr;
    Manifest manifest;
    GameRef game;
    std::string cheat_dir;
    std::string preferred_local;
    ReviewModel review;
    StateDb state;
    std::string error;
};

struct ApplyJob {
    CheatDbManager *owner = nullptr;
    ReviewModel review;
    std::string cheat_dir;
    std::unordered_set<std::string> selected;
    bool safe_only = false;
    bool success = false;
    bool changed = false;
    std::string status;
};

struct GlobalJob {
    CheatDbManager *owner = nullptr;
    Manifest manifest;
    std::string cheat_dir;
    size_t downloaded = 0;
    size_t updated = 0;
    size_t unchanged = 0;
    size_t preserved = 0;
    size_t failed = 0;
    bool success = false;
    std::string status;
};

} // namespace

struct CheatDbManager::Impl {
    Manifest manifest;
    StateDb state;
    bool manifest_loaded = false;
    bool manifest_checking = false;
    bool review_checking = false;
    bool apply_in_flight = false;
    bool global_in_flight = false;
    bool reload_current_requested = false;
    std::string status;
    std::string manifest_status;
    ReviewModel review;
    GameRef requested_game;
    bool global_view = false;
};

namespace {

GameRef CurrentGameRef()
{
    GameRef ref;
    const auto &game = current_game_manager.Get();
    if (!game.valid) {
        return ref;
    }
    ref.title_id = game.title_id;
    ref.game_id = CurrentGameManager::FormatDatabaseGameId(game.title_id);
    ref.name = game.title_name;
    ref.executable_identity = game.header_sha256;
    return ref;
}

bool SameGameIdentity(const GameRef &a, const GameRef &b)
{
    if (!a.valid() || !b.valid() || a.title_id != b.title_id) {
        return false;
    }
    if (a.executable_identity.empty() || b.executable_identity.empty()) {
        return true;
    }
    return Upper(a.executable_identity) == Upper(b.executable_identity);
}

const ManifestFile *FastCandidate(const Manifest &manifest, const GameRef &game)
{
    auto candidates = CandidateFiles(manifest, game, false);
    const ManifestFile *best = nullptr;
    size_t best_score = 0;
    const std::string short_id = CurrentShortId(game.title_id);
    const std::string full_id = FullId(game.title_id);
    const std::string identity = Upper(game.executable_identity);
    const std::string identity16 = identity.size() >= 16 ? identity.substr(0, 16) : identity;
    for (const ManifestFile *candidate : candidates) {
        const std::string path = Upper(candidate->relative_path);
        const std::string base = Upper(Basename(candidate->relative_path));
        size_t score = 1;
        if (!identity.empty() && path.find(identity) != std::string::npos) {
            score += 1024;
        } else if (!identity16.empty() && path.find(identity16) != std::string::npos) {
            score += 512;
        }
        if (base.rfind(short_id + "-", 0) == 0) {
            score += 128;
        } else if (base.rfind(full_id + "-", 0) == 0) {
            score += 64;
        }
        if (!best || score > best_score) {
            best = candidate;
            best_score = score;
        }
    }
    return best;
}

void ManifestWork(void *opaque)
{
    auto *job = static_cast<ManifestJob *>(opaque);
    std::string text;
    if (!DownloadUrl(kManifestUrl, kMaxManifestBytes, text, job->error)) {
        return;
    }
    ParseManifest(text, job->manifest, job->error);
}

void ManifestComplete(void *opaque)
{
    std::unique_ptr<ManifestJob> job(static_cast<ManifestJob *>(opaque));
    CheatDbManager *owner = job->owner;
    if (!owner || !owner->m) {
        return;
    }
    owner->m->manifest_checking = false;
    if (!job->error.empty()) {
        owner->m->manifest_loaded = false;
        owner->m->manifest_status = "CheatDB check failed: " + job->error;
        return;
    }
    owner->m->manifest = std::move(job->manifest);
    owner->m->manifest_loaded = true;
    owner->m->state = LoadState(cheat_engine_window.CheatDirectoryPath());
    owner->m->manifest_status =
        "CheatDB manifest loaded: " +
        std::to_string(owner->m->manifest.files.size()) + " files; source " +
        (owner->m->manifest.source_commit.empty()
             ? std::string("unknown")
             : owner->m->manifest.source_commit.substr(
                   0, std::min<size_t>(12, owner->m->manifest.source_commit.size())));

    if (owner->m->requested_game.valid()) {
        owner->OpenForGame(owner->m->requested_game);
    }
}

void ReviewWork(void *opaque)
{
    auto *job = static_cast<ReviewJob *>(opaque);
    if (!EnsureCheatDirectory(job->cheat_dir, job->error)) {
        return;
    }
    job->state = LoadState(job->cheat_dir);

    auto candidates = CandidateFiles(job->manifest, job->game, false);
    if (candidates.empty()) {
        candidates = CandidateFiles(job->manifest, job->game, true);
    }

    const ManifestFile *best = nullptr;
    std::string best_text;
    size_t best_score = 0;
    size_t attempts = 0;
    for (const ManifestFile *candidate : candidates) {
        if (++attempts > 256) {
            break;
        }
        if (candidate->size > kMaxCheatFileBytes) {
            continue;
        }
        std::string remote_text;
        std::string download_error;
        if (!DownloadUrl(candidate->download_url, kMaxCheatFileBytes,
                         remote_text, download_error)) {
            continue;
        }
        Document remote_doc = ParseDocument(remote_text);
        if (!HeaderMatchesGame(remote_doc.header, job->game)) {
            continue;
        }
        size_t score = remote_doc.header.hash.size();
        const std::string base = Upper(Basename(candidate->relative_path));
        if (base.rfind(CurrentShortId(job->game.title_id) + "-", 0) == 0) {
            score += 256;
        } else if (base.rfind(FullId(job->game.title_id) + "-", 0) == 0) {
            score += 128;
        }
        if (!best || score > best_score) {
            best = candidate;
            best_text = std::move(remote_text);
            best_score = score;
        }
    }
    if (!best) {
        job->error = "No matching CMP cheat file was found in XEMU-CHEATDB.";
        return;
    }

    const std::string local_path =
        FindLocalFile(job->cheat_dir, job->game, job->preferred_local);
    std::string local_text;
    if (!local_path.empty()) {
        ReadTextFile(local_path, local_text);
    }
    job->review = BuildReview(job->game, *best, job->manifest.source_commit,
                              best_text, local_path, local_text, job->state);

    // Merely reviewing an identical database-owned block is enough to establish
    // a safe baseline for future LOCAL MODIFIED detection. No cheat text is
    // changed here; only the hidden ownership state is refreshed.
    if (!local_path.empty()) {
        FileState &file = job->state.files[best->path];
        file.remote_path = best->path;
        file.local_file = Basename(local_path);
        file.remote_file_sha256 = best->sha256;
        file.source_commit = job->manifest.source_commit;
        for (const ReviewItem &item : job->review.items) {
            if (item.has_remote && item.status == ItemStatus::Same) {
                file.block_hashes[item.identity] = item.remote_hash;
            }
        }
        std::string state_error;
        SaveState(job->cheat_dir, job->state, state_error);
    }
}

void ReviewComplete(void *opaque)
{
    std::unique_ptr<ReviewJob> job(static_cast<ReviewJob *>(opaque));
    CheatDbManager *owner = job->owner;
    if (!owner || !owner->m) {
        return;
    }
    owner->m->review_checking = false;
    if (!job->error.empty()) {
        owner->m->review = ReviewModel{};
        owner->m->status = job->error;
        return;
    }
    owner->m->state = std::move(job->state);
    owner->m->review = std::move(job->review);
    owner->m->global_view = false;
    owner->m->status.clear();
}

bool ApplyReviewToDisk(ApplyJob &job)
{
    ReviewModel &review = job.review;
    std::string error;
    if (!EnsureCheatDirectory(job.cheat_dir, error)) {
        job.status = error;
        return false;
    }

    StateDb state = LoadState(job.cheat_dir);
    const bool direct_download = review.local_path.empty();
    if (direct_download) {
        review.local_path = SuggestedDestination(job.cheat_dir, review.remote_file,
                                                review.remote_doc.header);
        if (!WriteTextFile(review.local_path, review.remote_text, error)) {
            job.status = "Download failed: " + error;
            return false;
        }
        std::unordered_set<std::string> all;
        for (const Block &block : review.remote_doc.blocks) {
            all.insert(BlockIdentity(block));
        }
        UpdateStateAfterMerge(state, review, all, true);
        job.changed = true;
        if (!SaveState(job.cheat_dir, state, error)) {
            job.status = "Cheats downloaded, but CheatDB state save failed: " + error;
            return true;
        }
        job.status = "Downloaded " + Basename(review.local_path) + " (" +
                     std::to_string(review.remote_doc.blocks.size()) +
                     " database codes).";
        return true;
    }

    const std::string current_sha = FileSha256(review.local_path);
    if (current_sha.empty() || current_sha != review.local_file_sha256) {
        job.status = "Local cheat file changed after the review opened. Re-check before merging.";
        return false;
    }

    std::unordered_set<std::string> selected = job.selected;
    if (job.safe_only) {
        selected.clear();
        for (const ReviewItem &item : review.items) {
            if (item.has_remote &&
                (item.status == ItemStatus::New || item.status == ItemStatus::Updated)) {
                selected.insert(item.identity);
            }
        }
    }
    if (selected.empty()) {
        job.status = "No database codes were selected for merge.";
        return true;
    }

    const auto merged = MergeSelected(review.local_doc, review.remote_doc, selected);
    if (merged.text == review.local_text) {
        job.status = "Selected database codes already match the local file.";
        return true;
    }

    const std::string backup = BackupFile(job.cheat_dir, review.local_path, error);
    if (backup.empty()) {
        job.status = "Merge cancelled because the local backup failed: " + error;
        return false;
    }
    if (!WriteTextFile(review.local_path, merged.text, error)) {
        job.status = "Merge failed: " + error + ". Backup: " + backup;
        return false;
    }
    UpdateStateAfterMerge(state, review, selected, false);
    job.changed = true;
    if (!SaveState(job.cheat_dir, state, error)) {
        job.status = "Merge completed, but CheatDB state save failed: " + error;
        return true;
    }
    job.status = "Merged " + std::to_string(merged.added) + " new and " +
                 std::to_string(merged.replaced) +
                 " updated database codes. Local-only codes were preserved. Backup: " +
                 backup;
    return true;
}

void ApplyWork(void *opaque)
{
    auto *job = static_cast<ApplyJob *>(opaque);
    job->success = ApplyReviewToDisk(*job);
}

void ApplyComplete(void *opaque)
{
    std::unique_ptr<ApplyJob> job(static_cast<ApplyJob *>(opaque));
    CheatDbManager *owner = job->owner;
    if (!owner || !owner->m) {
        return;
    }
    owner->m->apply_in_flight = false;
    owner->m->status = job->status;
    if (job->success && job->changed) {
        owner->m->state = LoadState(job->cheat_dir);
        owner->m->reload_current_requested = true;
        owner->m->review = ReviewModel{};
        owner->m->requested_game = job->review.game;
        owner->OpenForGame(job->review.game);
    }
}

void GlobalWork(void *opaque)
{
    auto *job = static_cast<GlobalJob *>(opaque);
    std::string error;
    if (!EnsureCheatDirectory(job->cheat_dir, error)) {
        job->status = error;
        return;
    }
    StateDb state = LoadState(job->cheat_dir);

    for (const ManifestFile &remote : job->manifest.files) {
        if (!EndsWithTxt(remote.relative_path) || IsReservedCheatPath(remote.relative_path) ||
            remote.size > kMaxCheatFileBytes) {
            continue;
        }
        std::string remote_text;
        std::string download_error;
        if (!DownloadUrl(remote.download_url, kMaxCheatFileBytes,
                         remote_text, download_error)) {
            ++job->failed;
            continue;
        }
        Document remote_doc = ParseDocument(remote_text);
        if (!remote_doc.header.title_id_valid || remote_doc.header.title_id == 0) {
            ++job->failed;
            continue;
        }
        GameRef game;
        game.title_id = remote_doc.header.title_id;
        game.game_id = remote_doc.header.game_id;
        game.name = remote_doc.header.name;
        game.executable_identity = remote_doc.header.hash;

        const std::string local_path = FindLocalFile(job->cheat_dir, game, {});
        std::string local_text;
        if (!local_path.empty()) {
            ReadTextFile(local_path, local_text);
        }
        ReviewModel review = BuildReview(game, remote, job->manifest.source_commit,
                                         remote_text, local_path, local_text, state);
        if (local_path.empty()) {
            review.local_path = SuggestedDestination(job->cheat_dir, remote,
                                                     remote_doc.header);
            if (!WriteTextFile(review.local_path, remote_text, error)) {
                ++job->failed;
                continue;
            }
            std::unordered_set<std::string> all;
            for (const Block &block : remote_doc.blocks) {
                all.insert(BlockIdentity(block));
            }
            UpdateStateAfterMerge(state, review, all, true);
            ++job->downloaded;
            continue;
        }

        std::unordered_set<std::string> safe;
        for (const ReviewItem &item : review.items) {
            if (item.has_remote &&
                (item.status == ItemStatus::New || item.status == ItemStatus::Updated)) {
                safe.insert(item.identity);
            }
        }
        if (safe.empty()) {
            const bool has_preserved = review.local_modified_count || review.conflict_count ||
                                       review.local_only_count;
            FileState &file = state.files[remote.path];
            file.remote_path = remote.path;
            file.local_file = Basename(local_path);
            file.remote_file_sha256 = remote.sha256;
            file.source_commit = job->manifest.source_commit;
            for (const Block &block : remote_doc.blocks) {
                const std::string identity = BlockIdentity(block);
                auto local_it = std::find_if(review.local_doc.blocks.begin(),
                                             review.local_doc.blocks.end(),
                    [&](const Block &local_block) {
                        return BlockIdentity(local_block) == identity &&
                               HashBlock(local_block) == HashBlock(block);
                    });
                if (local_it != review.local_doc.blocks.end()) {
                    file.block_hashes[identity] = HashBlock(block);
                }
            }
            if (has_preserved) {
                ++job->preserved;
            } else {
                ++job->unchanged;
            }
            continue;
        }

        const auto merged = MergeSelected(review.local_doc, review.remote_doc, safe);
        if (merged.text != local_text) {
            if (BackupFile(job->cheat_dir, local_path, error).empty() ||
                !WriteTextFile(local_path, merged.text, error)) {
                ++job->failed;
                continue;
            }
            UpdateStateAfterMerge(state, review, safe, false);
            ++job->updated;
        } else {
            ++job->unchanged;
        }
        if (review.local_modified_count || review.conflict_count || review.local_only_count) {
            ++job->preserved;
        }
    }

    if (!SaveState(job->cheat_dir, state, error)) {
        job->status = "Cheat files processed, but CheatDB state save failed: " + error;
        return;
    }
    job->success = true;
    std::ostringstream status;
    status << "Global CheatDB update complete. Downloaded " << job->downloaded
           << ", safely updated " << job->updated
           << ", unchanged " << job->unchanged
           << ", preserved local/conflicting files " << job->preserved
           << ", failed " << job->failed << ".";
    job->status = status.str();
}

void GlobalComplete(void *opaque)
{
    std::unique_ptr<GlobalJob> job(static_cast<GlobalJob *>(opaque));
    CheatDbManager *owner = job->owner;
    if (!owner || !owner->m) {
        return;
    }
    owner->m->global_in_flight = false;
    owner->m->status = job->status;
    if (job->success) {
        owner->m->state = LoadState(job->cheat_dir);
        owner->m->reload_current_requested = true;
    }
}

const char *ItemStatusLabel(ItemStatus status)
{
    switch (status) {
    case ItemStatus::Same: return "SAME";
    case ItemStatus::New: return "NEW";
    case ItemStatus::Updated: return "UPDATED";
    case ItemStatus::LocalModified: return "LOCAL MODIFIED";
    case ItemStatus::Conflict: return "CONFLICT";
    case ItemStatus::LocalOnly: return "LOCAL ONLY";
    }
    return "";
}

bool IsSafeUpdate(const ReviewItem &item)
{
    return item.has_remote &&
           (item.status == ItemStatus::New || item.status == ItemStatus::Updated);
}

void DrawReviewTree(ReviewModel &review)
{
    std::map<std::string, std::vector<size_t>> groups;
    for (size_t i = 0; i < review.items.size(); ++i) {
        groups[review.items[i].group_path].push_back(i);
    }
    ImGui::BeginChild("##CheatDbReviewTree", ImVec2(-1, 330), true);
    for (auto &entry : groups) {
        const std::string label = entry.first.empty() ? "Ungrouped" : entry.first;
        if (!ImGui::TreeNodeEx(label.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
            continue;
        }
        for (size_t index : entry.second) {
            ReviewItem &item = review.items[index];
            ImGui::PushID((int)index);
            if (item.has_remote && item.status != ItemStatus::Same) {
                ImGui::Checkbox("##select", &item.selected);
                ImGui::SameLine();
            } else {
                ImGui::Dummy(ImVec2(ImGui::GetFrameHeight(), 1));
                ImGui::SameLine();
            }
            ImGui::TextUnformatted(item.name.c_str());
            ImGui::SameLine();
            if (item.status == ItemStatus::New || item.status == ItemStatus::Updated) {
                ImGui::TextDisabled("[%s]", ItemStatusLabel(item.status));
            } else if (item.status == ItemStatus::LocalOnly) {
                ImGui::TextDisabled("[LOCAL ONLY - KEEP]");
            } else if (item.status == ItemStatus::LocalModified) {
                ImGui::TextDisabled("[LOCAL MODIFIED - KEEP unless selected]");
            } else if (item.status == ItemStatus::Conflict) {
                ImGui::TextDisabled("[CONFLICT - KEEP unless selected]");
            } else {
                ImGui::TextDisabled("[SAME]");
            }
            ImGui::PopID();
        }
        ImGui::TreePop();
    }
    ImGui::EndChild();
}

} // namespace

namespace {

void DrawCheatDbDetached()
{
    cheat_db_manager.DrawDetached();
}

} // namespace

CheatDbManager::CheatDbManager()
    : m(new Impl())
{
}

CheatDbManager::~CheatDbManager()
{
    delete m;
    m = nullptr;
}

void CheatDbManager::Register()
{
    m->state = LoadState(cheat_engine_window.CheatDirectoryPath());
    debug_tools_register_tick(340, []() { cheat_db_manager.Tick(); });
    debug_tools_register_cleanup(340, []() { cheat_db_manager.Cleanup(); });
    detached_tools_register({
        "xemu - Cheat Database",
        1040, 760,
        760, 540,
        &is_open,
        DrawCheatDbDetached,
        340,
        false,
    });
}

void CheatDbManager::Cleanup()
{
    is_open = false;
    m->review = ReviewModel{};
    m->requested_game = GameRef{};
}

void CheatDbManager::RequestManifestRefresh()
{
    if (m->manifest_checking || m->global_in_flight || m->apply_in_flight) {
        return;
    }
    m->manifest_checking = true;
    m->manifest_status = "Checking XEMU-CHEATDB manifest...";
    auto *job = new ManifestJob();
    job->owner = this;
    if (!debug_tools_queue_background_job(ManifestWork, job, ManifestComplete)) {
        delete job;
        m->manifest_checking = false;
        m->manifest_status = "Debug Tools background worker is unavailable.";
    }
}

void CheatDbManager::OpenForCurrentGame()
{
    GameRef game = CurrentGameRef();
    detached_tools_open_or_focus(&is_open);
    if (!game.valid()) {
        m->status = "No running XBE is available for CheatDB matching.";
        m->review = ReviewModel{};
        return;
    }
    OpenForGame(game);
}

void CheatDbManager::OpenForGame(const GameRef &game)
{
    detached_tools_open_or_focus(&is_open);
    m->global_view = false;
    m->requested_game = game;
    if (!game.valid()) {
        m->status = "Selected game does not have usable XBE metadata.";
        return;
    }
    if (!m->manifest_loaded) {
        if (!m->manifest_checking) {
            RequestManifestRefresh();
        }
        return;
    }
    if (m->review_checking || m->apply_in_flight || m->global_in_flight) {
        return;
    }

    m->review_checking = true;
    m->status = "Checking database cheats for " +
                (game.name.empty() ? game.game_id : game.name) + "...";
    auto *job = new ReviewJob();
    job->owner = this;
    job->manifest = m->manifest;
    job->game = game;
    job->cheat_dir = cheat_engine_window.CheatDirectoryPath();
    const GameRef current = CurrentGameRef();
    if (SameGameIdentity(current, game)) {
        job->preferred_local = cheat_engine_window.LoadedCheatPath();
    }
    if (!debug_tools_queue_background_job(ReviewWork, job, ReviewComplete)) {
        delete job;
        m->review_checking = false;
        m->status = "Debug Tools background worker is unavailable.";
    }
}

void CheatDbManager::OpenGlobal()
{
    detached_tools_open_or_focus(&is_open);
    m->global_view = true;
    m->requested_game = GameRef{};
    if (!m->manifest_loaded && !m->manifest_checking) {
        RequestManifestRefresh();
    }
}

ButtonState CheatDbManager::CurrentGameButtonState() const
{
    const GameRef game = CurrentGameRef();
    if (!game.valid()) {
        return ButtonState::NoneAvailable;
    }
    if (m->manifest_checking || m->review_checking) {
        return ButtonState::Checking;
    }
    if (!m->manifest_loaded) {
        return m->manifest_status.find("failed") != std::string::npos
                   ? ButtonState::Error
                   : ButtonState::Check;
    }
    const ManifestFile *remote = FastCandidate(m->manifest, game);
    if (!remote) {
        return ButtonState::NoneAvailable;
    }
    const std::string local = cheat_engine_window.LoadedCheatPath();
    if (local.empty() || !g_file_test(local.c_str(), G_FILE_TEST_IS_REGULAR)) {
        return ButtonState::Download;
    }
    if (m->review.valid && SameGameIdentity(m->review.game, game)) {
        if (m->review.new_count || m->review.updated_count) {
            return ButtonState::Update;
        }
        if (m->review.local_modified_count || m->review.conflict_count ||
            m->review.local_only_count) {
            return ButtonState::Manage;
        }
        return ButtonState::UpToDate;
    }
    const FileState *state = FindFileState(m->state, remote->path);
    if (!state) {
        return ButtonState::Update;
    }
    if (Upper(state->remote_file_sha256) != Upper(remote->sha256)) {
        return ButtonState::Update;
    }
    // Do not hash the local cheat file from the UI thread every frame. The
    // per-block review establishes the exact UP TO DATE state asynchronously;
    // when the recorded database revision matches but no review is cached,
    // expose Manage Cheats without touching the filesystem beyond existence.
    return ButtonState::Manage;
}

const char *CheatDbManager::CurrentGameButtonLabel() const
{
    switch (CurrentGameButtonState()) {
    case ButtonState::Check: return "Check Cheats";
    case ButtonState::Checking: return "Checking Cheats...";
    case ButtonState::NoneAvailable: return "No Database Cheats";
    case ButtonState::Download: return "Download Cheats";
    case ButtonState::Update: return "Update Cheats";
    case ButtonState::Manage: return "Manage Cheats";
    case ButtonState::UpToDate: return "Cheats Up To Date";
    case ButtonState::Error: return "Retry CheatDB";
    }
    return "CheatDB";
}

std::string CheatDbManager::GameLibraryButtonLabel(const GameRef &game) const
{
    if (!game.valid()) {
        return "CHEATS";
    }
    if (!m->manifest_loaded) {
        return m->manifest_checking ? "CHECKING CHEATS..." : "CHEATS";
    }
    const ManifestFile *remote = FastCandidate(m->manifest, game);
    if (!remote) {
        return "NO DATABASE CHEATS";
    }
    const FileState *state = FindFileState(m->state, remote->path);
    if (!state || state->local_file.empty() ||
        !g_file_test(JoinFile(cheat_engine_window.CheatDirectoryPath(),
                             state->local_file).c_str(), G_FILE_TEST_IS_REGULAR)) {
        return "DOWNLOAD CHEATS";
    }
    return Upper(state->remote_file_sha256) == Upper(remote->sha256)
               ? "MANAGE CHEATS"
               : "UPDATE CHEATS";
}

std::string CheatDbManager::GameStatusText(const GameRef &game) const
{
    if (!m->manifest_loaded) {
        return "CheatDB not checked";
    }
    const ManifestFile *remote = FastCandidate(m->manifest, game);
    if (!remote) {
        return "No database cheats";
    }
    const FileState *state = FindFileState(m->state, remote->path);
    if (!state) {
        return "Database cheats available";
    }
    return Upper(state->remote_file_sha256) == Upper(remote->sha256)
               ? "Database revision checked"
               : "Cheat update available";
}

void CheatDbManager::Tick()
{
    // Guest/Cheat Engine state changes stay on the synchronized Debug Tools
    // tick. The CheatDB ImGui frame itself is built by the detached host in
    // xemu_hud_build_detached_frames_unlocked().
    if (m->reload_current_requested) {
        m->reload_current_requested = false;
        cheat_engine_window.ReloadCurrentCheatFile();
    }
}

void CheatDbManager::DrawDetached()
{
    if (!is_open) {
        return;
    }

    ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Always);
    const ImGuiWindowFlags window_flags =
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoSavedSettings;
    if (!ImGui::Begin("##DetachedCheatDatabase", nullptr, window_flags)) {
        ImGui::End();
        return;
    }

    ImGui::TextUnformatted("XEMU-CHEATDB");
    ImGui::SameLine();
    ImGui::TextDisabled("  github.com/SkillerCMP/XEMU-CHEATDB");
    if (!m->manifest_status.empty()) {
        ImGui::TextDisabled("%s", m->manifest_status.c_str());
    }
    if (!m->status.empty()) {
        ImGui::TextWrapped("%s", m->status.c_str());
    }

    if (ImGui::Button(m->manifest_checking ? "Checking Database..." : "Check Database")) {
        RequestManifestRefresh();
    }
    ImGui::SameLine();
    if (ImGui::Button("Current Game")) {
        OpenForCurrentGame();
    }
    ImGui::SameLine();
    if (ImGui::Button("Global Download / Update")) {
        OpenGlobal();
    }
    ImGui::Separator();

    const bool busy = m->manifest_checking || m->review_checking ||
                      m->apply_in_flight || m->global_in_flight;
    if (busy) {
        ImGui::TextDisabled("Background CheatDB operation in progress...");
    }

    if (m->global_view) {
        ImGui::TextWrapped(
            "Global safe update downloads missing CMP .txt files and merges only NEW or "
            "database-owned UPDATED codes. Local-only codes, locally edited codes, and "
            "conflicts are preserved.");
        if (m->manifest_loaded) {
            size_t cheat_files = 0;
            for (const ManifestFile &file : m->manifest.files) {
                if (EndsWithTxt(file.relative_path) && !IsReservedCheatPath(file.relative_path)) {
                    ++cheat_files;
                }
            }
            ImGui::Text("Database cheat files: %zu", cheat_files);
            ImGui::Text("Source commit: %s", m->manifest.source_commit.c_str());
            if (busy) {
                ImGui::BeginDisabled();
            }
            if (ImGui::Button("Download Missing / Update All Safely", ImVec2(300, 38))) {
                auto *job = new GlobalJob();
                job->owner = this;
                job->manifest = m->manifest;
                job->cheat_dir = cheat_engine_window.CheatDirectoryPath();
                m->global_in_flight = true;
                m->status = "Downloading and safely merging the CheatDB...";
                if (!debug_tools_queue_background_job(GlobalWork, job, GlobalComplete)) {
                    delete job;
                    m->global_in_flight = false;
                    m->status = "Debug Tools background worker is unavailable.";
                }
            }
            if (busy) {
                ImGui::EndDisabled();
            }
            ImGui::Spacing();
            ImGui::TextDisabled(
                "A timestamped copy is written under Cheats/Backup before any existing local file is changed.");
        } else {
            ImGui::TextDisabled("Check Database first to enable the global updater.");
        }
        ImGui::End();
        return;
    }

    if (m->review_checking) {
        ImGui::TextDisabled("Downloading the matching database file and comparing CMP code blocks...");
        ImGui::End();
        return;
    }
    if (!m->review.valid) {
        if (m->requested_game.valid()) {
            ImGui::Text("Target: %s (%s)",
                        m->requested_game.name.empty() ? "Selected Game" : m->requested_game.name.c_str(),
                        m->requested_game.game_id.c_str());
            if (m->manifest_loaded && !busy && ImGui::Button("Check This Game")) {
                OpenForGame(m->requested_game);
            }
        } else {
            ImGui::TextDisabled("Choose Current Game or open this window from the Game Library.");
        }
        ImGui::End();
        return;
    }

    ReviewModel &review = m->review;
    ImGui::Text("Game: %s", review.game.name.empty() ? review.game.game_id.c_str()
                                                      : review.game.name.c_str());
    ImGui::Text("Game ID: %s   Title ID: %08X", review.game.game_id.c_str(),
                review.game.title_id);
    ImGui::Text("Database: %s", review.remote_file.relative_path.c_str());
    ImGui::Text("Local: %s", review.local_path.empty() ? "<not installed>"
                                                        : review.local_path.c_str());
    ImGui::TextDisabled(
        "New: %zu   Updated: %zu   Local Modified: %zu   Conflicts: %zu   Local Only: %zu   Same: %zu",
        review.new_count, review.updated_count, review.local_modified_count,
        review.conflict_count, review.local_only_count, review.same_count);
    ImGui::Separator();

    DrawReviewTree(review);

    if (busy) {
        ImGui::BeginDisabled();
    }
    if (review.local_path.empty()) {
        if (ImGui::Button("Download Cheats", ImVec2(190, 38))) {
            auto *job = new ApplyJob();
            job->owner = this;
            job->review = review;
            job->cheat_dir = cheat_engine_window.CheatDirectoryPath();
            m->apply_in_flight = true;
            if (!debug_tools_queue_background_job(ApplyWork, job, ApplyComplete)) {
                delete job;
                m->apply_in_flight = false;
                m->status = "Debug Tools background worker is unavailable.";
            }
        }
    } else {
        if (ImGui::Button("Select New / Updated")) {
            for (ReviewItem &item : review.items) {
                item.selected = IsSafeUpdate(item);
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Select All Database Changes")) {
            for (ReviewItem &item : review.items) {
                item.selected = item.has_remote && item.status != ItemStatus::Same;
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Selection")) {
            for (ReviewItem &item : review.items) {
                item.selected = false;
            }
        }

        if (ImGui::Button("Merge Selected", ImVec2(180, 38))) {
            auto *job = new ApplyJob();
            job->owner = this;
            job->review = review;
            job->cheat_dir = cheat_engine_window.CheatDirectoryPath();
            for (const ReviewItem &item : review.items) {
                if (item.has_remote && item.selected) {
                    job->selected.insert(item.identity);
                }
            }
            m->apply_in_flight = true;
            if (!debug_tools_queue_background_job(ApplyWork, job, ApplyComplete)) {
                delete job;
                m->apply_in_flight = false;
                m->status = "Debug Tools background worker is unavailable.";
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Update All Safely", ImVec2(180, 38))) {
            auto *job = new ApplyJob();
            job->owner = this;
            job->review = review;
            job->cheat_dir = cheat_engine_window.CheatDirectoryPath();
            job->safe_only = true;
            m->apply_in_flight = true;
            if (!debug_tools_queue_background_job(ApplyWork, job, ApplyComplete)) {
                delete job;
                m->apply_in_flight = false;
                m->status = "Debug Tools background worker is unavailable.";
            }
        }
    }
    if (busy) {
        ImGui::EndDisabled();
    }

    ImGui::Spacing();
    ImGui::TextDisabled(
        "LOCAL ONLY is never deleted. LOCAL MODIFIED and CONFLICT are preserved unless you explicitly select them. Existing files are backed up before merge.");
    ImGui::End();
}

} // namespace XemuCheatDb
