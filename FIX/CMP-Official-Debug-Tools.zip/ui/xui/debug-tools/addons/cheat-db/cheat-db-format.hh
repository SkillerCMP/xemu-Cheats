#pragma once

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace XemuCheatDbFormat {

struct Header {
    std::string hash;
    std::string game_id;
    std::string name;
    uint32_t title_id = 0;
    bool title_id_valid = false;
};

struct Block {
    std::string group_path;
    std::string name;
    uint32_t ordinal = 0;
    size_t start_line = 0;
    size_t end_line = 0;
    std::vector<std::string> lines;
};

struct Group {
    std::string path;
    std::string name;
    std::string parent_path;
    size_t open_line = 0;
    size_t close_line = static_cast<size_t>(-1);
};

struct Document {
    Header header;
    std::vector<std::string> lines;
    std::vector<Block> blocks;
    std::vector<Group> groups;
    std::string newline = "\n";
    bool final_newline = false;
};

enum class BlockCompareStatus {
    Same,
    New,
    Updated,
    LocalModified,
    Conflict,
    LocalOnly,
};

inline BlockCompareStatus ClassifyRemoteBlock(bool has_local,
                                               const std::string &local_hash,
                                               const std::string &remote_hash,
                                               const std::string &previous_db_hash)
{
    if (!has_local) {
        return BlockCompareStatus::New;
    }
    if (local_hash == remote_hash) {
        return BlockCompareStatus::Same;
    }
    if (!previous_db_hash.empty()) {
        if (local_hash == previous_db_hash && remote_hash != previous_db_hash) {
            return BlockCompareStatus::Updated;
        }
        if (local_hash != previous_db_hash && remote_hash == previous_db_hash) {
            return BlockCompareStatus::LocalModified;
        }
    }
    return BlockCompareStatus::Conflict;
}

inline std::string Trim(const std::string &s)
{
    size_t first = 0;
    while (first < s.size() && std::isspace((unsigned char)s[first])) {
        ++first;
    }
    size_t last = s.size();
    while (last > first && std::isspace((unsigned char)s[last - 1])) {
        --last;
    }
    return s.substr(first, last - first);
}

inline std::string Upper(std::string s)
{
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return (char)std::toupper(c);
    });
    return s;
}

inline bool ParseGameId(const std::string &text, uint32_t &title_id)
{
    const std::string value = Upper(Trim(text));
    if (value.size() == 8) {
        char *end = nullptr;
        unsigned long parsed = std::strtoul(value.c_str(), &end, 16);
        if (end && *end == '\0' && parsed <= 0xFFFFFFFFul) {
            title_id = (uint32_t)parsed;
            return true;
        }
        return false;
    }
    if (value.size() == 6 &&
        std::isxdigit((unsigned char)value[2]) &&
        std::isxdigit((unsigned char)value[3]) &&
        std::isxdigit((unsigned char)value[4]) &&
        std::isxdigit((unsigned char)value[5])) {
        char *end = nullptr;
        unsigned long game = std::strtoul(value.c_str() + 2, &end, 16);
        if (!end || *end != '\0' || game > 0xFFFFul) {
            return false;
        }
        title_id = ((uint32_t)(uint8_t)value[0] << 24) |
                   ((uint32_t)(uint8_t)value[1] << 16) |
                   (uint32_t)game;
        return true;
    }
    return false;
}

inline std::vector<std::string> SplitLines(const std::string &source,
                                           std::string &newline,
                                           bool &final_newline)
{
    newline = source.find("\r\n") != std::string::npos ? "\r\n" : "\n";
    final_newline = !source.empty() && source.back() == '\n';
    std::vector<std::string> lines;
    size_t pos = 0;
    while (pos < source.size()) {
        size_t end = source.find('\n', pos);
        if (end == std::string::npos) {
            end = source.size();
        }
        size_t content_end = end;
        if (content_end > pos && source[content_end - 1] == '\r') {
            --content_end;
        }
        lines.emplace_back(source.substr(pos, content_end - pos));
        if (end == source.size()) {
            pos = end;
        } else {
            pos = end + 1;
        }
    }
    return lines;
}

inline std::string JoinLines(const std::vector<std::string> &lines,
                             const std::string &newline,
                             bool final_newline)
{
    std::string out;
    for (size_t i = 0; i < lines.size(); ++i) {
        if (i != 0) {
            out += newline;
        }
        out += lines[i];
    }
    if (final_newline && !lines.empty()) {
        out += newline;
    }
    return out;
}

inline std::string JoinPath(const std::vector<std::string> &parts)
{
    std::string path;
    for (const auto &part : parts) {
        if (!path.empty()) {
            path += "/";
        }
        path += part;
    }
    return path;
}

inline std::vector<std::string> SplitPath(const std::string &path)
{
    std::vector<std::string> out;
    size_t pos = 0;
    while (pos <= path.size()) {
        size_t slash = path.find('/', pos);
        if (slash == std::string::npos) {
            slash = path.size();
        }
        std::string part = path.substr(pos, slash - pos);
        if (!part.empty()) {
            out.push_back(part);
        }
        if (slash == path.size()) {
            break;
        }
        pos = slash + 1;
    }
    return out;
}

inline std::string BlockIdentity(const Block &block)
{
    return block.group_path + "\n" + block.name + "\n" +
           std::to_string(block.ordinal);
}

inline std::string BlockText(const Block &block)
{
    return JoinLines(block.lines, "\n", false);
}

inline Header ParseHeader(const std::vector<std::string> &lines)
{
    Header out;
    int inspected = 0;
    for (const std::string &line : lines) {
        std::string t = Trim(line);
        if (t.empty() || t[0] == ';') {
            continue;
        }
        if (++inspected > 64) {
            break;
        }
        if (t[0] != '^') {
            if (t[0] == '+' || t[0] == '!' || t[0] == '$' ||
                std::isxdigit((unsigned char)t[0])) {
                break;
            }
            continue;
        }
        size_t eq = t.find('=');
        if (eq == std::string::npos) {
            continue;
        }
        const std::string lhs = Upper(Trim(t.substr(0, eq)));
        const std::string rhs = Trim(t.substr(eq + 1));
        const size_t colon = rhs.find(':');
        const std::string key = colon == std::string::npos
                                    ? std::string()
                                    : Upper(Trim(rhs.substr(0, colon)));
        const std::string value = colon == std::string::npos
                                      ? rhs
                                      : Trim(rhs.substr(colon + 1));
        if (lhs == "^1" && (key.empty() || key == "HASH")) {
            out.hash = Upper(value);
        } else if (lhs == "^2" &&
                   (key.empty() || key == "GAMEID" || key == "GAME ID")) {
            out.game_id = Upper(value);
            out.title_id_valid = ParseGameId(value, out.title_id);
        } else if (lhs == "^3" && (key.empty() || key == "NAME")) {
            out.name = value;
        }
    }
    return out;
}

inline Document ParseDocument(const std::string &source)
{
    Document doc;
    doc.lines = SplitLines(source, doc.newline, doc.final_newline);
    doc.header = ParseHeader(doc.lines);

    std::vector<std::string> group_names;
    std::vector<size_t> group_indices;
    std::unordered_map<std::string, uint32_t> ordinals;
    size_t active_block = static_cast<size_t>(-1);

    auto finish_block = [&](size_t line_index) {
        if (active_block == static_cast<size_t>(-1)) {
            return;
        }
        Block &block = doc.blocks[active_block];
        block.end_line = line_index;
        block.lines.assign(doc.lines.begin() + block.start_line,
                           doc.lines.begin() + block.end_line);
        active_block = static_cast<size_t>(-1);
    };

    for (size_t i = 0; i < doc.lines.size(); ++i) {
        const std::string t = Trim(doc.lines[i]);
        if (t.empty() || t[0] == ';' || t[0] == '^') {
            continue;
        }

        if (t.rfind("!!", 0) == 0) {
            finish_block(i);
            if (!group_indices.empty()) {
                doc.groups[group_indices.back()].close_line = i;
                group_indices.pop_back();
                group_names.pop_back();
            }
            continue;
        }

        if (t[0] == '!') {
            finish_block(i);
            std::string name = Trim(t.substr(1));
            if (!name.empty() && name.back() == ':') {
                name.pop_back();
                name = Trim(name);
            }
            if (!name.empty()) {
                Group group;
                group.name = name;
                group.parent_path = JoinPath(group_names);
                group_names.push_back(name);
                group.path = JoinPath(group_names);
                group.open_line = i;
                doc.groups.push_back(group);
                group_indices.push_back(doc.groups.size() - 1);
            }
            continue;
        }

        if (t[0] == '+') {
            finish_block(i);
            std::string spec = Trim(t.substr(1));
            const std::string preentry = ":PREENTRY:";
            if (Upper(spec).rfind(preentry, 0) == 0) {
                spec = Trim(spec.substr(preentry.size()));
            }
            size_t open = spec.find('{');
            size_t close = spec.rfind('}');
            std::string name = (open != std::string::npos &&
                                close != std::string::npos && close > open)
                                   ? Trim(spec.substr(0, open))
                                   : Trim(spec);
            if (name.empty()) {
                name = "RAW Codes";
            }
            Block block;
            block.group_path = JoinPath(group_names);
            block.name = name;
            const std::string base = block.group_path + "\n" + block.name;
            block.ordinal = ordinals[base]++;
            block.start_line = i;
            block.end_line = doc.lines.size();
            doc.blocks.push_back(std::move(block));
            active_block = doc.blocks.size() - 1;
        }
    }
    finish_block(doc.lines.size());

    return doc;
}

struct MergeResult {
    std::string text;
    size_t replaced = 0;
    size_t added = 0;
};

inline MergeResult MergeSelected(const Document &local,
                                 const Document &remote,
                                 const std::unordered_set<std::string> &selected)
{
    struct Operation {
        size_t pos = 0;
        size_t erase_count = 0;
        std::vector<std::string> insert;
    };

    std::unordered_map<std::string, const Block *> local_blocks;
    for (const Block &block : local.blocks) {
        local_blocks.emplace(BlockIdentity(block), &block);
    }
    std::unordered_map<std::string, const Group *> local_groups;
    for (const Group &group : local.groups) {
        local_groups.emplace(group.path, &group);
    }

    std::vector<Operation> operations;
    std::unordered_map<std::string, std::vector<const Block *>> additions;
    MergeResult result;

    for (const Block &remote_block : remote.blocks) {
        const std::string identity = BlockIdentity(remote_block);
        if (selected.find(identity) == selected.end()) {
            continue;
        }
        auto it = local_blocks.find(identity);
        if (it != local_blocks.end()) {
            const Block &local_block = *it->second;
            Operation op;
            op.pos = local_block.start_line;
            op.erase_count = local_block.end_line - local_block.start_line;
            op.insert = remote_block.lines;
            operations.push_back(std::move(op));
            ++result.replaced;
        } else {
            additions[remote_block.group_path].push_back(&remote_block);
            ++result.added;
        }
    }

    for (const auto &entry : additions) {
        const std::string &target_path = entry.first;
        std::vector<std::string> payload;
        for (const Block *block : entry.second) {
            if (!payload.empty() && !payload.back().empty()) {
                payload.push_back("");
            }
            payload.insert(payload.end(), block->lines.begin(), block->lines.end());
        }

        auto exact_group = local_groups.find(target_path);
        if (target_path.empty()) {
            if (!payload.empty() && !local.lines.empty() &&
                !Trim(local.lines.back()).empty()) {
                payload.insert(payload.begin(), "");
            }
            operations.push_back(Operation{local.lines.size(), 0, std::move(payload)});
            continue;
        }
        if (exact_group != local_groups.end() &&
            exact_group->second->close_line != static_cast<size_t>(-1)) {
            const size_t close_line = exact_group->second->close_line;
            if (!payload.empty() && close_line > 0 &&
                !Trim(local.lines[close_line - 1]).empty()) {
                payload.insert(payload.begin(), "");
            }
            operations.push_back(Operation{close_line, 0, std::move(payload)});
            continue;
        }

        const std::vector<std::string> parts = SplitPath(target_path);
        size_t existing_depth = 0;
        const Group *parent = nullptr;
        std::vector<std::string> probe;
        for (size_t depth = 0; depth < parts.size(); ++depth) {
            probe.push_back(parts[depth]);
            auto pit = local_groups.find(JoinPath(probe));
            if (pit == local_groups.end()) {
                break;
            }
            parent = pit->second;
            existing_depth = depth + 1;
        }

        std::vector<std::string> wrapped;
        for (size_t depth = existing_depth; depth < parts.size(); ++depth) {
            wrapped.push_back("!" + parts[depth] + ":");
        }
        wrapped.insert(wrapped.end(), payload.begin(), payload.end());
        for (size_t depth = existing_depth; depth < parts.size(); ++depth) {
            wrapped.push_back("!!");
        }
        size_t pos = local.lines.size();
        if (parent && parent->close_line != static_cast<size_t>(-1)) {
            pos = parent->close_line;
        }
        operations.push_back(Operation{pos, 0, std::move(wrapped)});
    }

    std::sort(operations.begin(), operations.end(),
              [](const Operation &a, const Operation &b) {
                  if (a.pos != b.pos) {
                      return a.pos > b.pos;
                  }
                  return a.erase_count > b.erase_count;
              });

    std::vector<std::string> lines = local.lines;
    for (const Operation &op : operations) {
        const size_t pos = std::min(op.pos, lines.size());
        const size_t erase_count = std::min(op.erase_count, lines.size() - pos);
        lines.erase(lines.begin() + pos, lines.begin() + pos + erase_count);
        lines.insert(lines.begin() + pos, op.insert.begin(), op.insert.end());
    }

    result.text = JoinLines(lines, local.newline, local.final_newline || !lines.empty());
    return result;
}

} // namespace XemuCheatDbFormat
