#pragma once

#include <cstdint>
#include <string>

namespace XemuCheatDb {

struct GameRef {
    uint32_t title_id = 0;
    std::string game_id;
    std::string name;
    std::string executable_identity;

    bool valid() const { return title_id != 0; }
};

enum class ButtonState {
    Check,
    Checking,
    NoneAvailable,
    Download,
    Update,
    Manage,
    UpToDate,
    Error,
};

class CheatDbManager {
public:
    CheatDbManager();
    ~CheatDbManager();

    void Register();
    void Tick();
    void DrawDetached();
    void Cleanup();

    void OpenForCurrentGame();
    void OpenForGame(const GameRef &game);
    void OpenGlobal();
    void RequestManifestRefresh();

    ButtonState CurrentGameButtonState() const;
    const char *CurrentGameButtonLabel() const;
    std::string GameLibraryButtonLabel(const GameRef &game) const;
    std::string GameStatusText(const GameRef &game) const;

    bool is_open = false;

    // Internal state is exposed only so the C-style background-worker callbacks
    // in cheat-db.cc can complete on the UI thread without global side tables.
    struct Impl;
    Impl *m = nullptr;
};

extern CheatDbManager cheat_db_manager;

} // namespace XemuCheatDb
