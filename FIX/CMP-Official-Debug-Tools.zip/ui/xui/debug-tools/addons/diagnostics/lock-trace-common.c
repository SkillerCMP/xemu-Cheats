/* Info: Shared lock-trace core preserves each recorder's disabled-state policy. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/timer.h"
#include "qemu/thread.h"
#include "hw/core/cpu.h"

#include "lock-trace-common.h"
#include "diagnostics-trace-buffer.h"
#include "diagnostics-cpu-context.h"

#define LOCK_TRACE_NO_OWNER 0

typedef struct XemuDebugToolsLockTraceSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsLockTraceEvent event;
} XemuDebugToolsLockTraceSlot;

typedef struct XemuDebugToolsLockTraceAttemptTls {
    int active;
    uint64_t attempt_host_ns;
    int32_t thread_id;
    int32_t cpu_index;
    uint64_t guest_pc;
    uint32_t guest_pc_valid;
    int32_t owner_thread_id;
    int32_t owner_cpu_index;
    uint64_t owner_acquire_host_ns;
    uint64_t owner_guest_pc_start;
    uint32_t owner_guest_pc_start_valid;
    const char *owner_caller_file;
    int32_t owner_caller_line;
    uint32_t caller_context;
    uint32_t owner_context;
    uint32_t owner_stage_at_attempt;
    uint64_t owner_stage_elapsed_at_attempt_ns;
} XemuDebugToolsLockTraceAttemptTls;

typedef struct XemuDebugToolsLockTraceState {
    int enabled;
    uint64_t total_events;
    int32_t owner_thread_id;
    int32_t owner_cpu_index;
    uint64_t owner_acquire_host_ns;
    uint64_t owner_guest_pc_start;
    uint32_t owner_guest_pc_start_valid;
    const char *owner_caller_file;
    int32_t owner_caller_line;
    uint32_t owner_context;
    uint32_t owner_stage;
    uint64_t owner_stage_start_host_ns;
    uint32_t owner_longest_stage;
    uint64_t owner_longest_stage_ns;
    uint32_t buffer_multiplier;
    XemuDebugToolsLockTraceSlot
        *slots[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsLockTraceState;

typedef struct XemuDebugToolsLockTracePolicy {
    int clear_full_attempt_when_disabled;
    int observe_acquire_when_disabled;
    int clear_owner_when_disabled;
} XemuDebugToolsLockTracePolicy;

static XemuDebugToolsLockTraceState lock_trace[XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT] = {
    [XEMU_DEBUG_TOOLS_LOCK_TRACE_BQL] = { .buffer_multiplier = 1 },
    [XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP] = { .buffer_multiplier = 1 },
};

/* Info: BQL keeps owner bookkeeping across trace toggles; main-loop tracing does not. */
static const XemuDebugToolsLockTracePolicy
    lock_trace_policy[XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT] = {
        [XEMU_DEBUG_TOOLS_LOCK_TRACE_BQL] = {
            .clear_full_attempt_when_disabled = 1,
            .observe_acquire_when_disabled = 1,
            .clear_owner_when_disabled = 1,
        },
        [XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP] = {
            .clear_full_attempt_when_disabled = 0,
            .observe_acquire_when_disabled = 0,
            .clear_owner_when_disabled = 0,
        },
    };

static __thread XemuDebugToolsLockTraceAttemptTls
    lock_trace_attempt_tls[XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT];
static __thread uint32_t
    lock_trace_next_context_tls[XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT];

static XemuDebugToolsLockTraceState *lock_trace_state(
    XemuDebugToolsLockTraceKind kind)
{
    g_assert(kind >= 0 && kind < XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT);
    return &lock_trace[kind];
}

static const XemuDebugToolsLockTracePolicy *lock_trace_get_policy(
    XemuDebugToolsLockTraceKind kind)
{
    g_assert(kind >= 0 && kind < XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT);
    return &lock_trace_policy[kind];
}

static void lock_trace_copy_file(
    char dst[XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX], const char *src)
{
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    g_strlcpy(dst, src, XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX);
}

static void lock_trace_finish_owner_stage(
    XemuDebugToolsLockTraceState *trace, uint64_t now)
{
    uint32_t stage = qatomic_read(&trace->owner_stage);
    uint64_t start = qatomic_read(&trace->owner_stage_start_host_ns);

    if (stage != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE && start != 0 && now >= start) {
        uint64_t duration = now - start;
        if (duration > qatomic_read(&trace->owner_longest_stage_ns)) {
            qatomic_set(&trace->owner_longest_stage_ns, duration);
            qatomic_set(&trace->owner_longest_stage, stage);
        }
    }
    qatomic_set(&trace->owner_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
    qatomic_set(&trace->owner_stage_start_host_ns, 0);
}

void xemu_debug_tools_lock_trace_core_set_next_context(
    XemuDebugToolsLockTraceKind kind, uint32_t context)
{
    lock_trace_state(kind);
    lock_trace_next_context_tls[kind] = context;
}

void xemu_debug_tools_lock_trace_core_owner_stage_begin(
    XemuDebugToolsLockTraceKind kind, uint32_t stage)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    int32_t tid;
    uint64_t now;

    if (!qatomic_read(&trace->enabled) ||
        stage == XEMU_DEBUG_TOOLS_BQL_STAGE_NONE) {
        return;
    }
    tid = qemu_get_thread_id();
    if (qatomic_read(&trace->owner_thread_id) != tid) {
        return;
    }
    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    lock_trace_finish_owner_stage(trace, now);
    qatomic_set(&trace->owner_stage_start_host_ns, now);
    smp_wmb();
    qatomic_set(&trace->owner_stage, stage);
}

void xemu_debug_tools_lock_trace_core_owner_stage_end(
    XemuDebugToolsLockTraceKind kind)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    int32_t tid;

    if (!qatomic_read(&trace->enabled)) {
        return;
    }
    tid = qemu_get_thread_id();
    if (qatomic_read(&trace->owner_thread_id) != tid) {
        return;
    }
    lock_trace_finish_owner_stage(trace, qemu_clock_get_ns(QEMU_CLOCK_HOST));
}

static void lock_trace_append(XemuDebugToolsLockTraceState *trace,
                              XemuDebugToolsLockTraceEvent *event)
{
    uint64_t sequence;
    XemuDebugToolsLockTraceSlot *slot;
    size_t trace_capacity;

    sequence = qatomic_fetch_inc(&trace->total_events);
    {
        uint32_t multiplier = qatomic_read(&trace->buffer_multiplier);
        trace_capacity = xemu_debug_tools_trace_buffer_capacity(
            XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY, multiplier ? multiplier : 1);
    }
    slot = &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        trace->slots, XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY,
        sequence % trace_capacity);
    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}

void xemu_debug_tools_lock_trace_core_lock_attempt(
    XemuDebugToolsLockTraceKind kind, const char *file, int line)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    const XemuDebugToolsLockTracePolicy *policy = lock_trace_get_policy(kind);
    XemuDebugToolsLockTraceAttemptTls *tls = &lock_trace_attempt_tls[kind];
    uint32_t caller_context = lock_trace_next_context_tls[kind];
    uint64_t now;
    uint64_t owner_acquire;
    uint64_t owner_stage_start;

    (void)file;
    (void)line;
    lock_trace_next_context_tls[kind] = XEMU_DEBUG_TOOLS_BQL_CONTEXT_NONE;
    if (policy->clear_full_attempt_when_disabled) {
        memset(tls, 0, sizeof(*tls));
        tls->caller_context = caller_context;
    } else {
        tls->active = 0;
    }
    if (!qatomic_read(&trace->enabled)) {
        return;
    }

    if (!policy->clear_full_attempt_when_disabled) {
        memset(tls, 0, sizeof(*tls));
        tls->caller_context = caller_context;
    }
    tls->active = 1;
    tls->thread_id = qemu_get_thread_id();
    tls->attempt_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    xemu_debug_tools_diagnostics_current_cpu_context(
        &tls->cpu_index, &tls->guest_pc, &tls->guest_pc_valid);

    tls->owner_thread_id = qatomic_read(&trace->owner_thread_id);
    tls->owner_cpu_index = qatomic_read(&trace->owner_cpu_index);
    tls->owner_acquire_host_ns = qatomic_read(&trace->owner_acquire_host_ns);
    tls->owner_guest_pc_start = qatomic_read(&trace->owner_guest_pc_start);
    tls->owner_guest_pc_start_valid =
        qatomic_read(&trace->owner_guest_pc_start_valid);
    tls->owner_caller_file = qatomic_read(&trace->owner_caller_file);
    tls->owner_caller_line = qatomic_read(&trace->owner_caller_line);
    tls->owner_context = qatomic_read(&trace->owner_context);
    tls->owner_stage_at_attempt = qatomic_read(&trace->owner_stage);

    /* Info: Ignore stale future owner timestamps in diagnostic duration math. */
    now = tls->attempt_host_ns;
    owner_acquire = tls->owner_acquire_host_ns;
    if (owner_acquire > now) {
        tls->owner_acquire_host_ns = 0;
    }
    owner_stage_start = qatomic_read(&trace->owner_stage_start_host_ns);
    if (tls->owner_stage_at_attempt != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE &&
        owner_stage_start != 0 && owner_stage_start <= now) {
        tls->owner_stage_elapsed_at_attempt_ns = now - owner_stage_start;
    }
}

void xemu_debug_tools_lock_trace_core_lock_acquired(
    XemuDebugToolsLockTraceKind kind, const char *file, int line)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    const XemuDebugToolsLockTracePolicy *policy = lock_trace_get_policy(kind);
    XemuDebugToolsLockTraceAttemptTls *tls = &lock_trace_attempt_tls[kind];
    XemuDebugToolsLockTraceEvent event = { 0 };
    uint64_t now;
    uint64_t wait_ns = 0;
    int32_t cpu_index;
    uint64_t guest_pc;
    uint32_t guest_pc_valid;
    int32_t tid;

    if (!qatomic_read(&trace->enabled) &&
        !policy->observe_acquire_when_disabled) {
        tls->active = 0;
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    tid = qemu_get_thread_id();
    if (tls->active && now >= tls->attempt_host_ns) {
        wait_ns = now - tls->attempt_host_ns;
    }

    if (qatomic_read(&trace->enabled) && tls->active &&
        wait_ns >= XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS) {
        event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
        event.host_ns = now;
        event.wait_ns = wait_ns;
        event.thread_id = tls->thread_id;
        event.cpu_index = tls->cpu_index;
        event.guest_pc_start = tls->guest_pc;
        event.guest_pc_start_valid = tls->guest_pc_valid;
        event.owner_thread_id = tls->owner_thread_id;
        event.owner_cpu_index = tls->owner_cpu_index;
        event.owner_acquire_host_ns = tls->owner_acquire_host_ns;
        event.owner_guest_pc_start = tls->owner_guest_pc_start;
        event.owner_guest_pc_start_valid = tls->owner_guest_pc_start_valid;
        event.caller_context = tls->caller_context;
        event.owner_context = tls->owner_context;
        event.owner_stage_at_attempt = tls->owner_stage_at_attempt;
        event.owner_stage_elapsed_at_attempt_ns =
            tls->owner_stage_elapsed_at_attempt_ns;
        if (tls->owner_acquire_host_ns != 0 &&
            tls->attempt_host_ns >= tls->owner_acquire_host_ns) {
            event.owner_held_at_attempt_ns =
                tls->attempt_host_ns - tls->owner_acquire_host_ns;
        }
        event.caller_line = line;
        event.owner_caller_line = tls->owner_caller_line;
        event.event_type = XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_WAIT;
        lock_trace_copy_file(event.caller_file, file);
        lock_trace_copy_file(event.owner_caller_file, tls->owner_caller_file);
        lock_trace_append(trace, &event);
    }

    xemu_debug_tools_diagnostics_current_cpu_context(
        &cpu_index, &guest_pc, &guest_pc_valid);
    qatomic_set(&trace->owner_cpu_index, cpu_index);
    qatomic_set(&trace->owner_acquire_host_ns, now);
    qatomic_set(&trace->owner_guest_pc_start, guest_pc);
    qatomic_set(&trace->owner_guest_pc_start_valid, guest_pc_valid);
    qatomic_set(&trace->owner_caller_file, file);
    qatomic_set(&trace->owner_caller_line, line);
    qatomic_set(&trace->owner_context, tls->caller_context);
    qatomic_set(&trace->owner_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
    qatomic_set(&trace->owner_stage_start_host_ns, 0);
    qatomic_set(&trace->owner_longest_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
    qatomic_set(&trace->owner_longest_stage_ns, 0);
    /* Info: Publish owner TID last so readers first observe complete metadata. */
    smp_wmb();
    qatomic_set(&trace->owner_thread_id, tid);
    memset(tls, 0, sizeof(*tls));
}

void xemu_debug_tools_lock_trace_core_unlock_begin(
    XemuDebugToolsLockTraceKind kind)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    XemuDebugToolsLockTraceEvent event = { 0 };
    int32_t tid;
    int32_t owner_tid;
    uint64_t acquired;
    uint64_t now;
    uint64_t held_ns;
    int32_t cpu_index;
    uint64_t guest_pc_end;
    uint32_t guest_pc_end_valid;

    if (!qatomic_read(&trace->enabled)) {
        return;
    }

    tid = qemu_get_thread_id();
    owner_tid = qatomic_read(&trace->owner_thread_id);
    if (owner_tid != tid) {
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    lock_trace_finish_owner_stage(trace, now);
    acquired = qatomic_read(&trace->owner_acquire_host_ns);
    if (acquired == 0 || now < acquired) {
        return;
    }
    held_ns = now - acquired;
    if (held_ns < XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS) {
        return;
    }

    xemu_debug_tools_diagnostics_current_cpu_context(
        &cpu_index, &guest_pc_end, &guest_pc_end_valid);
    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = now;
    event.held_ns = held_ns;
    event.owner_acquire_host_ns = acquired;
    event.thread_id = tid;
    event.cpu_index = qatomic_read(&trace->owner_cpu_index);
    event.guest_pc_start = qatomic_read(&trace->owner_guest_pc_start);
    event.guest_pc_start_valid =
        qatomic_read(&trace->owner_guest_pc_start_valid);
    event.guest_pc_end = guest_pc_end;
    event.guest_pc_end_valid = guest_pc_end_valid;
    event.caller_line = qatomic_read(&trace->owner_caller_line);
    event.caller_context = qatomic_read(&trace->owner_context);
    event.longest_stage = qatomic_read(&trace->owner_longest_stage);
    event.longest_stage_ns = qatomic_read(&trace->owner_longest_stage_ns);
    event.event_type = XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_HOLD;
    lock_trace_copy_file(event.caller_file,
                         qatomic_read(&trace->owner_caller_file));
    lock_trace_append(trace, &event);
}

static void lock_trace_clear_owner(XemuDebugToolsLockTraceState *trace,
                                   int32_t tid)
{
    if (qatomic_cmpxchg(&trace->owner_thread_id, tid,
                        LOCK_TRACE_NO_OWNER) == tid) {
        qatomic_set(&trace->owner_cpu_index, -1);
        qatomic_set(&trace->owner_acquire_host_ns, 0);
        qatomic_set(&trace->owner_guest_pc_start, 0);
        qatomic_set(&trace->owner_guest_pc_start_valid, 0);
        qatomic_set(&trace->owner_caller_file, NULL);
        qatomic_set(&trace->owner_caller_line, 0);
        qatomic_set(&trace->owner_context, XEMU_DEBUG_TOOLS_BQL_CONTEXT_NONE);
        qatomic_set(&trace->owner_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_stage_start_host_ns, 0);
        qatomic_set(&trace->owner_longest_stage,
                    XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_longest_stage_ns, 0);
    }
}

void xemu_debug_tools_lock_trace_core_unlock_end(
    XemuDebugToolsLockTraceKind kind)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    const XemuDebugToolsLockTracePolicy *policy = lock_trace_get_policy(kind);

    if (!qatomic_read(&trace->enabled) &&
        !policy->clear_owner_when_disabled) {
        return;
    }
    lock_trace_clear_owner(trace, qemu_get_thread_id());
}

void xemu_debug_tools_lock_trace_core_set_enabled(
    XemuDebugToolsLockTraceKind kind, int enabled)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);

    if (enabled) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            trace->slots, XemuDebugToolsLockTraceSlot,
            XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY,
            xemu_debug_tools_lock_trace_core_get_buffer_multiplier(kind), ok);
        if (!ok) {
            return;
        }
        xemu_debug_tools_lock_trace_core_clear(kind);
        qatomic_set(&trace->owner_thread_id, LOCK_TRACE_NO_OWNER);
        qatomic_set(&trace->owner_cpu_index, -1);
        qatomic_set(&trace->owner_acquire_host_ns, 0);
        qatomic_set(&trace->owner_guest_pc_start, 0);
        qatomic_set(&trace->owner_guest_pc_start_valid, 0);
        qatomic_set(&trace->owner_caller_file, NULL);
        qatomic_set(&trace->owner_caller_line, 0);
        qatomic_set(&trace->owner_context, XEMU_DEBUG_TOOLS_BQL_CONTEXT_NONE);
        qatomic_set(&trace->owner_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_stage_start_host_ns, 0);
        qatomic_set(&trace->owner_longest_stage,
                    XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_longest_stage_ns, 0);
        qatomic_set(&trace->enabled, 1);
    } else {
        qatomic_set(&trace->enabled, 0);
        qatomic_set(&trace->owner_thread_id, LOCK_TRACE_NO_OWNER);
        qatomic_set(&trace->owner_cpu_index, -1);
        qatomic_set(&trace->owner_acquire_host_ns, 0);
        qatomic_set(&trace->owner_guest_pc_start, 0);
        qatomic_set(&trace->owner_guest_pc_start_valid, 0);
        qatomic_set(&trace->owner_caller_file, NULL);
        qatomic_set(&trace->owner_caller_line, 0);
        qatomic_set(&trace->owner_context, XEMU_DEBUG_TOOLS_BQL_CONTEXT_NONE);
        qatomic_set(&trace->owner_stage, XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_stage_start_host_ns, 0);
        qatomic_set(&trace->owner_longest_stage,
                    XEMU_DEBUG_TOOLS_BQL_STAGE_NONE);
        qatomic_set(&trace->owner_longest_stage_ns, 0);
    }
}

int xemu_debug_tools_lock_trace_core_set_buffer_multiplier(
    XemuDebugToolsLockTraceKind kind, uint32_t multiplier)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    bool ok;

    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        trace->slots, XemuDebugToolsLockTraceSlot,
        XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY, multiplier, ok);
    if (!ok) {
        return 0;
    }
    qatomic_set(&trace->buffer_multiplier, multiplier);
    xemu_debug_tools_lock_trace_core_clear(kind);
    return 1;
}

uint32_t xemu_debug_tools_lock_trace_core_get_buffer_multiplier(
    XemuDebugToolsLockTraceKind kind)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    uint32_t multiplier = qatomic_read(&trace->buffer_multiplier);

    return multiplier ? multiplier : 1;
}

size_t xemu_debug_tools_lock_trace_core_get_buffer_capacity(
    XemuDebugToolsLockTraceKind kind)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY,
        xemu_debug_tools_lock_trace_core_get_buffer_multiplier(kind));
}

void xemu_debug_tools_lock_trace_core_clear(XemuDebugToolsLockTraceKind kind)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);

    qatomic_set(&trace->total_events, 0);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        trace->slots, XemuDebugToolsLockTraceSlot,
        XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY,
        xemu_debug_tools_lock_trace_core_get_buffer_multiplier(kind));
}

void xemu_debug_tools_lock_trace_core_get_status(
    XemuDebugToolsLockTraceKind kind, XemuDebugToolsLockTraceStatus *status)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    uint64_t total;
    uint64_t now;
    uint64_t acquired;
    size_t trace_capacity;

    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    status->current_owner_cpu_index = -1;
    status->enabled = qatomic_read(&trace->enabled) ? 1 : 0;
    total = qatomic_read(&trace->total_events);
    trace_capacity = xemu_debug_tools_lock_trace_core_get_buffer_capacity(kind);
    status->total_events = total;
    status->count = MIN(total, (uint64_t)trace_capacity);
    status->overwritten_events =
        total > xemu_debug_tools_lock_trace_core_get_buffer_capacity(kind)
            ? total - xemu_debug_tools_lock_trace_core_get_buffer_capacity(kind)
            : 0;
    status->long_wait_threshold_ns = XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS;
    status->current_owner_thread_id = qatomic_read(&trace->owner_thread_id);
    status->current_owner_cpu_index =
        status->current_owner_thread_id != LOCK_TRACE_NO_OWNER
            ? qatomic_read(&trace->owner_cpu_index)
            : -1;
    status->current_owner_guest_pc = qatomic_read(&trace->owner_guest_pc_start);
    status->current_owner_guest_pc_valid =
        qatomic_read(&trace->owner_guest_pc_start_valid);
    status->current_owner_context = qatomic_read(&trace->owner_context);
    status->current_owner_stage = qatomic_read(&trace->owner_stage);
    status->current_owner_caller_line = qatomic_read(&trace->owner_caller_line);
    lock_trace_copy_file(status->current_owner_caller_file,
                         qatomic_read(&trace->owner_caller_file));
    acquired = qatomic_read(&trace->owner_acquire_host_ns);
    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (status->current_owner_thread_id != LOCK_TRACE_NO_OWNER &&
        acquired != 0 && now >= acquired) {
        status->current_owner_held_ns = now - acquired;
    }
    if (status->current_owner_stage != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE) {
        uint64_t stage_start = qatomic_read(&trace->owner_stage_start_host_ns);
        if (stage_start != 0 && now >= stage_start) {
            status->current_owner_stage_elapsed_ns = now - stage_start;
        }
    }
}

size_t xemu_debug_tools_lock_trace_core_snapshot(
    XemuDebugToolsLockTraceKind kind, XemuDebugToolsLockTraceEvent *events,
    size_t capacity)
{
    XemuDebugToolsLockTraceState *trace = lock_trace_state(kind);
    uint64_t total;
    uint64_t available;
    uint64_t first;
    size_t copied = 0;
    uint64_t sequence;
    size_t trace_capacity;

    if (events == NULL || capacity == 0) {
        return 0;
    }

    total = qatomic_read(&trace->total_events);
    trace_capacity = xemu_debug_tools_lock_trace_core_get_buffer_capacity(kind);
    available = MIN(total, (uint64_t)trace_capacity);
    if (available > capacity) {
        first = total - capacity;
    } else {
        first = total - available;
    }

    for (sequence = first; sequence < total && copied < capacity; ++sequence) {
        XemuDebugToolsLockTraceSlot *slot = &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            trace->slots, XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY,
            sequence % trace_capacity);
        uint64_t commit_before =
            qatomic_read(&slot->committed_sequence_plus_one);
        XemuDebugToolsLockTraceEvent event;
        uint64_t commit_after;

        if (commit_before != sequence + 1) {
            continue;
        }
        smp_rmb();
        event = slot->event;
        smp_rmb();
        commit_after = qatomic_read(&slot->committed_sequence_plus_one);
        if (commit_after != commit_before || event.sequence != sequence) {
            continue;
        }
        events[copied++] = event;
    }
    return copied;
}
