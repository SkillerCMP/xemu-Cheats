//
// xemu Debug Tools - standalone Diagnostics window
//
#pragma once

#include "../../cheat-engine-memory.h"
#include "diagnostics-backend.h"
#include "diagnostics-view-sections.h"

#include <array>
#include <cstdint>
#include <deque>
#include <string>
#include <vector>

class DiagnosticsWindow
{
public:
    bool is_open = false;

    void Tick();
    void Draw(bool detached = false);
    void NotifyGameReset();
    void ProcessDeferredActions();

private:
    enum class WatchType {
        U8 = 0,
        U16,
        U32,
        U64,
        S32,
        Float32,
        Float64,
    };

    struct CustomWatch {
        std::array<char, 48> name{};
        uint32_t address = 0;
        bool virtual_address = true;
        bool enabled = false;
        bool physical_valid = false;
        uint64_t physical_address = 0;
        WatchType type = WatchType::U32;
        bool warn_if_unchanged = false;
        uint32_t unchanged_warning_ms = 1000;
        bool valid = false;
        std::array<uint8_t, 8> raw{};
        std::array<uint8_t, 8> previous_raw{};
        uint64_t last_change_ms = 0;
        bool warning_active = false;
    };

    struct EventRow {
        uint64_t elapsed_ms = 0;
        std::string category;
        std::string text;
    };

    XemuCheatX86Registers m_regs{};
    bool m_regs_valid = false;
    std::array<uint32_t, 16> m_stack{};
    bool m_stack_valid = false;
    std::array<XemuCheatDisasmRow, 12> m_disasm{};
    size_t m_disasm_count = 0;
    XemuDiagnosticsTimingSnapshot m_timing{};
    XemuDiagnosticsDeviceSnapshot m_device{};

    uint32_t m_refresh_ms = 250;
    uint64_t m_last_sample_ms = 0;
    uint64_t m_session_start_ms = 0;
    uint64_t m_sample_count = 0;

    uint32_t m_last_eip = 0;
    uint64_t m_eip_same_since_ms = 0;
    bool m_pc_stall_warning = false;
    std::deque<std::pair<uint64_t, uint32_t>> m_pc_history;

    bool m_tsc_baseline_valid = false;
    int64_t m_tsc_offset_baseline = 0;
    int64_t m_tsc_drift_ticks = 0;
    double m_tsc_drift_us = 0.0;
    bool m_tsc_warning = false;

    uint32_t m_last_gpu_frame_count = 0;
    uint64_t m_last_gpu_frame_change_ms = 0;
    bool m_gpu_stall_warning = false;
    bool m_ptimer_late_warning = false;
    bool m_apu_timing_warning = false;
    bool m_last_running = false;
    bool m_running_initialized = false;
    uint32_t m_last_ptimer_pending = 0;
    uint64_t m_last_bql_trace_total_events = 0;
    uint64_t m_last_flip_trace_total_events = 0;
    bool m_flip_stall_warning = false;
    uint64_t m_last_scheduler_trace_total_events = 0;
    bool m_scheduler_idle_warning = false;

    bool m_pause_history = false;
    std::deque<EventRow> m_events;
    static constexpr size_t kBaseMaxEvents = 512;
    uint32_t m_recent_events_multiplier = 1;
    bool m_buffer_editor_initialized = false;
    int m_all_buffer_multiplier_edit = 1;
    std::array<int, XEMU_DIAG_BUFFER_COUNT> m_buffer_multiplier_edit{};
    int m_recent_events_multiplier_edit = 1;

    std::vector<CustomWatch> m_watches;

    bool m_auto_save = false;
    uint32_t m_auto_save_interval_ms = 2000;
    uint64_t m_last_auto_save_ms = 0;
    bool m_auto_save_requested = false;
    bool m_save_snapshot_requested = false;
    bool m_manual_refresh_requested = false;
    bool m_manual_snapshot_requested = false;
    std::string m_auto_save_path;
    std::string m_status;

    // One selection controls visibility and Save/Copy/Live report sections.
    using DiagnosticSection = XemuDiagnosticsView::Section;
    XemuDiagnosticsView::State m_view;


    void Sample(uint64_t now_ms);
    void SampleWatches(uint64_t now_ms);
    void UpdateDetectors(uint64_t now_ms);
    void UpdateBqlRecentEvents(uint64_t now_ms);
    void UpdateFlipRecentEvents(uint64_t now_ms);
    void UpdateSchedulerRecentEvents(uint64_t now_ms);
    void AddEvent(uint64_t now_ms, const char *category,
                  const std::string &text);
    size_t PcUniqueCount(uint64_t now_ms) const;

    void DrawOverview();
    void DrawCpuTiming();
    void DrawNv2a();
    void DrawAudio();
    void DrawWatches();
    void DrawHistory();
    void DrawBufferSizePopup();

    struct OpenSnapshotsFolderJob {
        DiagnosticsWindow *owner = nullptr;
        std::string directory;
        std::string status;
    };

    bool m_open_snapshots_folder_requested = false;
    std::string m_snapshots_folder_status = "Not requested this session.";

    std::string BuildSnapshotText() const;
    bool SaveSnapshotToPath(const std::string &path, bool atomic) const;
    bool RequestSaveSnapshot();
    void OpenSnapshotsFolder();
    static void OpenSnapshotsFolderWorker(void *opaque);
    static void OpenSnapshotsFolderComplete(void *opaque);
    void DrawViewMenu();
    void DrawRecordingControls();
    void CopySummaryToClipboard();
    void MaybeAutoSave(uint64_t now_ms);
    void HandleHotkeys(uint64_t now_ms);
    bool AllRecordingOptionsEnabled() const;
    void SetAllRecordingOptionsEnabled(bool enabled);
    void QueueSnapshotSave(uint64_t now_ms, bool from_hotkey);
    void ResetTscBaseline();

    static size_t WatchSize(WatchType type);
    static std::string FormatWatchValue(const CustomWatch &watch);
};

extern DiagnosticsWindow diagnostics_window;
