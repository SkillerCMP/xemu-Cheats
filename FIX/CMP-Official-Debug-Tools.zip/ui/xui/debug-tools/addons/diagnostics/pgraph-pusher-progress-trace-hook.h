/* Info: Observation-only NV2A pusher/semaphore hooks for Diagnostics. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct XemuDebugToolsPgraphPusherPfifoScope {
    uint64_t host_start_ns;
    uint64_t virtual_start_ns;
    uint32_t dma_get_before;
    uint32_t dma_put_before;
    uint32_t channel_id;
    uint32_t active;
} XemuDebugToolsPgraphPusherPfifoScope;

typedef struct XemuDebugToolsPgraphPusherPullerScope {
    uint64_t host_start_ns;
    uint32_t active;
} XemuDebugToolsPgraphPusherPullerScope;

typedef struct XemuDebugToolsPgraphPusherSemaphoreScope {
    uint64_t host_start_ns;
    uint64_t virtual_start_ns;
    uint64_t last_dma_put_host_ns;
    uint32_t last_dma_put_channel;
    uint32_t dma_instance;
    uint32_t semaphore_offset;
    uint32_t requested_value;
    uint32_t dma_get_before;
    uint32_t dma_put_before;
    uint32_t semaphore_phys;
    uint32_t semaphore_guest_va;
    uint32_t previous_value;
    uint32_t target_valid;
    uint32_t active;
} XemuDebugToolsPgraphPusherSemaphoreScope;

int xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled(void);

/* NV_USER_DMA_PUT is the guest-facing push-buffer submission point used by
 * XDK D3D KickOff-style paths. The recorder captures the current vCPU PC on
 * the Diagnostics side so upstream NV2A code remains symbol-agnostic. */
void xemu_debug_tools_pgraph_pusher_progress_note_dma_put(
    uint32_t channel_id, uint32_t dma_get, uint32_t old_dma_put,
    uint32_t new_dma_put);

/* One summary per PFIFO pusher invocation that had queued work when tracing
 * was enabled. Raw GET/PUT positions are retained even when a push-buffer jump
 * makes a simple byte delta meaningless. */
void xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(
    XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t channel_id,
    uint32_t dma_get, uint32_t dma_put);
void xemu_debug_tools_pgraph_pusher_progress_pfifo_end(
    XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t dma_get,
    uint32_t dma_put, uint32_t method_words_processed,
    uint32_t waiting_for_nop, uint32_t waiting_for_flip,
    uint32_t fifo_access);

/* v3.14w method-time breakdown. The PFIFO caller times each puller dispatch;
 * pgraph_method only supplies the resolved graphics-class/method identity.
 * Keeping the clock calls at the PFIFO boundary lets the measurement include
 * the real gate/lock/method cost without adding timers inside every handler. */
int xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled(void);
void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin(
    XemuDebugToolsPgraphPusherPullerScope *scope);
void xemu_debug_tools_pgraph_pusher_method_breakdown_note_method(
    uint32_t subchannel, uint32_t graphics_class, uint32_t method,
    uint32_t method_base, uint32_t parameter, const char *method_name);
void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end(
    XemuDebugToolsPgraphPusherPullerScope *scope, uint32_t words_processed);

/* XDK D3D fences/GpuTime are backed by NV097 semaphore releases. Patch 300
 * enters this observation after the stock surface_update()/semaphore-offset
 * sequence so optional Patch 20 remains independently applicable. target()
 * records the mapped guest RAM location and prewrite() commits the observation
 * immediately before the unchanged stl_le_p write. The recorder also correlates
 * the event to the most recent guest DMA PUT timestamp. No title/XDK address is
 * hardcoded. */
void xemu_debug_tools_pgraph_pusher_progress_semaphore_begin(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t dma_instance,
    uint32_t semaphore_offset, uint32_t value);
void xemu_debug_tools_pgraph_pusher_progress_semaphore_target(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t physical_address,
    uint32_t guest_virtual_address, uint32_t previous_value);
void xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t waiting_for_nop,
    uint32_t waiting_for_flip);

#ifdef __cplusplus
}
#endif
