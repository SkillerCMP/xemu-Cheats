#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "hw/xbox/nv2a/nv2a_int.h"
#include "hw/xbox/nv2a/nv2a_regs.h"
#include "cpu.h"

#include "flip-stall-trace.h"
#include "diagnostics-trace-buffer.h"
#include "pgraph-flip-delay-trace.h"

typedef struct XemuDebugToolsFlipStallTraceRing {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;
    bool active_stall;
    uint64_t active_stall_start_host_ns;
    uint64_t active_stall_start_virtual_ns;
    XemuDebugToolsFlipStallTraceEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsFlipStallTraceRing;

static XemuDebugToolsFlipStallTraceRing g_flip_trace;

static void flip_trace_init(void)
{
    if (!g_flip_trace.initialized) {
        qemu_mutex_init(&g_flip_trace.lock);
        g_flip_trace.buffer_multiplier = 1;
        g_flip_trace.initialized = true;
    }
}

static void flip_trace_reset_locked(void)
{
    g_flip_trace.count = 0;
    g_flip_trace.write_index = 0;
    g_flip_trace.total_events = 0;
    g_flip_trace.overwritten_events = 0;
    g_flip_trace.active_stall = false;
    g_flip_trace.active_stall_start_host_ns = 0;
    g_flip_trace.active_stall_start_virtual_ns = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_flip_trace.events, XemuDebugToolsFlipStallTraceEvent,
        XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY,
        g_flip_trace.buffer_multiplier);
}

static void flip_trace_fill_context(XemuDebugToolsFlipStallTraceEvent *event,
                                    const PGRAPHState *pg)
{
    CPUState *cpu = current_cpu;
    uint32_t surface = pg ? qatomic_read(&pg->regs_[NV_PGRAPH_SURFACE]) : 0;

    event->thread_id = qemu_get_thread_id();
    event->cpu_index = cpu ? cpu->cpu_index : -1;
    if (cpu && cpu->cc && cpu->cc->get_pc) {
        event->guest_pc = cpu->cc->get_pc(cpu);
        event->guest_pc_valid = 1;
    }

    event->surface = surface;
    event->read_3d = GET_MASK(surface, NV_PGRAPH_SURFACE_READ_3D);
    event->write_3d = GET_MASK(surface, NV_PGRAPH_SURFACE_WRITE_3D);
    event->modulo_3d = GET_MASK(surface, NV_PGRAPH_SURFACE_MODULO_3D);
    if (pg) {
        event->waiting_for_flip = qatomic_read(&pg->waiting_for_flip) ? 1u : 0u;
        event->pending_interrupts = qatomic_read(&pg->pending_interrupts);
        event->enabled_interrupts = qatomic_read(&pg->enabled_interrupts);
        event->flush_pending = qatomic_read(&pg->flush_pending) ? 1u : 0u;
        event->sync_pending = qatomic_read(&pg->sync_pending) ? 1u : 0u;
        event->frame_time = pg->frame_time;
    }
}

static void flip_trace_store_locked(XemuDebugToolsFlipStallTraceEvent *event)
{
    size_t cap = xemu_debug_tools_flip_stall_trace_get_buffer_capacity();
    size_t slot = g_flip_trace.write_index;

    event->sequence = g_flip_trace.total_events++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_flip_trace.events, XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY,
        slot) = *event;
    g_flip_trace.write_index = (slot + 1) % cap;
    if (g_flip_trace.count < cap) {
        g_flip_trace.count++;
    } else {
        g_flip_trace.overwritten_events++;
    }
}

void xemu_debug_tools_flip_stall_trace_record(
    unsigned int event_type, const void *opaque,
    uint32_t method, uint32_t parameter, uint32_t value0, uint32_t value1,
    uint64_t duration_ns)
{
    XemuDebugToolsFlipStallTraceEvent event = { 0 };
    const PGRAPHState *pg = opaque;

    const bool regular_enabled =
        g_flip_trace.initialized && qatomic_read(&g_flip_trace.enabled);
    const bool delay_enabled =
        xemu_debug_tools_pgraph_flip_delay_trace_is_enabled() != 0;
    if (!regular_enabled && !delay_enabled) {
        return;
    }

    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.event_type = event_type;
    event.method = method;
    event.parameter = parameter;
    event.value0 = value0;
    event.value1 = value1;
    event.duration_ns = duration_ns;
    flip_trace_fill_context(&event, pg);
    xemu_debug_tools_pgraph_flip_delay_note_flip_event(&event);

    if (!regular_enabled) {
        return;
    }

    qemu_mutex_lock(&g_flip_trace.lock);
    if (!qatomic_read(&g_flip_trace.enabled)) {
        qemu_mutex_unlock(&g_flip_trace.lock);
        return;
    }
    if (g_flip_trace.active_stall &&
        event.host_ns >= g_flip_trace.active_stall_start_host_ns) {
        event.stall_age_ns =
            event.host_ns - g_flip_trace.active_stall_start_host_ns;
    }
    flip_trace_store_locked(&event);
    qemu_mutex_unlock(&g_flip_trace.lock);
}

void xemu_debug_tools_flip_stall_trace_begin(const void *opaque)
{
    uint64_t host_ns;
    uint64_t virtual_ns;

    const bool regular_enabled =
        g_flip_trace.initialized && qatomic_read(&g_flip_trace.enabled);
    if (!regular_enabled &&
        !xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        return;
    }

    host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    if (regular_enabled) {
        qemu_mutex_lock(&g_flip_trace.lock);
        if (!g_flip_trace.active_stall) {
            g_flip_trace.active_stall = true;
            g_flip_trace.active_stall_start_host_ns = host_ns;
            g_flip_trace.active_stall_start_virtual_ns = virtual_ns;
        }
        qemu_mutex_unlock(&g_flip_trace.lock);
    }

    xemu_debug_tools_flip_stall_trace_record(
        XEMU_DEBUG_TOOLS_FLIP_STALL_BEGIN, opaque,
        NV097_FLIP_STALL, 0, 0, 0, 0);
}

void xemu_debug_tools_flip_stall_trace_end(const void *opaque)
{
    uint64_t age_ns = 0;
    uint64_t host_ns;

    const bool regular_enabled =
        g_flip_trace.initialized && qatomic_read(&g_flip_trace.enabled);
    if (!regular_enabled &&
        !xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        return;
    }

    host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (regular_enabled) {
        qemu_mutex_lock(&g_flip_trace.lock);
        if (g_flip_trace.active_stall &&
            host_ns >= g_flip_trace.active_stall_start_host_ns) {
            age_ns = host_ns - g_flip_trace.active_stall_start_host_ns;
        }
        qemu_mutex_unlock(&g_flip_trace.lock);
    }

    xemu_debug_tools_flip_stall_trace_record(
        XEMU_DEBUG_TOOLS_FLIP_PFIFO_RELEASE, opaque,
        NV097_FLIP_STALL, 0, 0, 0, age_ns);

    if (regular_enabled) {
        qemu_mutex_lock(&g_flip_trace.lock);
        g_flip_trace.active_stall = false;
        g_flip_trace.active_stall_start_host_ns = 0;
        g_flip_trace.active_stall_start_virtual_ns = 0;
        qemu_mutex_unlock(&g_flip_trace.lock);
    }
}

void xemu_debug_tools_flip_stall_trace_set_enabled(int enabled)
{
    bool ok = true;
    flip_trace_init();
    qemu_mutex_lock(&g_flip_trace.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_flip_trace.events, XemuDebugToolsFlipStallTraceEvent,
            XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY,
            g_flip_trace.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&g_flip_trace.lock);
            return;
        }
    }
    if (enabled && !g_flip_trace.enabled) {
        flip_trace_reset_locked();
    }
    qatomic_set(&g_flip_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&g_flip_trace.lock);
}

void xemu_debug_tools_flip_stall_trace_clear(void)
{
    flip_trace_init();
    qemu_mutex_lock(&g_flip_trace.lock);
    flip_trace_reset_locked();
    qemu_mutex_unlock(&g_flip_trace.lock);
}

int xemu_debug_tools_flip_stall_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok;
    flip_trace_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_flip_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_flip_trace.events, XemuDebugToolsFlipStallTraceEvent,
        XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY, multiplier, ok);
    if (ok) {
        g_flip_trace.buffer_multiplier = multiplier;
        flip_trace_reset_locked();
    }
    qemu_mutex_unlock(&g_flip_trace.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_flip_stall_trace_get_buffer_multiplier(void)
{
    return g_flip_trace.buffer_multiplier ? g_flip_trace.buffer_multiplier : 1;
}

size_t xemu_debug_tools_flip_stall_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY,
        xemu_debug_tools_flip_stall_trace_get_buffer_multiplier());
}

void xemu_debug_tools_flip_stall_trace_get_status(
    XemuDebugToolsFlipStallTraceStatus *status)
{
    uint64_t now_ns;
    if (!status) {
        return;
    }
    flip_trace_init();
    memset(status, 0, sizeof(*status));
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    qemu_mutex_lock(&g_flip_trace.lock);
    status->enabled = g_flip_trace.enabled;
    status->count = g_flip_trace.count;
    status->total_events = g_flip_trace.total_events;
    status->overwritten_events = g_flip_trace.overwritten_events;
    status->active_stall = g_flip_trace.active_stall ? 1u : 0u;
    status->active_stall_start_host_ns = g_flip_trace.active_stall_start_host_ns;
    status->active_stall_start_virtual_ns = g_flip_trace.active_stall_start_virtual_ns;
    if (g_flip_trace.active_stall && now_ns >= g_flip_trace.active_stall_start_host_ns) {
        status->active_stall_age_ns = now_ns - g_flip_trace.active_stall_start_host_ns;
    }
    qemu_mutex_unlock(&g_flip_trace.lock);
}

size_t xemu_debug_tools_flip_stall_trace_snapshot(
    XemuDebugToolsFlipStallTraceEvent *events, size_t capacity)
{
    size_t ring_capacity;
    size_t count;
    size_t oldest;
    size_t i;

    if (!events || capacity == 0) {
        return 0;
    }
    flip_trace_init();
    qemu_mutex_lock(&g_flip_trace.lock);
    ring_capacity = xemu_debug_tools_flip_stall_trace_get_buffer_capacity();
    count = MIN(capacity, g_flip_trace.count);
    oldest = g_flip_trace.count == ring_capacity ? g_flip_trace.write_index : 0;
    if (count < g_flip_trace.count) {
        oldest = (oldest + g_flip_trace.count - count) % ring_capacity;
    }
    for (i = 0; i < count; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_flip_trace.events, XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY,
            (oldest + i) % ring_capacity);
    }
    qemu_mutex_unlock(&g_flip_trace.lock);
    return count;
}
