/* Info: APU output batches, UI VBlank ticks, and guest PGRAPH FLIP_STALL
 * boundaries feed the Diagnostics A/V/PGRAPH cadence recorder. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void xemu_debug_tools_av_sync_trace_note_audio_batch(const void *apu_state,
                                                      uint32_t samples);
void xemu_debug_tools_av_sync_trace_note_vblank(uint64_t interval_ns);
void xemu_debug_tools_av_sync_trace_note_pgraph_flip(uint32_t frame_time);

#ifdef __cplusplus
}
#endif
