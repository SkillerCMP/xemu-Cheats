/*
 * xemu Debug Tools - Diagnostics-owned Controller / XID reconnect trace.
 */
#pragma once

#include "controller-xid-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_NAME_MAX 96
#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_GUID_MAX 40

typedef struct XemuDebugToolsControllerXidTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t xid_device;
    uint32_t event_type;
    int32_t port;
    uint32_t instance_id;
    int32_t save_binding;
    uint32_t value0;
    uint32_t value1;
    uint32_t value2;
    uint32_t value3;
    uint32_t value4;
    uint32_t report_length;
    uint8_t report[XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX];
    uint32_t host_buttons;
    int16_t host_axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT];
    uint16_t xid_buttons;
    uint8_t xid_analog[XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT];
    int16_t thumb_lx;
    int16_t thumb_ly;
    int16_t thumb_rx;
    int16_t thumb_ry;
    char name[XEMU_DEBUG_TOOLS_CONTROLLER_XID_NAME_MAX];
    char guid[XEMU_DEBUG_TOOLS_CONTROLLER_XID_GUID_MAX];
} XemuDebugToolsControllerXidTraceEvent;

typedef struct XemuDebugToolsControllerXidTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_observations;
    uint64_t stored_events;
    uint64_t overwritten_events;
    uint64_t observations[XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT];
} XemuDebugToolsControllerXidTraceStatus;

void xemu_debug_tools_controller_xid_trace_set_enabled(int enabled);
void xemu_debug_tools_controller_xid_trace_clear(void);
int xemu_debug_tools_controller_xid_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_controller_xid_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_controller_xid_trace_get_buffer_capacity(void);
void xemu_debug_tools_controller_xid_trace_get_status(
    XemuDebugToolsControllerXidTraceStatus *status);
size_t xemu_debug_tools_controller_xid_trace_snapshot(
    XemuDebugToolsControllerXidTraceEvent *events,
    size_t capacity);

#ifdef __cplusplus
}
#endif
