/* xemu Debug Tools - Diagnostics PGRAPH long-frame delay breakdown. */
#pragma once

#include "pgraph-flip-delay-trace-hook.h"
#include "flip-stall-trace.h"
#include "pgraph-ptimer-latency-trace-types.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY 1024
#define XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_DEFAULT_THRESHOLD_NS 40000000ULL
#define XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_PC_SAMPLE_INTERVAL_NS 500000ULL
#define XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT 8

typedef struct XemuDebugToolsPgraphFlipDelayEvent {
    uint64_t sequence;
    uint64_t start_host_ns;
    uint64_t end_host_ns;
    uint64_t start_virtual_ns;
    uint64_t end_virtual_ns;
    uint64_t frame_host_ns;
    uint64_t frame_virtual_ns;
    uint32_t start_frame_time;
    uint32_t end_frame_time;

    /* Non-overlapping high-level pieces of one FLIP_STALL->FLIP_STALL frame. */
    uint64_t stall_total_ns;
    uint64_t post_release_to_next_stall_ns;
    uint64_t release_to_flip_increment_ns;
    uint64_t flip_increment_to_next_stall_ns;

    /* FLIP_STALL internal pieces. Renderer finish is a correlated sub-stage
     * inside stall_method_ns and is intentionally not added a second time. */
    uint64_t stall_method_ns;
    uint64_t renderer_finish_total_ns;
    uint64_t renderer_finish_max_ns;
    uint64_t waiting_to_vblank_read_ns;
    uint64_t vblank_read_to_release_ns;

    /* Correlated PFIFO/PGRAPH serialization observed during the frame. */
    uint64_t cpu_mmio_gate_wait_total_ns;
    uint64_t cpu_mmio_gate_wait_max_ns;
    uint64_t pfifo_cpu_mmio_gate_wait_total_ns;
    uint64_t pfifo_cpu_mmio_gate_wait_max_ns;
    uint64_t renderer_cpu_mmio_gate_wait_total_ns;
    uint64_t renderer_cpu_mmio_gate_wait_max_ns;
    uint64_t pgraph_lock_wait_total_ns;
    uint64_t pgraph_lock_wait_max_ns;
    uint32_t pfifo_gate_count;
    uint32_t renderer_gate_count;
    uint32_t pgraph_lock_count;

    /* VBlank READ_3D consumption / release-side timing. */
    uint64_t surface_lock_wait_total_ns;
    uint64_t surface_lock_wait_max_ns;
    uint64_t surface_update_total_ns;
    uint64_t pfifo_kick_total_ns;
    uint64_t bql_reacquire_total_ns;
    uint32_t pgraph_increment_count;

    uint32_t vblank_irq_count;
    uint32_t vblank_read_increment_count;
    uint32_t pfifo_stall_check_count;
    uint32_t pfifo_release_count;

    uint32_t read_3d;
    uint32_t write_3d;
    uint32_t modulo_3d;

    /* Natural TCG-dispatch samples gathered only after PFIFO release. Sampling
     * begins after half the long-frame threshold, so normal frames usually
     * incur no recorder lock traffic. Hits are approximate execution hotspots
     * at dispatcher-visible TB entry PCs, not instruction counts. */
    uint32_t post_release_pc_samples;
    uint32_t post_release_pc_tracked_unique;
    uint32_t post_release_pc_untracked_samples;
    uint32_t hot_pc[XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT];
    uint32_t hot_pc_hits[XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT];
} XemuDebugToolsPgraphFlipDelayEvent;

typedef struct XemuDebugToolsPgraphFlipDelayStatus {
    int enabled;
    size_t count;
    uint64_t total_frames_seen;
    uint64_t captured_long_frames;
    uint64_t overwritten_events;
    uint64_t threshold_ns;
    uint64_t last_frame_ns;
    uint64_t worst_frame_ns;
    uint64_t worst_stall_total_ns;
    uint64_t worst_post_release_ns;
    uint64_t worst_cpu_mmio_gate_wait_ns;
    uint64_t worst_pfifo_cpu_mmio_gate_wait_ns;
    uint64_t worst_renderer_cpu_mmio_gate_wait_ns;
    uint64_t worst_pgraph_lock_wait_ns;
    uint64_t worst_renderer_finish_ns;
    uint64_t guest_pc_sample_interval_ns;
    uint64_t guest_pc_arm_delay_ns;
    uint64_t guest_pc_samples;
    uint64_t guest_pc_untracked_samples;
    uint32_t active_frame;
    uint64_t active_frame_age_ns;
} XemuDebugToolsPgraphFlipDelayStatus;

void xemu_debug_tools_pgraph_flip_delay_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_flip_delay_trace_clear(void);
void xemu_debug_tools_pgraph_flip_delay_trace_set_threshold_ns(uint64_t ns);
int xemu_debug_tools_pgraph_flip_delay_trace_is_enabled(void);
int xemu_debug_tools_pgraph_flip_delay_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_capacity(void);
void xemu_debug_tools_pgraph_flip_delay_trace_get_status(
    XemuDebugToolsPgraphFlipDelayStatus *status);
size_t xemu_debug_tools_pgraph_flip_delay_trace_snapshot(
    XemuDebugToolsPgraphFlipDelayEvent *events, size_t capacity);

/* Internal cross-recorder observation points. They are kept in the
 * Diagnostics implementation so Patch 300 stays limited to stable XEMU hooks. */
void xemu_debug_tools_pgraph_flip_delay_note_flip_event(
    const XemuDebugToolsFlipStallTraceEvent *event);
void xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_attempt(void);
void xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_acquired(void);
void xemu_debug_tools_pgraph_flip_delay_note_increment(
    const XemuDebugToolsPgraphIncrementEvent *event);

#ifdef __cplusplus
}
#endif
