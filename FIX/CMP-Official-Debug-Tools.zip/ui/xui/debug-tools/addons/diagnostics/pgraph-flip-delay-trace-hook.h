/* Info: XEMU exposes pre-PGRAPH gates; Diagnostics owns delay analysis. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Called immediately after PFIFO drops pfifo.lock and before it attempts to
 * enter PGRAPH. When Patch 20 is present its CPU-MMIO drain runs between this
 * marker and the existing PGRAPH_LOCK lock-attempt marker, allowing the
 * Diagnostics layer to separate that wait from the mutex wait itself. */
void xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(
    const void *pgraph_state, uint32_t method, uint32_t parameter);

/* Renderer process_pending() entry markers. Patch 300 places begin before the
 * pending-condition evaluation so Patch 20 remains independently applicable;
 * if pending work exists, Patch 20's CPU-MMIO drain executes before the normal
 * PGRAPH_LOCK attempt and is therefore measured inside this gate. cancel()
 * clears the marker when no pending work entered PGRAPH. */
enum {
    XEMU_PGRAPH_FLIP_DELAY_RENDERER_GL = 1,
    XEMU_PGRAPH_FLIP_DELAY_RENDERER_NULL = 2,
    XEMU_PGRAPH_FLIP_DELAY_RENDERER_VK = 3,
};
void xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(
    const void *pgraph_state, uint32_t renderer_kind);
void xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel(void);

/* Low-intrusion TCG post-release PC sampler. active() is true only between
 * PFIFO_RELEASE and the next FLIP_STALL while the delay recorder is enabled.
 * note_guest_pc() is called only at natural TCG dispatcher boundaries; Patch
 * 300 must not force single-step TBs or disable direct chaining for this. */
int xemu_debug_tools_pgraph_flip_delay_guest_pc_sampler_active(void);
void xemu_debug_tools_pgraph_flip_delay_note_guest_pc(uint32_t guest_pc);

#ifdef __cplusplus
}
#endif
