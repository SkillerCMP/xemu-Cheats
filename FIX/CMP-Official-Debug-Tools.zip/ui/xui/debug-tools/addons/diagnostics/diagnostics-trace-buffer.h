/* Info: Trace buffers grow by retained chunks to avoid hot-path free/reallocation races. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#define XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER 100U

static inline uint32_t xemu_debug_tools_trace_buffer_clamp_multiplier(
    uint32_t multiplier)
{
    if (multiplier < 1U) {
        return 1U;
    }
    if (multiplier > XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER) {
        return XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER;
    }
    return multiplier;
}

static inline size_t xemu_debug_tools_trace_buffer_capacity(
    size_t base_capacity, uint32_t multiplier)
{
    return base_capacity *
           (size_t)xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
}

#define XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(chunks, type, base_capacity, multiplier, ok_var) \
    do {                                                                                     \
        uint32_t _xdt_mult = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);      \
        uint32_t _xdt_i;                                                                      \
        (ok_var) = true;                                                                       \
        for (_xdt_i = 0; _xdt_i < _xdt_mult; ++_xdt_i) {                                     \
            if ((chunks)[_xdt_i] == NULL) {                                                    \
                type *_xdt_chunk = g_try_new0(type, (base_capacity));                          \
                if (_xdt_chunk == NULL) {                                                      \
                    (ok_var) = false;                                                          \
                    break;                                                                     \
                }                                                                              \
                (chunks)[_xdt_i] = _xdt_chunk;                                                 \
            }                                                                                  \
        }                                                                                      \
    } while (0)

#define XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(chunks, base_capacity, index) \
    ((chunks)[(index) / (base_capacity)][(index) % (base_capacity)])

#define XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(chunks, type, base_capacity, multiplier) \
    do {                                                                                        \
        uint32_t _xdt_mult = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);        \
        uint32_t _xdt_i;                                                                        \
        for (_xdt_i = 0; _xdt_i < _xdt_mult; ++_xdt_i) {                                       \
            if ((chunks)[_xdt_i] != NULL) {                                                      \
                memset((chunks)[_xdt_i], 0, sizeof(type) * (base_capacity));                     \
            }                                                                                    \
        }                                                                                        \
    } while (0)
