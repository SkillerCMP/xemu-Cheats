/* Info: Patch 305.4 Windows host-stall / page-fault correlation trace. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"

#include "host-stall-trace.h"
#include "guest-timer-deadline-trace.h"
#include "ptimer-irq-delivery-trace.h"

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#endif

typedef struct XemuDebugToolsHostProcessSample {
    uint64_t host_ns;
    uint64_t page_fault_count;
    uint64_t working_set;
    uint64_t private_usage;
    uint64_t available_phys;
    uint32_t memory_load;
    int valid;
} XemuDebugToolsHostProcessSample;

typedef struct XemuDebugToolsHostThreadSample {
    uint64_t host_ns;
    uint64_t qemu_virtual_ns;
    uint64_t cpu_ns;
    uint64_t cycles;
    uint32_t guest_pc;
    uint32_t thread_id;
    int cpu_valid;
    int cycles_valid;
    int valid;
    XemuDebugToolsHostProcessSample process;
} XemuDebugToolsHostThreadSample;

typedef struct XemuDebugToolsHostMainLoopWait {
    uint64_t host_ns;
    uint64_t qemu_virtual_ns;
    uint64_t cpu_ns;
    uint64_t cycles;
    uint32_t thread_id;
    int64_t timeout_ns;
    int cpu_valid;
    int cycles_valid;
    int active;
    XemuDebugToolsHostProcessSample process;
} XemuDebugToolsHostMainLoopWait;

typedef struct XemuDebugToolsHostStallState {
    QemuMutex lock;
    int enabled;
    uint64_t sequence;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t vcpu_events;
    uint64_t main_loop_events;
    uint64_t pagefault_correlated_events;
    uint64_t offcpu_events;
    uint64_t busy_events;
    uint64_t worst_vcpu_wall_ns;
    uint64_t worst_vcpu_offcpu_ns;
    uint64_t worst_main_loop_excess_ns;
    uint64_t worst_page_fault_delta;
    size_t write_index;
    size_t count;
    XemuDebugToolsHostStallEvent events[XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY];
    XemuDebugToolsHostThreadSample vcpu_sample;
    XemuDebugToolsHostProcessSample vcpu_process_baseline;
    XemuDebugToolsHostMainLoopWait main_wait;
    XemuDebugToolsHostProcessSample main_process_baseline;
} XemuDebugToolsHostStallState;

static XemuDebugToolsHostStallState g_host_stall;
static gsize g_host_stall_once;

static void host_stall_init(void)
{
    if (g_once_init_enter(&g_host_stall_once)) {
        qemu_mutex_init(&g_host_stall.lock);
        g_once_init_leave(&g_host_stall_once, 1);
    }
}

#ifdef _WIN32

static uint64_t host_now_ns(void)
{
    return qemu_clock_get_ns(QEMU_CLOCK_HOST);
}

static uint64_t virtual_now_ns(void)
{
    return qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
}

typedef BOOL (WINAPI *XemuGetProcessMemoryInfoFn)(
    HANDLE, PPROCESS_MEMORY_COUNTERS, DWORD);

static XemuGetProcessMemoryInfoFn g_get_process_memory_info;
static HMODULE g_psapi_module;
static gsize g_process_api_once;

static void host_stall_init_process_api(void)
{
    HMODULE kernel32;

    if (!g_once_init_enter(&g_process_api_once)) {
        return;
    }

    kernel32 = GetModuleHandleA("kernel32.dll");
    if (kernel32 != NULL) {
        g_get_process_memory_info = (XemuGetProcessMemoryInfoFn)(uintptr_t)
            GetProcAddress(kernel32, "K32GetProcessMemoryInfo");
    }
    if (g_get_process_memory_info == NULL) {
        g_psapi_module = LoadLibraryA("psapi.dll");
        if (g_psapi_module != NULL) {
            g_get_process_memory_info = (XemuGetProcessMemoryInfoFn)(uintptr_t)
                GetProcAddress(g_psapi_module, "GetProcessMemoryInfo");
        }
    }

    g_once_init_leave(&g_process_api_once, 1);
}

static uint64_t filetime_100ns(const FILETIME *value)
{
    ULARGE_INTEGER v;

    v.LowPart = value->dwLowDateTime;
    v.HighPart = value->dwHighDateTime;
    return v.QuadPart;
}

static int host_stall_read_thread(uint64_t *cpu_ns, uint64_t *cycles,
                                  uint32_t *thread_id,
                                  int *cpu_valid, int *cycles_valid)
{
    FILETIME creation, exit, kernel, user;
    ULONG64 cycle_value = 0;
    HANDLE thread = GetCurrentThread();

    if (cpu_ns != NULL) {
        *cpu_ns = 0;
    }
    if (cycles != NULL) {
        *cycles = 0;
    }
    if (thread_id != NULL) {
        *thread_id = GetCurrentThreadId();
    }
    if (cpu_valid != NULL) {
        *cpu_valid = 0;
    }
    if (cycles_valid != NULL) {
        *cycles_valid = 0;
    }

    if (GetThreadTimes(thread, &creation, &exit, &kernel, &user)) {
        if (cpu_ns != NULL) {
            *cpu_ns = (filetime_100ns(&kernel) + filetime_100ns(&user)) * 100ULL;
        }
        if (cpu_valid != NULL) {
            *cpu_valid = 1;
        }
    }
    if (QueryThreadCycleTime(thread, &cycle_value)) {
        if (cycles != NULL) {
            *cycles = cycle_value;
        }
        if (cycles_valid != NULL) {
            *cycles_valid = 1;
        }
    }
    return 1;
}

static int host_stall_read_process(XemuDebugToolsHostProcessSample *sample,
                                   uint64_t now_host_ns)
{
    PROCESS_MEMORY_COUNTERS_EX pmc;
    MEMORYSTATUSEX memory;
    int ok = 0;

    if (sample == NULL) {
        return 0;
    }
    memset(sample, 0, sizeof(*sample));
    sample->host_ns = now_host_ns;

    host_stall_init_process_api();
    memset(&pmc, 0, sizeof(pmc));
    pmc.cb = sizeof(pmc);
    if (g_get_process_memory_info != NULL &&
        g_get_process_memory_info(GetCurrentProcess(),
            (PPROCESS_MEMORY_COUNTERS)&pmc, sizeof(pmc))) {
        sample->page_fault_count = pmc.PageFaultCount;
        sample->working_set = (uint64_t)pmc.WorkingSetSize;
        sample->private_usage = (uint64_t)pmc.PrivateUsage;
        ok = 1;
    }

    memset(&memory, 0, sizeof(memory));
    memory.dwLength = sizeof(memory);
    if (GlobalMemoryStatusEx(&memory)) {
        sample->available_phys = memory.ullAvailPhys;
        sample->memory_load = memory.dwMemoryLoad;
        ok = 1;
    }
    sample->valid = ok;
    return ok;
}


static uint32_t host_stall_guest_pc(CPUState *cpu)
{
    if (cpu != NULL && cpu->cc != NULL && cpu->cc->get_pc != NULL) {
        return (uint32_t)cpu->cc->get_pc(cpu);
    }
    return 0;
}

static void host_stall_fill_process_delta(
    XemuDebugToolsHostStallEvent *event,
    const XemuDebugToolsHostProcessSample *before,
    const XemuDebugToolsHostProcessSample *after)
{
    if (event == NULL || before == NULL || after == NULL ||
        !before->valid || !after->valid) {
        return;
    }

    event->process_memory_valid = 1;
    event->process_sample_age_ns =
        event->host_after_ns >= before->host_ns ?
        event->host_after_ns - before->host_ns : 0;
    event->page_fault_count_before = before->page_fault_count;
    event->page_fault_count_after = after->page_fault_count;
    event->page_fault_delta = after->page_fault_count >= before->page_fault_count ?
        after->page_fault_count - before->page_fault_count : 0;
    event->working_set_before = before->working_set;
    event->working_set_after = after->working_set;
    event->private_usage_before = before->private_usage;
    event->private_usage_after = after->private_usage;
    event->available_phys_before = before->available_phys;
    event->available_phys_after = after->available_phys;
    event->memory_load_before = before->memory_load;
    event->memory_load_after = after->memory_load;
}

static void host_stall_fill_guest_correlation(
    XemuDebugToolsHostStallEvent *event)
{
    XemuDebugToolsGuestTimerDeadlineTraceStatus guest = { 0 };
    XemuDebugToolsPtimerIrqDeliveryStatus ptimer = { 0 };

    if (event == NULL) {
        return;
    }

    xemu_debug_tools_guest_timer_deadline_trace_get_status(&guest);
    event->input_sequence = guest.input_sequences;
    event->d3d_sequence = guest.deadline_sequences;
    event->callback_expected_due_ns = guest.callback_expected_due_ns;
    if (guest.callback_expected_due_ns != 0) {
        if (event->qemu_virtual_after_ns >= guest.callback_expected_due_ns) {
            const uint64_t delta = event->qemu_virtual_after_ns -
                                   guest.callback_expected_due_ns;
            event->callback_due_delta_ns =
                delta > INT64_MAX ? INT64_MAX : (int64_t)delta;
        } else {
            const uint64_t delta = guest.callback_expected_due_ns -
                                   event->qemu_virtual_after_ns;
            event->callback_due_delta_ns =
                delta > (uint64_t)INT64_MAX ? INT64_MIN : -(int64_t)delta;
        }
    }
    event->callback_watch_armed = guest.callback_watch_armed ? 1 : 0;
    event->callback_overdue_latched =
        guest.callback_overdue_latched ? 1 : 0;
    event->callback_target = guest.callback_target;
    event->callback_state_valid = guest.enabled ? 1 : 0;

    xemu_debug_tools_ptimer_irq_delivery_trace_get_status(&ptimer);
    event->ptimer_irq_active = ptimer.active ? 1 : 0;
    event->ptimer_irq_set_virtual_ns = ptimer.active_set_virtual_ns;
    event->ptimer_irq_age_ns = ptimer.active_age_ns;
    event->ptimer_state_valid = ptimer.enabled ? 1 : 0;
}

static void host_stall_store_event(XemuDebugToolsHostStallEvent *event)
{
    if (event == NULL || !qatomic_read(&g_host_stall.enabled)) {
        return;
    }

    host_stall_fill_guest_correlation(event);
    host_stall_init();
    qemu_mutex_lock(&g_host_stall.lock);
    if (!qatomic_read(&g_host_stall.enabled)) {
        qemu_mutex_unlock(&g_host_stall.lock);
        return;
    }

    event->sequence = g_host_stall.sequence++;
    g_host_stall.events[g_host_stall.write_index] = *event;
    g_host_stall.write_index =
        (g_host_stall.write_index + 1) % XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY;
    if (g_host_stall.count < XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY) {
        ++g_host_stall.count;
    } else {
        ++g_host_stall.overwritten_events;
    }
    ++g_host_stall.total_events;

    if (event->type == XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_VCPU_SAMPLE) {
        ++g_host_stall.vcpu_events;
        g_host_stall.worst_vcpu_wall_ns =
            MAX(g_host_stall.worst_vcpu_wall_ns, event->wall_span_ns);
        g_host_stall.worst_vcpu_offcpu_ns =
            MAX(g_host_stall.worst_vcpu_offcpu_ns, event->off_cpu_ns);
    } else if (event->type ==
               XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_MAIN_LOOP_WAIT) {
        ++g_host_stall.main_loop_events;
        if (event->wait_excess_ns > 0) {
            g_host_stall.worst_main_loop_excess_ns = MAX(
                g_host_stall.worst_main_loop_excess_ns,
                (uint64_t)event->wait_excess_ns);
        }
    }
    if (event->classification ==
        XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED) {
        ++g_host_stall.pagefault_correlated_events;
    }
    if (event->classification ==
        XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_HOST_OFFCPU) {
        ++g_host_stall.offcpu_events;
    }
    if (event->classification ==
        XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_THREAD_BUSY) {
        ++g_host_stall.busy_events;
    }
    g_host_stall.worst_page_fault_delta = MAX(
        g_host_stall.worst_page_fault_delta, event->page_fault_delta);
    qemu_mutex_unlock(&g_host_stall.lock);
}

#endif /* _WIN32 */

int xemu_debug_tools_host_stall_trace_active(void)
{
    return qatomic_read(&g_host_stall.enabled);
}

void xemu_debug_tools_host_stall_trace_set_enabled(int enabled)
{
    host_stall_init();
    qemu_mutex_lock(&g_host_stall.lock);
    if (enabled && !qatomic_read(&g_host_stall.enabled)) {
        memset(&g_host_stall.vcpu_sample, 0, sizeof(g_host_stall.vcpu_sample));
        memset(&g_host_stall.vcpu_process_baseline, 0,
               sizeof(g_host_stall.vcpu_process_baseline));
        memset(&g_host_stall.main_wait, 0, sizeof(g_host_stall.main_wait));
        memset(&g_host_stall.main_process_baseline, 0,
               sizeof(g_host_stall.main_process_baseline));
    }
    qatomic_set(&g_host_stall.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_host_stall.lock);
}

void xemu_debug_tools_host_stall_trace_clear(void)
{
    int enabled;

    host_stall_init();
    qemu_mutex_lock(&g_host_stall.lock);
    enabled = qatomic_read(&g_host_stall.enabled);
    memset(g_host_stall.events, 0, sizeof(g_host_stall.events));
    g_host_stall.sequence = 0;
    g_host_stall.total_events = 0;
    g_host_stall.overwritten_events = 0;
    g_host_stall.vcpu_events = 0;
    g_host_stall.main_loop_events = 0;
    g_host_stall.pagefault_correlated_events = 0;
    g_host_stall.offcpu_events = 0;
    g_host_stall.busy_events = 0;
    g_host_stall.worst_vcpu_wall_ns = 0;
    g_host_stall.worst_vcpu_offcpu_ns = 0;
    g_host_stall.worst_main_loop_excess_ns = 0;
    g_host_stall.worst_page_fault_delta = 0;
    g_host_stall.write_index = 0;
    g_host_stall.count = 0;
    memset(&g_host_stall.vcpu_sample, 0, sizeof(g_host_stall.vcpu_sample));
    memset(&g_host_stall.vcpu_process_baseline, 0,
           sizeof(g_host_stall.vcpu_process_baseline));
    memset(&g_host_stall.main_wait, 0, sizeof(g_host_stall.main_wait));
    memset(&g_host_stall.main_process_baseline, 0,
           sizeof(g_host_stall.main_process_baseline));
    qatomic_set(&g_host_stall.enabled, enabled);
    qemu_mutex_unlock(&g_host_stall.lock);
}

void xemu_debug_tools_host_stall_note_vcpu(CPUState *cpu)
{
#ifdef _WIN32
    XemuDebugToolsHostThreadSample current = { 0 };
    XemuDebugToolsHostThreadSample previous;
    XemuDebugToolsHostProcessSample process_after = { 0 };
    XemuDebugToolsHostStallEvent event = { 0 };
    uint64_t wall_ns;
    uint64_t cpu_delta = 0;
    uint64_t offcpu_ns = 0;
    uint64_t cycles_delta = 0;
    int capture = 0;

    if (!qatomic_read(&g_host_stall.enabled) || cpu == NULL) {
        return;
    }

    current.host_ns = host_now_ns();
    previous = g_host_stall.vcpu_sample;
    if (previous.valid && current.host_ns >= previous.host_ns &&
        current.host_ns - previous.host_ns <
            XEMU_DEBUG_TOOLS_HOST_STALL_SAMPLE_INTERVAL_NS) {
        return;
    }

    current.qemu_virtual_ns = virtual_now_ns();
    current.guest_pc = host_stall_guest_pc(cpu);
    host_stall_read_thread(&current.cpu_ns, &current.cycles,
                           &current.thread_id, &current.cpu_valid,
                           &current.cycles_valid);
    current.valid = 1;

    if (!previous.valid) {
        g_host_stall.vcpu_sample = current;
        host_stall_read_process(&g_host_stall.vcpu_process_baseline,
                                current.host_ns);
        return;
    }

    wall_ns = current.host_ns - previous.host_ns;
    if (current.cpu_valid && previous.cpu_valid &&
        current.cpu_ns >= previous.cpu_ns) {
        cpu_delta = current.cpu_ns - previous.cpu_ns;
        offcpu_ns = wall_ns > cpu_delta ? wall_ns - cpu_delta : 0;
    }
    if (current.cycles_valid && previous.cycles_valid &&
        current.cycles >= previous.cycles) {
        cycles_delta = current.cycles - previous.cycles;
    }

    capture = offcpu_ns >= XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS ||
              wall_ns >= XEMU_DEBUG_TOOLS_HOST_STALL_BUSY_THRESHOLD_NS;

    if (capture) {
        host_stall_read_process(&process_after, current.host_ns);
        event.type = XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_VCPU_SAMPLE;
        event.thread_id = current.thread_id;
        event.platform_counters_valid = 1;
        event.host_before_ns = previous.host_ns;
        event.host_after_ns = current.host_ns;
        event.wall_span_ns = wall_ns;
        event.thread_cpu_ns = cpu_delta;
        event.off_cpu_ns = offcpu_ns;
        event.thread_cycles_delta = cycles_delta;
        event.thread_cpu_valid = current.cpu_valid && previous.cpu_valid;
        event.thread_cycles_valid = current.cycles_valid && previous.cycles_valid;
        event.qemu_virtual_before_ns = previous.qemu_virtual_ns;
        event.qemu_virtual_after_ns = current.qemu_virtual_ns;
        event.guest_pc_before = previous.guest_pc;
        event.guest_pc_after = current.guest_pc;
        host_stall_fill_process_delta(&event,
            &g_host_stall.vcpu_process_baseline, &process_after);

        if (event.process_memory_valid && event.page_fault_delta != 0 &&
            offcpu_ns >= XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS) {
            event.classification =
                XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED;
        } else if (offcpu_ns >=
                   XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS) {
            event.classification = XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_HOST_OFFCPU;
        } else if (event.thread_cpu_valid && wall_ns != 0 &&
                   cpu_delta * 100ULL >= wall_ns * 80ULL) {
            event.classification = XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_THREAD_BUSY;
        } else {
            event.classification = XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MIXED;
        }
        host_stall_store_event(&event);
        if (process_after.valid) {
            g_host_stall.vcpu_process_baseline = process_after;
        }
    } else if (!g_host_stall.vcpu_process_baseline.valid ||
               current.host_ns - g_host_stall.vcpu_process_baseline.host_ns >=
                   XEMU_DEBUG_TOOLS_HOST_STALL_PROCESS_SAMPLE_NS) {
        host_stall_read_process(&g_host_stall.vcpu_process_baseline,
                                current.host_ns);
    }

    g_host_stall.vcpu_sample = current;
#else
    (void)cpu;
#endif
}

void xemu_debug_tools_host_stall_main_loop_wait_begin(int64_t timeout_ns)
{
#ifdef _WIN32
    XemuDebugToolsHostMainLoopWait *wait = &g_host_stall.main_wait;

    if (!qatomic_read(&g_host_stall.enabled)) {
        return;
    }
    memset(wait, 0, sizeof(*wait));
    wait->host_ns = host_now_ns();
    wait->qemu_virtual_ns = virtual_now_ns();
    wait->timeout_ns = timeout_ns;
    host_stall_read_thread(&wait->cpu_ns, &wait->cycles, &wait->thread_id,
                           &wait->cpu_valid, &wait->cycles_valid);
    wait->active = 1;

    if (!g_host_stall.main_process_baseline.valid ||
        wait->host_ns - g_host_stall.main_process_baseline.host_ns >=
            XEMU_DEBUG_TOOLS_HOST_STALL_PROCESS_SAMPLE_NS) {
        host_stall_read_process(&g_host_stall.main_process_baseline,
                                wait->host_ns);
    }
#else
    (void)timeout_ns;
#endif
}

void xemu_debug_tools_host_stall_main_loop_wait_end(int64_t timeout_ns)
{
#ifdef _WIN32
    XemuDebugToolsHostMainLoopWait before = g_host_stall.main_wait;
    XemuDebugToolsHostProcessSample process_after = { 0 };
    XemuDebugToolsHostStallEvent event = { 0 };
    uint64_t host_after;
    uint64_t virtual_after;
    uint64_t cpu_after = 0;
    uint64_t cycles_after = 0;
    uint64_t cpu_delta = 0;
    uint64_t cycles_delta = 0;
    uint64_t wall_ns;
    uint64_t offcpu_ns = 0;
    uint32_t thread_id = 0;
    int cpu_valid = 0;
    int cycles_valid = 0;
    int64_t effective_timeout;
    int64_t excess_ns;

    if (!qatomic_read(&g_host_stall.enabled) || !before.active) {
        return;
    }
    g_host_stall.main_wait.active = 0;
    host_after = host_now_ns();
    virtual_after = virtual_now_ns();
    host_stall_read_thread(&cpu_after, &cycles_after, &thread_id,
                           &cpu_valid, &cycles_valid);
    if (host_after < before.host_ns) {
        return;
    }
    wall_ns = host_after - before.host_ns;
    if (cpu_valid && before.cpu_valid && cpu_after >= before.cpu_ns) {
        cpu_delta = cpu_after - before.cpu_ns;
        offcpu_ns = wall_ns > cpu_delta ? wall_ns - cpu_delta : 0;
    }
    if (cycles_valid && before.cycles_valid && cycles_after >= before.cycles) {
        cycles_delta = cycles_after - before.cycles;
    }

    effective_timeout = timeout_ns >= 0 ? timeout_ns : before.timeout_ns;
    if (effective_timeout < 0) {
        return;
    }
    excess_ns = wall_ns > (uint64_t)effective_timeout ?
        (int64_t)(wall_ns - (uint64_t)effective_timeout) : 0;
    if (excess_ns < (int64_t)XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS) {
        if (!g_host_stall.main_process_baseline.valid ||
            host_after - g_host_stall.main_process_baseline.host_ns >=
                XEMU_DEBUG_TOOLS_HOST_STALL_PROCESS_SAMPLE_NS) {
            host_stall_read_process(&g_host_stall.main_process_baseline,
                                    host_after);
        }
        return;
    }

    host_stall_read_process(&process_after, host_after);
    event.type = XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_MAIN_LOOP_WAIT;
    event.thread_id = thread_id != 0 ? thread_id : before.thread_id;
    event.platform_counters_valid = 1;
    event.host_before_ns = before.host_ns;
    event.host_after_ns = host_after;
    event.wall_span_ns = wall_ns;
    event.thread_cpu_ns = cpu_delta;
    event.off_cpu_ns = offcpu_ns;
    event.thread_cycles_delta = cycles_delta;
    event.thread_cpu_valid = cpu_valid && before.cpu_valid;
    event.thread_cycles_valid = cycles_valid && before.cycles_valid;
    event.requested_timeout_ns = effective_timeout;
    event.wait_excess_ns = excess_ns;
    event.qemu_virtual_before_ns = before.qemu_virtual_ns;
    event.qemu_virtual_after_ns = virtual_after;
    host_stall_fill_process_delta(&event,
        &g_host_stall.main_process_baseline, &process_after);
    if (event.process_memory_valid && event.page_fault_delta != 0) {
        event.classification =
            XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED;
    } else {
        event.classification =
            XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MAIN_LOOP_EXCESS;
    }
    host_stall_store_event(&event);
    if (process_after.valid) {
        g_host_stall.main_process_baseline = process_after;
    }
#else
    (void)timeout_ns;
#endif
}

void xemu_debug_tools_host_stall_trace_get_status(
    XemuDebugToolsHostStallStatus *status)
{
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    host_stall_init();
    qemu_mutex_lock(&g_host_stall.lock);
    status->enabled = qatomic_read(&g_host_stall.enabled);
#ifdef _WIN32
    status->windows_supported = 1;
#else
    status->windows_supported = 0;
#endif
    status->count = g_host_stall.count;
    status->total_events = g_host_stall.total_events;
    status->overwritten_events = g_host_stall.overwritten_events;
    status->vcpu_events = g_host_stall.vcpu_events;
    status->main_loop_events = g_host_stall.main_loop_events;
    status->pagefault_correlated_events = g_host_stall.pagefault_correlated_events;
    status->offcpu_events = g_host_stall.offcpu_events;
    status->busy_events = g_host_stall.busy_events;
    status->worst_vcpu_wall_ns = g_host_stall.worst_vcpu_wall_ns;
    status->worst_vcpu_offcpu_ns = g_host_stall.worst_vcpu_offcpu_ns;
    status->worst_main_loop_excess_ns = g_host_stall.worst_main_loop_excess_ns;
    status->worst_page_fault_delta = g_host_stall.worst_page_fault_delta;
    status->sample_interval_ns = XEMU_DEBUG_TOOLS_HOST_STALL_SAMPLE_INTERVAL_NS;
    status->offcpu_threshold_ns = XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS;
    status->busy_threshold_ns = XEMU_DEBUG_TOOLS_HOST_STALL_BUSY_THRESHOLD_NS;
    status->process_sample_interval_ns =
        XEMU_DEBUG_TOOLS_HOST_STALL_PROCESS_SAMPLE_NS;
    qemu_mutex_unlock(&g_host_stall.lock);
}

size_t xemu_debug_tools_host_stall_trace_snapshot(
    XemuDebugToolsHostStallEvent *events, size_t capacity)
{
    size_t count;
    size_t start;
    size_t i;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    host_stall_init();
    qemu_mutex_lock(&g_host_stall.lock);
    count = MIN(g_host_stall.count, capacity);
    start = (g_host_stall.write_index + XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY -
             g_host_stall.count) % XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY;
    if (count < g_host_stall.count) {
        start = (start + g_host_stall.count - count) %
                XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY;
    }
    for (i = 0; i < count; ++i) {
        events[i] = g_host_stall.events[
            (start + i) % XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY];
    }
    qemu_mutex_unlock(&g_host_stall.lock);
    return count;
}
