/* Info: NV2A reports FLIP/VBlank transitions; Diagnostics owns analysis. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsFlipStallTraceEventType {
    XEMU_DEBUG_TOOLS_FLIP_SET_READ = 1,
    XEMU_DEBUG_TOOLS_FLIP_SET_WRITE,
    XEMU_DEBUG_TOOLS_FLIP_SET_MODULO,
    XEMU_DEBUG_TOOLS_FLIP_INCREMENT_WRITE,
    XEMU_DEBUG_TOOLS_FLIP_STALL_BEGIN,
    XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_BEGIN,
    XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_END,
    XEMU_DEBUG_TOOLS_FLIP_WAITING_SET,
    XEMU_DEBUG_TOOLS_FLIP_VBLANK_IRQ,
    XEMU_DEBUG_TOOLS_FLIP_VBLANK_READ_INCREMENT,
    XEMU_DEBUG_TOOLS_FLIP_PFIFO_CHECK_STALL,
    XEMU_DEBUG_TOOLS_FLIP_PFIFO_RELEASE,
} XemuDebugToolsFlipStallTraceEventType;

void xemu_debug_tools_flip_stall_trace_record(
    unsigned int event_type, const void *pgraph_state,
    uint32_t method, uint32_t parameter, uint32_t value0, uint32_t value1,
    uint64_t duration_ns);
void xemu_debug_tools_flip_stall_trace_begin(const void *pgraph_state);
void xemu_debug_tools_flip_stall_trace_end(const void *pgraph_state);

#ifdef __cplusplus
}
#endif
