/* Info: One-shot pinned forensic capture for overdue D3D InputBuffer callbacks. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "d3d-callback-capture.h"

typedef struct XemuDebugToolsD3dCallbackCaptureState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    int latched;
    int capture_in_progress;
    uint64_t capture_count;
    uint64_t transient_recoveries;
    uint64_t last_recovery_virtual_ns;
    int64_t last_recovery_delta_ns;
    XemuDebugToolsD3dCallbackCaptureSnapshot snapshot;
} XemuDebugToolsD3dCallbackCaptureState;

static XemuDebugToolsD3dCallbackCaptureState g_d3d_callback_capture;

static void d3d_callback_capture_init(void)
{
    if (!g_d3d_callback_capture.initialized) {
        qemu_mutex_init(&g_d3d_callback_capture.lock);
        g_d3d_callback_capture.initialized = true;
    }
}

int xemu_debug_tools_d3d_callback_capture_active(void)
{
    return qatomic_read(&g_d3d_callback_capture.enabled) != 0;
}

void xemu_debug_tools_d3d_callback_capture_set_enabled(int enabled)
{
    d3d_callback_capture_init();
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    qatomic_set(&g_d3d_callback_capture.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);

    if (enabled) {
        /* This watchdog depends on the exact-PC Guest Timer/Deadline trace and
         * pins small generic tails only when the callback is already overdue.
         * Do not disable dependencies automatically when the watchdog is
         * turned off because the user may have enabled them independently. */
        xemu_debug_tools_guest_timer_deadline_trace_set_enabled(1);
        xemu_debug_tools_qemu_timer_trace_set_enabled(1);
        xemu_debug_tools_bql_trace_set_enabled(1);
        xemu_debug_tools_main_loop_lock_trace_set_enabled(1);
        xemu_debug_tools_pgraph_lock_trace_set_enabled(1);
        xemu_debug_tools_scheduler_trace_set_enabled(1);
    }
}

void xemu_debug_tools_d3d_callback_capture_clear(void)
{
    d3d_callback_capture_init();
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    g_d3d_callback_capture.latched = 0;
    g_d3d_callback_capture.capture_in_progress = 0;
    g_d3d_callback_capture.transient_recoveries = 0;
    g_d3d_callback_capture.last_recovery_virtual_ns = 0;
    g_d3d_callback_capture.last_recovery_delta_ns = 0;
    memset(&g_d3d_callback_capture.snapshot, 0,
           sizeof(g_d3d_callback_capture.snapshot));
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);
}

void xemu_debug_tools_d3d_callback_capture_note_overdue(
    const XemuDebugToolsD3dCallbackCaptureTrigger *trigger)
{
    XemuDebugToolsD3dCallbackCaptureSnapshot *capture;
    uint64_t capture_start_host_ns;
    uint64_t capture_end_host_ns;

    if (trigger == NULL ||
        trigger->overdue_ns < XEMU_DEBUG_TOOLS_D3D_CALLBACK_GRACE_NS ||
        !qatomic_read(&g_d3d_callback_capture.enabled)) {
        return;
    }

    d3d_callback_capture_init();
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    if (!qatomic_read(&g_d3d_callback_capture.enabled) ||
        g_d3d_callback_capture.latched ||
        g_d3d_callback_capture.capture_in_progress) {
        qemu_mutex_unlock(&g_d3d_callback_capture.lock);
        return;
    }
    g_d3d_callback_capture.capture_in_progress = 1;
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);

    capture = g_new0(XemuDebugToolsD3dCallbackCaptureSnapshot, 1);
    if (capture == NULL) {
        qemu_mutex_lock(&g_d3d_callback_capture.lock);
        g_d3d_callback_capture.capture_in_progress = 0;
        qemu_mutex_unlock(&g_d3d_callback_capture.lock);
        return;
    }

    capture_start_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    capture->status.enabled = 1;
    capture->status.latched = 1;
    capture->status.capture_in_progress = 0;
    capture->status.grace_ns = XEMU_DEBUG_TOOLS_D3D_CALLBACK_GRACE_NS;
    capture->status.trigger = *trigger;

    /* The trigger is already fixed before these snapshots begin. Keeping the
     * tails small lets us retain the relevant IRQ/scheduler/lock state without
     * creating another high-volume recorder. */
    xemu_debug_tools_bql_trace_get_status(&capture->status.bql_status);
    xemu_debug_tools_main_loop_lock_trace_get_status(
        &capture->status.main_loop_lock_status);
    xemu_debug_tools_pgraph_lock_trace_get_status(&capture->status.pgraph_status);
    xemu_debug_tools_scheduler_trace_get_status(&capture->status.scheduler_status);
    xemu_debug_tools_guest_timer_deadline_trace_get_status(
        &capture->status.guest_timer_status);

    capture->status.qtimer_count = xemu_debug_tools_qemu_timer_trace_snapshot(
        capture->qtimer, XEMU_DEBUG_TOOLS_D3D_CALLBACK_QTIMER_EVENTS);
    capture->status.bql_count = xemu_debug_tools_bql_trace_snapshot(
        capture->bql, XEMU_DEBUG_TOOLS_D3D_CALLBACK_BQL_EVENTS);
    capture->status.main_loop_lock_count =
        xemu_debug_tools_main_loop_lock_trace_snapshot(
            capture->main_loop_lock,
            XEMU_DEBUG_TOOLS_D3D_CALLBACK_MAIN_LOOP_LOCK_EVENTS);
    capture->status.pgraph_count = xemu_debug_tools_pgraph_lock_trace_snapshot(
        capture->pgraph, XEMU_DEBUG_TOOLS_D3D_CALLBACK_PGRAPH_EVENTS);
    capture->status.scheduler_count = xemu_debug_tools_scheduler_trace_snapshot(
        capture->scheduler, XEMU_DEBUG_TOOLS_D3D_CALLBACK_SCHEDULER_EVENTS);
    capture->status.guest_timer_count =
        xemu_debug_tools_guest_timer_deadline_trace_snapshot(
            capture->guest_timer,
            XEMU_DEBUG_TOOLS_D3D_CALLBACK_GUEST_TIMER_EVENTS);

    capture_end_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    capture->status.capture_duration_host_ns =
        capture_end_host_ns - capture_start_host_ns;

    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    if (qatomic_read(&g_d3d_callback_capture.enabled)) {
        ++g_d3d_callback_capture.capture_count;
        capture->status.capture_count = g_d3d_callback_capture.capture_count;
        g_d3d_callback_capture.snapshot = *capture;
        g_d3d_callback_capture.latched = 1;
    }
    g_d3d_callback_capture.capture_in_progress = 0;
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);
    g_free(capture);
}

void xemu_debug_tools_d3d_callback_capture_note_recovered(
    uint64_t input_sequence, uint64_t callback_entry_virtual_ns)
{
    d3d_callback_capture_init();
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    if (g_d3d_callback_capture.latched &&
        g_d3d_callback_capture.snapshot.status.trigger.input_sequence ==
            input_sequence) {
        const uint64_t due =
            g_d3d_callback_capture.snapshot.status.trigger.expected_due_ns;

        ++g_d3d_callback_capture.transient_recoveries;
        g_d3d_callback_capture.last_recovery_virtual_ns =
            callback_entry_virtual_ns;
        g_d3d_callback_capture.last_recovery_delta_ns =
            due != 0 && callback_entry_virtual_ns >= due
                ? (int64_t)(callback_entry_virtual_ns - due)
                : (due != 0
                       ? -(int64_t)(due - callback_entry_virtual_ns)
                       : 0);

        /* A recovered overdue callback is useful evidence, but it must not
         * consume the one-shot slot needed for a later permanent failure.
         * The detailed guest lifecycle ring retains the recovered path. */
        g_d3d_callback_capture.latched = 0;
    }
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);
}

void xemu_debug_tools_d3d_callback_capture_get_status(
    XemuDebugToolsD3dCallbackCaptureStatus *status)
{
    if (status == NULL) {
        return;
    }
    d3d_callback_capture_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    if (g_d3d_callback_capture.latched) {
        *status = g_d3d_callback_capture.snapshot.status;
    }
    status->enabled = qatomic_read(&g_d3d_callback_capture.enabled) ? 1 : 0;
    status->latched = g_d3d_callback_capture.latched;
    status->capture_in_progress = g_d3d_callback_capture.capture_in_progress;
    status->capture_count = g_d3d_callback_capture.capture_count;
    status->transient_recoveries =
        g_d3d_callback_capture.transient_recoveries;
    status->last_recovery_virtual_ns =
        g_d3d_callback_capture.last_recovery_virtual_ns;
    status->last_recovery_delta_ns =
        g_d3d_callback_capture.last_recovery_delta_ns;
    status->grace_ns = XEMU_DEBUG_TOOLS_D3D_CALLBACK_GRACE_NS;
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);
}

int xemu_debug_tools_d3d_callback_capture_snapshot(
    XemuDebugToolsD3dCallbackCaptureSnapshot *snapshot)
{
    if (snapshot == NULL) {
        return 0;
    }
    d3d_callback_capture_init();
    memset(snapshot, 0, sizeof(*snapshot));
    qemu_mutex_lock(&g_d3d_callback_capture.lock);
    if (!g_d3d_callback_capture.latched) {
        qemu_mutex_unlock(&g_d3d_callback_capture.lock);
        return 0;
    }
    *snapshot = g_d3d_callback_capture.snapshot;
    qemu_mutex_unlock(&g_d3d_callback_capture.lock);
    return 1;
}
