/* Info: Core MMIO code emits observations; Diagnostics owns trace state. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsMmioAccessType {
    XEMU_DEBUG_TOOLS_MMIO_ACCESS_READ = 1,
    XEMU_DEBUG_TOOLS_MMIO_ACCESS_WRITE = 2,
} XemuDebugToolsMmioAccessType;

typedef struct XemuDebugToolsMmioTraceScope {
    uint64_t host_start_ns;
    uint64_t virtual_start_ns;
    uint64_t guest_pc_start;
    uint64_t guest_vaddr;
    uint64_t guest_paddr;
    uint64_t region_offset;
    const void *memory_region;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t guest_pc_start_valid;
    uint32_t size;
    uint32_t access_type;
    uint32_t active;
} XemuDebugToolsMmioTraceScope;

void xemu_debug_tools_mmio_trace_begin(XemuDebugToolsMmioTraceScope *scope,
                                       const void *memory_region,
                                       uint64_t region_offset,
                                       uint64_t guest_vaddr,
                                       uint64_t guest_paddr,
                                       uint32_t size,
                                       uint32_t access_type);
void xemu_debug_tools_mmio_trace_end(XemuDebugToolsMmioTraceScope *scope);

#ifdef __cplusplus
}
#endif
