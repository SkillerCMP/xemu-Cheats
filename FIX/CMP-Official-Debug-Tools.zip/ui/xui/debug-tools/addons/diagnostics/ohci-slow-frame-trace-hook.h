/* Info: OHCI emits frame timing samples; Diagnostics owns thresholds and storage. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY 128
#define XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_DEFAULT_THRESHOLD_NS 1000000ULL
#define XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_MIN_THRESHOLD_NS 10000ULL
#define XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_MAX_THRESHOLD_NS 10000000000ULL

typedef enum XemuDebugToolsOhciListKind {
    XEMU_DEBUG_TOOLS_OHCI_LIST_NONE = 0,
    XEMU_DEBUG_TOOLS_OHCI_LIST_PERIODIC = 1,
    XEMU_DEBUG_TOOLS_OHCI_LIST_CONTROL = 2,
    XEMU_DEBUG_TOOLS_OHCI_LIST_BULK = 3,
} XemuDebugToolsOhciListKind;

typedef enum XemuDebugToolsOhciLeafOperation {
    XEMU_DEBUG_TOOLS_OHCI_LEAF_NONE = 0,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_ED_READ = 1,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_ED_WRITE = 2,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_TD_READ = 3,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_TD_WRITE = 4,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_DMA_TO_DEVICE = 5,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_DEVICE_LOOKUP = 6,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_USB_HANDLE_PACKET = 7,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_DMA_FROM_DEVICE = 8,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_ASYNC_FLUSH = 9,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_ENDPOINT_STOP = 10,
    XEMU_DEBUG_TOOLS_OHCI_LEAF_ISO_TD = 11,
} XemuDebugToolsOhciLeafOperation;

typedef struct XemuDebugToolsOhciSlowFrameEvent {
    uint64_t sequence;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t host_duration_ns;
    uint64_t virtual_start_ns;
    uint64_t virtual_end_ns;
    int64_t virtual_duration_ns;
    uint64_t threshold_ns;

    uint64_t hcca_read_ns;
    uint64_t periodic_list_ns;
    uint64_t stop_endpoints_ns;
    uint64_t control_list_ns;
    uint64_t bulk_list_ns;
    uint64_t done_sof_ns;
    uint64_t hcca_write_ns;

    uint64_t ed_read_ns;
    uint64_t ed_write_ns;
    uint64_t td_read_ns;
    uint64_t td_write_ns;
    uint64_t dma_to_device_ns;
    uint64_t device_lookup_ns;
    uint64_t usb_handle_packet_ns;
    uint64_t dma_from_device_ns;
    uint64_t async_flush_ns;
    uint64_t endpoint_stop_ns;
    uint64_t iso_td_ns;

    uint64_t worst_leaf_ns;
    uint32_t worst_leaf_type;
    uint32_t worst_list_kind;
    uint32_t worst_ed_address;
    uint32_t worst_td_address;
    int32_t worst_direction;
    int32_t worst_pid;
    int32_t worst_packet_status;
    uint32_t worst_function_address;
    uint32_t worst_endpoint;
    uint32_t worst_packet_length;

    uint32_t frame_number;
    uint32_t ctl;
    uint32_t status;
    uint32_t hcca;
    uint32_t ed_count;
    uint32_t td_count;
    uint32_t iso_td_count;
    uint32_t usb_packet_count;
    uint32_t dma_to_device_count;
    uint32_t dma_from_device_count;
    int32_t thread_id;
    uint32_t bql_held;
} XemuDebugToolsOhciSlowFrameEvent;

typedef struct XemuDebugToolsOhciSlowFrameStatus {
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
} XemuDebugToolsOhciSlowFrameStatus;

/* Fast hot-path query. Returns 0 while disabled. */
uint64_t xemu_debug_tools_ohci_slow_frame_trace_threshold_ns(void);

/* Called by OHCI only after a frame has already crossed the threshold. */
void xemu_debug_tools_ohci_slow_frame_trace_record(
    const XemuDebugToolsOhciSlowFrameEvent *event);

void xemu_debug_tools_ohci_slow_frame_trace_set_enabled(int enabled);
void xemu_debug_tools_ohci_slow_frame_trace_set_threshold_ns(uint64_t threshold_ns);
void xemu_debug_tools_ohci_slow_frame_trace_clear(void);
int xemu_debug_tools_ohci_slow_frame_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_ohci_slow_frame_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_ohci_slow_frame_trace_get_buffer_capacity(void);
void xemu_debug_tools_ohci_slow_frame_trace_get_status(
    XemuDebugToolsOhciSlowFrameStatus *status);
size_t xemu_debug_tools_ohci_slow_frame_trace_snapshot(
    XemuDebugToolsOhciSlowFrameEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
