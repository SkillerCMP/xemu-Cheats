/* Info: Focused guest D3D timer-object/list state snapshots for Patch 305.3. */

#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/bswap.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"

#include "d3d-timer-state-trace.h"

typedef struct XemuD3dTimerStateTraceState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;

    uint32_t current_timer_object;
    uint64_t current_input_sequence;
    uint64_t current_deadline_sequence;
    uint32_t current_probe_count;

    int schedule_snapshot_valid;
    uint32_t schedule_dwords[XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS];
    int last_good_snapshot_valid;
    uint32_t last_good_dwords[XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS];

    uint64_t completed_good_cycles;
    uint64_t overdue_cycles;
    uint64_t rejected_cycles;

    XemuDebugToolsD3dTimerStateEvent
        events[XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY];
} XemuD3dTimerStateTraceState;

static XemuD3dTimerStateTraceState g_d3d_timer_state;

static void d3d_timer_state_init(void)
{
    if (!g_d3d_timer_state.initialized) {
        qemu_mutex_init(&g_d3d_timer_state.lock);
        g_d3d_timer_state.initialized = true;
    }
}

static void d3d_timer_state_reset_locked(void)
{
    g_d3d_timer_state.count = 0;
    g_d3d_timer_state.write_index = 0;
    g_d3d_timer_state.total_events = 0;
    g_d3d_timer_state.overwritten_events = 0;
    qatomic_set(&g_d3d_timer_state.current_timer_object, 0);
    g_d3d_timer_state.current_input_sequence = 0;
    g_d3d_timer_state.current_deadline_sequence = 0;
    qatomic_set(&g_d3d_timer_state.current_probe_count, 0);
    g_d3d_timer_state.schedule_snapshot_valid = 0;
    memset(g_d3d_timer_state.schedule_dwords, 0,
           sizeof(g_d3d_timer_state.schedule_dwords));
    g_d3d_timer_state.last_good_snapshot_valid = 0;
    memset(g_d3d_timer_state.last_good_dwords, 0,
           sizeof(g_d3d_timer_state.last_good_dwords));
    g_d3d_timer_state.completed_good_cycles = 0;
    g_d3d_timer_state.overdue_cycles = 0;
    g_d3d_timer_state.rejected_cycles = 0;
    memset(g_d3d_timer_state.events, 0, sizeof(g_d3d_timer_state.events));
}

static uint32_t d3d_timer_state_probe_type(uint32_t pc)
{
    switch (pc) {
    case 0x00223FE9u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_DUE_ENTRY;
    case 0x00223314u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SELECT;
    case 0x00223352u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_LOAD;
    case 0x0022336Du:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_CALL;
    case 0x002239A0u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SCAN;
    case 0x00223760u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_LIST;
    case 0x002237F7u:
    case 0x00223801u:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_IRQ_CHECK;
    default:
        return XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE;
    }
}

static bool d3d_timer_state_read(CPUState *cpu, uint32_t timer_object,
                                 uint32_t *dwords)
{
    uint8_t bytes[XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS * sizeof(uint32_t)];

    if (cpu == NULL || timer_object == 0 || dwords == NULL ||
        cpu_memory_rw_debug(cpu, timer_object, bytes, sizeof(bytes), false) != 0) {
        return false;
    }
    for (size_t i = 0; i < XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS; ++i) {
        dwords[i] = ldl_le_p(bytes + i * sizeof(uint32_t));
    }
    return true;
}

static uint64_t d3d_timer_state_changed_mask(const uint32_t *a,
                                             const uint32_t *b)
{
    uint64_t mask = 0;

    for (size_t i = 0; i < XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS; ++i) {
        if (a[i] != b[i]) {
            mask |= 1ULL << i;
        }
    }
    return mask;
}

static void d3d_timer_state_store_locked(
    XemuDebugToolsD3dTimerStateEvent *event)
{
    const size_t slot = g_d3d_timer_state.write_index;

    event->sequence = g_d3d_timer_state.total_events++;
    g_d3d_timer_state.events[slot] = *event;
    g_d3d_timer_state.write_index =
        (slot + 1) % XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY;
    if (g_d3d_timer_state.count < XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY) {
        ++g_d3d_timer_state.count;
    } else {
        ++g_d3d_timer_state.overwritten_events;
    }
}

int xemu_debug_tools_d3d_timer_state_trace_active(void)
{
    return qatomic_read(&g_d3d_timer_state.enabled) != 0;
}

int xemu_debug_tools_d3d_timer_state_trace_should_probe(uint32_t guest_pc)
{
    if (!qatomic_read(&g_d3d_timer_state.enabled) ||
        qatomic_read(&g_d3d_timer_state.current_timer_object) == 0 ||
        qatomic_read(&g_d3d_timer_state.current_probe_count) >=
            XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_MAX_PROBES_PER_CYCLE) {
        return 0;
    }
    return d3d_timer_state_probe_type(guest_pc) !=
           XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE;
}

void xemu_debug_tools_d3d_timer_state_trace_set_enabled(int enabled)
{
    d3d_timer_state_init();
    qemu_mutex_lock(&g_d3d_timer_state.lock);
    if (enabled && !qatomic_read(&g_d3d_timer_state.enabled)) {
        d3d_timer_state_reset_locked();
    }
    qatomic_set(&g_d3d_timer_state.enabled, enabled ? 1 : 0);
    if (!enabled) {
        qatomic_set(&g_d3d_timer_state.current_timer_object, 0);
        qatomic_set(&g_d3d_timer_state.current_probe_count, 0);
    }
    qemu_mutex_unlock(&g_d3d_timer_state.lock);
}

void xemu_debug_tools_d3d_timer_state_trace_clear(void)
{
    d3d_timer_state_init();
    qemu_mutex_lock(&g_d3d_timer_state.lock);
    d3d_timer_state_reset_locked();
    qemu_mutex_unlock(&g_d3d_timer_state.lock);
}

void xemu_debug_tools_d3d_timer_state_trace_note(
    CPUState *cpu, uint32_t event_type, uint32_t guest_pc,
    uint32_t timer_object, uint64_t input_sequence,
    uint64_t deadline_sequence)
{
    XemuDebugToolsD3dTimerStateEvent event = { 0 };
    uint32_t object;
    bool read_valid;

    if (!qatomic_read(&g_d3d_timer_state.enabled) || cpu == NULL) {
        return;
    }

    d3d_timer_state_init();
    if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE) {
        event_type = d3d_timer_state_probe_type(guest_pc);
        if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE) {
            return;
        }
    }

    object = timer_object != 0 ? timer_object
                               : qatomic_read(&g_d3d_timer_state.current_timer_object);
    if (object == 0) {
        return;
    }

    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.input_sequence = input_sequence;
    event.deadline_sequence = deadline_sequence;
    event.event_type = event_type;
    event.guest_pc = guest_pc;
    event.timer_object = object;
    read_valid = d3d_timer_state_read(cpu, object, event.dwords);
    event.read_valid = read_valid ? 1 : 0;

    qemu_mutex_lock(&g_d3d_timer_state.lock);
    if (!qatomic_read(&g_d3d_timer_state.enabled)) {
        qemu_mutex_unlock(&g_d3d_timer_state.lock);
        return;
    }

    if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_CALL) {
        qatomic_set(&g_d3d_timer_state.current_timer_object, object);
        g_d3d_timer_state.current_input_sequence = input_sequence;
        g_d3d_timer_state.current_deadline_sequence = deadline_sequence;
        qatomic_set(&g_d3d_timer_state.current_probe_count, 0);
        g_d3d_timer_state.schedule_snapshot_valid = read_valid ? 1 : 0;
        if (read_valid) {
            memcpy(g_d3d_timer_state.schedule_dwords, event.dwords,
                   sizeof(event.dwords));
        }
    } else if (event_type >=
                   XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_DUE_ENTRY &&
               event_type <=
                   XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_IRQ_CHECK) {
        qatomic_inc(&g_d3d_timer_state.current_probe_count);
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_OVERDUE) {
        ++g_d3d_timer_state.overdue_cycles;
    } else if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_D3D_REJECT) {
        ++g_d3d_timer_state.rejected_cycles;
    }

    if (read_valid && g_d3d_timer_state.schedule_snapshot_valid) {
        event.changed_from_schedule_mask = d3d_timer_state_changed_mask(
            event.dwords, g_d3d_timer_state.schedule_dwords);
    }
    if (read_valid && g_d3d_timer_state.last_good_snapshot_valid) {
        event.changed_from_last_good_mask = d3d_timer_state_changed_mask(
            event.dwords, g_d3d_timer_state.last_good_dwords);
    }

    d3d_timer_state_store_locked(&event);

    if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_ENTRY) {
        if (read_valid) {
            memcpy(g_d3d_timer_state.last_good_dwords, event.dwords,
                   sizeof(event.dwords));
            g_d3d_timer_state.last_good_snapshot_valid = 1;
        }
        ++g_d3d_timer_state.completed_good_cycles;
        qatomic_set(&g_d3d_timer_state.current_timer_object, 0);
        qatomic_set(&g_d3d_timer_state.current_probe_count, 0);
    } else if (event_type == XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_D3D_REJECT) {
        qatomic_set(&g_d3d_timer_state.current_timer_object, 0);
        qatomic_set(&g_d3d_timer_state.current_probe_count, 0);
    }

    qemu_mutex_unlock(&g_d3d_timer_state.lock);
}

void xemu_debug_tools_d3d_timer_state_trace_get_status(
    XemuDebugToolsD3dTimerStateStatus *status)
{
    if (status == NULL) {
        return;
    }
    d3d_timer_state_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_d3d_timer_state.lock);
    status->enabled = qatomic_read(&g_d3d_timer_state.enabled);
    status->count = g_d3d_timer_state.count;
    status->total_events = g_d3d_timer_state.total_events;
    status->overwritten_events = g_d3d_timer_state.overwritten_events;
    status->current_timer_object =
        qatomic_read(&g_d3d_timer_state.current_timer_object);
    status->current_input_sequence = g_d3d_timer_state.current_input_sequence;
    status->current_deadline_sequence =
        g_d3d_timer_state.current_deadline_sequence;
    status->current_probe_count =
        qatomic_read(&g_d3d_timer_state.current_probe_count);
    status->max_probes_per_cycle =
        XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_MAX_PROBES_PER_CYCLE;
    status->schedule_snapshot_valid = g_d3d_timer_state.schedule_snapshot_valid;
    status->last_good_snapshot_valid =
        g_d3d_timer_state.last_good_snapshot_valid;
    status->completed_good_cycles = g_d3d_timer_state.completed_good_cycles;
    status->overdue_cycles = g_d3d_timer_state.overdue_cycles;
    status->rejected_cycles = g_d3d_timer_state.rejected_cycles;
    qemu_mutex_unlock(&g_d3d_timer_state.lock);
}

size_t xemu_debug_tools_d3d_timer_state_trace_snapshot(
    XemuDebugToolsD3dTimerStateEvent *events, size_t capacity)
{
    size_t copy_count;
    size_t start;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    d3d_timer_state_init();
    qemu_mutex_lock(&g_d3d_timer_state.lock);
    copy_count = MIN(capacity, g_d3d_timer_state.count);
    start = (g_d3d_timer_state.write_index +
             XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY -
             g_d3d_timer_state.count) %
            XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY;
    if (copy_count < g_d3d_timer_state.count) {
        start = (start + g_d3d_timer_state.count - copy_count) %
                XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY;
    }
    for (size_t i = 0; i < copy_count; ++i) {
        events[i] = g_d3d_timer_state.events[
            (start + i) % XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY];
    }
    qemu_mutex_unlock(&g_d3d_timer_state.lock);
    return copy_count;
}
