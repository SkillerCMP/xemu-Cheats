/*
 * xemu Debug Tools - Diagnostics-owned PTIMER detailed timing trace.
 */
#pragma once

#include "ptimer-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY 4096

typedef struct XemuDebugToolsPtimerTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t ptimer_now;
    uint64_t alarm;
    int64_t alarm_delta_ns;
    uint64_t qemu_timer_expire_ns;
    int64_t qemu_timer_delta_ns;
    int64_t callback_lateness_ns;
    uint64_t guest_pc;
    uint64_t rdtsc_reference;
    uint32_t guest_pc_valid;
    uint32_t rdtsc_reference_valid;
    uint32_t pending_interrupts;
    uint32_t enabled_interrupts;
    uint32_t value;
    uint32_t previous_value;
    uint32_t event_type;
    uint32_t qemu_timer_pending;
} XemuDebugToolsPtimerTraceEvent;

typedef struct XemuDebugToolsPtimerTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
} XemuDebugToolsPtimerTraceStatus;

void xemu_debug_tools_ptimer_trace_set_enabled(int enabled);
void xemu_debug_tools_ptimer_trace_clear(void);
int xemu_debug_tools_ptimer_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_ptimer_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_ptimer_trace_get_buffer_capacity(void);
void xemu_debug_tools_ptimer_trace_get_status(
    XemuDebugToolsPtimerTraceStatus *status);
size_t xemu_debug_tools_ptimer_trace_snapshot(
    XemuDebugToolsPtimerTraceEvent *events,
    size_t capacity);

#ifdef __cplusplus
}
#endif
