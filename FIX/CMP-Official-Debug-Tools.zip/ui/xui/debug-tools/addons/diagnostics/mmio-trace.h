/* xemu Debug Tools - Diagnostics-owned long MMIO dispatch trace. */
#pragma once

#include "mmio-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_MMIO_TRACE_LONG_NS (1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX 96

typedef struct XemuDebugToolsMmioTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_start_ns;
    uint64_t qemu_virtual_end_ns;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t duration_host_ns;
    uint64_t duration_virtual_ns;
    uint64_t guest_pc_start;
    uint64_t guest_pc_end;
    uint64_t guest_vaddr;
    uint64_t guest_paddr;
    uint64_t region_offset;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t guest_pc_start_valid;
    uint32_t guest_pc_end_valid;
    uint32_t size;
    uint32_t access_type;
    char region_name[XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX];
    char owner_type[XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX];
} XemuDebugToolsMmioTraceEvent;

typedef struct XemuDebugToolsMmioTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t long_dispatch_threshold_ns;
} XemuDebugToolsMmioTraceStatus;

void xemu_debug_tools_mmio_trace_set_enabled(int enabled);
void xemu_debug_tools_mmio_trace_clear(void);
int xemu_debug_tools_mmio_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_mmio_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_mmio_trace_get_buffer_capacity(void);
void xemu_debug_tools_mmio_trace_get_status(XemuDebugToolsMmioTraceStatus *status);
size_t xemu_debug_tools_mmio_trace_snapshot(XemuDebugToolsMmioTraceEvent *events,
                                            size_t capacity);

#ifdef __cplusplus
}
#endif
