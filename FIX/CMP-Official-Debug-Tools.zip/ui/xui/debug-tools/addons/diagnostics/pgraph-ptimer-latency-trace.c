#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/main-loop.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "cpu.h"
#include "hw/xbox/nv2a/nv2a_int.h"
#include "pgraph-ptimer-latency-trace-hook.h"
#include "diagnostics-trace-buffer.h"

typedef struct TraceRingPgraph {
    QemuMutex lock;
    bool init;
    int enabled;
    uint64_t threshold_ns;
    size_t count, write_index;
    uint64_t total, overwritten;
    uint32_t buffer_multiplier;
    XemuDebugToolsPgraphIncrementEvent
        *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} TraceRingPgraph;

typedef struct TraceRingPtimer {
    QemuMutex lock;
    bool init;
    int enabled;
    uint64_t threshold_ns;
    size_t count, write_index;
    uint64_t total, overwritten;
    bool active;
    uint64_t set_host_ns, set_virtual_ns;
    uint32_t pending_at_set, enabled_at_set;
    int32_t set_tid;
    uint32_t buffer_multiplier;
    XemuDebugToolsPtimerIrqLatencyEvent
        *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} TraceRingPtimer;

static TraceRingPgraph pgtrace;
static TraceRingPtimer pttrace;

static uint64_t clamp_ns(uint64_t ns)
{
    return MAX(10000ULL, MIN(ns, 10000000000ULL));
}

static void pginit(void)
{
    if (!pgtrace.init) {
        qemu_mutex_init(&pgtrace.lock);
        pgtrace.threshold_ns =
            XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_DEFAULT_THRESHOLD_NS;
        pgtrace.buffer_multiplier = 1;
        pgtrace.init = true;
    }
}

static void ptinit(void)
{
    if (!pttrace.init) {
        qemu_mutex_init(&pttrace.lock);
        pttrace.threshold_ns =
            XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_DEFAULT_THRESHOLD_NS;
        pttrace.buffer_multiplier = 1;
        pttrace.init = true;
    }
}

static void pgreset(void)
{
    pgtrace.count = pgtrace.write_index = 0;
    pgtrace.total = pgtrace.overwritten = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        pgtrace.events, XemuDebugToolsPgraphIncrementEvent,
        XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY, pgtrace.buffer_multiplier);
}

static void ptreset(void)
{
    pttrace.count = pttrace.write_index = 0;
    pttrace.total = pttrace.overwritten = 0;
    pttrace.active = false;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        pttrace.events, XemuDebugToolsPtimerIrqLatencyEvent,
        XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY, pttrace.buffer_multiplier);
}

uint64_t xemu_debug_tools_pgraph_increment_trace_threshold_ns(void)
{
    return pgtrace.init && qatomic_read(&pgtrace.enabled) ?
               qatomic_read(&pgtrace.threshold_ns) :
               0;
}

void xemu_debug_tools_pgraph_increment_trace_record(
    const XemuDebugToolsPgraphIncrementEvent *src)
{
    XemuDebugToolsPgraphIncrementEvent e;
    size_t s;

    if (!src || !pgtrace.init || !qatomic_read(&pgtrace.enabled) ||
        src->host_duration_ns < src->threshold_ns)
        return;

    e = *src;
    e.thread_id = qemu_get_thread_id();
    e.bql_held_after = bql_locked() ? 1 : 0;

    qemu_mutex_lock(&pgtrace.lock);
    if (!qatomic_read(&pgtrace.enabled)) {
        qemu_mutex_unlock(&pgtrace.lock);
        return;
    }

    size_t cap = xemu_debug_tools_pgraph_increment_trace_get_buffer_capacity();
    s = pgtrace.write_index;
    e.sequence = pgtrace.total++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        pgtrace.events, XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY, s) = e;
    pgtrace.write_index = (s + 1) % cap;
    if (pgtrace.count < cap)
        pgtrace.count++;
    else
        pgtrace.overwritten++;
    qemu_mutex_unlock(&pgtrace.lock);
}

void xemu_debug_tools_pgraph_increment_trace_set_enabled(int e)
{
    pginit();
    qemu_mutex_lock(&pgtrace.lock);
    if (e) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            pgtrace.events, XemuDebugToolsPgraphIncrementEvent,
            XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY,
            pgtrace.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&pgtrace.lock);
            return;
        }
    }
    if (e && !pgtrace.enabled)
        pgreset();
    qatomic_set(&pgtrace.enabled, e != 0);
    qemu_mutex_unlock(&pgtrace.lock);
}

void xemu_debug_tools_pgraph_increment_trace_set_threshold_ns(uint64_t ns)
{
    pginit();
    qemu_mutex_lock(&pgtrace.lock);
    pgtrace.threshold_ns = clamp_ns(ns);
    pgreset();
    qemu_mutex_unlock(&pgtrace.lock);
}

int xemu_debug_tools_pgraph_increment_trace_set_buffer_multiplier(uint32_t m)
{
    bool ok;

    pginit();
    m = xemu_debug_tools_trace_buffer_clamp_multiplier(m);
    qemu_mutex_lock(&pgtrace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        pgtrace.events, XemuDebugToolsPgraphIncrementEvent,
        XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY, m, ok);
    if (ok) {
        pgtrace.buffer_multiplier = m;
        pgreset();
    }
    qemu_mutex_unlock(&pgtrace.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_pgraph_increment_trace_get_buffer_multiplier(void)
{
    return pgtrace.buffer_multiplier ? pgtrace.buffer_multiplier : 1;
}

size_t xemu_debug_tools_pgraph_increment_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY,
        xemu_debug_tools_pgraph_increment_trace_get_buffer_multiplier());
}

void xemu_debug_tools_pgraph_increment_trace_clear(void)
{
    pginit();
    qemu_mutex_lock(&pgtrace.lock);
    pgreset();
    qemu_mutex_unlock(&pgtrace.lock);
}

void xemu_debug_tools_pgraph_increment_trace_get_status(
    XemuDebugToolsLatencyTraceStatus *s)
{
    if (!s)
        return;

    pginit();
    memset(s, 0, sizeof(*s));
    qemu_mutex_lock(&pgtrace.lock);
    s->enabled = pgtrace.enabled;
    s->threshold_ns = pgtrace.threshold_ns;
    s->count = pgtrace.count;
    s->total_events = pgtrace.total;
    s->overwritten_events = pgtrace.overwritten;
    qemu_mutex_unlock(&pgtrace.lock);
}

size_t xemu_debug_tools_pgraph_increment_trace_snapshot(
    XemuDebugToolsPgraphIncrementEvent *e, size_t cap)
{
    size_t n, o, i, ringcap;

    if (!e || !cap)
        return 0;

    pginit();
    qemu_mutex_lock(&pgtrace.lock);
    ringcap = xemu_debug_tools_pgraph_increment_trace_get_buffer_capacity();
    n = MIN(cap, pgtrace.count);
    o = pgtrace.count == ringcap ? pgtrace.write_index : 0;
    if (n < pgtrace.count)
        o = (o + pgtrace.count - n) % ringcap;
    for (i = 0; i < n; i++)
        e[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            pgtrace.events, XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY,
            (o + i) % ringcap);
    qemu_mutex_unlock(&pgtrace.lock);
    return n;
}

void xemu_debug_tools_ptimer_irq_latency_note_set(void *opaque)
{
    NV2AState *d = opaque;

    if (!d || !pttrace.init || !qatomic_read(&pttrace.enabled))
        return;

    qemu_mutex_lock(&pttrace.lock);
    pttrace.active = true;
    pttrace.set_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    pttrace.set_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    pttrace.pending_at_set = d->ptimer.pending_interrupts;
    pttrace.enabled_at_set = d->ptimer.enabled_interrupts;
    pttrace.set_tid = qemu_get_thread_id();
    qemu_mutex_unlock(&pttrace.lock);
}

void xemu_debug_tools_ptimer_irq_latency_note_clear(void *opaque,
                                                    uint32_t clear_value)
{
    NV2AState *d = opaque;
    XemuDebugToolsPtimerIrqLatencyEvent e = { 0 };
    CPUState *cpu;
    size_t s;

    if (!d || !pttrace.init || !qatomic_read(&pttrace.enabled))
        return;

    e.irq_clear_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    e.irq_clear_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    e.clear_thread_id = qemu_get_thread_id();
    e.clear_value = clear_value;
    cpu = current_cpu;
    if (cpu) {
        CPUX86State *env = &X86_CPU(cpu)->env;
        e.clear_interrupt_request = cpu->interrupt_request;
        e.clear_halted = cpu->halted ? 1 : 0;
        e.clear_eflags = env->eflags;
        e.clear_rdtsc_reference = cpu_get_tsc(env) + env->tsc_offset;
        e.clear_rdtsc_reference_valid = 1;
        if (cpu->cc && cpu->cc->get_pc) {
            e.clear_guest_pc = cpu->cc->get_pc(cpu);
            e.clear_guest_pc_valid = 1;
        }
    }

    qemu_mutex_lock(&pttrace.lock);
    if (!pttrace.active) {
        qemu_mutex_unlock(&pttrace.lock);
        return;
    }

    e.irq_set_host_ns = pttrace.set_host_ns;
    e.irq_set_virtual_ns = pttrace.set_virtual_ns;
    e.service_latency_ns = e.irq_clear_host_ns >= e.irq_set_host_ns ?
                               e.irq_clear_host_ns - e.irq_set_host_ns :
                               0;
    e.virtual_latency_ns =
        (int64_t)e.irq_clear_virtual_ns - (int64_t)e.irq_set_virtual_ns;
    e.threshold_ns = pttrace.threshold_ns;
    e.pending_at_set = pttrace.pending_at_set;
    e.enabled_at_set = pttrace.enabled_at_set;
    e.set_thread_id = pttrace.set_tid;
    pttrace.active = false;

    if (e.service_latency_ns >= pttrace.threshold_ns) {
        size_t cap =
            xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_capacity();
        s = pttrace.write_index;
        e.sequence = pttrace.total++;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            pttrace.events, XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY, s) = e;
        pttrace.write_index = (s + 1) % cap;
        if (pttrace.count < cap)
            pttrace.count++;
        else
            pttrace.overwritten++;
    }
    qemu_mutex_unlock(&pttrace.lock);
}

void xemu_debug_tools_ptimer_irq_latency_trace_set_enabled(int e)
{
    ptinit();
    qemu_mutex_lock(&pttrace.lock);
    if (e) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            pttrace.events, XemuDebugToolsPtimerIrqLatencyEvent,
            XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY,
            pttrace.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&pttrace.lock);
            return;
        }
    }
    if (e && !pttrace.enabled)
        ptreset();
    qatomic_set(&pttrace.enabled, e != 0);
    qemu_mutex_unlock(&pttrace.lock);
}

void xemu_debug_tools_ptimer_irq_latency_trace_set_threshold_ns(uint64_t ns)
{
    ptinit();
    qemu_mutex_lock(&pttrace.lock);
    pttrace.threshold_ns = clamp_ns(ns);
    ptreset();
    qemu_mutex_unlock(&pttrace.lock);
}

int xemu_debug_tools_ptimer_irq_latency_trace_set_buffer_multiplier(uint32_t m)
{
    bool ok;

    ptinit();
    m = xemu_debug_tools_trace_buffer_clamp_multiplier(m);
    qemu_mutex_lock(&pttrace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        pttrace.events, XemuDebugToolsPtimerIrqLatencyEvent,
        XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY, m, ok);
    if (ok) {
        pttrace.buffer_multiplier = m;
        ptreset();
    }
    qemu_mutex_unlock(&pttrace.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_multiplier(void)
{
    return pttrace.buffer_multiplier ? pttrace.buffer_multiplier : 1;
}

size_t xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY,
        xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_multiplier());
}

void xemu_debug_tools_ptimer_irq_latency_trace_clear(void)
{
    ptinit();
    qemu_mutex_lock(&pttrace.lock);
    ptreset();
    qemu_mutex_unlock(&pttrace.lock);
}

void xemu_debug_tools_ptimer_irq_latency_trace_get_status(
    XemuDebugToolsLatencyTraceStatus *s)
{
    if (!s)
        return;

    ptinit();
    memset(s, 0, sizeof(*s));
    qemu_mutex_lock(&pttrace.lock);
    s->enabled = pttrace.enabled;
    s->threshold_ns = pttrace.threshold_ns;
    s->count = pttrace.count;
    s->total_events = pttrace.total;
    s->overwritten_events = pttrace.overwritten;
    qemu_mutex_unlock(&pttrace.lock);
}

size_t xemu_debug_tools_ptimer_irq_latency_trace_snapshot(
    XemuDebugToolsPtimerIrqLatencyEvent *e, size_t cap)
{
    size_t n, o, i, ringcap;

    if (!e || !cap)
        return 0;

    ptinit();
    qemu_mutex_lock(&pttrace.lock);
    ringcap = xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_capacity();
    n = MIN(cap, pttrace.count);
    o = pttrace.count == ringcap ? pttrace.write_index : 0;
    if (n < pttrace.count)
        o = (o + pttrace.count - n) % ringcap;
    for (i = 0; i < n; i++)
        e[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            pttrace.events, XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY,
            (o + i) % ringcap);
    qemu_mutex_unlock(&pttrace.lock);
    return n;
}
