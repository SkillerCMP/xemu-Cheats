/* Info: QEMU timer/main-loop code emits events; Diagnostics owns analysis. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsQemuTimerHookEvent {
    XEMU_DEBUG_TOOLS_QTIMER_TIMER_MOD = 1,
    XEMU_DEBUG_TOOLS_QTIMER_TIMER_DEL,
    XEMU_DEBUG_TOOLS_QTIMER_CLOCK_NOTIFY,
    XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_BEGIN,
    XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_END,
    XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_ACQUIRE_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_PREPARE_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_PREPARE_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_BUSYWAIT_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_BUSYWAIT_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_BACKEND_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_POLL_BACKEND_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_MAIN_LOOP_LOCK_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_MAIN_LOOP_LOCK_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_REPLAY_LOCK_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_REPLAY_LOCK_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_BQL_LOCK_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_BQL_LOCK_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CHECK_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CHECK_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_DISPATCH_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_DISPATCH_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_WAIT_OBJECTS_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_WAIT_OBJECTS_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_POLLING_CALLBACKS_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_POLLING_CALLBACKS_EXIT,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_RELEASE_ENTER,
    XEMU_DEBUG_TOOLS_QTIMER_GLIB_CONTEXT_RELEASE_EXIT,
} XemuDebugToolsQemuTimerHookEvent;

typedef void (*XemuDebugToolsQemuTimerObserver)(
    void *timer,
    XemuDebugToolsQemuTimerHookEvent event_type,
    int clock_type,
    int64_t expire_ns,
    int64_t value);

typedef void (*XemuDebugToolsQemuMainLoopObserver)(
    XemuDebugToolsQemuTimerHookEvent event_type,
    int64_t timeout_ns,
    int64_t value);

/* Implemented by util/qemu-timer.c as a tiny generic observation bridge. */
void xemu_debug_tools_qemu_timer_hook_install(
    XemuDebugToolsQemuTimerObserver timer_observer,
    XemuDebugToolsQemuMainLoopObserver main_loop_observer);
void xemu_debug_tools_qemu_timer_hook_emit_main_loop(
    XemuDebugToolsQemuTimerHookEvent event_type,
    int64_t timeout_ns,
    int64_t value);

/* Implemented by the Diagnostics add-on (or no-op profile stub). */
void xemu_debug_tools_qemu_timer_trace_init(void);
void xemu_debug_tools_qemu_timer_trace_watch(void *timer);

#ifdef __cplusplus
}
#endif
