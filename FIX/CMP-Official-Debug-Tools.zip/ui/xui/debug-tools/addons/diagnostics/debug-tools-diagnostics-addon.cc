// xemu Debug Tools - Diagnostics optional addition registration.

#include "../../debug-tools-module.hh"
#include "../../detached-tools.hh"
#include "bql-trace-hook.h"
#include "diagnostics.hh"

namespace {

void DrawDiagnosticsDetached()
{
    diagnostics_window.Draw(true);
}

void TickDiagnostics()
{
    diagnostics_window.Tick();
}

void NotifyDiagnosticsReset()
{
    diagnostics_window.NotifyGameReset();
}

void ProcessDiagnosticsDeferredActions()
{
    diagnostics_window.ProcessDeferredActions();
}

} // namespace

void debug_tools_register_diagnostics_addition()
{
    debug_tools_register_menu_item(500, "Diagnostics",
                                   &diagnostics_window.is_open);
    debug_tools_register_tick(500, TickDiagnostics);
    debug_tools_register_reset(300, NotifyDiagnosticsReset);
    debug_tools_register_deferred_action(500,
                                         ProcessDiagnosticsDeferredActions);

    detached_tools_register({
        "xemu - Diagnostics",
        1050, 720,
        760, 500,
        &diagnostics_window.is_open,
        DrawDiagnosticsDetached,
        500,
        true,
    });
}
