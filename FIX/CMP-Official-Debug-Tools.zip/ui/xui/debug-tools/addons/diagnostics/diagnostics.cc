//
// xemu Debug Tools - standalone Diagnostics window
//
#include "diagnostics.hh"
#include "bql-trace-hook.h"

#include "../../../common.hh"
#include "../../../misc.hh"
#include "../../../../xemu-notifications.h"
#include "../../current-game.hh"
#include "../../tab-style.hh"
#include "../../debug-output-paths.hh"
#include "../../debug-tools.hh"

#include <SDL3/SDL.h>
#include <glib.h>
#include <glib/gstdio.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

DiagnosticsWindow diagnostics_window;

namespace {

constexpr double kXboxTscHz = 733333333.0;
constexpr double kAudioBytesPerMs = 48000.0 * 2.0 * 2.0 / 1000.0;

const char *BackendName()
{
    switch (xemu_cheat_debug_backend()) {
    case XEMU_CHEAT_DEBUG_BACKEND_TCG: return "TCG";
    case XEMU_CHEAT_DEBUG_BACKEND_WHPX: return "WHPX";
    case XEMU_CHEAT_DEBUG_BACKEND_KVM: return "KVM";
    case XEMU_CHEAT_DEBUG_BACKEND_HVF: return "HVF";
    default: return "Other / unavailable";
    }
}

std::string FormatHz(uint64_t hz)
{
    if (hz == 0) {
        return "<unavailable>";
    }
    char buf[96];
    if (hz >= 1000000ULL) {
        std::snprintf(buf, sizeof(buf), "%llu Hz (%.6f MHz)",
                      (unsigned long long)hz,
                      (double)hz / 1000000.0);
    } else if (hz >= 1000ULL) {
        std::snprintf(buf, sizeof(buf), "%llu Hz (%.3f kHz)",
                      (unsigned long long)hz,
                      (double)hz / 1000.0);
    } else {
        std::snprintf(buf, sizeof(buf), "%llu Hz",
                      (unsigned long long)hz);
    }
    return buf;
}

std::string FormatDurationNs(int64_t ns)
{
    char buf[96];
    const double abs_ns = std::fabs((double)ns);
    if (abs_ns >= 1000000.0) {
        std::snprintf(buf, sizeof(buf), "%+.3f ms", (double)ns / 1000000.0);
    } else if (abs_ns >= 1000.0) {
        std::snprintf(buf, sizeof(buf), "%+.3f us", (double)ns / 1000.0);
    } else {
        std::snprintf(buf, sizeof(buf), "%+lld ns", (long long)ns);
    }
    return buf;
}

std::string FormatGuestPc(uint64_t pc)
{
    if (pc > 0xFFFFFFFFull) {
        char raw[24];
        std::snprintf(raw, sizeof(raw), "%016llX",
                      (unsigned long long)pc);
        return raw;
    }
    return XemuXbeLabels::FormatAddress(current_game_manager.Labels(),
                                        (uint32_t)pc, true);
}

std::string FormatGuestPcLabel(uint64_t pc)
{
    if (pc > 0xFFFFFFFFull) {
        return {};
    }
    return XemuXbeLabels::FormatAddress(current_game_manager.Labels(),
                                        (uint32_t)pc, false);
}

void DrawGuestPc(uint64_t pc)
{
    const std::string text = FormatGuestPc(pc);
    ImGui::TextUnformatted(text.c_str());

    if (pc > 0xFFFFFFFFull || !ImGui::IsItemHovered()) {
        return;
    }
    XemuXbeLabels::ResolvedAddress resolved;
    if (!XemuXbeLabels::ResolveAddress(current_game_manager.Labels(),
                                       (uint32_t)pc, resolved) ||
        resolved.label == nullptr) {
        return;
    }
    ImGui::BeginTooltip();
    ImGui::Text("Base: %08X%s", resolved.label->virtual_address,
                resolved.exact ? " (exact)" : "");
    ImGui::Text("Type / Source / Confidence: %s / %s / %s",
                XemuXbeLabels::TypeName(resolved.label->type),
                XemuXbeLabels::SourceName(resolved.label->source),
                XemuXbeLabels::ConfidenceName(resolved.label->confidence));
    ImGui::EndTooltip();
}

void DrawGuestPcRange(uint64_t start, bool end_valid, uint64_t end)
{
    if (!end_valid) {
        DrawGuestPc(start);
        return;
    }
    const std::string start_text = FormatGuestPc(start);
    const std::string end_text = FormatGuestPc(end);
    ImGui::Text("%s -> %s", start_text.c_str(), end_text.c_str());
}

void AppendGuestPcLabel(std::ostream &os, uint64_t pc)
{
    const std::string label = FormatGuestPcLabel(pc);
    if (!label.empty()) {
        os << " [" << label << "]";
    }
}

size_t DiagnosticsBufferCapacity(XemuDiagnosticsBufferId id)
{
    XemuDiagnosticsBufferInfo info{};
    return xemu_diagnostics_buffer_get_info(id, &info) ? info.capacity : 0;
}

uint32_t DiagnosticsBufferMultiplier(XemuDiagnosticsBufferId id)
{
    XemuDiagnosticsBufferInfo info{};
    return xemu_diagnostics_buffer_get_info(id, &info) ? info.multiplier : 1;
}

const char *DiagnosticsBufferName(XemuDiagnosticsBufferId id)
{
    switch (id) {
    case XEMU_DIAG_BUFFER_PTIMER: return "PTIMER Detailed Timing";
    case XEMU_DIAG_BUFFER_QEMU_TIMER: return "QEMU Timer Dispatch";
    case XEMU_DIAG_BUFFER_SLOW_TIMER: return "Slow QEMU Timer Callback";
    case XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME: return "OHCI Slow Frame";
    case XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL: return "Controller Input Poll";
    case XEMU_DIAG_BUFFER_PGRAPH_INCREMENT: return "PGRAPH Increment";
    case XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY: return "PTIMER IRQ Latency";
    case XEMU_DIAG_BUFFER_BQL: return "BQL Ownership";
    case XEMU_DIAG_BUFFER_MMIO: return "MMIO Dispatch";
    case XEMU_DIAG_BUFFER_PGRAPH_LOCK: return "PGRAPH Lock Ownership";
    case XEMU_DIAG_BUFFER_PGRAPH_DRAW: return "PGRAPH Draw-End";
    case XEMU_DIAG_BUFFER_FLIP_STALL: return "FLIP_STALL / VBlank";
    case XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY: return "PGRAPH Flip Delay Breakdown";
    case XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS: return "D3D Pusher / GPU Progress";
    case XEMU_DIAG_BUFFER_AV_SYNC: return "Audio / Video Sync";
    case XEMU_DIAG_BUFFER_SCHEDULER: return "Xbox Scheduler / Thread Wake";
    case XEMU_DIAG_BUFFER_CONTROLLER_XID: return "Controller / XID / OHCI";
    case XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER: return "Guest Input Consumer Candidates";
    case XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE: return "Guest Timer / Deadline Correlation";
    case XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK: return "QEMU Main Loop Lock Ownership";
    default: return "Unknown";
    }
}

const char *AvSyncEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_BATCH: return "AUDIO_256";
    case XEMU_DEBUG_TOOLS_AV_SYNC_VBLANK: return "VBLANK";
    case XEMU_DEBUG_TOOLS_AV_SYNC_PGRAPH_FLIP: return "PGRAPH_FLIP";
    default: return "UNKNOWN";
    }
}

const char *FlipStallEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_FLIP_SET_READ: return "SET_FLIP_READ";
    case XEMU_DIAG_FLIP_SET_WRITE: return "SET_FLIP_WRITE";
    case XEMU_DIAG_FLIP_SET_MODULO: return "SET_FLIP_MODULO";
    case XEMU_DIAG_FLIP_INCREMENT_WRITE: return "FLIP_INCREMENT_WRITE";
    case XEMU_DIAG_FLIP_STALL_BEGIN: return "FLIP_STALL_BEGIN";
    case XEMU_DIAG_FLIP_VK_FINISH_BEGIN: return "VK_FINISH_BEGIN";
    case XEMU_DIAG_FLIP_VK_FINISH_END: return "VK_FINISH_END";
    case XEMU_DIAG_FLIP_WAITING_SET: return "WAITING_SET";
    case XEMU_DIAG_FLIP_VBLANK_IRQ: return "VBLANK_IRQ";
    case XEMU_DIAG_FLIP_VBLANK_READ_INCREMENT: return "READ_3D_INCREMENT";
    case XEMU_DIAG_FLIP_PFIFO_CHECK_STALL: return "PFIFO_CHECK_STALL";
    case XEMU_DIAG_FLIP_PFIFO_RELEASE: return "PFIFO_RELEASE";
    default: return "UNKNOWN";
    }
}

const char *PgraphPusherProgressEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_DMA_PUT: return "DMA_PUT";
    case XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PFIFO_RUN: return "PFIFO_RUN";
    case XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_SEMAPHORE_RELEASE: return "SEMAPHORE_RELEASE";
    default: return "UNKNOWN";
    }
}

const char *SchedulerTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_SCHED_IDLE_ENTER: return "IDLE_ENTER";
    case XEMU_DIAG_SCHED_IDLE_CHECKPOINT: return "IDLE_CHECKPOINT";
    case XEMU_DIAG_SCHED_IDLE_EXIT: return "IDLE_EXIT";
    case XEMU_DIAG_SCHED_TITLE_RETURN: return "TITLE_RETURN";
    default: return "UNKNOWN";
    }
}

const char *SchedulerWakeSourceName(uint32_t source)
{
    switch (source) {
    case XEMU_DIAG_SCHED_WAKE_PCRTC_VBLANK: return "PCRTC_VBLANK";
    case XEMU_DIAG_SCHED_WAKE_PTIMER: return "PTIMER";
    case XEMU_DIAG_SCHED_WAKE_PGRAPH: return "PGRAPH";
    case XEMU_DIAG_SCHED_WAKE_PFIFO: return "PFIFO";
    case XEMU_DIAG_SCHED_WAKE_OHCI: return "OHCI";
    default: return "NONE";
    }
}

/* Diagnostics watches are intentionally RAM-only.  The generic cheat-memory
 * bridge can also reach PCI/MMIO regions, where an apparently harmless read
 * may have device side effects.  Resolve virtual addresses a page at a time,
 * reject anything outside installed Xbox RAM, and then perform only physical
 * RAM reads. */
bool ReadWatchRamOnly(bool virtual_address, uint32_t address, void *buffer,
                      size_t size, uint64_t *first_physical)
{
    constexpr uint32_t kGuestPageSize = 4096;
    const uint64_t ram_size = xemu_cheat_ram_size();
    uint8_t *out = static_cast<uint8_t *>(buffer);

    if (buffer == nullptr || size == 0 || ram_size == 0 ||
        (uint64_t)address + size > 0x100000000ULL) {
        return false;
    }

    if (!virtual_address) {
        const uint64_t physical = address;
        if (physical >= ram_size || size > ram_size - physical) {
            return false;
        }
        if (first_physical != nullptr) {
            *first_physical = physical;
        }
        return xemu_cheat_memory_read(0, address, buffer, size) != 0;
    }

    if (!xemu_cheat_prepare_virtual_map()) {
        return false;
    }

    uint32_t current = address;
    size_t remaining = size;
    bool first = true;
    while (remaining != 0) {
        uint64_t physical = 0;
        if (!xemu_cheat_virtual_to_physical(current, &physical)) {
            return false;
        }

        const size_t page_remaining =
            kGuestPageSize - (size_t)(current & (kGuestPageSize - 1));
        const size_t amount = std::min(remaining, page_remaining);
        if (physical >= ram_size || amount > ram_size - physical ||
            physical > UINT32_MAX) {
            return false;
        }
        if (first && first_physical != nullptr) {
            *first_physical = physical;
        }
        if (!xemu_cheat_memory_read(0, (uint32_t)physical, out, amount)) {
            return false;
        }

        first = false;
        current += (uint32_t)amount;
        out += amount;
        remaining -= amount;
    }
    return true;
}

const char *PtimerTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_PTIMER_TRACE_RESET: return "RESET";
    case XEMU_DIAG_PTIMER_TRACE_SCHEDULE: return "SCHEDULE";
    case XEMU_DIAG_PTIMER_TRACE_SCHEDULE_DISABLED: return "SCHED_DISABLED";
    case XEMU_DIAG_PTIMER_TRACE_TIMER_DELETE: return "TIMER_DELETE";
    case XEMU_DIAG_PTIMER_TRACE_CALLBACK: return "CALLBACK";
    case XEMU_DIAG_PTIMER_TRACE_CALLBACK_DISABLED: return "CALLBACK_DISABLED";
    case XEMU_DIAG_PTIMER_TRACE_IRQ_SET: return "IRQ_SET";
    case XEMU_DIAG_PTIMER_TRACE_IRQ_CLEAR: return "IRQ_CLEAR";
    case XEMU_DIAG_PTIMER_TRACE_INTR_EN_WRITE: return "INTR_EN_WRITE";
    case XEMU_DIAG_PTIMER_TRACE_ALARM_WRITE: return "ALARM_WRITE";
    case XEMU_DIAG_PTIMER_TRACE_NUMERATOR_WRITE: return "NUM_WRITE";
    case XEMU_DIAG_PTIMER_TRACE_DENOMINATOR_WRITE: return "DEN_WRITE";
    case XEMU_DIAG_PTIMER_TRACE_TIME0_WRITE: return "TIME0_WRITE";
    case XEMU_DIAG_PTIMER_TRACE_TIME1_WRITE: return "TIME1_WRITE";
    default: return "UNKNOWN";
    }
}

const char *QemuTimerTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_QTIMER_TIMER_MOD: return "TIMER_MOD";
    case XEMU_DIAG_QTIMER_TIMER_DEL: return "TIMER_DEL";
    case XEMU_DIAG_QTIMER_CLOCK_NOTIFY: return "CLOCK_NOTIFY";
    case XEMU_DIAG_QTIMER_DISPATCH_BEGIN: return "DISPATCH_BEGIN";
    case XEMU_DIAG_QTIMER_DISPATCH_END: return "DISPATCH_END";
    case XEMU_DIAG_QTIMER_MAIN_WAIT_ENTER: return "WAIT_ENTER";
    case XEMU_DIAG_QTIMER_MAIN_WAIT_EXIT: return "WAIT_EXIT";
    case XEMU_DIAG_QTIMER_RUN_TIMERS_ENTER: return "RUN_TIMERS_ENTER";
    case XEMU_DIAG_QTIMER_RUN_TIMERS_EXIT: return "RUN_TIMERS_EXIT";
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER: return "GLIB_ACQUIRE_ENTER";
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_EXIT: return "GLIB_ACQUIRE_EXIT";
    case XEMU_DIAG_QTIMER_GLIB_PREPARE_ENTER: return "GLIB_PREPARE_ENTER";
    case XEMU_DIAG_QTIMER_GLIB_PREPARE_EXIT: return "GLIB_PREPARE_EXIT";
    case XEMU_DIAG_QTIMER_POLL_ENTER: return "POLL_ENTER";
    case XEMU_DIAG_QTIMER_POLL_EXIT: return "POLL_EXIT";
    case XEMU_DIAG_QTIMER_POLL_BUSYWAIT_ENTER: return "BUSYWAIT_ENTER";
    case XEMU_DIAG_QTIMER_POLL_BUSYWAIT_EXIT: return "BUSYWAIT_EXIT";
    case XEMU_DIAG_QTIMER_POLL_BACKEND_ENTER: return "POLL_BACKEND_ENTER";
    case XEMU_DIAG_QTIMER_POLL_BACKEND_EXIT: return "POLL_BACKEND_EXIT";
    case XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_ENTER: return "MAIN_LOOP_LOCK_ENTER";
    case XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_EXIT: return "MAIN_LOOP_LOCK_EXIT";
    case XEMU_DIAG_QTIMER_REPLAY_LOCK_ENTER: return "REPLAY_LOCK_ENTER";
    case XEMU_DIAG_QTIMER_REPLAY_LOCK_EXIT: return "REPLAY_LOCK_EXIT";
    case XEMU_DIAG_QTIMER_BQL_LOCK_ENTER: return "BQL_LOCK_ENTER";
    case XEMU_DIAG_QTIMER_BQL_LOCK_EXIT: return "BQL_LOCK_EXIT";
    case XEMU_DIAG_QTIMER_GLIB_CHECK_ENTER: return "GLIB_CHECK_ENTER";
    case XEMU_DIAG_QTIMER_GLIB_CHECK_EXIT: return "GLIB_CHECK_EXIT";
    case XEMU_DIAG_QTIMER_GLIB_DISPATCH_ENTER: return "GLIB_DISPATCH_ENTER";
    case XEMU_DIAG_QTIMER_GLIB_DISPATCH_EXIT: return "GLIB_DISPATCH_EXIT";
    case XEMU_DIAG_QTIMER_WAIT_OBJECTS_ENTER: return "WAIT_OBJECTS_ENTER";
    case XEMU_DIAG_QTIMER_WAIT_OBJECTS_EXIT: return "WAIT_OBJECTS_EXIT";
    case XEMU_DIAG_QTIMER_POLLING_CALLBACKS_ENTER: return "POLLING_CALLBACKS_ENTER";
    case XEMU_DIAG_QTIMER_POLLING_CALLBACKS_EXIT: return "POLLING_CALLBACKS_EXIT";
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_ENTER: return "GLIB_RELEASE_ENTER";
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_EXIT: return "GLIB_RELEASE_EXIT";
    default: return "UNKNOWN";
    }
}

const char *QemuClockTypeName(int type)
{
    switch (type) {
    case 0: return "REALTIME";
    case 1: return "VIRTUAL";
    case 2: return "HOST";
    case 3: return "VIRTUAL_RT";
    default: return "UNKNOWN";
    }
}

const char *OhciListKindName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_OHCI_LIST_PERIODIC: return "PERIODIC";
    case XEMU_DIAG_OHCI_LIST_CONTROL: return "CONTROL";
    case XEMU_DIAG_OHCI_LIST_BULK: return "BULK";
    default: return "NONE";
    }
}

const char *OhciLeafOperationName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_OHCI_LEAF_ED_READ: return "ED_READ";
    case XEMU_DIAG_OHCI_LEAF_ED_WRITE: return "ED_WRITE";
    case XEMU_DIAG_OHCI_LEAF_TD_READ: return "TD_READ";
    case XEMU_DIAG_OHCI_LEAF_TD_WRITE: return "TD_WRITE";
    case XEMU_DIAG_OHCI_LEAF_DMA_TO_DEVICE: return "DMA_TO_DEVICE";
    case XEMU_DIAG_OHCI_LEAF_DEVICE_LOOKUP: return "DEVICE_LOOKUP";
    case XEMU_DIAG_OHCI_LEAF_USB_HANDLE_PACKET: return "USB_HANDLE_PACKET";
    case XEMU_DIAG_OHCI_LEAF_DMA_FROM_DEVICE: return "DMA_FROM_DEVICE";
    case XEMU_DIAG_OHCI_LEAF_ASYNC_FLUSH: return "ASYNC_FLUSH";
    case XEMU_DIAG_OHCI_LEAF_ENDPOINT_STOP: return "ENDPOINT_STOP";
    case XEMU_DIAG_OHCI_LEAF_ISO_TD: return "ISO_TD";
    default: return "NONE";
    }
}

const char *ControllerInputGetterName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_INPUT_GETTER_BUTTON_A: return "BUTTON_A";
    case XEMU_DIAG_INPUT_GETTER_BUTTON_B: return "BUTTON_B";
    case XEMU_DIAG_INPUT_GETTER_BUTTON_X: return "BUTTON_X";
    case XEMU_DIAG_INPUT_GETTER_BUTTON_Y: return "BUTTON_Y";
    case XEMU_DIAG_INPUT_GETTER_DPAD_LEFT: return "DPAD_LEFT";
    case XEMU_DIAG_INPUT_GETTER_DPAD_UP: return "DPAD_UP";
    case XEMU_DIAG_INPUT_GETTER_DPAD_RIGHT: return "DPAD_RIGHT";
    case XEMU_DIAG_INPUT_GETTER_DPAD_DOWN: return "DPAD_DOWN";
    case XEMU_DIAG_INPUT_GETTER_BACK: return "BACK";
    case XEMU_DIAG_INPUT_GETTER_START: return "START";
    case XEMU_DIAG_INPUT_GETTER_LEFT_SHOULDER: return "LEFT_SHOULDER";
    case XEMU_DIAG_INPUT_GETTER_RIGHT_SHOULDER: return "RIGHT_SHOULDER";
    case XEMU_DIAG_INPUT_GETTER_LEFT_STICK_BUTTON: return "LEFT_STICK_BUTTON";
    case XEMU_DIAG_INPUT_GETTER_RIGHT_STICK_BUTTON: return "RIGHT_STICK_BUTTON";
    case XEMU_DIAG_INPUT_GETTER_GUIDE: return "GUIDE";
    case XEMU_DIAG_INPUT_GETTER_AXIS_TRIGGER_LEFT: return "AXIS_TRIGGER_LEFT";
    case XEMU_DIAG_INPUT_GETTER_AXIS_TRIGGER_RIGHT: return "AXIS_TRIGGER_RIGHT";
    case XEMU_DIAG_INPUT_GETTER_AXIS_LEFT_X: return "AXIS_LEFT_X";
    case XEMU_DIAG_INPUT_GETTER_AXIS_LEFT_Y: return "AXIS_LEFT_Y";
    case XEMU_DIAG_INPUT_GETTER_AXIS_RIGHT_X: return "AXIS_RIGHT_X";
    case XEMU_DIAG_INPUT_GETTER_AXIS_RIGHT_Y: return "AXIS_RIGHT_Y";
    default: return "NONE";
    }
}

const char *BqlTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_BQL_LONG_WAIT: return "LONG_WAIT";
    case XEMU_DIAG_BQL_LONG_HOLD: return "LONG_HOLD";
    default: return "UNKNOWN";
    }
}

const char *MainLoopLockTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_MAIN_LOOP_LOCK_LONG_WAIT: return "LONG_WAIT";
    case XEMU_DIAG_MAIN_LOOP_LOCK_LONG_HOLD: return "LONG_HOLD";
    default: return "UNKNOWN";
    }
}

const char *BqlTraceContextName(uint32_t context)
{
    switch (context) {
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_VBLANK: return "UI_VBLANK";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_CREATE: return "UI_FRAMEBUFFER_CREATE";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_HUD_UPDATE: return "UI_HUD_UPDATE";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_DESTROY: return "UI_FRAMEBUFFER_DESTROY";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_SDL_EVENT: return "UI_SDL_EVENT";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_COMMIT: return "UI_INPUT_COMMIT";
    case XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_INIT: return "UI_INPUT_INIT";
    default: return "UNLABELED";
    }
}

const char *BqlTraceStageName(uint32_t stage)
{
    switch (stage) {
    case XEMU_DEBUG_TOOLS_BQL_STAGE_HUD_CORE: return "HUD_CORE";
    case XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_TICK: return "DEBUG_TOOLS_TICK";
    case XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT: return "DEBUG_TOOLS_SDL_EVENT";
    default: return "NONE";
    }
}

struct BqlTraceAnalysis {
    uint64_t worst_wait_ns = 0;
    uint64_t worst_hold_ns = 0;
    bool have_worst_wait = false;
    bool have_worst_hold = false;
    bool have_overlapping_hold = false;
    uint64_t longest_overlapping_hold_ns = 0;
    XemuDiagnosticsBqlTraceEvent worst_wait{};
    XemuDiagnosticsBqlTraceEvent worst_hold{};
    XemuDiagnosticsBqlTraceEvent overlapping_hold{};
};

BqlTraceAnalysis AnalyzeBqlTrace(
    const std::vector<XemuDiagnosticsBqlTraceEvent> &trace)
{
    BqlTraceAnalysis result;
    for (const auto &event : trace) {
        if (event.event_type == XEMU_DIAG_BQL_LONG_WAIT &&
            event.wait_ns > result.worst_wait_ns) {
            result.worst_wait_ns = event.wait_ns;
            result.worst_wait = event;
            result.have_worst_wait = true;
        } else if (event.event_type == XEMU_DIAG_BQL_LONG_HOLD &&
                   event.held_ns > result.worst_hold_ns) {
            result.worst_hold_ns = event.held_ns;
            result.worst_hold = event;
            result.have_worst_hold = true;
        }
    }

    if (result.have_worst_wait && result.worst_wait.host_ns >= result.worst_wait.wait_ns) {
        const uint64_t wait_start = result.worst_wait.host_ns - result.worst_wait.wait_ns;
        const uint64_t wait_end = result.worst_wait.host_ns;
        for (const auto &event : trace) {
            if (event.event_type != XEMU_DIAG_BQL_LONG_HOLD ||
                event.host_ns < event.held_ns) {
                continue;
            }
            const uint64_t hold_start = event.host_ns - event.held_ns;
            const uint64_t hold_end = event.host_ns;
            const uint64_t overlap_start = std::max(wait_start, hold_start);
            const uint64_t overlap_end = std::min(wait_end, hold_end);
            if (overlap_end > overlap_start &&
                overlap_end - overlap_start > result.longest_overlapping_hold_ns) {
                result.longest_overlapping_hold_ns = overlap_end - overlap_start;
                result.overlapping_hold = event;
                result.have_overlapping_hold = true;
            }
        }
    }
    return result;
}

struct MainLoopLockTraceAnalysis {
    uint64_t worst_wait_ns = 0;
    uint64_t worst_hold_ns = 0;
    bool have_worst_wait = false;
    bool have_worst_hold = false;
    bool have_overlapping_hold = false;
    uint64_t longest_overlapping_hold_ns = 0;
    XemuDiagnosticsMainLoopLockTraceEvent worst_wait{};
    XemuDiagnosticsMainLoopLockTraceEvent worst_hold{};
    XemuDiagnosticsMainLoopLockTraceEvent overlapping_hold{};
};

MainLoopLockTraceAnalysis AnalyzeMainLoopLockTrace(
    const std::vector<XemuDiagnosticsMainLoopLockTraceEvent> &trace)
{
    MainLoopLockTraceAnalysis result;
    for (const auto &event : trace) {
        if (event.event_type == XEMU_DIAG_MAIN_LOOP_LOCK_LONG_WAIT &&
            event.wait_ns > result.worst_wait_ns) {
            result.worst_wait_ns = event.wait_ns;
            result.worst_wait = event;
            result.have_worst_wait = true;
        } else if (event.event_type == XEMU_DIAG_MAIN_LOOP_LOCK_LONG_HOLD &&
                   event.held_ns > result.worst_hold_ns) {
            result.worst_hold_ns = event.held_ns;
            result.worst_hold = event;
            result.have_worst_hold = true;
        }
    }

    if (result.have_worst_wait && result.worst_wait.host_ns >= result.worst_wait.wait_ns) {
        const uint64_t wait_start = result.worst_wait.host_ns - result.worst_wait.wait_ns;
        const uint64_t wait_end = result.worst_wait.host_ns;
        for (const auto &event : trace) {
            if (event.event_type != XEMU_DIAG_MAIN_LOOP_LOCK_LONG_HOLD ||
                event.host_ns < event.held_ns) {
                continue;
            }
            const uint64_t hold_start = event.host_ns - event.held_ns;
            const uint64_t hold_end = event.host_ns;
            const uint64_t overlap_start = std::max(wait_start, hold_start);
            const uint64_t overlap_end = std::min(wait_end, hold_end);
            if (overlap_end > overlap_start &&
                overlap_end - overlap_start > result.longest_overlapping_hold_ns) {
                result.longest_overlapping_hold_ns = overlap_end - overlap_start;
                result.overlapping_hold = event;
                result.have_overlapping_hold = true;
            }
        }
    }
    return result;
}

const char *MmioAccessName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_MMIO_READ: return "READ";
    case XEMU_DIAG_MMIO_WRITE: return "WRITE";
    default: return "UNKNOWN";
    }
}

struct MmioTraceAnalysis {
    uint64_t worst_host_ns = 0;
    uint64_t worst_virtual_ns = 0;
    bool have_worst = false;
    XemuDiagnosticsMmioTraceEvent worst{};
};

MmioTraceAnalysis AnalyzeMmioTrace(
    const std::vector<XemuDiagnosticsMmioTraceEvent> &trace)
{
    MmioTraceAnalysis result;
    for (const auto &event : trace) {
        if (event.duration_host_ns > result.worst_host_ns) {
            result.worst_host_ns = event.duration_host_ns;
            result.worst_virtual_ns = event.duration_virtual_ns;
            result.worst = event;
            result.have_worst = true;
        }
    }
    return result;
}

const char *PgraphLockTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_PGRAPH_LOCK_LONG_WAIT: return "LONG_WAIT";
    case XEMU_DIAG_PGRAPH_LOCK_LONG_HOLD: return "LONG_HOLD";
    default: return "UNKNOWN";
    }
}

std::string FormatPgraphMethod(const XemuDiagnosticsPgraphLockMethodContext &method)
{
    if (!method.valid) {
        return "<none>";
    }
    char buf[160];
    std::snprintf(buf, sizeof(buf),
                  "class=%02X subch=%u method=%04X param=%08X%s",
                  method.graphics_class, method.subchannel, method.method,
                  method.parameter, method.active ? " active" : "");
    return buf;
}

struct PgraphLockTraceAnalysis {
    uint64_t worst_wait_ns = 0;
    uint64_t worst_hold_ns = 0;
    bool have_worst_wait = false;
    bool have_worst_hold = false;
    bool have_overlapping_hold = false;
    uint64_t longest_overlapping_hold_ns = 0;
    XemuDiagnosticsPgraphLockTraceEvent worst_wait{};
    XemuDiagnosticsPgraphLockTraceEvent worst_hold{};
    XemuDiagnosticsPgraphLockTraceEvent overlapping_hold{};
};

PgraphLockTraceAnalysis AnalyzePgraphLockTrace(
    const std::vector<XemuDiagnosticsPgraphLockTraceEvent> &trace)
{
    PgraphLockTraceAnalysis result;
    for (const auto &event : trace) {
        if (event.event_type == XEMU_DIAG_PGRAPH_LOCK_LONG_WAIT &&
            event.wait_ns > result.worst_wait_ns) {
            result.worst_wait_ns = event.wait_ns;
            result.worst_wait = event;
            result.have_worst_wait = true;
        } else if (event.event_type == XEMU_DIAG_PGRAPH_LOCK_LONG_HOLD &&
                   event.held_ns > result.worst_hold_ns) {
            result.worst_hold_ns = event.held_ns;
            result.worst_hold = event;
            result.have_worst_hold = true;
        }
    }

    if (result.have_worst_wait && result.worst_wait.host_ns >= result.worst_wait.wait_ns) {
        const uint64_t wait_start = result.worst_wait.host_ns - result.worst_wait.wait_ns;
        const uint64_t wait_end = result.worst_wait.host_ns;
        for (const auto &event : trace) {
            if (event.event_type != XEMU_DIAG_PGRAPH_LOCK_LONG_HOLD ||
                event.host_ns < event.held_ns) {
                continue;
            }
            const uint64_t hold_start = event.host_ns - event.held_ns;
            const uint64_t hold_end = event.host_ns;
            const uint64_t overlap_start = std::max(wait_start, hold_start);
            const uint64_t overlap_end = std::min(wait_end, hold_end);
            if (overlap_end > overlap_start &&
                overlap_end - overlap_start > result.longest_overlapping_hold_ns) {
                result.longest_overlapping_hold_ns = overlap_end - overlap_start;
                result.overlapping_hold = event;
                result.have_overlapping_hold = true;
            }
        }
    }
    return result;
}

const char *AvSyncMarkerName(uint32_t kind)
{
    switch (kind) {
    case XEMU_DEBUG_TOOLS_AV_MARK_CUTSCENE_START: return "CUTSCENE_START";
    case XEMU_DEBUG_TOOLS_AV_MARK_SOUND_AHEAD: return "SOUND_AHEAD";
    case XEMU_DEBUG_TOOLS_AV_MARK_SCENE_END: return "SCENE_END";
    default: return "UNKNOWN";
    }
}

const char *PgraphDrawTraceStageName(uint32_t stage)
{
    switch (stage) {
    case XEMU_DIAG_PGRAPH_DRAW_SET_BEGIN_END_TOTAL: return "SET_BEGIN_END(END)_TOTAL";
    case XEMU_DIAG_PGRAPH_DRAW_RENDERER_DRAW_END: return "RENDERER_DRAW_END";
    case XEMU_DIAG_PGRAPH_DRAW_RESET_INLINE_BUFFERS: return "RESET_INLINE_BUFFERS";
    case XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_END_TOTAL: return "GL_DRAW_END_TOTAL";
    case XEMU_DIAG_PGRAPH_DRAW_GL_FLUSH_DRAW: return "GL_FLUSH_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_BIND_VERTEX_ATTRIBUTES: return "BIND_VERTEX_ATTRIBUTES";
    case XEMU_DIAG_PGRAPH_DRAW_INLINE_ELEMENT_SCAN: return "INLINE_ELEMENT_SCAN";
    case XEMU_DIAG_PGRAPH_DRAW_ELEMENT_CACHE_LOOKUP: return "ELEMENT_CACHE_LOOKUP";
    case XEMU_DIAG_PGRAPH_DRAW_GL_BUFFER_DATA: return "GL_BUFFER_DATA";
    case XEMU_DIAG_PGRAPH_DRAW_BIND_SHADERS: return "BIND_SHADERS";
    case XEMU_DIAG_PGRAPH_DRAW_INLINE_BUFFER_UPLOAD: return "INLINE_BUFFER_UPLOAD";
    case XEMU_DIAG_PGRAPH_DRAW_INLINE_ARRAY_BIND: return "INLINE_ARRAY_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_GL_MULTI_DRAW_ARRAYS: return "GL_MULTI_DRAW_ARRAYS";
    case XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_ELEMENTS: return "GL_DRAW_ELEMENTS";
    case XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_ARRAYS: return "GL_DRAW_ARRAYS";
    case XEMU_DIAG_PGRAPH_DRAW_GL_END_QUERY: return "GL_END_QUERY";
    case XEMU_DIAG_PGRAPH_DRAW_SURFACE_DIRTY: return "SURFACE_DIRTY";
    case XEMU_DIAG_PGRAPH_DRAW_VK_DRAW_END_TOTAL: return "VK_DRAW_END_TOTAL";
    case XEMU_DIAG_PGRAPH_DRAW_VK_FLUSH_DRAW: return "VK_FLUSH_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_BIND: return "VK_VERTEX_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_VK_ELEMENT_SCAN: return "VK_ELEMENT_SCAN";
    case XEMU_DIAG_PGRAPH_DRAW_VK_SYNC_VERTEX_RAM: return "VK_SYNC_VERTEX_RAM";
    case XEMU_DIAG_PGRAPH_DRAW_VK_REMAP_ATTRIBUTES: return "VK_REMAP_ATTRIBUTES";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PRE_DRAW: return "VK_PRE_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_PREP: return "VK_PIPELINE_PREP";
    case XEMU_DIAG_PGRAPH_DRAW_VK_FRAMEBUFFER_PREP: return "VK_FRAMEBUFFER_PREP";
    case XEMU_DIAG_PGRAPH_DRAW_VK_DESCRIPTOR_UPDATE: return "VK_DESCRIPTOR_UPDATE";
    case XEMU_DIAG_PGRAPH_DRAW_VK_COMMAND_BUFFER: return "VK_COMMAND_BUFFER";
    case XEMU_DIAG_PGRAPH_DRAW_VK_UPLOAD: return "VK_UPLOAD";
    case XEMU_DIAG_PGRAPH_DRAW_VK_BEGIN_DRAW: return "VK_BEGIN_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_VK_RENDER_PASS: return "VK_RENDER_PASS";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_BIND: return "VK_PIPELINE_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_VK_DESCRIPTOR_BIND: return "VK_DESCRIPTOR_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_VK_ISSUE_DRAW: return "VK_ISSUE_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_VK_END_DRAW: return "VK_END_DRAW";
    case XEMU_DIAG_PGRAPH_DRAW_VK_SURFACE_DIRTY: return "VK_SURFACE_DIRTY";
    case XEMU_DIAG_PGRAPH_DRAW_VK_TEXTURE_BIND: return "VK_TEXTURE_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_VK_SHADER_BIND: return "VK_SHADER_BIND";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_STATE_KEY: return "VK_PIPELINE_STATE_KEY";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_CACHE_LOOKUP: return "VK_PIPELINE_CACHE_LOOKUP";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_BUILD_STATE: return "VK_PIPELINE_BUILD_STATE";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_CREATE: return "VK_PIPELINE_CREATE";
    case XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_INSTALL: return "VK_PIPELINE_INSTALL";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_RANGE_PREP: return "VK_VERTEX_RANGE_PREP";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_DIRTY_CHECK: return "VK_VERTEX_DIRTY_CHECK";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_RANGE_UPDATE: return "VK_VERTEX_RANGE_UPDATE";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_SURFACE_DOWNLOAD: return "VK_VERTEX_SURFACE_DOWNLOAD";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_OVERLAP_CHECK: return "VK_VERTEX_OVERLAP_CHECK";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_DIRTY_FINISH: return "VK_VERTEX_DIRTY_FINISH";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_COPY: return "VK_VERTEX_COPY";
    case XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_BITMAP: return "VK_VERTEX_BITMAP";
    case XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_TOTAL: return "VK_FINISH_TOTAL";
    case XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_QUEUE_SUBMIT: return "VK_FINISH_QUEUE_SUBMIT";
    case XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_FENCE_WAIT: return "VK_FINISH_FENCE_WAIT";
    default: return "UNKNOWN";
    }
}

const char *PgraphDrawTracePathName(uint32_t path)
{
    switch (path) {
    case XEMU_DIAG_PGRAPH_DRAW_PATH_DRAW_ARRAYS: return "Draw Arrays";
    case XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_ELEMENTS: return "Inline Elements";
    case XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_BUFFER: return "Inline Buffer";
    case XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_ARRAY: return "Inline Array";
    case XEMU_DIAG_PGRAPH_DRAW_PATH_EMPTY: return "Empty";
    default: return "Unknown";
    }
}

const char *ControllerXidTraceEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_ADDED: return "HOST_GAMEPAD_ADDED";
    case XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_OPENED: return "HOST_GAMEPAD_OPENED";
    case XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_OPEN_FAILED: return "HOST_GAMEPAD_OPEN_FAILED";
    case XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_REMOVED: return "HOST_GAMEPAD_REMOVED";
    case XEMU_DIAG_CONTROLLER_XID_HOST_BIND: return "HOST_BIND";
    case XEMU_DIAG_CONTROLLER_XID_HOST_UNBIND: return "HOST_UNBIND";
    case XEMU_DIAG_CONTROLLER_XID_HOST_INPUT_STATE: return "HOST_INPUT_STATE";
    case XEMU_DIAG_CONTROLLER_XID_XID_REALIZE: return "XID_REALIZE";
    case XEMU_DIAG_CONTROLLER_XID_XID_UNREALIZE: return "XID_UNREALIZE";
    case XEMU_DIAG_CONTROLLER_XID_XID_RESET: return "XID_RESET";
    case XEMU_DIAG_CONTROLLER_XID_XID_GET_REPORT: return "GET_REPORT";
    case XEMU_DIAG_CONTROLLER_XID_XID_INTERRUPT_IN: return "INTERRUPT_IN";
    case XEMU_DIAG_CONTROLLER_XID_XID_INPUT_STATE: return "XID_INPUT_STATE";
    case XEMU_DIAG_CONTROLLER_XID_XID_BOUND_MISSING: return "XID_BOUND_MISSING";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_ATTACH: return "OHCI_PORT_ATTACH";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_DETACH: return "OHCI_PORT_DETACH";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_RHSC: return "OHCI_RHSC";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE: return "OHCI_PORT_STATUS_WRITE";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_RESET: return "OHCI_PORT_RESET";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_SETUP_TD: return "OHCI_SETUP_TD";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING: return "OHCI_TD_DEVICE_MISSING";
    case XEMU_DIAG_CONTROLLER_XID_USB_CONTROL_REQUEST: return "USB_CONTROL_REQUEST";
    case XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_NEUTRAL: return "HOST_PERSISTENT_NEUTRAL";
    case XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_REATTACHED: return "HOST_PERSISTENT_REATTACHED";
    case XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_ON: return "INPUT_TEST_MODE_ON";
    case XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_OFF: return "INPUT_TEST_MODE_OFF";
    case XEMU_DIAG_CONTROLLER_XID_XID_IN_PACKET_COMPLETE: return "XID_IN_PACKET_COMPLETE";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_TD_COMPLETE: return "OHCI_TD_COMPLETE";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_DONE_HEAD: return "OHCI_DONE_HEAD";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_WDH_IRQ: return "OHCI_WDH_IRQ";
    case XEMU_DIAG_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE: return "OHCI_GUEST_INPUT_WRITE";
    default: return "UNKNOWN";
    }
}

static std::string ControllerXidReportHex(
    const XemuDiagnosticsControllerXidTraceEvent &event)
{
    std::ostringstream os;
    const uint32_t count = std::min<uint32_t>(
        event.report_length, XEMU_DIAG_CONTROLLER_XID_REPORT_MAX);
    os << std::hex << std::uppercase << std::setfill('0');
    for (uint32_t i = 0; i < count; ++i) {
        os << std::setw(2) << static_cast<unsigned>(event.report[i]);
    }
    return os.str();
}

static const char *GuestInputConsumerEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_CHANGE:
        return "REPORT_CHANGE";
    case XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TITLE_TB:
        return "TITLE_TB";
    default:
        return "UNKNOWN";
    }
}

static std::string GuestInputConsumerReportHex(
    const XemuDiagnosticsGuestInputConsumerTraceEvent &event)
{
    std::ostringstream os;
    const uint32_t count = std::min<uint32_t>(
        event.report_length,
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX);
    os << std::hex << std::uppercase << std::setfill('0');
    for (uint32_t i = 0; i < count; ++i) {
        os << std::setw(2) << static_cast<unsigned>(event.report[i]);
    }
    return os.str();
}

static const char *GuestTimerDeadlineEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW:
        return "INPUT_SUB_LOW";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SBB_HIGH:
        return "INPUT_SBB_HIGH";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_RESULT:
        return "INPUT_RESULT";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_STORE_LOW:
        return "INPUT_STORE_LOW";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT:
        return "D3D_RDTSC_RESULT";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_HIGH:
        return "D3D_COMPARE_HIGH";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_LOW_RESULT:
        return "D3D_COMPARE_LOW_RESULT";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT:
        return "D3D_REJECT";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID:
        return "D3D_VALID";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RELATIVE_READY:
        return "D3D_RELATIVE_READY";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL:
        return "D3D_SCHEDULE_CALL";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN:
        return "D3D_SCHEDULE_RETURN";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC:
        return "D3D_DISPATCH_PC";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY:
        return "CALLBACK_ENTRY";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN:
        return "CALLBACK_RETURN";
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE:
        return "CALLBACK_OVERDUE";
    default:
        return "UNKNOWN";
    }
}

static const char *D3dTimerStateEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_CALL:
        return "SCHEDULE_CALL";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_RETURN:
        return "SCHEDULE_RETURN";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_DUE_ENTRY:
        return "DISPATCH_DUE_ENTRY";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SELECT:
        return "DISPATCH_SELECT";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_LOAD:
        return "DISPATCH_CALLBACK_LOAD";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_CALL:
        return "DISPATCH_CALLBACK_CALL";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SCAN:
        return "DISPATCH_SCAN";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_LIST:
        return "DISPATCH_LIST";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_IRQ_CHECK:
        return "DISPATCH_IRQ_CHECK";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_ENTRY:
        return "CALLBACK_ENTRY";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_OVERDUE:
        return "CALLBACK_OVERDUE";
    case XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_D3D_REJECT:
        return "D3D_REJECT";
    default:
        return "NONE";
    }
}

static const char *PtimerIrqDeliveryEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_SET: return "PTIMER_SET";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_NV2A_LINE: return "NV2A_LINE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PCI_ROUTE: return "PCI_ROUTE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PIC_CPU_LINE: return "PIC_CPU_LINE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_SAMPLE: return "TCG_SAMPLE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_HARD_TAKE: return "TCG_HARD_TAKE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PENDING_OVERDUE: return "PENDING_OVERDUE";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_CLEAR: return "PTIMER_CLEAR";
    default: return "NONE";
    }
}

static const char *PtimerIrqDeliveryClassName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_GUEST_IF_MASKED: return "GUEST_IF_MASKED";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_IRQ_INHIBITED: return "IRQ_INHIBITED";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_CPU_HARD_MISSING: return "CPU_HARD_MISSING";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_TCG_NOT_TAKEN: return "TCG_NOT_TAKEN";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_HARD_TAKEN_DURING_WINDOW: return "HARD_TAKEN_DURING_WINDOW";
    case XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_OTHER: return "OTHER";
    default: return "NONE";
    }
}

static double GuestTimerCyclesToUs(int64_t cycles)
{
    return (double)cycles * 1000000.0 / (double)XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TSC_HZ;
}

static std::string GuestTimerFormatU64(uint64_t value)
{
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%08X:%08X",
                  (uint32_t)(value >> 32), (uint32_t)value);
    return buf;
}

const char *UsbControlRequestName(uint32_t request)
{
    const uint32_t request_type = (request >> 8) & 0xff;
    const uint32_t request_code = request & 0xff;

    if ((request_type & 0x60) == 0x00) {
        switch (request_code) {
        case 0: return "GET_STATUS";
        case 1: return "CLEAR_FEATURE";
        case 3: return "SET_FEATURE";
        case 5: return "SET_ADDRESS";
        case 6: return "GET_DESCRIPTOR";
        case 7: return "SET_DESCRIPTOR";
        case 8: return "GET_CONFIGURATION";
        case 9: return "SET_CONFIGURATION";
        case 10: return "GET_INTERFACE";
        case 11: return "SET_INTERFACE";
        case 12: return "SYNCH_FRAME";
        default: break;
        }
    }
    if (request_type == 0xA1 && request_code == 1) {
        return "HID_GET_REPORT";
    }
    if (request_type == 0x21 && request_code == 9) {
        return "HID_SET_REPORT";
    }
    if ((request_type & 0x60) == 0x40 && request_code == 6) {
        return "XID_GET_DESCRIPTOR";
    }
    return "OTHER";
}

struct PgraphDrawTraceAnalysis {
    uint64_t worst_draw_ns = 0;
    uint64_t worst_stage_ns = 0;
    bool have_worst_draw = false;
    bool have_worst_stage = false;
    XemuDiagnosticsPgraphDrawTraceEvent worst_draw{};
    XemuDiagnosticsPgraphDrawTraceEvent worst_stage{};
};

PgraphDrawTraceAnalysis AnalyzePgraphDrawTrace(
    const std::vector<XemuDiagnosticsPgraphDrawTraceEvent> &trace)
{
    PgraphDrawTraceAnalysis result;
    for (const auto &event : trace) {
        if (event.stage == XEMU_DIAG_PGRAPH_DRAW_SET_BEGIN_END_TOTAL &&
            event.duration_host_ns > result.worst_draw_ns) {
            result.worst_draw_ns = event.duration_host_ns;
            result.worst_draw = event;
            result.have_worst_draw = true;
        }
        if (event.stage != XEMU_DIAG_PGRAPH_DRAW_SET_BEGIN_END_TOTAL &&
            event.duration_host_ns > result.worst_stage_ns) {
            result.worst_stage_ns = event.duration_host_ns;
            result.worst_stage = event;
            result.have_worst_stage = true;
        }
    }
    return result;
}

struct QemuTimerTraceAnalysis {
    int64_t worst_dispatch_late_ns = 0;
    int64_t worst_timeout_excess_ns = 0;
    int64_t worst_wait_overshoot_host_ns = 0;
    int64_t worst_wait_overshoot_virtual_ns = 0;
    int64_t worst_post_wait_gap_host_ns = 0;
    int64_t worst_post_wait_gap_virtual_ns = 0;
    int64_t late_wait_timeout_ns = 0;
    int64_t late_wait_elapsed_host_ns = 0;
    int64_t late_wait_elapsed_virtual_ns = 0;
    int64_t late_glib_acquire_host_ns = 0;
    int64_t late_glib_prepare_host_ns = 0;
    int64_t late_poll_host_ns = 0;
    int64_t late_busywait_host_ns = 0;
    int64_t late_poll_backend_host_ns = 0;
    int64_t late_main_loop_lock_host_ns = 0;
    int64_t late_replay_lock_host_ns = 0;
    int64_t late_bql_lock_host_ns = 0;
    int64_t late_wait_objects_host_ns = 0;
    int64_t late_glib_check_host_ns = 0;
    int64_t late_glib_dispatch_host_ns = 0;
    int64_t late_polling_callbacks_host_ns = 0;
    int64_t late_glib_release_host_ns = 0;
    bool saw_infinite_wait = false;
};

uint32_t MatchingQemuTimerStageEnter(uint32_t exit_type)
{
    switch (exit_type) {
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_EXIT:
        return XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER;
    case XEMU_DIAG_QTIMER_GLIB_PREPARE_EXIT:
        return XEMU_DIAG_QTIMER_GLIB_PREPARE_ENTER;
    case XEMU_DIAG_QTIMER_POLL_EXIT:
        return XEMU_DIAG_QTIMER_POLL_ENTER;
    case XEMU_DIAG_QTIMER_POLL_BUSYWAIT_EXIT:
        return XEMU_DIAG_QTIMER_POLL_BUSYWAIT_ENTER;
    case XEMU_DIAG_QTIMER_POLL_BACKEND_EXIT:
        return XEMU_DIAG_QTIMER_POLL_BACKEND_ENTER;
    case XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_EXIT:
        return XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_ENTER;
    case XEMU_DIAG_QTIMER_REPLAY_LOCK_EXIT:
        return XEMU_DIAG_QTIMER_REPLAY_LOCK_ENTER;
    case XEMU_DIAG_QTIMER_BQL_LOCK_EXIT:
        return XEMU_DIAG_QTIMER_BQL_LOCK_ENTER;
    case XEMU_DIAG_QTIMER_GLIB_CHECK_EXIT:
        return XEMU_DIAG_QTIMER_GLIB_CHECK_ENTER;
    case XEMU_DIAG_QTIMER_GLIB_DISPATCH_EXIT:
        return XEMU_DIAG_QTIMER_GLIB_DISPATCH_ENTER;
    case XEMU_DIAG_QTIMER_WAIT_OBJECTS_EXIT:
        return XEMU_DIAG_QTIMER_WAIT_OBJECTS_ENTER;
    case XEMU_DIAG_QTIMER_POLLING_CALLBACKS_EXIT:
        return XEMU_DIAG_QTIMER_POLLING_CALLBACKS_ENTER;
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_EXIT:
        return XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_ENTER;
    default:
        return 0;
    }
}

void AssignLateStageDuration(QemuTimerTraceAnalysis &result, uint32_t exit_type,
                             int64_t host_ns)
{
    switch (exit_type) {
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_EXIT:
        result.late_glib_acquire_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_GLIB_PREPARE_EXIT:
        result.late_glib_prepare_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_POLL_EXIT:
        result.late_poll_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_POLL_BUSYWAIT_EXIT:
        result.late_busywait_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_POLL_BACKEND_EXIT:
        result.late_poll_backend_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_EXIT:
        result.late_main_loop_lock_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_REPLAY_LOCK_EXIT:
        result.late_replay_lock_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_BQL_LOCK_EXIT:
        result.late_bql_lock_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_WAIT_OBJECTS_EXIT:
        result.late_wait_objects_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_GLIB_CHECK_EXIT:
        result.late_glib_check_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_GLIB_DISPATCH_EXIT:
        result.late_glib_dispatch_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_POLLING_CALLBACKS_EXIT:
        result.late_polling_callbacks_host_ns = host_ns; break;
    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_EXIT:
        result.late_glib_release_host_ns = host_ns; break;
    default:
        break;
    }
}

QemuTimerTraceAnalysis AnalyzeQemuTimerTrace(
    const std::vector<XemuDiagnosticsQemuTimerTraceEvent> &trace)
{
    QemuTimerTraceAnalysis result;
    uint64_t last_wait_exit_host_ns = 0;
    uint64_t last_wait_exit_virtual_ns = 0;
    bool have_wait_exit = false;
    size_t worst_dispatch_index = trace.size();

    for (size_t i = 0; i < trace.size(); ++i) {
        const auto &event = trace[i];
        switch (event.event_type) {
        case XEMU_DIAG_QTIMER_MAIN_WAIT_ENTER:
            if (event.watched_timer_pending && event.timer_delta_ns > 0) {
                if (event.timeout_ns < 0) {
                    result.saw_infinite_wait = true;
                } else {
                    result.worst_timeout_excess_ns = std::max(
                        result.worst_timeout_excess_ns,
                        event.timeout_ns - event.timer_delta_ns);
                }
            }
            break;
        case XEMU_DIAG_QTIMER_MAIN_WAIT_EXIT:
            if (event.timeout_ns >= 0) {
                result.worst_wait_overshoot_host_ns = std::max(
                    result.worst_wait_overshoot_host_ns,
                    event.wait_elapsed_host_ns - event.timeout_ns);
                result.worst_wait_overshoot_virtual_ns = std::max(
                    result.worst_wait_overshoot_virtual_ns,
                    event.wait_elapsed_virtual_ns - event.timeout_ns);
            }
            last_wait_exit_host_ns = event.host_ns;
            last_wait_exit_virtual_ns = event.qemu_virtual_ns;
            have_wait_exit = true;
            break;
        case XEMU_DIAG_QTIMER_RUN_TIMERS_ENTER:
            if (have_wait_exit) {
                result.worst_post_wait_gap_host_ns = std::max(
                    result.worst_post_wait_gap_host_ns,
                    (int64_t)(event.host_ns - last_wait_exit_host_ns));
                result.worst_post_wait_gap_virtual_ns = std::max(
                    result.worst_post_wait_gap_virtual_ns,
                    (int64_t)(event.qemu_virtual_ns - last_wait_exit_virtual_ns));
                have_wait_exit = false;
            }
            break;
        case XEMU_DIAG_QTIMER_DISPATCH_BEGIN:
            if (event.dispatch_late_ns > result.worst_dispatch_late_ns) {
                result.worst_dispatch_late_ns = event.dispatch_late_ns;
                worst_dispatch_index = i;
            }
            break;
        default:
            break;
        }
    }

    if (worst_dispatch_index < trace.size()) {
        const int32_t dispatch_thread = trace[worst_dispatch_index].thread_id;
        size_t wait_exit_index = trace.size();
        size_t wait_enter_index = trace.size();
        for (size_t i = worst_dispatch_index; i-- > 0;) {
            if (trace[i].thread_id == dispatch_thread &&
                trace[i].event_type == XEMU_DIAG_QTIMER_MAIN_WAIT_EXIT) {
                wait_exit_index = i;
                break;
            }
        }
        if (wait_exit_index < trace.size()) {
            for (size_t i = wait_exit_index; i-- > 0;) {
                if (trace[i].thread_id == dispatch_thread &&
                    trace[i].event_type == XEMU_DIAG_QTIMER_MAIN_WAIT_ENTER) {
                    wait_enter_index = i;
                    break;
                }
            }
        }
        if (wait_enter_index < trace.size() && wait_exit_index < trace.size()) {
            result.late_wait_timeout_ns = trace[wait_enter_index].timeout_ns;
            result.late_wait_elapsed_host_ns = trace[wait_exit_index].wait_elapsed_host_ns;
            result.late_wait_elapsed_virtual_ns = trace[wait_exit_index].wait_elapsed_virtual_ns;

            using StageKey = std::pair<int32_t, uint32_t>;
            std::map<StageKey, uint64_t> stage_enter_host;
            for (size_t i = wait_enter_index; i <= wait_exit_index; ++i) {
                const auto &event = trace[i];
                if (event.thread_id != dispatch_thread) {
                    continue;
                }
                const uint32_t enter_for_exit = MatchingQemuTimerStageEnter(event.event_type);
                if (enter_for_exit != 0) {
                    const StageKey key{event.thread_id, enter_for_exit};
                    const auto it = stage_enter_host.find(key);
                    if (it != stage_enter_host.end()) {
                        AssignLateStageDuration(result, event.event_type,
                            (int64_t)(event.host_ns - it->second));
                        stage_enter_host.erase(it);
                    }
                } else {
                    switch (event.event_type) {
                    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER:
                    case XEMU_DIAG_QTIMER_GLIB_PREPARE_ENTER:
                    case XEMU_DIAG_QTIMER_POLL_ENTER:
                    case XEMU_DIAG_QTIMER_POLL_BUSYWAIT_ENTER:
                    case XEMU_DIAG_QTIMER_POLL_BACKEND_ENTER:
                    case XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_ENTER:
                    case XEMU_DIAG_QTIMER_REPLAY_LOCK_ENTER:
                    case XEMU_DIAG_QTIMER_BQL_LOCK_ENTER:
                    case XEMU_DIAG_QTIMER_WAIT_OBJECTS_ENTER:
                    case XEMU_DIAG_QTIMER_GLIB_CHECK_ENTER:
                    case XEMU_DIAG_QTIMER_GLIB_DISPATCH_ENTER:
                    case XEMU_DIAG_QTIMER_POLLING_CALLBACKS_ENTER:
                    case XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_ENTER:
                        stage_enter_host[{event.thread_id, event.event_type}] = event.host_ns;
                        break;
                    default:
                        break;
                    }
                }
            }
        }
    }
    return result;
}

const char *LikelyQemuTimerDelayStage(const QemuTimerTraceAnalysis &analysis)
{
    constexpr int64_t kSignificantNs = 1000 * 1000;
    if (analysis.worst_dispatch_late_ns < kSignificantNs) {
        return "No significant late PTIMER dispatch retained";
    }
    if (analysis.saw_infinite_wait ||
        analysis.worst_timeout_excess_ns >= kSignificantNs) {
        return "Main-loop timeout/deadline selection";
    }
    if (analysis.worst_wait_overshoot_host_ns >= kSignificantNs ||
        analysis.worst_wait_overshoot_virtual_ns >= kSignificantNs) {
        if (analysis.late_busywait_host_ns >= kSignificantNs) {
            return "qemu_poll_ns Xbox busy-wait / host thread deschedule";
        }
        if (analysis.late_poll_backend_host_ns >= kSignificantNs) {
            return "qemu_poll_ns poll backend";
        }
        if (analysis.late_main_loop_lock_host_ns >= kSignificantNs) {
            return "Xemu main-loop lock reacquire";
        }
        if (analysis.late_replay_lock_host_ns >= kSignificantNs) {
            return "Replay mutex reacquire";
        }
        if (analysis.late_bql_lock_host_ns >= kSignificantNs) {
            return "BQL reacquire";
        }
        if (analysis.late_glib_acquire_host_ns >= kSignificantNs) {
            return "GLib context acquire";
        }
        if (analysis.late_glib_prepare_host_ns >= kSignificantNs) {
            return "GLib poll preparation";
        }
        if (analysis.late_wait_objects_host_ns >= kSignificantNs) {
            return "Windows wait-object callback dispatch";
        }
        if (analysis.late_glib_check_host_ns >= kSignificantNs) {
            return "GLib context check";
        }
        if (analysis.late_glib_dispatch_host_ns >= kSignificantNs) {
            return "GLib context dispatch";
        }
        if (analysis.late_polling_callbacks_host_ns >= kSignificantNs) {
            return "Windows polling callback dispatch";
        }
        if (analysis.late_glib_release_host_ns >= kSignificantNs) {
            return "GLib context release";
        }
        if (analysis.late_poll_host_ns >= kSignificantNs) {
            return "qemu_poll_ns (internal substage not retained)";
        }
        return "OS/main-loop wait overshoot";
    }
    if (analysis.worst_post_wait_gap_host_ns >= kSignificantNs ||
        analysis.worst_post_wait_gap_virtual_ns >= kSignificantNs) {
        return "Delay after main-loop wait before timer dispatch";
    }
    return "Timer-list dispatch or another scheduler stage";
}

void DrawHexPair(const char *label, uint32_t pending, uint32_t enabled)
{
    ImGui::Text("%-20s  pending %08X   enabled %08X   active %08X",
                label, pending, enabled, pending & enabled);
}

void DrawBoolState(const char *label, bool value)
{
    ImGui::Text("%-28s %s", label, value ? "Yes" : "No");
}

std::string DefaultAutoSavePath()
{
    const std::string directory =
        XemuDebugOutput::Directory(XemuDebugOutput::Folder::Snapshots);
    return directory.empty()
               ? std::string("XEMU-Diagnostics-Live.txt")
               : XemuDebugOutput::Join(directory, "XEMU-Diagnostics-Live.txt");
}

} // namespace

size_t DiagnosticsWindow::WatchSize(WatchType type)
{
    switch (type) {
    case WatchType::U8: return 1;
    case WatchType::U16: return 2;
    case WatchType::U32:
    case WatchType::S32:
    case WatchType::Float32: return 4;
    case WatchType::U64:
    case WatchType::Float64: return 8;
    }
    return 4;
}

std::string DiagnosticsWindow::FormatWatchValue(const CustomWatch &watch)
{
    char buf[128];
    if (!watch.enabled) {
        return "<disabled>";
    }
    if (!watch.valid) {
        return "<unmapped / non-RAM>";
    }

    switch (watch.type) {
    case WatchType::U8:
        std::snprintf(buf, sizeof(buf), "%02X (%u)", watch.raw[0],
                      (unsigned)watch.raw[0]);
        break;
    case WatchType::U16: {
        uint16_t v = 0;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%04X (%u)", v, (unsigned)v);
        break;
    }
    case WatchType::U32: {
        uint32_t v = 0;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%08X (%u)", v, v);
        break;
    }
    case WatchType::U64: {
        uint64_t v = 0;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%016llX (%llu)",
                      (unsigned long long)v, (unsigned long long)v);
        break;
    }
    case WatchType::S32: {
        int32_t v = 0;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%08X (%d)", (uint32_t)v, v);
        break;
    }
    case WatchType::Float32: {
        float v = 0.0f;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%.9g", v);
        break;
    }
    case WatchType::Float64: {
        double v = 0.0;
        std::memcpy(&v, watch.raw.data(), sizeof(v));
        std::snprintf(buf, sizeof(buf), "%.17g", v);
        break;
    }
    }
    return buf;
}

void DiagnosticsWindow::AddEvent(uint64_t now_ms, const char *category,
                                 const std::string &text)
{
    if (m_pause_history) {
        return;
    }
    if (m_session_start_ms == 0) {
        m_session_start_ms = now_ms;
    }
    m_events.push_back({now_ms - m_session_start_ms,
                        category ? category : "Info", text});
    const size_t max_events = kBaseMaxEvents * (size_t)std::max(1u, m_recent_events_multiplier);
    while (m_events.size() > max_events) {
        m_events.pop_front();
    }
}

void DiagnosticsWindow::ResetTscBaseline()
{
    m_tsc_baseline_valid = false;
    m_tsc_drift_ticks = 0;
    m_tsc_drift_us = 0.0;
    m_tsc_warning = false;
}

void DiagnosticsWindow::NotifyGameReset()
{
    const uint64_t now_ms = SDL_GetTicks();
    AddEvent(now_ms, "Reset", "Xbox game/system reset requested");
    ResetTscBaseline();
    m_pc_history.clear();
    m_eip_same_since_ms = now_ms;
    m_pc_stall_warning = false;
    m_gpu_stall_warning = false;
    m_ptimer_late_warning = false;
    m_scheduler_idle_warning = false;
    m_last_scheduler_trace_total_events = 0;
}

void DiagnosticsWindow::SampleWatches(uint64_t now_ms)
{
    for (CustomWatch &watch : m_watches) {
        if (!watch.enabled) {
            watch.valid = false;
            watch.physical_valid = false;
            watch.warning_active = false;
            continue;
        }

        const size_t size = WatchSize(watch.type);
        std::array<uint8_t, 8> next{};
        uint64_t physical = 0;
        const bool ok = ReadWatchRamOnly(
            watch.virtual_address, watch.address, next.data(), size, &physical);

        if (!ok) {
            if (watch.valid) {
                AddEvent(now_ms, "Watch",
                         std::string(watch.name.data()) +
                             " became unmapped or resolved outside Xbox RAM");
            }
            watch.valid = false;
            watch.physical_valid = false;
            watch.warning_active = false;
            continue;
        }
        watch.physical_address = physical;
        watch.physical_valid = true;

        if (!watch.valid ||
            std::memcmp(next.data(), watch.raw.data(), size) != 0) {
            watch.previous_raw = watch.raw;
            watch.raw = next;
            watch.valid = true;
            watch.last_change_ms = now_ms;
            if (watch.warning_active) {
                AddEvent(now_ms, "Watch",
                         std::string(watch.name.data()) + " changed again");
            }
            watch.warning_active = false;
        } else if (watch.warn_if_unchanged &&
                   now_ms - watch.last_change_ms >=
                       watch.unchanged_warning_ms &&
                   !watch.warning_active) {
            watch.warning_active = true;
            std::ostringstream os;
            os << watch.name.data() << " unchanged for "
               << watch.unchanged_warning_ms << " ms at "
               << (watch.virtual_address ? "V:" : "P:")
               << std::hex << std::uppercase << std::setw(8)
               << std::setfill('0') << watch.address;
            AddEvent(now_ms, "Watch", os.str());
        }
    }
}

size_t DiagnosticsWindow::PcUniqueCount(uint64_t now_ms) const
{
    std::set<uint32_t> unique;
    for (const auto &entry : m_pc_history) {
        if (now_ms >= entry.first && now_ms - entry.first <= 5000) {
            unique.insert(entry.second);
        }
    }
    return unique.size();
}

void DiagnosticsWindow::UpdateBqlRecentEvents(uint64_t now_ms)
{
    constexpr uint64_t kRecentEventThresholdNs = 25ULL * 1000ULL * 1000ULL;
    constexpr size_t kMaxScanEvents = 512;

    XemuDiagnosticsBqlTraceStatus status{};
    if (!xemu_diagnostics_get_bql_trace_status(&status) || !status.enabled) {
        m_last_bql_trace_total_events = 0;
        return;
    }
    if (status.total_events < m_last_bql_trace_total_events) {
        /* Trace was cleared or re-enabled; sequence numbering restarted. */
        m_last_bql_trace_total_events = 0;
    }
    if (status.total_events == m_last_bql_trace_total_events || status.count == 0) {
        return;
    }

    const size_t capacity = std::min(status.count, kMaxScanEvents);
    std::vector<XemuDiagnosticsBqlTraceEvent> trace(capacity);
    const size_t count = xemu_diagnostics_get_bql_trace(trace.data(), trace.size());
    for (size_t i = 0; i < count; ++i) {
        const auto &event = trace[i];
        if (event.sequence < m_last_bql_trace_total_events ||
            event.event_type != XEMU_DIAG_BQL_LONG_HOLD ||
            event.held_ns < kRecentEventThresholdNs) {
            continue;
        }

        std::ostringstream os;
        os << "BQL held " << std::fixed << std::setprecision(3)
           << ((double)event.held_ns / 1000000.0) << " ms by "
           << BqlTraceContextName(event.caller_context);
        if (event.longest_stage != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE) {
            os << "; longest stage " << BqlTraceStageName(event.longest_stage)
               << " " << std::fixed << std::setprecision(3)
               << ((double)event.longest_stage_ns / 1000000.0) << " ms";
        }
        os << " (TID " << event.thread_id << ")";
        AddEvent(now_ms, "BQL", os.str());
    }
    m_last_bql_trace_total_events = status.total_events;
}

void DiagnosticsWindow::UpdateFlipRecentEvents(uint64_t now_ms)
{
    constexpr uint64_t kLongFlipNs = 25ULL * 1000ULL * 1000ULL;
    constexpr uint64_t kActiveWarningNs = 100ULL * 1000ULL * 1000ULL;
    constexpr size_t kMaxScanEvents = 512;

    XemuDiagnosticsFlipStallStatus status{};
    if (!xemu_diagnostics_get_flip_stall_trace_status(&status) || !status.enabled) {
        m_last_flip_trace_total_events = 0;
        m_flip_stall_warning = false;
        return;
    }
    if (status.total_events < m_last_flip_trace_total_events) {
        m_last_flip_trace_total_events = 0;
        m_flip_stall_warning = false;
    }

    if (status.total_events != m_last_flip_trace_total_events && status.count != 0) {
        const size_t capacity = std::min(status.count, kMaxScanEvents);
        std::vector<XemuDiagnosticsFlipStallEvent> trace(capacity);
        const size_t count = xemu_diagnostics_get_flip_stall_trace(
            trace.data(), trace.size());
        for (size_t i = 0; i < count; ++i) {
            const auto &event = trace[i];
            if (event.sequence < m_last_flip_trace_total_events) {
                continue;
            }
            if (event.event_type == XEMU_DIAG_FLIP_VK_FINISH_END &&
                event.duration_ns >= kLongFlipNs) {
                std::ostringstream os;
                os << "Vulkan FLIP_STALL finish took " << std::fixed
                   << std::setprecision(3)
                   << ((double)event.duration_ns / 1000000.0) << " ms"
                   << " (R/W/M " << event.read_3d << "/" << event.write_3d
                   << "/" << event.modulo_3d << ")";
                AddEvent(now_ms, "FLIP", os.str());
            } else if (event.event_type == XEMU_DIAG_FLIP_PFIFO_RELEASE &&
                       event.duration_ns >= kLongFlipNs) {
                std::ostringstream os;
                os << "PFIFO released FLIP_STALL after " << std::fixed
                   << std::setprecision(3)
                   << ((double)event.duration_ns / 1000000.0) << " ms"
                   << " (R/W/M " << event.read_3d << "/" << event.write_3d
                   << "/" << event.modulo_3d << ")";
                AddEvent(now_ms, "FLIP", os.str());
            }
        }
        m_last_flip_trace_total_events = status.total_events;
    }

    if (status.active_stall && status.active_stall_age_ns >= kActiveWarningNs) {
        if (!m_flip_stall_warning) {
            std::ostringstream os;
            os << "FLIP_STALL still active after " << std::fixed
               << std::setprecision(3)
               << ((double)status.active_stall_age_ns / 1000000.0) << " ms";
            AddEvent(now_ms, "FLIP", os.str());
            m_flip_stall_warning = true;
        }
    } else if (!status.active_stall) {
        m_flip_stall_warning = false;
    }
}

void DiagnosticsWindow::UpdateSchedulerRecentEvents(uint64_t now_ms)
{
    constexpr uint64_t kIdleWarningNs = 1000ULL * 1000ULL * 1000ULL;
    constexpr size_t kMaxScanEvents = 256;
    XemuDiagnosticsSchedulerTraceStatus status{};

    if (!xemu_diagnostics_get_scheduler_trace_status(&status) || !status.enabled) {
        m_last_scheduler_trace_total_events = 0;
        m_scheduler_idle_warning = false;
        return;
    }
    if (status.total_events < m_last_scheduler_trace_total_events) {
        m_last_scheduler_trace_total_events = 0;
        m_scheduler_idle_warning = false;
    }

    if (status.total_events != m_last_scheduler_trace_total_events && status.count) {
        const size_t capacity = std::min(status.count, kMaxScanEvents);
        std::vector<XemuDiagnosticsSchedulerTraceEvent> trace(capacity);
        const size_t count = xemu_diagnostics_get_scheduler_trace(
            trace.data(), trace.size());
        for (size_t i = 0; i < count; ++i) {
            const auto &event = trace[i];
            if (event.sequence < m_last_scheduler_trace_total_events) {
                continue;
            }
            if (event.event_type == XEMU_DIAG_SCHED_IDLE_CHECKPOINT &&
                event.idle_age_ns >= kIdleWarningNs && !m_scheduler_idle_warning) {
                std::ostringstream os;
                os << "KiIdleLoop active for " << std::fixed << std::setprecision(3)
                   << ((double)event.idle_age_ns / 1000000.0) << " ms"
                   << "; last title PC " << FormatGuestPc(event.last_title_pc)
                   << "; IRQs V/Pt/Pg/Pf/OHCI=" << event.idle_vblank_count << "/"
                   << event.idle_ptimer_count << "/" << event.idle_pgraph_count
                   << "/" << event.idle_pfifo_count << "/" << event.idle_ohci_count;
                AddEvent(now_ms, "Scheduler", os.str());
                m_scheduler_idle_warning = true;
            } else if (event.event_type == XEMU_DIAG_SCHED_IDLE_EXIT &&
                       event.duration_ns >= kIdleWarningNs) {
                std::ostringstream os;
                os << "KiIdleLoop exited after " << std::fixed << std::setprecision(3)
                   << ((double)event.duration_ns / 1000000.0) << " ms"
                   << "; wake activity " << SchedulerWakeSourceName(event.last_irq_source)
                   << "; next PC " << FormatGuestPc(event.guest_pc);
                AddEvent(now_ms, "Scheduler", os.str());
                m_scheduler_idle_warning = false;
            } else if (event.event_type == XEMU_DIAG_SCHED_TITLE_RETURN &&
                       event.duration_ns >= kIdleWarningNs) {
                std::ostringstream os;
                os << "Title execution returned at PC " << FormatGuestPc(event.guest_pc)
                   << " after idle sequence " << std::fixed
                   << std::setprecision(3)
                   << ((double)event.duration_ns / 1000000.0) << " ms";
                AddEvent(now_ms, "Scheduler", os.str());
            }
        }
        m_last_scheduler_trace_total_events = status.total_events;
    }

    if (!status.active_idle) {
        m_scheduler_idle_warning = false;
    }
}

void DiagnosticsWindow::UpdateDetectors(uint64_t now_ms)
{
    const bool running = m_timing.running != 0;

    if (!m_running_initialized) {
        m_last_running = running;
        m_running_initialized = true;
    } else if (running != m_last_running) {
        AddEvent(now_ms, "Runstate", running ? "Guest resumed" : "Guest paused/stopped");
        m_last_running = running;
    }

    if (m_regs_valid) {
        m_pc_history.push_back({now_ms, m_regs.eip});
        while (!m_pc_history.empty() &&
               now_ms - m_pc_history.front().first > 5000) {
            m_pc_history.pop_front();
        }

        if (m_sample_count == 0 || m_regs.eip != m_last_eip) {
            if (m_pc_stall_warning) {
                AddEvent(now_ms, "CPU", "Sampled EIP changed after hot-loop/stall warning");
            }
            m_last_eip = m_regs.eip;
            m_eip_same_since_ms = now_ms;
            m_pc_stall_warning = false;
        } else if (running && now_ms - m_eip_same_since_ms >= 1000 &&
                   !m_pc_stall_warning) {
            m_pc_stall_warning = true;
            const std::string pc = FormatGuestPc(m_regs.eip);
            char msg[320];
            std::snprintf(msg, sizeof(msg),
                          "Sampled EIP %s unchanged for >= 1 second (hot loop/stall candidate)",
                          pc.c_str());
            AddEvent(now_ms, "CPU", msg);
        }
    }

    if (m_timing.actual_tsc_valid) {
        const int64_t offset =
            (int64_t)(m_timing.actual_tsc - m_timing.expected_xbox_tsc);
        if (!m_tsc_baseline_valid) {
            m_tsc_offset_baseline = offset;
            m_tsc_baseline_valid = true;
        }
        m_tsc_drift_ticks = offset - m_tsc_offset_baseline;
        const double hz = m_timing.whpx_processor_clock_valid &&
                                  m_timing.whpx_processor_clock_hz != 0
                              ? (double)m_timing.whpx_processor_clock_hz
                              : kXboxTscHz;
        m_tsc_drift_us = (double)m_tsc_drift_ticks * 1000000.0 / hz;

        const bool warning = std::fabs(m_tsc_drift_us) >= 1000.0;
        if (warning && !m_tsc_warning) {
            char msg[160];
            std::snprintf(msg, sizeof(msg),
                          "Guest TSC drift from diagnostics baseline reached %+.3f ms",
                          m_tsc_drift_us / 1000.0);
            AddEvent(now_ms, "Timing", msg);
        } else if (!warning && m_tsc_warning) {
            AddEvent(now_ms, "Timing", "Guest TSC drift returned below 1 ms");
        }
        m_tsc_warning = warning;
    }

    if (m_device.nv2a_available) {
        if (m_last_gpu_frame_change_ms == 0 ||
            m_device.gpu_frame_count != m_last_gpu_frame_count) {
            if (m_gpu_stall_warning) {
                AddEvent(now_ms, "GPU", "NV2A frame completion resumed");
            }
            m_last_gpu_frame_count = m_device.gpu_frame_count;
            m_last_gpu_frame_change_ms = now_ms;
            m_gpu_stall_warning = false;
        } else if (running && now_ms - m_last_gpu_frame_change_ms >= 1500 &&
                   !m_gpu_stall_warning) {
            m_gpu_stall_warning = true;
            AddEvent(now_ms, "GPU", "No NV2A frame completion observed for >= 1.5 seconds");
        }

        const bool ptimer_late =
            (m_device.ptimer_enabled != 0) &&
            m_device.ptimer_alarm_delta_ns <= -1000000LL;
        if (ptimer_late && !m_ptimer_late_warning) {
            AddEvent(now_ms, "PTIMER",
                     "PTIMER alarm target is >= 1 ms behind current PTIMER time");
        } else if (!ptimer_late && m_ptimer_late_warning) {
            AddEvent(now_ms, "PTIMER", "PTIMER alarm lateness cleared");
        }
        m_ptimer_late_warning = ptimer_late;

        const uint32_t ptimer_active =
            m_device.ptimer_pending & m_device.ptimer_enabled;
        if (ptimer_active && !m_last_ptimer_pending) {
            AddEvent(now_ms, "IRQ", "PTIMER interrupt became pending+enabled");
        }
        m_last_ptimer_pending = ptimer_active;
    }

    if (m_device.apu_available) {
        const bool apu_warning =
            std::llabs(m_device.apu_deviation_max_us) >= 5000;
        if (apu_warning && !m_apu_timing_warning) {
            char msg[160];
            std::snprintf(msg, sizeof(msg),
                          "APU frame pacing max deviation reached %lld us",
                          (long long)m_device.apu_deviation_max_us);
            AddEvent(now_ms, "Audio", msg);
        } else if (!apu_warning && m_apu_timing_warning) {
            AddEvent(now_ms, "Audio", "APU frame pacing deviation returned below 5 ms");
        }
        m_apu_timing_warning = apu_warning;
    }

    UpdateBqlRecentEvents(now_ms);
    UpdateFlipRecentEvents(now_ms);
    UpdateSchedulerRecentEvents(now_ms);
}

void DiagnosticsWindow::Sample(uint64_t now_ms)
{
    m_regs_valid = xemu_cheat_get_x86_registers(&m_regs) != 0;
    m_stack_valid = false;
    m_disasm_count = 0;
    if (m_regs_valid) {
        m_stack_valid = xemu_cheat_memory_read(
            1, m_regs.esp, m_stack.data(),
            m_stack.size() * sizeof(m_stack[0])) != 0;
        if (xemu_cheat_disassembler_available()) {
            size_t row_count = 0;
            if (xemu_cheat_disassemble_paired(
                    m_regs.eip, (int)m_disasm.size(), m_disasm.data(),
                    m_disasm.size(), &row_count) == XEMU_CHEAT_DISAS_OK) {
                m_disasm_count = std::min(row_count, m_disasm.size());
            }
        }
    }
    xemu_diagnostics_get_timing_snapshot(&m_timing);
    xemu_diagnostics_get_device_snapshot(&m_device);
    SampleWatches(now_ms);
    UpdateDetectors(now_ms);
    ++m_sample_count;
}

bool DiagnosticsWindow::AllRecordingOptionsEnabled() const
{
    XemuDiagnosticsPtimerTraceStatus ptimer{};
    XemuDiagnosticsQemuTimerTraceStatus qtimer{};
    XemuDiagnosticsSlowTimerTraceStatus slow_timer{};
    XemuDiagnosticsBqlTraceStatus bql{};
    XemuDiagnosticsMainLoopLockTraceStatus main_loop_lock{};
    XemuDiagnosticsMmioTraceStatus mmio{};
    XemuDiagnosticsPgraphLockTraceStatus pgraph_lock{};
    XemuDiagnosticsPgraphDrawTraceStatus pgraph_draw{};
    XemuDiagnosticsFlipStallStatus flip_stall{};
    XemuDiagnosticsPgraphFlipDelayStatus pgraph_flip_delay{};
    XemuDiagnosticsPgraphPusherProgressStatus pgraph_pusher_progress{};
    XemuDiagnosticsPgraphPusherMethodBreakdownStatus pgraph_method_breakdown{};
    XemuDiagnosticsAvSyncTraceStatus av_sync{};
    XemuDiagnosticsSchedulerTraceStatus scheduler{};
    XemuDiagnosticsControllerXidTraceStatus controller_xid{};
    XemuDiagnosticsGuestInputConsumerTraceStatus guest_input_consumer{};
    XemuDiagnosticsGuestTimerDeadlineTraceStatus guest_timer_deadline{};
    XemuDiagnosticsPtimerLateCaptureStatus ptimer_late_capture{};
    XemuDiagnosticsD3dCallbackCaptureStatus d3d_callback_capture{};
    XemuDiagnosticsPtimerIrqDeliveryStatus ptimer_irq_delivery{};
    XemuDiagnosticsHostStallStatus host_stall{};
    XemuDiagnosticsLatencyTraceStatus pgraph_increment{};
    XemuDiagnosticsLatencyTraceStatus ptimer_irq_latency{};
    XemuDiagnosticsOhciSlowFrameStatus ohci_slow{};
    XemuDiagnosticsControllerInputPollStatus input_poll{};

    xemu_diagnostics_get_ptimer_trace_status(&ptimer);
    xemu_diagnostics_get_qemu_timer_trace_status(&qtimer);
    xemu_diagnostics_get_slow_timer_trace_status(&slow_timer);
    xemu_diagnostics_get_bql_trace_status(&bql);
    xemu_diagnostics_get_main_loop_lock_trace_status(&main_loop_lock);
    xemu_diagnostics_get_mmio_trace_status(&mmio);
    xemu_diagnostics_get_pgraph_lock_trace_status(&pgraph_lock);
    xemu_diagnostics_get_pgraph_draw_trace_status(&pgraph_draw);
    xemu_diagnostics_get_flip_stall_trace_status(&flip_stall);
    xemu_diagnostics_get_pgraph_flip_delay_trace_status(&pgraph_flip_delay);
    xemu_diagnostics_get_pgraph_pusher_progress_trace_status(&pgraph_pusher_progress);
    xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
        &pgraph_method_breakdown);
    xemu_diagnostics_get_av_sync_trace_status(&av_sync);
    xemu_diagnostics_get_scheduler_trace_status(&scheduler);
    xemu_diagnostics_get_controller_xid_trace_status(&controller_xid);
    xemu_diagnostics_get_guest_input_consumer_trace_status(
        &guest_input_consumer);
    xemu_diagnostics_get_guest_timer_deadline_trace_status(
        &guest_timer_deadline);
    xemu_diagnostics_get_ptimer_late_capture_status(&ptimer_late_capture);
    xemu_diagnostics_get_d3d_callback_capture_status(&d3d_callback_capture);
    xemu_diagnostics_get_ptimer_irq_delivery_trace_status(&ptimer_irq_delivery);
    xemu_diagnostics_get_host_stall_trace_status(&host_stall);
    xemu_diagnostics_get_pgraph_increment_trace_status(&pgraph_increment);
    xemu_diagnostics_get_ptimer_irq_latency_trace_status(&ptimer_irq_latency);
    xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_slow);
    xemu_diagnostics_get_controller_input_poll_trace_status(&input_poll);

    return ptimer.enabled && qtimer.enabled && slow_timer.enabled &&
           bql.enabled && main_loop_lock.enabled && mmio.enabled && pgraph_lock.enabled &&
           pgraph_draw.enabled && flip_stall.enabled &&
           pgraph_flip_delay.enabled && pgraph_pusher_progress.enabled &&
           pgraph_method_breakdown.enabled && av_sync.enabled &&
           scheduler.enabled &&
           controller_xid.enabled && guest_input_consumer.enabled &&
           guest_timer_deadline.enabled && ptimer_late_capture.enabled &&
           d3d_callback_capture.enabled && ptimer_irq_delivery.enabled &&
           host_stall.enabled &&
           pgraph_increment.enabled && ptimer_irq_latency.enabled &&
           ohci_slow.enabled && input_poll.enabled;
}

void DiagnosticsWindow::SetAllRecordingOptionsEnabled(bool enabled)
{
    const int value = enabled ? 1 : 0;
    xemu_diagnostics_ptimer_trace_set_enabled(value);
    xemu_diagnostics_qemu_timer_trace_set_enabled(value);
    xemu_diagnostics_slow_timer_trace_set_enabled(value);
    xemu_diagnostics_pgraph_increment_trace_set_enabled(value);
    xemu_diagnostics_ptimer_irq_latency_trace_set_enabled(value);
    xemu_diagnostics_ptimer_irq_delivery_trace_set_enabled(value);
    xemu_diagnostics_host_stall_trace_set_enabled(value);
    xemu_diagnostics_bql_trace_set_enabled(value);
    xemu_diagnostics_main_loop_lock_trace_set_enabled(value);
    xemu_diagnostics_mmio_trace_set_enabled(value);
    xemu_diagnostics_pgraph_lock_trace_set_enabled(value);
    xemu_diagnostics_pgraph_draw_trace_set_enabled(value);
    xemu_diagnostics_flip_stall_trace_set_enabled(value);
    xemu_diagnostics_pgraph_flip_delay_trace_set_enabled(value);
    xemu_diagnostics_pgraph_pusher_progress_trace_set_enabled(value);
    xemu_diagnostics_pgraph_pusher_method_breakdown_trace_set_enabled(value);
    xemu_diagnostics_av_sync_trace_set_enabled(value);
    xemu_diagnostics_scheduler_trace_set_enabled(value);
    xemu_diagnostics_controller_xid_trace_set_enabled(value);
    xemu_diagnostics_guest_input_consumer_trace_set_enabled(value);
    xemu_diagnostics_guest_timer_deadline_trace_set_enabled(value);
    xemu_diagnostics_ptimer_late_capture_set_enabled(value);
    xemu_diagnostics_d3d_callback_capture_set_enabled(value);
    xemu_diagnostics_ohci_slow_frame_trace_set_enabled(value);
    xemu_diagnostics_controller_input_poll_trace_set_enabled(value);
    m_status = enabled ? "All diagnostics recording options enabled."
                       : "All diagnostics recording options disabled.";
}

void DiagnosticsWindow::QueueSnapshotSave(uint64_t now_ms, bool from_hotkey)
{
    /* Capture the small live CPU/device summary from the synchronized Debug
     * Tools tick. The expensive text formatting and file I/O are deferred
     * until after the frame has been presented. */
    Sample(now_ms);
    m_last_sample_ms = now_ms;
    m_save_snapshot_requested = true;
    m_status = from_hotkey ? "Diagnostics snapshot queued by F4."
                           : "Diagnostics snapshot queued.";
    if (from_hotkey) {
        xemu_queue_notification("Diagnostics snapshot queued (F4).");
    }
}

void DiagnosticsWindow::HandleHotkeys(uint64_t now_ms)
{
    /* Tick normally runs inside the main HUD ImGui frame.  Keep this guard so
     * a future non-UI tick caller cannot dereference a missing/currently
     * detached ImGui context. */
    if (ImGui::GetCurrentContext() == nullptr) {
        return;
    }

    ImGuiIO &io = ImGui::GetIO();
    if (io.WantTextInput || io.KeyAlt || io.KeyCtrl || io.KeyShift ||
        io.KeySuper) {
        return;
    }

    if (ImGui::IsKeyPressed(ImGuiKey_F3, false)) {
        const bool enable = !AllRecordingOptionsEnabled();
        SetAllRecordingOptionsEnabled(enable);
        xemu_queue_notification(enable
                                    ? "Diagnostics recording enabled (F3)."
                                    : "Diagnostics recording disabled (F3).");
    }

    if (ImGui::IsKeyPressed(ImGuiKey_F4, false)) {
        QueueSnapshotSave(now_ms, true);
    }
}

void DiagnosticsWindow::MaybeAutoSave(uint64_t now_ms)
{
    if (!m_auto_save || m_auto_save_requested ||
        now_ms - m_last_auto_save_ms < m_auto_save_interval_ms) {
        return;
    }

    /* Do not serialize or write a potentially very large snapshot while the
     * HUD owns the BQL.  ProcessDeferredActions() performs it post-present. */
    m_auto_save_requested = true;
    m_last_auto_save_ms = now_ms;
}

void DiagnosticsWindow::Tick()
{
    const uint64_t now_ms = SDL_GetTicks();
    HandleHotkeys(now_ms);
    /* Lightweight PC classification runs every Debug Tools tick when enabled;
     * retained transition events perform the heavier synchronized snapshot. */
    xemu_diagnostics_scheduler_trace_sample();

    if (!is_open && !m_auto_save && !m_save_snapshot_requested &&
        !m_manual_refresh_requested && !m_manual_snapshot_requested) {
        return;
    }

    if (m_session_start_ms == 0) {
        m_session_start_ms = now_ms;
    }

    bool sampled_this_tick = false;
    if (m_manual_snapshot_requested) {
        m_manual_snapshot_requested = false;
        QueueSnapshotSave(now_ms, false);
        sampled_this_tick = true;
    }
    if (m_manual_refresh_requested) {
        m_manual_refresh_requested = false;
        if (!sampled_this_tick) {
            Sample(now_ms);
            m_last_sample_ms = now_ms;
            sampled_this_tick = true;
        }
        m_status = "Diagnostics refresh completed.";
    }
    if (!sampled_this_tick &&
        (m_last_sample_ms == 0 || now_ms - m_last_sample_ms >= m_refresh_ms)) {
        Sample(now_ms);
        m_last_sample_ms = now_ms;
    }
    MaybeAutoSave(now_ms);
}

void DiagnosticsWindow::ProcessDeferredActions()
{
    /* This method is registered as a post-present Debug Tools callback.  It is
     * intentionally run on the UI thread with the BQL released. */
    if (m_open_snapshots_folder_requested) {
        m_open_snapshots_folder_requested = false;
        OpenSnapshotsFolder();
    }

    if (m_save_snapshot_requested) {
        m_save_snapshot_requested = false;
        m_auto_save_requested = false;
        if (RequestSaveSnapshot()) {
            xemu_queue_notification("Diagnostics snapshot saved (F4).");
        } else {
            xemu_queue_error_message("Diagnostics snapshot save failed.");
        }
        return;
    }

    if (!m_auto_save_requested) {
        return;
    }
    m_auto_save_requested = false;
    if (m_auto_save_path.empty()) {
        m_auto_save_path = DefaultAutoSavePath();
    }
    if (SaveSnapshotToPath(m_auto_save_path, true)) {
        m_status = "Rolling snapshot updated: " + m_auto_save_path;
    } else {
        m_status = "Failed to update rolling snapshot: " + m_auto_save_path;
    }
}

static const char *HostStallEventName(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_VCPU_SAMPLE:
        return "VCPU_SAMPLE";
    case XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_MAIN_LOOP_WAIT:
        return "MAIN_LOOP_WAIT";
    default:
        return "NONE";
    }
}

static const char *HostStallClassName(uint32_t classification)
{
    switch (classification) {
    case XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_HOST_OFFCPU:
        return "HOST_OFFCPU";
    case XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_THREAD_BUSY:
        return "THREAD_BUSY";
    case XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MIXED:
        return "MIXED";
    case XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MAIN_LOOP_EXCESS:
        return "MAIN_LOOP_EXCESS";
    case XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED:
        return "PAGEFAULT_CORRELATED";
    default:
        return "NONE";
    }
}

void DiagnosticsWindow::DrawOverview()
{
    const uint64_t now_ms = SDL_GetTicks();
    const uint64_t same_ms = m_regs_valid && now_ms >= m_eip_same_since_ms
                                 ? now_ms - m_eip_same_since_ms
                                 : 0;

    ImGui::Text("Accelerator               %s", BackendName());
    ImGui::Text("Guest runstate            %s", m_timing.running ? "Running" : "Paused / stopped");
    ImGui::Text("CPU halted                %s", m_timing.halted ? "Yes" : "No");
    ImGui::Text("CPU exception_index       %d", m_timing.exception_index);
    ImGui::Text("CPU interrupt_request     %08X", m_timing.interrupt_request);
    if (m_regs_valid) {
        const std::string sampled_eip = FormatGuestPc(m_regs.eip);
        ImGui::Text("Sampled EIP               %s", sampled_eip.c_str());
    } else {
        ImGui::TextUnformatted("Sampled EIP               <unavailable>");
    }
    ImGui::Text("Same sampled EIP          %llu ms",
                (unsigned long long)same_ms);
    ImGui::Text("Unique sampled EIPs (5s)  %zu", PcUniqueCount(now_ms));
    const auto &xdk_status = current_game_manager.XdkStatus();
    ImGui::Text("Guest-PC labels            %zu total | XDK %zu exact%s",
                current_game_manager.Labels().labels.size(),
                xdk_status.exact_matches,
                xdk_status.cache_loaded ? " (cache loaded)" : "");
    if (m_pc_stall_warning) {
        ImGui::TextWrapped("WARNING: sampled EIP is unchanged for >= 1 second. This can be a legitimate hot loop, but is a useful stall candidate.");
    }

    ImGui::Separator();
    ImGui::Text("GPU FPS                   %u", m_device.gpu_fps);
    ImGui::Text("GPU frames                %u", m_device.gpu_frame_count);
    ImGui::Text("Last GPU frame work       %d ms", m_device.gpu_last_frame_mspf);
    if (m_gpu_stall_warning) {
        ImGui::TextWrapped("WARNING: no NV2A frame completion observed for >= 1.5 seconds.");
    }

    ImGui::Separator();
    if (m_timing.actual_tsc_valid) {
        ImGui::Text("Guest TSC                 %016llX",
                    (unsigned long long)m_timing.actual_tsc);
        ImGui::Text("Xbox reference TSC        %016llX",
                    (unsigned long long)m_timing.expected_xbox_tsc);
        ImGui::Text("TSC drift from baseline   %+.3f us",
                    m_tsc_drift_us);
    }
    if (m_device.nv2a_available) {
        ImGui::Text("PTIMER alarm delta        %s",
                    FormatDurationNs(m_device.ptimer_alarm_delta_ns).c_str());
        ImGui::Text("PTIMER IRQ active         %s",
                    (m_device.ptimer_pending & m_device.ptimer_enabled) ? "Yes" : "No");
    }
    if (m_device.apu_available) {
        ImGui::Text("APU utilization           %.2f%%",
                    m_device.apu_utilization * 100.0f);
        ImGui::Text("APU max pacing deviation  %lld us",
                    (long long)m_device.apu_deviation_max_us);
    }
}

void DiagnosticsWindow::DrawCpuTiming()
{
    if (m_view.IsVisible(DiagnosticSection::Registers)) {
        if (!m_regs_valid) {
            ImGui::TextDisabled("CPU register snapshot unavailable.");
        } else {
            if (ImGui::BeginTable("diag_registers", 4,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
                auto reg = [](const char *name, uint32_t value) {
                    ImGui::TableNextColumn();
                    ImGui::Text("%s %08X", name, value);
                };
                reg("EAX", m_regs.eax); reg("EBX", m_regs.ebx);
                reg("ECX", m_regs.ecx); reg("EDX", m_regs.edx);
                reg("ESI", m_regs.esi); reg("EDI", m_regs.edi);
                reg("ESP", m_regs.esp); reg("EBP", m_regs.ebp);
                reg("EIP", m_regs.eip); reg("PC ", m_regs.pc);
                reg("EFLAGS", m_regs.eflags); reg("CR3", m_regs.cr3);
                reg("CR0", m_regs.cr0); reg("CR2", m_regs.cr2);
                reg("CR4", m_regs.cr4); reg("CS", m_regs.cs);
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Instructions)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Instruction Stream");
        if (m_disasm_count == 0) {
            ImGui::TextDisabled("Disassembly unavailable at the current EIP.");
        } else if (ImGui::BeginTable("diag_disasm", 4,
                                     ImGuiTableFlags_Borders |
                                     ImGuiTableFlags_RowBg |
                                     ImGuiTableFlags_Resizable)) {
            ImGui::TableSetupColumn("Address", ImGuiTableColumnFlags_WidthFixed, 90.0f);
            ImGui::TableSetupColumn("Bytes", ImGuiTableColumnFlags_WidthFixed, 140.0f);
            ImGui::TableSetupColumn("Mnemonic", ImGuiTableColumnFlags_WidthFixed, 90.0f);
            ImGui::TableSetupColumn("Operands");
            ImGui::TableHeadersRow();
            for (size_t i = 0; i < m_disasm_count; i++) {
                const XemuCheatDisasmRow &row = m_disasm[i];
                char bytes[64] = {};
                size_t used = 0;
                for (uint8_t j = 0; j < row.size && j < sizeof(row.bytes); j++) {
                    const int n = std::snprintf(bytes + used, sizeof(bytes) - used,
                                                j ? " %02X" : "%02X", row.bytes[j]);
                    if (n <= 0 || (size_t)n >= sizeof(bytes) - used) {
                        break;
                    }
                    used += (size_t)n;
                }
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                DrawGuestPc(row.virtual_address);
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(bytes);
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(row.mnemonic);
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(row.operands);
            }
            ImGui::EndTable();
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Stack)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Stack (ESP)");
        if (!m_stack_valid) {
            ImGui::TextDisabled("Stack memory unavailable.");
        } else if (ImGui::BeginTable("diag_stack", 4,
                                     ImGuiTableFlags_Borders |
                                     ImGuiTableFlags_RowBg)) {
            for (size_t i = 0; i < m_stack.size(); i++) {
                ImGui::TableNextColumn();
                ImGui::Text("%08X  %08X", m_regs.esp + (uint32_t)(i * 4),
                            m_stack[i]);
            }
            ImGui::EndTable();
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Clocks)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Clock Domains");
        ImGui::Text("QEMU virtual time          %llu ns",
                    (unsigned long long)m_timing.qemu_virtual_ns);
        ImGui::Text("QEMU/Xbox reference TSC    %016llX",
                    (unsigned long long)m_timing.expected_xbox_tsc);
        ImGui::Text("Guest-visible TSC          %s%016llX",
                    m_timing.actual_tsc_valid ? "" : "<unavailable> ",
                    (unsigned long long)m_timing.actual_tsc);
        ImGui::Text("QEMU model tsc-frequency   %s",
                    FormatHz(m_timing.model_tsc_hz).c_str());
        ImGui::Text("QEMU APIC/IRQ clock        %s",
                    FormatHz(m_timing.apic_bus_hz).c_str());
        ImGui::Text("WHPX processor clock       %s",
                    m_timing.whpx_processor_clock_valid
                        ? FormatHz(m_timing.whpx_processor_clock_hz).c_str()
                        : "<capability unavailable>");
        ImGui::Text("WHPX interrupt clock       %s",
                    m_timing.whpx_interrupt_clock_valid
                        ? FormatHz(m_timing.whpx_interrupt_clock_hz).c_str()
                        : "<capability unavailable>");
        ImGui::Text("TSC offset from reference  %lld ticks",
                    (long long)((int64_t)(m_timing.actual_tsc -
                                         m_timing.expected_xbox_tsc)));
        ImGui::Text("TSC drift from baseline    %lld ticks (%+.3f us)",
                    (long long)m_tsc_drift_ticks, m_tsc_drift_us);
        ImGui::SameLine();
        if (ImGui::SmallButton("Reset baseline")) {
            ResetTscBaseline();
        }

        ImGui::Spacing();
        ImGui::TextWrapped("The drift value removes the initial TSC offset and shows movement relative to the first diagnostics sample. This is more useful for timing-jitter/rate problems than comparing the raw counters directly.");
    }
}

void DiagnosticsWindow::DrawBufferSizePopup()
{
    bool open = true;
    if (!ImGui::BeginPopupModal("Diagnostics Buffer Sizes", &open,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        return;
    }

    if (!m_buffer_editor_initialized) {
        for (int i = 0; i < XEMU_DIAG_BUFFER_COUNT; ++i) {
            m_buffer_multiplier_edit[(size_t)i] =
                (int)DiagnosticsBufferMultiplier((XemuDiagnosticsBufferId)i);
        }
        m_recent_events_multiplier_edit = (int)m_recent_events_multiplier;
        m_all_buffer_multiplier_edit = 1;
        m_buffer_editor_initialized = true;
    }

    ImGui::TextWrapped("Multipliers change retained diagnostic history only. Changing a buffer clears that recorder but does not change whether it is enabled.");
    ImGui::TextDisabled("Allowed range: 1x to 100x. Large values can use substantial host RAM once those recorders fill.");
    ImGui::Separator();
    ImGui::SetNextItemWidth(100.0f);
    ImGui::InputInt("All recorders multiplier", &m_all_buffer_multiplier_edit, 1, 10);
    m_all_buffer_multiplier_edit = std::max(1, std::min(100, m_all_buffer_multiplier_edit));
    ImGui::SameLine();
    if (ImGui::Button("Apply to All")) {
        bool ok = true;
        for (int i = 0; i < XEMU_DIAG_BUFFER_COUNT; ++i) {
            if (!xemu_diagnostics_buffer_set_multiplier(
                    (XemuDiagnosticsBufferId)i,
                    (uint32_t)m_all_buffer_multiplier_edit)) {
                ok = false;
            }
            m_buffer_multiplier_edit[(size_t)i] = m_all_buffer_multiplier_edit;
        }
        m_recent_events_multiplier = (uint32_t)m_all_buffer_multiplier_edit;
        m_recent_events_multiplier_edit = m_all_buffer_multiplier_edit;
        m_events.clear();
        m_status = ok ? "Applied diagnostics buffer multiplier to all recorders."
                      : "One or more diagnostics buffers could not be resized.";
    }

    if (ImGui::BeginTable("diagnostics_buffer_sizes", 5,
                          ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                              ImGuiTableFlags_Resizable)) {
        ImGui::TableSetupColumn("Recorder");
        ImGui::TableSetupColumn("Base");
        ImGui::TableSetupColumn("Multiplier");
        ImGui::TableSetupColumn("Effective");
        ImGui::TableSetupColumn("Action");
        ImGui::TableHeadersRow();
        for (int i = 0; i < XEMU_DIAG_BUFFER_COUNT; ++i) {
            const auto id = (XemuDiagnosticsBufferId)i;
            XemuDiagnosticsBufferInfo info{};
            xemu_diagnostics_buffer_get_info(id, &info);
            ImGui::PushID(i);
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::TextUnformatted(DiagnosticsBufferName(id));
            ImGui::TableSetColumnIndex(1);
            ImGui::Text("%zu", info.base_capacity);
            ImGui::TableSetColumnIndex(2);
            ImGui::SetNextItemWidth(80.0f);
            ImGui::InputInt("##multiplier", &m_buffer_multiplier_edit[(size_t)i], 1, 10);
            m_buffer_multiplier_edit[(size_t)i] = std::max(1, std::min(100, m_buffer_multiplier_edit[(size_t)i]));
            ImGui::TableSetColumnIndex(3);
            ImGui::Text("%zu", info.base_capacity * (size_t)m_buffer_multiplier_edit[(size_t)i]);
            ImGui::TableSetColumnIndex(4);
            if (ImGui::SmallButton("Apply")) {
                if (xemu_diagnostics_buffer_set_multiplier(
                        id, (uint32_t)m_buffer_multiplier_edit[(size_t)i])) {
                    m_status = std::string("Updated buffer: ") + DiagnosticsBufferName(id);
                } else {
                    m_status = std::string("Could not resize buffer: ") + DiagnosticsBufferName(id);
                }
            }
            ImGui::PopID();
        }

        ImGui::PushID("recent-events");
        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        ImGui::TextUnformatted("Recent Events");
        ImGui::TableSetColumnIndex(1);
        ImGui::Text("%zu", kBaseMaxEvents);
        ImGui::TableSetColumnIndex(2);
        ImGui::SetNextItemWidth(80.0f);
        ImGui::InputInt("##multiplier", &m_recent_events_multiplier_edit, 1, 10);
        m_recent_events_multiplier_edit = std::max(1, std::min(100, m_recent_events_multiplier_edit));
        ImGui::TableSetColumnIndex(3);
        ImGui::Text("%zu", kBaseMaxEvents * (size_t)m_recent_events_multiplier_edit);
        ImGui::TableSetColumnIndex(4);
        if (ImGui::SmallButton("Apply")) {
            m_recent_events_multiplier = (uint32_t)m_recent_events_multiplier_edit;
            m_events.clear();
            m_status = "Updated buffer: Recent Events";
        }
        ImGui::PopID();
        ImGui::EndTable();
    }

    ImGui::Separator();
    if (ImGui::Button("Close")) {
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

void DiagnosticsWindow::DrawRecordingControls()
{
    bool check_all_recording = AllRecordingOptionsEnabled();
    if (ImGui::Checkbox("Check All Recording Options", &check_all_recording)) {
        SetAllRecordingOptionsEnabled(check_all_recording);
    }
    ImGui::SameLine();
    if (ImGui::Button("Clear All")) {
        xemu_diagnostics_ptimer_trace_clear();
        xemu_diagnostics_qemu_timer_trace_clear();
        xemu_diagnostics_slow_timer_trace_clear();
        xemu_diagnostics_ohci_slow_frame_trace_clear();
        xemu_diagnostics_pgraph_increment_trace_clear();
        xemu_diagnostics_ptimer_irq_latency_trace_clear();
        xemu_diagnostics_ptimer_irq_delivery_trace_clear();
        xemu_diagnostics_host_stall_trace_clear();
        xemu_diagnostics_controller_input_poll_trace_clear();
        xemu_diagnostics_bql_trace_clear();
        xemu_diagnostics_main_loop_lock_trace_clear();
        xemu_diagnostics_mmio_trace_clear();
        xemu_diagnostics_pgraph_lock_trace_clear();
        xemu_diagnostics_pgraph_draw_trace_clear();
        xemu_diagnostics_flip_stall_trace_clear();
        xemu_diagnostics_pgraph_flip_delay_trace_clear();
        xemu_diagnostics_pgraph_pusher_progress_trace_clear();
        xemu_diagnostics_pgraph_pusher_method_breakdown_trace_clear();
        xemu_diagnostics_av_sync_trace_clear();
        xemu_diagnostics_scheduler_trace_clear();
        xemu_diagnostics_controller_xid_trace_clear();
        xemu_diagnostics_guest_input_consumer_trace_clear();
        xemu_diagnostics_guest_timer_deadline_trace_clear();
        xemu_diagnostics_ptimer_late_capture_clear();
        xemu_diagnostics_d3d_callback_capture_clear();

        const uint64_t now_ms = SDL_GetTicks();
        m_events.clear();
        m_pc_history.clear();
        m_session_start_ms = now_ms;
        m_sample_count = 0;
        m_eip_same_since_ms = now_ms;
        m_last_gpu_frame_change_ms = now_ms;
        m_pc_stall_warning = false;
        m_gpu_stall_warning = false;
        m_ptimer_late_warning = false;
        m_apu_timing_warning = false;
        ResetTscBaseline();
        for (CustomWatch &watch : m_watches) {
            watch.previous_raw = watch.raw;
            watch.last_change_ms = now_ms;
            watch.warning_active = false;
        }
        m_status = "All diagnostics data cleared.";
    }
    ImGui::SameLine();
    if (ImGui::Button("Buffer Sizes...")) {
        m_buffer_editor_initialized = false;
        ImGui::OpenPopup("Diagnostics Buffer Sizes");
    }
    DrawBufferSizePopup();
    ImGui::TextDisabled("Check All changes recorder enable state; Clear All resets captured data without changing recorder settings.");

}

void DiagnosticsWindow::DrawNv2a()
{
    if (!m_device.nv2a_available) {
        ImGui::TextDisabled("NV2A is not initialized.");
        return;
    }

    if (m_view.IsVisible(DiagnosticSection::InterruptState)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Interrupt State");
        DrawHexPair("PMC", m_device.pmc_pending, m_device.pmc_enabled);
        DrawHexPair("PFIFO", m_device.pfifo_pending, m_device.pfifo_enabled);
        DrawHexPair("PGRAPH", m_device.pgraph_pending, m_device.pgraph_enabled);
        DrawHexPair("PCRTC", m_device.pcrtc_pending, m_device.pcrtc_enabled);
        DrawHexPair("PTIMER", m_device.ptimer_pending, m_device.ptimer_enabled);
    }
    if (m_view.IsVisible(DiagnosticSection::Ptimer)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PTIMER");
        ImGui::Text("Core clock                %s",
                    FormatHz(m_device.gpu_core_clock_hz).c_str());
        ImGui::Text("Numerator / denominator   %u / %u",
                    m_device.ptimer_numerator, m_device.ptimer_denominator);
        ImGui::Text("Current PTIMER            %016llX",
                    (unsigned long long)m_device.ptimer_now);
        ImGui::Text("Alarm target              %016llX",
                    (unsigned long long)m_device.ptimer_alarm);
        ImGui::Text("Alarm delta               %s",
                    FormatDurationNs(m_device.ptimer_alarm_delta_ns).c_str());
        DrawBoolState("QEMU alarm timer pending", m_device.ptimer_qemu_timer_pending != 0);
        if (m_device.ptimer_qemu_timer_pending) {
            ImGui::Text("QEMU timer due            %s",
                        FormatDurationNs(m_device.ptimer_qemu_timer_delta_ns).c_str());
            ImGui::Text("QEMU timer expiry         %llu ns",
                        (unsigned long long)m_device.ptimer_qemu_timer_expire_ns);
        }
    }
    if (m_view.IsVisible(DiagnosticSection::PtimerTrace)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Detailed PTIMER Timing Trace");
        XemuDiagnosticsPtimerTraceStatus trace_status{};
        xemu_diagnostics_get_ptimer_trace_status(&trace_status);
        bool trace_enabled = trace_status.enabled != 0;
        if (ImGui::Checkbox("Record detailed PTIMER events", &trace_enabled)) {
            xemu_diagnostics_ptimer_trace_set_enabled(trace_enabled ? 1 : 0);
            xemu_diagnostics_get_ptimer_trace_status(&trace_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PTIMER Trace")) {
            xemu_diagnostics_ptimer_trace_clear();
            xemu_diagnostics_get_ptimer_trace_status(&trace_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", trace_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PTIMER));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)trace_status.total_events,
                    (unsigned long long)trace_status.overwritten_events);
        ImGui::TextDisabled("In-memory only while recording; Save Snapshot exports the detailed event ring. Enabling starts a fresh capture.");
        ImGui::TextDisabled("RDTSC Ref is Xemu's Xbox cpu_get_tsc()+offset reference for events recorded in vCPU context; compare it with Guest-visible TSC in Timing.");

        if (trace_status.count != 0) {
            constexpr size_t kDisplayTraceEvents = 128;
            std::array<XemuDiagnosticsPtimerTraceEvent, kDisplayTraceEvents> trace{};
            const size_t trace_count =
                xemu_diagnostics_get_ptimer_trace(trace.data(), trace.size());
            if (ImGui::BeginTable("ptimer_detailed_trace", 10,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 260.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableSetupColumn("RDTSC Ref");
                ImGui::TableSetupColumn("Alarm Delta");
                ImGui::TableSetupColumn("QTimer Delta");
                ImGui::TableSetupColumn("Callback Late");
                ImGui::TableSetupColumn("Pending");
                ImGui::TableSetupColumn("Enabled");
                ImGui::TableSetupColumn("Value / Previous");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < trace_count; ++i) {
                    const auto &event = trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(PtimerTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    if (event.guest_pc_valid) {
                        DrawGuestPc(event.guest_pc);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                    ImGui::TableSetColumnIndex(3);
                    if (event.rdtsc_reference_valid) {
                        ImGui::Text("%016llX",
                                    (unsigned long long)event.rdtsc_reference);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs(event.alarm_delta_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(event.qemu_timer_pending
                                               ? FormatDurationNs(event.qemu_timer_delta_ns).c_str()
                                               : "<none>");
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(FormatDurationNs(event.callback_lateness_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%08X", event.pending_interrupts);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%08X", event.enabled_interrupts);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%08X / %08X", event.value, event.previous_value);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::SlowTimer)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Slow QEMU Timer Callback Detector");
        XemuDiagnosticsSlowTimerTraceStatus slow_timer_status{};
        xemu_diagnostics_get_slow_timer_trace_status(&slow_timer_status);
        bool slow_timer_enabled = slow_timer_status.enabled != 0;
        if (ImGui::Checkbox("Record slow QEMU timer callbacks", &slow_timer_enabled)) {
            xemu_diagnostics_slow_timer_trace_set_enabled(slow_timer_enabled ? 1 : 0);
            xemu_diagnostics_get_slow_timer_trace_status(&slow_timer_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Slow Timer Trace")) {
            xemu_diagnostics_slow_timer_trace_clear();
            xemu_diagnostics_get_slow_timer_trace_status(&slow_timer_status);
        }

        float slow_timer_threshold_ms =
            (float)((double)slow_timer_status.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(120.0f);
        if (ImGui::InputFloat("Threshold (ms)", &slow_timer_threshold_ms,
                              0.1f, 1.0f, "%.3f")) {
            slow_timer_threshold_ms =
                std::max(0.01f, std::min(slow_timer_threshold_ms, 10000.0f));
            const uint64_t threshold_ns = (uint64_t)std::llround(
                (double)slow_timer_threshold_ms * 1000000.0);
            xemu_diagnostics_slow_timer_trace_set_threshold_ns(threshold_ns);
            xemu_diagnostics_get_slow_timer_trace_status(&slow_timer_status);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("1 = 1 ms, 5 = 5 ms, 100 = 100 ms");
        ImGui::Text("Buffered slow callbacks   %zu / %zu", slow_timer_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_SLOW_TIMER));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)slow_timer_status.total_events,
                    (unsigned long long)slow_timer_status.overwritten_events);
        ImGui::TextDisabled("Only callbacks at or above the threshold are retained. Changing the threshold clears the tiny 128-event ring.");
        ImGui::TextDisabled("When disabled, the callback path does not take the slow-recorder mutex or capture timing samples.");

        if (slow_timer_status.count != 0) {
            constexpr size_t kDisplaySlowTimerEvents = 64;
            std::array<XemuDiagnosticsSlowTimerTraceEvent,
                       kDisplaySlowTimerEvents> slow_trace{};
            const size_t slow_count = xemu_diagnostics_get_slow_timer_trace(
                slow_trace.data(), slow_trace.size());
            if (ImGui::BeginTable("slow_qemu_timer_trace", 11,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Callback");
                ImGui::TableSetupColumn("Name");
                ImGui::TableSetupColumn("Source");
                ImGui::TableSetupColumn("Duration");
                ImGui::TableSetupColumn("Clock");
                ImGui::TableSetupColumn("Dispatch Late");
                ImGui::TableSetupColumn("Expiry");
                ImGui::TableSetupColumn("Timer");
                ImGui::TableSetupColumn("Opaque");
                ImGui::TableSetupColumn("BQL Before/After");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < slow_count; ++i) {
                    const auto &event = slow_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("0x%016llX",
                                (unsigned long long)event.callback_address);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(event.callback_name);
                    ImGui::TableSetColumnIndex(3);
                    if (event.source_line > 0) {
                        ImGui::Text("%s:%d", event.source_file, event.source_line);
                    } else {
                        ImGui::TextUnformatted(event.source_file);
                    }
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.host_duration_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(QemuClockTypeName(event.clock_type));
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.dispatch_late_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%lld", (long long)event.scheduled_expire_ns);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("0x%016llX",
                                (unsigned long long)event.timer_address);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("0x%016llX",
                                (unsigned long long)event.opaque_address);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%u / %u", event.bql_held_before,
                                event.bql_held_after);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Ohci)) {
        ImGui::Separator();
        ImGui::TextUnformatted("OHCI Slow Frame Stage Profiler");
        XemuDiagnosticsOhciSlowFrameStatus ohci_slow_status{};
        xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_slow_status);
        bool ohci_slow_enabled = ohci_slow_status.enabled != 0;
        if (ImGui::Checkbox("Record OHCI slow frame stages", &ohci_slow_enabled)) {
            xemu_diagnostics_ohci_slow_frame_trace_set_enabled(
                ohci_slow_enabled ? 1 : 0);
            xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_slow_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear OHCI Slow Frames")) {
            xemu_diagnostics_ohci_slow_frame_trace_clear();
            xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_slow_status);
        }

        float ohci_slow_threshold_ms =
            (float)((double)ohci_slow_status.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(120.0f);
        if (ImGui::InputFloat("OHCI Threshold (ms)", &ohci_slow_threshold_ms,
                              0.1f, 1.0f, "%.3f")) {
            ohci_slow_threshold_ms =
                std::max(0.01f, std::min(ohci_slow_threshold_ms, 10000.0f));
            const uint64_t threshold_ns = (uint64_t)std::llround(
                (double)ohci_slow_threshold_ms * 1000000.0);
            xemu_diagnostics_ohci_slow_frame_trace_set_threshold_ns(threshold_ns);
            xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_slow_status);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("1 = 1 ms; profiles frame/list/ED/TD/USB/DMA stages");
        ImGui::Text("Buffered slow OHCI frames %zu / %zu", ohci_slow_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)ohci_slow_status.total_events,
                    (unsigned long long)ohci_slow_status.overwritten_events);
        ImGui::TextDisabled("Timing samples are taken only while this profiler is enabled; the recorder locks only after a frame exceeds the threshold.");

        if (ohci_slow_status.count != 0) {
            constexpr size_t kDisplayOhciSlowFrames = 64;
            std::array<XemuDiagnosticsOhciSlowFrameEvent,
                       kDisplayOhciSlowFrames> ohci_trace{};
            const size_t ohci_count = xemu_diagnostics_get_ohci_slow_frame_trace(
                ohci_trace.data(), ohci_trace.size());
            if (ImGui::BeginTable("ohci_slow_frame_trace", 13,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Frame");
                ImGui::TableSetupColumn("Total");
                ImGui::TableSetupColumn("Periodic");
                ImGui::TableSetupColumn("Control");
                ImGui::TableSetupColumn("Bulk");
                ImGui::TableSetupColumn("USB Packet Sum");
                ImGui::TableSetupColumn("DMA To/From");
                ImGui::TableSetupColumn("ED R/W");
                ImGui::TableSetupColumn("TD R/W");
                ImGui::TableSetupColumn("Worst Leaf");
                ImGui::TableSetupColumn("ED / TD");
                ImGui::TableSetupColumn("FA:EP Dir Status Len");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < ohci_count; ++i) {
                    const auto &event = ohci_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%u", event.frame_number);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.host_duration_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.periodic_list_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.control_list_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.bulk_list_ns).c_str());
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.usb_handle_packet_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)event.dma_to_device_ns).c_str(),
                        FormatDurationNs((int64_t)event.dma_from_device_ns).c_str());
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)event.ed_read_ns).c_str(),
                        FormatDurationNs((int64_t)event.ed_write_ns).c_str());
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)event.td_read_ns).c_str(),
                        FormatDurationNs((int64_t)event.td_write_ns).c_str());
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%s %s %s",
                        OhciListKindName(event.worst_list_kind),
                        OhciLeafOperationName(event.worst_leaf_type),
                        FormatDurationNs((int64_t)event.worst_leaf_ns).c_str());
                    ImGui::TableSetColumnIndex(11);
                    ImGui::Text("%08X / %08X", event.worst_ed_address,
                                event.worst_td_address);
                    ImGui::TableSetColumnIndex(12);
                    ImGui::Text("%u:%u %d %d %u",
                                event.worst_function_address,
                                event.worst_endpoint,
                                event.worst_direction,
                                event.worst_packet_status,
                                event.worst_packet_length);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Increment)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PGRAPH Increment Stage Profiler");
        XemuDiagnosticsLatencyTraceStatus pginc_status{};
        xemu_diagnostics_get_pgraph_increment_trace_status(&pginc_status);
        bool pginc_enabled = pginc_status.enabled != 0;
        if (ImGui::Checkbox("Record slow PGRAPH increments", &pginc_enabled)) {
            xemu_diagnostics_pgraph_increment_trace_set_enabled(pginc_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_increment_trace_status(&pginc_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PGRAPH Increments")) {
            xemu_diagnostics_pgraph_increment_trace_clear();
            xemu_diagnostics_get_pgraph_increment_trace_status(&pginc_status);
        }
        float pginc_threshold_ms = (float)((double)pginc_status.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(120.0f);
        if (ImGui::InputFloat("PGRAPH Increment Threshold (ms)", &pginc_threshold_ms, 0.1f, 1.0f, "%.3f")) {
            pginc_threshold_ms = std::max(0.01f, std::min(pginc_threshold_ms, 10000.0f));
            xemu_diagnostics_pgraph_increment_trace_set_threshold_ns((uint64_t)std::llround((double)pginc_threshold_ms * 1000000.0));
            xemu_diagnostics_get_pgraph_increment_trace_status(&pginc_status);
        }
        ImGui::Text("Buffered slow PGRAPH increments %zu / %zu", pginc_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_INCREMENT));
        if (pginc_status.count) {
            std::array<XemuDiagnosticsPgraphIncrementEvent, 64> events{};
            size_t n = xemu_diagnostics_get_pgraph_increment_trace(events.data(), events.size());
            if (ImGui::BeginTable(
                    "pgraph_increment_trace", 8,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 180.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Total");
                ImGui::TableSetupColumn("Surface Lock Wait");
                ImGui::TableSetupColumn("Surface Update");
                ImGui::TableSetupColumn("PFIFO Kick");
                ImGui::TableSetupColumn("BQL Reacquire");
                ImGui::TableSetupColumn("Read Before/After");
                ImGui::TableSetupColumn("Modulo");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < n; i++) {
                    const auto &e = events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.host_duration_ns).c_str());
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.surface_lock_wait_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.surface_update_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.pfifo_kick_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.bql_reacquire_wait_ns).c_str());
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%u / %u", e.read_before, e.read_after);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%u", e.modulo);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::FlipStall)) {
        ImGui::Separator();
        ImGui::TextUnformatted("FLIP_STALL / VBlank Investigator");
        XemuDiagnosticsFlipStallStatus flip_status{};
        xemu_diagnostics_get_flip_stall_trace_status(&flip_status);
        bool flip_enabled = flip_status.enabled != 0;
        if (ImGui::Checkbox("Record FLIP_STALL / VBlank lifecycle", &flip_enabled)) {
            xemu_diagnostics_flip_stall_trace_set_enabled(flip_enabled ? 1 : 0);
            xemu_diagnostics_get_flip_stall_trace_status(&flip_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear FLIP_STALL Trace")) {
            xemu_diagnostics_flip_stall_trace_clear();
            xemu_diagnostics_get_flip_stall_trace_status(&flip_status);
        }
        ImGui::Text("Buffered flip events       %zu / %zu", flip_status.count,
                    DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_FLIP_STALL));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)flip_status.total_events,
                    (unsigned long long)flip_status.overwritten_events);
        if (flip_status.active_stall) {
            ImGui::Text("Active FLIP_STALL age     %s",
                        FormatDurationNs((int64_t)flip_status.active_stall_age_ns).c_str());
        } else {
            ImGui::TextDisabled("Active FLIP_STALL age     <none>");
        }
        ImGui::TextDisabled("Records Xbox D3D flip index changes, VBlank READ_3D advances, Vulkan FLIP_STALL finish time, and PFIFO stall/release decisions.");
        if (flip_status.count) {
            std::array<XemuDiagnosticsFlipStallEvent, 128> events{};
            size_t n = xemu_diagnostics_get_flip_stall_trace(events.data(), events.size());
            if (ImGui::BeginTable("flip_stall_trace", 9,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Stall Age");
                ImGui::TableSetupColumn("Duration");
                ImGui::TableSetupColumn("R/W/M");
                ImGui::TableSetupColumn("Waiting");
                ImGui::TableSetupColumn("Method/Param");
                ImGui::TableSetupColumn("PC");
                ImGui::TableSetupColumn("TID/CPU");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < n; ++i) {
                    const auto &e = events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(FlipStallEventName(e.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.stall_age_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.duration_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%u/%u/%u", e.read_3d, e.write_3d, e.modulo_3d);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%u", e.waiting_for_flip);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%04X/%08X", e.method, e.parameter);
                    ImGui::TableSetColumnIndex(7);
                    if (e.guest_pc_valid)
                        DrawGuestPc(e.guest_pc);
                    else
                        ImGui::TextDisabled("<n/a>");
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%d/%d", e.thread_id, e.cpu_index);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::FlipDelay)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PGRAPH Flip Delay Breakdown");
        XemuDiagnosticsPgraphFlipDelayStatus flip_delay{};
        xemu_diagnostics_get_pgraph_flip_delay_trace_status(&flip_delay);
        bool flip_delay_enabled = flip_delay.enabled != 0;
        if (ImGui::Checkbox("Record long PGRAPH flip breakdown",
                            &flip_delay_enabled)) {
            xemu_diagnostics_pgraph_flip_delay_trace_set_enabled(
                flip_delay_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_flip_delay_trace_status(&flip_delay);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PGRAPH Delay Capture")) {
            xemu_diagnostics_pgraph_flip_delay_trace_clear();
            xemu_diagnostics_get_pgraph_flip_delay_trace_status(&flip_delay);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("buffer %zu",
                            DiagnosticsBufferCapacity(
                                XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY));

        float flip_delay_threshold_ms =
            (float)((double)flip_delay.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(130.0f);
        if (ImGui::InputFloat("Long frame threshold (ms)##pgraph_flip_delay",
                              &flip_delay_threshold_ms, 1.0f, 10.0f, "%.3f")) {
            flip_delay_threshold_ms = std::max(1.0f,
                                               std::min(flip_delay_threshold_ms,
                                                        2000.0f));
            xemu_diagnostics_pgraph_flip_delay_trace_set_threshold_ns(
                (uint64_t)std::llround((double)flip_delay_threshold_ms *
                                       1000000.0));
            xemu_diagnostics_get_pgraph_flip_delay_trace_status(&flip_delay);
        }

        ImGui::Text("Frames seen / captured     %llu / %llu",
                    (unsigned long long)flip_delay.total_frames_seen,
                    (unsigned long long)flip_delay.captured_long_frames);
        ImGui::Text("Last / worst frame gap     %s / %s",
                    FormatDurationNs((int64_t)flip_delay.last_frame_ns).c_str(),
                    FormatDurationNs((int64_t)flip_delay.worst_frame_ns).c_str());
        ImGui::Text("Worst stall / post-release %s / %s",
                    FormatDurationNs((int64_t)flip_delay.worst_stall_total_ns).c_str(),
                    FormatDurationNs((int64_t)flip_delay.worst_post_release_ns).c_str());
        ImGui::Text("Worst CPU-MMIO gate / lock %s / %s",
                    FormatDurationNs(
                        (int64_t)flip_delay.worst_cpu_mmio_gate_wait_ns).c_str(),
                    FormatDurationNs(
                        (int64_t)flip_delay.worst_pgraph_lock_wait_ns).c_str());
        ImGui::Text("  PFIFO / renderer subset   %s / %s",
                    FormatDurationNs(
                        (int64_t)flip_delay.worst_pfifo_cpu_mmio_gate_wait_ns).c_str(),
                    FormatDurationNs(
                        (int64_t)flip_delay.worst_renderer_cpu_mmio_gate_wait_ns).c_str());
        ImGui::Text("Worst renderer finish      %s",
                    FormatDurationNs(
                        (int64_t)flip_delay.worst_renderer_finish_ns).c_str());
        ImGui::Text("Post-release guest PC samples %llu (untracked %llu)",
                    (unsigned long long)flip_delay.guest_pc_samples,
                    (unsigned long long)flip_delay.guest_pc_untracked_samples);
        ImGui::Text("  natural TCG dispatch every >= %s after %s arm delay",
                    FormatDurationNs(
                        (int64_t)flip_delay.guest_pc_sample_interval_ns).c_str(),
                    FormatDurationNs(
                        (int64_t)flip_delay.guest_pc_arm_delay_ns).c_str());
        if (flip_delay.active_frame) {
            ImGui::Text("Current frame age          %s",
                        FormatDurationNs(
                            (int64_t)flip_delay.active_frame_age_ns).c_str());
        }

        ImGui::TextDisabled(
            "For each FLIP_STALL->FLIP_STALL frame >= threshold, partitions stall vs post-release time and correlates PFIFO and renderer CPU-MMIO gates, PGRAPH mutex waiting, renderer finish, VBlank release, surface-lock, PFIFO-kick, BQL-reacquire timing, and post-release guest-PC hotspots.");
        ImGui::TextDisabled(
            "CPU-MMIO gate time is measured from Patch-300 pre-PGRAPH markers to the existing PGRAPH lock-attempt marker. PFIFO and renderer process_pending() gates are reported separately; with Patch 20 present, pgraph_wait_for_cpu_mmio_accesses() executes inside these intervals.");
        ImGui::TextDisabled(
            "Guest-PC hotspot sampling is TCG-only and intentionally does not single-step or disable direct TB chaining. It samples only natural dispatcher-visible TB PCs after half the long-frame threshold has already elapsed following PFIFO release.");
        ImGui::TextDisabled(
            "Guest-PC names are resolved at display/export time from the current merged Labels database (XBE/XDK/MAP/PDB/.xlabel); recorder hooks still store raw PCs only.");

        if (flip_delay.count != 0) {
            constexpr size_t kDisplayFlipDelayEvents = 64;
            std::array<XemuDiagnosticsPgraphFlipDelayEvent,
                       kDisplayFlipDelayEvents> events{};
            const size_t n = xemu_diagnostics_get_pgraph_flip_delay_trace(
                events.data(), events.size());
            if (n != 0) {
                const auto &last = events[n - 1];
                ImGui::Text("Latest long frame %u->%u  total %s | stall %s | post-release %s",
                            last.start_frame_time, last.end_frame_time,
                            FormatDurationNs((int64_t)last.frame_host_ns).c_str(),
                            FormatDurationNs((int64_t)last.stall_total_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.post_release_to_next_stall_ns).c_str());
                ImGui::Text("  release->increment %s | increment->stall %s | method %s | VBlank wait %s",
                            FormatDurationNs(
                                (int64_t)last.release_to_flip_increment_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.flip_increment_to_next_stall_ns).c_str(),
                            FormatDurationNs((int64_t)last.stall_method_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.waiting_to_vblank_read_ns).c_str());
                ImGui::Text("  renderer finish %s | PGRAPH lock %s | surface lock %s",
                            FormatDurationNs(
                                (int64_t)last.renderer_finish_total_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.pgraph_lock_wait_total_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.surface_lock_wait_total_ns).c_str());
                ImGui::Text("  CPU-MMIO all %s | PFIFO %s (%u) | renderer %s (%u)",
                            FormatDurationNs(
                                (int64_t)last.cpu_mmio_gate_wait_total_ns).c_str(),
                            FormatDurationNs(
                                (int64_t)last.pfifo_cpu_mmio_gate_wait_total_ns).c_str(),
                            last.pfifo_gate_count,
                            FormatDurationNs(
                                (int64_t)last.renderer_cpu_mmio_gate_wait_total_ns).c_str(),
                            last.renderer_gate_count);
                ImGui::Text("  post-release PC samples %u | tracked %u | untracked %u",
                            last.post_release_pc_samples,
                            last.post_release_pc_tracked_unique,
                            last.post_release_pc_untracked_samples);
                for (uint32_t rank = 0;
                     rank < XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT &&
                     last.hot_pc_hits[rank] != 0; ++rank) {
                    const std::string hot_pc = FormatGuestPc(last.hot_pc[rank]);
                    ImGui::Text("  #%u %s (%u)", rank + 1, hot_pc.c_str(),
                                last.hot_pc_hits[rank]);
                }
            }

            if (ImGui::BeginTable(
                    "pgraph_flip_delay_breakdown", 15,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                        ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 240.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Frame");
                ImGui::TableSetupColumn("Total");
                ImGui::TableSetupColumn("Stall");
                ImGui::TableSetupColumn("Post-release");
                ImGui::TableSetupColumn("Rel->Inc");
                ImGui::TableSetupColumn("Inc->Stall");
                ImGui::TableSetupColumn("Renderer");
                ImGui::TableSetupColumn("VBlank wait");
                ImGui::TableSetupColumn("PFIFO MMIO");
                ImGui::TableSetupColumn("Renderer MMIO");
                ImGui::TableSetupColumn("PGRAPH lock");
                ImGui::TableSetupColumn("Surface lock");
                ImGui::TableSetupColumn("V/R");
                ImGui::TableSetupColumn("Hot PC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < n; ++i) {
                    const auto &e = events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%u->%u", e.start_frame_time, e.end_frame_time);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.frame_host_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.stall_total_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.post_release_to_next_stall_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.release_to_flip_increment_ns).c_str());
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.flip_increment_to_next_stall_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.renderer_finish_total_ns).c_str());
                    ImGui::TableSetColumnIndex(8);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.waiting_to_vblank_read_ns).c_str());
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s (%u)",
                                FormatDurationNs((int64_t)e.pfifo_cpu_mmio_gate_wait_total_ns).c_str(),
                                e.pfifo_gate_count);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%s (%u)",
                                FormatDurationNs((int64_t)e.renderer_cpu_mmio_gate_wait_total_ns).c_str(),
                                e.renderer_gate_count);
                    ImGui::TableSetColumnIndex(11);
                    ImGui::Text("%s (%u)",
                                FormatDurationNs((int64_t)e.pgraph_lock_wait_total_ns).c_str(),
                                e.pgraph_lock_count);
                    ImGui::TableSetColumnIndex(12);
                    ImGui::TextUnformatted(FormatDurationNs(
                        (int64_t)e.surface_lock_wait_total_ns).c_str());
                    ImGui::TableSetColumnIndex(13);
                    ImGui::Text("%u/%u", e.vblank_read_increment_count,
                                e.pfifo_release_count);
                    ImGui::TableSetColumnIndex(14);
                    if (e.hot_pc_hits[0] != 0) {
                        const std::string hot_pc = FormatGuestPc(e.hot_pc[0]);
                        ImGui::Text("%s (%u/%u)", hot_pc.c_str(),
                                    e.hot_pc_hits[0], e.post_release_pc_samples);
                    } else {
                        ImGui::TextDisabled("<none>");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::PusherProgress)) {
        ImGui::Separator();
        ImGui::TextUnformatted("D3D Pusher / GPU Progress Correlation");
        XemuDiagnosticsPgraphPusherProgressStatus pusher_progress{};
        xemu_diagnostics_get_pgraph_pusher_progress_trace_status(&pusher_progress);
        bool pusher_progress_enabled = pusher_progress.enabled != 0;
        if (ImGui::Checkbox("Record D3D pusher / GPU progress correlation",
                            &pusher_progress_enabled)) {
            xemu_diagnostics_pgraph_pusher_progress_trace_set_enabled(
                pusher_progress_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_pusher_progress_trace_status(
                &pusher_progress);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Pusher Progress Trace")) {
            xemu_diagnostics_pgraph_pusher_progress_trace_clear();
            xemu_diagnostics_get_pgraph_pusher_progress_trace_status(
                &pusher_progress);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("buffer %zu",
                            DiagnosticsBufferCapacity(
                                XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS));
        ImGui::Text("DMA PUT / PFIFO run / semaphore  %llu / %llu / %llu",
                    (unsigned long long)pusher_progress.dma_put_events,
                    (unsigned long long)pusher_progress.pfifo_run_events,
                    (unsigned long long)pusher_progress.semaphore_release_events);
        ImGui::Text("Worst PFIFO / semaphore / PUT->semaphore %s / %s / %s",
                    FormatDurationNs((int64_t)pusher_progress.worst_pfifo_run_ns).c_str(),
                    FormatDurationNs((int64_t)pusher_progress.worst_semaphore_release_ns).c_str(),
                    FormatDurationNs((int64_t)pusher_progress.worst_dma_put_to_semaphore_ns).c_str());
        ImGui::Text("Last DMA PUT -> semaphore          %s",
                    FormatDurationNs((int64_t)pusher_progress.last_dma_put_to_semaphore_ns).c_str());
        ImGui::Text("Last PFIFO GET / PUT              %08X / %08X",
                    pusher_progress.last_dma_get, pusher_progress.last_dma_put);
        if (pusher_progress.last_semaphore_target_valid) {
            ImGui::Text("Last GPU-time semaphore           phys %08X | guest %08X | value %08X",
                        pusher_progress.last_semaphore_phys,
                        pusher_progress.last_semaphore_guest_va,
                        pusher_progress.last_semaphore_value);
        } else {
            ImGui::TextDisabled("Last GPU-time semaphore           <not observed>");
        }
        ImGui::TextDisabled(
            "Observation-only chain: guest NV_USER DMA PUT (KickOff-style submission) -> PFIFO GET/PUT consumption -> NV097 BACK_END_WRITE_SEMAPHORE_RELEASE. XDK D3D GpuTime/BlockOnTime reads the semaphore progress value; no title address is hardcoded.");

        if (pusher_progress.count != 0) {
            constexpr size_t kDisplayPusherProgressEvents = 96;
            std::array<XemuDiagnosticsPgraphPusherProgressEvent,
                       kDisplayPusherProgressEvents> pusher_events{};
            const size_t pusher_n =
                xemu_diagnostics_get_pgraph_pusher_progress_trace(
                    pusher_events.data(), pusher_events.size());
            if (ImGui::BeginTable(
                    "pgraph_pusher_progress", 9,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                        ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 240.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Duration");
                ImGui::TableSetupColumn("GET before->after");
                ImGui::TableSetupColumn("PUT before->after");
                ImGui::TableSetupColumn("Words");
                ImGui::TableSetupColumn("Semaphore phys/value");
                ImGui::TableSetupColumn("PUT->event");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < pusher_n; ++i) {
                    const auto &e = pusher_events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(PgraphPusherProgressEventName(e.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.duration_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("%08X->%08X", e.dma_get_before, e.dma_get_after);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%08X->%08X", e.dma_put_before, e.dma_put_after);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%u", e.method_words_processed);
                    ImGui::TableSetColumnIndex(6);
                    if (e.semaphore_target_valid) {
                        ImGui::Text("%08X %08X->%08X", e.semaphore_phys,
                                    e.semaphore_old_value, e.semaphore_new_value);
                    } else {
                        ImGui::TextDisabled("-");
                    }
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.dma_put_to_event_ns).c_str());
                    ImGui::TableSetColumnIndex(8);
                    if (e.guest_pc_valid) {
                        DrawGuestPc(e.guest_pc);
                    } else {
                        ImGui::TextDisabled("<n/a>");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::MethodBreakdown)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PFIFO Method-Time Breakdown");
        ImGui::TextDisabled("Also records all nonempty PFIFO runs in bounded ~100ms coverage windows, including sub-5ms work.");
        ImGui::TextDisabled("Vertex child stages separate dirty checks, surface download, overlap finish, fence wait and copy; metrics export with this panel.");

        XemuDiagnosticsPgraphPusherMethodBreakdownStatus method_breakdown{};
        xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
            &method_breakdown);
        bool method_breakdown_enabled = method_breakdown.enabled != 0;
        if (ImGui::Checkbox("Record PFIFO method-time breakdown",
                            &method_breakdown_enabled)) {
            xemu_diagnostics_pgraph_pusher_method_breakdown_trace_set_enabled(
                method_breakdown_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
                &method_breakdown);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PFIFO Method Breakdown")) {
            xemu_diagnostics_pgraph_pusher_method_breakdown_trace_clear();
            xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
                &method_breakdown);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("long-run threshold %s | buffer %zu",
                            FormatDurationNs((int64_t)method_breakdown.threshold_ns).c_str(),
                            method_breakdown.capacity);
        ImGui::TextDisabled("v3.14z: also aggregates every completed END draw stage, including draws below 5 ms, per retained PFIFO run.");
        ImGui::TextDisabled("Inclusive stage totals nest. Self time excludes measured children only; host time is not GPU execution time.");
        ImGui::Text("Long PFIFO runs retained/overwritten  %llu / %llu",
                    (unsigned long long)method_breakdown.total_long_runs,
                    (unsigned long long)method_breakdown.overwritten_events);
        ImGui::Text("Worst run / puller-dispatch / parser+other  %s / %s / %s",
                    FormatDurationNs((int64_t)method_breakdown.worst_run_ns).c_str(),
                    FormatDurationNs((int64_t)method_breakdown.worst_puller_dispatch_ns).c_str(),
                    FormatDurationNs((int64_t)method_breakdown.worst_parser_other_ns).c_str());
        ImGui::Text("Last run / puller-dispatch / parser+other   %s / %s / %s",
                    FormatDurationNs((int64_t)method_breakdown.last_run_ns).c_str(),
                    FormatDurationNs((int64_t)method_breakdown.last_puller_dispatch_ns).c_str(),
                    FormatDurationNs((int64_t)method_breakdown.last_parser_other_ns).c_str());
        ImGui::Text("Last puller calls / NV097 calls / unique methods  %u / %u / %u",
                    method_breakdown.last_puller_calls,
                    method_breakdown.last_nv097_calls,
                    method_breakdown.last_unique_nv097_methods);
        ImGui::TextDisabled(
            "Observation-only: each pfifo_run_puller() call is timed at its existing call boundary; PGRAPH supplies only the resolved method identity. Top entries group NV097 method ranges by their base method/name. parser+other is PFIFO_RUN minus summed puller-dispatch time.");

        if (method_breakdown.count != 0) {
            constexpr size_t kDisplayMethodBreakdownRuns = 24;
            std::array<XemuDiagnosticsPgraphPusherMethodBreakdownEvent,
                       kDisplayMethodBreakdownRuns> runs{};
            const size_t run_n =
                xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace(
                    runs.data(), runs.size());
            if (ImGui::BeginTable(
                    "pgraph_pusher_method_breakdown", 8,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                        ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 260.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("PFIFO run");
                ImGui::TableSetupColumn("Puller dispatch");
                ImGui::TableSetupColumn("Parser+other");
                ImGui::TableSetupColumn("Calls");
                ImGui::TableSetupColumn("Top NV097 method");
                ImGui::TableSetupColumn("Top total/calls");
                ImGui::TableSetupColumn("Top max");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < run_n; ++i) {
                    const auto &e = runs[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.duration_ns).c_str());
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.puller_dispatch_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)e.parser_other_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%u/%u", e.puller_calls, e.nv097_calls);
                    if (e.top_method_count != 0) {
                        const auto &top = e.top_methods[0];
                        ImGui::TableSetColumnIndex(5);
                        ImGui::Text("%s [97:%04X]", top.name, top.method_base);
                        ImGui::TableSetColumnIndex(6);
                        ImGui::Text("%s / %u",
                                    FormatDurationNs((int64_t)top.total_ns).c_str(),
                                    top.call_count);
                        ImGui::TableSetColumnIndex(7);
                        ImGui::TextUnformatted(
                            FormatDurationNs((int64_t)top.max_ns).c_str());
                    } else {
                        ImGui::TableSetColumnIndex(5);
                        ImGui::TextDisabled("<none>");
                    }
                }
                ImGui::EndTable();
            }
            if (run_n && ImGui::TreeNode("Last retained PFIFO run: all-draw stage totals")) {
                const auto &draw = runs[run_n - 1].draw;
                ImGui::Text("END draws / below 5 ms: %llu / %llu",
                    (unsigned long long)draw.completed_draws, (unsigned long long)draw.sub5ms_draws);
                ImGui::Text("Pipeline fast reuse / LRU hit / miss: %llu / %llu / %llu",
                    (unsigned long long)draw.fast_reuse, (unsigned long long)draw.cache_hits,
                    (unsigned long long)draw.cache_misses);
                ImGui::Text("Dropped / invalid spans / saturation: %llu / %llu / %llu",
                    (unsigned long long)draw.dropped_spans, (unsigned long long)draw.invalid_spans,
                    (unsigned long long)draw.saturated);
                for (uint32_t stage = 1; stage < XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT; ++stage) {
                    const auto &stat = draw.stages[stage];
                    if (!stat.calls) continue;
                    ImGui::Text("%s: total %s | self %s | calls %llu | max %s",
                        PgraphDrawTraceStageName(stage),
                        FormatDurationNs((int64_t)stat.total_ns).c_str(),
                        FormatDurationNs((int64_t)stat.self_ns).c_str(),
                        (unsigned long long)stat.calls,
                        FormatDurationNs((int64_t)stat.max_ns).c_str());
                }
                ImGui::TreePop();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Scheduler)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Xbox Scheduler / Thread Wake Investigator");
        XemuDiagnosticsSchedulerTraceStatus scheduler_status{};
        xemu_diagnostics_get_scheduler_trace_status(&scheduler_status);
        bool scheduler_enabled = scheduler_status.enabled != 0;
        if (ImGui::Checkbox("Record KiIdleLoop / thread wake lifecycle", &scheduler_enabled)) {
            xemu_diagnostics_scheduler_trace_set_enabled(scheduler_enabled ? 1 : 0);
            xemu_diagnostics_get_scheduler_trace_status(&scheduler_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Scheduler Trace")) {
            xemu_diagnostics_scheduler_trace_clear();
            xemu_diagnostics_get_scheduler_trace_status(&scheduler_status);
        }
        ImGui::Text("KiIdleLoop range          %08X-%08X",
                    scheduler_status.idle_pc_start, scheduler_status.idle_pc_end);
        const std::string scheduler_sample_pc =
            FormatGuestPc(scheduler_status.last_sample_pc);
        const std::string scheduler_title_pc =
            FormatGuestPc(scheduler_status.last_title_pc);
        ImGui::Text("Last sampled / title PC   %s / %s",
                    scheduler_sample_pc.c_str(), scheduler_title_pc.c_str());
        ImGui::Text("Buffered scheduler events %zu / %zu",
                    scheduler_status.count,
                    DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_SCHEDULER));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)scheduler_status.total_events,
                    (unsigned long long)scheduler_status.overwritten_events);
        ImGui::Text("Longest completed idle    %s",
                    FormatDurationNs((int64_t)scheduler_status.longest_completed_idle_ns).c_str());
        if (scheduler_status.active_idle) {
            ImGui::Text("Active KiIdleLoop age     %s",
                        FormatDurationNs((int64_t)scheduler_status.active_idle_age_ns).c_str());
        } else {
            ImGui::TextDisabled("Active KiIdleLoop age     <none>");
        }
        ImGui::TextDisabled("Uses KiIdleLoop at 8001B02E-8001B04F. Captures last title PC, EBX+28/+2C scheduler slots, CPU interrupt state, NV2A IRQ state, and IRQ activity observed while idle.");
        if (scheduler_status.count) {
            std::array<XemuDiagnosticsSchedulerTraceEvent, 96> events{};
            const size_t n = xemu_diagnostics_get_scheduler_trace(events.data(), events.size());
            if (ImGui::BeginTable("scheduler_wake_trace", 10,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Idle Age/Duration");
                ImGui::TableSetupColumn("PC");
                ImGui::TableSetupColumn("Last Title PC");
                ImGui::TableSetupColumn("EBX slots +28/+2C");
                ImGui::TableSetupColumn("CPU IRQ");
                ImGui::TableSetupColumn("Last IRQ");
                ImGui::TableSetupColumn("Idle IRQ counts V/Pt/Pg/Pf/OHCI");
                ImGui::TableSetupColumn("NV2A PMC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < n; ++i) {
                    const auto &e = events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(SchedulerTraceEventName(e.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)e.idle_age_ns).c_str(),
                        FormatDurationNs((int64_t)e.duration_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    DrawGuestPc(e.guest_pc);
                    ImGui::TableSetColumnIndex(4);
                    DrawGuestPc(e.last_title_pc);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%08X / %08X", e.scheduler_slot_28, e.scheduler_slot_2c);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("0x%X h=%u ex=%d", e.interrupt_request, e.halted, e.exception_index);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%s p=%08X e=%08X", SchedulerWakeSourceName(e.last_irq_source), e.last_irq_pending, e.last_irq_enabled);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%u/%u/%u/%u/%u", e.idle_vblank_count, e.idle_ptimer_count, e.idle_pgraph_count, e.idle_pfifo_count, e.idle_ohci_count);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%08X/%08X", e.pmc_pending, e.pmc_enabled);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::IrqLatency)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PTIMER IRQ Service Latency Profiler");
        XemuDiagnosticsLatencyTraceStatus irq_status{};
        xemu_diagnostics_get_ptimer_irq_latency_trace_status(&irq_status);
        bool irq_enabled = irq_status.enabled != 0;
        if (ImGui::Checkbox("Record slow PTIMER IRQ service", &irq_enabled)) {
            xemu_diagnostics_ptimer_irq_latency_trace_set_enabled(irq_enabled ? 1 : 0);
            xemu_diagnostics_get_ptimer_irq_latency_trace_status(&irq_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PTIMER IRQ Latency")) {
            xemu_diagnostics_ptimer_irq_latency_trace_clear();
            xemu_diagnostics_get_ptimer_irq_latency_trace_status(&irq_status);
        }
        float irq_threshold_ms = (float)((double)irq_status.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(120.0f);
        if (ImGui::InputFloat("PTIMER IRQ Threshold (ms)", &irq_threshold_ms,
                              0.1f, 1.0f, "%.3f")) {
            irq_threshold_ms =
                std::max(0.01f, std::min(irq_threshold_ms, 10000.0f));
            xemu_diagnostics_ptimer_irq_latency_trace_set_threshold_ns(
                (uint64_t)std::llround((double)irq_threshold_ms * 1000000.0));
            xemu_diagnostics_get_ptimer_irq_latency_trace_status(&irq_status);
        }
        ImGui::Text("Buffered slow PTIMER IRQ services %zu / %zu", irq_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY));
        if (irq_status.count) {
            std::array<XemuDiagnosticsPtimerIrqLatencyEvent, 64> events{};
            size_t n = xemu_diagnostics_get_ptimer_irq_latency_trace(
                events.data(), events.size());
            if (ImGui::BeginTable(
                    "ptimer_irq_latency_trace", 7,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 180.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Latency");
                ImGui::TableSetupColumn("Clear PC");
                ImGui::TableSetupColumn("Interrupt Req");
                ImGui::TableSetupColumn("EFLAGS");
                ImGui::TableSetupColumn("Halted");
                ImGui::TableSetupColumn("TIDs Set/Clear");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < n; i++) {
                    const auto &e = events[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)e.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)e.service_latency_ns).c_str());
                    ImGui::TableSetColumnIndex(2);
                    if (e.clear_guest_pc_valid) {
                        DrawGuestPc(e.clear_guest_pc);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("0x%X", e.clear_interrupt_request);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("0x%X", e.clear_eflags);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%u", e.clear_halted);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%d / %d", e.set_thread_id, e.clear_thread_id);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::IrqDelivery)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)");
        XemuDiagnosticsPtimerIrqDeliveryStatus delivery_status{};
        xemu_diagnostics_get_ptimer_irq_delivery_trace_status(&delivery_status);
        bool delivery_enabled = delivery_status.enabled != 0;
        if (ImGui::Checkbox("Record PTIMER -> PIC -> TCG interrupt delivery",
                            &delivery_enabled)) {
            xemu_diagnostics_ptimer_irq_delivery_trace_set_enabled(
                delivery_enabled ? 1 : 0);
            xemu_diagnostics_get_ptimer_irq_delivery_trace_status(&delivery_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PTIMER IRQ Delivery")) {
            xemu_diagnostics_ptimer_irq_delivery_trace_clear();
            xemu_diagnostics_get_ptimer_irq_delivery_trace_status(&delivery_status);
        }
        ImGui::Text("Active: %s  slow captures: %zu/%d  total windows: %llu",
                    delivery_status.active ? "yes" : "no",
                    delivery_status.stored_captures,
                    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT,
                    (unsigned long long)delivery_status.total_windows);
        ImGui::Text("Threshold: %.3f ms  sample: %.3f ms  last: %.3f ms (%s)",
                    (double)delivery_status.slow_threshold_ns / 1000000.0,
                    (double)delivery_status.sample_interval_ns / 1000000.0,
                    (double)delivery_status.last_service_virtual_ns / 1000000.0,
                    PtimerIrqDeliveryClassName(delivery_status.last_classification));
        if (delivery_status.dispatcher_single_step_suppressed) {
            ImGui::TextDisabled(
                "Patch 305.1 dispatcher-page single-step is suppressed while this trace is enabled.");
        }
    }
    if (m_view.IsVisible(DiagnosticSection::HostStall)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Windows Host Stall / Page-Fault Correlation (Patch 305.4)");
        XemuDiagnosticsHostStallStatus host_stall_status{};
        xemu_diagnostics_get_host_stall_trace_status(&host_stall_status);
        bool host_stall_enabled = host_stall_status.enabled != 0;
        if (ImGui::Checkbox("Record Windows vCPU/main-loop host stalls",
                            &host_stall_enabled)) {
            xemu_diagnostics_host_stall_trace_set_enabled(
                host_stall_enabled ? 1 : 0);
            xemu_diagnostics_get_host_stall_trace_status(&host_stall_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Host Stall Trace")) {
            xemu_diagnostics_host_stall_trace_clear();
            xemu_diagnostics_get_host_stall_trace_status(&host_stall_status);
        }
        ImGui::Text("Events %zu/%d  total %llu  vCPU/main %llu/%llu",
                    host_stall_status.count,
                    XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY,
                    (unsigned long long)host_stall_status.total_events,
                    (unsigned long long)host_stall_status.vcpu_events,
                    (unsigned long long)host_stall_status.main_loop_events);
        ImGui::Text("Worst vCPU wall/off-CPU %.3f/%.3f ms  main-loop excess %.3f ms",
                    (double)host_stall_status.worst_vcpu_wall_ns / 1000000.0,
                    (double)host_stall_status.worst_vcpu_offcpu_ns / 1000000.0,
                    (double)host_stall_status.worst_main_loop_excess_ns / 1000000.0);
        ImGui::Text("Page-fault correlated %llu  worst fault delta %llu",
                    (unsigned long long)host_stall_status.pagefault_correlated_events,
                    (unsigned long long)host_stall_status.worst_page_fault_delta);
        if (!host_stall_status.windows_supported) {
            ImGui::TextDisabled("Windows-only counters are unavailable on this host.");
        } else {
            ImGui::TextDisabled(
                "PageFaultCount includes soft and hard faults; correlation does not prove disk paging. "
                "vCPU events compare wall time with GetThreadTimes; main-loop events record wait timeout overshoot.");
        }
    }
    if (m_view.IsVisible(DiagnosticSection::InputPoll)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Controller Input Poll Stage Profiler");
        XemuDiagnosticsControllerInputPollStatus input_poll_status{};
        xemu_diagnostics_get_controller_input_poll_trace_status(&input_poll_status);
        bool input_poll_enabled = input_poll_status.enabled != 0;
        if (ImGui::Checkbox("Record slow controller input polls", &input_poll_enabled)) {
            xemu_diagnostics_controller_input_poll_trace_set_enabled(
                input_poll_enabled ? 1 : 0);
            xemu_diagnostics_get_controller_input_poll_trace_status(
                &input_poll_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Controller Input Polls")) {
            xemu_diagnostics_controller_input_poll_trace_clear();
            xemu_diagnostics_get_controller_input_poll_trace_status(
                &input_poll_status);
        }

        float input_poll_threshold_ms =
            (float)((double)input_poll_status.threshold_ns / 1000000.0);
        ImGui::SetNextItemWidth(120.0f);
        if (ImGui::InputFloat("Input Poll Threshold (ms)",
                              &input_poll_threshold_ms, 0.1f, 1.0f, "%.3f")) {
            input_poll_threshold_ms =
                std::max(0.01f, std::min(input_poll_threshold_ms, 10000.0f));
            const uint64_t threshold_ns = (uint64_t)std::llround(
                (double)input_poll_threshold_ms * 1000000.0);
            xemu_diagnostics_controller_input_poll_trace_set_threshold_ns(
                threshold_ns);
            xemu_diagnostics_get_controller_input_poll_trace_status(
                &input_poll_status);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("1 = 1 ms; profiles XID IN -> update_input -> SDL getters");
        ImGui::Text("Buffered slow input polls %zu / %zu", input_poll_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)input_poll_status.total_events,
                    (unsigned long long)input_poll_status.overwritten_events);
        ImGui::TextDisabled("Only XID interrupt-IN polls at or above the threshold are retained; all 15 button and 6 axis SDL getters are timed individually.");

        if (input_poll_status.count != 0) {
            constexpr size_t kDisplayInputPolls = 64;
            std::array<XemuDiagnosticsControllerInputPollEvent,
                       kDisplayInputPolls> input_polls{};
            const size_t input_poll_count =
                xemu_diagnostics_get_controller_input_poll_trace(
                    input_polls.data(), input_polls.size());
            if (ImGui::BeginTable("controller_input_poll_trace", 13,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY |
                                      ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Total");
                ImGui::TableSetupColumn("Update Input");
                ImGui::TableSetupColumn("Update Controller");
                ImGui::TableSetupColumn("SDL State");
                ImGui::TableSetupColumn("Buttons / Axes");
                ImGui::TableSetupColumn("Worst Getter");
                ImGui::TableSetupColumn("Gate");
                ImGui::TableSetupColumn("XID Mapping");
                ImGui::TableSetupColumn("Host / XID Trace");
                ImGui::TableSetupColumn("USB Copy");
                ImGui::TableSetupColumn("Packet Trace");
                ImGui::TableSetupColumn("SDL / Status");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < input_poll_count; ++i) {
                    const auto &event = input_polls[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.host_duration_ns).c_str());
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.update_input_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.update_controller_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.sdl_controller_state_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)event.sdl_button_getters_ns).c_str(),
                        FormatDurationNs((int64_t)event.sdl_axis_getters_ns).c_str());
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%s %s", ControllerInputGetterName(event.worst_getter),
                        FormatDurationNs((int64_t)event.worst_getter_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.update_gate_ns).c_str());
                    ImGui::TableSetColumnIndex(8);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.input_mapping_ns).c_str());
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s / %s",
                        FormatDurationNs((int64_t)event.host_state_trace_ns).c_str(),
                        FormatDurationNs((int64_t)event.xid_state_trace_ns).c_str());
                    ImGui::TableSetColumnIndex(10);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.usb_packet_copy_ns).c_str());
                    ImGui::TableSetColumnIndex(11);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.packet_complete_trace_ns).c_str());
                    ImGui::TableSetColumnIndex(12);
                    ImGui::Text("id=%d conn=%u upd=%u status=%d len=%u",
                                event.sdl_joystick_id, event.connected,
                                event.update_performed, event.packet_status,
                                event.actual_length);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::QemuTimer)) {
        ImGui::Separator();
        ImGui::TextUnformatted("QEMU Timer Dispatch Flight Recorder");
        XemuDiagnosticsQemuTimerTraceStatus qtimer_status{};
        xemu_diagnostics_get_qemu_timer_trace_status(&qtimer_status);
        bool qtimer_enabled = qtimer_status.enabled != 0;
        if (ImGui::Checkbox("Record PTIMER QEMU dispatch", &qtimer_enabled)) {
            xemu_diagnostics_qemu_timer_trace_set_enabled(qtimer_enabled ? 1 : 0);
            if (qtimer_enabled) {
                /* The ownership recorder is the next-stage companion to the timer
                 * flight recorder. Auto-arm it so a reproduced PTIMER miss cannot
                 * accidentally omit the blocking BQL owner. It remains independently
                 * controllable below after being armed. */
                xemu_diagnostics_bql_trace_set_enabled(1);
                xemu_diagnostics_main_loop_lock_trace_set_enabled(1);
                xemu_diagnostics_mmio_trace_set_enabled(1);
                xemu_diagnostics_pgraph_lock_trace_set_enabled(1);
                xemu_diagnostics_pgraph_draw_trace_set_enabled(1);
                xemu_diagnostics_flip_stall_trace_set_enabled(1);
            }
            xemu_diagnostics_get_qemu_timer_trace_status(&qtimer_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear QEMU Timer Trace")) {
            xemu_diagnostics_qemu_timer_trace_clear();
            xemu_diagnostics_get_qemu_timer_trace_status(&qtimer_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", qtimer_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_QEMU_TIMER));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)qtimer_status.total_events,
                    (unsigned long long)qtimer_status.overwritten_events);
        if (qtimer_status.watched_timer_expire_ns >= 0) {
            ImGui::Text("Watched PTIMER expiry     %lld ns",
                        (long long)qtimer_status.watched_timer_expire_ns);
        } else {
            ImGui::TextDisabled("Watched PTIMER expiry     <not armed>");
        }
        ImGui::TextDisabled("Records only the NV2A PTIMER plus main-loop wait/run-timer activity within +/-100 ms of its deadline.");
        ImGui::TextDisabled("Main-Loop Wait Stage Trace splits os_host_main_loop_wait into poll, lock-reacquire, GLib, and Windows callback stages.");
        ImGui::TextDisabled("Enabling PTIMER QEMU dispatch also arms BQL, MMIO, PGRAPH Lock, PGRAPH Draw-End, and FLIP_STALL/VBlank traces automatically.");

        if (qtimer_status.count != 0) {
            constexpr size_t kDisplayQTimerEvents = 128;
            std::array<XemuDiagnosticsQemuTimerTraceEvent,
                       kDisplayQTimerEvents> qtrace{};
            const size_t qtrace_count =
                xemu_diagnostics_get_qemu_timer_trace(qtrace.data(), qtrace.size());
            if (ImGui::BeginTable("qemu_timer_dispatch_trace", 8,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 240.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Timer Delta");
                ImGui::TableSetupColumn("Wait Timeout");
                ImGui::TableSetupColumn("Wait Host");
                ImGui::TableSetupColumn("Wait Virtual");
                ImGui::TableSetupColumn("Dispatch Late");
                ImGui::TableSetupColumn("Value");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < qtrace_count; ++i) {
                    const auto &event = qtrace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(QemuTimerTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.timer_delta_ns).c_str());
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.timeout_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.wait_elapsed_host_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.wait_elapsed_virtual_ns).c_str());
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(
                        FormatDurationNs(event.dispatch_late_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%lld", (long long)event.value);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Bql)) {
        ImGui::Separator();
        ImGui::TextUnformatted("BQL Ownership Trace");
        XemuDiagnosticsBqlTraceStatus bql_status{};
        xemu_diagnostics_get_bql_trace_status(&bql_status);
        bool bql_enabled = bql_status.enabled != 0;
        if (ImGui::Checkbox("Record BQL ownership", &bql_enabled)) {
            xemu_diagnostics_bql_trace_set_enabled(bql_enabled ? 1 : 0);
            xemu_diagnostics_get_bql_trace_status(&bql_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear BQL Trace")) {
            xemu_diagnostics_bql_trace_clear();
            xemu_diagnostics_get_bql_trace_status(&bql_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", bql_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_BQL));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)bql_status.total_events,
                    (unsigned long long)bql_status.overwritten_events);
        ImGui::Text("Long wait/hold threshold  %.3f ms",
                    (double)bql_status.long_wait_threshold_ns / 1000000.0);
        if (bql_status.current_owner_thread_id != 0) {
            ImGui::Text("Current owner             TID %d  CPU %d  held %s",
                        bql_status.current_owner_thread_id,
                        bql_status.current_owner_cpu_index,
                        FormatDurationNs((int64_t)bql_status.current_owner_held_ns).c_str());
            ImGui::Text("Owner acquisition         %s:%d",
                        bql_status.current_owner_caller_file[0]
                            ? bql_status.current_owner_caller_file : "<unknown>",
                        bql_status.current_owner_caller_line);
            ImGui::Text("Owner context             %s",
                        BqlTraceContextName(bql_status.current_owner_context));
            if (bql_status.current_owner_stage != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE) {
                ImGui::Text("Owner active stage        %s (%s)",
                            BqlTraceStageName(bql_status.current_owner_stage),
                            FormatDurationNs((int64_t)bql_status.current_owner_stage_elapsed_ns).c_str());
            }
            if (bql_status.current_owner_guest_pc_valid) {
                ImGui::TextUnformatted("Owner guest PC");
                ImGui::SameLine(170.0f);
                DrawGuestPc(bql_status.current_owner_guest_pc);
            }
        } else {
            ImGui::TextDisabled("Current owner             <not tracked / main-loop lock free>");
        }
        ImGui::TextDisabled("Lock-free recorder: only BQL waits/holds >= 1 ms are retained; every acquisition still updates owner metadata.");

        if (bql_status.count != 0) {
            constexpr size_t kDisplayBqlEvents = 64;
            std::array<XemuDiagnosticsBqlTraceEvent, kDisplayBqlEvents> bql_trace{};
            const size_t bql_count =
                xemu_diagnostics_get_bql_trace(bql_trace.data(), bql_trace.size());
            if (ImGui::BeginTable("bql_ownership_trace", 12,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("TID / CPU");
                ImGui::TableSetupColumn("Wait");
                ImGui::TableSetupColumn("Hold");
                ImGui::TableSetupColumn("Owner TID / CPU");
                ImGui::TableSetupColumn("Owner held at wait");
                ImGui::TableSetupColumn("Context");
                ImGui::TableSetupColumn("Owner context / stage");
                ImGui::TableSetupColumn("Callsite");
                ImGui::TableSetupColumn("Owner callsite");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < bql_count; ++i) {
                    const auto &event = bql_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(BqlTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%d / %d", event.thread_id, event.cpu_index);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.wait_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.held_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%d / %d", event.owner_thread_id, event.owner_cpu_index);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.owner_held_at_attempt_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(BqlTraceContextName(event.caller_context));
                    ImGui::TableSetColumnIndex(8);
                    if (event.event_type == XEMU_DIAG_BQL_LONG_WAIT) {
                        ImGui::Text("%s / %s",
                                    BqlTraceContextName(event.owner_context),
                                    BqlTraceStageName(event.owner_stage_at_attempt));
                    } else {
                        ImGui::Text("%s / %s",
                                    BqlTraceContextName(event.caller_context),
                                    BqlTraceStageName(event.longest_stage));
                    }
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s:%d", event.caller_file[0] ? event.caller_file : "<unknown>",
                                event.caller_line);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%s:%d",
                                event.owner_caller_file[0] ? event.owner_caller_file : "<unknown>",
                                event.owner_caller_line);
                    ImGui::TableSetColumnIndex(11);
                    if (event.event_type == XEMU_DIAG_BQL_LONG_WAIT &&
                        event.owner_guest_pc_start_valid) {
                        const std::string owner_pc =
                            FormatGuestPc(event.owner_guest_pc_start);
                        ImGui::Text("owner %s", owner_pc.c_str());
                    } else if (event.guest_pc_start_valid) {
                        DrawGuestPcRange(event.guest_pc_start,
                                         event.guest_pc_end_valid != 0,
                                         event.guest_pc_end);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::MainLoop)) {
        ImGui::Separator();
        ImGui::TextUnformatted("QEMU Main Loop Lock Ownership Trace");
        XemuDiagnosticsMainLoopLockTraceStatus main_loop_lock_status{};
        xemu_diagnostics_get_main_loop_lock_trace_status(&main_loop_lock_status);
        bool main_loop_lock_enabled = main_loop_lock_status.enabled != 0;
        if (ImGui::Checkbox("Record qemu_main_loop_lock ownership", &main_loop_lock_enabled)) {
            xemu_diagnostics_main_loop_lock_trace_set_enabled(main_loop_lock_enabled ? 1 : 0);
            xemu_diagnostics_get_main_loop_lock_trace_status(&main_loop_lock_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Main Loop Lock Trace")) {
            xemu_diagnostics_main_loop_lock_trace_clear();
            xemu_diagnostics_get_main_loop_lock_trace_status(&main_loop_lock_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", main_loop_lock_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)main_loop_lock_status.total_events,
                    (unsigned long long)main_loop_lock_status.overwritten_events);
        ImGui::Text("Long wait/hold threshold  %.3f ms",
                    (double)main_loop_lock_status.long_wait_threshold_ns / 1000000.0);
        if (main_loop_lock_status.current_owner_thread_id != 0) {
            ImGui::Text("Current owner             TID %d  CPU %d  held %s",
                        main_loop_lock_status.current_owner_thread_id,
                        main_loop_lock_status.current_owner_cpu_index,
                        FormatDurationNs((int64_t)main_loop_lock_status.current_owner_held_ns).c_str());
            ImGui::Text("Owner acquisition         %s:%d",
                        main_loop_lock_status.current_owner_caller_file[0]
                            ? main_loop_lock_status.current_owner_caller_file : "<unknown>",
                        main_loop_lock_status.current_owner_caller_line);
            ImGui::Text("Owner context             %s",
                        BqlTraceContextName(main_loop_lock_status.current_owner_context));
            if (main_loop_lock_status.current_owner_stage != XEMU_DEBUG_TOOLS_BQL_STAGE_NONE) {
                ImGui::Text("Owner active stage        %s (%s)",
                            BqlTraceStageName(main_loop_lock_status.current_owner_stage),
                            FormatDurationNs((int64_t)main_loop_lock_status.current_owner_stage_elapsed_ns).c_str());
            }
            if (main_loop_lock_status.current_owner_guest_pc_valid) {
                ImGui::TextUnformatted("Owner guest PC");
                ImGui::SameLine(170.0f);
                DrawGuestPc(main_loop_lock_status.current_owner_guest_pc);
            }
        } else {
            ImGui::TextDisabled("Current owner             <not tracked / main-loop lock free>");
        }
        ImGui::TextDisabled("Lock-free recorder: only qemu_main_loop_lock waits/holds >= 1 ms are retained; every acquisition still updates owner metadata.");

        if (main_loop_lock_status.count != 0) {
            constexpr size_t kDisplayMainLoopLockEvents = 64;
            std::array<XemuDiagnosticsMainLoopLockTraceEvent, kDisplayMainLoopLockEvents> main_loop_lock_trace{};
            const size_t main_loop_lock_count =
                xemu_diagnostics_get_main_loop_lock_trace(main_loop_lock_trace.data(), main_loop_lock_trace.size());
            if (ImGui::BeginTable("main_loop_lock_ownership_trace", 12,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("TID / CPU");
                ImGui::TableSetupColumn("Wait");
                ImGui::TableSetupColumn("Hold");
                ImGui::TableSetupColumn("Owner TID / CPU");
                ImGui::TableSetupColumn("Owner held at wait");
                ImGui::TableSetupColumn("Context");
                ImGui::TableSetupColumn("Owner context / stage");
                ImGui::TableSetupColumn("Callsite");
                ImGui::TableSetupColumn("Owner callsite");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < main_loop_lock_count; ++i) {
                    const auto &event = main_loop_lock_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(MainLoopLockTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%d / %d", event.thread_id, event.cpu_index);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.wait_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.held_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%d / %d", event.owner_thread_id, event.owner_cpu_index);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.owner_held_at_attempt_ns).c_str());
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(BqlTraceContextName(event.caller_context));
                    ImGui::TableSetColumnIndex(8);
                    if (event.event_type == XEMU_DIAG_MAIN_LOOP_LOCK_LONG_WAIT) {
                        ImGui::Text("%s / %s",
                                    BqlTraceContextName(event.owner_context),
                                    BqlTraceStageName(event.owner_stage_at_attempt));
                    } else {
                        ImGui::Text("%s / %s",
                                    BqlTraceContextName(event.caller_context),
                                    BqlTraceStageName(event.longest_stage));
                    }
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s:%d", event.caller_file[0] ? event.caller_file : "<unknown>",
                                event.caller_line);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%s:%d",
                                event.owner_caller_file[0] ? event.owner_caller_file : "<unknown>",
                                event.owner_caller_line);
                    ImGui::TableSetColumnIndex(11);
                    if (event.event_type == XEMU_DIAG_MAIN_LOOP_LOCK_LONG_WAIT &&
                        event.owner_guest_pc_start_valid) {
                        const std::string owner_pc =
                            FormatGuestPc(event.owner_guest_pc_start);
                        ImGui::Text("owner %s", owner_pc.c_str());
                    } else if (event.guest_pc_start_valid) {
                        DrawGuestPcRange(event.guest_pc_start,
                                         event.guest_pc_end_valid != 0,
                                         event.guest_pc_end);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::Mmio)) {
        ImGui::Separator();
        ImGui::TextUnformatted("MMIO Dispatch Trace");
        XemuDiagnosticsMmioTraceStatus mmio_status{};
        xemu_diagnostics_get_mmio_trace_status(&mmio_status);
        bool mmio_enabled = mmio_status.enabled != 0;
        if (ImGui::Checkbox("Record long MMIO dispatches", &mmio_enabled)) {
            xemu_diagnostics_mmio_trace_set_enabled(mmio_enabled ? 1 : 0);
            xemu_diagnostics_get_mmio_trace_status(&mmio_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear MMIO Trace")) {
            xemu_diagnostics_mmio_trace_clear();
            xemu_diagnostics_get_mmio_trace_status(&mmio_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", mmio_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_MMIO));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)mmio_status.total_events,
                    (unsigned long long)mmio_status.overwritten_events);
        ImGui::Text("Long dispatch threshold   %.3f ms",
                    (double)mmio_status.long_dispatch_threshold_ns / 1000000.0);
        ImGui::TextDisabled("Records CPU MMIO reads/writes that spend >= 1 ms inside the device MemoryRegion dispatch while BQL is held.");

        if (mmio_status.count != 0) {
            constexpr size_t kDisplayMmioEvents = 64;
            std::array<XemuDiagnosticsMmioTraceEvent, kDisplayMmioEvents> mmio_trace{};
            const size_t mmio_count =
                xemu_diagnostics_get_mmio_trace(mmio_trace.data(), mmio_trace.size());
            if (ImGui::BeginTable("mmio_dispatch_trace", 11,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 220.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Op");
                ImGui::TableSetupColumn("TID / CPU");
                ImGui::TableSetupColumn("Host time");
                ImGui::TableSetupColumn("Virtual time");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableSetupColumn("Guest VA");
                ImGui::TableSetupColumn("Guest PA");
                ImGui::TableSetupColumn("Size");
                ImGui::TableSetupColumn("MemoryRegion + offset");
                ImGui::TableSetupColumn("Owner type");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < mmio_count; ++i) {
                    const auto &event = mmio_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(MmioAccessName(event.access_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%d / %d", event.thread_id, event.cpu_index);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.duration_host_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.duration_virtual_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    if (event.guest_pc_start_valid) {
                        DrawGuestPcRange(event.guest_pc_start,
                                         event.guest_pc_end_valid != 0,
                                         event.guest_pc_end);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%08llX", (unsigned long long)event.guest_vaddr);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%08llX", (unsigned long long)event.guest_paddr);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%u", event.size);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%s + 0x%llX", event.region_name,
                                (unsigned long long)event.region_offset);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::TextUnformatted(event.owner_type);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::PgraphLock)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PGRAPH Lock Ownership Trace");
        XemuDiagnosticsPgraphLockTraceStatus pgraph_lock_status{};
        xemu_diagnostics_get_pgraph_lock_trace_status(&pgraph_lock_status);
        bool pgraph_lock_enabled = pgraph_lock_status.enabled != 0;
        if (ImGui::Checkbox("Record PGRAPH lock ownership", &pgraph_lock_enabled)) {
            xemu_diagnostics_pgraph_lock_trace_set_enabled(pgraph_lock_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_lock_trace_status(&pgraph_lock_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PGRAPH Lock Trace")) {
            xemu_diagnostics_pgraph_lock_trace_clear();
            xemu_diagnostics_get_pgraph_lock_trace_status(&pgraph_lock_status);
        }
        ImGui::Text("Buffered events           %zu / %zu", pgraph_lock_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_LOCK));
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)pgraph_lock_status.total_events,
                    (unsigned long long)pgraph_lock_status.overwritten_events);
        ImGui::Text("Long wait/hold threshold  %.3f ms",
                    (double)pgraph_lock_status.long_wait_threshold_ns / 1000000.0);
        if (pgraph_lock_status.current_owner_thread_id != 0) {
            ImGui::Text("Current owner             TID %d  CPU %d  held %s",
                        pgraph_lock_status.current_owner_thread_id,
                        pgraph_lock_status.current_owner_cpu_index,
                        FormatDurationNs((int64_t)pgraph_lock_status.current_owner_held_ns).c_str());
            ImGui::Text("Owner acquisition         %s:%d",
                        pgraph_lock_status.current_owner_acquire_file[0]
                            ? pgraph_lock_status.current_owner_acquire_file : "<unknown>",
                        pgraph_lock_status.current_owner_acquire_line);
            ImGui::Text("Owner method              %s",
                        FormatPgraphMethod(pgraph_lock_status.current_owner_method).c_str());
            if (pgraph_lock_status.current_owner_guest_pc_valid) {
                ImGui::TextUnformatted("Owner guest PC");
                ImGui::SameLine(170.0f);
                DrawGuestPc(pgraph_lock_status.current_owner_guest_pc);
            }
        } else {
            ImGui::TextDisabled("Current owner             <not tracked / PGRAPH lock free>");
        }
        ImGui::TextDisabled("Targets d->pgraph.lock only. Retains waits/holds >= 1 ms and captures PFIFO method/class context when available.");

        if (pgraph_lock_status.count != 0) {
            constexpr size_t kDisplayPgraphLockEvents = 64;
            std::array<XemuDiagnosticsPgraphLockTraceEvent, kDisplayPgraphLockEvents> pgraph_lock_trace{};
            const size_t pgraph_lock_count = xemu_diagnostics_get_pgraph_lock_trace(
                pgraph_lock_trace.data(), pgraph_lock_trace.size());
            if (ImGui::BeginTable("pgraph_lock_ownership_trace", 11,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 240.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("TID / CPU");
                ImGui::TableSetupColumn("Wait");
                ImGui::TableSetupColumn("Hold");
                ImGui::TableSetupColumn("Owner TID / CPU");
                ImGui::TableSetupColumn("Acquire");
                ImGui::TableSetupColumn("Owner Acquire");
                ImGui::TableSetupColumn("Method");
                ImGui::TableSetupColumn("State / Renderer");
                ImGui::TableSetupColumn("Guest PC");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < pgraph_lock_count; ++i) {
                    const auto &event = pgraph_lock_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(PgraphLockTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%d / %d", event.thread_id, event.cpu_index);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.wait_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatDurationNs((int64_t)event.held_ns).c_str());
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%d / %d", event.owner_thread_id, event.owner_cpu_index);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%s:%d",
                                event.acquire_file[0] ? event.acquire_file : "<unknown>",
                                event.acquire_line);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%s:%d",
                                event.owner_acquire_file[0] ? event.owner_acquire_file : "<n/a>",
                                event.owner_acquire_line);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::TextUnformatted(FormatPgraphMethod(
                        event.event_type == XEMU_DIAG_PGRAPH_LOCK_LONG_WAIT
                            ? event.owner_method : event.method).c_str());
                    ImGui::TableSetColumnIndex(9);
                    if (event.event_type == XEMU_DIAG_PGRAPH_LOCK_LONG_HOLD) {
                        ImGui::Text("%s wait=%u/%u/%u flush=%u sync=%u",
                                    event.state.renderer, event.state.waiting_for_nop,
                                    event.state.waiting_for_flip,
                                    event.state.waiting_for_context_switch,
                                    event.state.flush_pending, event.state.sync_pending);
                    } else {
                        ImGui::TextUnformatted("<owner hold event has state>");
                    }
                    ImGui::TableSetColumnIndex(10);
                    if (event.event_type == XEMU_DIAG_PGRAPH_LOCK_LONG_WAIT &&
                        event.owner_guest_pc_start_valid) {
                        const std::string owner_pc =
                            FormatGuestPc(event.owner_guest_pc_start);
                        ImGui::Text("owner %s", owner_pc.c_str());
                    } else if (event.guest_pc_start_valid) {
                        DrawGuestPcRange(event.guest_pc_start,
                                         event.guest_pc_end_valid != 0,
                                         event.guest_pc_end);
                    } else {
                        ImGui::TextUnformatted("<n/a>");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::DrawStages)) {
        ImGui::Separator();
        ImGui::TextUnformatted("SET_BEGIN_END / Renderer Draw-End Breakdown");
        XemuDiagnosticsPgraphDrawTraceStatus pgraph_draw_status{};
        xemu_diagnostics_get_pgraph_draw_trace_status(&pgraph_draw_status);
        bool pgraph_draw_enabled = pgraph_draw_status.enabled != 0;
        if (ImGui::Checkbox("Record long PGRAPH draw-end stages", &pgraph_draw_enabled)) {
            xemu_diagnostics_pgraph_draw_trace_set_enabled(pgraph_draw_enabled ? 1 : 0);
            xemu_diagnostics_get_pgraph_draw_trace_status(&pgraph_draw_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear PGRAPH Draw Trace")) {
            xemu_diagnostics_pgraph_draw_trace_clear();
            xemu_diagnostics_get_pgraph_draw_trace_status(&pgraph_draw_status);
        }
        ImGui::Text("Buffered stage events     %zu / %zu", pgraph_draw_status.count, DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_DRAW));
        ImGui::Text("Retained long draws       %llu",
                    (unsigned long long)pgraph_draw_status.retained_draws);
        ImGui::Text("Draws with omitted detail stages %llu (bounded 48-stage detail pool)",
                    (unsigned long long)pgraph_draw_status.truncated_draws);
        ImGui::Text("Total / overwritten       %llu / %llu",
                    (unsigned long long)pgraph_draw_status.total_events,
                    (unsigned long long)pgraph_draw_status.overwritten_events);
        ImGui::Text("Long draw threshold       %.3f ms",
                    (double)pgraph_draw_status.long_draw_threshold_ns / 1000000.0);
        ImGui::TextDisabled("Buffers SET_BEGIN_END(END) stage timings and commits the full breakdown only when total END work takes >= 5 ms. PFIFO Method-Time Breakdown separately labels SET_BEGIN_END(BEGIN) vs SET_BEGIN_END(END).");
        ImGui::TextDisabled("v3.14z splits Vulkan pipeline prep into texture/shader binding, state/key, cache lookup, build state, creation and install. PFIFO recording also collects sub-5ms draw totals.");

        if (pgraph_draw_status.count != 0) {
            constexpr size_t kDisplayPgraphDrawEvents = 96;
            std::array<XemuDiagnosticsPgraphDrawTraceEvent, kDisplayPgraphDrawEvents>
                pgraph_draw_trace{};
            const size_t pgraph_draw_count = xemu_diagnostics_get_pgraph_draw_trace(
                pgraph_draw_trace.data(), pgraph_draw_trace.size());
            if (ImGui::BeginTable("pgraph_draw_end_stage_trace", 10,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 260.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Draw");
                ImGui::TableSetupColumn("Stage");
                ImGui::TableSetupColumn("Host time");
                ImGui::TableSetupColumn("TID / CPU");
                ImGui::TableSetupColumn("Path");
                ImGui::TableSetupColumn("Primitive");
                ImGui::TableSetupColumn("Counts DA/IE/IB/IA");
                ImGui::TableSetupColumn("State");
                ImGui::TableSetupColumn("Value0 / Value1");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < pgraph_draw_count; ++i) {
                    const auto &event = pgraph_draw_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%llu", (unsigned long long)event.draw_id);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(PgraphDrawTraceStageName(event.stage));
                    ImGui::TableSetColumnIndex(3);
                    ImGui::TextUnformatted(
                        FormatDurationNs((int64_t)event.duration_host_ns).c_str());
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%d / %d", event.thread_id, event.cpu_index);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(PgraphDrawTracePathName(event.path));
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("0x%X", event.primitive_mode);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::Text("%u/%u/%u/%u", event.draw_arrays_length,
                                event.inline_elements_length,
                                event.inline_buffer_length,
                                event.inline_array_length);
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%s zq=%u flush=%u sync=%u", event.renderer,
                                event.zpass_pixel_count_enable,
                                event.flush_pending, event.sync_pending);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%llu / %llu",
                                (unsigned long long)event.value0,
                                (unsigned long long)event.value1);
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::ControllerXid)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Controller / XID / OHCI USB Reconnect Trace");
        XemuDiagnosticsControllerXidTraceStatus controller_xid_status{};
        xemu_diagnostics_get_controller_xid_trace_status(&controller_xid_status);
        bool controller_xid_enabled = controller_xid_status.enabled != 0;
        if (ImGui::Checkbox("Record Controller / XID / OHCI USB reconnect diagnostics",
                            &controller_xid_enabled)) {
            xemu_diagnostics_controller_xid_trace_set_enabled(
                controller_xid_enabled ? 1 : 0);
            xemu_diagnostics_get_controller_xid_trace_status(&controller_xid_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Controller / XID / USB Trace")) {
            xemu_diagnostics_controller_xid_trace_clear();
            xemu_diagnostics_get_controller_xid_trace_status(&controller_xid_status);
        }
        ImGui::Text("Buffered / capacity       %zu / %zu",
                    controller_xid_status.count,
                    DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_CONTROLLER_XID));
        ImGui::Text("Stored / observed          %llu / %llu",
                    (unsigned long long)controller_xid_status.stored_events,
                    (unsigned long long)controller_xid_status.total_observations);
        ImGui::Text("Overwritten                  %llu",
                    (unsigned long long)controller_xid_status.overwritten_events);
        ImGui::Text("Host state / XID state       %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_HOST_INPUT_STATE],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_XID_INPUT_STATE]);
        ImGui::Text("GET_REPORT / INTERRUPT_IN    %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_XID_GET_REPORT],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_XID_INTERRUPT_IN]);
        ImGui::Text("OHCI attach / detach / reset %llu / %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_ATTACH],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_DETACH],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_RESET]);
        ImGui::Text("OHCI RHSC / port writes       %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_RHSC],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE]);
        ImGui::Text("USB control / setup TD        %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_USB_CONTROL_REQUEST],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_SETUP_TD]);
        ImGui::Text("OHCI missing-device TDs       %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING]);
        ImGui::Text("Persistent neutral / reattach %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_NEUTRAL],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_REATTACHED]);
        ImGui::Text("Input test mode on / off      %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_ON],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_OFF]);
        ImGui::Text("XID packet complete             %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_XID_IN_PACKET_COMPLETE]);
        ImGui::Text("OHCI TD / done-head / WDH       %llu / %llu / %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_TD_COMPLETE],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_DONE_HEAD],
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_WDH_IRQ]);
        ImGui::Text("OHCI guest input writes          %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE]);
        ImGui::Text("Missing-bound requests        %llu",
                    (unsigned long long)controller_xid_status.observations[
                        XEMU_DIAG_CONTROLLER_XID_XID_BOUND_MISSING]);
        ImGui::TextDisabled("Reconnect + USB delivery diagnostics. The guest XID is retained across temporary host disconnects. Diagnostics-window controller activity no longer captures guest input. XID packet reports and endpoint-2 guest-memory writes are retained on change/heartbeat; OHCI completion, done-head, and WDH paths use periodic/error retention; counters count every observation.");

        if (controller_xid_status.count != 0) {
            constexpr size_t kDisplayControllerXidEvents = 96;
            std::array<XemuDiagnosticsControllerXidTraceEvent,
                       kDisplayControllerXidEvents> controller_xid_trace{};
            const size_t controller_xid_count = xemu_diagnostics_get_controller_xid_trace(
                controller_xid_trace.data(), controller_xid_trace.size());
            if (ImGui::BeginTable("controller_xid_reconnect_trace", 8,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 280.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Port / SDL ID");
                ImGui::TableSetupColumn("Host buttons");
                ImGui::TableSetupColumn("Host axes");
                ImGui::TableSetupColumn("XID buttons / analog");
                ImGui::TableSetupColumn("XID sticks");
                ImGui::TableSetupColumn("Detail");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < controller_xid_count; ++i) {
                    const auto &event = controller_xid_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(ControllerXidTraceEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    if (event.port >= 0) {
                        ImGui::Text("%d / %u", event.port + 1, event.instance_id);
                    } else {
                        ImGui::Text("- / %u", event.instance_id);
                    }
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("0x%04X", event.host_buttons);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%d %d %d %d %d %d",
                                event.host_axis[0], event.host_axis[1],
                                event.host_axis[2], event.host_axis[3],
                                event.host_axis[4], event.host_axis[5]);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("0x%04X A=%u B=%u X=%u Y=%u",
                                event.xid_buttons, event.xid_analog[0],
                                event.xid_analog[1], event.xid_analog[2],
                                event.xid_analog[3]);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%d %d %d %d", event.thumb_lx, event.thumb_ly,
                                event.thumb_rx, event.thumb_ry);
                    ImGui::TableSetColumnIndex(7);
                    if (event.name[0] || event.guid[0]) {
                        ImGui::Text("%s %s", event.name, event.guid);
                    } else if (event.event_type ==
                               XEMU_DIAG_CONTROLLER_XID_USB_CONTROL_REQUEST) {
                        ImGui::Text("%s req=0x%04X value=0x%04X index=0x%04X len=%u",
                                    UsbControlRequestName(event.value0), event.value0,
                                    event.value1, event.value2, event.value3);
                    } else if (event.event_type ==
                               XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE) {
                        ImGui::Text("write=0x%08X status 0x%08X -> 0x%08X",
                                    event.value0, event.value1, event.value2);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_ATTACH ||
                               event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_DETACH ||
                               event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_RESET) {
                        ImGui::Text("usb=%016llX status 0x%08X -> 0x%08X",
                                    (unsigned long long)event.xid_device,
                                    event.value0, event.value1);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_RHSC) {
                        ImGui::Text("intr 0x%08X -> 0x%08X set=0x%08X mask=0x%08X",
                                    event.value0, event.value1, event.value2, event.value3);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_SETUP_TD ||
                               event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING) {
                        ImGui::Text("addr=%u ep=%u value2=%u td=0x%08X",
                                    event.value0, event.value1, event.value2, event.value3);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_ON ||
                               event.event_type == XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_OFF) {
                        ImGui::Text("nav=%u activity=%u rebind=%u navigating=%u",
                                    event.value0, event.value1, event.value2, event.value3);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_XID_IN_PACKET_COMPLETE) {
                        const std::string report = ControllerXidReportHex(event);
                        ImGui::Text("status=%d actual=%u req=%u ep=%u report=%s",
                                    (int32_t)event.value0, event.value1, event.value2,
                                    event.value3, report.c_str());
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_TD_COMPLETE) {
                        ImGui::Text("addr=%u ep=%u td=0x%08X ret=%d cc=%u",
                                    event.value0, event.value1, event.value2,
                                    (int32_t)event.value3, event.value4);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_DONE_HEAD) {
                        ImGui::Text("prev=0x%08X td=0x%08X new=0x%08X done_count=%u cc=%u",
                                    event.value0, event.value1, event.value2,
                                    event.value3, event.value4);
                    } else if (event.event_type == XEMU_DIAG_CONTROLLER_XID_OHCI_WDH_IRQ) {
                        ImGui::Text("status 0x%08X -> 0x%08X enable=0x%08X arg=0x%08X %s",
                                    event.value0, event.value1, event.value2, event.value3,
                                    event.value4 ? "SET" : "CLEAR");
                    } else if (event.event_type ==
                               XEMU_DIAG_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE) {
                        const std::string report = ControllerXidReportHex(event);
                        ImGui::Text("td=0x%08X guest=0x%08X+%u",
                                    event.value0, event.value1, event.value2);
                        if (event.value4 != 0) {
                            ImGui::SameLine();
                            ImGui::Text("+ 0x%08X+%u", event.value3, event.value4);
                        }
                        ImGui::Text("report=%s", report.c_str());
                    } else {
                        ImGui::Text("xid=%016llX v=%u/%u/%u/%u",
                                    (unsigned long long)event.xid_device,
                                    event.value0, event.value1, event.value2,
                                    event.value3);
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::GpuWait)) {
        ImGui::Separator();
        ImGui::TextUnformatted("GPU Wait / Work State");
        DrawBoolState("PFIFO kick pending", m_device.pfifo_fifo_kick != 0);
        DrawBoolState("PFIFO halted", m_device.pfifo_halt != 0);
        DrawBoolState("PGRAPH waiting for NOP", m_device.pgraph_waiting_for_nop != 0);
        DrawBoolState("PGRAPH waiting for flip", m_device.pgraph_waiting_for_flip != 0);
        DrawBoolState("PGRAPH context switch wait", m_device.pgraph_waiting_for_context_switch != 0);
        DrawBoolState("PGRAPH flush pending", m_device.pgraph_flush_pending != 0);
        DrawBoolState("PGRAPH sync pending", m_device.pgraph_sync_pending != 0);
        ImGui::Text("FPS                       %u", m_device.gpu_fps);
        ImGui::Text("Frame count               %u", m_device.gpu_frame_count);
        ImGui::Text("Last frame work           %d ms", m_device.gpu_last_frame_mspf);
    }
    if (m_view.IsVisible(DiagnosticSection::GuestInput)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Guest Input Consumer Candidate Trace (TCG)");
        XemuDiagnosticsGuestInputConsumerTraceStatus input_consumer_status{};
        xemu_diagnostics_get_guest_input_consumer_trace_status(
            &input_consumer_status);
        bool input_consumer_enabled = input_consumer_status.enabled != 0;
        if (ImGui::Checkbox(
                "Record title blocks after meaningful controller changes",
                &input_consumer_enabled)) {
            xemu_diagnostics_guest_input_consumer_trace_set_enabled(
                input_consumer_enabled ? 1 : 0);
            xemu_diagnostics_get_guest_input_consumer_trace_status(
                &input_consumer_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Guest Input Consumer Trace")) {
            xemu_diagnostics_guest_input_consumer_trace_clear();
            xemu_diagnostics_get_guest_input_consumer_trace_status(
                &input_consumer_status);
        }
        ImGui::Text("Buffered / capacity       %zu / %zu",
                    input_consumer_status.count,
                    DiagnosticsBufferCapacity(
                        XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER));
        ImGui::Text("Report changes / TBs      %llu / %llu",
                    (unsigned long long)input_consumer_status.report_changes,
                    (unsigned long long)input_consumer_status.title_tb_candidates);
        ImGui::Text("Dropped candidates        %llu",
                    (unsigned long long)input_consumer_status.dropped_candidates);
        ImGui::Text("Current report / candidates %llu / %u",
                    (unsigned long long)input_consumer_status.current_report_sequence,
                    input_consumer_status.current_candidate_count);
        ImGui::Text("Capture window            %s (40 ms after changed report)",
                    input_consumer_status.capture_active ? "ACTIVE" : "idle");
        ImGui::TextDisabled(
            "The Xbox XInput/XAPI code is title-linked, so this is a generic consumer-candidate trace rather than a hard-coded XInputGetState hook.");
        ImGui::TextDisabled(
            "Only meaningful button/analog changes (or large stick motion) arm the 40 ms window. TCG direct chaining is disabled only while that window is active.");

        if (input_consumer_status.count != 0) {
            constexpr size_t kDisplayInputConsumerEvents = 160;
            std::array<XemuDiagnosticsGuestInputConsumerTraceEvent,
                       kDisplayInputConsumerEvents> input_consumer_trace{};
            const size_t input_consumer_count =
                xemu_diagnostics_get_guest_input_consumer_trace(
                    input_consumer_trace.data(), input_consumer_trace.size());
            if (ImGui::BeginTable(
                    "guest_input_consumer_trace", 8,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                        ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 280.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Report");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("PC");
                ImGui::TableSetupColumn("Age ms");
                ImGui::TableSetupColumn("Ordinal");
                ImGui::TableSetupColumn("Guest destination");
                ImGui::TableSetupColumn("Report bytes");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < input_consumer_count; ++i) {
                    const auto &event = input_consumer_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%llu",
                                (unsigned long long)event.report_sequence);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        GuestInputConsumerEventName(event.event_type));
                    ImGui::TableSetColumnIndex(3);
                    if (event.guest_pc != 0) {
                        DrawGuestPc(event.guest_pc);
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%.3f",
                                (double)event.age_since_report_ns / 1000000.0);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%u", event.candidate_ordinal);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%08X+%u / %08X+%u", event.guest_address0,
                                event.guest_length0, event.guest_address1,
                                event.guest_length1);
                    ImGui::TableSetColumnIndex(7);
                    ImGui::TextUnformatted(
                        GuestInputConsumerReportHex(event).c_str());
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::GuestTimer)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Guest Timer / Deadline Correlation Trace (TCG)");
        XemuDiagnosticsGuestTimerDeadlineTraceStatus timer_deadline_status{};
        xemu_diagnostics_get_guest_timer_deadline_trace_status(
            &timer_deadline_status);
        bool timer_deadline_enabled = timer_deadline_status.enabled != 0;
        if (ImGui::Checkbox(
                "Record InputBuffer -> D3D timer deadline correlation preset",
                &timer_deadline_enabled)) {
            xemu_diagnostics_guest_timer_deadline_trace_set_enabled(
                timer_deadline_enabled ? 1 : 0);
            xemu_diagnostics_get_guest_timer_deadline_trace_status(
                &timer_deadline_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear Guest Timer / Deadline Trace")) {
            xemu_diagnostics_guest_timer_deadline_trace_clear();
            xemu_diagnostics_get_guest_timer_deadline_trace_status(
                &timer_deadline_status);
        }
        ImGui::Text("Buffered / capacity       %zu / %zu",
                    timer_deadline_status.count,
                    DiagnosticsBufferCapacity(
                        XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE));
        ImGui::Text("Input / D3D sequences     %llu / %llu",
                    (unsigned long long)timer_deadline_status.input_sequences,
                    (unsigned long long)timer_deadline_status.deadline_sequences);
        ImGui::Text("D3D valid / reject        %llu / %llu",
                    (unsigned long long)timer_deadline_status.deadline_valid,
                    (unsigned long long)timer_deadline_status.deadline_rejects);
        ImGui::Text("Last deadline delta       %+lld cycles (%+.3f us)",
                    (long long)timer_deadline_status.last_deadline_delta_cycles,
                    GuestTimerCyclesToUs(
                        timer_deadline_status.last_deadline_delta_cycles));
        ImGui::Text("Worst late deadline       %+lld cycles (%+.3f us)",
                    (long long)timer_deadline_status.worst_late_delta_cycles,
                    GuestTimerCyclesToUs(
                        timer_deadline_status.worst_late_delta_cycles));
        ImGui::Text("D7EA0 schedule / return   %llu / %llu",
                    (unsigned long long)timer_deadline_status.callback_schedule_attempts,
                    (unsigned long long)timer_deadline_status.callback_schedule_returns);
        ImGui::Text("D7EA0 entry / return      %llu / %llu",
                    (unsigned long long)timer_deadline_status.callback_entries,
                    (unsigned long long)timer_deadline_status.callback_returns);
        ImGui::Text("Overdue / next InputBuffer %llu / %llu",
                    (unsigned long long)timer_deadline_status.callback_overdue_events,
                    (unsigned long long)timer_deadline_status.callback_next_input_entries);
        ImGui::Text("Dispatcher attempts / PCs   %llu / %llu",
                    (unsigned long long)timer_deadline_status.dispatcher_attempts,
                    (unsigned long long)timer_deadline_status.dispatcher_pc_events);
        ImGui::Text("Dispatcher good/overdue/recovered %llu / %llu / %llu",
                    (unsigned long long)timer_deadline_status.dispatcher_successful_attempts,
                    (unsigned long long)timer_deadline_status.dispatcher_overdue_attempts,
                    (unsigned long long)timer_deadline_status.dispatcher_recovered_overdue_attempts);
        ImGui::Text("Dispatcher PCs current/good/overdue/recovered %llu / %llu / %llu / %llu",
                    (unsigned long long)timer_deadline_status.dispatcher_current_pc_events,
                    (unsigned long long)timer_deadline_status.dispatcher_last_good_pc_events,
                    (unsigned long long)timer_deadline_status.dispatcher_last_overdue_pc_events,
                    (unsigned long long)timer_deadline_status.dispatcher_last_recovered_pc_events);
        ImGui::Text("Callback watch            %s  input=%llu target=%08X",
                    timer_deadline_status.callback_watch_armed ? "ARMED" :
                        (timer_deadline_status.callback_overdue_latched ? "OVERDUE" : "idle"),
                    (unsigned long long)timer_deadline_status.callback_watch_input_sequence,
                    timer_deadline_status.callback_target);
        if (timer_deadline_status.callback_expected_due_ns != 0) {
            ImGui::Text("Callback due / delta      %llu ns / %+.3f ms",
                        (unsigned long long)timer_deadline_status.callback_expected_due_ns,
                        (double)timer_deadline_status.callback_last_delta_ns / 1000000.0);
        }
        if (timer_deadline_status.callback_schedule_result_valid) {
            const std::string callback_return_pc =
                FormatGuestPc(timer_deadline_status.callback_return_pc);
            ImGui::Text("D3D schedule raw EAX      %08X  return PC=%s",
                        timer_deadline_status.callback_schedule_result_eax,
                        callback_return_pc.c_str());
        }
        ImGui::TextDisabled(
            "Diagnostic only: does not patch timer behavior or pause the guest. Patch 305.1 also traces the D3D PTIMER callback-dispatch path while 000D7EA0 is outstanding.");
        ImGui::TextDisabled(
            "Under TCG, pages 000D7000 and 00216000 use exact-PC capture; page 00223000 is split only from 2 ms before a D7EA0 due time until entry/overdue.");

        if (timer_deadline_status.count != 0) {
            constexpr size_t kDisplayTimerDeadlineEvents = 192;
            std::array<XemuDiagnosticsGuestTimerDeadlineTraceEvent,
                       kDisplayTimerDeadlineEvents> timer_deadline_trace{};
            const size_t timer_deadline_count =
                xemu_diagnostics_get_guest_timer_deadline_trace(
                    timer_deadline_trace.data(), timer_deadline_trace.size());
            if (ImGui::BeginTable(
                    "guest_timer_deadline_trace", 12,
                    ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                        ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX |
                        ImGuiTableFlags_Resizable,
                    ImVec2(0.0f, 300.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Input/D3D");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("PC");
                ImGui::TableSetupColumn("Age ms");
                ImGui::TableSetupColumn("EAX EBX ECX EDX");
                ImGui::TableSetupColumn("ESI EDI ESP EBP");
                ImGui::TableSetupColumn("Nominal / lateness");
                ImGui::TableSetupColumn("Calculated interval");
                ImGui::TableSetupColumn("Deadline / threshold / delta");
                ImGui::TableSetupColumn("Memory / stack");
                ImGui::TableSetupColumn("Callback lifecycle");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < timer_deadline_count; ++i) {
                    const auto &event = timer_deadline_trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%llu / %llu",
                                (unsigned long long)event.input_sequence,
                                (unsigned long long)event.deadline_sequence);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::TextUnformatted(
                        GuestTimerDeadlineEventName(event.event_type));
                    ImGui::TableSetColumnIndex(3);
                    DrawGuestPc(event.guest_pc);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%.3f",
                                (double)event.age_since_input_ns / 1000000.0);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%08X %08X %08X %08X", event.eax, event.ebx,
                                event.ecx, event.edx);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%08X %08X %08X %08X", event.esi, event.edi,
                                event.esp, event.ebp);
                    ImGui::TableSetColumnIndex(7);
                    if ((event.derived_valid_mask &
                         (XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_NOMINAL |
                          XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_LATENESS)) ==
                        (XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_NOMINAL |
                         XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_LATENESS)) {
                        ImGui::Text("%s / %s",
                                    GuestTimerFormatU64(event.nominal_interval).c_str(),
                                    GuestTimerFormatU64(event.accumulated_lateness).c_str());
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(8);
                    if (event.derived_valid_mask &
                        XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_CALCULATED) {
                        ImGui::Text("%s (%lld)",
                                    GuestTimerFormatU64(event.calculated_interval).c_str(),
                                    (long long)(int64_t)event.calculated_interval);
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(9);
                    if (event.derived_valid_mask &
                        XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_DEADLINE) {
                        ImGui::Text("%s / %s / %+lld (%+.3f us)",
                                    GuestTimerFormatU64(event.requested_deadline).c_str(),
                                    GuestTimerFormatU64(event.deadline_threshold).c_str(),
                                    (long long)event.deadline_delta_cycles,
                                    GuestTimerCyclesToUs(event.deadline_delta_cycles));
                    } else if (event.derived_valid_mask &
                               XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_RELATIVE) {
                        ImGui::Text("relative=%s",
                                    GuestTimerFormatU64(event.relative_delay).c_str());
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(10);
                    if (event.memory_valid_mask != 0) {
                        ImGui::Text("1A80=%08X 1A84=%08X 1A90=%08X 1A94=%08X S14=%08X S18=%08X S20=%08X",
                                    event.mem_1a80, event.mem_1a84,
                                    event.mem_1a90, event.mem_1a94,
                                    event.stack_14, event.stack_18,
                                    event.stack_20);
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(11);
                    if (event.callback_target != 0 || event.callback_flags != 0) {
                        ImGui::Text("target=%08X due=%llu d=%+.3fms ret=%08X eax=%08X flags=%02X",
                                    event.callback_target,
                                    (unsigned long long)event.callback_expected_due_ns,
                                    (double)event.callback_delta_ns / 1000000.0,
                                    event.callback_return_pc, event.schedule_result_eax,
                                    event.callback_flags);
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                }
                ImGui::EndTable();
            }
        }
    }
    if (m_view.IsVisible(DiagnosticSection::D3dCallback)) {
        ImGui::Separator();
        ImGui::TextUnformatted("D3D InputBuffer Callback Dispatch Capture (pinned one-shot)");
        XemuDiagnosticsD3dCallbackCaptureStatus callback_capture_status{};
        xemu_diagnostics_get_d3d_callback_capture_status(&callback_capture_status);
        bool callback_capture_enabled = callback_capture_status.enabled != 0;
        if (ImGui::Checkbox("Arm D3D InputBuffer callback watchdog (+5 ms grace)",
                            &callback_capture_enabled)) {
            xemu_diagnostics_d3d_callback_capture_set_enabled(
                callback_capture_enabled ? 1 : 0);
            xemu_diagnostics_get_d3d_callback_capture_status(
                &callback_capture_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear / Re-arm D3D Callback Capture")) {
            xemu_diagnostics_d3d_callback_capture_clear();
            xemu_diagnostics_get_d3d_callback_capture_status(
                &callback_capture_status);
        }
        ImGui::Text("State                     %s%s",
                    callback_capture_status.latched ? "LATCHED" : "armed / waiting",
                    callback_capture_status.capture_in_progress ? " (capturing)" : "");
        ImGui::Text("Overdue grace             %.3f ms",
                    (double)callback_capture_status.grace_ns / 1000000.0);
        ImGui::Text("Transient auto-rearms     %llu",
                    (unsigned long long)callback_capture_status.transient_recoveries);
        if (callback_capture_status.last_recovery_virtual_ns != 0) {
            ImGui::Text("Last transient recovery   %llu ns (%+.3f ms vs due)",
                        (unsigned long long)callback_capture_status.last_recovery_virtual_ns,
                        (double)callback_capture_status.last_recovery_delta_ns / 1000000.0);
        }
        if (callback_capture_status.latched) {
            const auto &t = callback_capture_status.trigger;
            ImGui::Text("Input / D3D sequence      %llu / %llu",
                        (unsigned long long)t.input_sequence,
                        (unsigned long long)t.deadline_sequence);
            ImGui::Text("Schedule / expected due   %llu / %llu ns",
                        (unsigned long long)t.schedule_virtual_ns,
                        (unsigned long long)t.expected_due_ns);
            const std::string trigger_pc = FormatGuestPc(t.trigger_guest_pc);
            ImGui::Text("Callback overdue          %+.3f ms at PC %s",
                        (double)t.overdue_ns / 1000000.0, trigger_pc.c_str());
            const std::string callback_target = FormatGuestPc(t.callback_target);
            const std::string callback_return = FormatGuestPc(t.callback_return_pc);
            ImGui::Text("Target / learned return   %s / %s",
                        callback_target.c_str(), callback_return.c_str());
            if (t.schedule_result_valid) {
                ImGui::Text("D3D schedule raw EAX      %08X", t.schedule_result_eax);
            } else {
                ImGui::TextUnformatted("D3D schedule raw EAX      <return not observed>");
            }
            ImGui::Text("Capture copy duration     %.3f ms",
                        (double)callback_capture_status.capture_duration_host_ns /
                            1000000.0);
            ImGui::Text("Pinned tails Q/B/ML/P/S/G %zu / %zu / %zu / %zu / %zu / %zu",
                        callback_capture_status.qtimer_count,
                        callback_capture_status.bql_count,
                        callback_capture_status.main_loop_lock_count,
                        callback_capture_status.pgraph_count,
                        callback_capture_status.scheduler_count,
                        callback_capture_status.guest_timer_count);
        }
        ImGui::TextDisabled(
            "Arms only for InputBuffer-linked D3D schedules whose callback target is 000D7EA0. The event is labeled OVERDUE, not failed, because a late callback may still arrive afterward.");
        ImGui::TextDisabled(
            "When the expected due time passes by 5 ms without 000D7EA0 entry, the watchdog pins timer/lock/scheduler/guest tails without pausing or modifying the guest.");
    }
    if (m_view.IsVisible(DiagnosticSection::LateCapture)) {
        ImGui::Separator();
        ImGui::TextUnformatted("PTIMER Late Callback Capture (pinned one-shot)");
        XemuDiagnosticsPtimerLateCaptureStatus late_capture_status{};
        xemu_diagnostics_get_ptimer_late_capture_status(&late_capture_status);
        bool late_capture_enabled = late_capture_status.enabled != 0;
        if (ImGui::Checkbox("Arm PTIMER >= 5 ms late-callback forensic capture",
                            &late_capture_enabled)) {
            xemu_diagnostics_ptimer_late_capture_set_enabled(
                late_capture_enabled ? 1 : 0);
            xemu_diagnostics_get_ptimer_late_capture_status(&late_capture_status);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear / Re-arm PTIMER Late Capture")) {
            xemu_diagnostics_ptimer_late_capture_clear();
            xemu_diagnostics_get_ptimer_late_capture_status(&late_capture_status);
        }
        ImGui::Text("State                     %s%s",
                    late_capture_status.latched ? "LATCHED" : "armed / waiting",
                    late_capture_status.capture_in_progress ? " (capturing)" : "");
        ImGui::Text("Trigger threshold         %.3f ms",
                    (double)late_capture_status.threshold_ns / 1000000.0);
        if (late_capture_status.latched) {
            ImGui::Text("Trigger virtual / host ns %llu / %llu",
                        (unsigned long long)late_capture_status.trigger_virtual_ns,
                        (unsigned long long)late_capture_status.trigger_host_ns);
            ImGui::Text("Expected expiry ns        %lld",
                        (long long)late_capture_status.trigger_expire_ns);
            ImGui::Text("Dispatch lateness         %.3f ms",
                        (double)late_capture_status.trigger_late_ns / 1000000.0);
            ImGui::Text("Capture copy duration     %.3f ms",
                        (double)late_capture_status.capture_duration_host_ns / 1000000.0);
            ImGui::Text("Pinned tails Q/B/ML/P/S/G %zu / %zu / %zu / %zu / %zu / %zu",
                        late_capture_status.qtimer_count,
                        late_capture_status.bql_count,
                        late_capture_status.main_loop_lock_count,
                        late_capture_status.pgraph_count,
                        late_capture_status.scheduler_count,
                        late_capture_status.guest_timer_count);
            ImGui::Text("BQL owner at capture      TID %d CPU %d held %.3f ms",
                        late_capture_status.bql_status.current_owner_thread_id,
                        late_capture_status.bql_status.current_owner_cpu_index,
                        (double)late_capture_status.bql_status.current_owner_held_ns / 1000000.0);
            ImGui::Text("PGRAPH owner at capture   TID %d CPU %d held %.3f ms",
                        late_capture_status.pgraph_status.current_owner_thread_id,
                        late_capture_status.pgraph_status.current_owner_cpu_index,
                        (double)late_capture_status.pgraph_status.current_owner_held_ns / 1000000.0);
            const std::string last_title_pc =
                FormatGuestPc(late_capture_status.scheduler_status.last_title_pc);
            ImGui::Text("Scheduler last title PC   %s", last_title_pc.c_str());
        }
        ImGui::TextDisabled(
            "The first watched PTIMER dispatch >= 5 ms late is copied into a fixed pinned snapshot. It remains available even if normal diagnostic rings later wrap.");
        ImGui::TextDisabled(
            "Arming enables the generic QEMU-timer/BQL/main-loop-lock/PGRAPH/scheduler source recorders. Guest Timer/Deadline is included only if separately enabled.");
    }
    if (m_view.IsVisible(DiagnosticSection::D3dTimerState)) {
        ImGui::Separator();
        ImGui::TextUnformatted("D3D Timer Record / List State Trace");
        XemuDiagnosticsD3dTimerStateStatus timer_state{};
        xemu_diagnostics_get_d3d_timer_state_trace_status(&timer_state);
        ImGui::Text("Recording                 %s", timer_state.enabled ? "on" : "off");
        ImGui::Text("Buffered / total / overwritten %zu / %llu / %llu",
                    timer_state.count, (unsigned long long)timer_state.total_events,
                    (unsigned long long)timer_state.overwritten_events);
        ImGui::Text("Timer object              %08X", timer_state.current_timer_object);
        ImGui::Text("Input / D3D sequence      %llu / %llu",
                    (unsigned long long)timer_state.current_input_sequence,
                    (unsigned long long)timer_state.current_deadline_sequence);
        ImGui::Text("Exact probes / cap        %u / %u",
                    timer_state.current_probe_count, timer_state.max_probes_per_cycle);
        ImGui::Text("Schedule / last-good baseline %d / %d",
                    timer_state.schedule_snapshot_valid, timer_state.last_good_snapshot_valid);
        ImGui::Text("Good / overdue / rejected %llu / %llu / %llu",
                    (unsigned long long)timer_state.completed_good_cycles,
                    (unsigned long long)timer_state.overdue_cycles,
                    (unsigned long long)timer_state.rejected_cycles);
        ImGui::TextDisabled("Recording is linked to Guest Timer / Deadline Correlation; this panel only displays retained status.");
    }
}

void DiagnosticsWindow::DrawAudio()
{
    if (!m_device.apu_available) {
        ImGui::TextDisabled("MCPX APU debug information is not initialized.");
        return;
    }

    if (m_view.IsVisible(DiagnosticSection::AudioMetrics)) {
        ImGui::Text("Frames processed          %d", m_device.apu_frames_processed);
        ImGui::Text("Utilization               %.2f%%", m_device.apu_utilization * 100.0f);
        ImGui::Text("Active voices             %d", m_device.apu_active_voices);
        ImGui::Text("Voice worker time         %d us", m_device.apu_worker_time_us);
        ImGui::Text("GP / EP DSP cycles        %d / %d",
                    m_device.apu_gp_cycles, m_device.apu_ep_cycles);
        ImGui::Text("GP / EP realtime          %s / %s",
                    m_device.apu_gp_realtime ? "Yes" : "No",
                    m_device.apu_ep_realtime ? "Yes" : "No");
    }
    if (m_view.IsVisible(DiagnosticSection::AudioPacing)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Frame Pacing");
        ImGui::Text("Deviation min/avg/max     %lld / %lld / %lld us",
                    (long long)m_device.apu_deviation_min_us,
                    (long long)m_device.apu_deviation_avg_us,
                    (long long)m_device.apu_deviation_max_us);
        ImGui::Text("Queue latency min/avg/max %.3f / %.3f / %.3f ms",
                    m_device.apu_latency_min_ms,
                    m_device.apu_latency_avg_ms,
                    m_device.apu_latency_max_ms);
        ImGui::Text("Queue low/high thresholds %.3f / %.3f ms",
                    m_device.apu_latency_low_ms,
                    m_device.apu_latency_high_ms);
    }
    if (m_view.IsVisible(DiagnosticSection::AvSync)) {
        ImGui::Separator();
        ImGui::TextUnformatted("Audio / Video Sync Trace");
        ImGui::TextDisabled("Cadence is not dialogue/animation sync. Start recording before the cutscene.");
        if (ImGui::Button("Mark cutscene start")) {
            m_status = xemu_debug_tools_av_sync_trace_mark(XEMU_DEBUG_TOOLS_AV_MARK_CUTSCENE_START)
                ? "A/V observation marker recorded."
                : "Enable Record A/V cadence before adding a marker.";
        }
        ImGui::SameLine();
        if (ImGui::Button("Mark sound ahead")) {
            m_status = xemu_debug_tools_av_sync_trace_mark(XEMU_DEBUG_TOOLS_AV_MARK_SOUND_AHEAD)
                ? "A/V observation marker recorded."
                : "Enable Record A/V cadence before adding a marker.";
        }
        ImGui::SameLine();
        if (ImGui::Button("Mark scene end")) {
            m_status = xemu_debug_tools_av_sync_trace_mark(XEMU_DEBUG_TOOLS_AV_MARK_SCENE_END)
                ? "A/V observation marker recorded."
                : "Enable Record A/V cadence before adding a marker.";
        }
        ImGui::TextDisabled("Markers are user observations at button-press time, not an automatic lip-sync measurement.");

        XemuDiagnosticsAvSyncTraceStatus av_sync{};
        xemu_diagnostics_get_av_sync_trace_status(&av_sync);
        bool av_sync_enabled = av_sync.enabled != 0;
        if (ImGui::Checkbox("Record A/V cadence", &av_sync_enabled)) {
            xemu_diagnostics_av_sync_trace_set_enabled(av_sync_enabled ? 1 : 0);
            xemu_diagnostics_get_av_sync_trace_status(&av_sync);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear A/V Sync Trace")) {
            xemu_diagnostics_av_sync_trace_clear();
            xemu_diagnostics_get_av_sync_trace_status(&av_sync);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("buffer %zu",
                            DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_AV_SYNC));

        ImGui::Text("Audio batches / samples    %llu / %llu",
                    (unsigned long long)av_sync.audio_batches,
                    (unsigned long long)av_sync.audio_samples);
        ImGui::Text("Video VBlank ticks         %llu",
                    (unsigned long long)av_sync.video_vblanks);
        ImGui::Text("PGRAPH FLIP_STALL frames   %llu (frame_time %u)",
                    (unsigned long long)av_sync.pgraph_flips,
                    av_sync.last_pgraph_frame_time);
        if (av_sync.pgraph_ready) {
            ImGui::Text("Last PGRAPH flip gap       %s virtual / %s host",
                        FormatDurationNs(av_sync.last_pgraph_virtual_interval_ns).c_str(),
                        FormatDurationNs(av_sync.last_pgraph_host_interval_ns).c_str());
            ImGui::Text("Last flip VBlanks / audio  %u / %.3f ms (%llu samples)",
                        av_sync.last_pgraph_vblank_delta,
                        (double)av_sync.last_pgraph_audio_sample_delta * 1000.0 / 48000.0,
                        (unsigned long long)av_sync.last_pgraph_audio_sample_delta);
            ImGui::Text("Worst PGRAPH flip gap      %s virtual / %u VBlanks",
                        FormatDurationNs(av_sync.max_pgraph_virtual_interval_ns).c_str(),
                        av_sync.max_pgraph_vblank_delta);
            ImGui::Text("Since last PGRAPH flip     age %s | audio +%s | VBlank +%s",
                        FormatDurationNs(av_sync.pgraph_virtual_age_ns).c_str(),
                        FormatDurationNs(av_sync.audio_since_pgraph_ns).c_str(),
                        FormatDurationNs(av_sync.vblank_since_pgraph_ns).c_str());
        } else {
            ImGui::TextDisabled(
                "PGRAPH flip cadence warming up: waiting for two FLIP_STALL boundaries.");
        }

        if (m_view.IsVisible(DiagnosticSection::FlipDelay)) {
            XemuDiagnosticsPgraphFlipDelayStatus flip_delay_summary{};
            xemu_diagnostics_get_pgraph_flip_delay_trace_status(&flip_delay_summary);
            if (flip_delay_summary.enabled) {
                ImGui::Text("PGRAPH delay capture       %llu long frames | worst %s",
                            (unsigned long long)flip_delay_summary.captured_long_frames,
                            FormatDurationNs(
                                (int64_t)flip_delay_summary.worst_frame_ns).c_str());
                ImGui::TextDisabled(
                    "Detailed stage breakdown: NV2A / PTIMER -> PGRAPH Flip Delay Breakdown.");
            }
        }
        if (av_sync.last_audio_queue_bytes >= 0) {
            ImGui::Text("Last audio queue           %.3f ms (%d bytes)",
                        (double)av_sync.last_audio_queue_bytes / kAudioBytesPerMs,
                        av_sync.last_audio_queue_bytes);
        } else {
            ImGui::TextDisabled("Last audio queue           <unavailable>");
        }
        if (av_sync.ready) {
            ImGui::Text("Audio host drift           %s",
                        FormatDurationNs(av_sync.audio_host_drift_ns).c_str());
            ImGui::Text("Video host drift           %s",
                        FormatDurationNs(av_sync.video_host_drift_ns).c_str());
            ImGui::Text("A/V host cadence drift     %s",
                        FormatDurationNs(av_sync.av_host_drift_ns).c_str());
            ImGui::Text("A/V virtual cadence drift  %s",
                        FormatDurationNs(av_sync.av_virtual_drift_ns).c_str());
            ImGui::TextDisabled(
                "Positive A/V drift = audio cadence has advanced faster than VBlank; negative = audio cadence is behind.");
        } else {
            ImGui::TextDisabled(
                "A/V drift warming up: record at least two audio batches and two VBlank ticks.");
        }
        ImGui::TextDisabled(
            "Audio events are 256-sample submissions at 48 kHz. VBlank is the UI/display cadence; PGRAPH_FLIP is the guest FLIP_STALL frame boundary used by the GPU frame counter.");
        ImGui::TextDisabled(
            "A growing PGRAPH age with continuing audio/VBlank progress identifies the rendered game side as the lagging clock. No target FPS is assumed.");

        if (av_sync.count != 0) {
            constexpr size_t kDisplayAvSyncEvents = 96;
            std::array<XemuDiagnosticsAvSyncTraceEvent, kDisplayAvSyncEvents> trace{};
            const size_t count = xemu_diagnostics_get_av_sync_trace(
                trace.data(), trace.size());
            if (ImGui::BeginTable("av_sync_trace", 16,
                                  ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_ScrollY |
                                      ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_Resizable,
                                  ImVec2(0.0f, 230.0f))) {
                ImGui::TableSetupColumn("Seq");
                ImGui::TableSetupColumn("Event");
                ImGui::TableSetupColumn("Virtual ns");
                ImGui::TableSetupColumn("Host ns");
                ImGui::TableSetupColumn("Audio samples");
                ImGui::TableSetupColumn("VBlanks");
                ImGui::TableSetupColumn("PGRAPH flips");
                ImGui::TableSetupColumn("Flip gap ms");
                ImGui::TableSetupColumn("Flip VBlanks");
                ImGui::TableSetupColumn("Audio since flip ms");
                ImGui::TableSetupColumn("VBlank since flip ms");
                ImGui::TableSetupColumn("Queue ms");
                ImGui::TableSetupColumn("Audio host");
                ImGui::TableSetupColumn("Video host");
                ImGui::TableSetupColumn("A/V host");
                ImGui::TableSetupColumn("A/V virtual");
                ImGui::TableHeadersRow();
                for (size_t i = 0; i < count; ++i) {
                    const auto &event = trace[i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)event.sequence);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextUnformatted(AvSyncEventName(event.event_type));
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%llu", (unsigned long long)event.qemu_virtual_ns);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("%llu", (unsigned long long)event.host_ns);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%llu", (unsigned long long)event.audio_samples);
                    ImGui::TableSetColumnIndex(5);
                    ImGui::Text("%llu", (unsigned long long)event.video_vblanks);
                    ImGui::TableSetColumnIndex(6);
                    ImGui::Text("%llu", (unsigned long long)event.pgraph_flips);
                    ImGui::TableSetColumnIndex(7);
                    if (event.pgraph_ready) {
                        ImGui::Text("%.3f",
                                    (double)event.pgraph_last_virtual_interval_ns / 1000000.0);
                    } else {
                        ImGui::TextUnformatted("<warm>");
                    }
                    ImGui::TableSetColumnIndex(8);
                    ImGui::Text("%u", event.pgraph_last_vblank_delta);
                    ImGui::TableSetColumnIndex(9);
                    ImGui::Text("%.3f",
                                (double)event.audio_since_pgraph_ns / 1000000.0);
                    ImGui::TableSetColumnIndex(10);
                    ImGui::Text("%.3f",
                                (double)event.vblank_since_pgraph_ns / 1000000.0);
                    ImGui::TableSetColumnIndex(11);
                    if (event.audio_queue_bytes >= 0) {
                        ImGui::Text("%.3f",
                                    (double)event.audio_queue_bytes / kAudioBytesPerMs);
                    } else {
                        ImGui::TextUnformatted("-");
                    }
                    ImGui::TableSetColumnIndex(12);
                    ImGui::TextUnformatted(
                        event.ready ? FormatDurationNs(event.audio_host_drift_ns).c_str()
                                    : "<warm>");
                    ImGui::TableSetColumnIndex(13);
                    ImGui::TextUnformatted(
                        event.ready ? FormatDurationNs(event.video_host_drift_ns).c_str()
                                    : "<warm>");
                    ImGui::TableSetColumnIndex(14);
                    ImGui::TextUnformatted(
                        event.ready ? FormatDurationNs(event.av_host_drift_ns).c_str()
                                    : "<warm>");
                    ImGui::TableSetColumnIndex(15);
                    ImGui::TextUnformatted(
                        event.ready ? FormatDurationNs(event.av_virtual_drift_ns).c_str()
                                    : "<warm>");
                }
                ImGui::EndTable();
            }
        }
    }
}

void DiagnosticsWindow::DrawWatches()
{
    static const char *types[] = {
        "U8", "U16", "U32", "U64", "S32", "Float32", "Float64"
    };

    if (ImGui::Button("Add Watch")) {
        CustomWatch watch;
        std::snprintf(watch.name.data(), watch.name.size(), "Watch %zu",
                      m_watches.size() + 1);
        watch.last_change_ms = SDL_GetTicks();
        m_watches.push_back(watch);
    }
    ImGui::SameLine();
    ImGui::TextDisabled(
        "RAM-only. Editing Space, Address, or Type disables the watch; "
        "enable it after entry.");

    if (ImGui::BeginTable("diagnostics_watches", 10,
                          ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                          ImGuiTableFlags_Resizable | ImGuiTableFlags_ScrollY |
                          ImGuiTableFlags_ScrollX,
                          ImVec2(0, -1))) {
        ImGui::TableSetupColumn("Name");
        ImGui::TableSetupColumn("Active", ImGuiTableColumnFlags_WidthFixed,
                                62.0f);
        ImGui::TableSetupColumn("Space", ImGuiTableColumnFlags_WidthFixed,
                                72.0f);
        ImGui::TableSetupColumn("Address", ImGuiTableColumnFlags_WidthFixed,
                                110.0f);
        ImGui::TableSetupColumn("Resolved P", ImGuiTableColumnFlags_WidthFixed,
                                105.0f);
        ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthFixed,
                                92.0f);
        ImGui::TableSetupColumn("Value");
        ImGui::TableSetupColumn("Warn unchanged",
                                ImGuiTableColumnFlags_WidthFixed, 110.0f);
        ImGui::TableSetupColumn("Unchanged ms",
                                ImGuiTableColumnFlags_WidthFixed, 105.0f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 60.0f);
        ImGui::TableHeadersRow();

        for (size_t i = 0; i < m_watches.size();) {
            CustomWatch &watch = m_watches[i];
            bool remove = false;
            ImGui::PushID((int)i);
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##name", watch.name.data(), watch.name.size());

            ImGui::TableNextColumn();
            if (ImGui::Checkbox("##active", &watch.enabled)) {
                watch.valid = false;
                watch.physical_valid = false;
                watch.warning_active = false;
                watch.last_change_ms = SDL_GetTicks();
            }

            ImGui::TableNextColumn();
            int space = watch.virtual_address ? 0 : 1;
            ImGui::SetNextItemWidth(-1);
            if (ImGui::Combo("##space", &space, "Virtual\0Physical\0")) {
                watch.virtual_address = space == 0;
                watch.enabled = false;
                watch.valid = false;
                watch.physical_valid = false;
                watch.warning_active = false;
            }

            ImGui::TableNextColumn();
            ImGui::SetNextItemWidth(-1);
            if (ImGui::InputScalar("##address", ImGuiDataType_U32,
                                   &watch.address, nullptr, nullptr, "%08X",
                                   ImGuiInputTextFlags_CharsHexadecimal)) {
                watch.enabled = false;
                watch.valid = false;
                watch.physical_valid = false;
                watch.warning_active = false;
            }

            ImGui::TableNextColumn();
            if (watch.enabled && watch.physical_valid) {
                ImGui::Text("%08llX",
                            (unsigned long long)watch.physical_address);
            } else {
                ImGui::TextDisabled("-");
            }

            ImGui::TableNextColumn();
            int type = (int)watch.type;
            ImGui::SetNextItemWidth(-1);
            if (ImGui::Combo("##type", &type, types, IM_ARRAYSIZE(types))) {
                watch.type = (WatchType)type;
                watch.enabled = false;
                watch.valid = false;
                watch.physical_valid = false;
                watch.warning_active = false;
            }

            ImGui::TableNextColumn();
            const std::string value = FormatWatchValue(watch);
            if (watch.warning_active) {
                ImGui::TextColored(ImVec4(1.0f, 0.55f, 0.2f, 1.0f),
                                   "%s", value.c_str());
            } else {
                ImGui::TextUnformatted(value.c_str());
            }

            ImGui::TableNextColumn();
            ImGui::Checkbox("##warn", &watch.warn_if_unchanged);

            ImGui::TableNextColumn();
            ImGui::SetNextItemWidth(-1);
            ImGui::InputScalar("##unchanged", ImGuiDataType_U32,
                               &watch.unchanged_warning_ms);
            watch.unchanged_warning_ms =
                std::clamp(watch.unchanged_warning_ms, 100u, 600000u);

            ImGui::TableNextColumn();
            if (ImGui::Button("Remove")) {
                remove = true;
            }
            ImGui::PopID();

            if (remove) {
                m_watches.erase(m_watches.begin() + i);
            } else {
                ++i;
            }
        }
        ImGui::EndTable();
    }
}

void DiagnosticsWindow::DrawHistory()
{
    if (ImGui::Button(m_pause_history ? "Resume History" : "Pause History")) {
        m_pause_history = !m_pause_history;
    }
    ImGui::SameLine();
    if (ImGui::Button("Clear History")) {
        m_events.clear();
        m_session_start_ms = SDL_GetTicks();
    }
    ImGui::SameLine();
    ImGui::TextDisabled("Rolling history keeps the newest %zu events.",
                        kBaseMaxEvents * (size_t)std::max(1u, m_recent_events_multiplier));

    if (ImGui::BeginTable("diagnostics_history", 3,
                          ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                          ImGuiTableFlags_ScrollY,
                          ImVec2(0, -1))) {
        ImGui::TableSetupColumn("Time", ImGuiTableColumnFlags_WidthFixed, 90.0f);
        ImGui::TableSetupColumn("Category", ImGuiTableColumnFlags_WidthFixed, 90.0f);
        ImGui::TableSetupColumn("Event");
        ImGui::TableHeadersRow();
        for (const EventRow &event : m_events) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::Text("%8.3f", (double)event.elapsed_ms / 1000.0);
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(event.category.c_str());
            ImGui::TableNextColumn();
            ImGui::TextWrapped("%s", event.text.c_str());
        }
        ImGui::EndTable();
    }
}

std::string DiagnosticsWindow::BuildSnapshotText() const
{
    std::ostringstream os;
    const auto &game = current_game_manager.Get();

    os << "XEMU Diagnostics Snapshot v3.14ab\n";
    os << "========================================\n";
    if (game.valid) {
        os << "Game: " << game.title_name << "\n";
        os << "Title ID: " << CurrentGameManager::FormatTitleId(game.title_id) << "\n";
        os << "Version: " << std::hex << std::uppercase << std::setw(8)
           << std::setfill('0') << game.version << std::dec << "\n";
        os << "XBE Identity SHA-256: " << game.header_sha256 << "\n";
        os << "XBE Raw Header SHA-256: " << game.raw_header_sha256 << "\n";
        os << "XBE Disc SHA-256: " << game.disc_xbe_sha256 << "\n";
    } else {
        os << "Game: <not detected>\n";
    }
    if (m_view.IsVisible(DiagnosticSection::Overview)) {
    os << "Accelerator: " << BackendName() << "\n";
    os << "Guest running: " << (m_timing.running ? "yes" : "no") << "\n";
    os << "CPU halted: " << (m_timing.halted ? "yes" : "no") << "\n";
    os << "CPU exception_index: " << m_timing.exception_index << "\n";
    os << "CPU interrupt_request: 0x" << std::hex << std::uppercase
       << m_timing.interrupt_request << std::dec << "\n";
    os << "Samples: " << m_sample_count << "\n";
    }
    if (m_view.IsVisible(DiagnosticSection::CurrentGame)) {
    os << "Guest-PC label database: "
       << current_game_manager.Labels().labels.size() << " labels; generation "
       << current_game_manager.LabelGeneration() << "\n";
    const auto &xdk_label_status = current_game_manager.XdkStatus();
    os << "XDK label status: build " << xdk_label_status.build
       << "; exact matches " << xdk_label_status.exact_matches
       << "; cache loaded " << (xdk_label_status.cache_loaded ? "yes" : "no")
       << "\n\n";

    }
    if (m_view.IsVisible(DiagnosticSection::Overview)) {
    os << "Diagnostics Buffer Sizes\n----------------------------------------\n";
    for (int i = 0; i < XEMU_DIAG_BUFFER_COUNT; ++i) {
        XemuDiagnosticsBufferInfo info{};
        const auto id = (XemuDiagnosticsBufferId)i;
        if (xemu_diagnostics_buffer_get_info(id, &info)) {
            os << DiagnosticsBufferName(id) << ": " << info.multiplier << "x ("
               << info.capacity << " events; base " << info.base_capacity << ")\n";
        }
    }
    os << "Recent Events: " << m_recent_events_multiplier << "x ("
       << (kBaseMaxEvents * (size_t)std::max(1u, m_recent_events_multiplier))
       << " events; base " << kBaseMaxEvents << ")\n\n";

    }
    if (m_view.IsVisible(DiagnosticSection::Background)) {
    os << "Debug Tools Background Work\n----------------------------------------\n";
    os << "Worker: "
       << (debug_tools_background_worker_is_running() ? "running" : "unavailable")
       << "\n";
    os << "Queued jobs: " << debug_tools_background_worker_pending_jobs() << "\n";
    os << "External input lease: "
       << (debug_tools_external_input_lease_active() ? "active" : "off") << "\n";
    os << "Open Snapshots Folder pending: "
       << (m_open_snapshots_folder_requested ? "yes" : "no") << "\n";
    os << "Open Snapshots Folder status: " << m_snapshots_folder_status << "\n\n";

    }
    if (m_view.Any(XemuDiagnosticsView::Group::Cpu)) {
        os << "CPU / Timing\n----------------------------------------\n";
        if (m_view.IsVisible(DiagnosticSection::Registers) && m_regs_valid) {
            os << std::hex << std::uppercase << std::setfill('0');
            os << "EAX " << std::setw(8) << m_regs.eax << "  EBX " << std::setw(8) << m_regs.ebx << "\n";
            os << "ECX " << std::setw(8) << m_regs.ecx << "  EDX " << std::setw(8) << m_regs.edx << "\n";
            os << "ESI " << std::setw(8) << m_regs.esi << "  EDI " << std::setw(8) << m_regs.edi << "\n";
            os << "ESP " << std::setw(8) << m_regs.esp << "  EBP " << std::setw(8) << m_regs.ebp << "\n";
            os << "EIP " << std::setw(8) << m_regs.eip << "  PC  " << std::setw(8) << m_regs.pc << "\n";
            os << "EFLAGS " << std::setw(8) << m_regs.eflags << "  CR3 " << std::setw(8) << m_regs.cr3 << "\n";
            os << std::dec;
            const std::string eip_label = FormatGuestPcLabel(m_regs.eip);
            const std::string pc_label = FormatGuestPcLabel(m_regs.pc);
            if (!eip_label.empty()) {
                os << "EIP label: " << eip_label << "\n";
            }
            if (!pc_label.empty()) {
                os << "PC label: " << pc_label << "\n";
            }
        }
        if (m_view.IsVisible(DiagnosticSection::Stack) && m_stack_valid) {
            os << "Stack at ESP:\n" << std::hex << std::uppercase << std::setfill('0');
            for (size_t i = 0; i < m_stack.size(); i++) {
                os << "  " << std::setw(8) << (m_regs.esp + (uint32_t)(i * 4))
                   << "  " << std::setw(8) << m_stack[i] << "\n";
            }
            os << std::dec;
        }
        if (m_view.IsVisible(DiagnosticSection::Instructions) && m_disasm_count != 0) {
            os << "Disassembly from EIP:\n";
            for (size_t i = 0; i < m_disasm_count; i++) {
                const XemuCheatDisasmRow &row = m_disasm[i];
                os << "  " << std::hex << std::uppercase << std::setw(8)
                   << std::setfill('0') << row.virtual_address << "  "
                   << row.mnemonic << " " << row.operands;
                const std::string row_label =
                    FormatGuestPcLabel(row.virtual_address);
                if (!row_label.empty()) {
                    os << "  ; " << row_label;
                }
                os << "\n";
            }
            os << std::dec;
        }
        if (m_view.IsVisible(DiagnosticSection::Clocks)) {
        os << "Installed Xbox RAM bytes: " << xemu_cheat_ram_size() << "\n";
        os << "QEMU virtual ns: " << m_timing.qemu_virtual_ns << "\n";
        os << "Xbox reference TSC: 0x" << std::hex << std::uppercase
           << m_timing.expected_xbox_tsc << "\n";
        os << "Guest-visible TSC: 0x" << m_timing.actual_tsc << std::dec << "\n";
        os << "QEMU model TSC Hz: " << m_timing.model_tsc_hz << "\n";
        os << "QEMU APIC bus Hz: " << m_timing.apic_bus_hz << "\n";
        os << "WHPX processor Hz: " << m_timing.whpx_processor_clock_hz
           << " (valid=" << m_timing.whpx_processor_clock_valid << ")\n";
        os << "WHPX interrupt Hz: " << m_timing.whpx_interrupt_clock_hz
           << " (valid=" << m_timing.whpx_interrupt_clock_valid << ")\n";
        os << "TSC drift ticks: " << m_tsc_drift_ticks << "\n";
        os << "TSC drift us: " << std::fixed << std::setprecision(3)
           << m_tsc_drift_us << "\n\n";
        }
    }

    if (m_view.IsVisible(DiagnosticSection::InterruptState) ||
        m_view.IsVisible(DiagnosticSection::Ptimer) ||
        m_view.IsVisible(DiagnosticSection::GpuWait)) {
        os << "NV2A / PTIMER\n----------------------------------------\n";
        if (m_device.nv2a_available) {
            if (m_view.IsVisible(DiagnosticSection::InterruptState)) {
            os << std::hex << std::uppercase << std::setfill('0');
            os << "PMC pending/enabled: " << std::setw(8) << m_device.pmc_pending
               << " / " << std::setw(8) << m_device.pmc_enabled << "\n";
            os << "PFIFO pending/enabled: " << std::setw(8) << m_device.pfifo_pending
               << " / " << std::setw(8) << m_device.pfifo_enabled << "\n";
            os << "PGRAPH pending/enabled: " << std::setw(8) << m_device.pgraph_pending
               << " / " << std::setw(8) << m_device.pgraph_enabled << "\n";
            os << "PCRTC pending/enabled: " << std::setw(8) << m_device.pcrtc_pending
               << " / " << std::setw(8) << m_device.pcrtc_enabled << "\n";
            os << "PTIMER pending/enabled: " << std::setw(8) << m_device.ptimer_pending
               << " / " << std::setw(8) << m_device.ptimer_enabled << "\n";
            os << std::dec;
            }
            if (m_view.IsVisible(DiagnosticSection::Ptimer)) {
            os << std::hex << std::uppercase;
            os << "PTIMER now/alarm: 0x" << m_device.ptimer_now << " / 0x"
               << m_device.ptimer_alarm << std::dec << "\n";
            os << "PTIMER alarm delta ns: " << m_device.ptimer_alarm_delta_ns << "\n";
            os << "QEMU PTIMER pending: " << m_device.ptimer_qemu_timer_pending << "\n";
            os << "QEMU PTIMER delta ns: " << m_device.ptimer_qemu_timer_delta_ns << "\n";
            os << "GPU core Hz: " << m_device.gpu_core_clock_hz << "\n";
            }
            if (m_view.IsVisible(DiagnosticSection::GpuWait)) {
            os << "FPS: " << m_device.gpu_fps << "\n";
            os << "GPU frame count: " << m_device.gpu_frame_count << "\n";
            os << "PGRAPH waiting NOP/flip/context: "
               << m_device.pgraph_waiting_for_nop << "/"
               << m_device.pgraph_waiting_for_flip << "/"
               << m_device.pgraph_waiting_for_context_switch << "\n";
            os << "PGRAPH flush/sync pending: " << m_device.pgraph_flush_pending
               << "/" << m_device.pgraph_sync_pending << "\n";
            }
        } else {
            os << "<unavailable>\n";
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::PtimerTrace)) {
        os << "PTIMER Detailed Timing Trace\n----------------------------------------\n";
        XemuDiagnosticsPtimerTraceStatus trace_status{};
        xemu_diagnostics_get_ptimer_trace_status(&trace_status);
        os << "Trace enabled: " << trace_status.enabled << "\n";
        os << "Buffered events: " << trace_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PTIMER) << "\n";
        os << "Total events: " << trace_status.total_events << "\n";
        os << "Overwritten events: " << trace_status.overwritten_events << "\n";
        if (trace_status.count != 0) {
            std::vector<XemuDiagnosticsPtimerTraceEvent> trace(trace_status.count);
            const size_t trace_count =
                xemu_diagnostics_get_ptimer_trace(trace.data(), trace.size());
            os << "Columns: seq qemu_ns host_ns event guest_pc guest_pc_valid "
                  "rdtsc_ref rdtsc_ref_valid ptimer_now alarm alarm_delta_ns "
                  "qtimer_pending qtimer_expire_ns "
                  "qtimer_delta_ns callback_late_ns pending enabled value previous\n";
            os << std::hex << std::uppercase << std::setfill('0');
            for (size_t i = 0; i < trace_count; ++i) {
                const auto &event = trace[i];
                os << std::dec << event.sequence << " "
                   << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << PtimerTraceEventName(event.event_type) << " "
                   << "0x" << std::hex << std::setw(16) << event.guest_pc << " "
                   << std::dec << event.guest_pc_valid << " "
                   << "0x" << std::hex << std::setw(16)
                   << event.rdtsc_reference << " "
                   << std::dec << event.rdtsc_reference_valid << " "
                   << "0x" << std::hex << std::setw(16) << event.ptimer_now << " "
                   << "0x" << std::setw(16) << event.alarm << " "
                   << std::dec << event.alarm_delta_ns << " "
                   << event.qemu_timer_pending << " "
                   << event.qemu_timer_expire_ns << " "
                   << event.qemu_timer_delta_ns << " "
                   << event.callback_lateness_ns << " "
                   << "0x" << std::hex << std::setw(8) << event.pending_interrupts << " "
                   << "0x" << std::setw(8) << event.enabled_interrupts << " "
                   << "0x" << std::setw(8) << event.value << " "
                   << "0x" << std::setw(8) << event.previous_value << "\n";
            }
            os << std::dec;
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::SlowTimer)) {
        os << "Slow QEMU Timer Callback Trace\n----------------------------------------\n";
        XemuDiagnosticsSlowTimerTraceStatus slow_status{};
        xemu_diagnostics_get_slow_timer_trace_status(&slow_status);
        os << "Trace enabled: " << slow_status.enabled << "\n";
        os << "Threshold ms: " << std::fixed << std::setprecision(3)
           << ((double)slow_status.threshold_ns / 1000000.0) << "\n";
        os << "Threshold ns: " << slow_status.threshold_ns << "\n";
        os << "Buffered events: " << slow_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_SLOW_TIMER) << "\n";
        os << "Total events: " << slow_status.total_events << "\n";
        os << "Overwritten events: " << slow_status.overwritten_events << "\n";
        if (slow_status.count != 0) {
            std::vector<XemuDiagnosticsSlowTimerTraceEvent> slow_trace(
                slow_status.count);
            const size_t slow_count = xemu_diagnostics_get_slow_timer_trace(
                slow_trace.data(), slow_trace.size());
            slow_trace.resize(slow_count);
            const XemuDiagnosticsSlowTimerTraceEvent *worst = nullptr;
            for (const auto &event : slow_trace) {
                if (worst == nullptr ||
                    event.host_duration_ns > worst->host_duration_ns) {
                    worst = &event;
                }
            }
            if (worst != nullptr) {
                os << "Worst callback duration ns: "
                   << worst->host_duration_ns << "\n";
                os << "Worst callback address: 0x" << std::hex
                   << std::uppercase << std::setw(16) << std::setfill('0')
                   << worst->callback_address << std::dec << "\n";
                os << "Worst callback name: " << worst->callback_name << "\n";
                os << "Worst callback source: " << worst->source_file;
                if (worst->source_line > 0) {
                    os << ":" << worst->source_line;
                }
                os << "\n";
            }
            os << "Columns: seq timer callback opaque clock tid expiry_ns "
                  "timer_clock_start_ns timer_clock_end_ns dispatch_late_ns "
                  "host_start_ns host_end_ns host_duration_ns virtual_start_ns "
                  "virtual_end_ns virtual_duration_ns threshold_ns bql_before bql_after "
                  "source_line callback_name source_file\n";
            for (const auto &event : slow_trace) {
                os << event.sequence << " "
                   << "0x" << std::hex << std::uppercase << std::setw(16)
                   << std::setfill('0') << event.timer_address << " "
                   << "0x" << std::setw(16) << event.callback_address << " "
                   << "0x" << std::setw(16) << event.opaque_address << " "
                   << std::dec << event.clock_type << " "
                   << event.thread_id << " "
                   << event.scheduled_expire_ns << " "
                   << event.timer_clock_start_ns << " "
                   << event.timer_clock_end_ns << " "
                   << event.dispatch_late_ns << " "
                   << event.host_start_ns << " "
                   << event.host_end_ns << " "
                   << event.host_duration_ns << " "
                   << event.virtual_start_ns << " "
                   << event.virtual_end_ns << " "
                   << event.virtual_duration_ns << " "
                   << event.threshold_ns << " "
                   << event.bql_held_before << " "
                   << event.bql_held_after << " "
                   << event.source_line << " \"" << event.callback_name << "\" \""
                   << event.source_file << "\"\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Ohci)) {
        os << "OHCI Slow Frame Stage Trace\n----------------------------------------\n";
        XemuDiagnosticsOhciSlowFrameStatus ohci_status{};
        xemu_diagnostics_get_ohci_slow_frame_trace_status(&ohci_status);
        os << "Trace enabled: " << ohci_status.enabled << "\n";
        os << "Threshold ms: " << std::fixed << std::setprecision(3)
           << ((double)ohci_status.threshold_ns / 1000000.0) << "\n";
        os << "Threshold ns: " << ohci_status.threshold_ns << "\n";
        os << "Buffered events: " << ohci_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME) << "\n";
        os << "Total events: " << ohci_status.total_events << "\n";
        os << "Overwritten events: " << ohci_status.overwritten_events << "\n";
        if (ohci_status.count != 0) {
            std::vector<XemuDiagnosticsOhciSlowFrameEvent> trace(
                ohci_status.count);
            const size_t count = xemu_diagnostics_get_ohci_slow_frame_trace(
                trace.data(), trace.size());
            trace.resize(count);
            const XemuDiagnosticsOhciSlowFrameEvent *worst = nullptr;
            for (const auto &event : trace) {
                if (worst == nullptr ||
                    event.host_duration_ns > worst->host_duration_ns) {
                    worst = &event;
                }
            }
            if (worst != nullptr) {
                os << "Worst frame duration ns: " << worst->host_duration_ns << "\n";
                os << "Worst frame number: " << worst->frame_number << "\n";
                os << "Worst leaf: " << OhciListKindName(worst->worst_list_kind)
                   << " " << OhciLeafOperationName(worst->worst_leaf_type)
                   << " " << worst->worst_leaf_ns << " ns"
                   << " ED=0x" << std::hex << std::uppercase
                   << std::setw(8) << std::setfill('0') << worst->worst_ed_address
                   << " TD=0x" << std::setw(8) << worst->worst_td_address
                   << std::dec << "\n";
            }
            os << "Columns: seq frame host_start_ns host_end_ns host_duration_ns "
                  "virtual_start_ns virtual_end_ns virtual_duration_ns threshold_ns "
                  "hcca_read_ns periodic_ns stop_endpoints_ns control_ns bulk_ns "
                  "done_sof_ns hcca_write_ns ed_read_ns ed_write_ns td_read_ns "
                  "td_write_ns dma_to_ns device_lookup_ns usb_packet_ns dma_from_ns "
                  "async_flush_ns endpoint_stop_ns iso_td_ns ed_count td_count "
                  "iso_count usb_packets dma_to_count dma_from_count worst_leaf_ns "
                  "worst_leaf worst_list worst_ed worst_td dir pid packet_status "
                  "function_address endpoint packet_length ctl status hcca tid bql\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.frame_number << " "
                   << event.host_start_ns << " " << event.host_end_ns << " "
                   << event.host_duration_ns << " " << event.virtual_start_ns << " "
                   << event.virtual_end_ns << " " << event.virtual_duration_ns << " "
                   << event.threshold_ns << " " << event.hcca_read_ns << " "
                   << event.periodic_list_ns << " " << event.stop_endpoints_ns << " "
                   << event.control_list_ns << " " << event.bulk_list_ns << " "
                   << event.done_sof_ns << " " << event.hcca_write_ns << " "
                   << event.ed_read_ns << " " << event.ed_write_ns << " "
                   << event.td_read_ns << " " << event.td_write_ns << " "
                   << event.dma_to_device_ns << " " << event.device_lookup_ns << " "
                   << event.usb_handle_packet_ns << " " << event.dma_from_device_ns << " "
                   << event.async_flush_ns << " " << event.endpoint_stop_ns << " "
                   << event.iso_td_ns << " " << event.ed_count << " "
                   << event.td_count << " " << event.iso_td_count << " "
                   << event.usb_packet_count << " " << event.dma_to_device_count << " "
                   << event.dma_from_device_count << " " << event.worst_leaf_ns << " "
                   << OhciLeafOperationName(event.worst_leaf_type) << " "
                   << OhciListKindName(event.worst_list_kind) << " "
                   << "0x" << std::hex << std::uppercase << std::setw(8)
                   << std::setfill('0') << event.worst_ed_address << " "
                   << "0x" << std::setw(8) << event.worst_td_address << std::dec << " "
                   << event.worst_direction << " " << event.worst_pid << " "
                   << event.worst_packet_status << " "
                   << event.worst_function_address << " " << event.worst_endpoint << " "
                   << event.worst_packet_length << " "
                   << "0x" << std::hex << std::uppercase << std::setw(8)
                   << event.ctl << " " << "0x" << std::setw(8) << event.status << " "
                   << "0x" << std::setw(8) << event.hcca << std::dec << " "
                   << event.thread_id << " " << event.bql_held << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::InputPoll)) {
        os << "Controller Input Poll Stage Trace\n----------------------------------------\n";
        XemuDiagnosticsControllerInputPollStatus input_status{};
        xemu_diagnostics_get_controller_input_poll_trace_status(&input_status);
        os << "Trace enabled: " << input_status.enabled << "\n";
        os << "Threshold ms: " << std::fixed << std::setprecision(3)
           << ((double)input_status.threshold_ns / 1000000.0) << "\n";
        os << "Threshold ns: " << input_status.threshold_ns << "\n";
        os << "Buffered events: " << input_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL) << "\n";
        os << "Total events: " << input_status.total_events << "\n";
        os << "Overwritten events: " << input_status.overwritten_events << "\n";
        if (input_status.count != 0) {
            std::vector<XemuDiagnosticsControllerInputPollEvent> trace(
                input_status.count);
            const size_t count = xemu_diagnostics_get_controller_input_poll_trace(
                trace.data(), trace.size());
            trace.resize(count);
            const XemuDiagnosticsControllerInputPollEvent *worst = nullptr;
            for (const auto &event : trace) {
                if (worst == nullptr ||
                    event.host_duration_ns > worst->host_duration_ns) {
                    worst = &event;
                }
            }
            if (worst != nullptr) {
                os << "Worst poll duration ns: " << worst->host_duration_ns << "\n";
                os << "Worst poll update_input ns: " << worst->update_input_ns << "\n";
                os << "Worst poll update_controller ns: "
                   << worst->update_controller_ns << "\n";
                os << "Worst poll SDL controller state ns: "
                   << worst->sdl_controller_state_ns << "\n";
                os << "Worst SDL getter: "
                   << ControllerInputGetterName(worst->worst_getter) << " "
                   << worst->worst_getter_ns << " ns\n";
            }
            os << "Columns: seq host_start_ns host_end_ns host_duration_ns "
                  "virtual_start_ns virtual_end_ns virtual_duration_ns threshold_ns "
                  "interrupt_trace_ns update_input_ns get_bound_ns update_controller_ns "
                  "update_gate_ns sdl_state_ns xid_mapping_ns host_trace_ns "
                  "xid_trace_ns usb_copy_ns packet_trace_ns button_getters_ns "
                  "axis_getters_ns worst_getter_ns worst_getter button_count axis_count "
                  "device_index pid endpoint requested_length packet_status actual_length "
                  "sdl_id controller_type connected update_performed skipped_disconnected "
                  "skipped_interval tid bql_before bql_after\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.host_start_ns << " "
                   << event.host_end_ns << " " << event.host_duration_ns << " "
                   << event.virtual_start_ns << " " << event.virtual_end_ns << " "
                   << event.virtual_duration_ns << " " << event.threshold_ns << " "
                   << event.interrupt_trace_ns << " " << event.update_input_ns << " "
                   << event.get_bound_ns << " " << event.update_controller_ns << " "
                   << event.update_gate_ns << " "
                   << event.sdl_controller_state_ns << " "
                   << event.input_mapping_ns << " " << event.host_state_trace_ns << " "
                   << event.xid_state_trace_ns << " " << event.usb_packet_copy_ns << " "
                   << event.packet_complete_trace_ns << " "
                   << event.sdl_button_getters_ns << " "
                   << event.sdl_axis_getters_ns << " " << event.worst_getter_ns << " "
                   << ControllerInputGetterName(event.worst_getter) << " "
                   << event.button_getter_count << " " << event.axis_getter_count << " "
                   << event.device_index << " " << event.pid << " " << event.endpoint << " "
                   << event.requested_length << " " << event.packet_status << " "
                   << event.actual_length << " " << event.sdl_joystick_id << " "
                   << event.controller_type << " " << event.connected << " "
                   << event.update_performed << " "
                   << event.update_skipped_disconnected << " "
                   << event.update_skipped_interval << " " << event.thread_id << " "
                   << event.bql_held_before << " " << event.bql_held_after << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Increment)) {
        os << "PGRAPH Increment Stage Trace\n----------------------------------------\n";
        XemuDiagnosticsLatencyTraceStatus status{};
        xemu_diagnostics_get_pgraph_increment_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\nThreshold ms: "
           << std::fixed << std::setprecision(3)
           << ((double)status.threshold_ns / 1000000.0)
           << "\nThreshold ns: " << status.threshold_ns
           << "\nBuffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_INCREMENT)
           << "\nTotal events: " << status.total_events
           << "\nOverwritten events: " << status.overwritten_events << "\n";
        if (status.count) {
            std::vector<XemuDiagnosticsPgraphIncrementEvent> ev(status.count);
            size_t n =
                xemu_diagnostics_get_pgraph_increment_trace(ev.data(), ev.size());
            ev.resize(n);
            const XemuDiagnosticsPgraphIncrementEvent *worst = nullptr;
            for (const auto &e : ev)
                if (!worst || e.host_duration_ns > worst->host_duration_ns)
                    worst = &e;
            if (worst) {
                os << "Worst total ns: " << worst->host_duration_ns
                   << "\nWorst surface lock wait ns: "
                   << worst->surface_lock_wait_ns
                   << "\nWorst surface update ns: " << worst->surface_update_ns
                   << "\nWorst PFIFO kick ns: " << worst->pfifo_kick_ns
                   << "\nWorst BQL reacquire ns: " << worst->bql_reacquire_wait_ns
                   << "\n";
            }
            os << "Columns: seq host_start_ns host_end_ns host_duration_ns virtual_start_ns virtual_end_ns virtual_duration_ns threshold_ns bql_release_ns surface_lock_wait_ns surface_update_ns pfifo_kick_ns bql_reacquire_ns value surface_before surface_after read_before read_after modulo tid had_bql bql_after\n";
            for (const auto &e : ev) {
                os << e.sequence << " " << e.host_start_ns << " " << e.host_end_ns
                   << " " << e.host_duration_ns << " " << e.virtual_start_ns << " "
                   << e.virtual_end_ns << " " << e.virtual_duration_ns << " "
                   << e.threshold_ns << " " << e.bql_release_ns << " "
                   << e.surface_lock_wait_ns << " " << e.surface_update_ns << " "
                   << e.pfifo_kick_ns << " " << e.bql_reacquire_wait_ns << " 0x"
                   << std::hex << std::uppercase << e.value << " 0x"
                   << e.surface_before << " 0x" << e.surface_after << std::dec << " "
                   << e.read_before << " " << e.read_after << " " << e.modulo << " "
                   << e.thread_id << " " << e.had_bql << " " << e.bql_held_after
                   << "\n";
            }
        }
        os << "\n";
    }
    if (m_view.IsVisible(DiagnosticSection::FlipStall)) {
        os << "FLIP_STALL / VBlank Trace\n----------------------------------------\n";
        XemuDiagnosticsFlipStallStatus status{};
        xemu_diagnostics_get_flip_stall_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_FLIP_STALL) << "\n";
        os << "Total events: " << status.total_events << "\n";
        os << "Overwritten events: " << status.overwritten_events << "\n";
        os << "Active stall: " << status.active_stall << "\n";
        os << "Active stall age ns: " << status.active_stall_age_ns << "\n";
        if (status.count) {
            std::vector<XemuDiagnosticsFlipStallEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_flip_stall_trace(ev.data(), ev.size());
            ev.resize(n);
            const XemuDiagnosticsFlipStallEvent *worst_stall = nullptr;
            const XemuDiagnosticsFlipStallEvent *worst_vk = nullptr;
            for (const auto &e : ev) {
                if (e.event_type == XEMU_DIAG_FLIP_PFIFO_RELEASE &&
                    (!worst_stall || e.duration_ns > worst_stall->duration_ns)) worst_stall = &e;
                if (e.event_type == XEMU_DIAG_FLIP_VK_FINISH_END &&
                    (!worst_vk || e.duration_ns > worst_vk->duration_ns)) worst_vk = &e;
            }
            if (worst_stall) {
                os << "Worst completed FLIP_STALL ns: " << worst_stall->duration_ns
                   << " R/W/M=" << worst_stall->read_3d << "/" << worst_stall->write_3d
                   << "/" << worst_stall->modulo_3d << "\n";
            }
            if (worst_vk) {
                os << "Worst Vulkan FLIP_STALL finish ns: " << worst_vk->duration_ns << "\n";
            }
            os << "Columns: seq qemu_ns host_ns event stall_age_ns duration_ns tid cpu guest_pc guest_pc_valid method parameter value0 value1 surface read write modulo waiting pending enabled flush sync frame_time\n";
            for (const auto &e : ev) {
                os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns << " "
                   << FlipStallEventName(e.event_type) << " " << e.stall_age_ns << " "
                   << e.duration_ns << " " << e.thread_id << " " << e.cpu_index << " "
                   << "0x" << std::hex << std::uppercase << e.guest_pc << std::dec << " "
                   << e.guest_pc_valid << " 0x" << std::hex << e.method << " 0x" << e.parameter
                   << " 0x" << e.value0 << " 0x" << e.value1 << " 0x" << e.surface << std::dec
                   << " " << e.read_3d << " " << e.write_3d << " " << e.modulo_3d
                   << " " << e.waiting_for_flip << " 0x" << std::hex << e.pending_interrupts
                   << " 0x" << e.enabled_interrupts << std::dec << " " << e.flush_pending
                   << " " << e.sync_pending << " " << e.frame_time << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::FlipDelay)) {
        os << "PGRAPH Flip Delay Breakdown\n----------------------------------------\n";
        XemuDiagnosticsPgraphFlipDelayStatus status{};
        xemu_diagnostics_get_pgraph_flip_delay_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Long-frame threshold ns: " << status.threshold_ns << "\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY)
           << "\n";
        os << "Frames seen / captured: " << status.total_frames_seen << " / "
           << status.captured_long_frames << "\n";
        os << "Overwritten events: " << status.overwritten_events << "\n";
        os << "Last / worst frame ns: " << status.last_frame_ns << " / "
           << status.worst_frame_ns << "\n";
        os << "Worst stall / post-release ns: " << status.worst_stall_total_ns
           << " / " << status.worst_post_release_ns << "\n";
        os << "Worst CPU-MMIO gate / PGRAPH lock wait ns: "
           << status.worst_cpu_mmio_gate_wait_ns << " / "
           << status.worst_pgraph_lock_wait_ns << "\n";
        os << "Worst PFIFO / renderer CPU-MMIO gate ns: "
           << status.worst_pfifo_cpu_mmio_gate_wait_ns << " / "
           << status.worst_renderer_cpu_mmio_gate_wait_ns << "\n";
        os << "Worst renderer finish ns: " << status.worst_renderer_finish_ns
           << "\n";
        os << "Post-release guest PC samples / untracked: "
           << status.guest_pc_samples << " / "
           << status.guest_pc_untracked_samples << "\n";
        os << "Guest PC sample interval / arm delay ns: "
           << status.guest_pc_sample_interval_ns << " / "
           << status.guest_pc_arm_delay_ns << "\n";
        os << "Active frame / age ns: " << status.active_frame << " / "
           << status.active_frame_age_ns << "\n";
        os << "Interpretation: frame_host_ns is FLIP_STALL->next FLIP_STALL. stall_total_ns covers FLIP_STALL_BEGIN->PFIFO_RELEASE; post_release_to_next_stall_ns is the remaining frame interval. Renderer finish and lock/gate timings are correlated sub-stages and may overlap those high-level partitions.\n";
        os << "CPU-MMIO gate note: Patch 300 marks both PFIFO PGRAPH-entry and GL/null/Vulkan renderer process_pending() paths before their PGRAPH gate. With Patch 20 present, pgraph_wait_for_cpu_mmio_accesses() runs before the existing PGRAPH lock-attempt marker; PFIFO and renderer subsets are exported separately.\n";
        os << "Guest-PC sampler note: TCG only; samples natural dispatcher-visible title TB entry PCs during PFIFO_RELEASE->next FLIP_STALL, beginning after half the long-frame threshold. It does not force one-instruction TBs and does not disable direct TB chaining. hot_pc_hits are sample hits, not instruction counts.\n";
        os << "Guest-PC label note: names below are resolved after capture from the current merged Labels database (XBE/XDK/MAP/PDB/.xlabel). Recorder hooks and raw event columns remain address-only.\n";
        if (status.count) {
            std::vector<XemuDiagnosticsPgraphFlipDelayEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_pgraph_flip_delay_trace(
                ev.data(), ev.size());
            ev.resize(n);
            os << "Columns: seq start_host_ns end_host_ns start_virtual_ns end_virtual_ns frame_host_ns frame_virtual_ns start_frame_time end_frame_time stall_total_ns post_release_to_next_stall_ns release_to_flip_increment_ns flip_increment_to_next_stall_ns stall_method_ns renderer_finish_total_ns renderer_finish_max_ns waiting_to_vblank_read_ns vblank_read_to_release_ns cpu_mmio_gate_wait_total_ns cpu_mmio_gate_wait_max_ns pfifo_cpu_mmio_gate_wait_total_ns pfifo_cpu_mmio_gate_wait_max_ns renderer_cpu_mmio_gate_wait_total_ns renderer_cpu_mmio_gate_wait_max_ns pgraph_lock_wait_total_ns pgraph_lock_wait_max_ns pfifo_gate_count renderer_gate_count pgraph_lock_count surface_lock_wait_total_ns surface_lock_wait_max_ns surface_update_total_ns pfifo_kick_total_ns bql_reacquire_total_ns pgraph_increment_count vblank_irq_count vblank_read_increment_count pfifo_stall_check_count pfifo_release_count read write modulo post_release_pc_samples post_release_pc_tracked_unique post_release_pc_untracked_samples hot_pc0 hot_hits0 hot_pc1 hot_hits1 hot_pc2 hot_hits2 hot_pc3 hot_hits3 hot_pc4 hot_hits4 hot_pc5 hot_hits5 hot_pc6 hot_hits6 hot_pc7 hot_hits7\n";
            std::set<uint32_t> hot_pcs;
            for (const auto &e : ev) {
                os << e.sequence << " " << e.start_host_ns << " "
                   << e.end_host_ns << " " << e.start_virtual_ns << " "
                   << e.end_virtual_ns << " " << e.frame_host_ns << " "
                   << e.frame_virtual_ns << " " << e.start_frame_time << " "
                   << e.end_frame_time << " " << e.stall_total_ns << " "
                   << e.post_release_to_next_stall_ns << " "
                   << e.release_to_flip_increment_ns << " "
                   << e.flip_increment_to_next_stall_ns << " "
                   << e.stall_method_ns << " "
                   << e.renderer_finish_total_ns << " "
                   << e.renderer_finish_max_ns << " "
                   << e.waiting_to_vblank_read_ns << " "
                   << e.vblank_read_to_release_ns << " "
                   << e.cpu_mmio_gate_wait_total_ns << " "
                   << e.cpu_mmio_gate_wait_max_ns << " "
                   << e.pfifo_cpu_mmio_gate_wait_total_ns << " "
                   << e.pfifo_cpu_mmio_gate_wait_max_ns << " "
                   << e.renderer_cpu_mmio_gate_wait_total_ns << " "
                   << e.renderer_cpu_mmio_gate_wait_max_ns << " "
                   << e.pgraph_lock_wait_total_ns << " "
                   << e.pgraph_lock_wait_max_ns << " "
                   << e.pfifo_gate_count << " " << e.renderer_gate_count << " "
                   << e.pgraph_lock_count << " "
                   << e.surface_lock_wait_total_ns << " "
                   << e.surface_lock_wait_max_ns << " "
                   << e.surface_update_total_ns << " "
                   << e.pfifo_kick_total_ns << " "
                   << e.bql_reacquire_total_ns << " "
                   << e.pgraph_increment_count << " " << e.vblank_irq_count
                   << " " << e.vblank_read_increment_count << " "
                   << e.pfifo_stall_check_count << " " << e.pfifo_release_count
                   << " " << e.read_3d << " " << e.write_3d << " "
                   << e.modulo_3d << " " << e.post_release_pc_samples << " "
                   << e.post_release_pc_tracked_unique << " "
                   << e.post_release_pc_untracked_samples;
                for (uint32_t rank = 0;
                     rank < XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT;
                     ++rank) {
                    os << " 0x" << std::hex << std::uppercase << e.hot_pc[rank]
                       << std::dec << " " << e.hot_pc_hits[rank];
                    if (e.hot_pc_hits[rank] != 0) {
                        hot_pcs.insert(e.hot_pc[rank]);
                    }
                }
                os << "\n";
            }
            if (!hot_pcs.empty()) {
                os << "Resolved hot PC labels:\n";
                for (uint32_t pc : hot_pcs) {
                    XemuXbeLabels::ResolvedAddress resolved;
                    if (!XemuXbeLabels::ResolveAddress(
                            current_game_manager.Labels(), pc, resolved) ||
                        resolved.label == nullptr) {
                        continue;
                    }
                    os << "  0x" << std::hex << std::uppercase << std::setw(8)
                       << std::setfill('0') << pc << std::dec << std::setfill(' ')
                       << " = " << FormatGuestPcLabel(pc)
                       << " [base=0x" << std::hex << std::uppercase
                       << std::setw(8) << std::setfill('0')
                       << resolved.label->virtual_address << std::dec
                       << std::setfill(' ') << ", "
                       << XemuXbeLabels::SourceName(resolved.label->source)
                       << "/"
                       << XemuXbeLabels::ConfidenceName(resolved.label->confidence)
                       << "]\n";
                }
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::PusherProgress)) {
        os << "D3D Pusher / GPU Progress Correlation\n"
              "----------------------------------------\n";
        XemuDiagnosticsPgraphPusherProgressStatus status{};
        xemu_diagnostics_get_pgraph_pusher_progress_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS)
           << "\n";
        os << "Total / overwritten events: " << status.total_events << " / "
           << status.overwritten_events << "\n";
        os << "DMA PUT / PFIFO run / semaphore release: "
           << status.dma_put_events << " / " << status.pfifo_run_events << " / "
           << status.semaphore_release_events << "\n";
        os << "Worst PFIFO run / semaphore / DMA-PUT-to-semaphore ns: "
           << status.worst_pfifo_run_ns << " / "
           << status.worst_semaphore_release_ns << " / "
           << status.worst_dma_put_to_semaphore_ns << "\n";
        os << "Last DMA-PUT-to-semaphore ns: "
           << status.last_dma_put_to_semaphore_ns << "\n";
        os << "Last PFIFO GET / PUT: 0x" << std::hex << std::uppercase
           << status.last_dma_get << " / 0x" << status.last_dma_put << std::dec
           << "\n";
        if (status.last_semaphore_target_valid) {
            os << "Last GPU-time semaphore phys / guest / value: 0x"
               << std::hex << std::uppercase << status.last_semaphore_phys
               << " / 0x" << status.last_semaphore_guest_va << " / 0x"
               << status.last_semaphore_value << std::dec << "\n";
        } else {
            os << "Last GPU-time semaphore: <not observed>\n";
        }
        os << "Interpretation: DMA_PUT is guest NV_USER_DMA_PUT submission; PFIFO_RUN measures DMA GET/PUT consumption; SEMAPHORE_RELEASE observes NV097 BACK_END_WRITE_SEMAPHORE_RELEASE immediately before its unchanged guest-memory write, after the stock renderer surface update. DMA-PUT-to-semaphore is measured from the most recent guest NV_USER_DMA_PUT. XDK D3D GpuTime/BlockOnTime reads this semaphore progress memory.\n";
        os << "Correlation note: host_start_ns/host_end_ns share the host clock used by PGRAPH Flip Delay Breakdown, so long-frame windows can be intersected without adding symbol work to recorder hooks.\n";
        os << "Observation-only note: this trace does not alter DMA PUT/GET, PFIFO scheduling, surface update, semaphore values, guest memory visibility, or D3D behavior; the semaphore event is timestamped immediately before the existing stl_le_p write.\n";
        if (status.count) {
            std::vector<XemuDiagnosticsPgraphPusherProgressEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_pgraph_pusher_progress_trace(
                ev.data(), ev.size());
            ev.resize(n);
            std::set<uint32_t> guest_pcs;
            os << "Columns: seq event host_start_ns host_end_ns virtual_start_ns virtual_end_ns duration_ns dma_put_to_event_ns tid cpu guest_pc guest_pc_valid channel dma_get_before dma_get_after dma_put_before dma_put_after method_words dma_instance semaphore_offset semaphore_phys semaphore_guest_va semaphore_old semaphore_new target_valid waiting_nop waiting_flip fifo_access\n";
            for (const auto &e : ev) {
                os << e.sequence << " "
                   << PgraphPusherProgressEventName(e.event_type) << " "
                   << e.host_start_ns << " " << e.host_end_ns << " "
                   << e.virtual_start_ns << " " << e.virtual_end_ns << " "
                   << e.duration_ns << " " << e.dma_put_to_event_ns << " "
                   << e.thread_id << " " << e.cpu_index << " 0x"
                   << std::hex << std::uppercase << e.guest_pc << std::dec << " "
                   << e.guest_pc_valid << " " << e.channel_id << " 0x"
                   << std::hex << e.dma_get_before << " 0x" << e.dma_get_after
                   << " 0x" << e.dma_put_before << " 0x" << e.dma_put_after
                   << std::dec << " " << e.method_words_processed << " 0x"
                   << std::hex << e.dma_instance << " 0x" << e.semaphore_offset
                   << " 0x" << e.semaphore_phys << " 0x" << e.semaphore_guest_va
                   << " 0x" << e.semaphore_old_value << " 0x"
                   << e.semaphore_new_value << std::dec << " "
                   << e.semaphore_target_valid << " " << e.waiting_for_nop
                   << " " << e.waiting_for_flip << " " << e.fifo_access
                   << "\n";
                if (e.guest_pc_valid) {
                    guest_pcs.insert((uint32_t)e.guest_pc);
                }
            }
            if (!guest_pcs.empty()) {
                os << "Resolved DMA PUT guest PC labels:\n";
                for (uint32_t pc : guest_pcs) {
                    XemuXbeLabels::ResolvedAddress resolved;
                    if (!XemuXbeLabels::ResolveAddress(
                            current_game_manager.Labels(), pc, resolved) ||
                        resolved.label == nullptr) {
                        continue;
                    }
                    os << "  0x" << std::hex << std::uppercase << std::setw(8)
                       << std::setfill('0') << pc << std::dec << std::setfill(' ')
                       << " = " << FormatGuestPcLabel(pc)
                       << " [base=0x" << std::hex << std::uppercase
                       << std::setw(8) << std::setfill('0')
                       << resolved.label->virtual_address << std::dec
                       << std::setfill(' ') << ", "
                       << XemuXbeLabels::SourceName(resolved.label->source)
                       << "/"
                       << XemuXbeLabels::ConfidenceName(resolved.label->confidence)
                       << "]\n";
                }
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::MethodBreakdown)) {
        XemuDiagnosticsPgraphPusherMethodBreakdownStatus status{};
        xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(&status);
        os << "PFIFO Method-Time Breakdown\n"
           << "----------------------------------------\n";
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Long-run threshold ns: " << status.threshold_ns << "\n";
        os << "Buffered / capacity: " << status.count << " / "
           << status.capacity << "\n";
        os << "Total long runs / overwritten: " << status.total_long_runs
           << " / " << status.overwritten_events << "\n";
        os << "Worst run / puller-dispatch / parser+other ns: "
           << status.worst_run_ns << " / " << status.worst_puller_dispatch_ns
           << " / " << status.worst_parser_other_ns << "\n";
        os << "Last run / puller-dispatch / parser+other ns: "
           << status.last_run_ns << " / " << status.last_puller_dispatch_ns
           << " / " << status.last_parser_other_ns << "\n";
        os << "Last puller calls / NV097 calls / unique methods: "
           << status.last_puller_calls << " / " << status.last_nv097_calls
           << " / " << status.last_unique_nv097_methods << "\n";
        os << "Interpretation: PFIFO_RUN is split into summed pfifo_run_puller() dispatch wall time and parser+other time outside those calls. NV097 top methods are grouped by the pgraph Kelvin method table base/name; SET_BEGIN_END is split into BEGIN and END variants. Totals include the existing CPU-MMIO gate, PGRAPH lock and method execution inside that puller dispatch.\n";
        os << "Observation-only note: the breakdown adds timestamps/identity accounting only while separately enabled; it does not change DMA parsing, GET/PUT, lock order, method dispatch, renderer work, or semaphore writes.\n";
        os << "Draw aggregates: v3.14z; all completed END draws in each retained >=5ms PFIFO run, not just >=5ms individual draws.\n";
        os << "DRAW_SUMMARY and DRAW_STAGE lines belong to the preceding RUN; inclusive total_ns spans nest and must NOT be added. self_ns excludes measured immediate children only, includes observer overhead, and is unreliable when dropped/invalid/saturated is nonzero.\n";
        os << "Cache counters describe renderer fast-reuse/LRU branches, NOT Vulkan driver cache hits. VK_PIPELINE_BUILD_STATE includes layout/render-pass preparation; VK_PIPELINE_CREATE wraps only vkCreateGraphicsPipelines.\n";
        if (status.count) {
            std::vector<XemuDiagnosticsPgraphPusherMethodBreakdownEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace(
                ev.data(), ev.size());
            ev.resize(n);
            os << "Columns: seq host_start_ns host_end_ns virtual_start_ns virtual_end_ns duration_ns puller_dispatch_ns parser_other_ns nv097_puller_ns non_nv097_puller_ns unclassified_puller_ns untracked_nv097_ns channel dma_get_before dma_get_after dma_put_before dma_put_after method_words puller_calls nv097_calls non_nv097_calls unclassified_calls unique_nv097_methods untracked_nv097_calls top_count\n";
            for (const auto &e : ev) {
                os << "RUN " << e.sequence << " " << e.host_start_ns << " "
                   << e.host_end_ns << " " << e.virtual_start_ns << " "
                   << e.virtual_end_ns << " " << e.duration_ns << " "
                   << e.puller_dispatch_ns << " " << e.parser_other_ns << " "
                   << e.nv097_puller_ns << " " << e.non_nv097_puller_ns << " "
                   << e.unclassified_puller_ns << " " << e.untracked_nv097_ns
                   << " " << e.channel_id << " 0x" << std::hex << std::uppercase
                   << e.dma_get_before << " 0x" << e.dma_get_after << " 0x"
                   << e.dma_put_before << " 0x" << e.dma_put_after << std::dec
                   << " " << e.method_words_processed << " " << e.puller_calls
                   << " " << e.nv097_calls << " " << e.non_nv097_calls << " "
                   << e.unclassified_calls << " " << e.unique_nv097_methods
                   << " " << e.untracked_nv097_calls << " " << e.top_method_count
                   << "\n";
                os << "  DRAW_SUMMARY completed=" << e.draw.completed_draws
                   << " sub5ms=" << e.draw.sub5ms_draws
                   << " fast_reuse=" << e.draw.fast_reuse
                   << " cache_hit=" << e.draw.cache_hits
                   << " cache_miss=" << e.draw.cache_misses
                   << " dropped=" << e.draw.dropped_spans
                   << " invalid=" << e.draw.invalid_spans
                   << " saturated=" << e.draw.saturated << "\n";
                os << "  VERTEX_METRICS"
                   << " vertex_requested_ranges=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_REQUESTED_RANGES]
                   << " vertex_merged_ranges=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_MERGED_RANGES]
                   << " vertex_tested_bytes=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_TESTED_BYTES]
                   << " vertex_dirty_ranges=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_RANGES]
                   << " vertex_dirty_bytes=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_BYTES]
                   << " vertex_copy_calls=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_CALLS]
                   << " vertex_copy_bytes=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_BYTES]
                   << " vertex_overlap_finishes=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_OVERLAP_FINISHES]
                   << " vertex_dirty_fence_wait_ns=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAIT_NS]
                   << " vertex_dirty_fence_waits=" << e.draw.metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAITS]
                   << "\n";
                for (uint32_t stage = 1; stage < XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT; ++stage) {
                    const auto &stat = e.draw.stages[stage];
                    if (!stat.calls) continue;
                    os << "  DRAW_STAGE " << PgraphDrawTraceStageName(stage)
                       << " total_ns=" << stat.total_ns << " self_ns=" << stat.self_ns
                       << " calls=" << stat.calls << " max_ns=" << stat.max_ns << "\n";
                }
                for (uint32_t rank = 0; rank < e.top_method_count; ++rank) {
                    const auto &m = e.top_methods[rank];
                    os << "  TOP " << (rank + 1) << " class=0x" << std::hex
                       << std::uppercase << m.graphics_class << " subch=" << std::dec
                       << m.subchannel << " method=0x" << std::hex << std::uppercase
                       << m.method << " base=0x" << m.method_base << std::dec
                       << " name=" << m.name << " variant=" << m.variant << " total_ns=" << m.total_ns
                       << " calls=" << m.call_count << " max_ns=" << m.max_ns
                       << " words=" << m.words_processed << "\n";
                }
            }
        }
        std::vector<XemuDebugToolsPgraphCoverageEvent> coverage(
            XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY);
        uint64_t coverage_skipped = 0;
        coverage.resize(xemu_debug_tools_pgraph_pusher_coverage_snapshot(
            coverage.data(), coverage.size(), &coverage_skipped));
        os << "PFIFO All-Run Coverage v3.14ab\n";
        os << "Coverage windows / capacity / skipped snapshot slots: "
           << coverage.size() << " / " << XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY
           << " / " << coverage_skipped << "\n";
        os << "Coverage note: includes every completed nonempty PFIFO scope while method recording is enabled, even runs below 5ms. Windows close at a run end after >=100ms host span; gaps between runs are not charged as work. Durations are whole-run, not frame-clipped. Nested stage times must not be added. Live windows (closed=0) are revisions: replace by the newest row with the same epoch/sequence, never sum snapshots. Busy-slot publication is deferred without waiting; the next successful update catches up. A stopped capture may have an unpublished tail. Sequence gaps/first sequence >0 indicate unavailable/overwritten windows.\n";
        for (const auto &window : coverage) {
            os << "COVERAGE_WINDOW " << window.sequence
               << " epoch=" << window.epoch << " generation=" << window.recording_generation
               << " closed=" << window.closed;
#define XEMU_COVERAGE_EXPORT(field) os << " " #field "=" << window.field;
            XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_FIELDS(XEMU_COVERAGE_EXPORT)
#undef XEMU_COVERAGE_EXPORT
            os << "\n";
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Scheduler)) {
        os << "Xbox Scheduler / Thread Wake Trace\n----------------------------------------\n";
        XemuDiagnosticsSchedulerTraceStatus status{};
        xemu_diagnostics_get_scheduler_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_SCHEDULER) << "\n";
        os << "Total events: " << status.total_events << "\n";
        os << "Overwritten events: " << status.overwritten_events << "\n";
        os << "KiIdleLoop range: 0x" << std::hex << std::uppercase
           << status.idle_pc_start << "-0x" << status.idle_pc_end << std::dec << "\n";
        os << "Active idle: " << status.active_idle << "\n";
        os << "Active idle age ns: " << status.active_idle_age_ns << "\n";
        os << "Longest completed idle ns: " << status.longest_completed_idle_ns << "\n";
        os << "Last sampled PC: 0x" << std::hex << std::uppercase
           << status.last_sample_pc;
        AppendGuestPcLabel(os, status.last_sample_pc);
        os << " last title PC: 0x" << status.last_title_pc;
        AppendGuestPcLabel(os, status.last_title_pc);
        os << std::dec << "\n";
        os << "Last IRQ source: " << SchedulerWakeSourceName(status.last_irq_source) << "\n";
        if (status.count) {
            std::vector<XemuDiagnosticsSchedulerTraceEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_scheduler_trace(ev.data(), ev.size());
            ev.resize(n);
            os << "Columns: seq qemu_ns host_ns event idle_age_ns duration_ns pc last_title_pc eflags ebx ebp esp slot28 slot2c interrupt_request exception_index cpu halted last_irq_source last_irq_age_ns last_irq_pending last_irq_enabled pmc_pending pmc_enabled pfifo_pending pfifo_enabled pgraph_pending pgraph_enabled pcrtc_pending pcrtc_enabled ptimer_pending ptimer_enabled idle_vblank idle_ptimer idle_pgraph idle_pfifo idle_ohci\n";
            for (const auto &e : ev) {
                os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns << " "
                   << SchedulerTraceEventName(e.event_type) << " " << e.idle_age_ns << " "
                   << e.duration_ns << " 0x" << std::hex << std::uppercase << e.guest_pc
                   << " 0x" << e.last_title_pc << " 0x" << e.eflags << " 0x" << e.ebx
                   << " 0x" << e.ebp << " 0x" << e.esp << " 0x" << e.scheduler_slot_28
                   << " 0x" << e.scheduler_slot_2c << " 0x" << e.interrupt_request << std::dec
                   << " " << e.exception_index << " " << e.cpu_index << " " << e.halted
                   << " " << SchedulerWakeSourceName(e.last_irq_source) << " " << e.last_irq_age_ns
                   << " 0x" << std::hex << e.last_irq_pending << " 0x" << e.last_irq_enabled
                   << " 0x" << e.pmc_pending << " 0x" << e.pmc_enabled
                   << " 0x" << e.pfifo_pending << " 0x" << e.pfifo_enabled
                   << " 0x" << e.pgraph_pending << " 0x" << e.pgraph_enabled
                   << " 0x" << e.pcrtc_pending << " 0x" << e.pcrtc_enabled
                   << " 0x" << e.ptimer_pending << " 0x" << e.ptimer_enabled << std::dec
                   << " " << e.idle_vblank_count << " " << e.idle_ptimer_count
                   << " " << e.idle_pgraph_count << " " << e.idle_pfifo_count
                   << " " << e.idle_ohci_count << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::IrqLatency)) {
        os << "PTIMER IRQ Service Latency Trace\n----------------------------------------\n";
        XemuDiagnosticsLatencyTraceStatus status{};
        xemu_diagnostics_get_ptimer_irq_latency_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\nThreshold ms: "
           << std::fixed << std::setprecision(3)
           << ((double)status.threshold_ns / 1000000.0)
           << "\nThreshold ns: " << status.threshold_ns
           << "\nBuffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY)
           << "\nTotal events: " << status.total_events
           << "\nOverwritten events: " << status.overwritten_events << "\n";
        if (status.count) {
            std::vector<XemuDiagnosticsPtimerIrqLatencyEvent> ev(status.count);
            size_t n = xemu_diagnostics_get_ptimer_irq_latency_trace(
                ev.data(), ev.size());
            ev.resize(n);
            const XemuDiagnosticsPtimerIrqLatencyEvent *worst = nullptr;
            for (const auto &e : ev)
                if (!worst || e.service_latency_ns > worst->service_latency_ns)
                    worst = &e;
            if (worst) {
                os << "Worst IRQ service latency ns: " << worst->service_latency_ns
                   << "\nWorst clear guest PC: 0x" << std::hex << std::uppercase
                   << worst->clear_guest_pc;
                if (worst->clear_guest_pc_valid) {
                    AppendGuestPcLabel(os, worst->clear_guest_pc);
                }
                os << std::dec << " valid=" << worst->clear_guest_pc_valid << "\n";
            }
            os << "Columns: seq set_host_ns clear_host_ns service_latency_ns set_virtual_ns clear_virtual_ns virtual_latency_ns threshold_ns clear_pc clear_pc_valid clear_rdtsc rdtsc_valid interrupt_request eflags halted pending_at_set enabled_at_set clear_value set_tid clear_tid\n";
            for (const auto &e : ev) {
                os << e.sequence << " " << e.irq_set_host_ns << " "
                   << e.irq_clear_host_ns << " " << e.service_latency_ns << " "
                   << e.irq_set_virtual_ns << " " << e.irq_clear_virtual_ns << " "
                   << e.virtual_latency_ns << " " << e.threshold_ns << " 0x"
                   << std::hex << std::uppercase << e.clear_guest_pc << std::dec
                   << " " << e.clear_guest_pc_valid << " 0x" << std::hex
                   << e.clear_rdtsc_reference << std::dec << " "
                   << e.clear_rdtsc_reference_valid << " 0x" << std::hex
                   << e.clear_interrupt_request << " 0x" << e.clear_eflags
                   << std::dec << " " << e.clear_halted << " 0x" << std::hex
                   << e.pending_at_set << " 0x" << e.enabled_at_set << " 0x"
                   << e.clear_value << std::dec << " " << e.set_thread_id << " "
                   << e.clear_thread_id << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::IrqDelivery)) {
        os << "PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)\n"
              "----------------------------------------\n";
        XemuDiagnosticsPtimerIrqDeliverySnapshot snapshot{};
        XemuDiagnosticsPtimerIrqDeliveryStatus status{};
        xemu_diagnostics_get_ptimer_irq_delivery_trace_status(&status);
        os << "Trace enabled / active: " << status.enabled << " / "
           << status.active << "\n";
        os << "Slow / overdue threshold ns: " << status.slow_threshold_ns
           << " / " << status.overdue_threshold_ns << "\n";
        os << "TCG sample interval ns: " << status.sample_interval_ns << "\n";
        os << "Total / slow windows: " << status.total_windows << " / "
           << status.slow_windows << "\n";
        os << "Stored / total / overwritten captures: "
           << status.stored_captures << " / " << status.capture_count << " / "
           << status.overwritten_captures << "\n";
        os << "Active set/age ns: " << status.active_set_virtual_ns << " / "
           << status.active_age_ns << "\n";
        os << "Last service ns/classification: " << status.last_service_virtual_ns
           << " / " << PtimerIrqDeliveryClassName(status.last_classification)
           << "\n";
        os << "Patch3051 dispatcher single-step suppressed: "
           << status.dispatcher_single_step_suppressed << "\n";

        if (xemu_diagnostics_get_ptimer_irq_delivery_trace(&snapshot)) {
            for (size_t ci = 0; ci < snapshot.status.stored_captures; ++ci) {
                const auto &c = snapshot.captures[ci];
                os << "Capture " << c.capture_sequence << ": service_virtual_ns="
                   << c.service_virtual_ns << " service_host_ns="
                   << c.service_host_ns << " class="
                   << PtimerIrqDeliveryClassName(c.classification)
                   << " events=" << c.event_count << " checks="
                   << c.total_tcg_checks << " sampled=" << c.sampled_tcg_checks
                   << " dropped=" << c.dropped_samples << "\n";
                os << "  IF0/IF1=" << c.if_disabled_samples << "/"
                   << c.if_enabled_samples << " inhibit=" << c.inhibit_samples
                   << " hard_present/missing/eligible=" << c.hard_present_samples
                   << "/" << c.hard_missing_samples << "/"
                   << c.hard_eligible_samples << " noirq=" << c.noirq_samples
                   << " hard_take=" << c.hard_take_events
                   << " nv2a/pci/pic=" << c.saw_nv2a_assert << "/"
                   << c.saw_pci_route_assert << "/" << c.saw_pic_cpu_assert
                   << " overdue=" << c.overdue_marked << "\n";
                os << "Columns: capture seq virtual_ns host_ns since_set_ns event pc interrupt_request cflags_next_tb eflags hflags hflags2 ptimer_pending ptimer_enabled pmc_pending pmc_enabled level pirq pic_irq selected_interrupt vector cpu_valid hard_present hard_eligible if_enabled inhibit_irq noirq halted exception apic_path\n";
                for (size_t ei = 0; ei < c.event_count; ++ei) {
                    const auto &e = c.events[ei];
                    os << c.capture_sequence << " " << e.sequence << " "
                       << e.virtual_ns << " " << e.host_ns << " "
                       << e.since_set_ns << " "
                       << PtimerIrqDeliveryEventName(e.type) << " 0x"
                       << std::hex << std::uppercase << e.guest_pc << " 0x"
                       << e.interrupt_request << std::dec << " "
                       << e.cflags_next_tb << " 0x" << std::hex << e.eflags
                       << " 0x" << e.hflags << " 0x" << e.hflags2
                       << " 0x" << e.ptimer_pending << " 0x" << e.ptimer_enabled
                       << " 0x" << e.pmc_pending << " 0x" << e.pmc_enabled
                       << std::dec << " " << e.level << " " << e.pirq << " "
                       << e.pic_irq << " " << e.selected_interrupt << " "
                       << e.interrupt_vector << " " << e.cpu_valid << " "
                       << e.hard_present << " " << e.hard_eligible << " "
                       << e.if_enabled << " " << e.inhibit_irq << " "
                       << e.noirq_cflags << " " << e.cpu_halted << " "
                       << e.exception_index << " " << e.apic_path << "\n";
                }
            }
            if (snapshot.status.active && snapshot.current.event_count != 0) {
                const auto &c = snapshot.current;
                os << "Current in-progress window: set_virtual_ns="
                   << c.irq_set_virtual_ns << " events=" << c.event_count
                   << " checks=" << c.total_tcg_checks << " sampled="
                   << c.sampled_tcg_checks << " dropped=" << c.dropped_samples
                   << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::QemuTimer)) {
        os << "QEMU Timer Dispatch Trace\n----------------------------------------\n";
        XemuDiagnosticsQemuTimerTraceStatus trace_status{};
        xemu_diagnostics_get_qemu_timer_trace_status(&trace_status);
        os << "Trace enabled: " << trace_status.enabled << "\n";
        os << "Buffered events: " << trace_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_QEMU_TIMER) << "\n";
        os << "Total events: " << trace_status.total_events << "\n";
        os << "Overwritten events: " << trace_status.overwritten_events << "\n";
        os << "Watched PTIMER expiry ns: " << trace_status.watched_timer_expire_ns << "\n";
        if (trace_status.count != 0) {
            std::vector<XemuDiagnosticsQemuTimerTraceEvent> trace(trace_status.count);
            const size_t trace_count =
                xemu_diagnostics_get_qemu_timer_trace(trace.data(), trace.size());
            trace.resize(trace_count);
            const QemuTimerTraceAnalysis analysis = AnalyzeQemuTimerTrace(trace);
            os << "Analysis:\n";
            os << "  Worst dispatch lateness ns: "
               << analysis.worst_dispatch_late_ns << "\n";
            os << "  Worst selected-timeout excess vs PTIMER delta ns: "
               << analysis.worst_timeout_excess_ns << "\n";
            os << "  Saw infinite wait while PTIMER near deadline: "
               << (analysis.saw_infinite_wait ? "yes" : "no") << "\n";
            os << "  Worst wait overshoot host ns: "
               << analysis.worst_wait_overshoot_host_ns << "\n";
            os << "  Worst wait overshoot virtual ns: "
               << analysis.worst_wait_overshoot_virtual_ns << "\n";
            os << "  Worst wait-exit -> run-timers gap host ns: "
               << analysis.worst_post_wait_gap_host_ns << "\n";
            os << "  Worst wait-exit -> run-timers gap virtual ns: "
               << analysis.worst_post_wait_gap_virtual_ns << "\n";
            os << "  Late-dispatch preceding wait timeout ns: "
               << analysis.late_wait_timeout_ns << "\n";
            os << "  Late-dispatch preceding wait elapsed host/virtual ns: "
               << analysis.late_wait_elapsed_host_ns << "/"
               << analysis.late_wait_elapsed_virtual_ns << "\n";
            os << "  Late-wait stage host ns (glib_acquire/glib_prepare/poll/busywait/poll_backend/main_loop_lock/replay_lock/bql_lock/wait_objects/glib_check/glib_dispatch/polling_callbacks/glib_release): "
               << analysis.late_glib_acquire_host_ns << "/"
               << analysis.late_glib_prepare_host_ns << "/"
               << analysis.late_poll_host_ns << "/"
               << analysis.late_busywait_host_ns << "/"
               << analysis.late_poll_backend_host_ns << "/"
               << analysis.late_main_loop_lock_host_ns << "/"
               << analysis.late_replay_lock_host_ns << "/"
               << analysis.late_bql_lock_host_ns << "/"
               << analysis.late_wait_objects_host_ns << "/"
               << analysis.late_glib_check_host_ns << "/"
               << analysis.late_glib_dispatch_host_ns << "/"
               << analysis.late_polling_callbacks_host_ns << "/"
               << analysis.late_glib_release_host_ns << "\n";
            os << "  Likely delay stage: " << LikelyQemuTimerDelayStage(analysis)
               << "\n";
            os << "Columns: seq qemu_ns host_ns event clock tid timeout_ns "
                  "timer_expire_ns timer_delta_ns wait_host_ns wait_virtual_ns "
                  "dispatch_late_ns pending value\n";
            for (size_t i = 0; i < trace_count; ++i) {
                const auto &event = trace[i];
                os << event.sequence << " "
                   << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << QemuTimerTraceEventName(event.event_type) << " "
                   << event.clock_type << " "
                   << event.thread_id << " "
                   << event.timeout_ns << " "
                   << event.timer_expire_ns << " "
                   << event.timer_delta_ns << " "
                   << event.wait_elapsed_host_ns << " "
                   << event.wait_elapsed_virtual_ns << " "
                   << event.dispatch_late_ns << " "
                   << event.watched_timer_pending << " "
                   << event.value << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::HostStall)) {
        os << "Windows Host Stall / Page-Fault Correlation (Patch 305.4)\n"
              "----------------------------------------\n";
        XemuDiagnosticsHostStallStatus status{};
        xemu_diagnostics_get_host_stall_trace_status(&status);
        os << "Trace enabled / Windows supported: " << status.enabled << " / "
           << status.windows_supported << "\n";
        os << "Buffered / total / overwritten: " << status.count << " / "
           << status.total_events << " / " << status.overwritten_events << "\n";
        os << "vCPU / main-loop events: " << status.vcpu_events << " / "
           << status.main_loop_events << "\n";
        os << "Page-fault correlated / host-offCPU / thread-busy: "
           << status.pagefault_correlated_events << " / " << status.offcpu_events
           << " / " << status.busy_events << "\n";
        os << "Sample/offCPU/busy/process intervals ns: "
           << status.sample_interval_ns << " / " << status.offcpu_threshold_ns
           << " / " << status.busy_threshold_ns << " / "
           << status.process_sample_interval_ns << "\n";
        os << "Worst vCPU wall/offCPU ns: " << status.worst_vcpu_wall_ns << " / "
           << status.worst_vcpu_offcpu_ns << "\n";
        os << "Worst main-loop timeout excess ns: "
           << status.worst_main_loop_excess_ns << "\n";
        os << "Worst process PageFaultCount delta: "
           << status.worst_page_fault_delta << "\n";
        os << "Note: Windows PageFaultCount includes soft and hard faults; a matching "
              "delta is correlation, not proof of disk paging.\n";
        if (status.count != 0) {
            std::vector<XemuDiagnosticsHostStallEvent> trace(status.count);
            const size_t count = xemu_diagnostics_get_host_stall_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Columns: seq type class tid host_before host_after wall_ns cpu_ns "
                  "offcpu_ns cycles timeout_ns excess_ns virtual_before virtual_after "
                  "pc_before pc_after proc_age_ns pf_before pf_after pf_delta ws_before "
                  "ws_after private_before private_after avail_before avail_after "
                  "memload_before memload_after input_seq d3d_seq d7ea0_due_ns "
                  "d7ea0_delta_ns watch_armed overdue target ptimer_active "
                  "ptimer_set_ns ptimer_age_ns\n";
            for (const auto &event : trace) {
                os << event.sequence << " "
                   << HostStallEventName(event.type) << " "
                   << HostStallClassName(event.classification) << " "
                   << event.thread_id << " " << event.host_before_ns << " "
                   << event.host_after_ns << " " << event.wall_span_ns << " "
                   << event.thread_cpu_ns << " " << event.off_cpu_ns << " "
                   << event.thread_cycles_delta << " " << event.requested_timeout_ns
                   << " " << event.wait_excess_ns << " "
                   << event.qemu_virtual_before_ns << " "
                   << event.qemu_virtual_after_ns << " 0x" << std::hex
                   << std::uppercase << event.guest_pc_before << " 0x"
                   << event.guest_pc_after << std::dec << " "
                   << event.process_sample_age_ns << " "
                   << event.page_fault_count_before << " "
                   << event.page_fault_count_after << " " << event.page_fault_delta
                   << " " << event.working_set_before << " "
                   << event.working_set_after << " " << event.private_usage_before
                   << " " << event.private_usage_after << " "
                   << event.available_phys_before << " "
                   << event.available_phys_after << " " << event.memory_load_before
                   << " " << event.memory_load_after << " " << event.input_sequence
                   << " " << event.d3d_sequence << " "
                   << event.callback_expected_due_ns << " "
                   << event.callback_due_delta_ns << " "
                   << event.callback_watch_armed << " "
                   << event.callback_overdue_latched << " 0x" << std::hex
                   << std::uppercase << event.callback_target << std::dec << " "
                   << event.ptimer_irq_active << " "
                   << event.ptimer_irq_set_virtual_ns << " "
                   << event.ptimer_irq_age_ns << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Bql)) {
        os << "BQL Ownership Trace\n----------------------------------------\n";
        XemuDiagnosticsBqlTraceStatus bql_status{};
        xemu_diagnostics_get_bql_trace_status(&bql_status);
        os << "Trace enabled: " << bql_status.enabled << "\n";
        os << "Buffered events: " << bql_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_BQL) << "\n";
        os << "Total events: " << bql_status.total_events << "\n";
        os << "Overwritten events: " << bql_status.overwritten_events << "\n";
        os << "Long wait/hold threshold ns: " << bql_status.long_wait_threshold_ns << "\n";
        os << "Current owner TID/CPU/held ns: "
           << bql_status.current_owner_thread_id << "/"
           << bql_status.current_owner_cpu_index << "/"
           << bql_status.current_owner_held_ns << "\n";
        os << "Current owner acquisition: "
           << (bql_status.current_owner_caller_file[0]
                   ? bql_status.current_owner_caller_file : "<unknown>")
           << ":" << bql_status.current_owner_caller_line << "\n";
        os << "Current owner context: "
           << BqlTraceContextName(bql_status.current_owner_context) << "\n";
        os << "Current owner stage/elapsed ns: "
           << BqlTraceStageName(bql_status.current_owner_stage) << "/"
           << bql_status.current_owner_stage_elapsed_ns << "\n";
        if (bql_status.current_owner_guest_pc_valid) {
            os << "Current owner guest PC: 0x" << std::hex << std::uppercase
               << std::setw(16) << std::setfill('0')
               << bql_status.current_owner_guest_pc;
            AppendGuestPcLabel(os, bql_status.current_owner_guest_pc);
            os << std::dec << std::setfill(' ') << "\n";
        }
        if (bql_status.count != 0) {
            std::vector<XemuDiagnosticsBqlTraceEvent> bql_trace(bql_status.count);
            const size_t bql_count =
                xemu_diagnostics_get_bql_trace(bql_trace.data(), bql_trace.size());
            bql_trace.resize(bql_count);
            const BqlTraceAnalysis analysis = AnalyzeBqlTrace(bql_trace);
            os << "Analysis:\n";
            os << "  Worst BQL wait ns: " << analysis.worst_wait_ns << "\n";
            if (analysis.have_worst_wait) {
                const auto &event = analysis.worst_wait;
                os << "  Worst wait waiter TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst wait callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Blocking owner TID/CPU: " << event.owner_thread_id << "/"
                   << event.owner_cpu_index << "\n";
                os << "  Owner already held at wait attempt ns: "
                   << event.owner_held_at_attempt_ns << "\n";
                os << "  Owner acquisition callsite: "
                   << (event.owner_caller_file[0]
                           ? event.owner_caller_file : "<unknown>")
                   << ":" << event.owner_caller_line << "\n";
                os << "  Waiter context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Blocking owner context: "
                   << BqlTraceContextName(event.owner_context) << "\n";
                os << "  Blocking owner stage at wait: "
                   << BqlTraceStageName(event.owner_stage_at_attempt)
                   << " (elapsed ns=" << event.owner_stage_elapsed_at_attempt_ns
                   << ")\n";
                if (event.owner_guest_pc_start_valid) {
                    os << "  Owner guest PC at acquisition: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.owner_guest_pc_start << std::dec << "\n";
                }
            }
            os << "  Longest BQL hold overlapping worst wait ns: "
               << analysis.longest_overlapping_hold_ns << "\n";
            if (analysis.have_overlapping_hold) {
                const auto &event = analysis.overlapping_hold;
                os << "  Overlapping holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Overlapping holder acquisition callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Overlapping holder context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Overlapping holder longest stage: "
                   << BqlTraceStageName(event.longest_stage)
                   << " (ns=" << event.longest_stage_ns << ")\n";
                if (event.guest_pc_start_valid) {
                    os << "  Overlapping holder guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Overlapping holder guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
            }
            os << "  Worst BQL hold ns: " << analysis.worst_hold_ns << "\n";
            if (analysis.have_worst_hold) {
                const auto &event = analysis.worst_hold;
                os << "  Worst holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst hold acquisition callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Worst hold context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Worst hold longest stage: "
                   << BqlTraceStageName(event.longest_stage)
                   << " (ns=" << event.longest_stage_ns << ")\n";
                if (event.guest_pc_start_valid) {
                    os << "  Holder guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Holder guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
            }
            os << "Columns: seq qemu_ns host_ns event tid cpu wait_ns hold_ns "
                  "owner_tid owner_cpu owner_held_at_attempt_ns owner_acquire_host_ns "
                  "context owner_context owner_stage_at_attempt owner_stage_elapsed_at_attempt_ns "
                  "longest_stage longest_stage_ns caller owner_caller "
                  "guest_pc_start guest_pc_end owner_guest_pc_start\n";
            for (const auto &event : bql_trace) {
                os << event.sequence << " "
                   << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << BqlTraceEventName(event.event_type) << " "
                   << event.thread_id << " "
                   << event.cpu_index << " "
                   << event.wait_ns << " "
                   << event.held_ns << " "
                   << event.owner_thread_id << " "
                   << event.owner_cpu_index << " "
                   << event.owner_held_at_attempt_ns << " "
                   << event.owner_acquire_host_ns << " "
                   << BqlTraceContextName(event.caller_context) << " "
                   << BqlTraceContextName(event.owner_context) << " "
                   << BqlTraceStageName(event.owner_stage_at_attempt) << " "
                   << event.owner_stage_elapsed_at_attempt_ns << " "
                   << BqlTraceStageName(event.longest_stage) << " "
                   << event.longest_stage_ns << " "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << " "
                   << (event.owner_caller_file[0]
                           ? event.owner_caller_file : "<unknown>")
                   << ":" << event.owner_caller_line << " ";
                if (event.guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.guest_pc_end_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_end << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.owner_guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.owner_guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::MainLoop)) {
        os << "QEMU Main Loop Lock Ownership Trace\n----------------------------------------\n";
        XemuDiagnosticsMainLoopLockTraceStatus main_loop_lock_status{};
        xemu_diagnostics_get_main_loop_lock_trace_status(&main_loop_lock_status);
        os << "Trace enabled: " << main_loop_lock_status.enabled << "\n";
        os << "Buffered events: " << main_loop_lock_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK) << "\n";
        os << "Total events: " << main_loop_lock_status.total_events << "\n";
        os << "Overwritten events: " << main_loop_lock_status.overwritten_events << "\n";
        os << "Long wait/hold threshold ns: " << main_loop_lock_status.long_wait_threshold_ns << "\n";
        os << "Current owner TID/CPU/held ns: "
           << main_loop_lock_status.current_owner_thread_id << "/"
           << main_loop_lock_status.current_owner_cpu_index << "/"
           << main_loop_lock_status.current_owner_held_ns << "\n";
        os << "Current owner acquisition: "
           << (main_loop_lock_status.current_owner_caller_file[0]
                   ? main_loop_lock_status.current_owner_caller_file : "<unknown>")
           << ":" << main_loop_lock_status.current_owner_caller_line << "\n";
        os << "Current owner context: "
           << BqlTraceContextName(main_loop_lock_status.current_owner_context) << "\n";
        os << "Current owner stage/elapsed ns: "
           << BqlTraceStageName(main_loop_lock_status.current_owner_stage) << "/"
           << main_loop_lock_status.current_owner_stage_elapsed_ns << "\n";
        if (main_loop_lock_status.current_owner_guest_pc_valid) {
            os << "Current owner guest PC: 0x" << std::hex << std::uppercase
               << std::setw(16) << std::setfill('0')
               << main_loop_lock_status.current_owner_guest_pc;
            AppendGuestPcLabel(os, main_loop_lock_status.current_owner_guest_pc);
            os << std::dec << std::setfill(' ') << "\n";
        }
        if (main_loop_lock_status.count != 0) {
            std::vector<XemuDiagnosticsMainLoopLockTraceEvent> main_loop_lock_trace(main_loop_lock_status.count);
            const size_t main_loop_lock_count =
                xemu_diagnostics_get_main_loop_lock_trace(main_loop_lock_trace.data(), main_loop_lock_trace.size());
            main_loop_lock_trace.resize(main_loop_lock_count);
            const MainLoopLockTraceAnalysis analysis = AnalyzeMainLoopLockTrace(main_loop_lock_trace);
            os << "Analysis:\n";
            os << "  Worst qemu_main_loop_lock wait ns: " << analysis.worst_wait_ns << "\n";
            if (analysis.have_worst_wait) {
                const auto &event = analysis.worst_wait;
                os << "  Worst wait waiter TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst wait callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Blocking owner TID/CPU: " << event.owner_thread_id << "/"
                   << event.owner_cpu_index << "\n";
                os << "  Owner already held at wait attempt ns: "
                   << event.owner_held_at_attempt_ns << "\n";
                os << "  Owner acquisition callsite: "
                   << (event.owner_caller_file[0]
                           ? event.owner_caller_file : "<unknown>")
                   << ":" << event.owner_caller_line << "\n";
                os << "  Waiter context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Blocking owner context: "
                   << BqlTraceContextName(event.owner_context) << "\n";
                os << "  Blocking owner stage at wait: "
                   << BqlTraceStageName(event.owner_stage_at_attempt)
                   << " (elapsed ns=" << event.owner_stage_elapsed_at_attempt_ns
                   << ")\n";
                if (event.owner_guest_pc_start_valid) {
                    os << "  Owner guest PC at acquisition: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.owner_guest_pc_start << std::dec << "\n";
                }
            }
            os << "  Longest qemu_main_loop_lock hold overlapping worst wait ns: "
               << analysis.longest_overlapping_hold_ns << "\n";
            if (analysis.have_overlapping_hold) {
                const auto &event = analysis.overlapping_hold;
                os << "  Overlapping holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Overlapping holder acquisition callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Overlapping holder context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Overlapping holder longest stage: "
                   << BqlTraceStageName(event.longest_stage)
                   << " (ns=" << event.longest_stage_ns << ")\n";
                if (event.guest_pc_start_valid) {
                    os << "  Overlapping holder guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Overlapping holder guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
            }
            os << "  Worst qemu_main_loop_lock hold ns: " << analysis.worst_hold_ns << "\n";
            if (analysis.have_worst_hold) {
                const auto &event = analysis.worst_hold;
                os << "  Worst holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst hold acquisition callsite: "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << "\n";
                os << "  Worst hold context: "
                   << BqlTraceContextName(event.caller_context) << "\n";
                os << "  Worst hold longest stage: "
                   << BqlTraceStageName(event.longest_stage)
                   << " (ns=" << event.longest_stage_ns << ")\n";
                if (event.guest_pc_start_valid) {
                    os << "  Holder guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Holder guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
            }
            os << "Columns: seq qemu_ns host_ns event tid cpu wait_ns hold_ns "
                  "owner_tid owner_cpu owner_held_at_attempt_ns owner_acquire_host_ns "
                  "context owner_context owner_stage_at_attempt owner_stage_elapsed_at_attempt_ns "
                  "longest_stage longest_stage_ns caller owner_caller "
                  "guest_pc_start guest_pc_end owner_guest_pc_start\n";
            for (const auto &event : main_loop_lock_trace) {
                os << event.sequence << " "
                   << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << MainLoopLockTraceEventName(event.event_type) << " "
                   << event.thread_id << " "
                   << event.cpu_index << " "
                   << event.wait_ns << " "
                   << event.held_ns << " "
                   << event.owner_thread_id << " "
                   << event.owner_cpu_index << " "
                   << event.owner_held_at_attempt_ns << " "
                   << event.owner_acquire_host_ns << " "
                   << BqlTraceContextName(event.caller_context) << " "
                   << BqlTraceContextName(event.owner_context) << " "
                   << BqlTraceStageName(event.owner_stage_at_attempt) << " "
                   << event.owner_stage_elapsed_at_attempt_ns << " "
                   << BqlTraceStageName(event.longest_stage) << " "
                   << event.longest_stage_ns << " "
                   << (event.caller_file[0] ? event.caller_file : "<unknown>")
                   << ":" << event.caller_line << " "
                   << (event.owner_caller_file[0]
                           ? event.owner_caller_file : "<unknown>")
                   << ":" << event.owner_caller_line << " ";
                if (event.guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.guest_pc_end_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_end << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.owner_guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.owner_guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Mmio)) {
        os << "MMIO Dispatch Trace\n----------------------------------------\n";
        XemuDiagnosticsMmioTraceStatus mmio_status{};
        xemu_diagnostics_get_mmio_trace_status(&mmio_status);
        os << "Trace enabled: " << mmio_status.enabled << "\n";
        os << "Buffered events: " << mmio_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_MMIO) << "\n";
        os << "Total events: " << mmio_status.total_events << "\n";
        os << "Overwritten events: " << mmio_status.overwritten_events << "\n";
        os << "Long dispatch threshold ns: "
           << mmio_status.long_dispatch_threshold_ns << "\n";
        if (mmio_status.count != 0) {
            std::vector<XemuDiagnosticsMmioTraceEvent> mmio_trace(mmio_status.count);
            const size_t mmio_count =
                xemu_diagnostics_get_mmio_trace(mmio_trace.data(), mmio_trace.size());
            mmio_trace.resize(mmio_count);
            const MmioTraceAnalysis analysis = AnalyzeMmioTrace(mmio_trace);
            os << "Analysis:\n";
            os << "  Worst MMIO dispatch host ns: " << analysis.worst_host_ns << "\n";
            os << "  Worst MMIO dispatch virtual ns: " << analysis.worst_virtual_ns << "\n";
            if (analysis.have_worst) {
                const auto &event = analysis.worst;
                os << "  Worst MMIO access: " << MmioAccessName(event.access_type)
                   << " size=" << event.size << "\n";
                os << "  Worst MMIO TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                if (event.guest_pc_start_valid) {
                    os << "  Worst MMIO guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Worst MMIO guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
                os << "  Worst MMIO guest VA/PA: 0x" << std::hex
                   << std::uppercase << std::setw(16) << std::setfill('0')
                   << event.guest_vaddr << "/0x" << std::setw(16)
                   << event.guest_paddr << std::dec << "\n";
                os << "  Worst MMIO MemoryRegion: " << event.region_name
                   << " + 0x" << std::hex << std::uppercase
                   << event.region_offset << std::dec << "\n";
                os << "  Worst MMIO owner type: " << event.owner_type << "\n";
            }
            os << "Columns: seq qemu_start_ns qemu_end_ns host_start_ns host_end_ns "
                  "host_duration_ns virtual_duration_ns op tid cpu size guest_pc_start "
                  "guest_pc_end guest_va guest_pa region_offset region owner_type\n";
            for (const auto &event : mmio_trace) {
                os << event.sequence << " "
                   << event.qemu_virtual_start_ns << " "
                   << event.qemu_virtual_end_ns << " "
                   << event.host_start_ns << " "
                   << event.host_end_ns << " "
                   << event.duration_host_ns << " "
                   << event.duration_virtual_ns << " "
                   << MmioAccessName(event.access_type) << " "
                   << event.thread_id << " "
                   << event.cpu_index << " "
                   << event.size << " ";
                if (event.guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.guest_pc_end_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_end << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " 0x" << std::hex << std::uppercase << std::setw(16)
                   << std::setfill('0') << event.guest_vaddr
                   << " 0x" << std::setw(16) << event.guest_paddr
                   << " 0x" << event.region_offset << std::dec
                   << " " << event.region_name
                   << " " << event.owner_type << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::PgraphLock)) {
        os << "PGRAPH Lock Ownership Trace\n----------------------------------------\n";
        XemuDiagnosticsPgraphLockTraceStatus pgraph_lock_status{};
        xemu_diagnostics_get_pgraph_lock_trace_status(&pgraph_lock_status);
        os << "Trace enabled: " << pgraph_lock_status.enabled << "\n";
        os << "Buffered events: " << pgraph_lock_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_LOCK) << "\n";
        os << "Total events: " << pgraph_lock_status.total_events << "\n";
        os << "Overwritten events: " << pgraph_lock_status.overwritten_events << "\n";
        os << "Long wait/hold threshold ns: "
           << pgraph_lock_status.long_wait_threshold_ns << "\n";
        os << "Current owner TID/CPU/held ns: "
           << pgraph_lock_status.current_owner_thread_id << "/"
           << pgraph_lock_status.current_owner_cpu_index << "/"
           << pgraph_lock_status.current_owner_held_ns << "\n";
        os << "Current owner acquisition: "
           << (pgraph_lock_status.current_owner_acquire_file[0]
                   ? pgraph_lock_status.current_owner_acquire_file : "<unknown>")
           << ":" << pgraph_lock_status.current_owner_acquire_line << "\n";
        os << "Current owner method: "
           << FormatPgraphMethod(pgraph_lock_status.current_owner_method) << "\n";
        if (pgraph_lock_status.current_owner_guest_pc_valid) {
            os << "Current owner guest PC: 0x" << std::hex << std::uppercase
               << std::setw(16) << std::setfill('0')
               << pgraph_lock_status.current_owner_guest_pc;
            AppendGuestPcLabel(os, pgraph_lock_status.current_owner_guest_pc);
            os << std::dec << std::setfill(' ') << "\n";
        }
        if (pgraph_lock_status.count != 0) {
            std::vector<XemuDiagnosticsPgraphLockTraceEvent> pgraph_trace(
                pgraph_lock_status.count);
            const size_t pgraph_count = xemu_diagnostics_get_pgraph_lock_trace(
                pgraph_trace.data(), pgraph_trace.size());
            pgraph_trace.resize(pgraph_count);
            const PgraphLockTraceAnalysis analysis =
                AnalyzePgraphLockTrace(pgraph_trace);
            os << "Analysis:\n";
            os << "  Worst PGRAPH lock wait ns: " << analysis.worst_wait_ns << "\n";
            if (analysis.have_worst_wait) {
                const auto &event = analysis.worst_wait;
                os << "  Worst wait waiter TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst wait acquisition callsite: "
                   << (event.acquire_file[0] ? event.acquire_file : "<unknown>")
                   << ":" << event.acquire_line << "\n";
                os << "  Blocking owner TID/CPU: " << event.owner_thread_id << "/"
                   << event.owner_cpu_index << "\n";
                os << "  Owner already held at wait attempt ns: "
                   << event.owner_held_at_attempt_ns << "\n";
                os << "  Owner acquisition callsite: "
                   << (event.owner_acquire_file[0]
                           ? event.owner_acquire_file : "<unknown>")
                   << ":" << event.owner_acquire_line << "\n";
                os << "  Owner method at wait attempt: "
                   << FormatPgraphMethod(event.owner_method) << "\n";
                if (event.owner_guest_pc_start_valid) {
                    os << "  Owner guest PC at acquisition: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.owner_guest_pc_start << std::dec << "\n";
                }
            }
            os << "  Longest PGRAPH hold overlapping worst wait ns: "
               << analysis.longest_overlapping_hold_ns << "\n";
            if (analysis.have_overlapping_hold) {
                const auto &event = analysis.overlapping_hold;
                os << "  Overlapping holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Overlapping holder acquire/release: "
                   << (event.acquire_file[0] ? event.acquire_file : "<unknown>")
                   << ":" << event.acquire_line << " -> "
                   << (event.release_file[0] ? event.release_file : "<unknown>")
                   << ":" << event.release_line << "\n";
                os << "  Overlapping holder method: "
                   << FormatPgraphMethod(event.method) << "\n";
                os << "  Overlapping holder renderer/state: " << event.state.renderer
                   << " wait=" << event.state.waiting_for_nop << "/"
                   << event.state.waiting_for_flip << "/"
                   << event.state.waiting_for_context_switch
                   << " flush=" << event.state.flush_pending
                   << " sync=" << event.state.sync_pending
                   << " primitive=0x" << std::hex << std::uppercase
                   << event.state.primitive_mode << std::dec << "\n";
            }
            os << "  Worst PGRAPH lock hold ns: " << analysis.worst_hold_ns << "\n";
            if (analysis.have_worst_hold) {
                const auto &event = analysis.worst_hold;
                os << "  Worst holder TID/CPU: " << event.thread_id << "/"
                   << event.cpu_index << "\n";
                os << "  Worst hold acquire/release: "
                   << (event.acquire_file[0] ? event.acquire_file : "<unknown>")
                   << ":" << event.acquire_line << " -> "
                   << (event.release_file[0] ? event.release_file : "<unknown>")
                   << ":" << event.release_line << "\n";
                os << "  Worst holder method: " << FormatPgraphMethod(event.method)
                   << "\n";
                os << "  Worst holder renderer/state: " << event.state.renderer
                   << " wait=" << event.state.waiting_for_nop << "/"
                   << event.state.waiting_for_flip << "/"
                   << event.state.waiting_for_context_switch
                   << " flush=" << event.state.flush_pending
                   << " sync=" << event.state.sync_pending
                   << " primitive=0x" << std::hex << std::uppercase
                   << event.state.primitive_mode << std::dec << "\n";
                if (event.guest_pc_start_valid) {
                    os << "  Worst holder guest PC start: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_start << std::dec << "\n";
                }
                if (event.guest_pc_end_valid) {
                    os << "  Worst holder guest PC end: 0x" << std::hex
                       << std::uppercase << std::setw(16) << std::setfill('0')
                       << event.guest_pc_end << std::dec << "\n";
                }
            }
            os << "Columns: seq qemu_ns host_ns event tid cpu wait_ns hold_ns "
                  "owner_tid owner_cpu owner_held_at_attempt_ns owner_acquire_host_ns "
                  "acquire release owner_acquire guest_pc_start guest_pc_end "
                  "owner_guest_pc_start method_valid method_active subch class method "
                  "parameter owner_method_valid owner_method_active owner_subch "
                  "owner_class owner_method owner_parameter pending enabled primitive "
                  "wait_nop wait_flip wait_context flush sync renderer\n";
            for (const auto &event : pgraph_trace) {
                os << event.sequence << " "
                   << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << PgraphLockTraceEventName(event.event_type) << " "
                   << event.thread_id << " "
                   << event.cpu_index << " "
                   << event.wait_ns << " "
                   << event.held_ns << " "
                   << event.owner_thread_id << " "
                   << event.owner_cpu_index << " "
                   << event.owner_held_at_attempt_ns << " "
                   << event.owner_acquire_host_ns << " "
                   << (event.acquire_file[0] ? event.acquire_file : "<unknown>")
                   << ":" << event.acquire_line << " "
                   << (event.release_file[0] ? event.release_file : "<n/a>")
                   << ":" << event.release_line << " "
                   << (event.owner_acquire_file[0]
                           ? event.owner_acquire_file : "<n/a>")
                   << ":" << event.owner_acquire_line << " ";
                if (event.guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.guest_pc_end_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.guest_pc_end << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " ";
                if (event.owner_guest_pc_start_valid) {
                    os << "0x" << std::hex << std::uppercase << std::setw(16)
                       << std::setfill('0') << event.owner_guest_pc_start << std::dec;
                } else {
                    os << "<n/a>";
                }
                os << " " << event.method.valid
                   << " " << event.method.active
                   << " " << event.method.subchannel
                   << " 0x" << std::hex << std::uppercase << event.method.graphics_class
                   << " 0x" << event.method.method
                   << " 0x" << event.method.parameter << std::dec
                   << " " << event.owner_method.valid
                   << " " << event.owner_method.active
                   << " " << event.owner_method.subchannel
                   << " 0x" << std::hex << std::uppercase
                   << event.owner_method.graphics_class
                   << " 0x" << event.owner_method.method
                   << " 0x" << event.owner_method.parameter
                   << " 0x" << event.state.pending_interrupts
                   << " 0x" << event.state.enabled_interrupts
                   << " 0x" << event.state.primitive_mode << std::dec
                   << " " << event.state.waiting_for_nop
                   << " " << event.state.waiting_for_flip
                   << " " << event.state.waiting_for_context_switch
                   << " " << event.state.flush_pending
                   << " " << event.state.sync_pending
                   << " " << event.state.renderer << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::DrawStages)) {
        os << "PGRAPH Draw-End Stage Trace\n----------------------------------------\n";
        XemuDiagnosticsPgraphDrawTraceStatus pgraph_draw_status{};
        xemu_diagnostics_get_pgraph_draw_trace_status(&pgraph_draw_status);
        os << "Trace enabled: " << pgraph_draw_status.enabled << "\n";
        os << "Buffered events: " << pgraph_draw_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_PGRAPH_DRAW) << "\n";
        os << "Total events: " << pgraph_draw_status.total_events << "\n";
        os << "Overwritten events: " << pgraph_draw_status.overwritten_events << "\n";
        os << "Retained long draws: " << pgraph_draw_status.retained_draws << "\n";
        os << "Retained draws with omitted detail stages: "
           << pgraph_draw_status.truncated_draws << "\n";
        os << "Detail coverage: at most 48 stage records per draw; omitted children do not affect independent PFIFO aggregates. Use DRAW_STAGE and VERTEX_METRICS for full per-run accounting.\n";
        os << "Long draw threshold ns: "
           << pgraph_draw_status.long_draw_threshold_ns << "\n";
        if (pgraph_draw_status.count != 0) {
            std::vector<XemuDiagnosticsPgraphDrawTraceEvent> pgraph_draw_trace(
                pgraph_draw_status.count);
            const size_t pgraph_draw_count = xemu_diagnostics_get_pgraph_draw_trace(
                pgraph_draw_trace.data(), pgraph_draw_trace.size());
            pgraph_draw_trace.resize(pgraph_draw_count);
            const PgraphDrawTraceAnalysis analysis =
                AnalyzePgraphDrawTrace(pgraph_draw_trace);
            os << "Analysis:\n";
            os << "  Worst SET_BEGIN_END(END) host ns: "
               << analysis.worst_draw_ns << "\n";
            if (analysis.have_worst_draw) {
                const auto &event = analysis.worst_draw;
                os << "  Worst draw id/TID/CPU: " << event.draw_id << "/"
                   << event.thread_id << "/" << event.cpu_index << "\n";
                os << "  Worst draw path/primitive: "
                   << PgraphDrawTracePathName(event.path) << "/0x"
                   << std::hex << std::uppercase << event.primitive_mode
                   << std::dec << "\n";
                os << "  Worst draw counts arrays/max/elements/buffer/inline-array: "
                   << event.draw_arrays_length << "/"
                   << event.draw_arrays_max_count << "/"
                   << event.inline_elements_length << "/"
                   << event.inline_buffer_length << "/"
                   << event.inline_array_length << "\n";
                os << "  Worst draw renderer/state zquery/flush/sync: "
                   << event.renderer << " " << event.zpass_pixel_count_enable
                   << "/" << event.flush_pending << "/" << event.sync_pending
                   << "\n";
                os << "  Worst draw stage breakdown:\n";
                for (const auto &stage : pgraph_draw_trace) {
                    if (stage.draw_id != event.draw_id) {
                        continue;
                    }
                    os << "    " << PgraphDrawTraceStageName(stage.stage)
                       << ": " << stage.duration_host_ns << " ns"
                       << " (virtual " << stage.duration_virtual_ns << " ns)"
                       << " value0=" << stage.value0
                       << " value1=" << stage.value1 << "\n";
                }
            }
            os << "  Worst individual child stage host ns: "
               << analysis.worst_stage_ns << "\n";
            if (analysis.have_worst_stage) {
                os << "  Worst individual child stage: draw="
                   << analysis.worst_stage.draw_id << " "
                   << PgraphDrawTraceStageName(analysis.worst_stage.stage)
                   << " path="
                   << PgraphDrawTracePathName(analysis.worst_stage.path)
                   << "\n";
            }
            os << "Columns: seq draw_id qemu_start_ns qemu_end_ns host_start_ns "
                  "host_end_ns host_duration_ns virtual_duration_ns stage tid cpu "
                  "path primitive draw_arrays_length draw_arrays_max_count "
                  "inline_elements_length inline_buffer_length inline_array_length "
                  "zquery flush sync value0 value1 renderer\n";
            for (const auto &event : pgraph_draw_trace) {
                os << event.sequence << " "
                   << event.draw_id << " "
                   << event.qemu_virtual_start_ns << " "
                   << event.qemu_virtual_end_ns << " "
                   << event.host_start_ns << " "
                   << event.host_end_ns << " "
                   << event.duration_host_ns << " "
                   << event.duration_virtual_ns << " "
                   << PgraphDrawTraceStageName(event.stage) << " "
                   << event.thread_id << " "
                   << event.cpu_index << " "
                   << PgraphDrawTracePathName(event.path) << " "
                   << "0x" << std::hex << std::uppercase << event.primitive_mode
                   << std::dec << " "
                   << event.draw_arrays_length << " "
                   << event.draw_arrays_max_count << " "
                   << event.inline_elements_length << " "
                   << event.inline_buffer_length << " "
                   << event.inline_array_length << " "
                   << event.zpass_pixel_count_enable << " "
                   << event.flush_pending << " "
                   << event.sync_pending << " "
                   << event.value0 << " "
                   << event.value1 << " "
                   << event.renderer << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::ControllerXid)) {
        os << "Controller / XID / OHCI USB Reconnect Trace\n----------------------------------------\n";
        XemuDiagnosticsControllerXidTraceStatus controller_xid_status{};
        xemu_diagnostics_get_controller_xid_trace_status(&controller_xid_status);
        os << "Trace enabled: " << controller_xid_status.enabled << "\n";
        os << "Buffered events: " << controller_xid_status.count << " / " << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_CONTROLLER_XID) << "\n";
        os << "Stored events: " << controller_xid_status.stored_events << "\n";
        os << "Total observations: " << controller_xid_status.total_observations << "\n";
        os << "Overwritten events: " << controller_xid_status.overwritten_events << "\n";
        os << "Observation counters:\n";
        for (uint32_t type = 1; type < XEMU_DIAG_CONTROLLER_XID_EVENT_COUNT; ++type) {
            os << "  " << ControllerXidTraceEventName(type) << ": "
               << controller_xid_status.observations[type] << "\n";
        }
        if (controller_xid_status.count != 0) {
            std::vector<XemuDiagnosticsControllerXidTraceEvent> trace(
                controller_xid_status.count);
            const size_t count = xemu_diagnostics_get_controller_xid_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Columns: seq virtual_ns host_ns event port sdl_id xid_device "
                  "host_buttons host_axes[6] xid_buttons analog[8] sticks[4] "
                  "value0 value1 value2 value3 value4 report_hex save name guid\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.qemu_virtual_ns << " "
                   << event.host_ns << " "
                   << ControllerXidTraceEventName(event.event_type) << " "
                   << event.port << " " << event.instance_id << " 0x"
                   << std::hex << std::uppercase << event.xid_device << std::dec
                   << " 0x" << std::hex << std::uppercase << event.host_buttons
                   << std::dec;
                for (int axis : event.host_axis) {
                    os << " " << axis;
                }
                os << " 0x" << std::hex << std::uppercase << event.xid_buttons
                   << std::dec;
                for (unsigned analog : event.xid_analog) {
                    os << " " << analog;
                }
                os << " " << event.thumb_lx << " " << event.thumb_ly
                   << " " << event.thumb_rx << " " << event.thumb_ry
                   << " " << event.value0 << " " << event.value1
                   << " " << event.value2 << " " << event.value3
                   << " " << event.value4 << " " << ControllerXidReportHex(event)
                   << " " << event.save_binding << " \"" << event.name
                   << "\" \"" << event.guid << "\"\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::GuestInput)) {
        os << "Guest Input Consumer Candidate Trace (TCG)\n"
              "----------------------------------------\n";
        XemuDiagnosticsGuestInputConsumerTraceStatus status{};
        xemu_diagnostics_get_guest_input_consumer_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Capture active: " << status.capture_active << "\n";
        os << "Capture window ns: "
           << XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_WINDOW_NS << "\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(
                  XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER) << "\n";
        os << "Total / overwritten events: " << status.total_events << " / "
           << status.overwritten_events << "\n";
        os << "Meaningful report changes: " << status.report_changes << "\n";
        os << "Title TB candidates: " << status.title_tb_candidates << "\n";
        os << "Dropped candidates: " << status.dropped_candidates << "\n";
        os << "Current report sequence: " << status.current_report_sequence
           << "\n";
        os << "Last report virtual ns: " << status.last_report_virtual_ns
           << "\n";
        if (status.count != 0) {
            std::vector<XemuDiagnosticsGuestInputConsumerTraceEvent> trace(
                status.count);
            const size_t count = xemu_diagnostics_get_guest_input_consumer_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Columns: seq virtual_ns host_ns report_seq event guest_pc "
                  "age_since_report_ns candidate_ordinal guest_addr0 guest_len0 "
                  "guest_addr1 guest_len1 report_hex\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.qemu_virtual_ns << " "
                   << event.host_ns << " " << event.report_sequence << " "
                   << GuestInputConsumerEventName(event.event_type) << " "
                   << "0x" << std::hex << std::uppercase << event.guest_pc
                   << std::dec << " " << event.age_since_report_ns << " "
                   << event.candidate_ordinal << " 0x" << std::hex
                   << std::uppercase << event.guest_address0 << std::dec << " "
                   << event.guest_length0 << " 0x" << std::hex
                   << std::uppercase << event.guest_address1 << std::dec << " "
                   << event.guest_length1 << " "
                   << GuestInputConsumerReportHex(event) << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::GuestTimer)) {
        os << "Guest Timer / Deadline Correlation Trace (TCG, current research preset)\n"
              "----------------------------------------\n";
        XemuDiagnosticsGuestTimerDeadlineTraceStatus status{};
        xemu_diagnostics_get_guest_timer_deadline_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Watched pages: 000D7000 and 00216000; 00223000 from 2 ms before D7EA0 due until entry/overdue\n";
        os << "Buffered events: " << status.count << " / "
           << DiagnosticsBufferCapacity(XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE)
           << "\n";
        os << "Total / overwritten events: " << status.total_events << " / "
           << status.overwritten_events << "\n";
        os << "Input / D3D sequences: " << status.input_sequences << " / "
           << status.deadline_sequences << "\n";
        os << "D3D valid / reject: " << status.deadline_valid << " / "
           << status.deadline_rejects << "\n";
        os << "Last deadline delta cycles/us: "
           << status.last_deadline_delta_cycles << " / " << std::fixed
           << std::setprecision(3)
           << GuestTimerCyclesToUs(status.last_deadline_delta_cycles) << "\n";
        os << "Worst late deadline cycles/us: "
           << status.worst_late_delta_cycles << " / "
           << GuestTimerCyclesToUs(status.worst_late_delta_cycles) << "\n";
        os << std::defaultfloat;
        os << "D7EA0 schedule / return: " << status.callback_schedule_attempts
           << " / " << status.callback_schedule_returns << "\n";
        os << "D7EA0 entry / return: " << status.callback_entries << " / "
           << status.callback_returns << "\n";
        os << "Callback overdue / next InputBuffer: "
           << status.callback_overdue_events << " / "
           << status.callback_next_input_entries << "\n";
        os << "D3D dispatcher attempts / PC events: "
           << status.dispatcher_attempts << " / "
           << status.dispatcher_pc_events << "\n";
        os << "D3D dispatcher good / overdue / recovered-overdue: "
           << status.dispatcher_successful_attempts << " / "
           << status.dispatcher_overdue_attempts << " / "
           << status.dispatcher_recovered_overdue_attempts << "\n";
        os << "D3D dispatcher PC counts current/good/overdue/recovered: "
           << status.dispatcher_current_pc_events << "/"
           << status.dispatcher_last_good_pc_events << "/"
           << status.dispatcher_last_overdue_pc_events << "/"
           << status.dispatcher_last_recovered_pc_events << "\n";
        os << "Callback watch armed/overdue/input: "
           << status.callback_watch_armed << "/"
           << status.callback_overdue_latched << "/"
           << status.callback_watch_input_sequence << "\n";
        os << "Callback schedule/due/relative: "
           << status.callback_schedule_virtual_ns << "/"
           << status.callback_expected_due_ns << "/"
           << status.callback_relative_delay_cycles << "\n";
        os << "Callback target/return/raw-EAX/result-valid: 0x" << std::hex
           << std::uppercase << status.callback_target << "/0x"
           << status.callback_return_pc << "/0x"
           << status.callback_schedule_result_eax << std::dec << "/"
           << status.callback_schedule_result_valid << "\n";
        os << "Callback last due delta ns/ms: " << status.callback_last_delta_ns
           << " / " << std::fixed << std::setprecision(3)
           << (double)status.callback_last_delta_ns / 1000000.0 << "\n";
        os << std::defaultfloat;
        if (status.count != 0) {
            std::vector<XemuDiagnosticsGuestTimerDeadlineTraceEvent> trace(
                status.count);
            const size_t count = xemu_diagnostics_get_guest_timer_deadline_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Columns: seq virtual_ns host_ns input_seq deadline_seq event pc "
                  "age_since_input_ns eax ebx ecx edx esi edi esp ebp eflags "
                  "mem_valid mem_1a80 mem_1a84 mem_1a90 mem_1a94 stack14 stack18 "
                  "stack20 derived_valid nominal_interval lateness calculated_interval "
                  "current_tsc requested_deadline threshold deadline_delta_cycles "
                  "deadline_delta_us relative_delay callback_due_ns callback_delta_ns "
                  "callback_target callback_return_pc schedule_result_eax callback_flags\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.qemu_virtual_ns << " "
                   << event.host_ns << " " << event.input_sequence << " "
                   << event.deadline_sequence << " "
                   << GuestTimerDeadlineEventName(event.event_type) << " 0x"
                   << std::hex << std::uppercase << event.guest_pc << std::dec
                   << " " << event.age_since_input_ns
                   << " 0x" << std::hex << std::uppercase << event.eax
                   << " 0x" << event.ebx << " 0x" << event.ecx
                   << " 0x" << event.edx << " 0x" << event.esi
                   << " 0x" << event.edi << " 0x" << event.esp
                   << " 0x" << event.ebp << " 0x" << event.eflags
                   << " 0x" << event.memory_valid_mask
                   << " 0x" << event.mem_1a80 << " 0x" << event.mem_1a84
                   << " 0x" << event.mem_1a90 << " 0x" << event.mem_1a94
                   << " 0x" << event.stack_14 << " 0x" << event.stack_18
                   << " 0x" << event.stack_20
                   << " 0x" << event.derived_valid_mask << std::dec
                   << " " << event.nominal_interval
                   << " " << event.accumulated_lateness
                   << " " << event.calculated_interval
                   << " " << event.current_tsc
                   << " " << event.requested_deadline
                   << " " << event.deadline_threshold
                   << " " << event.deadline_delta_cycles << " "
                   << std::fixed << std::setprecision(3)
                   << GuestTimerCyclesToUs(event.deadline_delta_cycles)
                   << std::defaultfloat << " " << event.relative_delay << " "
                   << event.callback_expected_due_ns << " "
                   << event.callback_delta_ns << " 0x" << std::hex
                   << std::uppercase << event.callback_target << " 0x"
                   << event.callback_return_pc << " 0x"
                   << event.schedule_result_eax << " 0x"
                   << event.callback_flags << std::dec << "\n";
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::D3dTimerState)) {
        os << "D3D Timer Record / List State Trace (Patch 305.3)\n"
              "----------------------------------------\n";
        XemuDiagnosticsD3dTimerStateStatus status{};
        xemu_diagnostics_get_d3d_timer_state_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Buffered / total / overwritten snapshots: " << status.count
           << " / " << status.total_events << " / "
           << status.overwritten_events << "\n";
        os << "Current timer object / input / D3D sequence: 0x" << std::hex
           << std::uppercase << status.current_timer_object << std::dec << " / "
           << status.current_input_sequence << " / "
           << status.current_deadline_sequence << "\n";
        os << "Current exact probes / cap: " << status.current_probe_count
           << " / " << status.max_probes_per_cycle << "\n";
        os << "Schedule baseline / last-good baseline valid: "
           << status.schedule_snapshot_valid << " / "
           << status.last_good_snapshot_valid << "\n";
        os << "Completed-good / overdue / rejected cycles: "
           << status.completed_good_cycles << " / " << status.overdue_cycles
           << " / " << status.rejected_cycles << "\n";
        if (status.count != 0) {
            std::vector<XemuDiagnosticsD3dTimerStateEvent> trace(status.count);
            const size_t count = xemu_diagnostics_get_d3d_timer_state_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Snapshot header: seq virtual_ns host_ns input_seq D3D_seq event "
                  "pc object read_valid changed_from_schedule "
                  "changed_from_last_good\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.qemu_virtual_ns << " "
                   << event.host_ns << " " << event.input_sequence << " "
                   << event.deadline_sequence << " "
                   << D3dTimerStateEventName(event.event_type) << " 0x"
                   << std::hex << std::uppercase << event.guest_pc << " 0x"
                   << event.timer_object << std::dec << " " << event.read_valid
                   << " 0x" << std::hex << std::uppercase
                   << event.changed_from_schedule_mask << " 0x"
                   << event.changed_from_last_good_mask << std::dec << "\n";
                if (event.read_valid) {
                    os << std::hex << std::uppercase << std::setfill('0');
                    for (size_t i = 0;
                         i < XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS; i += 8) {
                        os << "  +" << std::setw(3) << (i * 4) << ":";
                        for (size_t j = 0; j < 8; ++j) {
                            os << " " << std::setw(8) << event.dwords[i + j];
                        }
                        os << "\n";
                    }
                    os << std::dec << std::setfill(' ');
                }
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::D3dCallback)) {
        os << "D3D InputBuffer Callback Dispatch Capture (pinned one-shot)\n"
              "----------------------------------------\n";
        XemuDiagnosticsD3dCallbackCaptureStatus status{};
        xemu_diagnostics_get_d3d_callback_capture_status(&status);
        os << "Capture enabled: " << status.enabled << "\n";
        os << "Latched / in progress: " << status.latched << " / "
           << status.capture_in_progress << "\n";
        os << "Capture count: " << status.capture_count << "\n";
        os << "Transient auto-rearms: " << status.transient_recoveries << "\n";
        os << "Last transient recovery virtual/delta ns: "
           << status.last_recovery_virtual_ns << "/"
           << status.last_recovery_delta_ns << "\n";
        os << "Overdue grace ns/ms: " << status.grace_ns << " / "
           << std::fixed << std::setprecision(3)
           << (double)status.grace_ns / 1000000.0 << "\n";
        os << std::defaultfloat;
        if (status.latched) {
            XemuDiagnosticsD3dCallbackCaptureSnapshot capture{};
            if (xemu_diagnostics_get_d3d_callback_capture(&capture)) {
                const auto &st = capture.status;
                const auto &t = st.trigger;
                os << "Trigger virtual ns: " << t.trigger_virtual_ns << "\n";
                os << "Trigger host ns: " << t.trigger_host_ns << "\n";
                os << "Trigger guest PC: 0x" << std::hex << std::uppercase
                   << t.trigger_guest_pc;
                AppendGuestPcLabel(os, t.trigger_guest_pc);
                os << std::dec << "\n";
                os << "Input / D3D sequence: " << t.input_sequence << " / "
                   << t.deadline_sequence << "\n";
                os << "Schedule virtual ns: " << t.schedule_virtual_ns << "\n";
                os << "Expected callback due ns: " << t.expected_due_ns << "\n";
                os << "Callback overdue ns/ms: " << t.overdue_ns << " / "
                   << std::fixed << std::setprecision(3)
                   << (double)t.overdue_ns / 1000000.0 << "\n";
                os << std::defaultfloat;
                os << "Relative delay cycles: " << t.relative_delay_cycles << "\n";
                os << "Callback target / learned return PC: 0x" << std::hex
                   << std::uppercase << t.callback_target;
                AppendGuestPcLabel(os, t.callback_target);
                os << " / 0x" << t.callback_return_pc;
                AppendGuestPcLabel(os, t.callback_return_pc);
                os << std::dec << "\n";
                os << "D3D schedule return observed/raw EAX: "
                   << t.schedule_result_valid << " / 0x" << std::hex
                   << std::uppercase << t.schedule_result_eax << std::dec << "\n";
                os << "Capture copy duration ns/ms: "
                   << st.capture_duration_host_ns << " / " << std::fixed
                   << std::setprecision(3)
                   << (double)st.capture_duration_host_ns / 1000000.0 << "\n";
                os << std::defaultfloat;
                os << "Pinned counts qtimer/bql/mainloop/pgraph/scheduler/guest: "
                   << st.qtimer_count << "/" << st.bql_count << "/"
                   << st.main_loop_lock_count << "/" << st.pgraph_count << "/"
                   << st.scheduler_count << "/" << st.guest_timer_count << "\n";
                os << "BQL owner TID/CPU/held_ns: "
                   << st.bql_status.current_owner_thread_id << "/"
                   << st.bql_status.current_owner_cpu_index << "/"
                   << st.bql_status.current_owner_held_ns << "\n";
                os << "Main-loop-lock owner TID/CPU/held_ns: "
                   << st.main_loop_lock_status.current_owner_thread_id << "/"
                   << st.main_loop_lock_status.current_owner_cpu_index << "/"
                   << st.main_loop_lock_status.current_owner_held_ns << "\n";
                os << "PGRAPH owner TID/CPU/held_ns: "
                   << st.pgraph_status.current_owner_thread_id << "/"
                   << st.pgraph_status.current_owner_cpu_index << "/"
                   << st.pgraph_status.current_owner_held_ns << "\n";
                os << "Scheduler active idle / last title PC / last IRQ: "
                   << st.scheduler_status.active_idle << " 0x" << std::hex
                   << std::uppercase << st.scheduler_status.last_title_pc << " 0x"
                   << st.scheduler_status.last_irq_source << std::dec << "\n";
                os << "Guest lifecycle schedule/return/entry/return/overdue/next: "
                   << st.guest_timer_status.callback_schedule_attempts << "/"
                   << st.guest_timer_status.callback_schedule_returns << "/"
                   << st.guest_timer_status.callback_entries << "/"
                   << st.guest_timer_status.callback_returns << "/"
                   << st.guest_timer_status.callback_overdue_events << "/"
                   << st.guest_timer_status.callback_next_input_entries << "\n\n";

                os << "Pinned QEMU Timer / Main-Loop Events\n";
                os << "Columns: seq virtual_ns host_ns event clock tid timeout_ns expire_ns timer_delta_ns wait_host_ns wait_virtual_ns dispatch_late_ns pending value\n";
                for (size_t i = 0; i < st.qtimer_count; ++i) {
                    const auto &e = capture.qtimer[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << QemuTimerTraceEventName(e.event_type) << " "
                       << e.clock_type << " " << e.thread_id << " " << e.timeout_ns
                       << " " << e.timer_expire_ns << " " << e.timer_delta_ns << " "
                       << e.wait_elapsed_host_ns << " " << e.wait_elapsed_virtual_ns
                       << " " << e.dispatch_late_ns << " " << e.watched_timer_pending
                       << " " << e.value << "\n";
                }

                os << "\nPinned BQL Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns context owner_context owner_stage caller owner_caller guest_pc_start guest_pc_end owner_guest_pc\n";
                for (size_t i = 0; i < st.bql_count; ++i) {
                    const auto &e = capture.bql[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << BqlTraceEventName(e.event_type) << " " << e.thread_id
                       << " " << e.cpu_index << " " << e.wait_ns << " " << e.held_ns
                       << " " << e.owner_thread_id << " " << e.owner_cpu_index << " "
                       << e.owner_held_at_attempt_ns << " "
                       << BqlTraceContextName(e.caller_context) << " "
                       << BqlTraceContextName(e.owner_context) << " "
                       << BqlTraceStageName(e.owner_stage_at_attempt) << " "
                       << (e.caller_file[0] ? e.caller_file : "<unknown>") << ":"
                       << e.caller_line << " "
                       << (e.owner_caller_file[0] ? e.owner_caller_file : "<unknown>")
                       << ":" << e.owner_caller_line << " 0x" << std::hex
                       << std::uppercase << e.guest_pc_start << " 0x" << e.guest_pc_end
                       << " 0x" << e.owner_guest_pc_start << std::dec << "\n";
                }

                os << "\nPinned QEMU Main Loop Lock Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns context owner_context owner_stage caller owner_caller guest_pc_start guest_pc_end owner_guest_pc\n";
                for (size_t i = 0; i < st.main_loop_lock_count; ++i) {
                    const auto &e = capture.main_loop_lock[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << MainLoopLockTraceEventName(e.event_type) << " "
                       << e.thread_id << " " << e.cpu_index << " " << e.wait_ns << " "
                       << e.held_ns << " " << e.owner_thread_id << " "
                       << e.owner_cpu_index << " " << e.owner_held_at_attempt_ns << " "
                       << BqlTraceContextName(e.caller_context) << " "
                       << BqlTraceContextName(e.owner_context) << " "
                       << BqlTraceStageName(e.owner_stage_at_attempt) << " "
                       << (e.caller_file[0] ? e.caller_file : "<unknown>") << ":"
                       << e.caller_line << " "
                       << (e.owner_caller_file[0] ? e.owner_caller_file : "<unknown>")
                       << ":" << e.owner_caller_line << " 0x" << std::hex
                       << std::uppercase << e.guest_pc_start << " 0x" << e.guest_pc_end
                       << " 0x" << e.owner_guest_pc_start << std::dec << "\n";
                }

                os << "\nPinned PGRAPH Lock Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns acquire release owner_acquire method class parameter waiting_nop waiting_flip waiting_context renderer\n";
                for (size_t i = 0; i < st.pgraph_count; ++i) {
                    const auto &e = capture.pgraph[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << PgraphLockTraceEventName(e.event_type) << " "
                       << e.thread_id << " " << e.cpu_index << " " << e.wait_ns << " "
                       << e.held_ns << " " << e.owner_thread_id << " "
                       << e.owner_cpu_index << " " << e.owner_held_at_attempt_ns << " "
                       << (e.acquire_file[0] ? e.acquire_file : "<unknown>") << ":"
                       << e.acquire_line << " "
                       << (e.release_file[0] ? e.release_file : "<unknown>") << ":"
                       << e.release_line << " "
                       << (e.owner_acquire_file[0] ? e.owner_acquire_file : "<unknown>")
                       << ":" << e.owner_acquire_line << " 0x" << std::hex
                       << std::uppercase << e.method.method << " 0x"
                       << e.method.graphics_class << " 0x" << e.method.parameter
                       << std::dec << " " << e.state.waiting_for_nop << " "
                       << e.state.waiting_for_flip << " "
                       << e.state.waiting_for_context_switch << " "
                       << e.state.renderer << "\n";
                }

                os << "\nPinned Scheduler / CPU Events\n";
                os << "Columns: seq virtual_ns host_ns event idle_age_ns duration_ns pc last_title_pc eflags ebx ebp esp irq exception cpu halted last_irq_source last_irq_age_ns ptimer_pending ptimer_enabled vblank_count ptimer_count pgraph_count pfifo_count ohci_count\n";
                for (size_t i = 0; i < st.scheduler_count; ++i) {
                    const auto &e = capture.scheduler[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << SchedulerTraceEventName(e.event_type) << " "
                       << e.idle_age_ns << " " << e.duration_ns << " 0x" << std::hex
                       << std::uppercase << e.guest_pc << " 0x" << e.last_title_pc
                       << " 0x" << e.eflags << " 0x" << e.ebx << " 0x" << e.ebp
                       << " 0x" << e.esp << " 0x" << e.interrupt_request << std::dec
                       << " " << e.exception_index << " " << e.cpu_index << " "
                       << e.halted << " " << e.last_irq_source << " "
                       << e.last_irq_age_ns << " " << e.ptimer_pending << " "
                       << e.ptimer_enabled << " " << e.idle_vblank_count << " "
                       << e.idle_ptimer_count << " " << e.idle_pgraph_count << " "
                       << e.idle_pfifo_count << " " << e.idle_ohci_count << "\n";
                }

                os << "\nPinned Guest Timer / Deadline / Callback Events\n";
                os << "Columns: seq virtual_ns host_ns input_seq deadline_seq event pc age_ns nominal lateness calculated relative callback_due_ns callback_delta_ns callback_target callback_return_pc schedule_result_eax callback_flags\n";
                for (size_t i = 0; i < st.guest_timer_count; ++i) {
                    const auto &e = capture.guest_timer[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << e.input_sequence << " " << e.deadline_sequence << " "
                       << GuestTimerDeadlineEventName(e.event_type) << " 0x" << std::hex
                       << std::uppercase << e.guest_pc << std::dec << " "
                       << e.age_since_input_ns << " " << e.nominal_interval << " "
                       << e.accumulated_lateness << " " << e.calculated_interval << " "
                       << e.relative_delay << " " << e.callback_expected_due_ns << " "
                       << e.callback_delta_ns << " 0x" << std::hex << std::uppercase
                       << e.callback_target << " 0x" << e.callback_return_pc << " 0x"
                       << e.schedule_result_eax << " 0x" << e.callback_flags
                       << std::dec << "\n";
                }
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::LateCapture)) {
        os << "PTIMER Late Callback Capture (pinned one-shot)\n"
              "----------------------------------------\n";
        XemuDiagnosticsPtimerLateCaptureStatus status{};
        xemu_diagnostics_get_ptimer_late_capture_status(&status);
        os << "Capture enabled: " << status.enabled << "\n";
        os << "Latched / in progress: " << status.latched << " / "
           << status.capture_in_progress << "\n";
        os << "Capture count: " << status.capture_count << "\n";
        os << "Threshold ns: " << status.threshold_ns << "\n";
        if (status.latched) {
            XemuDiagnosticsPtimerLateCaptureSnapshot capture{};
            if (xemu_diagnostics_get_ptimer_late_capture(&capture)) {
                const auto &st = capture.status;
                os << "Trigger virtual ns: " << st.trigger_virtual_ns << "\n";
                os << "Trigger host ns: " << st.trigger_host_ns << "\n";
                os << "Expected expiry ns: " << st.trigger_expire_ns << "\n";
                os << "Dispatch lateness ns/ms: " << st.trigger_late_ns << " / "
                   << std::fixed << std::setprecision(3)
                   << (double)st.trigger_late_ns / 1000000.0 << "\n";
                os << "Trigger thread id: " << st.trigger_thread_id << "\n";
                os << "Capture copy duration ns/ms: "
                   << st.capture_duration_host_ns << " / "
                   << (double)st.capture_duration_host_ns / 1000000.0 << "\n";
                os << std::defaultfloat;
                os << "Pinned counts qtimer/bql/mainloop/pgraph/scheduler/guest: "
                   << st.qtimer_count << "/" << st.bql_count << "/"
                   << st.main_loop_lock_count << "/" << st.pgraph_count << "/"
                   << st.scheduler_count << "/" << st.guest_timer_count << "\n";
                os << "BQL owner TID/CPU/held_ns: "
                   << st.bql_status.current_owner_thread_id << "/"
                   << st.bql_status.current_owner_cpu_index << "/"
                   << st.bql_status.current_owner_held_ns << "\n";
                os << "BQL owner callsite/context/stage: "
                   << (st.bql_status.current_owner_caller_file[0]
                           ? st.bql_status.current_owner_caller_file
                           : "<unknown>")
                   << ":" << st.bql_status.current_owner_caller_line << " "
                   << BqlTraceContextName(st.bql_status.current_owner_context) << " "
                   << BqlTraceStageName(st.bql_status.current_owner_stage) << "\n";
                os << "Main-loop-lock owner TID/CPU/held_ns: "
                   << st.main_loop_lock_status.current_owner_thread_id << "/"
                   << st.main_loop_lock_status.current_owner_cpu_index << "/"
                   << st.main_loop_lock_status.current_owner_held_ns << "\n";
                os << "PGRAPH owner TID/CPU/held_ns: "
                   << st.pgraph_status.current_owner_thread_id << "/"
                   << st.pgraph_status.current_owner_cpu_index << "/"
                   << st.pgraph_status.current_owner_held_ns << "\n";
                os << "PGRAPH owner callsite: "
                   << (st.pgraph_status.current_owner_acquire_file[0]
                           ? st.pgraph_status.current_owner_acquire_file
                           : "<unknown>")
                   << ":" << st.pgraph_status.current_owner_acquire_line << "\n";
                os << "Scheduler active idle / last title PC / last IRQ: "
                   << st.scheduler_status.active_idle << " 0x" << std::hex
                   << std::uppercase << st.scheduler_status.last_title_pc << " 0x"
                   << st.scheduler_status.last_irq_source << std::dec << "\n";
                os << "Guest timer Input/D3D/valid/reject: "
                   << st.guest_timer_status.input_sequences << "/"
                   << st.guest_timer_status.deadline_sequences << "/"
                   << st.guest_timer_status.deadline_valid << "/"
                   << st.guest_timer_status.deadline_rejects << "\n\n";

                os << "Pinned QEMU Timer / Main-Loop Events\n";
                os << "Columns: seq virtual_ns host_ns event clock tid timeout_ns expire_ns timer_delta_ns wait_host_ns wait_virtual_ns dispatch_late_ns pending value\n";
                for (size_t i = 0; i < st.qtimer_count; ++i) {
                    const auto &e = capture.qtimer[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << QemuTimerTraceEventName(e.event_type) << " "
                       << e.clock_type << " " << e.thread_id << " " << e.timeout_ns
                       << " " << e.timer_expire_ns << " " << e.timer_delta_ns << " "
                       << e.wait_elapsed_host_ns << " " << e.wait_elapsed_virtual_ns
                       << " " << e.dispatch_late_ns << " " << e.watched_timer_pending
                       << " " << e.value << "\n";
                }

                os << "\nPinned BQL Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns context owner_context owner_stage caller owner_caller guest_pc_start guest_pc_end owner_guest_pc\n";
                for (size_t i = 0; i < st.bql_count; ++i) {
                    const auto &e = capture.bql[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << BqlTraceEventName(e.event_type) << " " << e.thread_id
                       << " " << e.cpu_index << " " << e.wait_ns << " " << e.held_ns
                       << " " << e.owner_thread_id << " " << e.owner_cpu_index << " "
                       << e.owner_held_at_attempt_ns << " "
                       << BqlTraceContextName(e.caller_context) << " "
                       << BqlTraceContextName(e.owner_context) << " "
                       << BqlTraceStageName(e.owner_stage_at_attempt) << " "
                       << (e.caller_file[0] ? e.caller_file : "<unknown>") << ":"
                       << e.caller_line << " "
                       << (e.owner_caller_file[0] ? e.owner_caller_file : "<unknown>")
                       << ":" << e.owner_caller_line << " 0x" << std::hex
                       << std::uppercase << e.guest_pc_start << " 0x" << e.guest_pc_end
                       << " 0x" << e.owner_guest_pc_start << std::dec << "\n";
                }

                os << "\nPinned QEMU Main Loop Lock Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns context owner_context owner_stage caller owner_caller guest_pc_start guest_pc_end owner_guest_pc\n";
                for (size_t i = 0; i < st.main_loop_lock_count; ++i) {
                    const auto &e = capture.main_loop_lock[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << MainLoopLockTraceEventName(e.event_type) << " "
                       << e.thread_id << " " << e.cpu_index << " " << e.wait_ns << " "
                       << e.held_ns << " " << e.owner_thread_id << " "
                       << e.owner_cpu_index << " " << e.owner_held_at_attempt_ns << " "
                       << BqlTraceContextName(e.caller_context) << " "
                       << BqlTraceContextName(e.owner_context) << " "
                       << BqlTraceStageName(e.owner_stage_at_attempt) << " "
                       << (e.caller_file[0] ? e.caller_file : "<unknown>") << ":"
                       << e.caller_line << " "
                       << (e.owner_caller_file[0] ? e.owner_caller_file : "<unknown>")
                       << ":" << e.owner_caller_line << " 0x" << std::hex
                       << std::uppercase << e.guest_pc_start << " 0x" << e.guest_pc_end
                       << " 0x" << e.owner_guest_pc_start << std::dec << "\n";
                }

                os << "\nPinned PGRAPH Lock Events\n";
                os << "Columns: seq virtual_ns host_ns event tid cpu wait_ns hold_ns owner_tid owner_cpu owner_held_ns acquire release owner_acquire method class parameter waiting_nop waiting_flip waiting_context renderer\n";
                for (size_t i = 0; i < st.pgraph_count; ++i) {
                    const auto &e = capture.pgraph[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << PgraphLockTraceEventName(e.event_type) << " "
                       << e.thread_id << " " << e.cpu_index << " " << e.wait_ns << " "
                       << e.held_ns << " " << e.owner_thread_id << " "
                       << e.owner_cpu_index << " " << e.owner_held_at_attempt_ns << " "
                       << (e.acquire_file[0] ? e.acquire_file : "<unknown>") << ":"
                       << e.acquire_line << " "
                       << (e.release_file[0] ? e.release_file : "<unknown>") << ":"
                       << e.release_line << " "
                       << (e.owner_acquire_file[0] ? e.owner_acquire_file : "<unknown>")
                       << ":" << e.owner_acquire_line << " 0x" << std::hex
                       << std::uppercase << e.method.method << " 0x"
                       << e.method.graphics_class << " 0x" << e.method.parameter
                       << std::dec << " " << e.state.waiting_for_nop << " "
                       << e.state.waiting_for_flip << " "
                       << e.state.waiting_for_context_switch << " "
                       << e.state.renderer << "\n";
                }

                os << "\nPinned Scheduler / CPU Events\n";
                os << "Columns: seq virtual_ns host_ns event idle_age_ns duration_ns pc last_title_pc eflags ebx ebp esp irq exception cpu halted last_irq_source last_irq_age_ns ptimer_pending ptimer_enabled vblank_count ptimer_count pgraph_count pfifo_count ohci_count\n";
                for (size_t i = 0; i < st.scheduler_count; ++i) {
                    const auto &e = capture.scheduler[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << SchedulerTraceEventName(e.event_type) << " "
                       << e.idle_age_ns << " " << e.duration_ns << " 0x" << std::hex
                       << std::uppercase << e.guest_pc << " 0x" << e.last_title_pc
                       << " 0x" << e.eflags << " 0x" << e.ebx << " 0x" << e.ebp
                       << " 0x" << e.esp << " 0x" << e.interrupt_request << std::dec
                       << " " << e.exception_index << " " << e.cpu_index << " "
                       << e.halted << " " << e.last_irq_source << " "
                       << e.last_irq_age_ns << " " << e.ptimer_pending << " "
                       << e.ptimer_enabled << " " << e.idle_vblank_count << " "
                       << e.idle_ptimer_count << " " << e.idle_pgraph_count << " "
                       << e.idle_pfifo_count << " " << e.idle_ohci_count << "\n";
                }

                os << "\nPinned Guest Timer / Deadline Events\n";
                os << "Columns: seq virtual_ns host_ns input_seq deadline_seq event pc age_since_input_ns nominal lateness calculated current_tsc requested threshold delta_cycles delta_us relative\n";
                for (size_t i = 0; i < st.guest_timer_count; ++i) {
                    const auto &e = capture.guest_timer[i];
                    os << e.sequence << " " << e.qemu_virtual_ns << " " << e.host_ns
                       << " " << e.input_sequence << " " << e.deadline_sequence << " "
                       << GuestTimerDeadlineEventName(e.event_type) << " 0x" << std::hex
                       << std::uppercase << e.guest_pc << std::dec << " "
                       << e.age_since_input_ns << " " << e.nominal_interval << " "
                       << e.accumulated_lateness << " " << e.calculated_interval << " "
                       << e.current_tsc << " " << e.requested_deadline << " "
                       << e.deadline_threshold << " " << e.deadline_delta_cycles << " "
                       << std::fixed << std::setprecision(3)
                       << GuestTimerCyclesToUs(e.deadline_delta_cycles)
                       << std::defaultfloat << " " << e.relative_delay << "\n";
                }
            }
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::AudioMetrics) ||
        m_view.IsVisible(DiagnosticSection::AudioPacing)) {
        os << "Audio\n----------------------------------------\n";
        if (m_device.apu_available) {
            if (m_view.IsVisible(DiagnosticSection::AudioMetrics)) {
                os << "Frames processed: " << m_device.apu_frames_processed << "\n";
                os << "Utilization: " << m_device.apu_utilization << "\n";
                os << "Active voices: " << m_device.apu_active_voices << "\n";
            }
            if (m_view.IsVisible(DiagnosticSection::AudioPacing)) {
                os << "Pacing deviation us min/avg/max: "
                   << m_device.apu_deviation_min_us << "/"
                   << m_device.apu_deviation_avg_us << "/"
                   << m_device.apu_deviation_max_us << "\n";
                os << "Queue latency ms min/avg/max: "
                   << m_device.apu_latency_min_ms << "/"
                   << m_device.apu_latency_avg_ms << "/"
                   << m_device.apu_latency_max_ms << "\n";
            }
        } else {
            os << "<unavailable>\n";
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::AvSync)) {
        os << "Audio / Video Sync Trace\n----------------------------------------\n";
        XemuDiagnosticsAvSyncTraceStatus status{};
        xemu_diagnostics_get_av_sync_trace_status(&status);
        os << "Trace enabled: " << status.enabled << "\n";
        os << "Buffered / total / overwritten events: " << status.count
           << " / " << status.total_events << " / "
           << status.overwritten_events << "\n";
        os << "Audio batches / samples: " << status.audio_batches << " / "
           << status.audio_samples << "\n";
        os << "Video VBlank ticks: " << status.video_vblanks << "\n";
        os << "PGRAPH FLIP_STALL frames / frame_time: " << status.pgraph_flips
           << " / " << status.last_pgraph_frame_time << "\n";
        os << "PGRAPH ready: " << status.pgraph_ready << "\n";
        os << "Last PGRAPH flip host / virtual interval ns: "
           << status.last_pgraph_host_interval_ns << " / "
           << status.last_pgraph_virtual_interval_ns << "\n";
        os << "Last PGRAPH flip VBlank / audio-sample delta: "
           << status.last_pgraph_vblank_delta << " / "
           << status.last_pgraph_audio_sample_delta << "\n";
        os << "Max PGRAPH flip host / virtual interval ns: "
           << status.max_pgraph_host_interval_ns << " / "
           << status.max_pgraph_virtual_interval_ns << "\n";
        os << "Max PGRAPH flip VBlank delta: " << status.max_pgraph_vblank_delta << "\n";
        os << "Since last PGRAPH flip host / virtual age ns: "
           << status.pgraph_host_age_ns << " / " << status.pgraph_virtual_age_ns << "\n";
        os << "Since last PGRAPH flip audio / VBlank advance ns: "
           << status.audio_since_pgraph_ns << " / "
           << status.vblank_since_pgraph_ns << "\n";
        os << "Last audio queue bytes: " << status.last_audio_queue_bytes << "\n";
        os << "Ready: " << status.ready << "\n";
        os << "Audio host / virtual drift ns: " << status.audio_host_drift_ns
           << " / " << status.audio_virtual_drift_ns << "\n";
        os << "Video host / virtual drift ns: " << status.video_host_drift_ns
           << " / " << status.video_virtual_drift_ns << "\n";
        os << "A/V host / virtual cadence drift ns: " << status.av_host_drift_ns
           << " / " << status.av_virtual_drift_ns << "\n";
        os << "Sign: positive A/V drift means audio cadence advanced faster than VBlank; negative means audio cadence is behind.\n";
        os << "PGRAPH note: flip gaps are raw guest FLIP_STALL cadence; no target FPS is assumed. Audio/VBlank advance since the last flip shows how far those clocks continued while PGRAPH did not produce a new frame.\n";
        if (status.count != 0) {
            std::vector<XemuDiagnosticsAvSyncTraceEvent> trace(status.count);
            const size_t count = xemu_diagnostics_get_av_sync_trace(
                trace.data(), trace.size());
            trace.resize(count);
            os << "Columns: seq virtual_ns host_ns event ready pgraph_ready audio_batches "
                  "audio_samples video_vblanks video_expected_ns vblank_interval_ns "
                  "pgraph_flips pgraph_frame_time pgraph_last_vblank_delta "
                  "pgraph_last_audio_sample_delta pgraph_last_host_interval_ns "
                  "pgraph_last_virtual_interval_ns pgraph_max_host_interval_ns "
                  "pgraph_max_virtual_interval_ns pgraph_max_vblank_delta "
                  "pgraph_host_age_ns pgraph_virtual_age_ns audio_since_pgraph_ns "
                  "vblank_since_pgraph_ns audio_queue_bytes audio_batch_samples "
                  "audio_host_drift_ns audio_virtual_drift_ns video_host_drift_ns "
                  "video_virtual_drift_ns av_host_drift_ns av_virtual_drift_ns\n";
            for (const auto &event : trace) {
                os << event.sequence << " " << event.qemu_virtual_ns << " "
                   << event.host_ns << " " << AvSyncEventName(event.event_type)
                   << " " << event.ready << " " << event.pgraph_ready << " "
                   << event.audio_batches << " " << event.audio_samples << " "
                   << event.video_vblanks << " " << event.video_expected_ns << " "
                   << event.vblank_interval_ns << " " << event.pgraph_flips << " "
                   << event.pgraph_frame_time << " " << event.pgraph_last_vblank_delta << " "
                   << event.pgraph_last_audio_sample_delta << " "
                   << event.pgraph_last_host_interval_ns << " "
                   << event.pgraph_last_virtual_interval_ns << " "
                   << event.pgraph_max_host_interval_ns << " "
                   << event.pgraph_max_virtual_interval_ns << " "
                   << event.pgraph_max_vblank_delta << " " << event.pgraph_host_age_ns << " "
                   << event.pgraph_virtual_age_ns << " " << event.audio_since_pgraph_ns << " "
                   << event.vblank_since_pgraph_ns << " " << event.audio_queue_bytes << " "
                   << event.audio_batch_samples << " "
                   << event.audio_host_drift_ns << " "
                   << event.audio_virtual_drift_ns << " "
                   << event.video_host_drift_ns << " "
                   << event.video_virtual_drift_ns << " "
                   << event.av_host_drift_ns << " "
                   << event.av_virtual_drift_ns << "\n";
            }
        }
        std::array<XemuDebugToolsAvSyncMarker,
                   XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY> markers{};
        uint64_t marker_total = 0;
        size_t marker_count = xemu_debug_tools_av_sync_trace_markers_snapshot(
            markers.data(), markers.size(), &marker_total);
        os << "A/V User Markers: " << marker_count << " retained / " << marker_total
           << " total; timestamps are UI button presses, not measured content offsets.\n";
        for (size_t i = 0; i < marker_count; i++) {
            const auto &m = markers[i];
            os << "AV_MARKER " << m.sequence << " " << AvSyncMarkerName(m.kind)
               << " host_ns=" << m.host_ns << " virtual_ns=" << m.virtual_ns
               << " audio_samples=" << m.audio_samples
               << " video_vblanks=" << m.video_vblanks
               << " pgraph_flips=" << m.pgraph_flips << "\n";
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::Watches)) {
        os << "Custom Watches\n----------------------------------------\n";
        for (const CustomWatch &watch : m_watches) {
            os << watch.name.data() << "  "
               << (watch.virtual_address ? "V:" : "P:")
               << std::hex << std::uppercase << std::setw(8) << std::setfill('0')
               << watch.address;
            if (watch.enabled && watch.physical_valid) {
                os << " -> P:" << std::setw(8) << watch.physical_address;
            }
            os << std::dec << "  " << FormatWatchValue(watch)
               << (watch.warning_active ? "  WARNING unchanged" : "") << "\n";
        }
        os << "\n";
    }

    if (m_view.IsVisible(DiagnosticSection::History)) {
        os << "Recent Events\n----------------------------------------\n";
        for (const EventRow &event : m_events) {
            os << std::fixed << std::setprecision(3)
               << (double)event.elapsed_ms / 1000.0 << "  [" << event.category
               << "] " << event.text << "\n";
        }
    }
    return os.str();
}

bool DiagnosticsWindow::SaveSnapshotToPath(const std::string &path,
                                           bool atomic) const
{
    if (path.empty()) {
        return false;
    }

    gchar *parent = g_path_get_dirname(path.c_str());
    if (parent == nullptr) {
        return false;
    }
    const bool parent_ok = g_mkdir_with_parents(parent, 0755) == 0;
    g_free(parent);
    if (!parent_ok) {
        return false;
    }

    const std::string text = BuildSnapshotText();
    const std::string write_path = atomic ? path + ".tmp" : path;
    FILE *out = g_fopen(write_path.c_str(), "wb");
    if (out == nullptr) {
        return false;
    }
    const size_t written = std::fwrite(text.data(), 1, text.size(), out);
    const int close_result = std::fclose(out);
    if (written != text.size() || close_result != 0) {
        if (atomic) {
            g_remove(write_path.c_str());
        }
        return false;
    }

    if (atomic) {
        // Windows rename does not replace an existing destination. Remove the
        // previous rolling snapshot first, then move the completed temp file.
        g_remove(path.c_str());
        if (g_rename(write_path.c_str(), path.c_str()) != 0) {
            g_remove(write_path.c_str());
            return false;
        }
    }
    return true;
}

bool DiagnosticsWindow::RequestSaveSnapshot()
{
    std::string error;
    if (!XemuDebugOutput::EnsureDirectory(
            XemuDebugOutput::Folder::Snapshots, &error)) {
        m_status = error;
        return false;
    }

    const auto &game = current_game_manager.Get();
    std::string stem = game.valid
                           ? CurrentGameManager::FormatDatabaseGameId(game.title_id)
                           : std::string("XEMU");
    stem += "-Diagnostics-";
    stem += XemuDebugOutput::Timestamp();
    const std::string output = XemuDebugOutput::UniqueFilePath(
        XemuDebugOutput::Folder::Snapshots, stem, ".txt");
    if (output.empty()) {
        m_status = "Could not create a unique DEBUG/Snapshots filename.";
        return false;
    }
    if (SaveSnapshotToPath(output, false)) {
        m_status = "Saved diagnostics snapshot: " + output;
        return true;
    }
    m_status = "Failed to save diagnostics snapshot: " + output;
    return false;
}

void DiagnosticsWindow::OpenSnapshotsFolder()
{
    /* Called only from ProcessDeferredActions(), after present and with the BQL
     * released.  The worker performs directory/file-manager work so the UI
     * thread only has to enqueue a tiny job and maintain the temporary input
     * lease. */
    auto *job = new OpenSnapshotsFolderJob{};
    job->owner = this;

    if (!debug_tools_queue_background_job(
            OpenSnapshotsFolderWorker, job, OpenSnapshotsFolderComplete, true)) {
        delete job;
        m_snapshots_folder_status =
            "Debug Tools worker unavailable; snapshots folder not opened.";
        m_status = m_snapshots_folder_status;
        AddEvent(SDL_GetTicks(), "Debug Tools", m_snapshots_folder_status);
        return;
    }
    m_snapshots_folder_status = "Opening DEBUG/Snapshots in background...";
    m_status = m_snapshots_folder_status;
}

void DiagnosticsWindow::OpenSnapshotsFolderWorker(void *opaque)
{
    auto *job = static_cast<OpenSnapshotsFolderJob *>(opaque);
    if (!job) {
        return;
    }

    /* Filesystem work is safe on the worker. SDL_OpenURL is intentionally NOT
     * called here because SDL requires it on the main thread. */
    std::string error;
    if (!XemuDebugOutput::EnsureDirectory(
            XemuDebugOutput::Folder::Snapshots, &error)) {
        job->status = error;
        return;
    }

    job->directory = XemuDebugOutput::Directory(
        XemuDebugOutput::Folder::Snapshots);
    if (job->directory.empty()) {
        job->status = "Could not determine DEBUG/Snapshots directory.";
    }
}

void DiagnosticsWindow::OpenSnapshotsFolderComplete(void *opaque)
{
    auto *job = static_cast<OpenSnapshotsFolderJob *>(opaque);
    if (!job) {
        return;
    }
    if (job->owner) {
        if (job->status.empty()) {
            /* Info: Open Explorer post-present with BQL released and input lease retained. */
            std::string error;
            if (XemuDebugOutput::OpenDirectory(
                    XemuDebugOutput::Folder::Snapshots, &error)) {
                job->status = "Opened DEBUG/Snapshots: " + job->directory;
            } else {
                job->status = error;
            }
        }

        job->owner->m_snapshots_folder_status = job->status.empty()
            ? "Open Snapshots Folder completed without a status."
            : job->status;
        job->owner->m_status = job->owner->m_snapshots_folder_status;
        job->owner->AddEvent(SDL_GetTicks(), "Debug Tools",
                             job->owner->m_snapshots_folder_status);
    }
    delete job;
}

void DiagnosticsWindow::DrawViewMenu()
{
    if (!ImGui::BeginMenu("View")) {
        return;
    }

    ImGui::TextDisabled("Checked panels are visible and included in Save/Copy/Live Snapshot");
    ImGui::TextDisabled("View stays open while changing selections; click outside it to close.");

    /* MenuItem() auto-closes an ImGui popup when activated.  View is a
     * multi-selection menu, so use ordinary widgets here instead: Buttons
     * and Checkboxes remain open until the user clicks away from the popup. */
    if (ImGui::Button("Check All")) {
        m_view.SetAll(true);
    }
    ImGui::SameLine();
    if (ImGui::Button("Uncheck All")) {
        m_view.SetAll(false);
    }
    ImGui::Separator();

    const auto group_items = [this](XemuDiagnosticsView::Group group) {
        for (const auto &section : XemuDiagnosticsView::kSections) {
            if (section.group == group) {
                ImGui::Checkbox(section.label,
                    &m_view.checked[static_cast<size_t>(section.id)]);
            }
        }
    };

    group_items(XemuDiagnosticsView::Group::General);
    group_items(XemuDiagnosticsView::Group::Overview);
    if (ImGui::BeginMenu("CPU / Timing")) {
        group_items(XemuDiagnosticsView::Group::Cpu);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("NV2A / PTIMER")) {
        group_items(XemuDiagnosticsView::Group::Nv2a);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Audio")) {
        group_items(XemuDiagnosticsView::Group::Audio);
        ImGui::EndMenu();
    }
    group_items(XemuDiagnosticsView::Group::Watches);
    group_items(XemuDiagnosticsView::Group::History);
    ImGui::EndMenu();
}


void DiagnosticsWindow::CopySummaryToClipboard()
{
    const std::string text = BuildSnapshotText();
    if (SDL_SetClipboardText(text.c_str())) {
        m_status = "Diagnostics snapshot copied to clipboard.";
    } else {
        m_status = std::string("Clipboard copy failed: ") + SDL_GetError();
    }
}

void DiagnosticsWindow::Draw(bool detached)
{
    if (!is_open) {
        return;
    }

    ImGuiWindowFlags flags = ImGuiWindowFlags_MenuBar;
    const char *name = "Diagnostics";
    bool *open = &is_open;
    if (detached) {
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Always);
        flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings;
        name = "##DetachedDiagnostics";
        open = nullptr;
    } else {
        ImGui::SetNextWindowSize(ImVec2(1050, 720), ImGuiCond_FirstUseEver);
    }

    if (!ImGui::Begin(name, open, flags)) {
        ImGui::End();
        return;
    }

    if (ImGui::BeginMenuBar()) {
        DrawViewMenu();
        ImGui::EndMenuBar();
    }

    if (m_view.IsVisible(DiagnosticSection::CurrentGame)) {
        current_game_manager.DrawInlineSummary("diagnostics-current-game");
        ImGui::Separator();
    }

    ImGui::Text("Refresh");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(110.0f);
    int refresh = (int)m_refresh_ms;
    if (ImGui::InputInt("ms##diagrefresh", &refresh, 10, 100)) {
        m_refresh_ms = (uint32_t)std::clamp(refresh, 50, 5000);
    }
    ImGui::SameLine();
    if (ImGui::Button("Refresh Now")) {
        m_manual_refresh_requested = true;
        m_status = "Diagnostics refresh queued for the next synchronized tick.";
    }
    ImGui::SameLine();
    if (ImGui::Button("Save Snapshot")) {
        m_manual_snapshot_requested = true;
        m_status = "Diagnostics snapshot capture queued for the next synchronized tick.";
    }
    ImGui::SameLine();
    if (ImGui::Button("Open Snapshots Folder")) {
        /* Draw() may run in the detached unlocked phase. Never create
         * directories, change the background-input lease, or launch external
         * process work here. Consume this request post-present instead. */
        m_open_snapshots_folder_requested = true;
        m_snapshots_folder_status = "Open Snapshots Folder queued.";
        m_status = m_snapshots_folder_status;
    }
    ImGui::SameLine();
    if (ImGui::Button("Copy Snapshot")) {
        CopySummaryToClipboard();
    }
    ImGui::TextDisabled("Global hotkeys: F3 toggles Check All Recording Options; F4 saves a Diagnostics snapshot.");
    if (m_view.IsVisible(DiagnosticSection::Background)) {
        ImGui::TextDisabled(
            "Debug worker: %s | queued jobs: %u | external input lease: %s",
            debug_tools_background_worker_is_running() ? "running" : "unavailable",
            debug_tools_background_worker_pending_jobs(),
            debug_tools_external_input_lease_active() ? "active" : "off");
    }

    ImGui::Checkbox("Rolling crash/stall snapshot", &m_auto_save);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(100.0f);
    int auto_ms = (int)m_auto_save_interval_ms;
    if (ImGui::InputInt("ms##diagautosave", &auto_ms, 250, 1000)) {
        m_auto_save_interval_ms =
            (uint32_t)std::clamp(auto_ms, 500, 60000);
    }
    ImGui::SameLine();
    ImGui::TextDisabled("Writes one rolling file to DEBUG/Snapshots/XEMU-Diagnostics-Live.txt. Save Snapshot writes timestamped files to the same folder.");

    if (!m_status.empty()) {
        ImGui::TextDisabled("%s", m_status.c_str());
    }

    DrawRecordingControls();
    ImGui::TextDisabled("View selects visible AND saved sections. Hidden recorders keep their current recording state.");

    XemuDebugUi::ScopedTabStyle tab_style;
    if (ImGui::BeginTabBar("diagnostics_tabs")) {
        if (m_view.Any(XemuDiagnosticsView::Group::Overview) &&
            ImGui::BeginTabItem("Overview")) {
            DrawOverview();
            ImGui::EndTabItem();
        }
        if (m_view.Any(XemuDiagnosticsView::Group::Cpu) &&
            ImGui::BeginTabItem("CPU / Timing")) {
            DrawCpuTiming();
            ImGui::EndTabItem();
        }
        if (m_view.Any(XemuDiagnosticsView::Group::Nv2a) &&
            ImGui::BeginTabItem("NV2A / PTIMER")) {
            DrawNv2a();
            ImGui::EndTabItem();
        }
        if (m_view.Any(XemuDiagnosticsView::Group::Audio) &&
            ImGui::BeginTabItem("Audio")) {
            DrawAudio();
            ImGui::EndTabItem();
        }
        if (m_view.Any(XemuDiagnosticsView::Group::Watches) &&
            ImGui::BeginTabItem("Memory Watches")) {
            DrawWatches();
            ImGui::EndTabItem();
        }
        if (m_view.Any(XemuDiagnosticsView::Group::History) &&
            ImGui::BeginTabItem("History / Events")) {
            DrawHistory();
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    tab_style.Restore();
    if (!m_view.Any(XemuDiagnosticsView::Group::Overview) &&
        !m_view.Any(XemuDiagnosticsView::Group::Cpu) &&
        !m_view.Any(XemuDiagnosticsView::Group::Nv2a) &&
        !m_view.Any(XemuDiagnosticsView::Group::Audio) &&
        !m_view.Any(XemuDiagnosticsView::Group::Watches) &&
        !m_view.Any(XemuDiagnosticsView::Group::History)) {
        ImGui::TextDisabled("All diagnostic panels are hidden. Choose panels from View.");
    }

    ImGui::End();
}
