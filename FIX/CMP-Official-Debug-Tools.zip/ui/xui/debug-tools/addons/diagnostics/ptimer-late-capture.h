/* Info: One-shot pinned forensic capture for materially late PTIMER callbacks. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "bql-trace.h"
#include "guest-timer-deadline-trace.h"
#include "main-loop-lock-trace.h"
#include "pgraph-lock-trace.h"
#include "qemu-timer-trace.h"
#include "scheduler-trace.h"

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS (5 * 1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_QTIMER_EVENTS 128
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_BQL_EVENTS 48
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_MAIN_LOOP_LOCK_EVENTS 48
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_PGRAPH_EVENTS 48
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_SCHEDULER_EVENTS 48
#define XEMU_DEBUG_TOOLS_PTIMER_LATE_GUEST_TIMER_EVENTS 24

typedef struct XemuDebugToolsPtimerLateCaptureStatus {
    int enabled;
    int latched;
    int capture_in_progress;
    uint64_t capture_count;
    int64_t threshold_ns;
    uint64_t trigger_virtual_ns;
    uint64_t trigger_host_ns;
    int64_t trigger_expire_ns;
    int64_t trigger_late_ns;
    int32_t trigger_thread_id;
    uint64_t capture_duration_host_ns;
    size_t qtimer_count;
    size_t bql_count;
    size_t main_loop_lock_count;
    size_t pgraph_count;
    size_t scheduler_count;
    size_t guest_timer_count;
    XemuDebugToolsBqlTraceStatus bql_status;
    XemuDebugToolsMainLoopLockTraceStatus main_loop_lock_status;
    XemuDebugToolsPgraphLockTraceStatus pgraph_status;
    XemuDebugToolsSchedulerTraceStatus scheduler_status;
    XemuDebugToolsGuestTimerDeadlineTraceStatus guest_timer_status;
} XemuDebugToolsPtimerLateCaptureStatus;

typedef struct XemuDebugToolsPtimerLateCaptureSnapshot {
    XemuDebugToolsPtimerLateCaptureStatus status;
    XemuDebugToolsQemuTimerTraceEvent
        qtimer[XEMU_DEBUG_TOOLS_PTIMER_LATE_QTIMER_EVENTS];
    XemuDebugToolsBqlTraceEvent
        bql[XEMU_DEBUG_TOOLS_PTIMER_LATE_BQL_EVENTS];
    XemuDebugToolsMainLoopLockTraceEvent
        main_loop_lock[XEMU_DEBUG_TOOLS_PTIMER_LATE_MAIN_LOOP_LOCK_EVENTS];
    XemuDebugToolsPgraphLockTraceEvent
        pgraph[XEMU_DEBUG_TOOLS_PTIMER_LATE_PGRAPH_EVENTS];
    XemuDebugToolsSchedulerTraceEvent
        scheduler[XEMU_DEBUG_TOOLS_PTIMER_LATE_SCHEDULER_EVENTS];
    XemuDebugToolsGuestTimerDeadlineTraceEvent
        guest_timer[XEMU_DEBUG_TOOLS_PTIMER_LATE_GUEST_TIMER_EVENTS];
} XemuDebugToolsPtimerLateCaptureSnapshot;

int xemu_debug_tools_ptimer_late_capture_active(void);
void xemu_debug_tools_ptimer_late_capture_set_enabled(int enabled);
void xemu_debug_tools_ptimer_late_capture_clear(void);
void xemu_debug_tools_ptimer_late_capture_note_dispatch(
    const XemuDebugToolsQemuTimerTraceEvent *event);
void xemu_debug_tools_ptimer_late_capture_get_status(
    XemuDebugToolsPtimerLateCaptureStatus *status);
int xemu_debug_tools_ptimer_late_capture_snapshot(
    XemuDebugToolsPtimerLateCaptureSnapshot *snapshot);

#ifdef __cplusplus
}
#endif
