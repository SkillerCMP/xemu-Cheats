/* Info: IRQ sources report wake activity; Diagnostics owns scheduler analysis. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsSchedulerWakeSource {
    XEMU_DEBUG_TOOLS_SCHED_WAKE_NONE = 0,
    XEMU_DEBUG_TOOLS_SCHED_WAKE_PCRTC_VBLANK,
    XEMU_DEBUG_TOOLS_SCHED_WAKE_PTIMER,
    XEMU_DEBUG_TOOLS_SCHED_WAKE_PGRAPH,
    XEMU_DEBUG_TOOLS_SCHED_WAKE_PFIFO,
    XEMU_DEBUG_TOOLS_SCHED_WAKE_OHCI,
} XemuDebugToolsSchedulerWakeSource;

void xemu_debug_tools_scheduler_trace_note_irq(
    unsigned int source, uint32_t pending, uint32_t enabled);

#ifdef __cplusplus
}
#endif
