/* Info: Plain C snapshot bridge keeps device internals out of ImGui code. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "av-sync-trace.h"
#include "bql-trace.h"
#include "controller-input-poll-trace-hook.h"
#include "controller-xid-trace.h"
#include "guest-input-consumer-trace.h"
#include "guest-timer-deadline-trace.h"
#include "host-stall-trace.h"
#include "flip-stall-trace.h"
#include "main-loop-lock-trace.h"
#include "mmio-trace.h"
#include "ohci-slow-frame-trace-hook.h"
#include "pgraph-draw-trace.h"
#include "pgraph-lock-trace.h"
#include "pgraph-flip-delay-trace.h"
#include "pgraph-pusher-progress-trace.h"
#include "pgraph-ptimer-latency-trace-types.h"
#include "ptimer-trace.h"
#include "ptimer-late-capture.h"
#include "d3d-callback-capture.h"
#include "d3d-timer-state-trace.h"
#include "ptimer-irq-delivery-trace.h"
#include "qemu-timer-trace.h"
#include "scheduler-trace.h"
#include "slow-timer-trace.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDiagnosticsBufferId {
    XEMU_DIAG_BUFFER_PTIMER = 0,
    XEMU_DIAG_BUFFER_QEMU_TIMER,
    XEMU_DIAG_BUFFER_SLOW_TIMER,
    XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME,
    XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL,
    XEMU_DIAG_BUFFER_PGRAPH_INCREMENT,
    XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY,
    XEMU_DIAG_BUFFER_BQL,
    XEMU_DIAG_BUFFER_MMIO,
    XEMU_DIAG_BUFFER_PGRAPH_LOCK,
    XEMU_DIAG_BUFFER_PGRAPH_DRAW,
    XEMU_DIAG_BUFFER_FLIP_STALL,
    XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY,
    XEMU_DIAG_BUFFER_AV_SYNC,
    XEMU_DIAG_BUFFER_SCHEDULER,
    XEMU_DIAG_BUFFER_CONTROLLER_XID,
    XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER,
    XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK,
    XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE,
    XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS,
    XEMU_DIAG_BUFFER_COUNT,
} XemuDiagnosticsBufferId;

typedef struct XemuDiagnosticsBufferInfo {
    uint32_t multiplier;
    size_t base_capacity;
    size_t capacity;
} XemuDiagnosticsBufferInfo;

int xemu_diagnostics_buffer_set_multiplier(XemuDiagnosticsBufferId id,
                                           uint32_t multiplier);
int xemu_diagnostics_buffer_get_info(XemuDiagnosticsBufferId id,
                                     XemuDiagnosticsBufferInfo *info);


typedef struct XemuDiagnosticsTimingSnapshot {
    int available;
    int whpx_active;
    int running;
    int halted;
    int exception_index;
    uint32_t interrupt_request;
    uint64_t qemu_virtual_ns;
    uint64_t expected_xbox_tsc;
    uint64_t actual_tsc;
    int actual_tsc_valid;
    uint64_t model_tsc_hz;
    uint64_t apic_bus_hz;
    uint64_t whpx_processor_clock_hz;
    int whpx_processor_clock_valid;
    uint64_t whpx_interrupt_clock_hz;
    int whpx_interrupt_clock_valid;
} XemuDiagnosticsTimingSnapshot;

int xemu_diagnostics_get_timing_snapshot(
    XemuDiagnosticsTimingSnapshot *snapshot);

typedef struct XemuDiagnosticsDeviceSnapshot {
    int nv2a_available;
    uint64_t qemu_virtual_ns;

    uint32_t pmc_pending;
    uint32_t pmc_enabled;
    uint32_t pfifo_pending;
    uint32_t pfifo_enabled;
    uint32_t pgraph_pending;
    uint32_t pgraph_enabled;
    uint32_t pcrtc_pending;
    uint32_t pcrtc_enabled;
    uint32_t ptimer_pending;
    uint32_t ptimer_enabled;

    int pfifo_fifo_kick;
    int pfifo_halt;
    int pgraph_waiting_for_nop;
    int pgraph_waiting_for_flip;
    int pgraph_waiting_for_context_switch;
    int pgraph_flush_pending;
    int pgraph_sync_pending;

    uint32_t ptimer_numerator;
    uint32_t ptimer_denominator;
    uint64_t ptimer_now;
    uint64_t ptimer_alarm;
    int64_t ptimer_alarm_delta_ns; /* +future, -late */
    int ptimer_qemu_timer_pending;
    int64_t ptimer_qemu_timer_delta_ns;
    uint64_t ptimer_qemu_timer_expire_ns;

    uint64_t gpu_core_clock_hz;
    uint32_t gpu_fps;
    uint32_t gpu_frame_count;
    int32_t gpu_last_frame_mspf;

    int apu_available;
    int32_t apu_frames_processed;
    float apu_utilization;
    int32_t apu_active_voices;
    int32_t apu_worker_time_us;
    int32_t apu_gp_cycles;
    int32_t apu_ep_cycles;
    int64_t apu_deviation_min_us;
    int64_t apu_deviation_avg_us;
    int64_t apu_deviation_max_us;
    float apu_latency_min_ms;
    float apu_latency_avg_ms;
    float apu_latency_max_ms;
    float apu_latency_low_ms;
    float apu_latency_high_ms;
    int apu_gp_realtime;
    int apu_ep_realtime;
} XemuDiagnosticsDeviceSnapshot;

int xemu_diagnostics_get_device_snapshot(
    XemuDiagnosticsDeviceSnapshot *snapshot);

typedef XemuDebugToolsPgraphFlipDelayEvent XemuDiagnosticsPgraphFlipDelayEvent;
typedef XemuDebugToolsPgraphFlipDelayStatus XemuDiagnosticsPgraphFlipDelayStatus;

void xemu_diagnostics_pgraph_flip_delay_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_flip_delay_trace_clear(void);
void xemu_diagnostics_pgraph_flip_delay_trace_set_threshold_ns(uint64_t ns);
int xemu_diagnostics_get_pgraph_flip_delay_trace_status(
    XemuDiagnosticsPgraphFlipDelayStatus *status);
size_t xemu_diagnostics_get_pgraph_flip_delay_trace(
    XemuDiagnosticsPgraphFlipDelayEvent *events, size_t capacity);

typedef XemuDebugToolsPgraphPusherProgressEvent XemuDiagnosticsPgraphPusherProgressEvent;
typedef XemuDebugToolsPgraphPusherProgressStatus XemuDiagnosticsPgraphPusherProgressStatus;
typedef XemuDebugToolsPgraphPusherMethodBreakdownEvent XemuDiagnosticsPgraphPusherMethodBreakdownEvent;
typedef XemuDebugToolsPgraphPusherMethodBreakdownStatus XemuDiagnosticsPgraphPusherMethodBreakdownStatus;

void xemu_diagnostics_pgraph_pusher_progress_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_pusher_progress_trace_clear(void);
int xemu_diagnostics_get_pgraph_pusher_progress_trace_status(
    XemuDiagnosticsPgraphPusherProgressStatus *status);
size_t xemu_diagnostics_get_pgraph_pusher_progress_trace(
    XemuDiagnosticsPgraphPusherProgressEvent *events, size_t capacity);

void xemu_diagnostics_pgraph_pusher_method_breakdown_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_pusher_method_breakdown_trace_clear(void);
int xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
    XemuDiagnosticsPgraphPusherMethodBreakdownStatus *status);
size_t xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace(
    XemuDiagnosticsPgraphPusherMethodBreakdownEvent *events, size_t capacity);

typedef XemuDebugToolsAvSyncTraceEvent XemuDiagnosticsAvSyncTraceEvent;
typedef XemuDebugToolsAvSyncTraceStatus XemuDiagnosticsAvSyncTraceStatus;

void xemu_diagnostics_av_sync_trace_set_enabled(int enabled);
void xemu_diagnostics_av_sync_trace_clear(void);
int xemu_diagnostics_get_av_sync_trace_status(
    XemuDiagnosticsAvSyncTraceStatus *status);
size_t xemu_diagnostics_get_av_sync_trace(
    XemuDiagnosticsAvSyncTraceEvent *events, size_t capacity);

typedef enum XemuDiagnosticsPtimerTraceEventType {
    XEMU_DIAG_PTIMER_TRACE_RESET = 1,
    XEMU_DIAG_PTIMER_TRACE_SCHEDULE,
    XEMU_DIAG_PTIMER_TRACE_SCHEDULE_DISABLED,
    XEMU_DIAG_PTIMER_TRACE_TIMER_DELETE,
    XEMU_DIAG_PTIMER_TRACE_CALLBACK,
    XEMU_DIAG_PTIMER_TRACE_CALLBACK_DISABLED,
    XEMU_DIAG_PTIMER_TRACE_IRQ_SET,
    XEMU_DIAG_PTIMER_TRACE_IRQ_CLEAR,
    XEMU_DIAG_PTIMER_TRACE_INTR_EN_WRITE,
    XEMU_DIAG_PTIMER_TRACE_ALARM_WRITE,
    XEMU_DIAG_PTIMER_TRACE_NUMERATOR_WRITE,
    XEMU_DIAG_PTIMER_TRACE_DENOMINATOR_WRITE,
    XEMU_DIAG_PTIMER_TRACE_TIME0_WRITE,
    XEMU_DIAG_PTIMER_TRACE_TIME1_WRITE,
} XemuDiagnosticsPtimerTraceEventType;

/* Info: Recorder headers own trace record layouts; Diagnostics keeps API aliases. */
typedef XemuDebugToolsPtimerTraceEvent XemuDiagnosticsPtimerTraceEvent;

typedef XemuDebugToolsPtimerTraceStatus XemuDiagnosticsPtimerTraceStatus;

void xemu_diagnostics_ptimer_trace_set_enabled(int enabled);
void xemu_diagnostics_ptimer_trace_clear(void);
int xemu_diagnostics_get_ptimer_trace_status(
    XemuDiagnosticsPtimerTraceStatus *status);
size_t xemu_diagnostics_get_ptimer_trace(
    XemuDiagnosticsPtimerTraceEvent *events, size_t capacity);

typedef enum XemuDiagnosticsQemuTimerTraceEventType {
    XEMU_DIAG_QTIMER_TIMER_MOD = 1,
    XEMU_DIAG_QTIMER_TIMER_DEL,
    XEMU_DIAG_QTIMER_CLOCK_NOTIFY,
    XEMU_DIAG_QTIMER_DISPATCH_BEGIN,
    XEMU_DIAG_QTIMER_DISPATCH_END,
    XEMU_DIAG_QTIMER_MAIN_WAIT_ENTER,
    XEMU_DIAG_QTIMER_MAIN_WAIT_EXIT,
    XEMU_DIAG_QTIMER_RUN_TIMERS_ENTER,
    XEMU_DIAG_QTIMER_RUN_TIMERS_EXIT,
    XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_ENTER,
    XEMU_DIAG_QTIMER_GLIB_CONTEXT_ACQUIRE_EXIT,
    XEMU_DIAG_QTIMER_GLIB_PREPARE_ENTER,
    XEMU_DIAG_QTIMER_GLIB_PREPARE_EXIT,
    XEMU_DIAG_QTIMER_POLL_ENTER,
    XEMU_DIAG_QTIMER_POLL_EXIT,
    XEMU_DIAG_QTIMER_POLL_BUSYWAIT_ENTER,
    XEMU_DIAG_QTIMER_POLL_BUSYWAIT_EXIT,
    XEMU_DIAG_QTIMER_POLL_BACKEND_ENTER,
    XEMU_DIAG_QTIMER_POLL_BACKEND_EXIT,
    XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_ENTER,
    XEMU_DIAG_QTIMER_MAIN_LOOP_LOCK_EXIT,
    XEMU_DIAG_QTIMER_REPLAY_LOCK_ENTER,
    XEMU_DIAG_QTIMER_REPLAY_LOCK_EXIT,
    XEMU_DIAG_QTIMER_BQL_LOCK_ENTER,
    XEMU_DIAG_QTIMER_BQL_LOCK_EXIT,
    XEMU_DIAG_QTIMER_GLIB_CHECK_ENTER,
    XEMU_DIAG_QTIMER_GLIB_CHECK_EXIT,
    XEMU_DIAG_QTIMER_GLIB_DISPATCH_ENTER,
    XEMU_DIAG_QTIMER_GLIB_DISPATCH_EXIT,
    XEMU_DIAG_QTIMER_WAIT_OBJECTS_ENTER,
    XEMU_DIAG_QTIMER_WAIT_OBJECTS_EXIT,
    XEMU_DIAG_QTIMER_POLLING_CALLBACKS_ENTER,
    XEMU_DIAG_QTIMER_POLLING_CALLBACKS_EXIT,
    XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_ENTER,
    XEMU_DIAG_QTIMER_GLIB_CONTEXT_RELEASE_EXIT,
} XemuDiagnosticsQemuTimerTraceEventType;

typedef XemuDebugToolsQemuTimerTraceEvent XemuDiagnosticsQemuTimerTraceEvent;

typedef XemuDebugToolsQemuTimerTraceStatus XemuDiagnosticsQemuTimerTraceStatus;

void xemu_diagnostics_qemu_timer_trace_set_enabled(int enabled);
void xemu_diagnostics_qemu_timer_trace_clear(void);
int xemu_diagnostics_get_qemu_timer_trace_status(
    XemuDiagnosticsQemuTimerTraceStatus *status);
size_t xemu_diagnostics_get_qemu_timer_trace(
    XemuDiagnosticsQemuTimerTraceEvent *events, size_t capacity);

typedef XemuDebugToolsSlowTimerTraceEvent XemuDiagnosticsSlowTimerTraceEvent;

typedef XemuDebugToolsSlowTimerTraceStatus XemuDiagnosticsSlowTimerTraceStatus;

void xemu_diagnostics_slow_timer_trace_set_enabled(int enabled);
void xemu_diagnostics_slow_timer_trace_set_threshold_ns(uint64_t threshold_ns);
void xemu_diagnostics_slow_timer_trace_clear(void);
int xemu_diagnostics_get_slow_timer_trace_status(
    XemuDiagnosticsSlowTimerTraceStatus *status);
size_t xemu_diagnostics_get_slow_timer_trace(
    XemuDiagnosticsSlowTimerTraceEvent *events, size_t capacity);

typedef enum XemuDiagnosticsOhciListKind {
    XEMU_DIAG_OHCI_LIST_NONE = 0,
    XEMU_DIAG_OHCI_LIST_PERIODIC = 1,
    XEMU_DIAG_OHCI_LIST_CONTROL = 2,
    XEMU_DIAG_OHCI_LIST_BULK = 3,
} XemuDiagnosticsOhciListKind;

typedef enum XemuDiagnosticsOhciLeafOperation {
    XEMU_DIAG_OHCI_LEAF_NONE = 0,
    XEMU_DIAG_OHCI_LEAF_ED_READ = 1,
    XEMU_DIAG_OHCI_LEAF_ED_WRITE = 2,
    XEMU_DIAG_OHCI_LEAF_TD_READ = 3,
    XEMU_DIAG_OHCI_LEAF_TD_WRITE = 4,
    XEMU_DIAG_OHCI_LEAF_DMA_TO_DEVICE = 5,
    XEMU_DIAG_OHCI_LEAF_DEVICE_LOOKUP = 6,
    XEMU_DIAG_OHCI_LEAF_USB_HANDLE_PACKET = 7,
    XEMU_DIAG_OHCI_LEAF_DMA_FROM_DEVICE = 8,
    XEMU_DIAG_OHCI_LEAF_ASYNC_FLUSH = 9,
    XEMU_DIAG_OHCI_LEAF_ENDPOINT_STOP = 10,
    XEMU_DIAG_OHCI_LEAF_ISO_TD = 11,
} XemuDiagnosticsOhciLeafOperation;

typedef XemuDebugToolsOhciSlowFrameEvent XemuDiagnosticsOhciSlowFrameEvent;

typedef XemuDebugToolsOhciSlowFrameStatus XemuDiagnosticsOhciSlowFrameStatus;

void xemu_diagnostics_ohci_slow_frame_trace_set_enabled(int enabled);
void xemu_diagnostics_ohci_slow_frame_trace_set_threshold_ns(uint64_t threshold_ns);
void xemu_diagnostics_ohci_slow_frame_trace_clear(void);
int xemu_diagnostics_get_ohci_slow_frame_trace_status(
    XemuDiagnosticsOhciSlowFrameStatus *status);
size_t xemu_diagnostics_get_ohci_slow_frame_trace(
    XemuDiagnosticsOhciSlowFrameEvent *events, size_t capacity);

typedef enum XemuDiagnosticsControllerInputGetter {
    XEMU_DIAG_INPUT_GETTER_NONE = 0,
    XEMU_DIAG_INPUT_GETTER_BUTTON_A = 1,
    XEMU_DIAG_INPUT_GETTER_BUTTON_B = 2,
    XEMU_DIAG_INPUT_GETTER_BUTTON_X = 3,
    XEMU_DIAG_INPUT_GETTER_BUTTON_Y = 4,
    XEMU_DIAG_INPUT_GETTER_DPAD_LEFT = 5,
    XEMU_DIAG_INPUT_GETTER_DPAD_UP = 6,
    XEMU_DIAG_INPUT_GETTER_DPAD_RIGHT = 7,
    XEMU_DIAG_INPUT_GETTER_DPAD_DOWN = 8,
    XEMU_DIAG_INPUT_GETTER_BACK = 9,
    XEMU_DIAG_INPUT_GETTER_START = 10,
    XEMU_DIAG_INPUT_GETTER_LEFT_SHOULDER = 11,
    XEMU_DIAG_INPUT_GETTER_RIGHT_SHOULDER = 12,
    XEMU_DIAG_INPUT_GETTER_LEFT_STICK_BUTTON = 13,
    XEMU_DIAG_INPUT_GETTER_RIGHT_STICK_BUTTON = 14,
    XEMU_DIAG_INPUT_GETTER_GUIDE = 15,
    XEMU_DIAG_INPUT_GETTER_AXIS_TRIGGER_LEFT = 16,
    XEMU_DIAG_INPUT_GETTER_AXIS_TRIGGER_RIGHT = 17,
    XEMU_DIAG_INPUT_GETTER_AXIS_LEFT_X = 18,
    XEMU_DIAG_INPUT_GETTER_AXIS_LEFT_Y = 19,
    XEMU_DIAG_INPUT_GETTER_AXIS_RIGHT_X = 20,
    XEMU_DIAG_INPUT_GETTER_AXIS_RIGHT_Y = 21,
} XemuDiagnosticsControllerInputGetter;

typedef XemuDebugToolsControllerInputPollEvent XemuDiagnosticsControllerInputPollEvent;

typedef XemuDebugToolsControllerInputPollStatus XemuDiagnosticsControllerInputPollStatus;

void xemu_diagnostics_controller_input_poll_trace_set_enabled(int enabled);
void xemu_diagnostics_controller_input_poll_trace_set_threshold_ns(
    uint64_t threshold_ns);
void xemu_diagnostics_controller_input_poll_trace_clear(void);
int xemu_diagnostics_get_controller_input_poll_trace_status(
    XemuDiagnosticsControllerInputPollStatus *status);
size_t xemu_diagnostics_get_controller_input_poll_trace(
    XemuDiagnosticsControllerInputPollEvent *events, size_t capacity);


typedef XemuDebugToolsPgraphIncrementEvent XemuDiagnosticsPgraphIncrementEvent;
typedef XemuDebugToolsPtimerIrqLatencyEvent XemuDiagnosticsPtimerIrqLatencyEvent;
typedef XemuDebugToolsLatencyTraceStatus XemuDiagnosticsLatencyTraceStatus;
void xemu_diagnostics_pgraph_increment_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_increment_trace_set_threshold_ns(uint64_t ns);
void xemu_diagnostics_pgraph_increment_trace_clear(void);
int xemu_diagnostics_get_pgraph_increment_trace_status(XemuDiagnosticsLatencyTraceStatus *status);
size_t xemu_diagnostics_get_pgraph_increment_trace(XemuDiagnosticsPgraphIncrementEvent *events, size_t capacity);
void xemu_diagnostics_ptimer_irq_latency_trace_set_enabled(int enabled);
void xemu_diagnostics_ptimer_irq_latency_trace_set_threshold_ns(uint64_t ns);
void xemu_diagnostics_ptimer_irq_latency_trace_clear(void);
int xemu_diagnostics_get_ptimer_irq_latency_trace_status(XemuDiagnosticsLatencyTraceStatus *status);
size_t xemu_diagnostics_get_ptimer_irq_latency_trace(XemuDiagnosticsPtimerIrqLatencyEvent *events, size_t capacity);

typedef enum XemuDiagnosticsBqlTraceEventType {
    XEMU_DIAG_BQL_LONG_WAIT = 1,
    XEMU_DIAG_BQL_LONG_HOLD,
} XemuDiagnosticsBqlTraceEventType;

#define XEMU_DIAG_BQL_TRACE_FILE_MAX 96

typedef XemuDebugToolsBqlTraceEvent XemuDiagnosticsBqlTraceEvent;

typedef XemuDebugToolsBqlTraceStatus XemuDiagnosticsBqlTraceStatus;

void xemu_diagnostics_bql_trace_set_enabled(int enabled);
void xemu_diagnostics_bql_trace_clear(void);
int xemu_diagnostics_get_bql_trace_status(XemuDiagnosticsBqlTraceStatus *status);
size_t xemu_diagnostics_get_bql_trace(XemuDiagnosticsBqlTraceEvent *events,
                                      size_t capacity);

typedef enum XemuDiagnosticsMainLoopLockTraceEventType {
    XEMU_DIAG_MAIN_LOOP_LOCK_LONG_WAIT = 1,
    XEMU_DIAG_MAIN_LOOP_LOCK_LONG_HOLD,
} XemuDiagnosticsMainLoopLockTraceEventType;

#define XEMU_DIAG_MAIN_LOOP_LOCK_TRACE_FILE_MAX 96

typedef XemuDebugToolsMainLoopLockTraceEvent XemuDiagnosticsMainLoopLockTraceEvent;

typedef XemuDebugToolsMainLoopLockTraceStatus XemuDiagnosticsMainLoopLockTraceStatus;

void xemu_diagnostics_main_loop_lock_trace_set_enabled(int enabled);
void xemu_diagnostics_main_loop_lock_trace_clear(void);
int xemu_diagnostics_get_main_loop_lock_trace_status(
    XemuDiagnosticsMainLoopLockTraceStatus *status);
size_t xemu_diagnostics_get_main_loop_lock_trace(
    XemuDiagnosticsMainLoopLockTraceEvent *events, size_t capacity);

#define XEMU_DIAG_MMIO_TRACE_NAME_MAX 96

typedef enum XemuDiagnosticsMmioAccessType {
    XEMU_DIAG_MMIO_READ = 1,
    XEMU_DIAG_MMIO_WRITE = 2,
} XemuDiagnosticsMmioAccessType;

typedef XemuDebugToolsMmioTraceEvent XemuDiagnosticsMmioTraceEvent;

typedef XemuDebugToolsMmioTraceStatus XemuDiagnosticsMmioTraceStatus;

void xemu_diagnostics_mmio_trace_set_enabled(int enabled);
void xemu_diagnostics_mmio_trace_clear(void);
int xemu_diagnostics_get_mmio_trace_status(XemuDiagnosticsMmioTraceStatus *status);
size_t xemu_diagnostics_get_mmio_trace(XemuDiagnosticsMmioTraceEvent *events,
                                       size_t capacity);

#define XEMU_DIAG_PGRAPH_LOCK_TRACE_FILE_MAX 96
#define XEMU_DIAG_PGRAPH_LOCK_TRACE_RENDERER_MAX 32

typedef enum XemuDiagnosticsPgraphLockTraceEventType {
    XEMU_DIAG_PGRAPH_LOCK_LONG_WAIT = 1,
    XEMU_DIAG_PGRAPH_LOCK_LONG_HOLD,
} XemuDiagnosticsPgraphLockTraceEventType;

typedef XemuDebugToolsPgraphLockMethodContext XemuDiagnosticsPgraphLockMethodContext;

typedef XemuDebugToolsPgraphLockStateContext XemuDiagnosticsPgraphLockStateContext;

typedef XemuDebugToolsPgraphLockTraceEvent XemuDiagnosticsPgraphLockTraceEvent;

typedef XemuDebugToolsPgraphLockTraceStatus XemuDiagnosticsPgraphLockTraceStatus;

void xemu_diagnostics_pgraph_lock_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_lock_trace_clear(void);
int xemu_diagnostics_get_pgraph_lock_trace_status(
    XemuDiagnosticsPgraphLockTraceStatus *status);
size_t xemu_diagnostics_get_pgraph_lock_trace(
    XemuDiagnosticsPgraphLockTraceEvent *events, size_t capacity);

typedef enum XemuDiagnosticsFlipStallEventType {
    XEMU_DIAG_FLIP_SET_READ = 1,
    XEMU_DIAG_FLIP_SET_WRITE,
    XEMU_DIAG_FLIP_SET_MODULO,
    XEMU_DIAG_FLIP_INCREMENT_WRITE,
    XEMU_DIAG_FLIP_STALL_BEGIN,
    XEMU_DIAG_FLIP_VK_FINISH_BEGIN,
    XEMU_DIAG_FLIP_VK_FINISH_END,
    XEMU_DIAG_FLIP_WAITING_SET,
    XEMU_DIAG_FLIP_VBLANK_IRQ,
    XEMU_DIAG_FLIP_VBLANK_READ_INCREMENT,
    XEMU_DIAG_FLIP_PFIFO_CHECK_STALL,
    XEMU_DIAG_FLIP_PFIFO_RELEASE,
} XemuDiagnosticsFlipStallEventType;

typedef XemuDebugToolsFlipStallTraceEvent XemuDiagnosticsFlipStallEvent;

typedef XemuDebugToolsFlipStallTraceStatus XemuDiagnosticsFlipStallStatus;

void xemu_diagnostics_flip_stall_trace_set_enabled(int enabled);
void xemu_diagnostics_flip_stall_trace_clear(void);
int xemu_diagnostics_get_flip_stall_trace_status(
    XemuDiagnosticsFlipStallStatus *status);
size_t xemu_diagnostics_get_flip_stall_trace(
    XemuDiagnosticsFlipStallEvent *events, size_t capacity);

typedef enum XemuDiagnosticsSchedulerTraceEventType {
    XEMU_DIAG_SCHED_IDLE_ENTER = 1,
    XEMU_DIAG_SCHED_IDLE_CHECKPOINT,
    XEMU_DIAG_SCHED_IDLE_EXIT,
    XEMU_DIAG_SCHED_TITLE_RETURN,
} XemuDiagnosticsSchedulerTraceEventType;

typedef enum XemuDiagnosticsSchedulerWakeSource {
    XEMU_DIAG_SCHED_WAKE_NONE = 0,
    XEMU_DIAG_SCHED_WAKE_PCRTC_VBLANK,
    XEMU_DIAG_SCHED_WAKE_PTIMER,
    XEMU_DIAG_SCHED_WAKE_PGRAPH,
    XEMU_DIAG_SCHED_WAKE_PFIFO,
    XEMU_DIAG_SCHED_WAKE_OHCI,
} XemuDiagnosticsSchedulerWakeSource;

typedef XemuDebugToolsSchedulerTraceEvent XemuDiagnosticsSchedulerTraceEvent;

typedef XemuDebugToolsSchedulerTraceStatus XemuDiagnosticsSchedulerTraceStatus;

void xemu_diagnostics_scheduler_trace_sample(void);
void xemu_diagnostics_scheduler_trace_set_enabled(int enabled);
void xemu_diagnostics_scheduler_trace_clear(void);
int xemu_diagnostics_get_scheduler_trace_status(
    XemuDiagnosticsSchedulerTraceStatus *status);
size_t xemu_diagnostics_get_scheduler_trace(
    XemuDiagnosticsSchedulerTraceEvent *events, size_t capacity);

#define XEMU_DIAG_PGRAPH_DRAW_TRACE_RENDERER_MAX 32

typedef enum XemuDiagnosticsPgraphDrawTraceStage {
    XEMU_DIAG_PGRAPH_DRAW_SET_BEGIN_END_TOTAL = 1,
    XEMU_DIAG_PGRAPH_DRAW_RENDERER_DRAW_END,
    XEMU_DIAG_PGRAPH_DRAW_RESET_INLINE_BUFFERS,
    XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_END_TOTAL,
    XEMU_DIAG_PGRAPH_DRAW_GL_FLUSH_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_BIND_VERTEX_ATTRIBUTES,
    XEMU_DIAG_PGRAPH_DRAW_INLINE_ELEMENT_SCAN,
    XEMU_DIAG_PGRAPH_DRAW_ELEMENT_CACHE_LOOKUP,
    XEMU_DIAG_PGRAPH_DRAW_GL_BUFFER_DATA,
    XEMU_DIAG_PGRAPH_DRAW_BIND_SHADERS,
    XEMU_DIAG_PGRAPH_DRAW_INLINE_BUFFER_UPLOAD,
    XEMU_DIAG_PGRAPH_DRAW_INLINE_ARRAY_BIND,
    XEMU_DIAG_PGRAPH_DRAW_GL_MULTI_DRAW_ARRAYS,
    XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_ELEMENTS,
    XEMU_DIAG_PGRAPH_DRAW_GL_DRAW_ARRAYS,
    XEMU_DIAG_PGRAPH_DRAW_GL_END_QUERY,
    XEMU_DIAG_PGRAPH_DRAW_SURFACE_DIRTY,
    XEMU_DIAG_PGRAPH_DRAW_VK_DRAW_END_TOTAL,
    XEMU_DIAG_PGRAPH_DRAW_VK_FLUSH_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_BIND,
    XEMU_DIAG_PGRAPH_DRAW_VK_ELEMENT_SCAN,
    XEMU_DIAG_PGRAPH_DRAW_VK_SYNC_VERTEX_RAM,
    XEMU_DIAG_PGRAPH_DRAW_VK_REMAP_ATTRIBUTES,
    XEMU_DIAG_PGRAPH_DRAW_VK_PRE_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_PREP,
    XEMU_DIAG_PGRAPH_DRAW_VK_FRAMEBUFFER_PREP,
    XEMU_DIAG_PGRAPH_DRAW_VK_DESCRIPTOR_UPDATE,
    XEMU_DIAG_PGRAPH_DRAW_VK_COMMAND_BUFFER,
    XEMU_DIAG_PGRAPH_DRAW_VK_UPLOAD,
    XEMU_DIAG_PGRAPH_DRAW_VK_BEGIN_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_VK_RENDER_PASS,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_BIND,
    XEMU_DIAG_PGRAPH_DRAW_VK_DESCRIPTOR_BIND,
    XEMU_DIAG_PGRAPH_DRAW_VK_ISSUE_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_VK_END_DRAW,
    XEMU_DIAG_PGRAPH_DRAW_VK_SURFACE_DIRTY,
    XEMU_DIAG_PGRAPH_DRAW_VK_TEXTURE_BIND,
    XEMU_DIAG_PGRAPH_DRAW_VK_SHADER_BIND,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_STATE_KEY,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_CACHE_LOOKUP,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_BUILD_STATE,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_CREATE,
    XEMU_DIAG_PGRAPH_DRAW_VK_PIPELINE_INSTALL,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_RANGE_PREP = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_RANGE_PREP,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_DIRTY_CHECK = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_DIRTY_CHECK,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_RANGE_UPDATE = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_RANGE_UPDATE,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_SURFACE_DOWNLOAD = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_SURFACE_DOWNLOAD,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_OVERLAP_CHECK = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_OVERLAP_CHECK,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_DIRTY_FINISH = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_DIRTY_FINISH,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_COPY = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_COPY,
    XEMU_DIAG_PGRAPH_DRAW_VK_VERTEX_BITMAP = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_BITMAP,
    XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_TOTAL = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_FINISH_TOTAL,
    XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_QUEUE_SUBMIT = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_FINISH_QUEUE_SUBMIT,
    XEMU_DIAG_PGRAPH_DRAW_VK_FINISH_FENCE_WAIT = XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_FINISH_FENCE_WAIT,
} XemuDiagnosticsPgraphDrawTraceStage;

typedef enum XemuDiagnosticsPgraphDrawTracePath {
    XEMU_DIAG_PGRAPH_DRAW_PATH_UNKNOWN = 0,
    XEMU_DIAG_PGRAPH_DRAW_PATH_DRAW_ARRAYS,
    XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_ELEMENTS,
    XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_BUFFER,
    XEMU_DIAG_PGRAPH_DRAW_PATH_INLINE_ARRAY,
    XEMU_DIAG_PGRAPH_DRAW_PATH_EMPTY,
} XemuDiagnosticsPgraphDrawTracePath;

typedef XemuDebugToolsPgraphDrawTraceEvent XemuDiagnosticsPgraphDrawTraceEvent;

typedef XemuDebugToolsPgraphDrawTraceStatus XemuDiagnosticsPgraphDrawTraceStatus;

void xemu_diagnostics_pgraph_draw_trace_set_enabled(int enabled);
void xemu_diagnostics_pgraph_draw_trace_clear(void);
int xemu_diagnostics_get_pgraph_draw_trace_status(
    XemuDiagnosticsPgraphDrawTraceStatus *status);
size_t xemu_diagnostics_get_pgraph_draw_trace(
    XemuDiagnosticsPgraphDrawTraceEvent *events, size_t capacity);


#define XEMU_DIAG_CONTROLLER_XID_HOST_AXIS_COUNT 6
#define XEMU_DIAG_CONTROLLER_XID_ANALOG_BUTTON_COUNT 8
#define XEMU_DIAG_CONTROLLER_XID_REPORT_MAX 20
#define XEMU_DIAG_CONTROLLER_XID_NAME_MAX 96
#define XEMU_DIAG_CONTROLLER_XID_GUID_MAX 40

typedef enum XemuDiagnosticsControllerXidTraceEventType {
    XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_ADDED = 1,
    XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_OPENED,
    XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_OPEN_FAILED,
    XEMU_DIAG_CONTROLLER_XID_HOST_GAMEPAD_REMOVED,
    XEMU_DIAG_CONTROLLER_XID_HOST_BIND,
    XEMU_DIAG_CONTROLLER_XID_HOST_UNBIND,
    XEMU_DIAG_CONTROLLER_XID_HOST_INPUT_STATE,
    XEMU_DIAG_CONTROLLER_XID_XID_REALIZE,
    XEMU_DIAG_CONTROLLER_XID_XID_UNREALIZE,
    XEMU_DIAG_CONTROLLER_XID_XID_RESET,
    XEMU_DIAG_CONTROLLER_XID_XID_GET_REPORT,
    XEMU_DIAG_CONTROLLER_XID_XID_INTERRUPT_IN,
    XEMU_DIAG_CONTROLLER_XID_XID_INPUT_STATE,
    XEMU_DIAG_CONTROLLER_XID_XID_BOUND_MISSING,
    XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_ATTACH,
    XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_DETACH,
    XEMU_DIAG_CONTROLLER_XID_OHCI_RHSC,
    XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE,
    XEMU_DIAG_CONTROLLER_XID_OHCI_PORT_RESET,
    XEMU_DIAG_CONTROLLER_XID_OHCI_SETUP_TD,
    XEMU_DIAG_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING,
    XEMU_DIAG_CONTROLLER_XID_USB_CONTROL_REQUEST,
    XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_NEUTRAL,
    XEMU_DIAG_CONTROLLER_XID_HOST_PERSISTENT_REATTACHED,
    XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_ON,
    XEMU_DIAG_CONTROLLER_XID_INPUT_TEST_MODE_OFF,
    XEMU_DIAG_CONTROLLER_XID_XID_IN_PACKET_COMPLETE,
    XEMU_DIAG_CONTROLLER_XID_OHCI_TD_COMPLETE,
    XEMU_DIAG_CONTROLLER_XID_OHCI_DONE_HEAD,
    XEMU_DIAG_CONTROLLER_XID_OHCI_WDH_IRQ,
    XEMU_DIAG_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE,
    XEMU_DIAG_CONTROLLER_XID_EVENT_COUNT,
} XemuDiagnosticsControllerXidTraceEventType;

typedef XemuDebugToolsControllerXidTraceEvent XemuDiagnosticsControllerXidTraceEvent;

typedef XemuDebugToolsControllerXidTraceStatus XemuDiagnosticsControllerXidTraceStatus;

void xemu_diagnostics_controller_xid_trace_set_enabled(int enabled);
void xemu_diagnostics_controller_xid_trace_clear(void);
int xemu_diagnostics_get_controller_xid_trace_status(
    XemuDiagnosticsControllerXidTraceStatus *status);
size_t xemu_diagnostics_get_controller_xid_trace(
    XemuDiagnosticsControllerXidTraceEvent *events, size_t capacity);

typedef XemuDebugToolsGuestInputConsumerTraceEvent
    XemuDiagnosticsGuestInputConsumerTraceEvent;
typedef XemuDebugToolsGuestInputConsumerTraceStatus
    XemuDiagnosticsGuestInputConsumerTraceStatus;

void xemu_diagnostics_guest_input_consumer_trace_set_enabled(int enabled);
void xemu_diagnostics_guest_input_consumer_trace_clear(void);
int xemu_diagnostics_get_guest_input_consumer_trace_status(
    XemuDiagnosticsGuestInputConsumerTraceStatus *status);
size_t xemu_diagnostics_get_guest_input_consumer_trace(
    XemuDiagnosticsGuestInputConsumerTraceEvent *events, size_t capacity);


typedef XemuDebugToolsPtimerLateCaptureStatus
    XemuDiagnosticsPtimerLateCaptureStatus;
typedef XemuDebugToolsPtimerLateCaptureSnapshot
    XemuDiagnosticsPtimerLateCaptureSnapshot;

void xemu_diagnostics_ptimer_late_capture_set_enabled(int enabled);
void xemu_diagnostics_ptimer_late_capture_clear(void);
int xemu_diagnostics_get_ptimer_late_capture_status(
    XemuDiagnosticsPtimerLateCaptureStatus *status);
int xemu_diagnostics_get_ptimer_late_capture(
    XemuDiagnosticsPtimerLateCaptureSnapshot *snapshot);

typedef XemuDebugToolsD3dCallbackCaptureStatus
    XemuDiagnosticsD3dCallbackCaptureStatus;
typedef XemuDebugToolsD3dCallbackCaptureSnapshot
    XemuDiagnosticsD3dCallbackCaptureSnapshot;

void xemu_diagnostics_d3d_callback_capture_set_enabled(int enabled);
void xemu_diagnostics_d3d_callback_capture_clear(void);
int xemu_diagnostics_get_d3d_callback_capture_status(
    XemuDiagnosticsD3dCallbackCaptureStatus *status);
int xemu_diagnostics_get_d3d_callback_capture(
    XemuDiagnosticsD3dCallbackCaptureSnapshot *snapshot);

typedef XemuDebugToolsPtimerIrqDeliveryEvent
    XemuDiagnosticsPtimerIrqDeliveryEvent;
typedef XemuDebugToolsPtimerIrqDeliveryCapture
    XemuDiagnosticsPtimerIrqDeliveryCapture;
typedef XemuDebugToolsPtimerIrqDeliveryStatus
    XemuDiagnosticsPtimerIrqDeliveryStatus;
typedef XemuDebugToolsPtimerIrqDeliverySnapshot
    XemuDiagnosticsPtimerIrqDeliverySnapshot;

void xemu_diagnostics_ptimer_irq_delivery_trace_set_enabled(int enabled);
void xemu_diagnostics_ptimer_irq_delivery_trace_clear(void);
int xemu_diagnostics_get_ptimer_irq_delivery_trace_status(
    XemuDiagnosticsPtimerIrqDeliveryStatus *status);
int xemu_diagnostics_get_ptimer_irq_delivery_trace(
    XemuDiagnosticsPtimerIrqDeliverySnapshot *snapshot);

typedef XemuDebugToolsGuestTimerDeadlineTraceEvent
    XemuDiagnosticsGuestTimerDeadlineTraceEvent;
typedef XemuDebugToolsGuestTimerDeadlineTraceStatus
    XemuDiagnosticsGuestTimerDeadlineTraceStatus;

typedef XemuDebugToolsD3dTimerStateEvent
    XemuDiagnosticsD3dTimerStateEvent;
typedef XemuDebugToolsD3dTimerStateStatus
    XemuDiagnosticsD3dTimerStateStatus;

void xemu_diagnostics_guest_timer_deadline_trace_set_enabled(int enabled);
void xemu_diagnostics_guest_timer_deadline_trace_clear(void);
int xemu_diagnostics_get_guest_timer_deadline_trace_status(
    XemuDiagnosticsGuestTimerDeadlineTraceStatus *status);
size_t xemu_diagnostics_get_guest_timer_deadline_trace(
    XemuDiagnosticsGuestTimerDeadlineTraceEvent *events, size_t capacity);

int xemu_diagnostics_get_d3d_timer_state_trace_status(
    XemuDiagnosticsD3dTimerStateStatus *status);
size_t xemu_diagnostics_get_d3d_timer_state_trace(
    XemuDiagnosticsD3dTimerStateEvent *events, size_t capacity);

typedef XemuDebugToolsHostStallEvent XemuDiagnosticsHostStallEvent;
typedef XemuDebugToolsHostStallStatus XemuDiagnosticsHostStallStatus;

void xemu_diagnostics_host_stall_trace_set_enabled(int enabled);
void xemu_diagnostics_host_stall_trace_clear(void);
int xemu_diagnostics_get_host_stall_trace_status(
    XemuDiagnosticsHostStallStatus *status);
size_t xemu_diagnostics_get_host_stall_trace(
    XemuDiagnosticsHostStallEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
