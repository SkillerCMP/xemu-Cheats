#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/bswap.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "hw/xbox/nv2a/nv2a_int.h"
#include "cpu.h"
#include "system/cpus.h"
#include "system/hw_accel.h"
#include "system/runstate.h"

#include "scheduler-trace.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsSchedulerTraceRing {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;

    uint64_t last_sample_host_ns;
    uint32_t last_sample_pc;
    uint32_t last_title_pc;

    bool active_idle;
    uint64_t active_idle_start_host_ns;
    uint64_t active_idle_start_virtual_ns;
    uint64_t next_checkpoint_ns;
    uint64_t longest_completed_idle_ns;

    bool title_return_pending;
    uint64_t wake_idle_start_host_ns;

    uint32_t last_irq_source;
    uint64_t last_irq_host_ns;
    uint32_t last_irq_pending;
    uint32_t last_irq_enabled;
    uint32_t idle_vblank_count;
    uint32_t idle_ptimer_count;
    uint32_t idle_pgraph_count;
    uint32_t idle_pfifo_count;
    uint32_t idle_ohci_count;

    XemuDebugToolsSchedulerTraceEvent *events[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsSchedulerTraceRing;

static XemuDebugToolsSchedulerTraceRing g_scheduler_trace;

static void scheduler_trace_init(void)
{
    if (!g_scheduler_trace.initialized) {
        qemu_mutex_init(&g_scheduler_trace.lock);
        g_scheduler_trace.buffer_multiplier = 1;
        g_scheduler_trace.initialized = true;
    }
}

static void scheduler_trace_reset_idle_locked(void)
{
    g_scheduler_trace.last_irq_source = XEMU_DEBUG_TOOLS_SCHED_WAKE_NONE;
    g_scheduler_trace.last_irq_host_ns = 0;
    g_scheduler_trace.last_irq_pending = 0;
    g_scheduler_trace.last_irq_enabled = 0;
    g_scheduler_trace.idle_vblank_count = 0;
    g_scheduler_trace.idle_ptimer_count = 0;
    g_scheduler_trace.idle_pgraph_count = 0;
    g_scheduler_trace.idle_pfifo_count = 0;
    g_scheduler_trace.idle_ohci_count = 0;
}

static void scheduler_trace_reset_locked(void)
{
    g_scheduler_trace.count = 0;
    g_scheduler_trace.write_index = 0;
    g_scheduler_trace.total_events = 0;
    g_scheduler_trace.overwritten_events = 0;
    g_scheduler_trace.last_sample_host_ns = 0;
    g_scheduler_trace.last_sample_pc = 0;
    g_scheduler_trace.last_title_pc = 0;
    g_scheduler_trace.active_idle = false;
    g_scheduler_trace.active_idle_start_host_ns = 0;
    g_scheduler_trace.active_idle_start_virtual_ns = 0;
    g_scheduler_trace.next_checkpoint_ns = 100000000ULL;
    g_scheduler_trace.longest_completed_idle_ns = 0;
    g_scheduler_trace.title_return_pending = false;
    g_scheduler_trace.wake_idle_start_host_ns = 0;
    scheduler_trace_reset_idle_locked();
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_scheduler_trace.events, XemuDebugToolsSchedulerTraceEvent,
        XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY,
        g_scheduler_trace.buffer_multiplier);
}

static bool scheduler_trace_is_title_pc(uint32_t pc)
{
    return pc >= 0x00010000u && pc < 0x80000000u;
}

static bool scheduler_trace_is_idle_pc(uint32_t pc)
{
    return pc >= XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_START &&
           pc <= XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_END;
}

static uint32_t scheduler_trace_read_u32(CPUState *cpu, uint32_t address)
{
    uint8_t bytes[4];
    if (!cpu || cpu_memory_rw_debug(cpu, address, bytes, sizeof(bytes), 0) != 0) {
        return 0;
    }
    return ldl_le_p(bytes);
}

static void scheduler_trace_fill_context(
    XemuDebugToolsSchedulerTraceEvent *event, CPUState *cpu, uint32_t pc,
    uint64_t host_ns)
{
    CPUX86State *env = NULL;
    NV2AState *d = g_nv2a;

    event->host_ns = host_ns;
    event->qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event->guest_pc = pc;
    event->cpu_index = cpu ? cpu->cpu_index : -1;

    if (cpu) {
        /* This runs from the BQL-owned Diagnostics tick and only for retained
         * transition/checkpoint events, not for every lightweight PC sample. */
        cpu_synchronize_state(cpu);
        env = &X86_CPU(cpu)->env;
        event->eflags = env->eflags;
        event->ebx = (uint32_t)env->regs[R_EBX];
        event->ebp = (uint32_t)env->regs[R_EBP];
        event->esp = (uint32_t)env->regs[R_ESP];
        event->scheduler_slot_28 =
            scheduler_trace_read_u32(cpu, event->ebx + 0x28u);
        event->scheduler_slot_2c =
            scheduler_trace_read_u32(cpu, event->ebx + 0x2Cu);
        event->interrupt_request = cpu->interrupt_request;
        event->exception_index = cpu->exception_index;
        event->halted = cpu->halted ? 1u : 0u;
    }

    if (d) {
        event->pmc_pending = d->pmc.pending_interrupts;
        event->pmc_enabled = d->pmc.enabled_interrupts;
        event->pfifo_pending = d->pfifo.pending_interrupts;
        event->pfifo_enabled = d->pfifo.enabled_interrupts;
        event->pgraph_pending = qatomic_read(&d->pgraph.pending_interrupts);
        event->pgraph_enabled = qatomic_read(&d->pgraph.enabled_interrupts);
        event->pcrtc_pending = d->pcrtc.pending_interrupts;
        event->pcrtc_enabled = d->pcrtc.enabled_interrupts;
        event->ptimer_pending = d->ptimer.pending_interrupts;
        event->ptimer_enabled = d->ptimer.enabled_interrupts;
    }
}

static void scheduler_trace_store_locked(
    XemuDebugToolsSchedulerTraceEvent *event)
{
    size_t cap = xemu_debug_tools_scheduler_trace_get_buffer_capacity();
    size_t slot = g_scheduler_trace.write_index;

    event->sequence = g_scheduler_trace.total_events++;
    event->last_title_pc = g_scheduler_trace.last_title_pc;
    event->last_irq_source = g_scheduler_trace.last_irq_source;
    event->last_irq_host_ns = g_scheduler_trace.last_irq_host_ns;
    event->last_irq_pending = g_scheduler_trace.last_irq_pending;
    event->last_irq_enabled = g_scheduler_trace.last_irq_enabled;
    event->idle_vblank_count = g_scheduler_trace.idle_vblank_count;
    event->idle_ptimer_count = g_scheduler_trace.idle_ptimer_count;
    event->idle_pgraph_count = g_scheduler_trace.idle_pgraph_count;
    event->idle_pfifo_count = g_scheduler_trace.idle_pfifo_count;
    event->idle_ohci_count = g_scheduler_trace.idle_ohci_count;
    if (g_scheduler_trace.last_irq_host_ns != 0 &&
        event->host_ns >= g_scheduler_trace.last_irq_host_ns) {
        event->last_irq_age_ns =
            event->host_ns - g_scheduler_trace.last_irq_host_ns;
    }

    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_scheduler_trace.events, XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY,
        slot) = *event;
    g_scheduler_trace.write_index = (slot + 1) % cap;
    if (g_scheduler_trace.count < cap) {
        g_scheduler_trace.count++;
    } else {
        g_scheduler_trace.overwritten_events++;
    }
}

static void scheduler_trace_emit(unsigned int event_type, CPUState *cpu,
                                 uint32_t pc, uint64_t idle_age_ns,
                                 uint64_t duration_ns, uint64_t host_ns)
{
    XemuDebugToolsSchedulerTraceEvent event = { 0 };

    event.event_type = event_type;
    event.idle_age_ns = idle_age_ns;
    event.duration_ns = duration_ns;
    scheduler_trace_fill_context(&event, cpu, pc, host_ns);

    qemu_mutex_lock(&g_scheduler_trace.lock);
    if (qatomic_read(&g_scheduler_trace.enabled)) {
        scheduler_trace_store_locked(&event);
    }
    qemu_mutex_unlock(&g_scheduler_trace.lock);
}

void xemu_debug_tools_scheduler_trace_note_irq(
    unsigned int source, uint32_t pending, uint32_t enabled)
{
    uint64_t now_ns;

    if (!g_scheduler_trace.initialized ||
        !qatomic_read(&g_scheduler_trace.enabled)) {
        return;
    }

    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    qemu_mutex_lock(&g_scheduler_trace.lock);
    if (g_scheduler_trace.active_idle) {
        g_scheduler_trace.last_irq_source = source;
        g_scheduler_trace.last_irq_host_ns = now_ns;
        g_scheduler_trace.last_irq_pending = pending;
        g_scheduler_trace.last_irq_enabled = enabled;
        switch (source) {
        case XEMU_DEBUG_TOOLS_SCHED_WAKE_PCRTC_VBLANK:
            g_scheduler_trace.idle_vblank_count++;
            break;
        case XEMU_DEBUG_TOOLS_SCHED_WAKE_PTIMER:
            g_scheduler_trace.idle_ptimer_count++;
            break;
        case XEMU_DEBUG_TOOLS_SCHED_WAKE_PGRAPH:
            g_scheduler_trace.idle_pgraph_count++;
            break;
        case XEMU_DEBUG_TOOLS_SCHED_WAKE_PFIFO:
            g_scheduler_trace.idle_pfifo_count++;
            break;
        case XEMU_DEBUG_TOOLS_SCHED_WAKE_OHCI:
            g_scheduler_trace.idle_ohci_count++;
            break;
        default:
            break;
        }
    }
    qemu_mutex_unlock(&g_scheduler_trace.lock);
}

void xemu_debug_tools_scheduler_trace_sample(void)
{
    CPUState *cpu;
    uint64_t host_ns;
    uint32_t pc;
    bool emit_enter = false;
    bool emit_checkpoint = false;
    bool emit_exit = false;
    bool emit_title_return = false;
    uint64_t idle_age_ns = 0;
    uint64_t idle_duration_ns = 0;
    uint64_t title_return_duration_ns = 0;

    if (!g_scheduler_trace.initialized ||
        !qatomic_read(&g_scheduler_trace.enabled) ||
        !runstate_is_running()) {
        return;
    }

    host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    qemu_mutex_lock(&g_scheduler_trace.lock);
    if (g_scheduler_trace.last_sample_host_ns != 0 &&
        host_ns - g_scheduler_trace.last_sample_host_ns < 5000000ULL) {
        qemu_mutex_unlock(&g_scheduler_trace.lock);
        return;
    }
    g_scheduler_trace.last_sample_host_ns = host_ns;
    qemu_mutex_unlock(&g_scheduler_trace.lock);

    cpu = qemu_get_cpu(0);
    if (!cpu || !cpu->cc || !cpu->cc->get_pc) {
        return;
    }
    pc = (uint32_t)cpu->cc->get_pc(cpu);

    qemu_mutex_lock(&g_scheduler_trace.lock);
    g_scheduler_trace.last_sample_pc = pc;

    if (scheduler_trace_is_title_pc(pc)) {
        g_scheduler_trace.last_title_pc = pc;
        if (g_scheduler_trace.title_return_pending) {
            emit_title_return = true;
            if (host_ns >= g_scheduler_trace.wake_idle_start_host_ns) {
                title_return_duration_ns =
                    host_ns - g_scheduler_trace.wake_idle_start_host_ns;
            }
            g_scheduler_trace.title_return_pending = false;
            g_scheduler_trace.wake_idle_start_host_ns = 0;
        }
    }

    if (scheduler_trace_is_idle_pc(pc)) {
        if (!g_scheduler_trace.active_idle) {
            g_scheduler_trace.active_idle = true;
            g_scheduler_trace.active_idle_start_host_ns = host_ns;
            g_scheduler_trace.active_idle_start_virtual_ns =
                qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
            g_scheduler_trace.next_checkpoint_ns = 100000000ULL;
            scheduler_trace_reset_idle_locked();
            emit_enter = true;
        } else if (host_ns >= g_scheduler_trace.active_idle_start_host_ns) {
            idle_age_ns = host_ns - g_scheduler_trace.active_idle_start_host_ns;
            if (idle_age_ns >= g_scheduler_trace.next_checkpoint_ns) {
                emit_checkpoint = true;
                if (g_scheduler_trace.next_checkpoint_ns < 250000000ULL) {
                    g_scheduler_trace.next_checkpoint_ns = 250000000ULL;
                } else if (g_scheduler_trace.next_checkpoint_ns < 500000000ULL) {
                    g_scheduler_trace.next_checkpoint_ns = 500000000ULL;
                } else if (g_scheduler_trace.next_checkpoint_ns < 1000000000ULL) {
                    g_scheduler_trace.next_checkpoint_ns = 1000000000ULL;
                } else {
                    g_scheduler_trace.next_checkpoint_ns += 1000000000ULL;
                }
            }
        }
    } else if (g_scheduler_trace.active_idle) {
        if (host_ns >= g_scheduler_trace.active_idle_start_host_ns) {
            idle_duration_ns =
                host_ns - g_scheduler_trace.active_idle_start_host_ns;
        }
        if (idle_duration_ns > g_scheduler_trace.longest_completed_idle_ns) {
            g_scheduler_trace.longest_completed_idle_ns = idle_duration_ns;
        }
        g_scheduler_trace.title_return_pending = true;
        g_scheduler_trace.wake_idle_start_host_ns =
            g_scheduler_trace.active_idle_start_host_ns;
        g_scheduler_trace.active_idle = false;
        g_scheduler_trace.active_idle_start_host_ns = 0;
        g_scheduler_trace.active_idle_start_virtual_ns = 0;
        emit_exit = true;
    }
    qemu_mutex_unlock(&g_scheduler_trace.lock);

    if (emit_enter) {
        scheduler_trace_emit(XEMU_DEBUG_TOOLS_SCHED_IDLE_ENTER, cpu, pc, 0, 0,
                             host_ns);
    }
    if (emit_checkpoint) {
        scheduler_trace_emit(XEMU_DEBUG_TOOLS_SCHED_IDLE_CHECKPOINT, cpu, pc,
                             idle_age_ns, 0, host_ns);
    }
    if (emit_exit) {
        scheduler_trace_emit(XEMU_DEBUG_TOOLS_SCHED_IDLE_EXIT, cpu, pc,
                             idle_duration_ns, idle_duration_ns, host_ns);
    }
    if (emit_title_return) {
        scheduler_trace_emit(XEMU_DEBUG_TOOLS_SCHED_TITLE_RETURN, cpu, pc, 0,
                             title_return_duration_ns, host_ns);
    }
}

void xemu_debug_tools_scheduler_trace_set_enabled(int enabled)
{
    bool ok = true;
    scheduler_trace_init();
    qemu_mutex_lock(&g_scheduler_trace.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_scheduler_trace.events, XemuDebugToolsSchedulerTraceEvent,
            XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY,
            g_scheduler_trace.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&g_scheduler_trace.lock);
            return;
        }
    }
    if (enabled && !g_scheduler_trace.enabled) {
        scheduler_trace_reset_locked();
    }
    qatomic_set(&g_scheduler_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&g_scheduler_trace.lock);
}

void xemu_debug_tools_scheduler_trace_clear(void)
{
    scheduler_trace_init();
    qemu_mutex_lock(&g_scheduler_trace.lock);
    scheduler_trace_reset_locked();
    qemu_mutex_unlock(&g_scheduler_trace.lock);
}

int xemu_debug_tools_scheduler_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok;
    scheduler_trace_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_scheduler_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_scheduler_trace.events, XemuDebugToolsSchedulerTraceEvent,
        XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY, multiplier, ok);
    if (ok) {
        g_scheduler_trace.buffer_multiplier = multiplier;
        scheduler_trace_reset_locked();
    }
    qemu_mutex_unlock(&g_scheduler_trace.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_scheduler_trace_get_buffer_multiplier(void)
{
    return g_scheduler_trace.buffer_multiplier ?
        g_scheduler_trace.buffer_multiplier : 1;
}

size_t xemu_debug_tools_scheduler_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY,
        xemu_debug_tools_scheduler_trace_get_buffer_multiplier());
}

void xemu_debug_tools_scheduler_trace_get_status(
    XemuDebugToolsSchedulerTraceStatus *status)
{
    uint64_t now_ns;
    if (!status) {
        return;
    }
    scheduler_trace_init();
    memset(status, 0, sizeof(*status));
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    qemu_mutex_lock(&g_scheduler_trace.lock);
    status->enabled = g_scheduler_trace.enabled;
    status->count = g_scheduler_trace.count;
    status->total_events = g_scheduler_trace.total_events;
    status->overwritten_events = g_scheduler_trace.overwritten_events;
    status->active_idle = g_scheduler_trace.active_idle ? 1u : 0u;
    status->active_idle_start_host_ns =
        g_scheduler_trace.active_idle_start_host_ns;
    status->active_idle_start_virtual_ns =
        g_scheduler_trace.active_idle_start_virtual_ns;
    if (g_scheduler_trace.active_idle &&
        now_ns >= g_scheduler_trace.active_idle_start_host_ns) {
        status->active_idle_age_ns =
            now_ns - g_scheduler_trace.active_idle_start_host_ns;
    }
    status->longest_completed_idle_ns =
        g_scheduler_trace.longest_completed_idle_ns;
    status->last_sample_pc = g_scheduler_trace.last_sample_pc;
    status->last_title_pc = g_scheduler_trace.last_title_pc;
    status->last_irq_source = g_scheduler_trace.last_irq_source;
    status->last_irq_host_ns = g_scheduler_trace.last_irq_host_ns;
    status->idle_pc_start = XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_START;
    status->idle_pc_end = XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_END;
    qemu_mutex_unlock(&g_scheduler_trace.lock);
}

size_t xemu_debug_tools_scheduler_trace_snapshot(
    XemuDebugToolsSchedulerTraceEvent *events, size_t capacity)
{
    size_t ring_capacity;
    size_t count;
    size_t oldest;
    size_t i;

    if (!events || capacity == 0) {
        return 0;
    }
    scheduler_trace_init();
    qemu_mutex_lock(&g_scheduler_trace.lock);
    ring_capacity = xemu_debug_tools_scheduler_trace_get_buffer_capacity();
    count = MIN(g_scheduler_trace.count, capacity);
    oldest = (g_scheduler_trace.write_index + ring_capacity -
              g_scheduler_trace.count) % ring_capacity;
    if (count < g_scheduler_trace.count) {
        oldest = (oldest + (g_scheduler_trace.count - count)) % ring_capacity;
    }
    for (i = 0; i < count; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_scheduler_trace.events,
            XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY,
            (oldest + i) % ring_capacity);
    }
    qemu_mutex_unlock(&g_scheduler_trace.lock);
    return count;
}
