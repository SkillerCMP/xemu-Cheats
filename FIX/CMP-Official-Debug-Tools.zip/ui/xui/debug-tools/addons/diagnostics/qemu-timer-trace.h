/* xemu Debug Tools - Diagnostics-owned QEMU timer dispatch flight recorder. */
#pragma once

#include "qemu-timer-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY 16384

typedef struct XemuDebugToolsQemuTimerTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    int64_t timeout_ns;
    int64_t timer_expire_ns;
    int64_t timer_delta_ns;
    int64_t wait_elapsed_host_ns;
    int64_t wait_elapsed_virtual_ns;
    int64_t dispatch_late_ns;
    int64_t value;
    uint32_t event_type;
    int32_t clock_type;
    int32_t thread_id;
    uint32_t watched_timer_pending;
} XemuDebugToolsQemuTimerTraceEvent;

typedef struct XemuDebugToolsQemuTimerTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    int64_t watched_timer_expire_ns;
} XemuDebugToolsQemuTimerTraceStatus;

void xemu_debug_tools_qemu_timer_trace_set_enabled(int enabled);
void xemu_debug_tools_qemu_timer_trace_clear(void);
int xemu_debug_tools_qemu_timer_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_qemu_timer_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_qemu_timer_trace_get_buffer_capacity(void);
void xemu_debug_tools_qemu_timer_trace_get_status(
    XemuDebugToolsQemuTimerTraceStatus *status);
size_t xemu_debug_tools_qemu_timer_trace_snapshot(
    XemuDebugToolsQemuTimerTraceEvent *events,
    size_t capacity);

#ifdef __cplusplus
}
#endif
