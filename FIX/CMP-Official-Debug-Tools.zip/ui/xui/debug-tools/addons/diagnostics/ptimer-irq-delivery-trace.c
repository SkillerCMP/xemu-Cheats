/* Info: Focused PTIMER -> PIC -> TCG interrupt-delivery forensic trace. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "cpu.h"
#include "exec/translation-block.h"

#include "ptimer-irq-delivery-trace.h"

typedef struct XemuDebugToolsPtimerIrqDeliveryState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    int active;
    uint64_t total_windows;
    uint64_t slow_windows;
    uint64_t capture_count;
    uint64_t overwritten_captures;
    size_t capture_write_index;
    size_t stored_captures;
    uint64_t event_sequence;
    uint64_t last_sample_virtual_ns;
    uint32_t last_sample_interrupt_request;
    uint32_t last_sample_eflags;
    uint32_t last_sample_hflags;
    uint32_t last_sample_hflags2;
    int last_sample_cflags_next_tb;
    uint32_t last_sample_pc;
    int overdue_emitted;
    XemuDebugToolsPtimerIrqDeliveryCapture current;
    XemuDebugToolsPtimerIrqDeliveryCapture
        captures[XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT];
} XemuDebugToolsPtimerIrqDeliveryState;

static XemuDebugToolsPtimerIrqDeliveryState g_delivery;

static void delivery_init(void)
{
    if (!g_delivery.initialized) {
        qemu_mutex_init(&g_delivery.lock);
        g_delivery.initialized = true;
    }
}

static uint64_t delivery_now_virtual(void)
{
    return qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
}

static uint64_t delivery_now_host(void)
{
    return qemu_clock_get_ns(QEMU_CLOCK_HOST);
}

static void delivery_fill_cpu(XemuDebugToolsPtimerIrqDeliveryEvent *e,
                              CPUState *cs)
{
    X86CPU *cpu;
    CPUX86State *env;
    uint32_t req;
    bool hard_eligible;

    if (e == NULL || cs == NULL) {
        return;
    }

    cpu = X86_CPU(cs);
    env = &cpu->env;
    req = qatomic_read(&cs->interrupt_request);
    hard_eligible = (req & CPU_INTERRUPT_HARD) &&
        (((env->hflags2 & HF2_VINTR_MASK) &&
          (env->hflags2 & HF2_HIF_MASK)) ||
         (!(env->hflags2 & HF2_VINTR_MASK) &&
          (env->eflags & IF_MASK) &&
          !(env->hflags & HF_INHIBIT_IRQ_MASK)));

    e->cpu_valid = 1;
    e->interrupt_request = req;
    e->cflags_next_tb = cs->cflags_next_tb;
    e->eflags = env->eflags;
    e->hflags = env->hflags;
    e->hflags2 = env->hflags2;
    e->hard_present = (req & CPU_INTERRUPT_HARD) ? 1 : 0;
    e->hard_eligible = hard_eligible ? 1 : 0;
    e->if_enabled = (env->eflags & IF_MASK) ? 1 : 0;
    e->inhibit_irq = (env->hflags & HF_INHIBIT_IRQ_MASK) ? 1 : 0;
    e->noirq_cflags =
        (cs->cflags_next_tb != -1 &&
         (cs->cflags_next_tb & CF_NOIRQ)) ? 1 : 0;
    e->cpu_halted = cs->halted ? 1 : 0;
    e->exception_index = cs->exception_index;
    if (cs->cc != NULL && cs->cc->get_pc != NULL) {
        e->guest_pc = (uint32_t)cs->cc->get_pc(cs);
    }
}

static bool delivery_record_locked(XemuDebugToolsPtimerIrqDeliveryEvent *e,
                                   bool sample)
{
    XemuDebugToolsPtimerIrqDeliveryCapture *c = &g_delivery.current;

    if (!g_delivery.active || e == NULL) {
        return false;
    }

    if (sample && c->sampled_tcg_checks >=
                      XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_BUDGET) {
        ++c->dropped_samples;
        return false;
    }
    if (c->event_count >= XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_EVENTS) {
        if (sample) {
            ++c->dropped_samples;
        }
        return false;
    }

    e->sequence = g_delivery.event_sequence++;
    e->virtual_ns = delivery_now_virtual();
    e->host_ns = delivery_now_host();
    if (c->irq_set_virtual_ns != 0 &&
        e->virtual_ns >= c->irq_set_virtual_ns) {
        e->since_set_ns = e->virtual_ns - c->irq_set_virtual_ns;
    }
    c->events[c->event_count++] = *e;
    if (sample) {
        ++c->sampled_tcg_checks;
    }
    return true;
}

static uint32_t delivery_classify(
    const XemuDebugToolsPtimerIrqDeliveryCapture *c)
{
    if (c == NULL) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_NONE;
    }
    if (c->hard_eligible_samples != 0 && c->hard_take_events == 0) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_TCG_NOT_TAKEN;
    }
    if (c->hard_take_events != 0) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_HARD_TAKEN_DURING_WINDOW;
    }
    if (c->hard_present_samples == 0 || !c->saw_pic_cpu_assert) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_CPU_HARD_MISSING;
    }
    if (c->inhibit_samples != 0 && c->if_disabled_samples == 0) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_IRQ_INHIBITED;
    }
    if (c->if_disabled_samples != 0 && c->hard_eligible_samples == 0) {
        return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_GUEST_IF_MASKED;
    }
    return XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_OTHER;
}

int xemu_debug_tools_ptimer_irq_delivery_trace_active(void)
{
    return qatomic_read(&g_delivery.enabled) &&
           qatomic_read(&g_delivery.active);
}

void xemu_debug_tools_ptimer_irq_delivery_trace_set_enabled(int enabled)
{
    bool was_enabled;

    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    was_enabled = qatomic_read(&g_delivery.enabled) != 0;
    if (enabled && !was_enabled) {
        qatomic_set(&g_delivery.active, 0);
        g_delivery.total_windows = 0;
        g_delivery.slow_windows = 0;
        g_delivery.capture_count = 0;
        g_delivery.overwritten_captures = 0;
        g_delivery.capture_write_index = 0;
        g_delivery.stored_captures = 0;
        g_delivery.event_sequence = 0;
        qatomic_set(&g_delivery.last_sample_virtual_ns, 0);
        g_delivery.last_sample_interrupt_request = 0;
        g_delivery.last_sample_eflags = 0;
        g_delivery.last_sample_hflags = 0;
        g_delivery.last_sample_hflags2 = 0;
        g_delivery.last_sample_cflags_next_tb = -1;
        g_delivery.last_sample_pc = 0;
        g_delivery.overdue_emitted = 0;
        memset(&g_delivery.current, 0, sizeof(g_delivery.current));
        memset(g_delivery.captures, 0, sizeof(g_delivery.captures));
    } else if (!enabled) {
        qatomic_set(&g_delivery.active, 0);
        memset(&g_delivery.current, 0, sizeof(g_delivery.current));
    }
    qatomic_set(&g_delivery.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_trace_clear(void)
{
    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    qatomic_set(&g_delivery.active, 0);
    g_delivery.total_windows = 0;
    g_delivery.slow_windows = 0;
    g_delivery.capture_count = 0;
    g_delivery.overwritten_captures = 0;
    g_delivery.capture_write_index = 0;
    g_delivery.stored_captures = 0;
    g_delivery.event_sequence = 0;
    qatomic_set(&g_delivery.last_sample_virtual_ns, 0);
    g_delivery.last_sample_interrupt_request = 0;
    g_delivery.last_sample_eflags = 0;
    g_delivery.last_sample_hflags = 0;
    g_delivery.last_sample_hflags2 = 0;
    g_delivery.last_sample_cflags_next_tb = -1;
    g_delivery.last_sample_pc = 0;
    g_delivery.overdue_emitted = 0;
    memset(&g_delivery.current, 0, sizeof(g_delivery.current));
    memset(g_delivery.captures, 0, sizeof(g_delivery.captures));
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_set(
    uint32_t ptimer_pending, uint32_t ptimer_enabled,
    uint32_t pmc_pending, uint32_t pmc_enabled)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };

    if (!qatomic_read(&g_delivery.enabled) ||
        (ptimer_pending & ptimer_enabled) == 0 || pmc_enabled == 0) {
        return;
    }
    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!qatomic_read(&g_delivery.enabled) || g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }

    memset(&g_delivery.current, 0, sizeof(g_delivery.current));
    g_delivery.current.irq_set_virtual_ns = delivery_now_virtual();
    g_delivery.current.irq_set_host_ns = delivery_now_host();
    ++g_delivery.total_windows;
    qatomic_set(&g_delivery.last_sample_virtual_ns, 0);
    g_delivery.last_sample_interrupt_request = UINT32_MAX;
    g_delivery.last_sample_eflags = UINT32_MAX;
    g_delivery.last_sample_hflags = UINT32_MAX;
    g_delivery.last_sample_hflags2 = UINT32_MAX;
    g_delivery.last_sample_cflags_next_tb = INT_MIN;
    g_delivery.last_sample_pc = UINT32_MAX;
    g_delivery.overdue_emitted = 0;
    qatomic_set(&g_delivery.active, 1);

    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_SET;
    e.ptimer_pending = ptimer_pending;
    e.ptimer_enabled = ptimer_enabled;
    e.pmc_pending = pmc_pending;
    e.pmc_enabled = pmc_enabled;
    delivery_record_locked(&e, false);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_nv2a_line(
    int level, uint32_t ptimer_pending, uint32_t ptimer_enabled,
    uint32_t pmc_pending, uint32_t pmc_enabled)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };

    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active()) {
        return;
    }
    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_NV2A_LINE;
    e.level = level;
    e.ptimer_pending = ptimer_pending;
    e.ptimer_enabled = ptimer_enabled;
    e.pmc_pending = pmc_pending;
    e.pmc_enabled = pmc_enabled;
    if (level) {
        g_delivery.current.saw_nv2a_assert = 1;
    }
    delivery_record_locked(&e, false);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_pci_route(
    int pirq, int pic_irq, int level)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };

    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active()) {
        return;
    }
    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PCI_ROUTE;
    e.level = level;
    e.pirq = pirq;
    e.pic_irq = pic_irq;
    if (level) {
        g_delivery.current.saw_pci_route_assert = 1;
    }
    delivery_record_locked(&e, false);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_pic_cpu_line(
    CPUState *cpu, int level, uint32_t interrupt_request_before,
    uint32_t interrupt_request_after, int apic_path)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };

    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active()) {
        return;
    }
    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PIC_CPU_LINE;
    e.level = level;
    e.apic_path = apic_path ? 1 : 0;
    delivery_fill_cpu(&e, cpu);
    /* Preserve both sides of the line transition without adding more fields:
     * interrupt_request is the post-transition value; selected_interrupt keeps
     * the pre-transition mask for forensic comparison. */
    e.selected_interrupt = (int32_t)interrupt_request_before;
    e.interrupt_request = interrupt_request_after;
    if (level) {
        g_delivery.current.saw_pic_cpu_assert = 1;
    }
    delivery_record_locked(&e, false);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_tcg_check(CPUState *cpu)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };
    uint64_t now;
    uint64_t last_sample;

    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active() || cpu == NULL) {
        return;
    }

    /* Keep the hot TCG path almost lock-free. Normal IRQ service completes in
     * well under the 2 ms capture threshold; during an anomalous pending
     * window, one CPU-state sample every 50 us is sufficient to distinguish
     * IF masking, HF_INHIBIT_IRQ, missing CPU_INTERRUPT_HARD, or a deliverable
     * interrupt that TCG failed to take. Explicit PIC-line and HARD-take hooks
     * still record those transitions immediately. */
    now = delivery_now_virtual();
    last_sample = qatomic_read(&g_delivery.last_sample_virtual_ns);
    if (last_sample != 0 && now >= last_sample &&
        now - last_sample < XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_NS) {
        return;
    }

    delivery_fill_cpu(&e, cpu);

    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }

    last_sample = qatomic_read(&g_delivery.last_sample_virtual_ns);
    if (last_sample != 0 && now >= last_sample &&
        now - last_sample < XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_NS) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }

    ++g_delivery.current.total_tcg_checks;
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_SAMPLE;
    if (delivery_record_locked(&e, true)) {
        qatomic_set(&g_delivery.last_sample_virtual_ns, now);
        g_delivery.last_sample_interrupt_request = e.interrupt_request;
        g_delivery.last_sample_eflags = e.eflags;
        g_delivery.last_sample_hflags = e.hflags;
        g_delivery.last_sample_hflags2 = e.hflags2;
        g_delivery.last_sample_cflags_next_tb = e.cflags_next_tb;
        g_delivery.last_sample_pc = e.guest_pc;
        g_delivery.current.if_disabled_samples += e.if_enabled ? 0 : 1;
        g_delivery.current.if_enabled_samples += e.if_enabled ? 1 : 0;
        g_delivery.current.inhibit_samples += e.inhibit_irq ? 1 : 0;
        g_delivery.current.hard_present_samples += e.hard_present ? 1 : 0;
        g_delivery.current.hard_missing_samples += e.hard_present ? 0 : 1;
        g_delivery.current.hard_eligible_samples += e.hard_eligible ? 1 : 0;
        g_delivery.current.noirq_samples += e.noirq_cflags ? 1 : 0;
    }

    if (!g_delivery.overdue_emitted &&
        g_delivery.current.irq_set_virtual_ns != 0 &&
        now >= g_delivery.current.irq_set_virtual_ns +
                   XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_OVERDUE_NS) {
        XemuDebugToolsPtimerIrqDeliveryEvent overdue = e;
        overdue.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PENDING_OVERDUE;
        delivery_record_locked(&overdue, false);
        g_delivery.current.overdue_marked = 1;
        g_delivery.overdue_emitted = 1;
    }
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_tcg_take(
    CPUState *cpu, int selected_interrupt, int interrupt_vector)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };

    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active()) {
        return;
    }
    delivery_fill_cpu(&e, cpu);
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_HARD_TAKE;
    e.selected_interrupt = selected_interrupt;
    e.interrupt_vector = interrupt_vector;

    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (g_delivery.active) {
        ++g_delivery.current.hard_take_events;
        delivery_record_locked(&e, false);
    }
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_note_clear(
    uint32_t clear_value, uint32_t ptimer_pending,
    uint32_t ptimer_enabled, uint32_t pmc_pending, uint32_t pmc_enabled)
{
    XemuDebugToolsPtimerIrqDeliveryEvent e = { 0 };
    XemuDebugToolsPtimerIrqDeliveryCapture *dst;
    uint64_t now_virtual;
    uint64_t now_host;

    (void)clear_value;
    if (!xemu_debug_tools_ptimer_irq_delivery_trace_active()) {
        return;
    }

    now_virtual = delivery_now_virtual();
    now_host = delivery_now_host();
    delivery_fill_cpu(&e, current_cpu);
    e.type = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_CLEAR;
    e.ptimer_pending = ptimer_pending;
    e.ptimer_enabled = ptimer_enabled;
    e.pmc_pending = pmc_pending;
    e.pmc_enabled = pmc_enabled;

    delivery_init();
    qemu_mutex_lock(&g_delivery.lock);
    if (!g_delivery.active) {
        qemu_mutex_unlock(&g_delivery.lock);
        return;
    }

    delivery_record_locked(&e, false);
    g_delivery.current.irq_clear_virtual_ns = now_virtual;
    g_delivery.current.irq_clear_host_ns = now_host;
    if (now_virtual >= g_delivery.current.irq_set_virtual_ns) {
        g_delivery.current.service_virtual_ns =
            now_virtual - g_delivery.current.irq_set_virtual_ns;
    }
    if (now_host >= g_delivery.current.irq_set_host_ns) {
        g_delivery.current.service_host_ns =
            now_host - g_delivery.current.irq_set_host_ns;
    }
    g_delivery.current.classification = delivery_classify(&g_delivery.current);

    if (g_delivery.current.service_virtual_ns >=
        XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SLOW_NS) {
        ++g_delivery.slow_windows;
        ++g_delivery.capture_count;
        g_delivery.current.capture_sequence = g_delivery.capture_count;
        dst = &g_delivery.captures[g_delivery.capture_write_index];
        *dst = g_delivery.current;
        g_delivery.capture_write_index =
            (g_delivery.capture_write_index + 1) %
            XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT;
        if (g_delivery.stored_captures <
            XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT) {
            ++g_delivery.stored_captures;
        } else {
            ++g_delivery.overwritten_captures;
        }
    }

    qatomic_set(&g_delivery.active, 0);
    qemu_mutex_unlock(&g_delivery.lock);
}

void xemu_debug_tools_ptimer_irq_delivery_trace_get_status(
    XemuDebugToolsPtimerIrqDeliveryStatus *status)
{
    uint64_t now;
    size_t last_index;

    if (status == NULL) {
        return;
    }
    delivery_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_delivery.lock);
    status->enabled = qatomic_read(&g_delivery.enabled) ? 1 : 0;
    status->active = g_delivery.active;
    status->slow_threshold_ns = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SLOW_NS;
    status->overdue_threshold_ns = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_OVERDUE_NS;
    status->sample_interval_ns = XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_NS;
    status->total_windows = g_delivery.total_windows;
    status->slow_windows = g_delivery.slow_windows;
    status->capture_count = g_delivery.capture_count;
    status->overwritten_captures = g_delivery.overwritten_captures;
    status->stored_captures = g_delivery.stored_captures;
    status->active_set_virtual_ns = g_delivery.current.irq_set_virtual_ns;
    if (g_delivery.active && status->active_set_virtual_ns != 0) {
        now = delivery_now_virtual();
        if (now >= status->active_set_virtual_ns) {
            status->active_age_ns = now - status->active_set_virtual_ns;
        }
    }
    if (g_delivery.stored_captures != 0) {
        last_index = (g_delivery.capture_write_index +
                      XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT - 1) %
                     XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT;
        status->last_classification =
            g_delivery.captures[last_index].classification;
        status->last_service_virtual_ns =
            g_delivery.captures[last_index].service_virtual_ns;
    }
    /* Patch 305.2 intentionally disables Patch-305.1's dispatcher-page
     * single-instruction tracing while this recorder is enabled. */
    status->dispatcher_single_step_suppressed = status->enabled ? 1 : 0;
    qemu_mutex_unlock(&g_delivery.lock);
}

int xemu_debug_tools_ptimer_irq_delivery_trace_snapshot(
    XemuDebugToolsPtimerIrqDeliverySnapshot *snapshot)
{
    size_t i;
    size_t oldest;

    if (snapshot == NULL) {
        return 0;
    }
    delivery_init();
    memset(snapshot, 0, sizeof(*snapshot));
    xemu_debug_tools_ptimer_irq_delivery_trace_get_status(&snapshot->status);

    qemu_mutex_lock(&g_delivery.lock);
    if (g_delivery.stored_captures != 0) {
        oldest = g_delivery.stored_captures ==
                         XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT
                     ? g_delivery.capture_write_index
                     : 0;
        for (i = 0; i < g_delivery.stored_captures; ++i) {
            snapshot->captures[i] = g_delivery.captures[
                (oldest + i) % XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT];
        }
    }
    if (g_delivery.active) {
        snapshot->current = g_delivery.current;
    }
    qemu_mutex_unlock(&g_delivery.lock);
    return 1;
}
