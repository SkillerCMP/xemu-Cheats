/* Info: One-shot pinned forensic capture for materially late PTIMER callbacks. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "ptimer-late-capture.h"

typedef struct XemuDebugToolsPtimerLateCaptureState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    int latched;
    int capture_in_progress;
    uint64_t capture_count;
    XemuDebugToolsPtimerLateCaptureSnapshot snapshot;
} XemuDebugToolsPtimerLateCaptureState;

static XemuDebugToolsPtimerLateCaptureState g_ptimer_late_capture;

static void ptimer_late_capture_init(void)
{
    if (!g_ptimer_late_capture.initialized) {
        qemu_mutex_init(&g_ptimer_late_capture.lock);
        g_ptimer_late_capture.initialized = true;
    }
}

int xemu_debug_tools_ptimer_late_capture_active(void)
{
    return qatomic_read(&g_ptimer_late_capture.enabled) != 0;
}

void xemu_debug_tools_ptimer_late_capture_set_enabled(int enabled)
{
    ptimer_late_capture_init();
    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    qatomic_set(&g_ptimer_late_capture.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);

    if (enabled) {
        /* Arm the generic source recorders required for root-cause context.
         * The Def Jam-specific Guest Timer/Deadline tracer is intentionally
         * not forced on here; if the user enabled it independently, its tail
         * is included too. Do not turn generic dependencies off automatically
         * because they may have been enabled independently by the user. */
        xemu_debug_tools_qemu_timer_trace_set_enabled(1);
        xemu_debug_tools_bql_trace_set_enabled(1);
        xemu_debug_tools_main_loop_lock_trace_set_enabled(1);
        xemu_debug_tools_pgraph_lock_trace_set_enabled(1);
        xemu_debug_tools_scheduler_trace_set_enabled(1);
    }
}

void xemu_debug_tools_ptimer_late_capture_clear(void)
{
    ptimer_late_capture_init();
    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    g_ptimer_late_capture.latched = 0;
    g_ptimer_late_capture.capture_in_progress = 0;
    memset(&g_ptimer_late_capture.snapshot, 0,
           sizeof(g_ptimer_late_capture.snapshot));
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);
}

void xemu_debug_tools_ptimer_late_capture_note_dispatch(
    const XemuDebugToolsQemuTimerTraceEvent *event)
{
    XemuDebugToolsPtimerLateCaptureSnapshot *capture;
    uint64_t capture_start_host_ns;
    uint64_t capture_end_host_ns;

    if (event == NULL ||
        event->event_type != XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_BEGIN ||
        event->dispatch_late_ns < XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS ||
        !qatomic_read(&g_ptimer_late_capture.enabled)) {
        return;
    }

    ptimer_late_capture_init();
    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    if (!qatomic_read(&g_ptimer_late_capture.enabled) ||
        g_ptimer_late_capture.latched ||
        g_ptimer_late_capture.capture_in_progress) {
        qemu_mutex_unlock(&g_ptimer_late_capture.lock);
        return;
    }
    g_ptimer_late_capture.capture_in_progress = 1;
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);

    capture = g_new0(XemuDebugToolsPtimerLateCaptureSnapshot, 1);
    if (capture == NULL) {
        qemu_mutex_lock(&g_ptimer_late_capture.lock);
        g_ptimer_late_capture.capture_in_progress = 0;
        qemu_mutex_unlock(&g_ptimer_late_capture.lock);
        return;
    }

    capture_start_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    capture->status.enabled = 1;
    capture->status.latched = 1;
    capture->status.capture_in_progress = 0;
    capture->status.threshold_ns =
        XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS;
    capture->status.trigger_virtual_ns = event->qemu_virtual_ns;
    capture->status.trigger_host_ns = event->host_ns;
    capture->status.trigger_expire_ns = event->timer_expire_ns;
    capture->status.trigger_late_ns = event->dispatch_late_ns;
    capture->status.trigger_thread_id = event->thread_id;

    /* Snapshot only small tails from the existing recorders. The trigger is
     * already known before this work begins, and capture_duration_host_ns is
     * exported so any post-trigger observer perturbation remains measurable. */
    xemu_debug_tools_bql_trace_get_status(&capture->status.bql_status);
    xemu_debug_tools_main_loop_lock_trace_get_status(
        &capture->status.main_loop_lock_status);
    xemu_debug_tools_pgraph_lock_trace_get_status(&capture->status.pgraph_status);
    xemu_debug_tools_scheduler_trace_get_status(&capture->status.scheduler_status);
    xemu_debug_tools_guest_timer_deadline_trace_get_status(
        &capture->status.guest_timer_status);

    capture->status.qtimer_count = xemu_debug_tools_qemu_timer_trace_snapshot(
        capture->qtimer, XEMU_DEBUG_TOOLS_PTIMER_LATE_QTIMER_EVENTS);
    capture->status.bql_count = xemu_debug_tools_bql_trace_snapshot(
        capture->bql, XEMU_DEBUG_TOOLS_PTIMER_LATE_BQL_EVENTS);
    capture->status.main_loop_lock_count =
        xemu_debug_tools_main_loop_lock_trace_snapshot(
            capture->main_loop_lock,
            XEMU_DEBUG_TOOLS_PTIMER_LATE_MAIN_LOOP_LOCK_EVENTS);
    capture->status.pgraph_count = xemu_debug_tools_pgraph_lock_trace_snapshot(
        capture->pgraph, XEMU_DEBUG_TOOLS_PTIMER_LATE_PGRAPH_EVENTS);
    capture->status.scheduler_count = xemu_debug_tools_scheduler_trace_snapshot(
        capture->scheduler, XEMU_DEBUG_TOOLS_PTIMER_LATE_SCHEDULER_EVENTS);
    capture->status.guest_timer_count =
        xemu_debug_tools_guest_timer_deadline_trace_snapshot(
            capture->guest_timer,
            XEMU_DEBUG_TOOLS_PTIMER_LATE_GUEST_TIMER_EVENTS);

    capture_end_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    capture->status.capture_duration_host_ns =
        capture_end_host_ns - capture_start_host_ns;

    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    if (qatomic_read(&g_ptimer_late_capture.enabled)) {
        ++g_ptimer_late_capture.capture_count;
        capture->status.capture_count = g_ptimer_late_capture.capture_count;
        g_ptimer_late_capture.snapshot = *capture;
        g_ptimer_late_capture.latched = 1;
    }
    g_ptimer_late_capture.capture_in_progress = 0;
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);
    g_free(capture);
}

void xemu_debug_tools_ptimer_late_capture_get_status(
    XemuDebugToolsPtimerLateCaptureStatus *status)
{
    if (status == NULL) {
        return;
    }
    ptimer_late_capture_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    if (g_ptimer_late_capture.latched) {
        *status = g_ptimer_late_capture.snapshot.status;
    }
    status->enabled = qatomic_read(&g_ptimer_late_capture.enabled) ? 1 : 0;
    status->latched = g_ptimer_late_capture.latched;
    status->capture_in_progress = g_ptimer_late_capture.capture_in_progress;
    status->capture_count = g_ptimer_late_capture.capture_count;
    status->threshold_ns = XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS;
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);
}

int xemu_debug_tools_ptimer_late_capture_snapshot(
    XemuDebugToolsPtimerLateCaptureSnapshot *snapshot)
{
    if (snapshot == NULL) {
        return 0;
    }
    ptimer_late_capture_init();
    memset(snapshot, 0, sizeof(*snapshot));
    qemu_mutex_lock(&g_ptimer_late_capture.lock);
    if (!g_ptimer_late_capture.latched) {
        qemu_mutex_unlock(&g_ptimer_late_capture.lock);
        return 0;
    }
    *snapshot = g_ptimer_late_capture.snapshot;
    qemu_mutex_unlock(&g_ptimer_late_capture.lock);
    return 1;
}
