/* Info: PGRAPH core emits lock observations; Diagnostics owns storage and analysis. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void xemu_debug_tools_pgraph_lock_trace_lock_attempt(const void *pgraph_state,
                                                      const char *file,
                                                      int line);
void xemu_debug_tools_pgraph_lock_trace_lock_acquired(const void *pgraph_state,
                                                       const char *file,
                                                       int line);
void xemu_debug_tools_pgraph_lock_trace_unlock_begin(const void *pgraph_state,
                                                      const char *file,
                                                      int line);
void xemu_debug_tools_pgraph_lock_trace_unlock_end(const void *pgraph_state);
void xemu_debug_tools_pgraph_lock_trace_method_enter(unsigned int subchannel,
                                                      unsigned int graphics_class,
                                                      unsigned int method,
                                                      uint32_t parameter);
void xemu_debug_tools_pgraph_lock_trace_method_exit(void);

#ifdef __cplusplus
}
#endif
