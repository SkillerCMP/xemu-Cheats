/* Info: Observation-only PTIMER/main-loop deadline trace. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "qemu-timer-trace.h"
#include "diagnostics-trace-buffer.h"
#include "ptimer-late-capture.h"

#define QTIMER_MAINLOOP_WINDOW_NS (100 * 1000 * 1000LL)

typedef struct XemuDebugToolsQemuTimerTraceState {
    QemuMutex lock;
    bool lock_initialized;
    int enabled;
    void *watched_timer;
    int64_t watched_timer_expire_ns;
    uint64_t wait_enter_host_ns;
    uint64_t wait_enter_virtual_ns;
    int64_t wait_enter_timeout_ns;
    bool wait_enter_relevant;
    bool run_timers_relevant;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;
    XemuDebugToolsQemuTimerTraceEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsQemuTimerTraceState;

static XemuDebugToolsQemuTimerTraceState qtimer_trace;

static void qtimer_trace_append_locked(XemuDebugToolsQemuTimerTraceEvent *event)
{
    const size_t trace_capacity = xemu_debug_tools_qemu_timer_trace_get_buffer_capacity();
    size_t slot = qtimer_trace.write_index;
    event->sequence = qtimer_trace.total_events++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(qtimer_trace.events,
                                     XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, slot) = *event;
    qtimer_trace.write_index = (slot + 1) % trace_capacity;
    if (qtimer_trace.count < trace_capacity) {
        ++qtimer_trace.count;
    } else {
        ++qtimer_trace.overwritten_events;
    }
}

static bool qtimer_trace_mainloop_relevant_locked(uint64_t virtual_ns)
{
    int64_t delta;
    if (qtimer_trace.watched_timer == NULL ||
        qtimer_trace.watched_timer_expire_ns < 0) {
        return false;
    }
    delta = qtimer_trace.watched_timer_expire_ns - (int64_t)virtual_ns;
    return delta >= -QTIMER_MAINLOOP_WINDOW_NS &&
           delta <= QTIMER_MAINLOOP_WINDOW_NS;
}

static void qtimer_timer_observer(
    void *timer,
    XemuDebugToolsQemuTimerHookEvent event_type,
    int clock_type,
    int64_t expire_ns,
    int64_t value)
{
    XemuDebugToolsQemuTimerTraceEvent event = { 0 };
    uint64_t virtual_ns;
    bool trigger_late_capture = false;

    if (!qtimer_trace.lock_initialized ||
        !qatomic_read(&qtimer_trace.enabled)) {
        return;
    }

    qemu_mutex_lock(&qtimer_trace.lock);
    if (!qatomic_read(&qtimer_trace.enabled)) {
        qemu_mutex_unlock(&qtimer_trace.lock);
        return;
    }

    virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

    if (event_type == XEMU_DEBUG_TOOLS_QTIMER_CLOCK_NOTIFY) {
        if (clock_type != QEMU_CLOCK_VIRTUAL ||
            !qtimer_trace_mainloop_relevant_locked(virtual_ns)) {
            qemu_mutex_unlock(&qtimer_trace.lock);
            return;
        }
    } else if (timer != qtimer_trace.watched_timer) {
        qemu_mutex_unlock(&qtimer_trace.lock);
        return;
    }

    if (event_type == XEMU_DEBUG_TOOLS_QTIMER_TIMER_MOD) {
        qtimer_trace.watched_timer_expire_ns = expire_ns;
    } else if (event_type == XEMU_DEBUG_TOOLS_QTIMER_TIMER_DEL) {
        qtimer_trace.watched_timer_expire_ns = -1;
        qtimer_trace.buffer_multiplier = 1;
    }

    event.qemu_virtual_ns = virtual_ns;
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.event_type = event_type;
    event.clock_type = clock_type;
    event.thread_id = qemu_get_thread_id();
    event.timer_expire_ns = expire_ns >= 0
                                ? expire_ns
                                : qtimer_trace.watched_timer_expire_ns;
    event.watched_timer_pending =
        qtimer_trace.watched_timer_expire_ns >= 0 ? 1 : 0;
    if (event.timer_expire_ns >= 0) {
        event.timer_delta_ns = event.timer_expire_ns - (int64_t)virtual_ns;
    }
    if (event_type == XEMU_DEBUG_TOOLS_QTIMER_DISPATCH_BEGIN &&
        expire_ns >= 0) {
        event.dispatch_late_ns = (int64_t)virtual_ns - expire_ns;
        trigger_late_capture =
            event.dispatch_late_ns >=
                XEMU_DEBUG_TOOLS_PTIMER_LATE_CAPTURE_THRESHOLD_NS &&
            xemu_debug_tools_ptimer_late_capture_active();
    }
    event.value = value;
    qtimer_trace_append_locked(&event);
    qemu_mutex_unlock(&qtimer_trace.lock);

    /* Trigger only after dropping the QEMU-timer trace lock. The pinned
     * capture snapshots this ring plus other diagnostic recorders and must not
     * recursively acquire qtimer_trace.lock. */
    if (trigger_late_capture) {
        xemu_debug_tools_ptimer_late_capture_note_dispatch(&event);
    }
}

static void qtimer_main_loop_observer(
    XemuDebugToolsQemuTimerHookEvent event_type,
    int64_t timeout_ns,
    int64_t value)
{
    XemuDebugToolsQemuTimerTraceEvent event = { 0 };
    uint64_t virtual_ns;
    uint64_t host_ns;

    if (!qtimer_trace.lock_initialized ||
        !qatomic_read(&qtimer_trace.enabled)) {
        return;
    }

    qemu_mutex_lock(&qtimer_trace.lock);
    if (!qatomic_read(&qtimer_trace.enabled)) {
        qemu_mutex_unlock(&qtimer_trace.lock);
        return;
    }

    virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);

    const bool current_relevant =
        qtimer_trace_mainloop_relevant_locked(virtual_ns);

    if (event_type == XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_ENTER) {
        qtimer_trace.wait_enter_host_ns = host_ns;
        qtimer_trace.wait_enter_virtual_ns = virtual_ns;
        qtimer_trace.wait_enter_timeout_ns = timeout_ns;
        /* A zero-time poll cannot explain a frame-sized oversleep. Keep finite
         * blocking waits and suspicious infinite waits while PTIMER is close. */
        qtimer_trace.wait_enter_relevant = current_relevant && timeout_ns != 0;
        if (!qtimer_trace.wait_enter_relevant) {
            qemu_mutex_unlock(&qtimer_trace.lock);
            return;
        }
    } else if (event_type == XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_EXIT) {
        if (!qtimer_trace.wait_enter_relevant && !current_relevant) {
            qemu_mutex_unlock(&qtimer_trace.lock);
            return;
        }
    } else if (event_type == XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_ENTER) {
        qtimer_trace.run_timers_relevant = current_relevant;
        if (!qtimer_trace.run_timers_relevant) {
            qemu_mutex_unlock(&qtimer_trace.lock);
            return;
        }
    } else if (event_type == XEMU_DEBUG_TOOLS_QTIMER_RUN_TIMERS_EXIT) {
        if (!qtimer_trace.run_timers_relevant && !current_relevant) {
            qemu_mutex_unlock(&qtimer_trace.lock);
            return;
        }
        qtimer_trace.run_timers_relevant = false;
    } else if (!current_relevant) {
        qemu_mutex_unlock(&qtimer_trace.lock);
        return;
    }

    event.qemu_virtual_ns = virtual_ns;
    event.host_ns = host_ns;
    event.event_type = event_type;
    event.thread_id = qemu_get_thread_id();
    event.timeout_ns = timeout_ns;
    event.value = value;
    event.timer_expire_ns = qtimer_trace.watched_timer_expire_ns;
    event.watched_timer_pending =
        qtimer_trace.watched_timer_expire_ns >= 0 ? 1 : 0;
    if (event.timer_expire_ns >= 0) {
        event.timer_delta_ns = event.timer_expire_ns - (int64_t)virtual_ns;
    }

    if (event_type == XEMU_DEBUG_TOOLS_QTIMER_MAIN_WAIT_EXIT &&
        qtimer_trace.wait_enter_host_ns != 0) {
        event.wait_elapsed_host_ns =
            (int64_t)(host_ns - qtimer_trace.wait_enter_host_ns);
        event.wait_elapsed_virtual_ns =
            (int64_t)(virtual_ns - qtimer_trace.wait_enter_virtual_ns);
    }

    qtimer_trace_append_locked(&event);
    qemu_mutex_unlock(&qtimer_trace.lock);
}

void xemu_debug_tools_qemu_timer_trace_init(void)
{
    if (!qtimer_trace.lock_initialized) {
        qemu_mutex_init(&qtimer_trace.lock);
        qtimer_trace.lock_initialized = true;
        qtimer_trace.watched_timer_expire_ns = -1;
        xemu_debug_tools_qemu_timer_hook_install(
            qtimer_timer_observer, qtimer_main_loop_observer);
    }
}

void xemu_debug_tools_qemu_timer_trace_watch(void *timer)
{
    xemu_debug_tools_qemu_timer_trace_init();
    qemu_mutex_lock(&qtimer_trace.lock);
    qtimer_trace.watched_timer = timer;
    qtimer_trace.watched_timer_expire_ns = -1;
    qemu_mutex_unlock(&qtimer_trace.lock);
}

void xemu_debug_tools_qemu_timer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_qemu_timer_trace_init();
    qemu_mutex_lock(&qtimer_trace.lock);
    if (enabled) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(qtimer_trace.events,
                                             XemuDebugToolsQemuTimerTraceEvent,
                                             XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY,
                                             qtimer_trace.buffer_multiplier, ok);
        if (!ok) { qemu_mutex_unlock(&qtimer_trace.lock); return; }
    }
    if (enabled && !qatomic_read(&qtimer_trace.enabled)) {
        qtimer_trace.count = 0;
        qtimer_trace.write_index = 0;
        qtimer_trace.total_events = 0;
        qtimer_trace.overwritten_events = 0;
        qtimer_trace.wait_enter_host_ns = 0;
        qtimer_trace.wait_enter_virtual_ns = 0;
        qtimer_trace.wait_enter_timeout_ns = 0;
        qtimer_trace.wait_enter_relevant = false;
        qtimer_trace.run_timers_relevant = false;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(qtimer_trace.events, XemuDebugToolsQemuTimerTraceEvent, XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, qtimer_trace.buffer_multiplier);
    }
    qatomic_set(&qtimer_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&qtimer_trace.lock);
}

int xemu_debug_tools_qemu_timer_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok;
    xemu_debug_tools_qemu_timer_trace_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&qtimer_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(qtimer_trace.events, XemuDebugToolsQemuTimerTraceEvent, XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, multiplier, ok);
    if (ok) {
        qtimer_trace.buffer_multiplier = multiplier;
        qtimer_trace.count = qtimer_trace.write_index = 0;
        qtimer_trace.total_events = qtimer_trace.overwritten_events = 0;
        qtimer_trace.wait_enter_host_ns = qtimer_trace.wait_enter_virtual_ns = 0;
        qtimer_trace.wait_enter_timeout_ns = 0; qtimer_trace.wait_enter_relevant = false; qtimer_trace.run_timers_relevant = false;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(qtimer_trace.events, XemuDebugToolsQemuTimerTraceEvent, XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, multiplier);
    }
    qemu_mutex_unlock(&qtimer_trace.lock);
    return ok ? 1 : 0;
}
uint32_t xemu_debug_tools_qemu_timer_trace_get_buffer_multiplier(void) { return qtimer_trace.buffer_multiplier ? qtimer_trace.buffer_multiplier : 1; }
size_t xemu_debug_tools_qemu_timer_trace_get_buffer_capacity(void) { return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, xemu_debug_tools_qemu_timer_trace_get_buffer_multiplier()); }

void xemu_debug_tools_qemu_timer_trace_clear(void)
{
    xemu_debug_tools_qemu_timer_trace_init();
    qemu_mutex_lock(&qtimer_trace.lock);
    qtimer_trace.count = 0;
    qtimer_trace.write_index = 0;
    qtimer_trace.total_events = 0;
    qtimer_trace.overwritten_events = 0;
    qtimer_trace.wait_enter_host_ns = 0;
    qtimer_trace.wait_enter_virtual_ns = 0;
    qtimer_trace.wait_enter_timeout_ns = 0;
    qtimer_trace.wait_enter_relevant = false;
    qtimer_trace.run_timers_relevant = false;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(qtimer_trace.events, XemuDebugToolsQemuTimerTraceEvent, XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, qtimer_trace.buffer_multiplier);
    qemu_mutex_unlock(&qtimer_trace.lock);
}

void xemu_debug_tools_qemu_timer_trace_get_status(
    XemuDebugToolsQemuTimerTraceStatus *status)
{
    if (!status) {
        return;
    }
    memset(status, 0, sizeof(*status));
    status->watched_timer_expire_ns = -1;
    if (!qtimer_trace.lock_initialized) {
        return;
    }
    qemu_mutex_lock(&qtimer_trace.lock);
    status->enabled = qatomic_read(&qtimer_trace.enabled) ? 1 : 0;
    status->count = qtimer_trace.count;
    status->total_events = qtimer_trace.total_events;
    status->overwritten_events = qtimer_trace.overwritten_events;
    status->watched_timer_expire_ns = qtimer_trace.watched_timer_expire_ns;
    qemu_mutex_unlock(&qtimer_trace.lock);
}

size_t xemu_debug_tools_qemu_timer_trace_snapshot(
    XemuDebugToolsQemuTimerTraceEvent *events,
    size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (!events || capacity == 0 || !qtimer_trace.lock_initialized) {
        return 0;
    }
    qemu_mutex_lock(&qtimer_trace.lock);
    to_copy = MIN(capacity, qtimer_trace.count);
    const size_t trace_capacity = xemu_debug_tools_qemu_timer_trace_get_buffer_capacity();
    oldest = qtimer_trace.count == trace_capacity ? qtimer_trace.write_index : 0;
    if (to_copy < qtimer_trace.count) {
        oldest = (oldest + qtimer_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(qtimer_trace.events, XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY, (oldest + i) % trace_capacity);
    }
    qemu_mutex_unlock(&qtimer_trace.lock);
    return to_copy;
}
