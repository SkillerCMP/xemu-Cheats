/*
 * xemu Debug Tools - device diagnostics snapshot bridge
 */
#include "qemu/osdep.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "cpu.h"
#include "system/cpus.h"
#include "system/runstate.h"
#ifdef CONFIG_WHPX
#include "system/whpx.h"
#include "../../../../../target/i386/whpx/whpx-internal.h"
#endif
#include "hw/xbox/nv2a/nv2a_int.h"
#include "ptimer-trace.h"
#include "qemu-timer-trace.h"
#include "slow-timer-trace.h"
#include "ohci-slow-frame-trace-hook.h"
#include "controller-input-poll-trace-hook.h"
#include "pgraph-ptimer-latency-trace-hook.h"
#include "bql-trace.h"
#include "main-loop-lock-trace.h"
#include "mmio-trace.h"
#include "pgraph-lock-trace.h"
#include "pgraph-flip-delay-trace.h"
#include "pgraph-pusher-progress-trace.h"
#include "pgraph-draw-trace.h"
#include "flip-stall-trace.h"
#include "scheduler-trace.h"
#include "controller-xid-trace.h"
#include "guest-input-consumer-trace.h"
#include "guest-timer-deadline-trace.h"
#include "d3d-callback-capture.h"
#include "d3d-timer-state-trace.h"
#include "ptimer-irq-delivery-trace.h"
#include "hw/xbox/mcpx/apu/apu_int.h"
#include "hw/xbox/mcpx/apu/apu_debug.h"

#include "diagnostics-backend.h"
#include "diagnostics-ptimer-utils.h"

int xemu_diagnostics_buffer_set_multiplier(XemuDiagnosticsBufferId id, uint32_t multiplier)
{
    switch (id) {
    case XEMU_DIAG_BUFFER_PTIMER: return xemu_debug_tools_ptimer_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_QEMU_TIMER: return xemu_debug_tools_qemu_timer_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_SLOW_TIMER: return xemu_debug_tools_slow_timer_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME: return xemu_debug_tools_ohci_slow_frame_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL: return xemu_debug_tools_controller_input_poll_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PGRAPH_INCREMENT: return xemu_debug_tools_pgraph_increment_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY: return xemu_debug_tools_ptimer_irq_latency_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_BQL: return xemu_debug_tools_bql_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_MMIO: return xemu_debug_tools_mmio_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PGRAPH_LOCK: return xemu_debug_tools_pgraph_lock_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PGRAPH_DRAW: return xemu_debug_tools_pgraph_draw_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_FLIP_STALL: return xemu_debug_tools_flip_stall_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY: return xemu_debug_tools_pgraph_flip_delay_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS: return xemu_debug_tools_pgraph_pusher_progress_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_AV_SYNC: return xemu_debug_tools_av_sync_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_SCHEDULER: return xemu_debug_tools_scheduler_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_CONTROLLER_XID: return xemu_debug_tools_controller_xid_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER: return xemu_debug_tools_guest_input_consumer_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE: return xemu_debug_tools_guest_timer_deadline_trace_set_buffer_multiplier(multiplier);
    case XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK: return xemu_debug_tools_main_loop_lock_trace_set_buffer_multiplier(multiplier);
    default: return 0;
    }
}

int xemu_diagnostics_buffer_get_info(XemuDiagnosticsBufferId id, XemuDiagnosticsBufferInfo *info)
{
    if (info == NULL) return 0;
    memset(info, 0, sizeof(*info));
    switch (id) {
    case XEMU_DIAG_BUFFER_PTIMER: info->base_capacity=XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_ptimer_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_ptimer_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_QEMU_TIMER: info->base_capacity=XEMU_DEBUG_TOOLS_QTIMER_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_qemu_timer_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_qemu_timer_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_SLOW_TIMER: info->base_capacity=XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_slow_timer_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_slow_timer_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_OHCI_SLOW_FRAME: info->base_capacity=XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY; info->multiplier=xemu_debug_tools_ohci_slow_frame_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_ohci_slow_frame_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_CONTROLLER_INPUT_POLL: info->base_capacity=XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY; info->multiplier=xemu_debug_tools_controller_input_poll_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_controller_input_poll_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PGRAPH_INCREMENT: info->base_capacity=XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY; info->multiplier=xemu_debug_tools_pgraph_increment_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_pgraph_increment_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PTIMER_IRQ_LATENCY: info->base_capacity=XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY; info->multiplier=xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_BQL: info->base_capacity=XEMU_DEBUG_TOOLS_BQL_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_bql_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_bql_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_MMIO: info->base_capacity=XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_mmio_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_mmio_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PGRAPH_LOCK: info->base_capacity=XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PGRAPH_DRAW: info->base_capacity=XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_FLIP_STALL: info->base_capacity=XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_flip_stall_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_flip_stall_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PGRAPH_FLIP_DELAY: info->base_capacity=XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY; info->multiplier=xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_PGRAPH_PUSHER_PROGRESS: info->base_capacity=XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY; info->multiplier=xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_AV_SYNC: info->base_capacity=XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_av_sync_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_av_sync_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_SCHEDULER: info->base_capacity=XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_scheduler_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_scheduler_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_CONTROLLER_XID: info->base_capacity=XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_controller_xid_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_controller_xid_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_GUEST_INPUT_CONSUMER: info->base_capacity=XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_guest_input_consumer_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_guest_input_consumer_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_GUEST_TIMER_DEADLINE: info->base_capacity=XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_guest_timer_deadline_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_guest_timer_deadline_trace_get_buffer_capacity(); break;
    case XEMU_DIAG_BUFFER_MAIN_LOOP_LOCK: info->base_capacity=XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_CAPACITY; info->multiplier=xemu_debug_tools_main_loop_lock_trace_get_buffer_multiplier(); info->capacity=xemu_debug_tools_main_loop_lock_trace_get_buffer_capacity(); break;
    default: return 0;
    }
    return 1;
}

#ifdef CONFIG_WHPX
typedef struct XemuDiagnosticsWhpxTscResult {
    int ok;
    uint64_t actual_tsc;
} XemuDiagnosticsWhpxTscResult;

static void diagnostics_whpx_read_tsc(CPUState *cpu, run_on_cpu_data data)
{
    XemuDiagnosticsWhpxTscResult *result = data.host_ptr;
    WHV_REGISTER_NAME name = WHvX64RegisterTsc;
    WHV_REGISTER_VALUE value;
    HRESULT hr;

    hr = whp_dispatch.WHvGetVirtualProcessorRegisters(
        whpx_global.partition, cpu->cpu_index, &name, 1, &value);
    if (FAILED(hr)) {
        return;
    }

    result->actual_tsc = value.Reg64;
    result->ok = 1;
}

static void diagnostics_collect_whpx_timing(
    CPUState *cpu, XemuDiagnosticsTimingSnapshot *snapshot)
{
    XemuDiagnosticsWhpxTscResult result = { 0 };
    UINT64 freq = 0;
    HRESULT hr;

    snapshot->whpx_active = 1;

    hr = whp_dispatch.WHvGetCapability(
        WHvCapabilityCodeProcessorClockFrequency, &freq, sizeof(freq), NULL);
    if (SUCCEEDED(hr)) {
        snapshot->whpx_processor_clock_hz = freq;
        snapshot->whpx_processor_clock_valid = 1;
    }

    freq = 0;
    hr = whp_dispatch.WHvGetCapability(
        WHvCapabilityCodeInterruptClockFrequency, &freq, sizeof(freq), NULL);
    if (SUCCEEDED(hr)) {
        snapshot->whpx_interrupt_clock_hz = freq;
        snapshot->whpx_interrupt_clock_valid = 1;
    }

    /* WHPX vCPU register access must happen in vCPU context; doing it here
     * avoids racing WHvRunVirtualProcessor from the UI thread. */
    run_on_cpu(cpu, diagnostics_whpx_read_tsc,
               RUN_ON_CPU_HOST_PTR(&result));
    if (result.ok) {
        snapshot->actual_tsc = result.actual_tsc;
        snapshot->actual_tsc_valid = 1;
    }
}
#endif

int xemu_diagnostics_get_timing_snapshot(
    XemuDiagnosticsTimingSnapshot *snapshot)
{
    CPUState *cpu;
    CPUX86State *env;

    if (snapshot == NULL) {
        return 0;
    }

    memset(snapshot, 0, sizeof(*snapshot));
    cpu = qemu_get_cpu(0);
    if (cpu == NULL) {
        return 0;
    }

    env = &X86_CPU(cpu)->env;
    snapshot->available = 1;
    snapshot->running = runstate_is_running() ? 1 : 0;
    snapshot->halted = cpu->halted ? 1 : 0;
    snapshot->exception_index = cpu->exception_index;
    snapshot->interrupt_request = cpu->interrupt_request;
    snapshot->qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

    /* Xbox builds use the fixed console timebase for cpu_get_tsc(). This is
     * the reference clock used to measure accelerator-visible drift. */
    snapshot->expected_xbox_tsc = cpu_get_tsc(env);
    snapshot->model_tsc_hz = env->tsc_khz > 0 ?
        (uint64_t)env->tsc_khz * 1000ULL : 0;
    snapshot->apic_bus_hz = env->apic_bus_freq > 0 ?
        (uint64_t)env->apic_bus_freq : 0;

#ifdef CONFIG_WHPX
    if (whpx_enabled()) {
        diagnostics_collect_whpx_timing(cpu, snapshot);
    } else
#endif
    {
        snapshot->actual_tsc = snapshot->expected_xbox_tsc;
        snapshot->actual_tsc_valid = 1;
    }

    return 1;
}


int xemu_diagnostics_get_device_snapshot(
    XemuDiagnosticsDeviceSnapshot *snapshot)
{
    NV2AState *d = g_nv2a;
    const struct McpxApuDebug *apu = NULL;
    uint64_t now_ns;

    if (snapshot == NULL) {
        return 0;
    }
    memset(snapshot, 0, sizeof(*snapshot));

    now_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    snapshot->qemu_virtual_ns = now_ns;

    if (d != NULL) {
        unsigned int last_frame;
        uint64_t alarm;

        snapshot->nv2a_available = 1;
        snapshot->pmc_pending = d->pmc.pending_interrupts;
        snapshot->pmc_enabled = d->pmc.enabled_interrupts;
        snapshot->pfifo_pending = d->pfifo.pending_interrupts;
        snapshot->pfifo_enabled = d->pfifo.enabled_interrupts;
        snapshot->pgraph_pending = qatomic_read(&d->pgraph.pending_interrupts);
        snapshot->pgraph_enabled = qatomic_read(&d->pgraph.enabled_interrupts);
        snapshot->pcrtc_pending = d->pcrtc.pending_interrupts;
        snapshot->pcrtc_enabled = d->pcrtc.enabled_interrupts;
        snapshot->ptimer_pending = d->ptimer.pending_interrupts;
        snapshot->ptimer_enabled = d->ptimer.enabled_interrupts;

        snapshot->pfifo_fifo_kick = d->pfifo.fifo_kick ? 1 : 0;
        snapshot->pfifo_halt = d->pfifo.halt ? 1 : 0;
        snapshot->pgraph_waiting_for_nop = d->pgraph.waiting_for_nop ? 1 : 0;
        snapshot->pgraph_waiting_for_flip = d->pgraph.waiting_for_flip ? 1 : 0;
        snapshot->pgraph_waiting_for_context_switch =
            d->pgraph.waiting_for_context_switch ? 1 : 0;
        snapshot->pgraph_flush_pending = d->pgraph.flush_pending ? 1 : 0;
        snapshot->pgraph_sync_pending = d->pgraph.sync_pending ? 1 : 0;

        snapshot->ptimer_numerator = d->ptimer.numerator;
        snapshot->ptimer_denominator = d->ptimer.denominator;
        snapshot->ptimer_now = xemu_debug_tools_ptimer_clock(d, now_ns);
        alarm = d->ptimer.alarm_time;
        snapshot->ptimer_alarm = alarm;
        snapshot->ptimer_alarm_delta_ns =
            xemu_debug_tools_ptimer_signed_alarm_delta_ns(
                d, snapshot->ptimer_now, alarm);
        snapshot->ptimer_qemu_timer_pending =
            timer_pending(&d->ptimer.timer) ? 1 : 0;
        if (snapshot->ptimer_qemu_timer_pending) {
            snapshot->ptimer_qemu_timer_expire_ns =
                timer_expire_time_ns(&d->ptimer.timer);
            snapshot->ptimer_qemu_timer_delta_ns =
                (int64_t)snapshot->ptimer_qemu_timer_expire_ns -
                (int64_t)now_ns;
        }

        snapshot->gpu_core_clock_hz = d->pramdac.core_clock_freq;
        snapshot->gpu_fps = g_nv2a_stats.increment_fps;
        snapshot->gpu_frame_count = g_nv2a_stats.frame_count;
        last_frame = (g_nv2a_stats.frame_ptr + NV2A_PROF_NUM_FRAMES - 1) %
                     NV2A_PROF_NUM_FRAMES;
        snapshot->gpu_last_frame_mspf =
            g_nv2a_stats.frame_history[last_frame].mspf;
    }

    if (g_state != NULL) {
        int i;
        int active_voices = 0;

        apu = mcpx_apu_get_debug_info();
        snapshot->apu_available = apu != NULL ? 1 : 0;
        if (apu != NULL) {
            snapshot->apu_frames_processed = apu->frames_processed;
            snapshot->apu_utilization = apu->utilization;
            for (i = 0; i < 256; i++) {
                if (apu->vp.v[i].active) {
                    active_voices++;
                }
            }
            snapshot->apu_active_voices = active_voices;
            snapshot->apu_worker_time_us = apu->vp.total_worker_time_us;
            snapshot->apu_gp_cycles = apu->gp.cycles;
            snapshot->apu_ep_cycles = apu->ep.cycles;
            snapshot->apu_deviation_min_us = apu->throttle.deviation.min_us;
            snapshot->apu_deviation_avg_us = apu->throttle.deviation.avg_us;
            snapshot->apu_deviation_max_us = apu->throttle.deviation.max_us;
            snapshot->apu_latency_min_ms = apu->throttle.latency.min_ms;
            snapshot->apu_latency_avg_ms = apu->throttle.latency.avg_ms;
            snapshot->apu_latency_max_ms = apu->throttle.latency.max_ms;
            snapshot->apu_latency_low_ms = apu->throttle.latency.low_ms;
            snapshot->apu_latency_high_ms = apu->throttle.latency.high_ms;
            snapshot->apu_gp_realtime = apu->gp_realtime ? 1 : 0;
            snapshot->apu_ep_realtime = apu->ep_realtime ? 1 : 0;
        }
    }

    return snapshot->nv2a_available || snapshot->apu_available;
}

void xemu_diagnostics_ptimer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_ptimer_trace_set_enabled(enabled);
}

void xemu_diagnostics_ptimer_trace_clear(void)
{
    xemu_debug_tools_ptimer_trace_clear();
}

int xemu_diagnostics_get_ptimer_trace_status(
    XemuDiagnosticsPtimerTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_ptimer_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_ptimer_trace(
    XemuDiagnosticsPtimerTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_ptimer_trace_snapshot(events, capacity);
}


void xemu_diagnostics_qemu_timer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_qemu_timer_trace_set_enabled(enabled);
}

void xemu_diagnostics_qemu_timer_trace_clear(void)
{
    xemu_debug_tools_qemu_timer_trace_clear();
}

int xemu_diagnostics_get_qemu_timer_trace_status(
    XemuDiagnosticsQemuTimerTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_qemu_timer_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_qemu_timer_trace(
    XemuDiagnosticsQemuTimerTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_qemu_timer_trace_snapshot(events, capacity);
}

void xemu_diagnostics_slow_timer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_slow_timer_trace_set_enabled(enabled);
}

void xemu_diagnostics_slow_timer_trace_set_threshold_ns(uint64_t threshold_ns)
{
    xemu_debug_tools_slow_timer_trace_set_threshold_ns(threshold_ns);
}

void xemu_diagnostics_slow_timer_trace_clear(void)
{
    xemu_debug_tools_slow_timer_trace_clear();
}

int xemu_diagnostics_get_slow_timer_trace_status(
    XemuDiagnosticsSlowTimerTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_slow_timer_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_slow_timer_trace(
    XemuDiagnosticsSlowTimerTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_slow_timer_trace_snapshot(events, capacity);
}


void xemu_diagnostics_ohci_slow_frame_trace_set_enabled(int enabled)
{
    xemu_debug_tools_ohci_slow_frame_trace_set_enabled(enabled);
}

void xemu_diagnostics_ohci_slow_frame_trace_set_threshold_ns(uint64_t threshold_ns)
{
    xemu_debug_tools_ohci_slow_frame_trace_set_threshold_ns(threshold_ns);
}

void xemu_diagnostics_ohci_slow_frame_trace_clear(void)
{
    xemu_debug_tools_ohci_slow_frame_trace_clear();
}

int xemu_diagnostics_get_ohci_slow_frame_trace_status(
    XemuDiagnosticsOhciSlowFrameStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_ohci_slow_frame_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_ohci_slow_frame_trace(
    XemuDiagnosticsOhciSlowFrameEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_ohci_slow_frame_trace_snapshot(events, capacity);
}

void xemu_diagnostics_pgraph_increment_trace_set_enabled(int enabled){xemu_debug_tools_pgraph_increment_trace_set_enabled(enabled);}
void xemu_diagnostics_pgraph_increment_trace_set_threshold_ns(uint64_t ns){xemu_debug_tools_pgraph_increment_trace_set_threshold_ns(ns);}
void xemu_diagnostics_pgraph_increment_trace_clear(void){xemu_debug_tools_pgraph_increment_trace_clear();}
int xemu_diagnostics_get_pgraph_increment_trace_status(
    XemuDiagnosticsLatencyTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_pgraph_increment_trace_get_status(status);
    return 1;
}
size_t xemu_diagnostics_get_pgraph_increment_trace(
    XemuDiagnosticsPgraphIncrementEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_pgraph_increment_trace_snapshot(events, capacity);
}
void xemu_diagnostics_ptimer_irq_latency_trace_set_enabled(int enabled){xemu_debug_tools_ptimer_irq_latency_trace_set_enabled(enabled);}
void xemu_diagnostics_ptimer_irq_latency_trace_set_threshold_ns(uint64_t ns){xemu_debug_tools_ptimer_irq_latency_trace_set_threshold_ns(ns);}
void xemu_diagnostics_ptimer_irq_latency_trace_clear(void){xemu_debug_tools_ptimer_irq_latency_trace_clear();}
int xemu_diagnostics_get_ptimer_irq_latency_trace_status(
    XemuDiagnosticsLatencyTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_ptimer_irq_latency_trace_get_status(status);
    return 1;
}
size_t xemu_diagnostics_get_ptimer_irq_latency_trace(
    XemuDiagnosticsPtimerIrqLatencyEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_ptimer_irq_latency_trace_snapshot(events, capacity);
}

void xemu_diagnostics_controller_input_poll_trace_set_enabled(int enabled)
{
    xemu_debug_tools_controller_input_poll_trace_set_enabled(enabled);
}

void xemu_diagnostics_controller_input_poll_trace_set_threshold_ns(
    uint64_t threshold_ns)
{
    xemu_debug_tools_controller_input_poll_trace_set_threshold_ns(threshold_ns);
}

void xemu_diagnostics_controller_input_poll_trace_clear(void)
{
    xemu_debug_tools_controller_input_poll_trace_clear();
}

int xemu_diagnostics_get_controller_input_poll_trace_status(
    XemuDiagnosticsControllerInputPollStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_controller_input_poll_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_controller_input_poll_trace(
    XemuDiagnosticsControllerInputPollEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_controller_input_poll_trace_snapshot(events, capacity);
}

void xemu_diagnostics_bql_trace_set_enabled(int enabled)
{
    xemu_debug_tools_bql_trace_set_enabled(enabled);
}

void xemu_diagnostics_bql_trace_clear(void)
{
    xemu_debug_tools_bql_trace_clear();
}

int xemu_diagnostics_get_bql_trace_status(
    XemuDiagnosticsBqlTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_bql_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_bql_trace(
    XemuDiagnosticsBqlTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_bql_trace_snapshot(events, capacity);
}

void xemu_diagnostics_main_loop_lock_trace_set_enabled(int enabled)
{
    xemu_debug_tools_main_loop_lock_trace_set_enabled(enabled);
}

void xemu_diagnostics_main_loop_lock_trace_clear(void)
{
    xemu_debug_tools_main_loop_lock_trace_clear();
}

int xemu_diagnostics_get_main_loop_lock_trace_status(
    XemuDiagnosticsMainLoopLockTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_main_loop_lock_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_main_loop_lock_trace(
    XemuDiagnosticsMainLoopLockTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_main_loop_lock_trace_snapshot(events, capacity);
}

void xemu_diagnostics_mmio_trace_set_enabled(int enabled)
{
    xemu_debug_tools_mmio_trace_set_enabled(enabled);
}

void xemu_diagnostics_mmio_trace_clear(void)
{
    xemu_debug_tools_mmio_trace_clear();
}

int xemu_diagnostics_get_mmio_trace_status(
    XemuDiagnosticsMmioTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_mmio_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_mmio_trace(
    XemuDiagnosticsMmioTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_mmio_trace_snapshot(events, capacity);
}

void xemu_diagnostics_pgraph_lock_trace_set_enabled(int enabled)
{
    xemu_debug_tools_pgraph_lock_trace_set_enabled(enabled);
}

void xemu_diagnostics_pgraph_lock_trace_clear(void)
{
    xemu_debug_tools_pgraph_lock_trace_clear();
}

int xemu_diagnostics_get_pgraph_lock_trace_status(
    XemuDiagnosticsPgraphLockTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_pgraph_lock_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_pgraph_lock_trace(
    XemuDiagnosticsPgraphLockTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_pgraph_lock_trace_snapshot(events, capacity);
}


void xemu_diagnostics_pgraph_flip_delay_trace_set_enabled(int enabled)
{
    xemu_debug_tools_pgraph_flip_delay_trace_set_enabled(enabled);
}

void xemu_diagnostics_pgraph_flip_delay_trace_clear(void)
{
    xemu_debug_tools_pgraph_flip_delay_trace_clear();
}

void xemu_diagnostics_pgraph_flip_delay_trace_set_threshold_ns(uint64_t ns)
{
    xemu_debug_tools_pgraph_flip_delay_trace_set_threshold_ns(ns);
}

int xemu_diagnostics_get_pgraph_flip_delay_trace_status(
    XemuDiagnosticsPgraphFlipDelayStatus *status)
{
    if (!status) {
        return 0;
    }
    xemu_debug_tools_pgraph_flip_delay_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_pgraph_flip_delay_trace(
    XemuDiagnosticsPgraphFlipDelayEvent *events, size_t capacity)
{
    return xemu_debug_tools_pgraph_flip_delay_trace_snapshot(events, capacity);
}

void xemu_diagnostics_pgraph_pusher_progress_trace_set_enabled(int enabled)
{
    xemu_debug_tools_pgraph_pusher_progress_trace_set_enabled(enabled);
}

void xemu_diagnostics_pgraph_pusher_progress_trace_clear(void)
{
    xemu_debug_tools_pgraph_pusher_progress_trace_clear();
}

int xemu_diagnostics_get_pgraph_pusher_progress_trace_status(
    XemuDiagnosticsPgraphPusherProgressStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_pgraph_pusher_progress_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_pgraph_pusher_progress_trace(
    XemuDiagnosticsPgraphPusherProgressEvent *events, size_t capacity)
{
    return xemu_debug_tools_pgraph_pusher_progress_trace_snapshot(events, capacity);
}


void xemu_diagnostics_pgraph_pusher_method_breakdown_trace_set_enabled(int enabled)
{
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(enabled);
}

void xemu_diagnostics_pgraph_pusher_method_breakdown_trace_clear(void)
{
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear();
}

int xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace_status(
    XemuDiagnosticsPgraphPusherMethodBreakdownStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_pgraph_pusher_method_breakdown_trace(
    XemuDiagnosticsPgraphPusherMethodBreakdownEvent *events, size_t capacity)
{
    return xemu_debug_tools_pgraph_pusher_method_breakdown_trace_snapshot(
        events, capacity);
}

void xemu_diagnostics_av_sync_trace_set_enabled(int enabled)
{
    xemu_debug_tools_av_sync_trace_set_enabled(enabled);
}
void xemu_diagnostics_av_sync_trace_clear(void)
{
    xemu_debug_tools_av_sync_trace_clear();
}
int xemu_diagnostics_get_av_sync_trace_status(
    XemuDiagnosticsAvSyncTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_av_sync_trace_get_status(status);
    return 1;
}
size_t xemu_diagnostics_get_av_sync_trace(
    XemuDiagnosticsAvSyncTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_av_sync_trace_snapshot(events, capacity);
}

void xemu_diagnostics_flip_stall_trace_set_enabled(int enabled){xemu_debug_tools_flip_stall_trace_set_enabled(enabled);}
void xemu_diagnostics_flip_stall_trace_clear(void){xemu_debug_tools_flip_stall_trace_clear();}
int xemu_diagnostics_get_flip_stall_trace_status(
    XemuDiagnosticsFlipStallStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_flip_stall_trace_get_status(status);
    return 1;
}
size_t xemu_diagnostics_get_flip_stall_trace(
    XemuDiagnosticsFlipStallEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_flip_stall_trace_snapshot(events, capacity);
}

void xemu_diagnostics_scheduler_trace_sample(void){xemu_debug_tools_scheduler_trace_sample();}
void xemu_diagnostics_scheduler_trace_set_enabled(int enabled){xemu_debug_tools_scheduler_trace_set_enabled(enabled);}
void xemu_diagnostics_scheduler_trace_clear(void){xemu_debug_tools_scheduler_trace_clear();}
int xemu_diagnostics_get_scheduler_trace_status(
    XemuDiagnosticsSchedulerTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_scheduler_trace_get_status(status);
    return 1;
}
size_t xemu_diagnostics_get_scheduler_trace(
    XemuDiagnosticsSchedulerTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_scheduler_trace_snapshot(events, capacity);
}

void xemu_diagnostics_pgraph_draw_trace_set_enabled(int enabled)
{
    xemu_debug_tools_pgraph_draw_trace_set_enabled(enabled);
}

void xemu_diagnostics_pgraph_draw_trace_clear(void)
{
    xemu_debug_tools_pgraph_draw_trace_clear();
}

int xemu_diagnostics_get_pgraph_draw_trace_status(
    XemuDiagnosticsPgraphDrawTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_pgraph_draw_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_pgraph_draw_trace(
    XemuDiagnosticsPgraphDrawTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_pgraph_draw_trace_snapshot(events, capacity);
}

void xemu_diagnostics_controller_xid_trace_set_enabled(int enabled)
{
    xemu_debug_tools_controller_xid_trace_set_enabled(enabled);
}

void xemu_diagnostics_controller_xid_trace_clear(void)
{
    xemu_debug_tools_controller_xid_trace_clear();
}

int xemu_diagnostics_get_controller_xid_trace_status(
    XemuDiagnosticsControllerXidTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_controller_xid_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_controller_xid_trace(
    XemuDiagnosticsControllerXidTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_controller_xid_trace_snapshot(events, capacity);
}

void xemu_diagnostics_guest_input_consumer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_guest_input_consumer_trace_set_enabled(enabled);
}

void xemu_diagnostics_guest_input_consumer_trace_clear(void)
{
    xemu_debug_tools_guest_input_consumer_trace_clear();
}

int xemu_diagnostics_get_guest_input_consumer_trace_status(
    XemuDiagnosticsGuestInputConsumerTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_guest_input_consumer_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_guest_input_consumer_trace(
    XemuDiagnosticsGuestInputConsumerTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_guest_input_consumer_trace_snapshot(
        events, capacity);
}

void xemu_diagnostics_ptimer_late_capture_set_enabled(int enabled)
{
    xemu_debug_tools_ptimer_late_capture_set_enabled(enabled);
}

void xemu_diagnostics_ptimer_late_capture_clear(void)
{
    xemu_debug_tools_ptimer_late_capture_clear();
}

int xemu_diagnostics_get_ptimer_late_capture_status(
    XemuDiagnosticsPtimerLateCaptureStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_ptimer_late_capture_get_status(status);
    return 1;
}

int xemu_diagnostics_get_ptimer_late_capture(
    XemuDiagnosticsPtimerLateCaptureSnapshot *snapshot)
{
    if (snapshot == NULL) {
        return 0;
    }
    return xemu_debug_tools_ptimer_late_capture_snapshot(snapshot);
}

void xemu_diagnostics_d3d_callback_capture_set_enabled(int enabled)
{
    xemu_debug_tools_d3d_callback_capture_set_enabled(enabled);
}

void xemu_diagnostics_d3d_callback_capture_clear(void)
{
    xemu_debug_tools_d3d_callback_capture_clear();
}

int xemu_diagnostics_get_d3d_callback_capture_status(
    XemuDiagnosticsD3dCallbackCaptureStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_d3d_callback_capture_get_status(status);
    return 1;
}

int xemu_diagnostics_get_d3d_callback_capture(
    XemuDiagnosticsD3dCallbackCaptureSnapshot *snapshot)
{
    if (snapshot == NULL) {
        return 0;
    }
    return xemu_debug_tools_d3d_callback_capture_snapshot(snapshot);
}

void xemu_diagnostics_ptimer_irq_delivery_trace_set_enabled(int enabled)
{
    xemu_debug_tools_ptimer_irq_delivery_trace_set_enabled(enabled);
}

void xemu_diagnostics_ptimer_irq_delivery_trace_clear(void)
{
    xemu_debug_tools_ptimer_irq_delivery_trace_clear();
}

int xemu_diagnostics_get_ptimer_irq_delivery_trace_status(
    XemuDiagnosticsPtimerIrqDeliveryStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_ptimer_irq_delivery_trace_get_status(status);
    return 1;
}

int xemu_diagnostics_get_ptimer_irq_delivery_trace(
    XemuDiagnosticsPtimerIrqDeliverySnapshot *snapshot)
{
    if (snapshot == NULL) {
        return 0;
    }
    return xemu_debug_tools_ptimer_irq_delivery_trace_snapshot(snapshot);
}

void xemu_diagnostics_guest_timer_deadline_trace_set_enabled(int enabled)
{
    xemu_debug_tools_guest_timer_deadline_trace_set_enabled(enabled);
}

void xemu_diagnostics_guest_timer_deadline_trace_clear(void)
{
    xemu_debug_tools_guest_timer_deadline_trace_clear();
}

int xemu_diagnostics_get_guest_timer_deadline_trace_status(
    XemuDiagnosticsGuestTimerDeadlineTraceStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_guest_timer_deadline_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_guest_timer_deadline_trace(
    XemuDiagnosticsGuestTimerDeadlineTraceEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_guest_timer_deadline_trace_snapshot(
        events, capacity);
}

int xemu_diagnostics_get_d3d_timer_state_trace_status(
    XemuDiagnosticsD3dTimerStateStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_d3d_timer_state_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_d3d_timer_state_trace(
    XemuDiagnosticsD3dTimerStateEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_d3d_timer_state_trace_snapshot(events, capacity);
}

void xemu_diagnostics_host_stall_trace_set_enabled(int enabled)
{
    xemu_debug_tools_host_stall_trace_set_enabled(enabled);
}

void xemu_diagnostics_host_stall_trace_clear(void)
{
    xemu_debug_tools_host_stall_trace_clear();
}

int xemu_diagnostics_get_host_stall_trace_status(
    XemuDiagnosticsHostStallStatus *status)
{
    if (status == NULL) {
        return 0;
    }
    xemu_debug_tools_host_stall_trace_get_status(status);
    return 1;
}

size_t xemu_diagnostics_get_host_stall_trace(
    XemuDiagnosticsHostStallEvent *events, size_t capacity)
{
    if (events == NULL || capacity == 0) {
        return 0;
    }
    return xemu_debug_tools_host_stall_trace_snapshot(events, capacity);
}

