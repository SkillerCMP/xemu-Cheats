/* xemu Debug Tools - Diagnostics-owned NV2A FLIP_STALL / VBlank trace. */
#pragma once

#include "flip-stall-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_FLIP_STALL_TRACE_CAPACITY 4096

typedef struct XemuDebugToolsFlipStallTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t stall_age_ns;
    uint64_t duration_ns;
    uint64_t guest_pc;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t guest_pc_valid;
    uint32_t event_type;
    uint32_t method;
    uint32_t parameter;
    uint32_t value0;
    uint32_t value1;
    uint32_t surface;
    uint32_t read_3d;
    uint32_t write_3d;
    uint32_t modulo_3d;
    uint32_t waiting_for_flip;
    uint32_t pending_interrupts;
    uint32_t enabled_interrupts;
    uint32_t flush_pending;
    uint32_t sync_pending;
    uint32_t frame_time;
} XemuDebugToolsFlipStallTraceEvent;

typedef struct XemuDebugToolsFlipStallTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t active_stall;
    uint64_t active_stall_start_host_ns;
    uint64_t active_stall_start_virtual_ns;
    uint64_t active_stall_age_ns;
} XemuDebugToolsFlipStallTraceStatus;

void xemu_debug_tools_flip_stall_trace_set_enabled(int enabled);
void xemu_debug_tools_flip_stall_trace_clear(void);
int xemu_debug_tools_flip_stall_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_flip_stall_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_flip_stall_trace_get_buffer_capacity(void);
void xemu_debug_tools_flip_stall_trace_get_status(
    XemuDebugToolsFlipStallTraceStatus *status);
size_t xemu_debug_tools_flip_stall_trace_snapshot(
    XemuDebugToolsFlipStallTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
