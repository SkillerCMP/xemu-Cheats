/* Info: Observation-only Controller/XID trace. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "controller-xid-trace.h"
#include "diagnostics-trace-buffer.h"

#define XEMU_CONTROLLER_XID_HEARTBEAT_NS 1000000000ULL
#define XEMU_CONTROLLER_XID_PORT_SLOTS 5

typedef struct XemuControllerXidStateSignature {
    bool valid;
    uint32_t buttons;
    int16_t axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT];
    uint16_t xid_buttons;
    uint8_t xid_analog[XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT];
    int16_t thumb_lx;
    int16_t thumb_ly;
    int16_t thumb_rx;
    int16_t thumb_ry;
    uint64_t last_store_host_ns;
} XemuControllerXidStateSignature;

typedef struct XemuControllerXidPacketSignature {
    bool valid;
    int32_t packet_status;
    uint32_t actual_length;
    uint32_t requested_length;
    uint32_t endpoint;
    uint32_t report_length;
    uint8_t report[XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX];
    uint64_t last_store_host_ns;
} XemuControllerXidPacketSignature;

typedef struct XemuControllerXidGuestWriteSignature {
    bool valid;
    uintptr_t usb_device;
    uint32_t report_length;
    uint8_t report[XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX];
    uint64_t last_store_host_ns;
} XemuControllerXidGuestWriteSignature;

typedef struct XemuControllerXidTraceState {
    QemuMutex lock;
    bool lock_initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_observations;
    uint64_t stored_events;
    uint64_t overwritten_events;
    uint64_t observations[XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT];
    uint64_t last_event_store_host_ns[XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT]
                                     [XEMU_CONTROLLER_XID_PORT_SLOTS];
    XemuControllerXidStateSignature host_state[XEMU_CONTROLLER_XID_PORT_SLOTS];
    XemuControllerXidStateSignature xid_state[XEMU_CONTROLLER_XID_PORT_SLOTS];
    XemuControllerXidPacketSignature xid_packet[XEMU_CONTROLLER_XID_PORT_SLOTS];
    XemuControllerXidGuestWriteSignature guest_input_write;
    bool input_mode_valid;
    bool input_mode_enabled;
    uint32_t buffer_multiplier;
    XemuDebugToolsControllerXidTraceEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuControllerXidTraceState;

static XemuControllerXidTraceState controller_xid_trace;

void xemu_debug_tools_controller_xid_trace_init(void)
{
    if (!controller_xid_trace.lock_initialized) {
        qemu_mutex_init(&controller_xid_trace.lock);
        controller_xid_trace.lock_initialized = true;
        controller_xid_trace.buffer_multiplier = 1;
    }
}

static int trace_port_slot(int32_t port)
{
    return port >= 0 && port < 4 ? port : 4;
}

static bool event_valid(XemuDebugToolsControllerXidTraceHookEvent event_type)
{
    return event_type > 0 &&
           event_type < XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT;
}

static uint64_t note_observation_locked(
    XemuDebugToolsControllerXidTraceHookEvent event_type)
{
    uint64_t sequence = controller_xid_trace.total_observations++;
    if (event_valid(event_type)) {
        ++controller_xid_trace.observations[event_type];
    }
    return sequence;
}

static void store_event_locked(XemuDebugToolsControllerXidTraceEvent *event)
{
    const size_t trace_capacity = xemu_debug_tools_controller_xid_trace_get_buffer_capacity();
    size_t slot = controller_xid_trace.write_index;

    event->qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event->host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(controller_xid_trace.events, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, slot) = *event;
    controller_xid_trace.write_index = (slot + 1) % trace_capacity;
    ++controller_xid_trace.stored_events;
    if (controller_xid_trace.count < trace_capacity) {
        ++controller_xid_trace.count;
    } else {
        ++controller_xid_trace.overwritten_events;
    }
}

static bool heartbeat_due(uint64_t now_ns, uint64_t last_ns)
{
    return last_ns == 0 || now_ns - last_ns >= XEMU_CONTROLLER_XID_HEARTBEAT_NS;
}

void xemu_debug_tools_controller_xid_trace_host_lifecycle(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    uint32_t instance_id,
    int32_t save_binding,
    const char *name,
    const char *guid)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(event_type);
    event.event_type = event_type;
    event.port = port;
    event.instance_id = instance_id;
    event.save_binding = save_binding;
    g_strlcpy(event.name, name != NULL ? name : "", sizeof(event.name));
    g_strlcpy(event.guid, guid != NULL ? guid : "", sizeof(event.guid));
    store_event_locked(&event);
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_host_state(
    int32_t port,
    uint32_t instance_id,
    uint32_t buttons,
    const int16_t axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT])
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    XemuControllerXidStateSignature *last;
    uint64_t now_ns;
    bool changed;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(
        XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_INPUT_STATE);
    slot = trace_port_slot(port);
    last = &controller_xid_trace.host_state[slot];
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    changed = !last->valid || last->buttons != buttons ||
              memcmp(last->axis, axis, sizeof(last->axis)) != 0;
    if (!changed && !heartbeat_due(now_ns, last->last_store_host_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_INPUT_STATE;
    event.port = port;
    event.instance_id = instance_id;
    event.host_buttons = buttons;
    memcpy(event.host_axis, axis, sizeof(event.host_axis));
    store_event_locked(&event);

    last->valid = true;
    last->buttons = buttons;
    memcpy(last->axis, axis, sizeof(last->axis));
    last->last_store_host_ns = now_ns;
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_xid_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *xid_device,
    uint32_t value0,
    uint32_t value1)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    uint64_t now_ns;
    uint64_t *last_store_ns;
    bool throttled;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(event_type);
    slot = trace_port_slot(port);
    throttled = event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_GET_REPORT ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INTERRUPT_IN;
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    last_store_ns = event_valid(event_type)
                        ? &controller_xid_trace.last_event_store_host_ns[event_type][slot]
                        : NULL;
    if (throttled && last_store_ns != NULL &&
        !heartbeat_due(now_ns, *last_store_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = event_type;
    event.port = port;
    event.xid_device = (uintptr_t)xid_device;
    event.value0 = value0;
    event.value1 = value1;
    store_event_locked(&event);
    if (last_store_ns != NULL) {
        *last_store_ns = now_ns;
    }
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_usb_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    uint64_t now_ns;
    uint64_t *last_store_ns;
    bool throttled;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(event_type);
    slot = trace_port_slot(port);
    throttled = event_type ==
                    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_COMPLETE ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_DONE_HEAD ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_WDH_IRQ;
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    last_store_ns = event_valid(event_type)
                        ? &controller_xid_trace.last_event_store_host_ns[event_type][slot]
                        : NULL;
    if (throttled && last_store_ns != NULL &&
        !heartbeat_due(now_ns, *last_store_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = event_type;
    event.port = port;
    event.xid_device = (uintptr_t)usb_device;
    event.value0 = value0;
    event.value1 = value1;
    event.value2 = value2;
    event.value3 = value3;
    store_event_locked(&event);
    if (last_store_ns != NULL) {
        *last_store_ns = now_ns;
    }
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_usb_event5(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3,
    uint32_t value4)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    uint64_t now_ns;
    uint64_t *last_store_ns;
    bool throttled;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(event_type);
    slot = event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_WDH_IRQ
               ? (value4 ? 0 : 1)
               : trace_port_slot(port);
    throttled = event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_COMPLETE ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_DONE_HEAD ||
                event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_WDH_IRQ;
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    last_store_ns = event_valid(event_type)
                        ? &controller_xid_trace.last_event_store_host_ns[event_type][slot]
                        : NULL;
    /* Retain healthy periodic paths at 1 Hz, but never hide a TD error. */
    const bool force_store_error =
        (event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_COMPLETE ||
         event_type == XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_DONE_HEAD) &&
        value4 != 0;
    if (throttled && !force_store_error && last_store_ns != NULL &&
        !heartbeat_due(now_ns, *last_store_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = event_type;
    event.port = port;
    event.xid_device = (uintptr_t)usb_device;
    event.value0 = value0;
    event.value1 = value1;
    event.value2 = value2;
    event.value3 = value3;
    event.value4 = value4;
    store_event_locked(&event);
    if (last_store_ns != NULL) {
        *last_store_ns = now_ns;
    }
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_xid_packet_complete(
    int32_t port,
    const void *xid_device,
    int32_t packet_status,
    uint32_t actual_length,
    uint32_t requested_length,
    uint32_t endpoint,
    const uint8_t *report,
    uint32_t report_length)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    XemuControllerXidPacketSignature *last;
    uint64_t now_ns;
    uint32_t stored_report_length;
    bool changed;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(
        XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_IN_PACKET_COMPLETE);
    slot = trace_port_slot(port);
    last = &controller_xid_trace.xid_packet[slot];
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    stored_report_length = MIN(report_length,
        (uint32_t)XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX);
    changed = !last->valid || last->packet_status != packet_status ||
              last->actual_length != actual_length ||
              last->requested_length != requested_length ||
              last->endpoint != endpoint ||
              last->report_length != stored_report_length ||
              (stored_report_length != 0 && report != NULL &&
               memcmp(last->report, report, stored_report_length) != 0);
    if (!changed && !heartbeat_due(now_ns, last->last_store_host_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_IN_PACKET_COMPLETE;
    event.port = port;
    event.xid_device = (uintptr_t)xid_device;
    event.value0 = (uint32_t)packet_status;
    event.value1 = actual_length;
    event.value2 = requested_length;
    event.value3 = endpoint;
    event.report_length = stored_report_length;
    if (stored_report_length != 0 && report != NULL) {
        memcpy(event.report, report, stored_report_length);
    }
    store_event_locked(&event);

    last->valid = true;
    last->packet_status = packet_status;
    last->actual_length = actual_length;
    last->requested_length = requested_length;
    last->endpoint = endpoint;
    last->report_length = stored_report_length;
    memset(last->report, 0, sizeof(last->report));
    if (stored_report_length != 0 && report != NULL) {
        memcpy(last->report, report, stored_report_length);
    }
    last->last_store_host_ns = now_ns;
    qemu_mutex_unlock(&controller_xid_trace.lock);
}


void xemu_debug_tools_controller_xid_trace_guest_input_write(
    const void *usb_device,
    uint32_t td_address,
    uint32_t guest_address0,
    uint32_t guest_length0,
    uint32_t guest_address1,
    uint32_t guest_length1,
    const uint8_t *report,
    uint32_t report_length)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    XemuControllerXidGuestWriteSignature *last;
    uint64_t now_ns;
    uint32_t stored_report_length;
    bool changed;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(
        XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE);
    last = &controller_xid_trace.guest_input_write;
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    stored_report_length = MIN(
        report_length, (uint32_t)XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX);
    changed = !last->valid || last->usb_device != (uintptr_t)usb_device ||
              last->report_length != stored_report_length ||
              (stored_report_length != 0 && report != NULL &&
               memcmp(last->report, report, stored_report_length) != 0);
    if (!changed && !heartbeat_due(now_ns, last->last_store_host_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type =
        XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE;
    event.port = -1;
    event.xid_device = (uintptr_t)usb_device;
    event.value0 = td_address;
    event.value1 = guest_address0;
    event.value2 = guest_length0;
    event.value3 = guest_address1;
    event.value4 = guest_length1;
    event.report_length = stored_report_length;
    if (stored_report_length != 0 && report != NULL) {
        memcpy(event.report, report, stored_report_length);
    }
    store_event_locked(&event);

    last->valid = true;
    last->usb_device = (uintptr_t)usb_device;
    last->report_length = stored_report_length;
    memset(last->report, 0, sizeof(last->report));
    if (stored_report_length != 0 && report != NULL) {
        memcpy(last->report, report, stored_report_length);
    }
    last->last_store_host_ns = now_ns;
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_input_mode(
    int32_t enabled,
    int32_t nav_active,
    int32_t controller_activity,
    int32_t rebinding,
    int32_t navigating_with_controller)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    bool mode_enabled = enabled != 0;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    if (controller_xid_trace.input_mode_valid &&
        controller_xid_trace.input_mode_enabled == mode_enabled) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = mode_enabled
        ? XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_ON
        : XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_OFF;
    event.sequence = note_observation_locked(event.event_type);
    event.port = -1;
    event.value0 = nav_active != 0;
    event.value1 = controller_activity != 0;
    event.value2 = rebinding != 0;
    event.value3 = navigating_with_controller != 0;
    store_event_locked(&event);

    controller_xid_trace.input_mode_valid = true;
    controller_xid_trace.input_mode_enabled = mode_enabled;
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_xid_state(
    int32_t port,
    const void *xid_device,
    uint32_t host_buttons,
    const int16_t host_axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT],
    uint16_t xid_buttons,
    const uint8_t xid_analog[XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT],
    int16_t thumb_lx,
    int16_t thumb_ly,
    int16_t thumb_rx,
    int16_t thumb_ry)
{
    XemuDebugToolsControllerXidTraceEvent event = { 0 };
    XemuControllerXidStateSignature *last;
    uint64_t now_ns;
    bool changed;
    int slot;

    if (!controller_xid_trace.lock_initialized ||
        !qatomic_read(&controller_xid_trace.enabled)) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (!qatomic_read(&controller_xid_trace.enabled)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.sequence = note_observation_locked(
        XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INPUT_STATE);
    slot = trace_port_slot(port);
    last = &controller_xid_trace.xid_state[slot];
    now_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    changed = !last->valid || last->buttons != host_buttons ||
              last->xid_buttons != xid_buttons ||
              memcmp(last->axis, host_axis, sizeof(last->axis)) != 0 ||
              memcmp(last->xid_analog, xid_analog, sizeof(last->xid_analog)) != 0 ||
              last->thumb_lx != thumb_lx || last->thumb_ly != thumb_ly ||
              last->thumb_rx != thumb_rx || last->thumb_ry != thumb_ry;
    if (!changed && !heartbeat_due(now_ns, last->last_store_host_ns)) {
        qemu_mutex_unlock(&controller_xid_trace.lock);
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INPUT_STATE;
    event.port = port;
    event.xid_device = (uintptr_t)xid_device;
    event.host_buttons = host_buttons;
    memcpy(event.host_axis, host_axis, sizeof(event.host_axis));
    event.xid_buttons = xid_buttons;
    memcpy(event.xid_analog, xid_analog, sizeof(event.xid_analog));
    event.thumb_lx = thumb_lx;
    event.thumb_ly = thumb_ly;
    event.thumb_rx = thumb_rx;
    event.thumb_ry = thumb_ry;
    store_event_locked(&event);

    last->valid = true;
    last->buttons = host_buttons;
    memcpy(last->axis, host_axis, sizeof(last->axis));
    last->xid_buttons = xid_buttons;
    memcpy(last->xid_analog, xid_analog, sizeof(last->xid_analog));
    last->thumb_lx = thumb_lx;
    last->thumb_ly = thumb_ly;
    last->thumb_rx = thumb_rx;
    last->thumb_ry = thumb_ry;
    last->last_store_host_ns = now_ns;
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_set_enabled(int enabled)
{
    xemu_debug_tools_controller_xid_trace_init();
    qemu_mutex_lock(&controller_xid_trace.lock);
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(controller_xid_trace.events, XemuDebugToolsControllerXidTraceEvent, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, controller_xid_trace.buffer_multiplier, ok); if (!ok) { qemu_mutex_unlock(&controller_xid_trace.lock); return; } }
    if (enabled && !qatomic_read(&controller_xid_trace.enabled)) {
        controller_xid_trace.count = 0;
        controller_xid_trace.write_index = 0;
        controller_xid_trace.total_observations = 0;
        controller_xid_trace.stored_events = 0;
        controller_xid_trace.overwritten_events = 0;
        memset(controller_xid_trace.observations, 0,
               sizeof(controller_xid_trace.observations));
        memset(controller_xid_trace.last_event_store_host_ns, 0,
               sizeof(controller_xid_trace.last_event_store_host_ns));
        memset(controller_xid_trace.host_state, 0,
               sizeof(controller_xid_trace.host_state));
        memset(controller_xid_trace.xid_state, 0,
               sizeof(controller_xid_trace.xid_state));
        memset(controller_xid_trace.xid_packet, 0,
               sizeof(controller_xid_trace.xid_packet));
        memset(&controller_xid_trace.guest_input_write, 0,
               sizeof(controller_xid_trace.guest_input_write));
        controller_xid_trace.input_mode_valid = false;
        controller_xid_trace.input_mode_enabled = false;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(controller_xid_trace.events, XemuDebugToolsControllerXidTraceEvent, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, controller_xid_trace.buffer_multiplier);
    }
    qatomic_set(&controller_xid_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

int xemu_debug_tools_controller_xid_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; xemu_debug_tools_controller_xid_trace_init(); multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier); qemu_mutex_lock(&controller_xid_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(controller_xid_trace.events, XemuDebugToolsControllerXidTraceEvent, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, multiplier, ok);
    if (ok) {
        controller_xid_trace.buffer_multiplier=multiplier; controller_xid_trace.count=controller_xid_trace.write_index=0; controller_xid_trace.total_observations=controller_xid_trace.stored_events=controller_xid_trace.overwritten_events=0;
        memset(controller_xid_trace.observations,0,sizeof(controller_xid_trace.observations)); memset(controller_xid_trace.last_event_store_host_ns,0,sizeof(controller_xid_trace.last_event_store_host_ns)); memset(controller_xid_trace.host_state,0,sizeof(controller_xid_trace.host_state)); memset(controller_xid_trace.xid_state,0,sizeof(controller_xid_trace.xid_state)); memset(controller_xid_trace.xid_packet,0,sizeof(controller_xid_trace.xid_packet)); memset(&controller_xid_trace.guest_input_write,0,sizeof(controller_xid_trace.guest_input_write)); controller_xid_trace.input_mode_valid=false; controller_xid_trace.input_mode_enabled=false;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(controller_xid_trace.events, XemuDebugToolsControllerXidTraceEvent, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, multiplier);
    }
    qemu_mutex_unlock(&controller_xid_trace.lock); return ok?1:0;
}
uint32_t xemu_debug_tools_controller_xid_trace_get_buffer_multiplier(void){ return controller_xid_trace.buffer_multiplier?controller_xid_trace.buffer_multiplier:1; }
size_t xemu_debug_tools_controller_xid_trace_get_buffer_capacity(void){ return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY,xemu_debug_tools_controller_xid_trace_get_buffer_multiplier()); }

void xemu_debug_tools_controller_xid_trace_clear(void)
{
    int enabled;

    xemu_debug_tools_controller_xid_trace_init();
    qemu_mutex_lock(&controller_xid_trace.lock);
    enabled = qatomic_read(&controller_xid_trace.enabled);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(controller_xid_trace.events, XemuDebugToolsControllerXidTraceEvent, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, controller_xid_trace.buffer_multiplier);
    controller_xid_trace.count = 0;
    controller_xid_trace.write_index = 0;
    controller_xid_trace.total_observations = 0;
    controller_xid_trace.stored_events = 0;
    controller_xid_trace.overwritten_events = 0;
    memset(controller_xid_trace.observations, 0,
           sizeof(controller_xid_trace.observations));
    memset(controller_xid_trace.last_event_store_host_ns, 0,
           sizeof(controller_xid_trace.last_event_store_host_ns));
    memset(controller_xid_trace.host_state, 0,
           sizeof(controller_xid_trace.host_state));
    memset(controller_xid_trace.xid_state, 0,
           sizeof(controller_xid_trace.xid_state));
    memset(controller_xid_trace.xid_packet, 0,
           sizeof(controller_xid_trace.xid_packet));
    controller_xid_trace.input_mode_valid = false;
    controller_xid_trace.input_mode_enabled = false;
    qatomic_set(&controller_xid_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

void xemu_debug_tools_controller_xid_trace_get_status(
    XemuDebugToolsControllerXidTraceStatus *status)
{
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    if (!controller_xid_trace.lock_initialized) {
        return;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    status->enabled = qatomic_read(&controller_xid_trace.enabled) ? 1 : 0;
    status->count = controller_xid_trace.count;
    status->total_observations = controller_xid_trace.total_observations;
    status->stored_events = controller_xid_trace.stored_events;
    status->overwritten_events = controller_xid_trace.overwritten_events;
    memcpy(status->observations, controller_xid_trace.observations,
           sizeof(status->observations));
    qemu_mutex_unlock(&controller_xid_trace.lock);
}

size_t xemu_debug_tools_controller_xid_trace_snapshot(
    XemuDebugToolsControllerXidTraceEvent *events,
    size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (events == NULL || capacity == 0 ||
        !controller_xid_trace.lock_initialized) {
        return 0;
    }
    qemu_mutex_lock(&controller_xid_trace.lock);
    to_copy = MIN(capacity, controller_xid_trace.count);
    const size_t trace_capacity=xemu_debug_tools_controller_xid_trace_get_buffer_capacity();
    oldest = controller_xid_trace.count == trace_capacity ? controller_xid_trace.write_index : 0;
    if (to_copy < controller_xid_trace.count) {
        oldest = (oldest + controller_xid_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(controller_xid_trace.events, XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY, (oldest+i)%trace_capacity);
    }
    qemu_mutex_unlock(&controller_xid_trace.lock);
    return to_copy;
}
