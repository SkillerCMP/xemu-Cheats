/* Info: Main-loop lock tracing forwards to the shared lock-trace recorder core. */
#include "main-loop-lock-trace.h"

void xemu_debug_tools_main_loop_lock_trace_set_next_context(uint32_t context)
{
    xemu_debug_tools_lock_trace_core_set_next_context(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, context);
}

void xemu_debug_tools_main_loop_lock_trace_owner_stage_begin(uint32_t stage)
{
    xemu_debug_tools_lock_trace_core_owner_stage_begin(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, stage);
}

void xemu_debug_tools_main_loop_lock_trace_owner_stage_end(void)
{
    xemu_debug_tools_lock_trace_core_owner_stage_end(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

void xemu_debug_tools_main_loop_lock_trace_lock_attempt(const char *file,
                                                        int line)
{
    xemu_debug_tools_lock_trace_core_lock_attempt(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, file, line);
}

void xemu_debug_tools_main_loop_lock_trace_lock_acquired(const char *file,
                                                         int line)
{
    xemu_debug_tools_lock_trace_core_lock_acquired(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, file, line);
}

void xemu_debug_tools_main_loop_lock_trace_unlock_begin(void)
{
    xemu_debug_tools_lock_trace_core_unlock_begin(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

void xemu_debug_tools_main_loop_lock_trace_unlock_end(void)
{
    xemu_debug_tools_lock_trace_core_unlock_end(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

void xemu_debug_tools_main_loop_lock_trace_set_enabled(int enabled)
{
    xemu_debug_tools_lock_trace_core_set_enabled(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, enabled);
}

int xemu_debug_tools_main_loop_lock_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    return xemu_debug_tools_lock_trace_core_set_buffer_multiplier(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, multiplier);
}

uint32_t xemu_debug_tools_main_loop_lock_trace_get_buffer_multiplier(void)
{
    return xemu_debug_tools_lock_trace_core_get_buffer_multiplier(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

size_t xemu_debug_tools_main_loop_lock_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_lock_trace_core_get_buffer_capacity(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

void xemu_debug_tools_main_loop_lock_trace_clear(void)
{
    xemu_debug_tools_lock_trace_core_clear(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP);
}

void xemu_debug_tools_main_loop_lock_trace_get_status(
    XemuDebugToolsMainLoopLockTraceStatus *status)
{
    xemu_debug_tools_lock_trace_core_get_status(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, status);
}

size_t xemu_debug_tools_main_loop_lock_trace_snapshot(
    XemuDebugToolsMainLoopLockTraceEvent *events, size_t capacity)
{
    return xemu_debug_tools_lock_trace_core_snapshot(
        XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP, events, capacity);
}
