/* Info: Focused PTIMER -> PIC -> TCG interrupt-delivery forensic trace. */
#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct CPUState CPUState;

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SLOW_NS (2 * 1000 * 1000ULL)
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_OVERDUE_NS (5 * 1000 * 1000ULL)
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_NS (50 * 1000ULL)
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT 4
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_EVENTS 768
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_SAMPLE_BUDGET 512

typedef enum XemuDebugToolsPtimerIrqDeliveryEventType {
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_NONE = 0,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_SET,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_NV2A_LINE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PCI_ROUTE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PIC_CPU_LINE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_SAMPLE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_TCG_HARD_TAKE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PENDING_OVERDUE,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_PTIMER_CLEAR,
} XemuDebugToolsPtimerIrqDeliveryEventType;

typedef enum XemuDebugToolsPtimerIrqDeliveryClassification {
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_NONE = 0,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_GUEST_IF_MASKED,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_IRQ_INHIBITED,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_CPU_HARD_MISSING,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_TCG_NOT_TAKEN,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_HARD_TAKEN_DURING_WINDOW,
    XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CLASS_OTHER,
} XemuDebugToolsPtimerIrqDeliveryClassification;

typedef struct XemuDebugToolsPtimerIrqDeliveryEvent {
    uint64_t sequence;
    uint64_t virtual_ns;
    uint64_t host_ns;
    uint64_t since_set_ns;
    uint32_t type;
    uint32_t guest_pc;
    uint32_t interrupt_request;
    int32_t cflags_next_tb;
    uint32_t eflags;
    uint32_t hflags;
    uint32_t hflags2;
    uint32_t ptimer_pending;
    uint32_t ptimer_enabled;
    uint32_t pmc_pending;
    uint32_t pmc_enabled;
    int32_t level;
    int32_t pirq;
    int32_t pic_irq;
    int32_t selected_interrupt;
    int32_t interrupt_vector;
    uint32_t cpu_valid;
    uint32_t hard_present;
    uint32_t hard_eligible;
    uint32_t if_enabled;
    uint32_t inhibit_irq;
    uint32_t noirq_cflags;
    uint32_t cpu_halted;
    int32_t exception_index;
    uint32_t apic_path;
} XemuDebugToolsPtimerIrqDeliveryEvent;

typedef struct XemuDebugToolsPtimerIrqDeliveryCapture {
    uint64_t capture_sequence;
    uint64_t irq_set_virtual_ns;
    uint64_t irq_clear_virtual_ns;
    uint64_t irq_set_host_ns;
    uint64_t irq_clear_host_ns;
    uint64_t service_virtual_ns;
    uint64_t service_host_ns;
    uint64_t total_tcg_checks;
    uint64_t sampled_tcg_checks;
    uint64_t dropped_samples;
    uint64_t if_disabled_samples;
    uint64_t if_enabled_samples;
    uint64_t inhibit_samples;
    uint64_t hard_present_samples;
    uint64_t hard_missing_samples;
    uint64_t hard_eligible_samples;
    uint64_t noirq_samples;
    uint64_t hard_take_events;
    uint32_t saw_nv2a_assert;
    uint32_t saw_pci_route_assert;
    uint32_t saw_pic_cpu_assert;
    uint32_t overdue_marked;
    uint32_t classification;
    size_t event_count;
    XemuDebugToolsPtimerIrqDeliveryEvent
        events[XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_EVENTS];
} XemuDebugToolsPtimerIrqDeliveryCapture;

typedef struct XemuDebugToolsPtimerIrqDeliveryStatus {
    int enabled;
    int active;
    uint64_t slow_threshold_ns;
    uint64_t overdue_threshold_ns;
    uint64_t sample_interval_ns;
    uint64_t total_windows;
    uint64_t slow_windows;
    uint64_t capture_count;
    uint64_t overwritten_captures;
    uint64_t active_set_virtual_ns;
    uint64_t active_age_ns;
    size_t stored_captures;
    uint32_t last_classification;
    uint64_t last_service_virtual_ns;
    uint32_t dispatcher_single_step_suppressed;
} XemuDebugToolsPtimerIrqDeliveryStatus;

typedef struct XemuDebugToolsPtimerIrqDeliverySnapshot {
    XemuDebugToolsPtimerIrqDeliveryStatus status;
    XemuDebugToolsPtimerIrqDeliveryCapture
        captures[XEMU_DEBUG_TOOLS_PTIMER_IRQ_DELIVERY_CAPTURE_COUNT];
    XemuDebugToolsPtimerIrqDeliveryCapture current;
} XemuDebugToolsPtimerIrqDeliverySnapshot;

int xemu_debug_tools_ptimer_irq_delivery_trace_active(void);
void xemu_debug_tools_ptimer_irq_delivery_trace_set_enabled(int enabled);
void xemu_debug_tools_ptimer_irq_delivery_trace_clear(void);
void xemu_debug_tools_ptimer_irq_delivery_note_set(
    uint32_t ptimer_pending, uint32_t ptimer_enabled,
    uint32_t pmc_pending, uint32_t pmc_enabled);
void xemu_debug_tools_ptimer_irq_delivery_note_nv2a_line(
    int level, uint32_t ptimer_pending, uint32_t ptimer_enabled,
    uint32_t pmc_pending, uint32_t pmc_enabled);
void xemu_debug_tools_ptimer_irq_delivery_note_pci_route(
    int pirq, int pic_irq, int level);
void xemu_debug_tools_ptimer_irq_delivery_note_pic_cpu_line(
    CPUState *cpu, int level, uint32_t interrupt_request_before,
    uint32_t interrupt_request_after, int apic_path);
void xemu_debug_tools_ptimer_irq_delivery_note_tcg_check(CPUState *cpu);
void xemu_debug_tools_ptimer_irq_delivery_note_tcg_take(
    CPUState *cpu, int selected_interrupt, int interrupt_vector);
void xemu_debug_tools_ptimer_irq_delivery_note_clear(
    uint32_t clear_value, uint32_t ptimer_pending,
    uint32_t ptimer_enabled, uint32_t pmc_pending, uint32_t pmc_enabled);
void xemu_debug_tools_ptimer_irq_delivery_trace_get_status(
    XemuDebugToolsPtimerIrqDeliveryStatus *status);
int xemu_debug_tools_ptimer_irq_delivery_trace_snapshot(
    XemuDebugToolsPtimerIrqDeliverySnapshot *snapshot);

#ifdef __cplusplus
}
#endif
