/* Info: Read-only PTIMER instrumentation. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "cpu.h"
#include "hw/xbox/nv2a/nv2a_int.h"

#include "ptimer-trace.h"
#include "diagnostics-trace-buffer.h"
#include "diagnostics-ptimer-utils.h"

typedef struct XemuDebugToolsPtimerTraceState {
    QemuMutex lock;
    bool lock_initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t last_scheduled_expire_ns;
    uint32_t buffer_multiplier;
    XemuDebugToolsPtimerTraceEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsPtimerTraceState;

static XemuDebugToolsPtimerTraceState ptimer_trace;

void xemu_debug_tools_ptimer_trace_init(void)
{
    if (!ptimer_trace.lock_initialized) {
        qemu_mutex_init(&ptimer_trace.lock);
        ptimer_trace.lock_initialized = true;
        ptimer_trace.buffer_multiplier = 1;
    }
}

void xemu_debug_tools_ptimer_trace_record(
    void *nv2a_state,
    XemuDebugToolsPtimerTraceHookEvent event_type,
    uint32_t value,
    uint32_t previous_value)
{
    NV2AState *d = nv2a_state;
    XemuDebugToolsPtimerTraceEvent event = { 0 };
    uint64_t now_ns;
    uint64_t alarm;
    size_t slot;
    CPUState *cpu;

    if (d == NULL || !ptimer_trace.lock_initialized ||
        !qatomic_read(&ptimer_trace.enabled)) {
        return;
    }

    qemu_mutex_lock(&ptimer_trace.lock);
    if (!qatomic_read(&ptimer_trace.enabled)) {
        qemu_mutex_unlock(&ptimer_trace.lock);
        return;
    }

    now_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.sequence = ptimer_trace.total_events++;
    event.qemu_virtual_ns = now_ns;
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    alarm = d->ptimer.alarm_time;
    event.alarm = alarm;

    if (d->ptimer.numerator != 0 && d->ptimer.denominator != 0 &&
        d->pramdac.core_clock_freq != 0) {
        event.ptimer_now = xemu_debug_tools_ptimer_clock(d, now_ns);
        event.alarm_delta_ns = xemu_debug_tools_ptimer_signed_alarm_delta_ns(
            d, event.ptimer_now, alarm);
    }

    event.qemu_timer_pending = timer_pending(&d->ptimer.timer) ? 1 : 0;
    if (event.qemu_timer_pending) {
        event.qemu_timer_expire_ns = timer_expire_time_ns(&d->ptimer.timer);
        event.qemu_timer_delta_ns =
            (int64_t)event.qemu_timer_expire_ns - (int64_t)now_ns;
    }

    if ((event_type == XEMU_DEBUG_TOOLS_PTIMER_TRACE_CALLBACK ||
         event_type == XEMU_DEBUG_TOOLS_PTIMER_TRACE_CALLBACK_DISABLED) &&
        ptimer_trace.last_scheduled_expire_ns != 0) {
        event.callback_lateness_ns =
            (int64_t)now_ns -
            (int64_t)ptimer_trace.last_scheduled_expire_ns;
    }

    cpu = current_cpu;
    if (cpu != NULL) {
        CPUX86State *env = &X86_CPU(cpu)->env;

        /* Same reference used by QEMU's x86 RDTSC helper. The Diagnostics
         * timing snapshot separately reports accelerator-visible WHPX TSC. */
        event.rdtsc_reference = cpu_get_tsc(env) + env->tsc_offset;
        event.rdtsc_reference_valid = 1;
        if (cpu->cc != NULL && cpu->cc->get_pc != NULL) {
            event.guest_pc = cpu->cc->get_pc(cpu);
            event.guest_pc_valid = 1;
        }
    }

    event.pending_interrupts = d->ptimer.pending_interrupts;
    event.enabled_interrupts = d->ptimer.enabled_interrupts;
    event.value = value;
    event.previous_value = previous_value;
    event.event_type = event_type;

    if (event_type == XEMU_DEBUG_TOOLS_PTIMER_TRACE_SCHEDULE &&
        event.qemu_timer_pending) {
        ptimer_trace.last_scheduled_expire_ns = event.qemu_timer_expire_ns;
    } else if (event_type == XEMU_DEBUG_TOOLS_PTIMER_TRACE_TIMER_DELETE ||
               event_type == XEMU_DEBUG_TOOLS_PTIMER_TRACE_RESET) {
        ptimer_trace.last_scheduled_expire_ns = 0;
    }

    const size_t trace_capacity = xemu_debug_tools_ptimer_trace_get_buffer_capacity();
    slot = ptimer_trace.write_index;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(ptimer_trace.events,
                                     XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                     slot) = event;
    ptimer_trace.write_index = (slot + 1) % trace_capacity;
    if (ptimer_trace.count < trace_capacity) {
        ++ptimer_trace.count;
    } else {
        ++ptimer_trace.overwritten_events;
    }
    qemu_mutex_unlock(&ptimer_trace.lock);
}

void xemu_debug_tools_ptimer_trace_set_enabled(int enabled)
{
    xemu_debug_tools_ptimer_trace_init();
    qemu_mutex_lock(&ptimer_trace.lock);
    if (enabled) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(ptimer_trace.events,
                                             XemuDebugToolsPtimerTraceEvent,
                                             XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                             ptimer_trace.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&ptimer_trace.lock);
            return;
        }
    }
    if (enabled && !qatomic_read(&ptimer_trace.enabled)) {
        ptimer_trace.count = 0;
        ptimer_trace.write_index = 0;
        ptimer_trace.total_events = 0;
        ptimer_trace.overwritten_events = 0;
        ptimer_trace.last_scheduled_expire_ns = 0;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(ptimer_trace.events,
                                           XemuDebugToolsPtimerTraceEvent,
                                           XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                           ptimer_trace.buffer_multiplier);
    }
    qatomic_set(&ptimer_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&ptimer_trace.lock);
}

int xemu_debug_tools_ptimer_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok;

    xemu_debug_tools_ptimer_trace_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&ptimer_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(ptimer_trace.events,
                                         XemuDebugToolsPtimerTraceEvent,
                                         XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                         multiplier, ok);
    if (ok) {
        ptimer_trace.buffer_multiplier = multiplier;
        ptimer_trace.count = 0;
        ptimer_trace.write_index = 0;
        ptimer_trace.total_events = 0;
        ptimer_trace.overwritten_events = 0;
        ptimer_trace.last_scheduled_expire_ns = 0;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(ptimer_trace.events,
                                           XemuDebugToolsPtimerTraceEvent,
                                           XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                           multiplier);
    }
    qemu_mutex_unlock(&ptimer_trace.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_ptimer_trace_get_buffer_multiplier(void)
{
    return ptimer_trace.buffer_multiplier != 0 ? ptimer_trace.buffer_multiplier : 1;
}

size_t xemu_debug_tools_ptimer_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
        xemu_debug_tools_ptimer_trace_get_buffer_multiplier());
}

void xemu_debug_tools_ptimer_trace_clear(void)
{
    xemu_debug_tools_ptimer_trace_init();
    qemu_mutex_lock(&ptimer_trace.lock);
    ptimer_trace.count = 0;
    ptimer_trace.write_index = 0;
    ptimer_trace.total_events = 0;
    ptimer_trace.overwritten_events = 0;
    ptimer_trace.last_scheduled_expire_ns = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(ptimer_trace.events,
                                       XemuDebugToolsPtimerTraceEvent,
                                       XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
                                       ptimer_trace.buffer_multiplier);
    qemu_mutex_unlock(&ptimer_trace.lock);
}

void xemu_debug_tools_ptimer_trace_get_status(
    XemuDebugToolsPtimerTraceStatus *status)
{
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    if (!ptimer_trace.lock_initialized) {
        return;
    }

    qemu_mutex_lock(&ptimer_trace.lock);
    status->enabled = qatomic_read(&ptimer_trace.enabled) ? 1 : 0;
    status->count = ptimer_trace.count;
    status->total_events = ptimer_trace.total_events;
    status->overwritten_events = ptimer_trace.overwritten_events;
    qemu_mutex_unlock(&ptimer_trace.lock);
}

size_t xemu_debug_tools_ptimer_trace_snapshot(
    XemuDebugToolsPtimerTraceEvent *events,
    size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (events == NULL || capacity == 0 || !ptimer_trace.lock_initialized) {
        return 0;
    }

    qemu_mutex_lock(&ptimer_trace.lock);
    to_copy = MIN(capacity, ptimer_trace.count);
    const size_t trace_capacity = xemu_debug_tools_ptimer_trace_get_buffer_capacity();
    oldest = ptimer_trace.count == trace_capacity ? ptimer_trace.write_index : 0;
    if (to_copy < ptimer_trace.count) {
        oldest = (oldest + ptimer_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            ptimer_trace.events, XEMU_DEBUG_TOOLS_PTIMER_TRACE_CAPACITY,
            (oldest + i) % trace_capacity);
    }
    qemu_mutex_unlock(&ptimer_trace.lock);
    return to_copy;
}
