/* xemu Debug Tools - D3D pusher / GPU progress correlation recorder. */
#pragma once

#include "pgraph-pusher-progress-trace-hook.h"
#include "pgraph-draw-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY 8192

#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY 1024
#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT 8
#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_NAME_CAPACITY 64
#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS 5000000ULL

typedef enum XemuDebugToolsPgraphPusherMethodVariant {
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_NORMAL = 0,
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_BEGIN = 1,
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_END = 2,
} XemuDebugToolsPgraphPusherMethodVariant;

typedef struct XemuDebugToolsPgraphPusherMethodStat {
    uint64_t total_ns;
    uint64_t max_ns;
    uint32_t graphics_class;
    uint32_t subchannel;
    uint32_t method;
    uint32_t method_base;
    uint32_t variant;
    uint32_t call_count;
    uint32_t words_processed;
    char name[XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_NAME_CAPACITY];
} XemuDebugToolsPgraphPusherMethodStat;

/* Inclusive spans nest; self_ns excludes measured immediate children only.
 * Self time still includes uninstrumented work and observer overhead. */
typedef struct XemuDebugToolsPgraphDrawAggregateStat {
    uint64_t total_ns;
    uint64_t self_ns;
    uint64_t max_ns;
    uint64_t calls;
} XemuDebugToolsPgraphDrawAggregateStat;

typedef struct XemuDebugToolsPgraphDrawAggregate {
    uint64_t completed_draws;
    uint64_t sub5ms_draws;
    uint64_t fast_reuse;
    uint64_t cache_hits;
    uint64_t cache_misses;
    uint64_t dropped_spans;
    uint64_t invalid_spans;
    uint64_t saturated;
    uint64_t metrics[XEMU_DEBUG_TOOLS_PGRAPH_METRIC_COUNT];
    XemuDebugToolsPgraphDrawAggregateStat stages[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT];
} XemuDebugToolsPgraphDrawAggregate;

typedef struct XemuDebugToolsPgraphPusherMethodBreakdownEvent {
    uint64_t sequence;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t virtual_start_ns;
    uint64_t virtual_end_ns;
    uint64_t duration_ns;
    uint64_t puller_dispatch_ns;
    uint64_t parser_other_ns;
    uint64_t nv097_puller_ns;
    uint64_t non_nv097_puller_ns;
    uint64_t unclassified_puller_ns;
    uint64_t untracked_nv097_ns;
    uint32_t channel_id;
    uint32_t dma_get_before;
    uint32_t dma_get_after;
    uint32_t dma_put_before;
    uint32_t dma_put_after;
    uint32_t method_words_processed;
    uint32_t puller_calls;
    uint32_t nv097_calls;
    uint32_t non_nv097_calls;
    uint32_t unclassified_calls;
    uint32_t unique_nv097_methods;
    uint32_t untracked_nv097_calls;
    uint32_t top_method_count;
    XemuDebugToolsPgraphDrawAggregate draw;
    XemuDebugToolsPgraphPusherMethodStat
        top_methods[XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT];
} XemuDebugToolsPgraphPusherMethodBreakdownEvent;

typedef struct XemuDebugToolsPgraphPusherMethodBreakdownStatus {
    int enabled;
    size_t count;
    size_t capacity;
    uint64_t threshold_ns;
    uint64_t total_long_runs;
    uint64_t overwritten_events;
    uint64_t worst_run_ns;
    uint64_t worst_puller_dispatch_ns;
    uint64_t worst_parser_other_ns;
    uint64_t last_run_ns;
    uint64_t last_puller_dispatch_ns;
    uint64_t last_parser_other_ns;
    uint32_t last_puller_calls;
    uint32_t last_nv097_calls;
    uint32_t last_unique_nv097_methods;
} XemuDebugToolsPgraphPusherMethodBreakdownStatus;

/* Bounded, all-nonempty-PFIFO coverage. Windows close after >=100ms of host
 * span, at an existing run end. No idle/empty FIFO scopes are manufactured.
 * The newest window may be live: replace it by its later revision, do not sum
 * snapshots. Durations are WHOLE runs, not clipped to arbitrary frame bounds. */
#define XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY 2048
#define XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_WINDOW_NS 100000000ULL
#define XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_FIELDS(X) \
    X(host_start_ns) \
    X(host_end_ns) \
    X(virtual_start_ns) \
    X(virtual_end_ns) \
    X(runs) \
    X(short_runs) \
    X(run_ns) \
    X(short_run_ns) \
    X(dispatch_ns) \
    X(short_dispatch_ns) \
    X(words) \
    X(max_run_ns) \
    X(draws) \
    X(end_ns) \
    X(vertex_ns) \
    X(range_prep_ns) \
    X(dirty_check_ns) \
    X(surface_ns) \
    X(overlap_check_ns) \
    X(vertex_finish_ns) \
    X(fence_wait_ns) \
    X(copy_ns) \
    X(requested_ranges) \
    X(merged_ranges) \
    X(tested_bytes) \
    X(dirty_ranges) \
    X(dirty_bytes) \
    X(copy_calls) \
    X(copy_bytes) \
    X(overlap_finishes) \
    X(vertex_fence_wait_ns) \
    X(vertex_fence_waits) \
    X(invalid_spans) \
    X(dropped_spans) \
    X(saturated) \
    X(publication_deferrals)

typedef struct XemuDebugToolsPgraphCoverageEvent {
    uint64_t sequence;
    uint64_t epoch;
    uint64_t recording_generation;
    uint32_t closed;
#define XEMU_COVERAGE_FIELD(name) uint64_t name;
    XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_FIELDS(XEMU_COVERAGE_FIELD)
#undef XEMU_COVERAGE_FIELD
} XemuDebugToolsPgraphCoverageEvent;

/* Nonblocking slot reads. skipped_slots tells the caller about busy slots;
 * callers may save again. Returned rows are in sequence order. */
size_t xemu_debug_tools_pgraph_pusher_coverage_snapshot(
    XemuDebugToolsPgraphCoverageEvent *events, size_t capacity,
    uint64_t *skipped_slots);

typedef enum XemuDebugToolsPgraphPusherProgressEventType {
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_DMA_PUT = 1,
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PFIFO_RUN = 2,
    XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_SEMAPHORE_RELEASE = 3,
} XemuDebugToolsPgraphPusherProgressEventType;

typedef struct XemuDebugToolsPgraphPusherProgressEvent {
    uint64_t sequence;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t virtual_start_ns;
    uint64_t virtual_end_ns;
    uint64_t duration_ns;
    uint64_t dma_put_to_event_ns;

    uint64_t guest_pc;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t guest_pc_valid;
    uint32_t event_type;
    uint32_t channel_id;

    uint32_t dma_get_before;
    uint32_t dma_get_after;
    uint32_t dma_put_before;
    uint32_t dma_put_after;
    uint32_t method_words_processed;

    uint32_t dma_instance;
    uint32_t semaphore_offset;
    uint32_t semaphore_phys;
    uint32_t semaphore_guest_va;
    uint32_t semaphore_old_value;
    uint32_t semaphore_new_value;
    uint32_t semaphore_target_valid;

    uint32_t waiting_for_nop;
    uint32_t waiting_for_flip;
    uint32_t fifo_access;
} XemuDebugToolsPgraphPusherProgressEvent;

typedef struct XemuDebugToolsPgraphPusherProgressStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t dma_put_events;
    uint64_t pfifo_run_events;
    uint64_t semaphore_release_events;
    uint64_t worst_pfifo_run_ns;
    uint64_t worst_semaphore_release_ns;
    uint64_t worst_dma_put_to_semaphore_ns;
    uint64_t last_dma_put_to_semaphore_ns;
    uint32_t last_dma_get;
    uint32_t last_dma_put;
    uint32_t last_semaphore_phys;
    uint32_t last_semaphore_guest_va;
    uint32_t last_semaphore_value;
    uint32_t last_semaphore_target_valid;
} XemuDebugToolsPgraphPusherProgressStatus;

void xemu_debug_tools_pgraph_pusher_progress_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_pusher_progress_trace_clear(void);
int xemu_debug_tools_pgraph_pusher_progress_trace_set_buffer_multiplier(
    uint32_t multiplier);
uint32_t xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity(void);
void xemu_debug_tools_pgraph_pusher_progress_trace_get_status(
    XemuDebugToolsPgraphPusherProgressStatus *status);
size_t xemu_debug_tools_pgraph_pusher_progress_trace_snapshot(
    XemuDebugToolsPgraphPusherProgressEvent *events, size_t capacity);

void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear(void);
void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(
    XemuDebugToolsPgraphPusherMethodBreakdownStatus *status);
size_t xemu_debug_tools_pgraph_pusher_method_breakdown_trace_snapshot(
    XemuDebugToolsPgraphPusherMethodBreakdownEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
