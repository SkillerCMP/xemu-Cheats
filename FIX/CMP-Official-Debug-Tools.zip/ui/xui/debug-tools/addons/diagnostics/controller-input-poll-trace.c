/* xemu Debug Tools - Diagnostics-owned controller input-poll stage recorder. */
#include "qemu/osdep.h"
#include "qemu/main-loop.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "controller-input-poll-trace-hook.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsControllerInputPollTraceState {
    QemuMutex lock;
    bool lock_initialized;
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;
    XemuDebugToolsControllerInputPollEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsControllerInputPollTraceState;

typedef struct XemuDebugToolsControllerInputPollTls {
    bool active;
    XemuDebugToolsControllerInputPollEvent event;
} XemuDebugToolsControllerInputPollTls;

static XemuDebugToolsControllerInputPollTraceState controller_input_poll_trace;
static __thread XemuDebugToolsControllerInputPollTls controller_input_poll_tls;

static uint64_t controller_input_poll_clamp_threshold(uint64_t threshold_ns)
{
    return MAX(XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_MIN_THRESHOLD_NS,
               MIN(threshold_ns,
                   XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_MAX_THRESHOLD_NS));
}

static void controller_input_poll_trace_init(void)
{
    if (!controller_input_poll_trace.lock_initialized) {
        qemu_mutex_init(&controller_input_poll_trace.lock);
        controller_input_poll_trace.threshold_ns =
            XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_DEFAULT_THRESHOLD_NS;
        controller_input_poll_trace.lock_initialized = true;
        controller_input_poll_trace.buffer_multiplier = 1;
    }
}

static void controller_input_poll_trace_reset_locked(void)
{
    controller_input_poll_trace.count = 0;
    controller_input_poll_trace.write_index = 0;
    controller_input_poll_trace.total_events = 0;
    controller_input_poll_trace.overwritten_events = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(controller_input_poll_trace.events, XemuDebugToolsControllerInputPollEvent, XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY, controller_input_poll_trace.buffer_multiplier);
}

static uint64_t controller_input_poll_duration(uint64_t start_ns,
                                               uint64_t end_ns)
{
    return end_ns >= start_ns ? end_ns - start_ns : 0;
}

uint64_t xemu_debug_tools_controller_input_poll_trace_threshold_ns(void)
{
    if (!controller_input_poll_trace.lock_initialized ||
        !qatomic_read(&controller_input_poll_trace.enabled)) {
        return 0;
    }
    return qatomic_read(&controller_input_poll_trace.threshold_ns);
}

int xemu_debug_tools_controller_input_poll_trace_begin(int device_index,
                                                       int pid,
                                                       uint32_t endpoint,
                                                       uint32_t requested_length)
{
    const uint64_t threshold_ns =
        xemu_debug_tools_controller_input_poll_trace_threshold_ns();
    XemuDebugToolsControllerInputPollEvent *event;

    if (threshold_ns == 0) {
        controller_input_poll_tls.active = false;
        return 0;
    }

    memset(&controller_input_poll_tls, 0, sizeof(controller_input_poll_tls));
    controller_input_poll_tls.active = true;
    event = &controller_input_poll_tls.event;
    event->threshold_ns = threshold_ns;
    event->device_index = device_index;
    event->pid = pid;
    event->endpoint = endpoint;
    event->requested_length = requested_length;
    event->thread_id = qemu_get_thread_id();
    event->bql_held_before = bql_locked() ? 1 : 0;
    event->virtual_start_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event->host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_REALTIME);
    return 1;
}

int xemu_debug_tools_controller_input_poll_trace_active(void)
{
    return controller_input_poll_tls.active ? 1 : 0;
}

uint64_t xemu_debug_tools_controller_input_poll_trace_stage_begin(void)
{
    if (!controller_input_poll_tls.active) {
        return 0;
    }
    return qemu_clock_get_ns(QEMU_CLOCK_REALTIME);
}

void xemu_debug_tools_controller_input_poll_trace_stage_end(
    uint32_t stage, uint64_t host_start_ns)
{
    XemuDebugToolsControllerInputPollEvent *event;
    uint64_t duration_ns;

    if (!controller_input_poll_tls.active || host_start_ns == 0) {
        return;
    }
    event = &controller_input_poll_tls.event;
    duration_ns = controller_input_poll_duration(
        host_start_ns, qemu_clock_get_ns(QEMU_CLOCK_REALTIME));

    switch (stage) {
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_INTERRUPT_TRACE:
        event->interrupt_trace_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_INPUT:
        event->update_input_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_GET_BOUND:
        event->get_bound_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_CONTROLLER:
        event->update_controller_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_GATE:
        event->update_gate_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_SDL_CONTROLLER_STATE:
        event->sdl_controller_state_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_INPUT_MAPPING:
        event->input_mapping_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_HOST_STATE_TRACE:
        event->host_state_trace_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_XID_STATE_TRACE:
        event->xid_state_trace_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_USB_PACKET_COPY:
        event->usb_packet_copy_ns += duration_ns;
        break;
    case XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_PACKET_COMPLETE_TRACE:
        event->packet_complete_trace_ns += duration_ns;
        break;
    default:
        break;
    }
}

void xemu_debug_tools_controller_input_poll_trace_getter_end(
    uint32_t getter, uint64_t host_start_ns)
{
    XemuDebugToolsControllerInputPollEvent *event;
    uint64_t duration_ns;

    if (!controller_input_poll_tls.active || host_start_ns == 0) {
        return;
    }
    event = &controller_input_poll_tls.event;
    duration_ns = controller_input_poll_duration(
        host_start_ns, qemu_clock_get_ns(QEMU_CLOCK_REALTIME));

    if (getter >= XEMU_DEBUG_TOOLS_INPUT_GETTER_BUTTON_A &&
        getter <= XEMU_DEBUG_TOOLS_INPUT_GETTER_GUIDE) {
        event->sdl_button_getters_ns += duration_ns;
        ++event->button_getter_count;
    } else if (getter >= XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_TRIGGER_LEFT &&
               getter <= XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_RIGHT_Y) {
        event->sdl_axis_getters_ns += duration_ns;
        ++event->axis_getter_count;
    }

    if (duration_ns > event->worst_getter_ns) {
        event->worst_getter_ns = duration_ns;
        event->worst_getter = getter;
    }
}

void xemu_debug_tools_controller_input_poll_trace_set_controller(
    int32_t sdl_joystick_id, uint32_t controller_type, uint32_t connected)
{
    if (!controller_input_poll_tls.active) {
        return;
    }
    controller_input_poll_tls.event.sdl_joystick_id = sdl_joystick_id;
    controller_input_poll_tls.event.controller_type = controller_type;
    controller_input_poll_tls.event.connected = connected;
}

void xemu_debug_tools_controller_input_poll_trace_set_update_result(
    uint32_t update_performed, uint32_t skipped_disconnected,
    uint32_t skipped_interval)
{
    if (!controller_input_poll_tls.active) {
        return;
    }
    controller_input_poll_tls.event.update_performed = update_performed;
    controller_input_poll_tls.event.update_skipped_disconnected =
        skipped_disconnected;
    controller_input_poll_tls.event.update_skipped_interval = skipped_interval;
}

void xemu_debug_tools_controller_input_poll_trace_end(int packet_status,
                                                     uint32_t actual_length)
{
    XemuDebugToolsControllerInputPollEvent event;
    size_t slot;

    if (!controller_input_poll_tls.active) {
        return;
    }

    event = controller_input_poll_tls.event;
    controller_input_poll_tls.active = false;
    event.packet_status = packet_status;
    event.actual_length = actual_length;
    event.host_end_ns = qemu_clock_get_ns(QEMU_CLOCK_REALTIME);
    event.virtual_end_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_duration_ns = controller_input_poll_duration(
        event.host_start_ns, event.host_end_ns);
    event.virtual_duration_ns = event.virtual_end_ns >= event.virtual_start_ns
                                    ? (int64_t)(event.virtual_end_ns -
                                                event.virtual_start_ns)
                                    : 0;
    event.bql_held_after = bql_locked() ? 1 : 0;

    if (event.host_duration_ns < event.threshold_ns ||
        !controller_input_poll_trace.lock_initialized ||
        !qatomic_read(&controller_input_poll_trace.enabled) ||
        event.threshold_ns !=
            qatomic_read(&controller_input_poll_trace.threshold_ns)) {
        return;
    }

    qemu_mutex_lock(&controller_input_poll_trace.lock);
    if (!qatomic_read(&controller_input_poll_trace.enabled) ||
        event.threshold_ns != controller_input_poll_trace.threshold_ns) {
        qemu_mutex_unlock(&controller_input_poll_trace.lock);
        return;
    }

    slot = controller_input_poll_trace.write_index;
    event.sequence = controller_input_poll_trace.total_events++;
    const size_t trace_capacity = xemu_debug_tools_controller_input_poll_trace_get_buffer_capacity();
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(controller_input_poll_trace.events, XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY, slot) = event;
    controller_input_poll_trace.write_index = (slot + 1) % trace_capacity;
    if (controller_input_poll_trace.count < trace_capacity) {
        ++controller_input_poll_trace.count;
    } else {
        ++controller_input_poll_trace.overwritten_events;
    }
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
}

void xemu_debug_tools_controller_input_poll_trace_set_enabled(int enabled)
{
    controller_input_poll_trace_init();
    qemu_mutex_lock(&controller_input_poll_trace.lock);
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(controller_input_poll_trace.events, XemuDebugToolsControllerInputPollEvent, XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY, controller_input_poll_trace.buffer_multiplier, ok); if (!ok) { qemu_mutex_unlock(&controller_input_poll_trace.lock); return; } }
    if (enabled && !qatomic_read(&controller_input_poll_trace.enabled)) {
        controller_input_poll_trace_reset_locked();
    }
    qatomic_set(&controller_input_poll_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
}

void xemu_debug_tools_controller_input_poll_trace_set_threshold_ns(
    uint64_t threshold_ns)
{
    const uint64_t clamped =
        controller_input_poll_clamp_threshold(threshold_ns);

    controller_input_poll_trace_init();
    qemu_mutex_lock(&controller_input_poll_trace.lock);
    if (controller_input_poll_trace.threshold_ns != clamped) {
        qatomic_set(&controller_input_poll_trace.threshold_ns, clamped);
        controller_input_poll_trace_reset_locked();
    }
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
}

int xemu_debug_tools_controller_input_poll_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; controller_input_poll_trace_init(); multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier); qemu_mutex_lock(&controller_input_poll_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(controller_input_poll_trace.events, XemuDebugToolsControllerInputPollEvent, XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY, multiplier, ok);
    if (ok) { controller_input_poll_trace.buffer_multiplier=multiplier; controller_input_poll_trace_reset_locked(); }
    qemu_mutex_unlock(&controller_input_poll_trace.lock); return ok?1:0;
}
uint32_t xemu_debug_tools_controller_input_poll_trace_get_buffer_multiplier(void){ return controller_input_poll_trace.buffer_multiplier?controller_input_poll_trace.buffer_multiplier:1; }
size_t xemu_debug_tools_controller_input_poll_trace_get_buffer_capacity(void){ return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY,xemu_debug_tools_controller_input_poll_trace_get_buffer_multiplier()); }

void xemu_debug_tools_controller_input_poll_trace_clear(void)
{
    controller_input_poll_trace_init();
    qemu_mutex_lock(&controller_input_poll_trace.lock);
    controller_input_poll_trace_reset_locked();
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
}

void xemu_debug_tools_controller_input_poll_trace_get_status(
    XemuDebugToolsControllerInputPollStatus *status)
{
    if (status == NULL) {
        return;
    }
    controller_input_poll_trace_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&controller_input_poll_trace.lock);
    status->enabled = qatomic_read(&controller_input_poll_trace.enabled) ? 1 : 0;
    status->threshold_ns = controller_input_poll_trace.threshold_ns;
    status->count = controller_input_poll_trace.count;
    status->total_events = controller_input_poll_trace.total_events;
    status->overwritten_events = controller_input_poll_trace.overwritten_events;
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
}

size_t xemu_debug_tools_controller_input_poll_trace_snapshot(
    XemuDebugToolsControllerInputPollEvent *events, size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    controller_input_poll_trace_init();
    qemu_mutex_lock(&controller_input_poll_trace.lock);
    to_copy = MIN(capacity, controller_input_poll_trace.count);
    const size_t trace_capacity=xemu_debug_tools_controller_input_poll_trace_get_buffer_capacity();
    oldest = controller_input_poll_trace.count == trace_capacity ? controller_input_poll_trace.write_index : 0;
    if (to_copy < controller_input_poll_trace.count) {
        oldest = (oldest + controller_input_poll_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(controller_input_poll_trace.events, XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY, (oldest+i)%trace_capacity);
    }
    qemu_mutex_unlock(&controller_input_poll_trace.lock);
    return to_copy;
}
