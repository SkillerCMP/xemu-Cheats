/* Info: XID/input emits poll stages; Diagnostics owns timing and storage. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_CAPACITY 128
#define XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_DEFAULT_THRESHOLD_NS 1000000ULL
#define XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_MIN_THRESHOLD_NS 10000ULL
#define XEMU_DEBUG_TOOLS_CONTROLLER_INPUT_POLL_MAX_THRESHOLD_NS 10000000000ULL

typedef enum XemuDebugToolsControllerInputPollStage {
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_NONE = 0,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_INTERRUPT_TRACE = 1,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_INPUT = 2,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_GET_BOUND = 3,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_CONTROLLER = 4,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_UPDATE_GATE = 5,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_SDL_CONTROLLER_STATE = 6,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_INPUT_MAPPING = 7,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_HOST_STATE_TRACE = 8,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_XID_STATE_TRACE = 9,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_USB_PACKET_COPY = 10,
    XEMU_DEBUG_TOOLS_INPUT_POLL_STAGE_PACKET_COMPLETE_TRACE = 11,
} XemuDebugToolsControllerInputPollStage;

typedef enum XemuDebugToolsControllerInputGetter {
    XEMU_DEBUG_TOOLS_INPUT_GETTER_NONE = 0,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_BUTTON_A = 1,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_BUTTON_B = 2,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_BUTTON_X = 3,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_BUTTON_Y = 4,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_DPAD_LEFT = 5,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_DPAD_UP = 6,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_DPAD_RIGHT = 7,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_DPAD_DOWN = 8,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_BACK = 9,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_START = 10,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_LEFT_SHOULDER = 11,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_RIGHT_SHOULDER = 12,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_LEFT_STICK_BUTTON = 13,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_RIGHT_STICK_BUTTON = 14,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_GUIDE = 15,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_TRIGGER_LEFT = 16,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_TRIGGER_RIGHT = 17,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_LEFT_X = 18,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_LEFT_Y = 19,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_RIGHT_X = 20,
    XEMU_DEBUG_TOOLS_INPUT_GETTER_AXIS_RIGHT_Y = 21,
} XemuDebugToolsControllerInputGetter;

typedef struct XemuDebugToolsControllerInputPollEvent {
    uint64_t sequence;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t host_duration_ns;
    uint64_t virtual_start_ns;
    uint64_t virtual_end_ns;
    int64_t virtual_duration_ns;
    uint64_t threshold_ns;

    uint64_t interrupt_trace_ns;
    uint64_t update_input_ns;
    uint64_t get_bound_ns;
    uint64_t update_controller_ns;
    uint64_t update_gate_ns;
    uint64_t sdl_controller_state_ns;
    uint64_t input_mapping_ns;
    uint64_t host_state_trace_ns;
    uint64_t xid_state_trace_ns;
    uint64_t usb_packet_copy_ns;
    uint64_t packet_complete_trace_ns;
    uint64_t sdl_button_getters_ns;
    uint64_t sdl_axis_getters_ns;

    uint64_t worst_getter_ns;
    uint32_t worst_getter;
    uint32_t button_getter_count;
    uint32_t axis_getter_count;

    int32_t device_index;
    int32_t pid;
    uint32_t endpoint;
    uint32_t requested_length;
    int32_t packet_status;
    uint32_t actual_length;
    int32_t sdl_joystick_id;
    uint32_t controller_type;
    uint32_t connected;
    uint32_t update_performed;
    uint32_t update_skipped_disconnected;
    uint32_t update_skipped_interval;
    int32_t thread_id;
    uint32_t bql_held_before;
    uint32_t bql_held_after;
} XemuDebugToolsControllerInputPollEvent;

typedef struct XemuDebugToolsControllerInputPollStatus {
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
} XemuDebugToolsControllerInputPollStatus;

uint64_t xemu_debug_tools_controller_input_poll_trace_threshold_ns(void);
int xemu_debug_tools_controller_input_poll_trace_begin(int device_index,
                                                       int pid,
                                                       uint32_t endpoint,
                                                       uint32_t requested_length);
int xemu_debug_tools_controller_input_poll_trace_active(void);
uint64_t xemu_debug_tools_controller_input_poll_trace_stage_begin(void);
void xemu_debug_tools_controller_input_poll_trace_stage_end(
    uint32_t stage, uint64_t host_start_ns);
void xemu_debug_tools_controller_input_poll_trace_getter_end(
    uint32_t getter, uint64_t host_start_ns);
void xemu_debug_tools_controller_input_poll_trace_set_controller(
    int32_t sdl_joystick_id, uint32_t controller_type, uint32_t connected);
void xemu_debug_tools_controller_input_poll_trace_set_update_result(
    uint32_t update_performed, uint32_t skipped_disconnected,
    uint32_t skipped_interval);
void xemu_debug_tools_controller_input_poll_trace_end(int packet_status,
                                                     uint32_t actual_length);

void xemu_debug_tools_controller_input_poll_trace_set_enabled(int enabled);
void xemu_debug_tools_controller_input_poll_trace_set_threshold_ns(
    uint64_t threshold_ns);
void xemu_debug_tools_controller_input_poll_trace_clear(void);
int xemu_debug_tools_controller_input_poll_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_controller_input_poll_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_controller_input_poll_trace_get_buffer_capacity(void);
void xemu_debug_tools_controller_input_poll_trace_get_status(
    XemuDebugToolsControllerInputPollStatus *status);
size_t xemu_debug_tools_controller_input_poll_trace_snapshot(
    XemuDebugToolsControllerInputPollEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
