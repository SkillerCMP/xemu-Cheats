/* Info: OHCI-side timing/bookkeeping helpers owned by Diagnostics. */
#pragma once

/*
 * This header is for the upstream OHCI device hook only.  Keep it separate
 * from ohci-slow-frame-trace-hook.h so the Debug Tools UI does not inherit
 * QEMU platform/header-order requirements through diagnostics-backend.h.
 */
#include "qemu/timer.h"
#include "ohci-slow-frame-trace-hook.h"

static inline uint64_t ohci_profile_now_ns(void)
{
    return (uint64_t)qemu_clock_get_ns(QEMU_CLOCK_REALTIME);
}

static inline void ohci_profile_add_leaf(
    XemuDebugToolsOhciSlowFrameEvent *profile,
    XemuDebugToolsOhciLeafOperation operation,
    XemuDebugToolsOhciListKind list_kind,
    uint64_t duration_ns,
    uint32_t ed_address,
    uint32_t td_address,
    int direction,
    int pid,
    int packet_status,
    uint32_t function_address,
    uint32_t endpoint,
    uint32_t packet_length)
{
    if (profile == NULL) {
        return;
    }
    if (duration_ns > profile->worst_leaf_ns) {
        profile->worst_leaf_ns = duration_ns;
        profile->worst_leaf_type = operation;
        profile->worst_list_kind = list_kind;
        profile->worst_ed_address = ed_address;
        profile->worst_td_address = td_address;
        profile->worst_direction = direction;
        profile->worst_pid = pid;
        profile->worst_packet_status = packet_status;
        profile->worst_function_address = function_address;
        profile->worst_endpoint = endpoint;
        profile->worst_packet_length = packet_length;
    }
}

static inline void ohci_profile_finish(
    XemuDebugToolsOhciSlowFrameEvent *profile)
{
    if (profile == NULL) {
        return;
    }
    profile->host_end_ns = ohci_profile_now_ns();
    profile->host_duration_ns =
        profile->host_end_ns >= profile->host_start_ns
            ? profile->host_end_ns - profile->host_start_ns
            : 0;
    profile->virtual_end_ns =
        (uint64_t)qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    profile->virtual_duration_ns =
        (int64_t)profile->virtual_end_ns - (int64_t)profile->virtual_start_ns;
    if (profile->host_duration_ns >= profile->threshold_ns) {
        xemu_debug_tools_ohci_slow_frame_trace_record(profile);
    }
}
