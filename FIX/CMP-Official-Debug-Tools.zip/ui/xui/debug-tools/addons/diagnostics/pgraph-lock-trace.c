/* Info: PGRAPH lock tracing is lock-free and retains waits/holds of at least 1 ms. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/timer.h"
#include "qemu/thread.h"
#include "hw/core/cpu.h"
#include "hw/xbox/nv2a/pgraph/pgraph.h"

#include "pgraph-lock-trace.h"
#include "diagnostics-trace-buffer.h"
#include "diagnostics-cpu-context.h"

#define PGRAPH_LOCK_TRACE_NO_OWNER 0

typedef struct XemuDebugToolsPgraphLockTraceSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsPgraphLockTraceEvent event;
} XemuDebugToolsPgraphLockTraceSlot;

typedef struct XemuDebugToolsPgraphLockAttemptTls {
    int active;
    uint64_t attempt_host_ns;
    int32_t thread_id;
    int32_t cpu_index;
    uint64_t guest_pc;
    uint32_t guest_pc_valid;
    int32_t owner_thread_id;
    int32_t owner_cpu_index;
    uint64_t owner_acquire_host_ns;
    uint64_t owner_guest_pc_start;
    uint32_t owner_guest_pc_start_valid;
    const char *owner_acquire_file;
    int32_t owner_acquire_line;
    XemuDebugToolsPgraphLockMethodContext owner_method;
} XemuDebugToolsPgraphLockAttemptTls;

static struct {
    int enabled;
    uint64_t total_events;
    int32_t owner_thread_id;
    int32_t owner_cpu_index;
    uint64_t owner_acquire_host_ns;
    uint64_t owner_guest_pc_start;
    uint32_t owner_guest_pc_start_valid;
    const char *owner_acquire_file;
    int32_t owner_acquire_line;
    uint32_t owner_method_valid;
    uint32_t owner_method_active;
    uint32_t owner_method_subchannel;
    uint32_t owner_method_graphics_class;
    uint32_t owner_method;
    uint32_t owner_method_parameter;
    uint32_t buffer_multiplier;
    XemuDebugToolsPgraphLockTraceSlot *slots[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} pgraph_lock_trace = { .buffer_multiplier = 1 };

static __thread XemuDebugToolsPgraphLockAttemptTls pgraph_lock_attempt_tls;

static void pgraph_lock_trace_copy_file(
    char dst[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX], const char *src)
{
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    g_strlcpy(dst, src, XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX);
}

static void pgraph_lock_trace_copy_renderer(
    char dst[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_RENDERER_MAX], const char *src)
{
    if (src == NULL || src[0] == '\0') {
        g_strlcpy(dst, "<unknown>",
                  XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_RENDERER_MAX);
        return;
    }
    g_strlcpy(dst, src, XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_RENDERER_MAX);
}

static XemuDebugToolsPgraphLockMethodContext pgraph_lock_trace_owner_method(void)
{
    XemuDebugToolsPgraphLockMethodContext method = { 0 };

    method.valid = qatomic_read(&pgraph_lock_trace.owner_method_valid);
    method.active = qatomic_read(&pgraph_lock_trace.owner_method_active);
    method.subchannel = qatomic_read(&pgraph_lock_trace.owner_method_subchannel);
    method.graphics_class =
        qatomic_read(&pgraph_lock_trace.owner_method_graphics_class);
    method.method = qatomic_read(&pgraph_lock_trace.owner_method);
    method.parameter = qatomic_read(&pgraph_lock_trace.owner_method_parameter);
    return method;
}

static void pgraph_lock_trace_capture_state(
    const PGRAPHState *pg, XemuDebugToolsPgraphLockStateContext *state)
{
    memset(state, 0, sizeof(*state));
    if (pg == NULL) {
        pgraph_lock_trace_copy_renderer(state->renderer, "<null>");
        return;
    }

    state->pending_interrupts = qatomic_read(&pg->pending_interrupts);
    state->enabled_interrupts = qatomic_read(&pg->enabled_interrupts);
    state->primitive_mode = pg->primitive_mode;
    state->waiting_for_nop = pg->waiting_for_nop ? 1u : 0u;
    state->waiting_for_flip = pg->waiting_for_flip ? 1u : 0u;
    state->waiting_for_context_switch =
        pg->waiting_for_context_switch ? 1u : 0u;
    state->flush_pending = pg->flush_pending ? 1u : 0u;
    state->sync_pending = pg->sync_pending ? 1u : 0u;
    pgraph_lock_trace_copy_renderer(
        state->renderer, pg->renderer != NULL ? pg->renderer->name : NULL);
}

static void pgraph_lock_trace_append(XemuDebugToolsPgraphLockTraceEvent *event)
{
    uint64_t sequence;
    XemuDebugToolsPgraphLockTraceSlot *slot;

    sequence = qatomic_fetch_inc(&pgraph_lock_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity();
    slot = &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(pgraph_lock_trace.slots,XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY,sequence % trace_capacity);
    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}

void xemu_debug_tools_pgraph_lock_trace_lock_attempt(const void *pgraph_state,
                                                      const char *file,
                                                      int line)
{
    XemuDebugToolsPgraphLockAttemptTls *tls = &pgraph_lock_attempt_tls;
    uint64_t now;
    uint64_t owner_acquire;

    (void)pgraph_state;
    (void)file;
    (void)line;
    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        tls->active = 0;
        return;
    }
    memset(tls, 0, sizeof(*tls));

    tls->active = 1;
    tls->thread_id = qemu_get_thread_id();
    tls->attempt_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    xemu_debug_tools_diagnostics_current_cpu_context(
        &tls->cpu_index, &tls->guest_pc, &tls->guest_pc_valid);

    tls->owner_thread_id = qatomic_read(&pgraph_lock_trace.owner_thread_id);
    tls->owner_cpu_index = qatomic_read(&pgraph_lock_trace.owner_cpu_index);
    tls->owner_acquire_host_ns =
        qatomic_read(&pgraph_lock_trace.owner_acquire_host_ns);
    tls->owner_guest_pc_start =
        qatomic_read(&pgraph_lock_trace.owner_guest_pc_start);
    tls->owner_guest_pc_start_valid =
        qatomic_read(&pgraph_lock_trace.owner_guest_pc_start_valid);
    tls->owner_acquire_file =
        qatomic_read(&pgraph_lock_trace.owner_acquire_file);
    tls->owner_acquire_line =
        qatomic_read(&pgraph_lock_trace.owner_acquire_line);
    tls->owner_method = pgraph_lock_trace_owner_method();

    now = tls->attempt_host_ns;
    owner_acquire = tls->owner_acquire_host_ns;
    if (owner_acquire > now) {
        tls->owner_acquire_host_ns = 0;
    }
}

void xemu_debug_tools_pgraph_lock_trace_lock_acquired(const void *pgraph_state,
                                                       const char *file,
                                                       int line)
{
    XemuDebugToolsPgraphLockAttemptTls *tls = &pgraph_lock_attempt_tls;
    XemuDebugToolsPgraphLockTraceEvent event = { 0 };
    uint64_t now;
    uint64_t wait_ns = 0;
    int32_t cpu_index;
    uint64_t guest_pc;
    uint32_t guest_pc_valid;
    int32_t tid;

    (void)pgraph_state;
    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        tls->active = 0;
        return;
    }
    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    tid = qemu_get_thread_id();
    if (tls->active && now >= tls->attempt_host_ns) {
        wait_ns = now - tls->attempt_host_ns;
    }

    if (tls->active &&
        wait_ns >= XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS) {
        event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
        event.host_ns = now;
        event.wait_ns = wait_ns;
        event.thread_id = tls->thread_id;
        event.cpu_index = tls->cpu_index;
        event.guest_pc_start = tls->guest_pc;
        event.guest_pc_start_valid = tls->guest_pc_valid;
        event.owner_thread_id = tls->owner_thread_id;
        event.owner_cpu_index = tls->owner_cpu_index;
        event.owner_acquire_host_ns = tls->owner_acquire_host_ns;
        event.owner_guest_pc_start = tls->owner_guest_pc_start;
        event.owner_guest_pc_start_valid = tls->owner_guest_pc_start_valid;
        event.owner_method = tls->owner_method;
        if (tls->owner_acquire_host_ns != 0 &&
            tls->attempt_host_ns >= tls->owner_acquire_host_ns) {
            event.owner_held_at_attempt_ns =
                tls->attempt_host_ns - tls->owner_acquire_host_ns;
        }
        event.acquire_line = line;
        event.owner_acquire_line = tls->owner_acquire_line;
        event.event_type = XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_WAIT;
        pgraph_lock_trace_copy_file(event.acquire_file, file);
        pgraph_lock_trace_copy_file(event.owner_acquire_file,
                                    tls->owner_acquire_file);
        pgraph_lock_trace_append(&event);
    }

    xemu_debug_tools_diagnostics_current_cpu_context(
        &cpu_index, &guest_pc, &guest_pc_valid);
    qatomic_set(&pgraph_lock_trace.owner_cpu_index, cpu_index);
    qatomic_set(&pgraph_lock_trace.owner_acquire_host_ns, now);
    qatomic_set(&pgraph_lock_trace.owner_guest_pc_start, guest_pc);
    qatomic_set(&pgraph_lock_trace.owner_guest_pc_start_valid, guest_pc_valid);
    qatomic_set(&pgraph_lock_trace.owner_acquire_file, file);
    qatomic_set(&pgraph_lock_trace.owner_acquire_line, line);
    qatomic_set(&pgraph_lock_trace.owner_method_valid, 0);
    qatomic_set(&pgraph_lock_trace.owner_method_active, 0);
    qatomic_set(&pgraph_lock_trace.owner_method_subchannel, 0);
    qatomic_set(&pgraph_lock_trace.owner_method_graphics_class, 0);
    qatomic_set(&pgraph_lock_trace.owner_method, 0);
    qatomic_set(&pgraph_lock_trace.owner_method_parameter, 0);
    smp_wmb();
    qatomic_set(&pgraph_lock_trace.owner_thread_id, tid);
    memset(tls, 0, sizeof(*tls));
}

void xemu_debug_tools_pgraph_lock_trace_unlock_begin(const void *pgraph_state,
                                                      const char *file,
                                                      int line)
{
    XemuDebugToolsPgraphLockTraceEvent event = { 0 };
    const PGRAPHState *pg = (const PGRAPHState *)pgraph_state;
    int32_t tid;
    int32_t owner_tid;
    uint64_t acquired;
    uint64_t now;
    uint64_t held_ns;
    int32_t cpu_index;
    uint64_t guest_pc_end;
    uint32_t guest_pc_end_valid;

    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        return;
    }

    tid = qemu_get_thread_id();
    owner_tid = qatomic_read(&pgraph_lock_trace.owner_thread_id);
    if (owner_tid != tid) {
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    acquired = qatomic_read(&pgraph_lock_trace.owner_acquire_host_ns);
    if (acquired == 0 || now < acquired) {
        return;
    }
    held_ns = now - acquired;
    if (held_ns < XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS) {
        return;
    }

    xemu_debug_tools_diagnostics_current_cpu_context(
        &cpu_index, &guest_pc_end, &guest_pc_end_valid);
    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = now;
    event.held_ns = held_ns;
    event.owner_acquire_host_ns = acquired;
    event.thread_id = tid;
    event.cpu_index = cpu_index;
    event.guest_pc_start = qatomic_read(&pgraph_lock_trace.owner_guest_pc_start);
    event.guest_pc_start_valid =
        qatomic_read(&pgraph_lock_trace.owner_guest_pc_start_valid);
    event.guest_pc_end = guest_pc_end;
    event.guest_pc_end_valid = guest_pc_end_valid;
    event.acquire_line = qatomic_read(&pgraph_lock_trace.owner_acquire_line);
    event.release_line = line;
    event.event_type = XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_HOLD;
    event.method = pgraph_lock_trace_owner_method();
    pgraph_lock_trace_capture_state(pg, &event.state);
    pgraph_lock_trace_copy_file(
        event.acquire_file, qatomic_read(&pgraph_lock_trace.owner_acquire_file));
    pgraph_lock_trace_copy_file(event.release_file, file);
    pgraph_lock_trace_append(&event);
}

void xemu_debug_tools_pgraph_lock_trace_unlock_end(const void *pgraph_state)
{
    int32_t tid;

    (void)pgraph_state;
    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        return;
    }
    tid = qemu_get_thread_id();
    if (qatomic_cmpxchg(&pgraph_lock_trace.owner_thread_id, tid,
                        PGRAPH_LOCK_TRACE_NO_OWNER) == tid) {
        qatomic_set(&pgraph_lock_trace.owner_cpu_index, -1);
        qatomic_set(&pgraph_lock_trace.owner_acquire_host_ns, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_acquire_file, NULL);
        qatomic_set(&pgraph_lock_trace.owner_acquire_line, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_active, 0);
    }
}

void xemu_debug_tools_pgraph_lock_trace_method_enter(unsigned int subchannel,
                                                      unsigned int graphics_class,
                                                      unsigned int method,
                                                      uint32_t parameter)
{
    int32_t tid;

    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        return;
    }
    tid = qemu_get_thread_id();
    if (qatomic_read(&pgraph_lock_trace.owner_thread_id) != tid) {
        return;
    }
    qatomic_set(&pgraph_lock_trace.owner_method_subchannel, subchannel);
    qatomic_set(&pgraph_lock_trace.owner_method_graphics_class, graphics_class);
    qatomic_set(&pgraph_lock_trace.owner_method, method);
    qatomic_set(&pgraph_lock_trace.owner_method_parameter, parameter);
    qatomic_set(&pgraph_lock_trace.owner_method_valid, 1);
    qatomic_set(&pgraph_lock_trace.owner_method_active, 1);
}

void xemu_debug_tools_pgraph_lock_trace_method_exit(void)
{
    int32_t tid;

    if (!qatomic_read(&pgraph_lock_trace.enabled)) {
        return;
    }
    tid = qemu_get_thread_id();
    if (qatomic_read(&pgraph_lock_trace.owner_thread_id) == tid) {
        qatomic_set(&pgraph_lock_trace.owner_method_active, 0);
    }
}

void xemu_debug_tools_pgraph_lock_trace_set_enabled(int enabled)
{
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(pgraph_lock_trace.slots,XemuDebugToolsPgraphLockTraceSlot,XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY,xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier(),ok); if(!ok) return; }
    if (enabled) {
        xemu_debug_tools_pgraph_lock_trace_clear();
        qatomic_set(&pgraph_lock_trace.owner_thread_id,
                    PGRAPH_LOCK_TRACE_NO_OWNER);
        qatomic_set(&pgraph_lock_trace.owner_cpu_index, -1);
        qatomic_set(&pgraph_lock_trace.owner_acquire_host_ns, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_acquire_file, NULL);
        qatomic_set(&pgraph_lock_trace.owner_acquire_line, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_active, 0);
        qatomic_set(&pgraph_lock_trace.enabled, 1);
    } else {
        qatomic_set(&pgraph_lock_trace.enabled, 0);
        qatomic_set(&pgraph_lock_trace.owner_thread_id,
                    PGRAPH_LOCK_TRACE_NO_OWNER);
        qatomic_set(&pgraph_lock_trace.owner_cpu_index, -1);
        qatomic_set(&pgraph_lock_trace.owner_acquire_host_ns, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start, 0);
        qatomic_set(&pgraph_lock_trace.owner_guest_pc_start_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_acquire_file, NULL);
        qatomic_set(&pgraph_lock_trace.owner_acquire_line, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_valid, 0);
        qatomic_set(&pgraph_lock_trace.owner_method_active, 0);
    }
}

int xemu_debug_tools_pgraph_lock_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(pgraph_lock_trace.slots,XemuDebugToolsPgraphLockTraceSlot,XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY,multiplier,ok); if(!ok) return 0;
    qatomic_set(&pgraph_lock_trace.buffer_multiplier,multiplier); xemu_debug_tools_pgraph_lock_trace_clear(); return 1;
}
uint32_t xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier(void){uint32_t m=qatomic_read(&pgraph_lock_trace.buffer_multiplier);return m?m:1;}
size_t xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity(void){return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY,xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier());}

void xemu_debug_tools_pgraph_lock_trace_clear(void)
{
    qatomic_set(&pgraph_lock_trace.total_events, 0);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(pgraph_lock_trace.slots, XemuDebugToolsPgraphLockTraceSlot, XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY, xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier());
}

void xemu_debug_tools_pgraph_lock_trace_get_status(
    XemuDebugToolsPgraphLockTraceStatus *status)
{
    uint64_t total;
    uint64_t now;
    uint64_t acquired;

    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    status->current_owner_cpu_index = -1;
    status->enabled = qatomic_read(&pgraph_lock_trace.enabled) ? 1 : 0;
    total = qatomic_read(&pgraph_lock_trace.total_events);
    status->total_events = total;
    status->count =
        MIN(total, (uint64_t)xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity());
    status->overwritten_events =
        total > xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity()
            ? total - xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity()
            : 0;
    status->long_wait_threshold_ns = XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS;
    status->current_owner_thread_id =
        qatomic_read(&pgraph_lock_trace.owner_thread_id);
    status->current_owner_cpu_index =
        status->current_owner_thread_id != PGRAPH_LOCK_TRACE_NO_OWNER
            ? qatomic_read(&pgraph_lock_trace.owner_cpu_index)
            : -1;
    status->current_owner_guest_pc =
        qatomic_read(&pgraph_lock_trace.owner_guest_pc_start);
    status->current_owner_guest_pc_valid =
        qatomic_read(&pgraph_lock_trace.owner_guest_pc_start_valid);
    status->current_owner_acquire_line =
        qatomic_read(&pgraph_lock_trace.owner_acquire_line);
    status->current_owner_method = pgraph_lock_trace_owner_method();
    pgraph_lock_trace_copy_file(
        status->current_owner_acquire_file,
        qatomic_read(&pgraph_lock_trace.owner_acquire_file));
    acquired = qatomic_read(&pgraph_lock_trace.owner_acquire_host_ns);
    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (status->current_owner_thread_id != PGRAPH_LOCK_TRACE_NO_OWNER &&
        acquired != 0 && now >= acquired) {
        status->current_owner_held_ns = now - acquired;
    }
}

size_t xemu_debug_tools_pgraph_lock_trace_snapshot(
    XemuDebugToolsPgraphLockTraceEvent *events, size_t capacity)
{
    uint64_t total;
    uint64_t available;
    uint64_t first;
    size_t copied = 0;
    uint64_t sequence;

    if (events == NULL || capacity == 0) {
        return 0;
    }

    total = qatomic_read(&pgraph_lock_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity();
    available = MIN(total, (uint64_t)trace_capacity);
    first = available > capacity ? total - capacity : total - available;

    for (sequence = first; sequence < total && copied < capacity; ++sequence) {
        XemuDebugToolsPgraphLockTraceSlot *slot =
            &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(pgraph_lock_trace.slots,XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY,sequence % trace_capacity);
        uint64_t commit_before =
            qatomic_read(&slot->committed_sequence_plus_one);
        XemuDebugToolsPgraphLockTraceEvent event;
        uint64_t commit_after;

        if (commit_before != sequence + 1) {
            continue;
        }
        smp_rmb();
        event = slot->event;
        smp_rmb();
        commit_after = qatomic_read(&slot->committed_sequence_plus_one);
        if (commit_after != commit_before || event.sequence != sequence) {
            continue;
        }
        events[copied++] = event;
    }
    return copied;
}
