/* Info: BQL and main-loop lock tracers share one observation-only recorder core. */
#pragma once

#include "bql-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS (1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX 96

typedef enum XemuDebugToolsLockTraceEventType {
    XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_WAIT = 1,
    XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_HOLD,
} XemuDebugToolsLockTraceEventType;

typedef struct XemuDebugToolsLockTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t wait_ns;
    uint64_t held_ns;
    uint64_t owner_held_at_attempt_ns;
    uint64_t owner_acquire_host_ns;
    uint64_t owner_stage_elapsed_at_attempt_ns;
    uint64_t longest_stage_ns;
    uint64_t guest_pc_start;
    uint64_t guest_pc_end;
    uint64_t owner_guest_pc_start;
    int32_t thread_id;
    int32_t owner_thread_id;
    int32_t cpu_index;
    int32_t owner_cpu_index;
    int32_t caller_line;
    int32_t owner_caller_line;
    uint32_t guest_pc_start_valid;
    uint32_t guest_pc_end_valid;
    uint32_t owner_guest_pc_start_valid;
    uint32_t event_type;
    uint32_t caller_context;
    uint32_t owner_context;
    uint32_t owner_stage_at_attempt;
    uint32_t longest_stage;
    char caller_file[XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX];
    char owner_caller_file[XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX];
} XemuDebugToolsLockTraceEvent;

typedef struct XemuDebugToolsLockTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t long_wait_threshold_ns;
    int32_t current_owner_thread_id;
    int32_t current_owner_cpu_index;
    uint64_t current_owner_held_ns;
    uint64_t current_owner_guest_pc;
    uint32_t current_owner_guest_pc_valid;
    uint32_t current_owner_context;
    uint32_t current_owner_stage;
    uint64_t current_owner_stage_elapsed_ns;
    int32_t current_owner_caller_line;
    char current_owner_caller_file[XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX];
} XemuDebugToolsLockTraceStatus;

typedef enum XemuDebugToolsLockTraceKind {
    XEMU_DEBUG_TOOLS_LOCK_TRACE_BQL = 0,
    XEMU_DEBUG_TOOLS_LOCK_TRACE_MAIN_LOOP,
    XEMU_DEBUG_TOOLS_LOCK_TRACE_COUNT,
} XemuDebugToolsLockTraceKind;

void xemu_debug_tools_lock_trace_core_set_next_context(
    XemuDebugToolsLockTraceKind kind, uint32_t context);
void xemu_debug_tools_lock_trace_core_owner_stage_begin(
    XemuDebugToolsLockTraceKind kind, uint32_t stage);
void xemu_debug_tools_lock_trace_core_owner_stage_end(
    XemuDebugToolsLockTraceKind kind);
void xemu_debug_tools_lock_trace_core_lock_attempt(
    XemuDebugToolsLockTraceKind kind, const char *file, int line);
void xemu_debug_tools_lock_trace_core_lock_acquired(
    XemuDebugToolsLockTraceKind kind, const char *file, int line);
void xemu_debug_tools_lock_trace_core_unlock_begin(
    XemuDebugToolsLockTraceKind kind);
void xemu_debug_tools_lock_trace_core_unlock_end(
    XemuDebugToolsLockTraceKind kind);
void xemu_debug_tools_lock_trace_core_set_enabled(
    XemuDebugToolsLockTraceKind kind, int enabled);
void xemu_debug_tools_lock_trace_core_clear(XemuDebugToolsLockTraceKind kind);
int xemu_debug_tools_lock_trace_core_set_buffer_multiplier(
    XemuDebugToolsLockTraceKind kind, uint32_t multiplier);
uint32_t xemu_debug_tools_lock_trace_core_get_buffer_multiplier(
    XemuDebugToolsLockTraceKind kind);
size_t xemu_debug_tools_lock_trace_core_get_buffer_capacity(
    XemuDebugToolsLockTraceKind kind);
void xemu_debug_tools_lock_trace_core_get_status(
    XemuDebugToolsLockTraceKind kind, XemuDebugToolsLockTraceStatus *status);
size_t xemu_debug_tools_lock_trace_core_snapshot(
    XemuDebugToolsLockTraceKind kind, XemuDebugToolsLockTraceEvent *events,
    size_t capacity);

#ifdef __cplusplus
}
#endif
