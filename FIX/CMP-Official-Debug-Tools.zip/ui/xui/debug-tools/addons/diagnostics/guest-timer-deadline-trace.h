/* Info: Non-breaking TCG correlation trace for guest timer/deadline research. */
#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct CPUState CPUState;

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY 8192
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TSC_HZ 733333333ULL
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET 0x000D7EA0u
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_GRACE_NS (5 * 1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_LINK_MAX_AGE_NS (1000 * 1000ULL)
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PRE_NS (2 * 1000 * 1000ULL)

#define XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_PAGE 0x000D7000u
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_PAGE   0x00216000u
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PAGE 0x00223000u
#define XEMU_DEBUG_TOOLS_GUEST_TIMER_PAGE_MASK  0xFFFFF000u

typedef enum XemuDebugToolsGuestTimerDeadlineEventType {
    XEMU_DEBUG_TOOLS_GUEST_TIMER_EVENT_NONE = 0,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SBB_HIGH,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_RESULT,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_STORE_LOW,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_HIGH,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_LOW_RESULT,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RELATIVE_READY,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE,
} XemuDebugToolsGuestTimerDeadlineEventType;

typedef enum XemuDebugToolsGuestTimerMemoryValidBits {
    XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A80 = 1u << 0,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A84 = 1u << 1,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A90 = 1u << 2,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A94 = 1u << 3,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_14 = 1u << 4,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_18 = 1u << 5,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_20 = 1u << 6,
} XemuDebugToolsGuestTimerMemoryValidBits;

typedef enum XemuDebugToolsGuestTimerDerivedValidBits {
    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_NOMINAL = 1u << 0,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_LATENESS = 1u << 1,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_CALCULATED = 1u << 2,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_DEADLINE = 1u << 3,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_RELATIVE = 1u << 4,
} XemuDebugToolsGuestTimerDerivedValidBits;


typedef enum XemuDebugToolsGuestTimerCallbackFlags {
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_LINKED = 1u << 0,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RESULT_VALID = 1u << 1,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE_LATCHED = 1u << 2,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY_SEEN = 1u << 3,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN_SEEN = 1u << 4,
    XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_NEXT_INPUT_SEEN = 1u << 5,
} XemuDebugToolsGuestTimerCallbackFlags;

typedef struct XemuDebugToolsGuestTimerDeadlineTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t input_sequence;
    uint64_t deadline_sequence;
    uint64_t age_since_input_ns;
    uint32_t event_type;
    uint32_t guest_pc;

    uint32_t eax;
    uint32_t ebx;
    uint32_t ecx;
    uint32_t edx;
    uint32_t esi;
    uint32_t edi;
    uint32_t esp;
    uint32_t ebp;
    uint32_t eflags;

    uint32_t memory_valid_mask;
    uint32_t mem_1a80;
    uint32_t mem_1a84;
    uint32_t mem_1a90;
    uint32_t mem_1a94;
    uint32_t stack_14;
    uint32_t stack_18;
    uint32_t stack_20;

    uint32_t derived_valid_mask;
    uint64_t nominal_interval;
    uint64_t accumulated_lateness;
    uint64_t calculated_interval;
    uint64_t current_tsc;
    uint64_t requested_deadline;
    uint64_t deadline_threshold;
    int64_t deadline_delta_cycles;
    uint64_t relative_delay;

    uint64_t callback_expected_due_ns;
    int64_t callback_delta_ns;
    uint32_t callback_target;
    uint32_t callback_return_pc;
    uint32_t schedule_result_eax;
    uint32_t callback_flags;
} XemuDebugToolsGuestTimerDeadlineTraceEvent;

typedef struct XemuDebugToolsGuestTimerDeadlineTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t input_sequences;
    uint64_t deadline_sequences;
    uint64_t deadline_rejects;
    uint64_t deadline_valid;
    int64_t last_deadline_delta_cycles;
    int64_t worst_late_delta_cycles;
    uint64_t last_input_virtual_ns;

    uint64_t callback_schedule_attempts;
    uint64_t callback_schedule_returns;
    uint64_t callback_entries;
    uint64_t callback_returns;
    uint64_t callback_overdue_events;
    uint64_t callback_next_input_entries;
    uint64_t dispatcher_attempts;
    uint64_t dispatcher_pc_events;
    uint64_t dispatcher_successful_attempts;
    uint64_t dispatcher_overdue_attempts;
    uint64_t dispatcher_recovered_overdue_attempts;
    uint64_t dispatcher_current_pc_events;
    uint64_t dispatcher_last_good_pc_events;
    uint64_t dispatcher_last_overdue_pc_events;
    uint64_t dispatcher_last_recovered_pc_events;
    int callback_watch_armed;
    int callback_overdue_latched;
    uint64_t callback_watch_input_sequence;
    uint64_t callback_schedule_virtual_ns;
    uint64_t callback_expected_due_ns;
    uint64_t callback_relative_delay_cycles;
    int64_t callback_last_delta_ns;
    uint32_t callback_target;
    uint32_t callback_return_pc;
    uint32_t callback_schedule_result_eax;
    int callback_schedule_result_valid;

    uint32_t buffer_multiplier;
} XemuDebugToolsGuestTimerDeadlineTraceStatus;

int xemu_debug_tools_guest_timer_deadline_trace_active(void);
int xemu_debug_tools_guest_timer_deadline_trace_should_single_step(uint32_t guest_pc);
void xemu_debug_tools_guest_timer_deadline_trace_note_pc(CPUState *cpu,
                                                          uint32_t guest_pc);
void xemu_debug_tools_guest_timer_deadline_trace_set_enabled(int enabled);
void xemu_debug_tools_guest_timer_deadline_trace_clear(void);
int xemu_debug_tools_guest_timer_deadline_trace_set_buffer_multiplier(
    uint32_t multiplier);
uint32_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_capacity(void);
void xemu_debug_tools_guest_timer_deadline_trace_get_status(
    XemuDebugToolsGuestTimerDeadlineTraceStatus *status);
size_t xemu_debug_tools_guest_timer_deadline_trace_snapshot(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
