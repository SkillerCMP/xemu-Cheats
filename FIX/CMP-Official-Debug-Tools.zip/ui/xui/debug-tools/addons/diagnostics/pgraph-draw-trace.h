/* xemu Debug Tools - Diagnostics-owned PGRAPH draw-end stage trace. */
#pragma once

#include "pgraph-draw-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS (5 * 1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_RENDERER_MAX 32

typedef enum XemuDebugToolsPgraphDrawTracePath {
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_UNKNOWN = 0,
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_DRAW_ARRAYS,
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_ELEMENTS,
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_BUFFER,
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_ARRAY,
    XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_EMPTY,
} XemuDebugToolsPgraphDrawTracePath;

typedef struct XemuDebugToolsPgraphDrawTraceEvent {
    uint64_t sequence;
    uint64_t draw_id;
    uint64_t qemu_virtual_start_ns;
    uint64_t qemu_virtual_end_ns;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t duration_host_ns;
    uint64_t duration_virtual_ns;
    uint64_t value0;
    uint64_t value1;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t stage;
    uint32_t path;
    uint32_t primitive_mode;
    uint32_t draw_arrays_length;
    uint32_t draw_arrays_max_count;
    uint32_t inline_elements_length;
    uint32_t inline_buffer_length;
    uint32_t inline_array_length;
    uint32_t zpass_pixel_count_enable;
    uint32_t flush_pending;
    uint32_t sync_pending;
    char renderer[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_RENDERER_MAX];
} XemuDebugToolsPgraphDrawTraceEvent;

typedef struct XemuDebugToolsPgraphDrawTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t retained_draws;
    uint64_t truncated_draws; /* Some child stages exceeded the bounded detail pool. */
    uint64_t long_draw_threshold_ns;
} XemuDebugToolsPgraphDrawTraceStatus;

void xemu_debug_tools_pgraph_draw_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_draw_trace_clear(void);
int xemu_debug_tools_pgraph_draw_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity(void);
void xemu_debug_tools_pgraph_draw_trace_get_status(
    XemuDebugToolsPgraphDrawTraceStatus *status);
size_t xemu_debug_tools_pgraph_draw_trace_snapshot(
    XemuDebugToolsPgraphDrawTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
