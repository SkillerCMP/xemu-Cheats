#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "pgraph-flip-delay-trace.h"
#include "diagnostics-trace-buffer.h"

enum {
    XEMU_PGRAPH_FLIP_DELAY_GATE_NONE = 0,
    XEMU_PGRAPH_FLIP_DELAY_GATE_PFIFO = 1,
    XEMU_PGRAPH_FLIP_DELAY_GATE_RENDERER = 2,
};

#define XEMU_PGRAPH_FLIP_DELAY_PC_TRACKED_CAPACITY 128

typedef struct XemuDebugToolsPgraphFlipDelayPcBucket {
    uint32_t pc;
    uint32_t hits;
} XemuDebugToolsPgraphFlipDelayPcBucket;

typedef struct XemuDebugToolsPgraphFlipDelayTls {
    int gate_active;
    uint32_t gate_source;
    uint32_t gate_renderer_kind;
    uint64_t gate_host_ns;
    uint32_t gate_method;
    uint32_t gate_parameter;
    int lock_attempt_active;
    uint64_t lock_attempt_host_ns;
    uint64_t pc_last_sample_host_ns;
} XemuDebugToolsPgraphFlipDelayTls;

typedef struct XemuDebugToolsPgraphFlipDelayRing {
    QemuMutex lock;
    bool initialized;
    int enabled;
    uint64_t threshold_ns;
    uint32_t buffer_multiplier;
    size_t count;
    size_t write_index;
    uint64_t total_frames_seen;
    uint64_t captured_long_frames;
    uint64_t overwritten_events;
    uint64_t last_frame_ns;
    uint64_t worst_frame_ns;
    uint64_t worst_stall_total_ns;
    uint64_t worst_post_release_ns;
    uint64_t worst_cpu_mmio_gate_wait_ns;
    uint64_t worst_pfifo_cpu_mmio_gate_wait_ns;
    uint64_t worst_renderer_cpu_mmio_gate_wait_ns;
    uint64_t worst_pgraph_lock_wait_ns;
    uint64_t worst_renderer_finish_ns;
    uint64_t guest_pc_samples;
    uint64_t guest_pc_untracked_samples;

    bool active_frame;
    XemuDebugToolsPgraphFlipDelayEvent current;
    uint64_t waiting_set_host_ns;
    uint64_t vblank_read_host_ns;
    uint64_t release_host_ns;
    bool waiting_set_valid;
    bool vblank_read_valid;
    bool release_valid;

    int pc_capture_active;
    uint64_t pc_sample_start_host_ns;
    uint32_t pc_bucket_count;
    uint32_t pc_untracked_samples;
    XemuDebugToolsPgraphFlipDelayPcBucket
        pc_buckets[XEMU_PGRAPH_FLIP_DELAY_PC_TRACKED_CAPACITY];

    uint64_t last_flip_increment_host_ns;
    bool last_flip_increment_valid;

    XemuDebugToolsPgraphFlipDelayEvent *events[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsPgraphFlipDelayRing;

static XemuDebugToolsPgraphFlipDelayRing g_flip_delay;
static __thread XemuDebugToolsPgraphFlipDelayTls g_flip_delay_tls;

static uint64_t elapsed_ns(uint64_t end, uint64_t start)
{
    return end >= start ? end - start : 0;
}

static void flip_delay_init(void)
{
    if (!g_flip_delay.initialized) {
        qemu_mutex_init(&g_flip_delay.lock);
        g_flip_delay.threshold_ns =
            XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_DEFAULT_THRESHOLD_NS;
        g_flip_delay.buffer_multiplier = 1;
        g_flip_delay.initialized = true;
    }
}

static void flip_delay_reset_locked(void)
{
    g_flip_delay.count = 0;
    g_flip_delay.write_index = 0;
    g_flip_delay.total_frames_seen = 0;
    g_flip_delay.captured_long_frames = 0;
    g_flip_delay.overwritten_events = 0;
    g_flip_delay.last_frame_ns = 0;
    g_flip_delay.worst_frame_ns = 0;
    g_flip_delay.worst_stall_total_ns = 0;
    g_flip_delay.worst_post_release_ns = 0;
    g_flip_delay.worst_cpu_mmio_gate_wait_ns = 0;
    g_flip_delay.worst_pfifo_cpu_mmio_gate_wait_ns = 0;
    g_flip_delay.worst_renderer_cpu_mmio_gate_wait_ns = 0;
    g_flip_delay.worst_pgraph_lock_wait_ns = 0;
    g_flip_delay.worst_renderer_finish_ns = 0;
    g_flip_delay.guest_pc_samples = 0;
    g_flip_delay.guest_pc_untracked_samples = 0;
    g_flip_delay.active_frame = false;
    memset(&g_flip_delay.current, 0, sizeof(g_flip_delay.current));
    g_flip_delay.waiting_set_host_ns = 0;
    g_flip_delay.vblank_read_host_ns = 0;
    g_flip_delay.release_host_ns = 0;
    g_flip_delay.waiting_set_valid = false;
    g_flip_delay.vblank_read_valid = false;
    g_flip_delay.release_valid = false;
    qatomic_set(&g_flip_delay.pc_capture_active, 0);
    qatomic_set_u64(&g_flip_delay.pc_sample_start_host_ns, 0);
    g_flip_delay.pc_bucket_count = 0;
    g_flip_delay.pc_untracked_samples = 0;
    memset(g_flip_delay.pc_buckets, 0, sizeof(g_flip_delay.pc_buckets));
    g_flip_delay.last_flip_increment_host_ns = 0;
    g_flip_delay.last_flip_increment_valid = false;
    memset(&g_flip_delay_tls, 0, sizeof(g_flip_delay_tls));
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_flip_delay.events, XemuDebugToolsPgraphFlipDelayEvent,
        XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY,
        g_flip_delay.buffer_multiplier);
}

static void flip_delay_store_locked(XemuDebugToolsPgraphFlipDelayEvent *event)
{
    size_t cap = xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_capacity();
    size_t slot = g_flip_delay.write_index;

    event->sequence = g_flip_delay.captured_long_frames++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_flip_delay.events, XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY,
        slot) = *event;
    g_flip_delay.write_index = (slot + 1) % cap;
    if (g_flip_delay.count < cap) {
        g_flip_delay.count++;
    } else {
        g_flip_delay.overwritten_events++;
    }
}

static void flip_delay_copy_hot_pcs_locked(
    XemuDebugToolsPgraphFlipDelayEvent *event)
{
    bool selected[XEMU_PGRAPH_FLIP_DELAY_PC_TRACKED_CAPACITY] = { false };

    event->post_release_pc_tracked_unique = g_flip_delay.pc_bucket_count;
    event->post_release_pc_untracked_samples = g_flip_delay.pc_untracked_samples;
    for (uint32_t rank = 0;
         rank < XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_HOT_PC_COUNT; ++rank) {
        uint32_t best = UINT32_MAX;
        for (uint32_t i = 0; i < g_flip_delay.pc_bucket_count; ++i) {
            if (selected[i]) {
                continue;
            }
            if (best == UINT32_MAX ||
                g_flip_delay.pc_buckets[i].hits >
                    g_flip_delay.pc_buckets[best].hits) {
                best = i;
            }
        }
        if (best == UINT32_MAX || g_flip_delay.pc_buckets[best].hits == 0) {
            break;
        }
        selected[best] = true;
        event->hot_pc[rank] = g_flip_delay.pc_buckets[best].pc;
        event->hot_pc_hits[rank] = g_flip_delay.pc_buckets[best].hits;
    }
}

static void flip_delay_finalize_locked(uint64_t end_host_ns,
                                       uint64_t end_virtual_ns,
                                       uint32_t end_frame_time)
{
    XemuDebugToolsPgraphFlipDelayEvent event;

    if (!g_flip_delay.active_frame) {
        return;
    }

    qatomic_set(&g_flip_delay.pc_capture_active, 0);
    event = g_flip_delay.current;
    flip_delay_copy_hot_pcs_locked(&event);
    event.end_host_ns = end_host_ns;
    event.end_virtual_ns = end_virtual_ns;
    event.end_frame_time = end_frame_time;
    event.frame_host_ns = elapsed_ns(end_host_ns, event.start_host_ns);
    event.frame_virtual_ns = elapsed_ns(end_virtual_ns, event.start_virtual_ns);

    if (g_flip_delay.release_valid) {
        event.post_release_to_next_stall_ns =
            elapsed_ns(end_host_ns, g_flip_delay.release_host_ns);
        if (g_flip_delay.last_flip_increment_valid &&
            g_flip_delay.last_flip_increment_host_ns >=
                g_flip_delay.release_host_ns &&
            g_flip_delay.last_flip_increment_host_ns <= end_host_ns) {
            event.release_to_flip_increment_ns = elapsed_ns(
                g_flip_delay.last_flip_increment_host_ns,
                g_flip_delay.release_host_ns);
            event.flip_increment_to_next_stall_ns = elapsed_ns(
                end_host_ns, g_flip_delay.last_flip_increment_host_ns);
        }
    }

    g_flip_delay.total_frames_seen++;
    g_flip_delay.last_frame_ns = event.frame_host_ns;
    g_flip_delay.worst_frame_ns = MAX(g_flip_delay.worst_frame_ns,
                                      event.frame_host_ns);
    g_flip_delay.worst_stall_total_ns = MAX(
        g_flip_delay.worst_stall_total_ns, event.stall_total_ns);
    g_flip_delay.worst_post_release_ns = MAX(
        g_flip_delay.worst_post_release_ns,
        event.post_release_to_next_stall_ns);
    g_flip_delay.worst_cpu_mmio_gate_wait_ns = MAX(
        g_flip_delay.worst_cpu_mmio_gate_wait_ns,
        event.cpu_mmio_gate_wait_max_ns);
    g_flip_delay.worst_pfifo_cpu_mmio_gate_wait_ns = MAX(
        g_flip_delay.worst_pfifo_cpu_mmio_gate_wait_ns,
        event.pfifo_cpu_mmio_gate_wait_max_ns);
    g_flip_delay.worst_renderer_cpu_mmio_gate_wait_ns = MAX(
        g_flip_delay.worst_renderer_cpu_mmio_gate_wait_ns,
        event.renderer_cpu_mmio_gate_wait_max_ns);
    g_flip_delay.worst_pgraph_lock_wait_ns = MAX(
        g_flip_delay.worst_pgraph_lock_wait_ns,
        event.pgraph_lock_wait_max_ns);
    g_flip_delay.worst_renderer_finish_ns = MAX(
        g_flip_delay.worst_renderer_finish_ns,
        event.renderer_finish_max_ns);

    if (event.frame_host_ns >= g_flip_delay.threshold_ns) {
        g_flip_delay.guest_pc_samples += event.post_release_pc_samples;
        g_flip_delay.guest_pc_untracked_samples +=
            event.post_release_pc_untracked_samples;
        flip_delay_store_locked(&event);
    }
}

static void flip_delay_start_locked(const XemuDebugToolsFlipStallTraceEvent *event)
{
    memset(&g_flip_delay.current, 0, sizeof(g_flip_delay.current));
    g_flip_delay.current.start_host_ns = event->host_ns;
    g_flip_delay.current.start_virtual_ns = event->qemu_virtual_ns;
    g_flip_delay.current.start_frame_time = event->frame_time;
    g_flip_delay.current.read_3d = event->read_3d;
    g_flip_delay.current.write_3d = event->write_3d;
    g_flip_delay.current.modulo_3d = event->modulo_3d;
    g_flip_delay.waiting_set_host_ns = 0;
    g_flip_delay.vblank_read_host_ns = 0;
    g_flip_delay.release_host_ns = 0;
    g_flip_delay.waiting_set_valid = false;
    g_flip_delay.vblank_read_valid = false;
    g_flip_delay.release_valid = false;
    qatomic_set(&g_flip_delay.pc_capture_active, 0);
    qatomic_set_u64(&g_flip_delay.pc_sample_start_host_ns, 0);
    g_flip_delay.pc_bucket_count = 0;
    g_flip_delay.pc_untracked_samples = 0;
    memset(g_flip_delay.pc_buckets, 0, sizeof(g_flip_delay.pc_buckets));
    g_flip_delay.active_frame = true;
}

int xemu_debug_tools_pgraph_flip_delay_trace_is_enabled(void)
{
    return g_flip_delay.initialized && qatomic_read(&g_flip_delay.enabled);
}

int xemu_debug_tools_pgraph_flip_delay_guest_pc_sampler_active(void)
{
    return xemu_debug_tools_pgraph_flip_delay_trace_is_enabled() &&
           qatomic_read(&g_flip_delay.pc_capture_active);
}

void xemu_debug_tools_pgraph_flip_delay_note_guest_pc(uint32_t guest_pc)
{
    uint64_t now;
    uint64_t start_ns;
    uint32_t i;

    if (!xemu_debug_tools_pgraph_flip_delay_guest_pc_sampler_active() ||
        guest_pc < 0x00010000u || guest_pc >= 0x80000000u) {
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    start_ns = qatomic_read_u64(&g_flip_delay.pc_sample_start_host_ns);
    if (start_ns == 0 || now < start_ns) {
        return;
    }
    if (g_flip_delay_tls.pc_last_sample_host_ns != 0 &&
        elapsed_ns(now, g_flip_delay_tls.pc_last_sample_host_ns) <
            XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_PC_SAMPLE_INTERVAL_NS) {
        return;
    }
    g_flip_delay_tls.pc_last_sample_host_ns = now;

    qemu_mutex_lock(&g_flip_delay.lock);
    if (!qatomic_read(&g_flip_delay.enabled) ||
        !qatomic_read(&g_flip_delay.pc_capture_active) ||
        !g_flip_delay.active_frame || !g_flip_delay.release_valid ||
        now < qatomic_read_u64(&g_flip_delay.pc_sample_start_host_ns)) {
        qemu_mutex_unlock(&g_flip_delay.lock);
        return;
    }

    g_flip_delay.current.post_release_pc_samples++;
    for (i = 0; i < g_flip_delay.pc_bucket_count; ++i) {
        if (g_flip_delay.pc_buckets[i].pc == guest_pc) {
            g_flip_delay.pc_buckets[i].hits++;
            qemu_mutex_unlock(&g_flip_delay.lock);
            return;
        }
    }

    if (g_flip_delay.pc_bucket_count <
        XEMU_PGRAPH_FLIP_DELAY_PC_TRACKED_CAPACITY) {
        XemuDebugToolsPgraphFlipDelayPcBucket *bucket =
            &g_flip_delay.pc_buckets[g_flip_delay.pc_bucket_count++];
        bucket->pc = guest_pc;
        bucket->hits = 1;
    } else {
        g_flip_delay.pc_untracked_samples++;
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
}

void xemu_debug_tools_pgraph_flip_delay_pfifo_gate_begin(
    const void *pgraph_state, uint32_t method, uint32_t parameter)
{
    (void)pgraph_state;
    if (!xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        g_flip_delay_tls.gate_active = 0;
        return;
    }
    g_flip_delay_tls.gate_active = 1;
    g_flip_delay_tls.gate_source = XEMU_PGRAPH_FLIP_DELAY_GATE_PFIFO;
    g_flip_delay_tls.gate_renderer_kind = 0;
    g_flip_delay_tls.gate_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    g_flip_delay_tls.gate_method = method;
    g_flip_delay_tls.gate_parameter = parameter;
}

void xemu_debug_tools_pgraph_flip_delay_renderer_gate_begin(
    const void *pgraph_state, uint32_t renderer_kind)
{
    (void)pgraph_state;
    if (!xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        g_flip_delay_tls.gate_active = 0;
        return;
    }
    g_flip_delay_tls.gate_active = 1;
    g_flip_delay_tls.gate_source = XEMU_PGRAPH_FLIP_DELAY_GATE_RENDERER;
    g_flip_delay_tls.gate_renderer_kind = renderer_kind;
    g_flip_delay_tls.gate_host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    g_flip_delay_tls.gate_method = 0;
    g_flip_delay_tls.gate_parameter = 0;
}

void xemu_debug_tools_pgraph_flip_delay_renderer_gate_cancel(void)
{
    if (g_flip_delay_tls.gate_source ==
        XEMU_PGRAPH_FLIP_DELAY_GATE_RENDERER) {
        g_flip_delay_tls.gate_active = 0;
        g_flip_delay_tls.gate_source = XEMU_PGRAPH_FLIP_DELAY_GATE_NONE;
        g_flip_delay_tls.gate_renderer_kind = 0;
    }
}

void xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_attempt(void)
{
    uint64_t now;

    if (!xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        g_flip_delay_tls.gate_active = 0;
        g_flip_delay_tls.lock_attempt_active = 0;
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (g_flip_delay_tls.gate_active) {
        uint64_t gate_wait = elapsed_ns(now, g_flip_delay_tls.gate_host_ns);
        qemu_mutex_lock(&g_flip_delay.lock);
        if (qatomic_read(&g_flip_delay.enabled) && g_flip_delay.active_frame) {
            g_flip_delay.current.cpu_mmio_gate_wait_total_ns += gate_wait;
            g_flip_delay.current.cpu_mmio_gate_wait_max_ns = MAX(
                g_flip_delay.current.cpu_mmio_gate_wait_max_ns, gate_wait);
            if (g_flip_delay_tls.gate_source ==
                XEMU_PGRAPH_FLIP_DELAY_GATE_RENDERER) {
                g_flip_delay.current.renderer_gate_count++;
                g_flip_delay.current.renderer_cpu_mmio_gate_wait_total_ns +=
                    gate_wait;
                g_flip_delay.current.renderer_cpu_mmio_gate_wait_max_ns = MAX(
                    g_flip_delay.current.renderer_cpu_mmio_gate_wait_max_ns,
                    gate_wait);
            } else {
                g_flip_delay.current.pfifo_gate_count++;
                g_flip_delay.current.pfifo_cpu_mmio_gate_wait_total_ns +=
                    gate_wait;
                g_flip_delay.current.pfifo_cpu_mmio_gate_wait_max_ns = MAX(
                    g_flip_delay.current.pfifo_cpu_mmio_gate_wait_max_ns,
                    gate_wait);
            }
        }
        qemu_mutex_unlock(&g_flip_delay.lock);
        g_flip_delay_tls.gate_active = 0;
        g_flip_delay_tls.gate_source = XEMU_PGRAPH_FLIP_DELAY_GATE_NONE;
        g_flip_delay_tls.gate_renderer_kind = 0;
    }

    g_flip_delay_tls.lock_attempt_active = 1;
    g_flip_delay_tls.lock_attempt_host_ns = now;
}

void xemu_debug_tools_pgraph_flip_delay_note_pgraph_lock_acquired(void)
{
    uint64_t now;
    uint64_t wait_ns;

    if (!xemu_debug_tools_pgraph_flip_delay_trace_is_enabled() ||
        !g_flip_delay_tls.lock_attempt_active) {
        g_flip_delay_tls.lock_attempt_active = 0;
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    wait_ns = elapsed_ns(now, g_flip_delay_tls.lock_attempt_host_ns);
    qemu_mutex_lock(&g_flip_delay.lock);
    if (qatomic_read(&g_flip_delay.enabled) && g_flip_delay.active_frame) {
        g_flip_delay.current.pgraph_lock_count++;
        g_flip_delay.current.pgraph_lock_wait_total_ns += wait_ns;
        g_flip_delay.current.pgraph_lock_wait_max_ns = MAX(
            g_flip_delay.current.pgraph_lock_wait_max_ns, wait_ns);
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
    g_flip_delay_tls.lock_attempt_active = 0;
}

void xemu_debug_tools_pgraph_flip_delay_note_increment(
    const XemuDebugToolsPgraphIncrementEvent *event)
{
    if (!event || !xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        return;
    }

    qemu_mutex_lock(&g_flip_delay.lock);
    if (qatomic_read(&g_flip_delay.enabled) && g_flip_delay.active_frame &&
        event->host_end_ns >= g_flip_delay.current.start_host_ns) {
        g_flip_delay.current.pgraph_increment_count++;
        g_flip_delay.current.surface_lock_wait_total_ns +=
            event->surface_lock_wait_ns;
        g_flip_delay.current.surface_lock_wait_max_ns = MAX(
            g_flip_delay.current.surface_lock_wait_max_ns,
            event->surface_lock_wait_ns);
        g_flip_delay.current.surface_update_total_ns += event->surface_update_ns;
        g_flip_delay.current.pfifo_kick_total_ns += event->pfifo_kick_ns;
        g_flip_delay.current.bql_reacquire_total_ns +=
            event->bql_reacquire_wait_ns;
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
}

void xemu_debug_tools_pgraph_flip_delay_note_flip_event(
    const XemuDebugToolsFlipStallTraceEvent *event)
{
    XemuDebugToolsPgraphFlipDelayEvent *current;

    if (!event || !xemu_debug_tools_pgraph_flip_delay_trace_is_enabled()) {
        return;
    }

    qemu_mutex_lock(&g_flip_delay.lock);
    if (!qatomic_read(&g_flip_delay.enabled)) {
        qemu_mutex_unlock(&g_flip_delay.lock);
        return;
    }

    if (event->event_type == XEMU_DEBUG_TOOLS_FLIP_INCREMENT_WRITE) {
        g_flip_delay.last_flip_increment_host_ns = event->host_ns;
        g_flip_delay.last_flip_increment_valid = true;
    }

    if (event->event_type == XEMU_DEBUG_TOOLS_FLIP_STALL_BEGIN) {
        if (g_flip_delay.active_frame) {
            flip_delay_finalize_locked(event->host_ns, event->qemu_virtual_ns,
                                       event->frame_time);
        }
        flip_delay_start_locked(event);
        qemu_mutex_unlock(&g_flip_delay.lock);
        return;
    }

    if (!g_flip_delay.active_frame) {
        qemu_mutex_unlock(&g_flip_delay.lock);
        return;
    }

    current = &g_flip_delay.current;
    current->read_3d = event->read_3d;
    current->write_3d = event->write_3d;
    current->modulo_3d = event->modulo_3d;

    switch (event->event_type) {
    case XEMU_DEBUG_TOOLS_FLIP_VK_FINISH_END:
        current->renderer_finish_total_ns += event->duration_ns;
        current->renderer_finish_max_ns = MAX(
            current->renderer_finish_max_ns, event->duration_ns);
        break;
    case XEMU_DEBUG_TOOLS_FLIP_WAITING_SET:
        if (!g_flip_delay.waiting_set_valid) {
            g_flip_delay.waiting_set_host_ns = event->host_ns;
            g_flip_delay.waiting_set_valid = true;
            current->stall_method_ns = elapsed_ns(
                event->host_ns, current->start_host_ns);
        }
        break;
    case XEMU_DEBUG_TOOLS_FLIP_VBLANK_IRQ:
        current->vblank_irq_count++;
        break;
    case XEMU_DEBUG_TOOLS_FLIP_VBLANK_READ_INCREMENT:
        current->vblank_read_increment_count++;
        if (g_flip_delay.waiting_set_valid && !g_flip_delay.vblank_read_valid) {
            g_flip_delay.vblank_read_host_ns = event->host_ns;
            g_flip_delay.vblank_read_valid = true;
            current->waiting_to_vblank_read_ns = elapsed_ns(
                event->host_ns, g_flip_delay.waiting_set_host_ns);
        }
        break;
    case XEMU_DEBUG_TOOLS_FLIP_PFIFO_CHECK_STALL:
        current->pfifo_stall_check_count++;
        break;
    case XEMU_DEBUG_TOOLS_FLIP_PFIFO_RELEASE:
        current->pfifo_release_count++;
        if (!g_flip_delay.release_valid) {
            g_flip_delay.release_host_ns = event->host_ns;
            g_flip_delay.release_valid = true;
            qatomic_set_u64(&g_flip_delay.pc_sample_start_host_ns,
                            event->host_ns + g_flip_delay.threshold_ns / 2);
            qatomic_set(&g_flip_delay.pc_capture_active, 1);
            current->stall_total_ns = elapsed_ns(
                event->host_ns, current->start_host_ns);
            if (g_flip_delay.vblank_read_valid) {
                current->vblank_read_to_release_ns = elapsed_ns(
                    event->host_ns, g_flip_delay.vblank_read_host_ns);
            }
        }
        break;
    default:
        break;
    }

    qemu_mutex_unlock(&g_flip_delay.lock);
}

void xemu_debug_tools_pgraph_flip_delay_trace_set_enabled(int enabled)
{
    bool ok = true;
    flip_delay_init();
    qemu_mutex_lock(&g_flip_delay.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_flip_delay.events, XemuDebugToolsPgraphFlipDelayEvent,
            XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY,
            g_flip_delay.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&g_flip_delay.lock);
            return;
        }
    }
    if (enabled && !g_flip_delay.enabled) {
        flip_delay_reset_locked();
    }
    qatomic_set(&g_flip_delay.enabled, enabled != 0);
    qemu_mutex_unlock(&g_flip_delay.lock);
    if (!enabled) {
        memset(&g_flip_delay_tls, 0, sizeof(g_flip_delay_tls));
    }
}

void xemu_debug_tools_pgraph_flip_delay_trace_clear(void)
{
    flip_delay_init();
    qemu_mutex_lock(&g_flip_delay.lock);
    flip_delay_reset_locked();
    qemu_mutex_unlock(&g_flip_delay.lock);
}

void xemu_debug_tools_pgraph_flip_delay_trace_set_threshold_ns(uint64_t ns)
{
    flip_delay_init();
    ns = MAX(1000000ULL, MIN(ns, 2000000000ULL));
    qemu_mutex_lock(&g_flip_delay.lock);
    g_flip_delay.threshold_ns = ns;
    flip_delay_reset_locked();
    qemu_mutex_unlock(&g_flip_delay.lock);
}

int xemu_debug_tools_pgraph_flip_delay_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    bool ok;
    flip_delay_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_flip_delay.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_flip_delay.events, XemuDebugToolsPgraphFlipDelayEvent,
        XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY, multiplier, ok);
    if (ok) {
        g_flip_delay.buffer_multiplier = multiplier;
        flip_delay_reset_locked();
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_multiplier(void)
{
    return g_flip_delay.buffer_multiplier ? g_flip_delay.buffer_multiplier : 1;
}

size_t xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY,
        xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_multiplier());
}

void xemu_debug_tools_pgraph_flip_delay_trace_get_status(
    XemuDebugToolsPgraphFlipDelayStatus *status)
{
    uint64_t now;

    if (!status) {
        return;
    }
    flip_delay_init();
    memset(status, 0, sizeof(*status));
    now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    qemu_mutex_lock(&g_flip_delay.lock);
    status->enabled = g_flip_delay.enabled;
    status->count = g_flip_delay.count;
    status->total_frames_seen = g_flip_delay.total_frames_seen;
    status->captured_long_frames = g_flip_delay.captured_long_frames;
    status->overwritten_events = g_flip_delay.overwritten_events;
    status->threshold_ns = g_flip_delay.threshold_ns;
    status->last_frame_ns = g_flip_delay.last_frame_ns;
    status->worst_frame_ns = g_flip_delay.worst_frame_ns;
    status->worst_stall_total_ns = g_flip_delay.worst_stall_total_ns;
    status->worst_post_release_ns = g_flip_delay.worst_post_release_ns;
    status->worst_cpu_mmio_gate_wait_ns =
        g_flip_delay.worst_cpu_mmio_gate_wait_ns;
    status->worst_pfifo_cpu_mmio_gate_wait_ns =
        g_flip_delay.worst_pfifo_cpu_mmio_gate_wait_ns;
    status->worst_renderer_cpu_mmio_gate_wait_ns =
        g_flip_delay.worst_renderer_cpu_mmio_gate_wait_ns;
    status->worst_pgraph_lock_wait_ns = g_flip_delay.worst_pgraph_lock_wait_ns;
    status->worst_renderer_finish_ns = g_flip_delay.worst_renderer_finish_ns;
    status->guest_pc_sample_interval_ns =
        XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_PC_SAMPLE_INTERVAL_NS;
    status->guest_pc_arm_delay_ns = g_flip_delay.threshold_ns / 2;
    status->guest_pc_samples = g_flip_delay.guest_pc_samples;
    status->guest_pc_untracked_samples = g_flip_delay.guest_pc_untracked_samples;
    status->active_frame = g_flip_delay.active_frame ? 1u : 0u;
    if (g_flip_delay.active_frame && now >= g_flip_delay.current.start_host_ns) {
        status->active_frame_age_ns = now - g_flip_delay.current.start_host_ns;
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
}

size_t xemu_debug_tools_pgraph_flip_delay_trace_snapshot(
    XemuDebugToolsPgraphFlipDelayEvent *events, size_t capacity)
{
    size_t ring_capacity;
    size_t count;
    size_t oldest;
    size_t i;

    if (!events || capacity == 0) {
        return 0;
    }
    flip_delay_init();
    qemu_mutex_lock(&g_flip_delay.lock);
    ring_capacity = xemu_debug_tools_pgraph_flip_delay_trace_get_buffer_capacity();
    count = MIN(capacity, g_flip_delay.count);
    oldest = g_flip_delay.count == ring_capacity ? g_flip_delay.write_index : 0;
    if (count < g_flip_delay.count) {
        oldest = (oldest + g_flip_delay.count - count) % ring_capacity;
    }
    for (i = 0; i < count; i++) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_flip_delay.events, XEMU_DEBUG_TOOLS_PGRAPH_FLIP_DELAY_CAPACITY,
            (oldest + i) % ring_capacity);
    }
    qemu_mutex_unlock(&g_flip_delay.lock);
    return count;
}
