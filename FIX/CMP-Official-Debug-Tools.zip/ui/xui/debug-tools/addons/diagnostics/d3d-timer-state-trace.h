/* Info: Focused guest D3D timer-object/list state snapshots for Patch 305.3. */
#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct CPUState CPUState;

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CAPACITY 256
#define XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS 64
#define XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_MAX_PROBES_PER_CYCLE 48

typedef enum XemuDebugToolsD3dTimerStateEventType {
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE = 0,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_CALL,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_RETURN,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_DUE_ENTRY,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SELECT,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_LOAD,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_CALLBACK_CALL,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_SCAN,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_LIST,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DISPATCH_IRQ_CHECK,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_ENTRY,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_OVERDUE,
    XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_D3D_REJECT,
} XemuDebugToolsD3dTimerStateEventType;

typedef struct XemuDebugToolsD3dTimerStateEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t input_sequence;
    uint64_t deadline_sequence;
    uint32_t event_type;
    uint32_t guest_pc;
    uint32_t timer_object;
    uint32_t read_valid;
    uint64_t changed_from_schedule_mask;
    uint64_t changed_from_last_good_mask;
    uint32_t dwords[XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_DWORDS];
} XemuDebugToolsD3dTimerStateEvent;

typedef struct XemuDebugToolsD3dTimerStateStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t current_timer_object;
    uint64_t current_input_sequence;
    uint64_t current_deadline_sequence;
    uint32_t current_probe_count;
    uint32_t max_probes_per_cycle;
    int schedule_snapshot_valid;
    int last_good_snapshot_valid;
    uint64_t completed_good_cycles;
    uint64_t overdue_cycles;
    uint64_t rejected_cycles;
} XemuDebugToolsD3dTimerStateStatus;

int xemu_debug_tools_d3d_timer_state_trace_active(void);
int xemu_debug_tools_d3d_timer_state_trace_should_probe(uint32_t guest_pc);
void xemu_debug_tools_d3d_timer_state_trace_set_enabled(int enabled);
void xemu_debug_tools_d3d_timer_state_trace_clear(void);
void xemu_debug_tools_d3d_timer_state_trace_note(
    CPUState *cpu, uint32_t event_type, uint32_t guest_pc,
    uint32_t timer_object, uint64_t input_sequence,
    uint64_t deadline_sequence);
void xemu_debug_tools_d3d_timer_state_trace_get_status(
    XemuDebugToolsD3dTimerStateStatus *status);
size_t xemu_debug_tools_d3d_timer_state_trace_snapshot(
    XemuDebugToolsD3dTimerStateEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
