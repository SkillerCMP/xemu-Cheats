/* xemu Debug Tools - Diagnostics A/V sync / cadence trace. */
#pragma once

#include "av-sync-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY 8192
#define XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_RATE 48000ULL

/* User observations only: timestamps are button-press times, NOT measured
 * speaker/display timestamps or an automatically detected cutscene timeline. */
#define XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY 64
typedef enum XemuDebugToolsAvSyncMarkerKind {
    XEMU_DEBUG_TOOLS_AV_MARK_CUTSCENE_START = 1,
    XEMU_DEBUG_TOOLS_AV_MARK_SOUND_AHEAD,
    XEMU_DEBUG_TOOLS_AV_MARK_SCENE_END,
} XemuDebugToolsAvSyncMarkerKind;
typedef struct XemuDebugToolsAvSyncMarker {
    uint64_t sequence, host_ns, virtual_ns;
    uint64_t audio_samples, video_vblanks, pgraph_flips;
    uint32_t kind;
} XemuDebugToolsAvSyncMarker;
int xemu_debug_tools_av_sync_trace_mark(unsigned int kind);
size_t xemu_debug_tools_av_sync_trace_markers_snapshot(
    XemuDebugToolsAvSyncMarker *markers, size_t capacity, uint64_t *total);

typedef enum XemuDebugToolsAvSyncEventType {
    XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_BATCH = 1,
    XEMU_DEBUG_TOOLS_AV_SYNC_VBLANK = 2,
    XEMU_DEBUG_TOOLS_AV_SYNC_PGRAPH_FLIP = 3,
} XemuDebugToolsAvSyncEventType;

typedef struct XemuDebugToolsAvSyncTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint32_t event_type;
    uint32_t ready;
    uint32_t pgraph_ready;
    uint32_t reserved_ready;

    uint64_t audio_batches;
    uint64_t audio_samples;
    uint64_t video_vblanks;
    uint64_t video_expected_ns;
    uint64_t vblank_interval_ns;

    uint64_t pgraph_flips;
    uint32_t pgraph_frame_time;
    uint32_t pgraph_last_vblank_delta;
    uint64_t pgraph_last_audio_sample_delta;
    uint64_t pgraph_last_host_interval_ns;
    uint64_t pgraph_last_virtual_interval_ns;
    uint64_t pgraph_max_host_interval_ns;
    uint64_t pgraph_max_virtual_interval_ns;
    uint32_t pgraph_max_vblank_delta;
    uint32_t reserved0;
    uint64_t pgraph_host_age_ns;
    uint64_t pgraph_virtual_age_ns;
    uint64_t audio_since_pgraph_ns;
    uint64_t vblank_since_pgraph_ns;

    int32_t audio_queue_bytes;
    uint32_t audio_batch_samples;

    int64_t audio_host_drift_ns;
    int64_t audio_virtual_drift_ns;
    int64_t video_host_drift_ns;
    int64_t video_virtual_drift_ns;
    int64_t av_host_drift_ns;
    int64_t av_virtual_drift_ns;
} XemuDebugToolsAvSyncTraceEvent;

typedef struct XemuDebugToolsAvSyncTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t ready;
    uint32_t pgraph_ready;

    uint64_t audio_batches;
    uint64_t audio_samples;
    uint64_t video_vblanks;
    uint64_t video_expected_ns;
    uint64_t last_vblank_interval_ns;
    int32_t last_audio_queue_bytes;

    uint64_t pgraph_flips;
    uint32_t last_pgraph_frame_time;
    uint32_t last_pgraph_vblank_delta;
    uint64_t last_pgraph_audio_sample_delta;
    uint64_t last_pgraph_host_interval_ns;
    uint64_t last_pgraph_virtual_interval_ns;
    uint64_t max_pgraph_host_interval_ns;
    uint64_t max_pgraph_virtual_interval_ns;
    uint32_t max_pgraph_vblank_delta;
    uint32_t reserved0;
    uint64_t pgraph_host_age_ns;
    uint64_t pgraph_virtual_age_ns;
    uint64_t audio_since_pgraph_ns;
    uint64_t vblank_since_pgraph_ns;

    int64_t audio_host_drift_ns;
    int64_t audio_virtual_drift_ns;
    int64_t video_host_drift_ns;
    int64_t video_virtual_drift_ns;
    int64_t av_host_drift_ns;
    int64_t av_virtual_drift_ns;
} XemuDebugToolsAvSyncTraceStatus;

void xemu_debug_tools_av_sync_trace_set_enabled(int enabled);
void xemu_debug_tools_av_sync_trace_clear(void);
int xemu_debug_tools_av_sync_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_av_sync_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_av_sync_trace_get_buffer_capacity(void);
void xemu_debug_tools_av_sync_trace_get_status(
    XemuDebugToolsAvSyncTraceStatus *status);
size_t xemu_debug_tools_av_sync_trace_snapshot(
    XemuDebugToolsAvSyncTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
