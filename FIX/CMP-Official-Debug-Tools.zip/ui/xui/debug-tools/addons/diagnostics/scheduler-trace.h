/* xemu Debug Tools - Diagnostics-owned Xbox scheduler / thread-wake trace. */
#pragma once

#include "scheduler-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_SCHEDULER_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_START 0x8001B02Eu
#define XEMU_DEBUG_TOOLS_KI_IDLE_LOOP_END   0x8001B04Fu

typedef enum XemuDebugToolsSchedulerTraceEventType {
    XEMU_DEBUG_TOOLS_SCHED_IDLE_ENTER = 1,
    XEMU_DEBUG_TOOLS_SCHED_IDLE_CHECKPOINT,
    XEMU_DEBUG_TOOLS_SCHED_IDLE_EXIT,
    XEMU_DEBUG_TOOLS_SCHED_TITLE_RETURN,
} XemuDebugToolsSchedulerTraceEventType;

typedef struct XemuDebugToolsSchedulerTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t idle_age_ns;
    uint64_t duration_ns;
    uint64_t last_irq_age_ns;
    uint64_t last_irq_host_ns;
    uint32_t event_type;
    uint32_t guest_pc;
    uint32_t last_title_pc;
    uint32_t eflags;
    uint32_t ebx;
    uint32_t ebp;
    uint32_t esp;
    uint32_t scheduler_slot_28;
    uint32_t scheduler_slot_2c;
    uint32_t interrupt_request;
    int32_t exception_index;
    int32_t cpu_index;
    uint32_t halted;
    uint32_t last_irq_source;
    uint32_t last_irq_pending;
    uint32_t last_irq_enabled;
    uint32_t pmc_pending;
    uint32_t pmc_enabled;
    uint32_t pfifo_pending;
    uint32_t pfifo_enabled;
    uint32_t pgraph_pending;
    uint32_t pgraph_enabled;
    uint32_t pcrtc_pending;
    uint32_t pcrtc_enabled;
    uint32_t ptimer_pending;
    uint32_t ptimer_enabled;
    uint32_t idle_vblank_count;
    uint32_t idle_ptimer_count;
    uint32_t idle_pgraph_count;
    uint32_t idle_pfifo_count;
    uint32_t idle_ohci_count;
} XemuDebugToolsSchedulerTraceEvent;

typedef struct XemuDebugToolsSchedulerTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t active_idle;
    uint64_t active_idle_start_host_ns;
    uint64_t active_idle_start_virtual_ns;
    uint64_t active_idle_age_ns;
    uint64_t longest_completed_idle_ns;
    uint32_t last_sample_pc;
    uint32_t last_title_pc;
    uint32_t last_irq_source;
    uint64_t last_irq_host_ns;
    uint32_t idle_pc_start;
    uint32_t idle_pc_end;
} XemuDebugToolsSchedulerTraceStatus;

void xemu_debug_tools_scheduler_trace_sample(void);
void xemu_debug_tools_scheduler_trace_set_enabled(int enabled);
void xemu_debug_tools_scheduler_trace_clear(void);
int xemu_debug_tools_scheduler_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_scheduler_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_scheduler_trace_get_buffer_capacity(void);
void xemu_debug_tools_scheduler_trace_get_status(
    XemuDebugToolsSchedulerTraceStatus *status);
size_t xemu_debug_tools_scheduler_trace_snapshot(
    XemuDebugToolsSchedulerTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
