#pragma once

#include <limits.h>
#include <stdint.h>

#include "qemu/timer.h"
#include "hw/xbox/nv2a/nv2a_int.h"

#define XEMU_DEBUG_TOOLS_PTIMER_NS_PER_SECOND 1000000000ULL

static inline uint64_t xemu_debug_tools_ptimer_absolute_clock(
    NV2AState *d, uint64_t virtual_ns)
{
    if (d->ptimer.numerator == 0 || d->pramdac.core_clock_freq == 0) {
        return 0;
    }
    return muldiv64(muldiv64(virtual_ns, d->pramdac.core_clock_freq,
                             XEMU_DEBUG_TOOLS_PTIMER_NS_PER_SECOND),
                    d->ptimer.denominator, d->ptimer.numerator);
}

static inline uint64_t xemu_debug_tools_ptimer_clock(NV2AState *d,
                                                      uint64_t virtual_ns)
{
    const uint64_t absolute =
        xemu_debug_tools_ptimer_absolute_clock(d, virtual_ns);
    return ((absolute + d->ptimer.time_offset) << 5) &
           0x1fffffffffffffffULL;
}

static inline uint64_t xemu_debug_tools_ptimer_ticks_to_ns(NV2AState *d,
                                                            uint64_t ticks)
{
    uint64_t gpu_ticks;

    if (d->ptimer.denominator == 0 || d->pramdac.core_clock_freq == 0) {
        return 0;
    }
    gpu_ticks = muldiv64(ticks, d->ptimer.numerator,
                         d->ptimer.denominator);
    return muldiv64(gpu_ticks, XEMU_DEBUG_TOOLS_PTIMER_NS_PER_SECOND,
                    d->pramdac.core_clock_freq);
}

static inline int64_t xemu_debug_tools_ptimer_signed_alarm_delta_ns(
    NV2AState *d, uint64_t now, uint64_t alarm)
{
    uint64_t ns;

    if (alarm >= now) {
        ns = xemu_debug_tools_ptimer_ticks_to_ns(d, (alarm - now) >> 5);
        return ns > INT64_MAX ? INT64_MAX : (int64_t)ns;
    }

    ns = xemu_debug_tools_ptimer_ticks_to_ns(d, (now - alarm) >> 5);
    return ns > INT64_MAX ? INT64_MIN : -(int64_t)ns;
}
