#pragma once

#include <stdint.h>

#include "hw/core/cpu.h"

static inline void xemu_debug_tools_diagnostics_current_cpu_context(
    int32_t *cpu_index, uint64_t *guest_pc, uint32_t *guest_pc_valid)
{
    CPUState *cpu = current_cpu;

    *cpu_index = -1;
    *guest_pc = 0;
    *guest_pc_valid = 0;
    if (cpu == NULL) {
        return;
    }
    *cpu_index = cpu->cpu_index;
    if (cpu->cc != NULL && cpu->cc->get_pc != NULL) {
        *guest_pc = cpu->cc->get_pc(cpu);
        *guest_pc_valid = 1;
    }
}
