/* Info: Central qemu_main_loop_lock wrapper emits ownership/latency boundaries. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void xemu_debug_tools_main_loop_lock_trace_set_next_context(uint32_t context);
void xemu_debug_tools_main_loop_lock_trace_owner_stage_begin(uint32_t stage);
void xemu_debug_tools_main_loop_lock_trace_owner_stage_end(void);

void xemu_debug_tools_main_loop_lock_trace_lock_attempt(const char *file,
                                                        int line);
void xemu_debug_tools_main_loop_lock_trace_lock_acquired(const char *file,
                                                         int line);
void xemu_debug_tools_main_loop_lock_trace_unlock_begin(void);
void xemu_debug_tools_main_loop_lock_trace_unlock_end(void);

#ifdef __cplusplus
}
#endif
