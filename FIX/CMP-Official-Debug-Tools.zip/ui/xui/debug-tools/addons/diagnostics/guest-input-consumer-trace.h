/* Info: Correlates changed Xbox input reports with nearby title TCG blocks. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX 20
#define XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_WINDOW_NS 40000000ULL
#define XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_MAX_PCS_PER_REPORT 192

typedef enum XemuDebugToolsGuestInputConsumerEventType {
    XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_CHANGE = 1,
    XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TITLE_TB,
} XemuDebugToolsGuestInputConsumerEventType;

typedef struct XemuDebugToolsGuestInputConsumerTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t report_sequence;
    uint64_t age_since_report_ns;
    uint32_t event_type;
    uint32_t guest_pc;
    uint32_t guest_address0;
    uint32_t guest_length0;
    uint32_t guest_address1;
    uint32_t guest_length1;
    uint32_t report_length;
    uint32_t candidate_ordinal;
    uint8_t report[XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX];
} XemuDebugToolsGuestInputConsumerTraceEvent;

typedef struct XemuDebugToolsGuestInputConsumerTraceStatus {
    int enabled;
    int capture_active;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t report_changes;
    uint64_t title_tb_candidates;
    uint64_t dropped_candidates;
    uint64_t current_report_sequence;
    uint64_t last_report_virtual_ns;
    uint64_t capture_until_virtual_ns;
    uint32_t current_candidate_count;
} XemuDebugToolsGuestInputConsumerTraceStatus;

int xemu_debug_tools_guest_input_consumer_trace_active(void);
int xemu_debug_tools_guest_input_consumer_trace_capture_active(void);
void xemu_debug_tools_guest_input_consumer_trace_note_report(
    uint32_t guest_address0, uint32_t guest_length0,
    uint32_t guest_address1, uint32_t guest_length1,
    const uint8_t *report, uint32_t report_length);
void xemu_debug_tools_guest_input_consumer_trace_note_title_tb(uint32_t guest_pc);
void xemu_debug_tools_guest_input_consumer_trace_set_enabled(int enabled);
void xemu_debug_tools_guest_input_consumer_trace_clear(void);
int xemu_debug_tools_guest_input_consumer_trace_set_buffer_multiplier(
    uint32_t multiplier);
uint32_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_capacity(void);
void xemu_debug_tools_guest_input_consumer_trace_get_status(
    XemuDebugToolsGuestInputConsumerTraceStatus *status);
size_t xemu_debug_tools_guest_input_consumer_trace_snapshot(
    XemuDebugToolsGuestInputConsumerTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
