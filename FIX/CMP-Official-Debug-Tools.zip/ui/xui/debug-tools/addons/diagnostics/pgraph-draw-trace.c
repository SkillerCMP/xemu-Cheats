/* Info: Commit detailed draw stages only when draw-end time reaches 5 ms. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/timer.h"
#include "qemu/thread.h"
#include "hw/core/cpu.h"
#include "hw/xbox/nv2a/pgraph/pgraph.h"

#include "pgraph-draw-trace.h"
#include "pgraph-draw-aggregate.h"
#include "diagnostics-trace-buffer.h"

#define PGRAPH_DRAW_TRACE_TLS_EVENTS 48
#define PGRAPH_DRAW_TRACE_TLS_STACK 24

typedef struct XemuDebugToolsPgraphDrawTraceSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsPgraphDrawTraceEvent event;
} XemuDebugToolsPgraphDrawTraceSlot;

typedef struct XemuDebugToolsPgraphDrawPending {
    XemuDebugToolsPgraphDrawTraceEvent event;
    uint32_t completed;
} XemuDebugToolsPgraphDrawPending;

typedef struct XemuDebugToolsPgraphDrawTraceTls {
    uint32_t active;
    uint64_t generation;
    const PGRAPHState *pgraph_state;
    uint64_t draw_id;
    int32_t thread_id;
    int32_t cpu_index;
    uint32_t path;
    uint32_t primitive_mode;
    uint32_t draw_arrays_length;
    uint32_t draw_arrays_max_count;
    uint32_t inline_elements_length;
    uint32_t inline_buffer_length;
    uint32_t inline_array_length;
    uint32_t zpass_pixel_count_enable;
    uint32_t flush_pending;
    uint32_t sync_pending;
    char renderer[XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_RENDERER_MAX];
    uint32_t skipped_depth;
    uint32_t truncated;
    uint32_t pending_count;
    uint32_t stack_depth;
    uint32_t stack[PGRAPH_DRAW_TRACE_TLS_STACK];
    XemuDebugToolsPgraphDrawPending pending[PGRAPH_DRAW_TRACE_TLS_EVENTS];
} XemuDebugToolsPgraphDrawTraceTls;

static struct {
    int enabled;
    uint64_t generation;
    uint64_t total_events;
    uint64_t next_draw_id;
    uint64_t retained_draws;
    uint64_t truncated_draws;
    uint32_t buffer_multiplier;
    XemuDebugToolsPgraphDrawTraceSlot *slots[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} pgraph_draw_trace = { .buffer_multiplier = 1 };

static __thread XemuDebugToolsPgraphDrawTraceTls pgraph_draw_trace_tls;

static int32_t pgraph_draw_trace_current_cpu(void)
{
    CPUState *cpu = current_cpu;
    return cpu != NULL ? cpu->cpu_index : -1;
}

static uint32_t pgraph_draw_trace_path(const PGRAPHState *pg)
{
    if (pg == NULL) {
        return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_UNKNOWN;
    }
    if (pg->draw_arrays_length) {
        return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_DRAW_ARRAYS;
    }
    if (pg->inline_elements_length) {
        return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_ELEMENTS;
    }
    if (pg->inline_buffer_length) {
        return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_BUFFER;
    }
    if (pg->inline_array_length) {
        return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_INLINE_ARRAY;
    }
    return XEMU_DEBUG_TOOLS_PGRAPH_DRAW_PATH_EMPTY;
}

static void pgraph_draw_trace_capture_context(
    XemuDebugToolsPgraphDrawTraceTls *tls, const PGRAPHState *pg)
{
    tls->thread_id = qemu_get_thread_id();
    tls->cpu_index = pgraph_draw_trace_current_cpu();
    tls->path = pgraph_draw_trace_path(pg);
    if (pg == NULL) {
        g_strlcpy(tls->renderer, "<null>", sizeof(tls->renderer));
        return;
    }

    tls->primitive_mode = pg->primitive_mode;
    tls->draw_arrays_length = pg->draw_arrays_length;
    tls->draw_arrays_max_count = pg->draw_arrays_max_count;
    tls->inline_elements_length = pg->inline_elements_length;
    tls->inline_buffer_length = pg->inline_buffer_length;
    tls->inline_array_length = pg->inline_array_length;
    tls->zpass_pixel_count_enable = pg->zpass_pixel_count_enable ? 1u : 0u;
    tls->flush_pending = pg->flush_pending ? 1u : 0u;
    tls->sync_pending = pg->sync_pending ? 1u : 0u;
    if (pg->renderer != NULL && pg->renderer->name != NULL) {
        g_strlcpy(tls->renderer, pg->renderer->name, sizeof(tls->renderer));
    } else {
        g_strlcpy(tls->renderer, "<unknown>", sizeof(tls->renderer));
    }
}

static void pgraph_draw_trace_fill_context(
    XemuDebugToolsPgraphDrawTraceEvent *event,
    const XemuDebugToolsPgraphDrawTraceTls *tls)
{
    event->draw_id = tls->draw_id;
    event->thread_id = tls->thread_id;
    event->cpu_index = tls->cpu_index;
    event->path = tls->path;
    event->primitive_mode = tls->primitive_mode;
    event->draw_arrays_length = tls->draw_arrays_length;
    event->draw_arrays_max_count = tls->draw_arrays_max_count;
    event->inline_elements_length = tls->inline_elements_length;
    event->inline_buffer_length = tls->inline_buffer_length;
    event->inline_array_length = tls->inline_array_length;
    event->zpass_pixel_count_enable = tls->zpass_pixel_count_enable;
    event->flush_pending = tls->flush_pending;
    event->sync_pending = tls->sync_pending;
    g_strlcpy(event->renderer, tls->renderer, sizeof(event->renderer));
}

static void pgraph_draw_trace_refresh_state(
    XemuDebugToolsPgraphDrawTraceEvent *event, const PGRAPHState *pg)
{
    if (pg == NULL) {
        return;
    }
    event->primitive_mode = pg->primitive_mode;
    event->zpass_pixel_count_enable = pg->zpass_pixel_count_enable ? 1u : 0u;
    event->flush_pending = pg->flush_pending ? 1u : 0u;
    event->sync_pending = pg->sync_pending ? 1u : 0u;
}

static void pgraph_draw_trace_append(XemuDebugToolsPgraphDrawTraceEvent *event)
{
    uint64_t sequence = qatomic_fetch_inc(&pgraph_draw_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity();
    XemuDebugToolsPgraphDrawTraceSlot *slot =
        &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(pgraph_draw_trace.slots,XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY,sequence % trace_capacity);

    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}

void xemu_debug_tools_pgraph_draw_trace_stage_begin(
    unsigned int stage, const void *pgraph_state, uint64_t value0,
    uint64_t value1)
{
    XemuDebugToolsPgraphDrawTraceTls *tls = &pgraph_draw_trace_tls;
    XemuDebugToolsPgraphDrawPending *pending;
    uint32_t index;
    uint64_t aggregate_host_ns = xemu_debug_tools_pgraph_draw_aggregate_begin(stage);

    if (!qatomic_read(&pgraph_draw_trace.enabled)) {
        if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL) {
            tls->active = 0;
        }
        return;
    }

    if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL) {
        const PGRAPHState *pg = (const PGRAPHState *)pgraph_state;
        memset(tls, 0, sizeof(*tls));
        tls->active = 1;
        tls->generation = qatomic_read(&pgraph_draw_trace.generation);
        tls->pgraph_state = pg;
        tls->draw_id = qatomic_fetch_inc(&pgraph_draw_trace.next_draw_id) + 1;
        pgraph_draw_trace_capture_context(tls, pg);
    } else if (!tls->active ||
               tls->generation != qatomic_read(&pgraph_draw_trace.generation)) {
        return;
    }

    if (tls->skipped_depth || tls->pending_count >= PGRAPH_DRAW_TRACE_TLS_EVENTS ||
        tls->stack_depth >= PGRAPH_DRAW_TRACE_TLS_STACK) {
        if (tls->skipped_depth != UINT32_MAX) tls->skipped_depth++;
        tls->truncated = 1;
        return;
    }

    index = tls->pending_count++;
    pending = &tls->pending[index];
    memset(pending, 0, sizeof(*pending));
    pgraph_draw_trace_fill_context(&pending->event, tls);
    pgraph_draw_trace_refresh_state(&pending->event,
        pgraph_state != NULL ? (const PGRAPHState *)pgraph_state
                             : tls->pgraph_state);
    pending->event.stage = stage;
    pending->event.value0 = value0;
    pending->event.value1 = value1;
    pending->event.host_start_ns = aggregate_host_ns ? aggregate_host_ns
        : (uint64_t)qemu_clock_get_ns(QEMU_CLOCK_HOST);
    pending->event.qemu_virtual_start_ns =
        qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    tls->stack[tls->stack_depth++] = index;
}

void xemu_debug_tools_pgraph_draw_trace_stage_end(unsigned int stage)
{
    XemuDebugToolsPgraphDrawTraceTls *tls = &pgraph_draw_trace_tls;
    XemuDebugToolsPgraphDrawPending *pending;
    uint32_t index;
    uint32_t depth;
    uint64_t aggregate_host_ns = xemu_debug_tools_pgraph_draw_aggregate_end(stage);

    if (!tls->active || !qatomic_read(&pgraph_draw_trace.enabled) ||
        tls->generation != qatomic_read(&pgraph_draw_trace.generation) ||
        tls->stack_depth == 0) {
        return;
    }

    if (tls->skipped_depth) {
        tls->skipped_depth--;
        return; /* An omitted child must not close an older same-name parent. */
    }

    depth = tls->stack_depth;
    while (depth > 0) {
        index = tls->stack[depth - 1];
        if (tls->pending[index].event.stage == stage) {
            break;
        }
        --depth;
    }
    if (depth == 0) {
        return;
    }

    index = tls->stack[depth - 1];
    tls->stack_depth = depth - 1;
    pending = &tls->pending[index];
    pending->event.qemu_virtual_end_ns =
        qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    pending->event.host_end_ns = aggregate_host_ns ? aggregate_host_ns
        : (uint64_t)qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (pending->event.host_end_ns >= pending->event.host_start_ns) {
        pending->event.duration_host_ns =
            pending->event.host_end_ns - pending->event.host_start_ns;
    }
    if (pending->event.qemu_virtual_end_ns >=
        pending->event.qemu_virtual_start_ns) {
        pending->event.duration_virtual_ns =
            pending->event.qemu_virtual_end_ns -
            pending->event.qemu_virtual_start_ns;
    }
    pgraph_draw_trace_refresh_state(&pending->event, tls->pgraph_state);
    pending->completed = 1;

    if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL) {
        uint64_t total_ns = pending->event.duration_host_ns;
        if (total_ns >= XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS) {
            uint32_t i;
            qatomic_inc(&pgraph_draw_trace.retained_draws);
            if (tls->truncated) qatomic_inc(&pgraph_draw_trace.truncated_draws);
            for (i = 0; i < tls->pending_count; ++i) {
                if (tls->pending[i].completed) {
                    pgraph_draw_trace_append(&tls->pending[i].event);
                }
            }
        }
        tls->active = 0;
        tls->pending_count = 0;
        tls->stack_depth = 0;
    }
}

void xemu_debug_tools_pgraph_draw_trace_pipeline_cache(unsigned int outcome)
{
    xemu_debug_tools_pgraph_draw_aggregate_cache(outcome);
}

void xemu_debug_tools_pgraph_draw_trace_set_enabled(int enabled)
{
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(pgraph_draw_trace.slots,XemuDebugToolsPgraphDrawTraceSlot,XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY,xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier(),ok); if(!ok) return; }
    if (enabled) {
        xemu_debug_tools_pgraph_draw_trace_clear();
        qatomic_set(&pgraph_draw_trace.enabled, 1);
    } else {
        qatomic_set(&pgraph_draw_trace.enabled, 0);
        qatomic_inc(&pgraph_draw_trace.generation);
        pgraph_draw_trace_tls.active = 0;
    }
}

int xemu_debug_tools_pgraph_draw_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(pgraph_draw_trace.slots,XemuDebugToolsPgraphDrawTraceSlot,XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY,multiplier,ok); if(!ok) return 0;
    qatomic_set(&pgraph_draw_trace.buffer_multiplier,multiplier); xemu_debug_tools_pgraph_draw_trace_clear(); return 1;
}
uint32_t xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier(void){uint32_t m=qatomic_read(&pgraph_draw_trace.buffer_multiplier);return m?m:1;}
size_t xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity(void){return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY,xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier());}

void xemu_debug_tools_pgraph_draw_trace_clear(void)
{
    qatomic_inc(&pgraph_draw_trace.generation);
    qatomic_set(&pgraph_draw_trace.total_events, 0);
    qatomic_set(&pgraph_draw_trace.next_draw_id, 0);
    qatomic_set(&pgraph_draw_trace.retained_draws, 0);
    qatomic_set(&pgraph_draw_trace.truncated_draws, 0);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(pgraph_draw_trace.slots, XemuDebugToolsPgraphDrawTraceSlot, XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY, xemu_debug_tools_pgraph_draw_trace_get_buffer_multiplier());
    memset(&pgraph_draw_trace_tls, 0, sizeof(pgraph_draw_trace_tls));
}

void xemu_debug_tools_pgraph_draw_trace_get_status(
    XemuDebugToolsPgraphDrawTraceStatus *status)
{
    uint64_t total;

    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    status->enabled = qatomic_read(&pgraph_draw_trace.enabled) ? 1 : 0;
    total = qatomic_read(&pgraph_draw_trace.total_events);
    status->total_events = total;
    status->count = MIN(total, (uint64_t)xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity());
    status->overwritten_events =
        total > xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity()
            ? total - xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity()
            : 0;
    status->retained_draws = qatomic_read(&pgraph_draw_trace.retained_draws);
    status->truncated_draws = qatomic_read(&pgraph_draw_trace.truncated_draws);
    status->long_draw_threshold_ns =
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_LONG_DRAW_NS;
}

size_t xemu_debug_tools_pgraph_draw_trace_snapshot(
    XemuDebugToolsPgraphDrawTraceEvent *events, size_t capacity)
{
    uint64_t total;
    uint64_t available;
    uint64_t first;
    uint64_t sequence;
    size_t copied = 0;

    if (events == NULL || capacity == 0) {
        return 0;
    }

    total = qatomic_read(&pgraph_draw_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_pgraph_draw_trace_get_buffer_capacity();
    available = MIN(total, (uint64_t)trace_capacity);
    first = available > capacity ? total - capacity : total - available;

    for (sequence = first; sequence < total && copied < capacity; ++sequence) {
        XemuDebugToolsPgraphDrawTraceSlot *slot =
            &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(pgraph_draw_trace.slots,XEMU_DEBUG_TOOLS_PGRAPH_DRAW_TRACE_CAPACITY,sequence % trace_capacity);
        uint64_t commit_before =
            qatomic_read(&slot->committed_sequence_plus_one);
        XemuDebugToolsPgraphDrawTraceEvent event;
        uint64_t commit_after;

        if (commit_before != sequence + 1) {
            continue;
        }
        smp_rmb();
        event = slot->event;
        smp_rmb();
        commit_after = qatomic_read(&slot->committed_sequence_plus_one);
        if (commit_after != commit_before || event.sequence != sequence) {
            continue;
        }
        events[copied++] = event;
    }
    return copied;
}
