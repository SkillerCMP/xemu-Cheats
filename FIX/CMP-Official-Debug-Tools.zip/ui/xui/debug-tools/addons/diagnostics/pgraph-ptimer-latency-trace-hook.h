/* xemu Debug Tools - PGRAPH increment + PTIMER IRQ service latency profiler. */
#pragma once
/*
 * pgraph.c includes this hook before qemu/timer.h. Pull in QEMU's platform
 * prerequisite first so timer.h never gets parsed without osdep setup on
 * Windows/MinGW (bool, glue macros, Win32 timing types, GLib types, etc.).
 */
#include "qemu/osdep.h"
#include "pgraph-ptimer-latency-trace-types.h"
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_CAPACITY 128
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_CAPACITY 128
#define XEMU_DEBUG_TOOLS_PGRAPH_INCREMENT_DEFAULT_THRESHOLD_NS 1000000ULL
#define XEMU_DEBUG_TOOLS_PTIMER_IRQ_LATENCY_DEFAULT_THRESHOLD_NS 1000000ULL


uint64_t xemu_debug_tools_pgraph_increment_trace_threshold_ns(void);
void xemu_debug_tools_pgraph_increment_trace_record(const XemuDebugToolsPgraphIncrementEvent *event);
void xemu_debug_tools_pgraph_increment_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_increment_trace_set_threshold_ns(uint64_t ns);
void xemu_debug_tools_pgraph_increment_trace_clear(void);
int xemu_debug_tools_pgraph_increment_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_pgraph_increment_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_pgraph_increment_trace_get_buffer_capacity(void);
void xemu_debug_tools_pgraph_increment_trace_get_status(XemuDebugToolsLatencyTraceStatus *status);
size_t xemu_debug_tools_pgraph_increment_trace_snapshot(XemuDebugToolsPgraphIncrementEvent *events, size_t capacity);

void xemu_debug_tools_ptimer_irq_latency_note_set(void *nv2a_state);
void xemu_debug_tools_ptimer_irq_latency_note_clear(void *nv2a_state, uint32_t clear_value);
void xemu_debug_tools_ptimer_irq_latency_trace_set_enabled(int enabled);
void xemu_debug_tools_ptimer_irq_latency_trace_set_threshold_ns(uint64_t ns);
void xemu_debug_tools_ptimer_irq_latency_trace_clear(void);
int xemu_debug_tools_ptimer_irq_latency_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_ptimer_irq_latency_trace_get_buffer_capacity(void);
void xemu_debug_tools_ptimer_irq_latency_trace_get_status(XemuDebugToolsLatencyTraceStatus *status);
size_t xemu_debug_tools_ptimer_irq_latency_trace_snapshot(XemuDebugToolsPtimerIrqLatencyEvent *events, size_t capacity);
#ifdef __cplusplus
}
#endif
