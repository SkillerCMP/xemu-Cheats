/* Info: Low-intrusion correlation of guest DMA PUT, PFIFO consumption, and
 * NV097 semaphore progress writes. The recorder is observation-only. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "diagnostics-cpu-context.h"
#include "diagnostics-trace-buffer.h"
#include "pgraph-pusher-progress-trace.h"
#include "pgraph-draw-aggregate.h"

typedef struct XemuDebugToolsPgraphPusherProgressSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsPgraphPusherProgressEvent event;
} XemuDebugToolsPgraphPusherProgressSlot;


typedef struct XemuDebugToolsPgraphPusherMethodBreakdownSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsPgraphPusherMethodBreakdownEvent event;
} XemuDebugToolsPgraphPusherMethodBreakdownSlot;

#define XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_WORK_CAPACITY 128

typedef struct XemuDebugToolsPgraphPusherMethodWorkStat {
    uint64_t total_ns;
    uint64_t max_ns;
    uint32_t graphics_class;
    uint32_t subchannel;
    uint32_t method;
    uint32_t method_base;
    uint32_t variant;
    uint32_t call_count;
    uint32_t words_processed;
    char name[XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_NAME_CAPACITY];
} XemuDebugToolsPgraphPusherMethodWorkStat;

#define PGRAPH_DRAW_AGGREGATE_STACK_CAPACITY 24

typedef struct XemuDebugToolsPgraphDrawAggregateFrame {
    uint64_t host_start_ns;
    uint64_t child_ns;
    uint32_t stage;
} XemuDebugToolsPgraphDrawAggregateFrame;

typedef struct XemuDebugToolsPgraphPusherMethodWork {
    int active;
    int32_t thread_id;
    uint32_t channel_id;
    uint32_t dma_get_before;
    uint32_t dma_put_before;
    uint64_t host_start_ns;
    uint64_t virtual_start_ns;
    uint64_t puller_dispatch_ns;
    uint64_t nv097_puller_ns;
    uint64_t non_nv097_puller_ns;
    uint64_t unclassified_puller_ns;
    uint64_t untracked_nv097_ns;
    uint32_t puller_calls;
    uint32_t nv097_calls;
    uint32_t non_nv097_calls;
    uint32_t unclassified_calls;
    uint32_t untracked_nv097_calls;
    uint32_t method_count;
    uint32_t pending_identity_valid;
    uint32_t pending_subchannel;
    uint32_t pending_graphics_class;
    uint32_t pending_method;
    uint32_t pending_method_base;
    uint32_t pending_parameter;
    const char *pending_method_name;
    uint64_t generation;
    uint64_t coverage_epoch;
    uint32_t draw_depth;
    uint32_t draw_overflow_depth;
    XemuDebugToolsPgraphDrawAggregate draw;
    XemuDebugToolsPgraphDrawAggregateFrame draw_stack[PGRAPH_DRAW_AGGREGATE_STACK_CAPACITY];
    XemuDebugToolsPgraphPusherMethodWorkStat
        methods[XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_WORK_CAPACITY];
} XemuDebugToolsPgraphPusherMethodWork;

static struct {
    int enabled;
    uint64_t total_events;
    uint64_t dma_put_events;
    uint64_t pfifo_run_events;
    uint64_t semaphore_release_events;
    uint64_t worst_pfifo_run_ns;
    uint64_t worst_semaphore_release_ns;
    uint64_t worst_dma_put_to_semaphore_ns;
    uint64_t last_dma_put_to_semaphore_ns;
    uint64_t last_dma_put_host_ns;
    uint32_t last_dma_put_channel;
    uint32_t last_dma_get;
    uint32_t last_dma_put;
    uint32_t last_semaphore_phys;
    uint32_t last_semaphore_guest_va;
    uint32_t last_semaphore_value;
    uint32_t last_semaphore_target_valid;
    uint32_t buffer_multiplier;
    XemuDebugToolsPgraphPusherProgressSlot *slots[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} g_pusher_progress = { .buffer_multiplier = 1 };


static struct {
    int enabled;
    uint64_t total_long_runs;
    uint64_t generation;
    uint64_t worst_run_ns;
    uint64_t worst_puller_dispatch_ns;
    uint64_t worst_parser_other_ns;
    uint64_t last_run_ns;
    uint64_t last_puller_dispatch_ns;
    uint64_t last_parser_other_ns;
    uint32_t last_puller_calls;
    uint32_t last_nv097_calls;
    uint32_t last_unique_nv097_methods;
    XemuDebugToolsPgraphPusherMethodBreakdownSlot *slots[1];
} g_method_breakdown;

/* PFIFO has one pusher thread. This working set is written only by that thread;
 * the UI sees only committed ring entries/status counters. */
static __thread XemuDebugToolsPgraphPusherMethodWork g_method_work;

/* Per-run publication uses a single try-CAS, never a wait/spin for the UI.
 * Slot payloads are accessed only while owned; no seqlock/plain-copy data race.
 * Producer TLS retains contributions after a deferred publication, so the next
 * successful publish catches up. Only clear intentionally discards that TLS. */
typedef struct XemuDebugToolsPgraphCoverageSlot {
    int busy;
    XemuDebugToolsPgraphCoverageEvent event;
} XemuDebugToolsPgraphCoverageSlot;
static XemuDebugToolsPgraphCoverageSlot *g_coverage_slots;
static uint64_t g_coverage_epoch = 1;
static __thread XemuDebugToolsPgraphCoverageEvent g_coverage_work;

static void coverage_add(uint64_t *dest, uint64_t value)
{
    if (UINT64_MAX - *dest < value) {
        *dest = UINT64_MAX;
        g_coverage_work.saturated = 1;
    } else {
        *dest += value;
    }
}

static bool coverage_publish(void)
{
    XemuDebugToolsPgraphCoverageSlot *slots = qatomic_load_acquire(&g_coverage_slots);
    if (!slots || !g_coverage_work.runs) {
        return false;
    }
    XemuDebugToolsPgraphCoverageSlot *slot = &slots[
        g_coverage_work.sequence % XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY];
    if (qatomic_cmpxchg(&slot->busy, 0, 1) != 0) {
        coverage_add(&g_coverage_work.publication_deferrals, 1);
        return false;
    }
    slot->event = g_coverage_work;
    qatomic_store_release(&slot->busy, 0);
    return true;
}

static void coverage_next(void)
{
    uint64_t next = g_coverage_work.sequence + 1;
    uint64_t epoch = g_coverage_work.epoch;
    memset(&g_coverage_work, 0, sizeof(g_coverage_work));
    g_coverage_work.sequence = next;
    g_coverage_work.epoch = epoch;
}

static void pusher_coverage_finish(uint64_t host_end_ns, uint64_t virtual_end_ns,
                                   uint32_t words)
{
    uint64_t epoch = g_method_work.coverage_epoch;
    if (epoch != qatomic_read(&g_coverage_epoch)) {
        return; /* Clear after the run-finish generation check: never relabel old work. */
    }
    if (g_coverage_work.epoch != epoch) {
        memset(&g_coverage_work, 0, sizeof(g_coverage_work));
        g_coverage_work.epoch = epoch;
    }
    if (g_coverage_work.runs && g_coverage_work.recording_generation !=
        g_method_work.generation) {
        g_coverage_work.closed = 1;
        if (coverage_publish()) {
            coverage_next();
        }
        /* A busy reader can defer closing across a toggle. Endpoints still
         * delimit the observed work; no idle time is added to run_ns. */
    }
    g_coverage_work.recording_generation = g_method_work.generation;
    if (!g_coverage_work.runs) {
        g_coverage_work.host_start_ns = g_method_work.host_start_ns;
        g_coverage_work.virtual_start_ns = g_method_work.virtual_start_ns;
    }
    g_coverage_work.host_end_ns = host_end_ns;
    g_coverage_work.virtual_end_ns = virtual_end_ns;
    uint64_t duration = host_end_ns >= g_method_work.host_start_ns ?
        host_end_ns - g_method_work.host_start_ns : 0;
    if (host_end_ns < g_method_work.host_start_ns) {
        coverage_add(&g_coverage_work.invalid_spans, 1);
    }
    coverage_add(&g_coverage_work.runs, 1);
    coverage_add(&g_coverage_work.run_ns, duration);
    coverage_add(&g_coverage_work.dispatch_ns, g_method_work.puller_dispatch_ns);
    coverage_add(&g_coverage_work.words, words);
    g_coverage_work.max_run_ns = MAX(g_coverage_work.max_run_ns, duration);
    if (duration < XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS) {
        coverage_add(&g_coverage_work.short_runs, 1);
        coverage_add(&g_coverage_work.short_run_ns, duration);
        coverage_add(&g_coverage_work.short_dispatch_ns, g_method_work.puller_dispatch_ns);
    }
    coverage_add(&g_coverage_work.draws, g_method_work.draw.completed_draws);
    coverage_add(&g_coverage_work.end_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL].total_ns);
    coverage_add(&g_coverage_work.vertex_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_SYNC_VERTEX_RAM].total_ns);
    coverage_add(&g_coverage_work.range_prep_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_RANGE_PREP].total_ns);
    coverage_add(&g_coverage_work.dirty_check_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_DIRTY_CHECK].total_ns);
    coverage_add(&g_coverage_work.surface_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_SURFACE_DOWNLOAD].total_ns);
    coverage_add(&g_coverage_work.overlap_check_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_OVERLAP_CHECK].total_ns);
    coverage_add(&g_coverage_work.vertex_finish_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_DIRTY_FINISH].total_ns);
    coverage_add(&g_coverage_work.fence_wait_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_FINISH_FENCE_WAIT].total_ns);
    coverage_add(&g_coverage_work.copy_ns, g_method_work.draw.stages[
        XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_COPY].total_ns);
    coverage_add(&g_coverage_work.requested_ranges, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_REQUESTED_RANGES]);
    coverage_add(&g_coverage_work.merged_ranges, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_MERGED_RANGES]);
    coverage_add(&g_coverage_work.tested_bytes, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_TESTED_BYTES]);
    coverage_add(&g_coverage_work.dirty_ranges, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_RANGES]);
    coverage_add(&g_coverage_work.dirty_bytes, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_BYTES]);
    coverage_add(&g_coverage_work.copy_calls, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_CALLS]);
    coverage_add(&g_coverage_work.copy_bytes, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_COPY_BYTES]);
    coverage_add(&g_coverage_work.overlap_finishes, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_OVERLAP_FINISHES]);
    coverage_add(&g_coverage_work.vertex_fence_wait_ns, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAIT_NS]);
    coverage_add(&g_coverage_work.vertex_fence_waits, g_method_work.draw.metrics[
        XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAITS]);
    coverage_add(&g_coverage_work.invalid_spans, g_method_work.draw.invalid_spans);
    coverage_add(&g_coverage_work.dropped_spans, g_method_work.draw.dropped_spans);
    if (g_method_work.draw_depth || g_method_work.draw_overflow_depth) {
        coverage_add(&g_coverage_work.invalid_spans, 1);
    }
    g_coverage_work.saturated |= g_method_work.draw.saturated;
    g_coverage_work.closed = host_end_ns >= g_coverage_work.host_start_ns &&
        host_end_ns - g_coverage_work.host_start_ns >=
            XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_WINDOW_NS;
    if (coverage_publish() && g_coverage_work.closed) {
        coverage_next();
    }
}

static int coverage_compare(const void *a, const void *b)
{
    const XemuDebugToolsPgraphCoverageEvent *x = a, *y = b;
    return (x->sequence > y->sequence) - (x->sequence < y->sequence);
}

size_t xemu_debug_tools_pgraph_pusher_coverage_snapshot(
    XemuDebugToolsPgraphCoverageEvent *events, size_t capacity,
    uint64_t *skipped_slots)
{
    size_t out = 0;
    uint64_t epoch = qatomic_read(&g_coverage_epoch);
    if (skipped_slots) *skipped_slots = 0;
    XemuDebugToolsPgraphCoverageSlot *slots = qatomic_load_acquire(&g_coverage_slots);
    if (!events || !capacity || !slots) return 0;
    for (size_t i = 0; i < XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY; i++) {
        XemuDebugToolsPgraphCoverageSlot *slot = &slots[i];
        if (qatomic_cmpxchg(&slot->busy, 0, 1) != 0) {
            if (skipped_slots) (*skipped_slots)++;
            continue;
        }
        if (slot->event.epoch == epoch && slot->event.runs) {
            if (out < capacity) events[out++] = slot->event;
            else if (skipped_slots) (*skipped_slots)++;
        }
        qatomic_store_release(&slot->busy, 0);
    }
    if (epoch != qatomic_read(&g_coverage_epoch)) {
        if (skipped_slots) (*skipped_slots)++;
        return 0; /* Clear raced the snapshot; do not mix generations. */
    }
    qsort(events, out, sizeof(*events), coverage_compare);
    return out;
}

static uint64_t elapsed_ns(uint64_t end, uint64_t start)
{
    return end >= start ? end - start : 0;
}

static void atomic_max_u64(uint64_t *value, uint64_t candidate)
{
    uint64_t current = qatomic_read(value);
    while (candidate > current) {
        uint64_t observed = qatomic_cmpxchg(value, current, candidate);
        if (observed == current) {
            return;
        }
        current = observed;
    }
}

static void pusher_method_breakdown_append(
    XemuDebugToolsPgraphPusherMethodBreakdownEvent *event)
{
    uint64_t sequence = qatomic_fetch_inc(&g_method_breakdown.total_long_runs);
    XemuDebugToolsPgraphPusherMethodBreakdownSlot *slot =
        &g_method_breakdown.slots[0][
            sequence % XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY];

    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}


static bool pusher_draw_aggregate_active(void)
{
    return qatomic_read(&g_method_breakdown.enabled) && g_method_work.active &&
        g_method_work.generation == qatomic_read(&g_method_breakdown.generation);
}

static void pusher_draw_add(uint64_t *dest, uint64_t value)
{
    if (UINT64_MAX - *dest < value) {
        *dest = UINT64_MAX;
        g_method_work.draw.saturated = 1;
    } else {
        *dest += value;
    }
}

uint64_t xemu_debug_tools_pgraph_draw_aggregate_begin(unsigned int stage)
{
    if (!pusher_draw_aggregate_active()) {
        return 0;
    }
    if (stage == 0 || stage >= XEMU_DEBUG_TOOLS_PGRAPH_DRAW_STAGE_COUNT) {
        pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
        return 0;
    }
    if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL) {
        if (g_method_work.draw_depth || g_method_work.draw_overflow_depth) {
            pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
        }
        g_method_work.draw_depth = 0;
        g_method_work.draw_overflow_depth = 0;
    } else if (g_method_work.draw_depth == 0) {
        return 0; /* Other renderer calls outside the measured END are excluded. */
    }
    if (g_method_work.draw_depth == PGRAPH_DRAW_AGGREGATE_STACK_CAPACITY ||
        g_method_work.draw_overflow_depth) {
        if (g_method_work.draw_overflow_depth != UINT32_MAX) {
            g_method_work.draw_overflow_depth++;
        }
        pusher_draw_add(&g_method_work.draw.dropped_spans, 1);
        return 0;
    }
    uint64_t now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    XemuDebugToolsPgraphDrawAggregateFrame *frame =
        &g_method_work.draw_stack[g_method_work.draw_depth++];
    frame->stage = stage;
    frame->host_start_ns = now;
    frame->child_ns = 0;
    return now;
}

uint64_t xemu_debug_tools_pgraph_draw_aggregate_end(unsigned int stage)
{
    if (!pusher_draw_aggregate_active() || g_method_work.draw_depth == 0) {
        return 0;
    }
    if (g_method_work.draw_overflow_depth) {
        g_method_work.draw_overflow_depth--;
        return 0;
    }
    XemuDebugToolsPgraphDrawAggregateFrame *frame =
        &g_method_work.draw_stack[g_method_work.draw_depth - 1];
    if (frame->stage != stage) {
        pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
        g_method_work.draw_depth = 0; /* Never invent an unmatched elapsed span. */
        return 0;
    }
    uint64_t now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    uint64_t duration = elapsed_ns(now, frame->host_start_ns);
    if (now < frame->host_start_ns || frame->child_ns > duration) {
        pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
    }
    XemuDebugToolsPgraphDrawAggregateStat *stat = &g_method_work.draw.stages[stage];
    pusher_draw_add(&stat->total_ns, duration);
    pusher_draw_add(&stat->self_ns,
                    duration > frame->child_ns ? duration - frame->child_ns : 0);
    pusher_draw_add(&stat->calls, 1);
    stat->max_ns = MAX(stat->max_ns, duration);
    if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_FINISH_FENCE_WAIT) {
        for (uint32_t i = 0; i + 1 < g_method_work.draw_depth; i++) {
            if (g_method_work.draw_stack[i].stage ==
                XEMU_DEBUG_TOOLS_PGRAPH_DRAW_VK_VERTEX_DIRTY_FINISH) {
                pusher_draw_add(&g_method_work.draw.metrics[
                    XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAIT_NS], duration);
                pusher_draw_add(&g_method_work.draw.metrics[
                    XEMU_DEBUG_TOOLS_PGRAPH_METRIC_VERTEX_DIRTY_FENCE_WAITS], 1);
                break;
            }
        }
    }
    if (--g_method_work.draw_depth) {
        pusher_draw_add(&g_method_work.draw_stack[g_method_work.draw_depth - 1].child_ns,
                        duration);
    }
    if (stage == XEMU_DEBUG_TOOLS_PGRAPH_DRAW_SET_BEGIN_END_TOTAL) {
        pusher_draw_add(&g_method_work.draw.completed_draws, 1);
        if (duration < 5000000ULL) {
            pusher_draw_add(&g_method_work.draw.sub5ms_draws, 1);
        }
    }
    return now;
}

void xemu_debug_tools_pgraph_draw_aggregate_cache(unsigned int outcome)
{
    if (!pusher_draw_aggregate_active() || g_method_work.draw_depth == 0) {
        return;
    }
    switch (outcome) {
    case XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_FAST_REUSE:
        pusher_draw_add(&g_method_work.draw.fast_reuse, 1);
        break;
    case XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_HIT:
        pusher_draw_add(&g_method_work.draw.cache_hits, 1);
        break;
    case XEMU_DEBUG_TOOLS_PGRAPH_PIPELINE_CACHE_MISS:
        pusher_draw_add(&g_method_work.draw.cache_misses, 1);
        break;
    default:
        pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
        break;
    }
}

void xemu_debug_tools_pgraph_draw_trace_metric(unsigned int metric, uint64_t value)
{
    if (!pusher_draw_aggregate_active() || !g_method_work.draw_depth) {
        return;
    }
    if (metric >= XEMU_DEBUG_TOOLS_PGRAPH_METRIC_COUNT) {
        pusher_draw_add(&g_method_work.draw.invalid_spans, 1);
        return;
    }
    pusher_draw_add(&g_method_work.draw.metrics[metric], value);
}

static void pusher_method_work_begin(uint32_t channel_id, uint32_t dma_get,
                                     uint32_t dma_put, uint64_t host_start_ns,
                                     uint64_t virtual_start_ns)
{
    if (!xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled()) {
        return;
    }
    memset(&g_method_work, 0, sizeof(g_method_work));
    g_method_work.active = 1;
    g_method_work.generation = qatomic_read(&g_method_breakdown.generation);
    g_method_work.coverage_epoch = qatomic_read(&g_coverage_epoch);
    g_method_work.thread_id = qemu_get_thread_id();
    g_method_work.channel_id = channel_id;
    g_method_work.dma_get_before = dma_get;
    g_method_work.dma_put_before = dma_put;
    g_method_work.host_start_ns = host_start_ns;
    g_method_work.virtual_start_ns = virtual_start_ns;
}

static XemuDebugToolsPgraphPusherMethodWorkStat *
pusher_method_work_find_or_add(uint32_t subchannel, uint32_t graphics_class,
                               uint32_t method, uint32_t method_base,
                               uint32_t variant, const char *method_name)
{
    for (uint32_t i = 0; i < g_method_work.method_count; ++i) {
        XemuDebugToolsPgraphPusherMethodWorkStat *stat = &g_method_work.methods[i];
        if (stat->graphics_class == graphics_class &&
            stat->subchannel == subchannel && stat->method_base == method_base &&
            stat->variant == variant) {
            return stat;
        }
    }
    if (g_method_work.method_count >=
        XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_WORK_CAPACITY) {
        return NULL;
    }
    XemuDebugToolsPgraphPusherMethodWorkStat *stat =
        &g_method_work.methods[g_method_work.method_count++];
    memset(stat, 0, sizeof(*stat));
    stat->graphics_class = graphics_class;
    stat->subchannel = subchannel;
    stat->method = method;
    stat->method_base = method_base;
    stat->variant = variant;
    if (variant == XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_BEGIN) {
        snprintf(stat->name, sizeof(stat->name), "%s(BEGIN)",
                 method_name && method_name[0] ? method_name : "<unknown>");
    } else if (variant == XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_END) {
        snprintf(stat->name, sizeof(stat->name), "%s(END)",
                 method_name && method_name[0] ? method_name : "<unknown>");
    } else {
        snprintf(stat->name, sizeof(stat->name), "%s",
                 method_name && method_name[0] ? method_name : "<unknown>");
    }
    return stat;
}

static void pusher_method_insert_top(
    XemuDebugToolsPgraphPusherMethodBreakdownEvent *event,
    const XemuDebugToolsPgraphPusherMethodWorkStat *work)
{
    XemuDebugToolsPgraphPusherMethodStat stat = { 0 };
    uint32_t pos = event->top_method_count;
    stat.total_ns = work->total_ns;
    stat.max_ns = work->max_ns;
    stat.graphics_class = work->graphics_class;
    stat.subchannel = work->subchannel;
    stat.method = work->method;
    stat.method_base = work->method_base;
    stat.variant = work->variant;
    stat.call_count = work->call_count;
    stat.words_processed = work->words_processed;
    snprintf(stat.name, sizeof(stat.name), "%s", work->name);

    if (pos > XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT) {
        pos = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT;
    }
    for (uint32_t i = 0; i < event->top_method_count; ++i) {
        if (stat.total_ns > event->top_methods[i].total_ns ||
            (stat.total_ns == event->top_methods[i].total_ns &&
             stat.max_ns > event->top_methods[i].max_ns)) {
            pos = i;
            break;
        }
    }
    if (pos >= XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT) {
        return;
    }
    uint32_t limit = event->top_method_count;
    if (limit >= XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT) {
        limit = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT - 1;
    }
    for (uint32_t i = limit; i > pos; --i) {
        event->top_methods[i] = event->top_methods[i - 1];
    }
    event->top_methods[pos] = stat;
    if (event->top_method_count < XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_TOP_COUNT) {
        event->top_method_count++;
    }
}

static void pusher_method_work_finish(uint64_t host_end_ns,
                                      uint64_t virtual_end_ns,
                                      uint32_t dma_get, uint32_t dma_put,
                                      uint32_t method_words_processed)
{
    XemuDebugToolsPgraphPusherMethodBreakdownEvent event = { 0 };
    if (!g_method_work.active ||
        g_method_work.thread_id != qemu_get_thread_id()) {
        memset(&g_method_work, 0, sizeof(g_method_work));
        return;
    }
    g_method_work.active = 0;
    if (!xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled()) {
        return;
    }
    if (g_method_work.generation != qatomic_read(&g_method_breakdown.generation)) {
        return;
    }
    event.host_start_ns = g_method_work.host_start_ns;
    event.host_end_ns = host_end_ns;
    event.virtual_start_ns = g_method_work.virtual_start_ns;
    event.virtual_end_ns = virtual_end_ns;
    event.duration_ns = elapsed_ns(host_end_ns, g_method_work.host_start_ns);
    pusher_coverage_finish(host_end_ns, virtual_end_ns, method_words_processed);
    if (event.duration_ns < XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS) {
        return;
    }
    event.draw = g_method_work.draw;
    if (g_method_work.draw_depth || g_method_work.draw_overflow_depth) {
        event.draw.invalid_spans++;
    }
    event.puller_dispatch_ns = g_method_work.puller_dispatch_ns;
    event.parser_other_ns = event.duration_ns > event.puller_dispatch_ns
        ? event.duration_ns - event.puller_dispatch_ns : 0;
    event.nv097_puller_ns = g_method_work.nv097_puller_ns;
    event.non_nv097_puller_ns = g_method_work.non_nv097_puller_ns;
    event.unclassified_puller_ns = g_method_work.unclassified_puller_ns;
    event.untracked_nv097_ns = g_method_work.untracked_nv097_ns;
    event.channel_id = g_method_work.channel_id;
    event.dma_get_before = g_method_work.dma_get_before;
    event.dma_get_after = dma_get;
    event.dma_put_before = g_method_work.dma_put_before;
    event.dma_put_after = dma_put;
    event.method_words_processed = method_words_processed;
    event.puller_calls = g_method_work.puller_calls;
    event.nv097_calls = g_method_work.nv097_calls;
    event.non_nv097_calls = g_method_work.non_nv097_calls;
    event.unclassified_calls = g_method_work.unclassified_calls;
    event.unique_nv097_methods = g_method_work.method_count;
    event.untracked_nv097_calls = g_method_work.untracked_nv097_calls;
    for (uint32_t i = 0; i < g_method_work.method_count; ++i) {
        pusher_method_insert_top(&event, &g_method_work.methods[i]);
    }
    qatomic_set(&g_method_breakdown.last_run_ns, event.duration_ns);
    qatomic_set(&g_method_breakdown.last_puller_dispatch_ns,
                event.puller_dispatch_ns);
    qatomic_set(&g_method_breakdown.last_parser_other_ns, event.parser_other_ns);
    qatomic_set(&g_method_breakdown.last_puller_calls, event.puller_calls);
    qatomic_set(&g_method_breakdown.last_nv097_calls, event.nv097_calls);
    qatomic_set(&g_method_breakdown.last_unique_nv097_methods,
                event.unique_nv097_methods);
    atomic_max_u64(&g_method_breakdown.worst_run_ns, event.duration_ns);
    atomic_max_u64(&g_method_breakdown.worst_puller_dispatch_ns,
                   event.puller_dispatch_ns);
    atomic_max_u64(&g_method_breakdown.worst_parser_other_ns,
                   event.parser_other_ns);
    pusher_method_breakdown_append(&event);
}

static void pusher_progress_append(
    XemuDebugToolsPgraphPusherProgressEvent *event)
{
    uint64_t sequence = qatomic_fetch_inc(&g_pusher_progress.total_events);
    const size_t capacity =
        xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity();
    XemuDebugToolsPgraphPusherProgressSlot *slot =
        &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_pusher_progress.slots,
            XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY,
            sequence % capacity);

    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}

int xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled(void)
{
    return qatomic_read(&g_pusher_progress.enabled);
}


int xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled(void)
{
    return qatomic_read(&g_method_breakdown.enabled);
}

void xemu_debug_tools_pgraph_pusher_progress_note_dma_put(
    uint32_t channel_id, uint32_t dma_get, uint32_t old_dma_put,
    uint32_t new_dma_put)
{
    XemuDebugToolsPgraphPusherProgressEvent event = { 0 };

    if (!xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled()) {
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_DMA_PUT;
    event.host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.host_end_ns = event.host_start_ns;
    event.virtual_start_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.virtual_end_ns = event.virtual_start_ns;
    event.thread_id = qemu_get_thread_id();
    event.channel_id = channel_id;
    event.dma_get_before = dma_get;
    event.dma_get_after = dma_get;
    event.dma_put_before = old_dma_put;
    event.dma_put_after = new_dma_put;
    xemu_debug_tools_diagnostics_current_cpu_context(
        &event.cpu_index, &event.guest_pc, &event.guest_pc_valid);

    qatomic_set(&g_pusher_progress.last_dma_get, dma_get);
    qatomic_set(&g_pusher_progress.last_dma_put, new_dma_put);
    qatomic_set(&g_pusher_progress.last_dma_put_host_ns, event.host_end_ns);
    qatomic_set(&g_pusher_progress.last_dma_put_channel, channel_id);
    qatomic_inc(&g_pusher_progress.dma_put_events);
    pusher_progress_append(&event);
}

void xemu_debug_tools_pgraph_pusher_progress_pfifo_begin(
    XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t channel_id,
    uint32_t dma_get, uint32_t dma_put)
{
    if (scope == NULL) {
        return;
    }
    memset(scope, 0, sizeof(*scope));
    if ((!xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled() &&
         !xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled()) ||
        dma_get == dma_put) {
        return;
    }
    scope->host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    scope->virtual_start_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    scope->dma_get_before = dma_get;
    scope->dma_put_before = dma_put;
    scope->channel_id = channel_id;
    if (xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled()) {
        qatomic_set(&g_pusher_progress.last_dma_get, dma_get);
        qatomic_set(&g_pusher_progress.last_dma_put, dma_put);
    }
    pusher_method_work_begin(channel_id, dma_get, dma_put,
                             scope->host_start_ns, scope->virtual_start_ns);
    scope->active = 1;
}

void xemu_debug_tools_pgraph_pusher_progress_pfifo_end(
    XemuDebugToolsPgraphPusherPfifoScope *scope, uint32_t dma_get,
    uint32_t dma_put, uint32_t method_words_processed,
    uint32_t waiting_for_nop, uint32_t waiting_for_flip,
    uint32_t fifo_access)
{
    XemuDebugToolsPgraphPusherProgressEvent event = { 0 };
    uint64_t host_end_ns;
    uint64_t virtual_end_ns;

    if (scope == NULL || !scope->active) {
        return;
    }
    scope->active = 0;
    host_end_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    virtual_end_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

    pusher_method_work_finish(host_end_ns, virtual_end_ns, dma_get, dma_put,
                              method_words_processed);

    if (!xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled()) {
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PFIFO_RUN;
    event.host_start_ns = scope->host_start_ns;
    event.host_end_ns = host_end_ns;
    event.virtual_start_ns = scope->virtual_start_ns;
    event.virtual_end_ns = virtual_end_ns;
    event.duration_ns = elapsed_ns(event.host_end_ns, event.host_start_ns);
    event.thread_id = qemu_get_thread_id();
    event.cpu_index = -1;
    event.channel_id = scope->channel_id;
    event.dma_get_before = scope->dma_get_before;
    event.dma_get_after = dma_get;
    event.dma_put_before = scope->dma_put_before;
    event.dma_put_after = dma_put;
    event.method_words_processed = method_words_processed;
    event.waiting_for_nop = waiting_for_nop;
    event.waiting_for_flip = waiting_for_flip;
    event.fifo_access = fifo_access;

    qatomic_set(&g_pusher_progress.last_dma_get, dma_get);
    qatomic_set(&g_pusher_progress.last_dma_put, dma_put);
    qatomic_inc(&g_pusher_progress.pfifo_run_events);
    atomic_max_u64(&g_pusher_progress.worst_pfifo_run_ns, event.duration_ns);
    pusher_progress_append(&event);
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_begin(
    XemuDebugToolsPgraphPusherPullerScope *scope)
{
    if (scope == NULL) {
        return;
    }
    memset(scope, 0, sizeof(*scope));
    if (!xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled() ||
        g_method_work.generation != qatomic_read(&g_method_breakdown.generation) ||
        !g_method_work.active ||
        g_method_work.thread_id != qemu_get_thread_id()) {
        return;
    }
    g_method_work.pending_identity_valid = 0;
    g_method_work.pending_method_name = NULL;
    scope->host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    scope->active = 1;
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_note_method(
    uint32_t subchannel, uint32_t graphics_class, uint32_t method,
    uint32_t method_base, uint32_t parameter, const char *method_name)
{
    if (!xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled() ||
        g_method_work.generation != qatomic_read(&g_method_breakdown.generation) ||
        !g_method_work.active ||
        g_method_work.thread_id != qemu_get_thread_id()) {
        return;
    }
    g_method_work.pending_subchannel = subchannel;
    g_method_work.pending_graphics_class = graphics_class;
    g_method_work.pending_method = method;
    g_method_work.pending_method_base = method_base;
    g_method_work.pending_parameter = parameter;
    g_method_work.pending_method_name = method_name;
    g_method_work.pending_identity_valid = 1;
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_puller_end(
    XemuDebugToolsPgraphPusherPullerScope *scope, uint32_t words_processed)
{
    uint64_t duration_ns;
    XemuDebugToolsPgraphPusherMethodWorkStat *stat;
    if (scope == NULL || !scope->active) {
        return;
    }
    scope->active = 0;
    if (!xemu_debug_tools_pgraph_pusher_method_breakdown_trace_is_enabled() ||
        g_method_work.generation != qatomic_read(&g_method_breakdown.generation) ||
        !g_method_work.active ||
        g_method_work.thread_id != qemu_get_thread_id()) {
        return;
    }
    duration_ns = elapsed_ns(qemu_clock_get_ns(QEMU_CLOCK_HOST),
                             scope->host_start_ns);
    g_method_work.puller_dispatch_ns += duration_ns;
    g_method_work.puller_calls++;
    if (!g_method_work.pending_identity_valid) {
        g_method_work.unclassified_puller_ns += duration_ns;
        g_method_work.unclassified_calls++;
        return;
    }
    if (g_method_work.pending_graphics_class != 0x97u) {
        g_method_work.non_nv097_puller_ns += duration_ns;
        g_method_work.non_nv097_calls++;
        return;
    }
    g_method_work.nv097_puller_ns += duration_ns;
    g_method_work.nv097_calls++;
    uint32_t variant = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_NORMAL;
    if (g_method_work.pending_graphics_class == 0x97u &&
        g_method_work.pending_method_base == 0x17FCu) {
        variant = g_method_work.pending_parameter == 0
            ? XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_END
            : XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_VARIANT_SET_BEGIN_END_BEGIN;
    }
    stat = pusher_method_work_find_or_add(
        g_method_work.pending_subchannel,
        g_method_work.pending_graphics_class,
        g_method_work.pending_method,
        g_method_work.pending_method_base,
        variant, g_method_work.pending_method_name);
    if (stat == NULL) {
        g_method_work.untracked_nv097_ns += duration_ns;
        g_method_work.untracked_nv097_calls++;
        return;
    }
    stat->total_ns += duration_ns;
    if (duration_ns > stat->max_ns) {
        stat->max_ns = duration_ns;
    }
    stat->call_count++;
    stat->words_processed += words_processed;
}

void xemu_debug_tools_pgraph_pusher_progress_semaphore_begin(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t dma_instance,
    uint32_t semaphore_offset, uint32_t value)
{
    if (scope == NULL) {
        return;
    }
    memset(scope, 0, sizeof(*scope));
    if (!xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled()) {
        return;
    }
    scope->host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    scope->virtual_start_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    scope->last_dma_put_host_ns =
        qatomic_read(&g_pusher_progress.last_dma_put_host_ns);
    scope->last_dma_put_channel =
        qatomic_read(&g_pusher_progress.last_dma_put_channel);
    scope->dma_instance = dma_instance;
    scope->semaphore_offset = semaphore_offset;
    scope->requested_value = value;
    scope->dma_get_before = qatomic_read(&g_pusher_progress.last_dma_get);
    scope->dma_put_before = qatomic_read(&g_pusher_progress.last_dma_put);
    scope->active = 1;
}

void xemu_debug_tools_pgraph_pusher_progress_semaphore_target(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t physical_address,
    uint32_t guest_virtual_address, uint32_t previous_value)
{
    if (scope == NULL || !scope->active) {
        return;
    }
    scope->semaphore_phys = physical_address;
    scope->semaphore_guest_va = guest_virtual_address;
    scope->previous_value = previous_value;
    scope->target_valid = 1;
}

void xemu_debug_tools_pgraph_pusher_progress_semaphore_prewrite(
    XemuDebugToolsPgraphPusherSemaphoreScope *scope, uint32_t waiting_for_nop,
    uint32_t waiting_for_flip)
{
    XemuDebugToolsPgraphPusherProgressEvent event = { 0 };

    if (scope == NULL || !scope->active) {
        return;
    }
    scope->active = 0;
    if (!xemu_debug_tools_pgraph_pusher_progress_trace_is_enabled()) {
        return;
    }

    event.event_type = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_SEMAPHORE_RELEASE;
    event.host_start_ns = scope->host_start_ns;
    event.host_end_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.virtual_start_ns = scope->virtual_start_ns;
    event.virtual_end_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.duration_ns = elapsed_ns(event.host_end_ns, event.host_start_ns);
    if (scope->last_dma_put_host_ns != 0 &&
        event.host_end_ns >= scope->last_dma_put_host_ns) {
        event.dma_put_to_event_ns =
            event.host_end_ns - scope->last_dma_put_host_ns;
    }
    event.thread_id = qemu_get_thread_id();
    event.cpu_index = -1;
    event.channel_id = scope->last_dma_put_channel;
    event.dma_get_before = scope->dma_get_before;
    event.dma_get_after = qatomic_read(&g_pusher_progress.last_dma_get);
    event.dma_put_before = scope->dma_put_before;
    event.dma_put_after = qatomic_read(&g_pusher_progress.last_dma_put);
    event.dma_instance = scope->dma_instance;
    event.semaphore_offset = scope->semaphore_offset;
    event.semaphore_phys = scope->semaphore_phys;
    event.semaphore_guest_va = scope->semaphore_guest_va;
    event.semaphore_old_value = scope->previous_value;
    event.semaphore_new_value = scope->requested_value;
    event.semaphore_target_valid = scope->target_valid;
    event.waiting_for_nop = waiting_for_nop;
    event.waiting_for_flip = waiting_for_flip;
    event.fifo_access = 1;

    if (scope->target_valid) {
        qatomic_set(&g_pusher_progress.last_semaphore_phys,
                    scope->semaphore_phys);
        qatomic_set(&g_pusher_progress.last_semaphore_guest_va,
                    scope->semaphore_guest_va);
        qatomic_set(&g_pusher_progress.last_semaphore_value,
                    scope->requested_value);
        qatomic_set(&g_pusher_progress.last_semaphore_target_valid, 1);
    }
    qatomic_inc(&g_pusher_progress.semaphore_release_events);
    atomic_max_u64(&g_pusher_progress.worst_semaphore_release_ns,
                   event.duration_ns);
    qatomic_set(&g_pusher_progress.last_dma_put_to_semaphore_ns,
                event.dma_put_to_event_ns);
    atomic_max_u64(&g_pusher_progress.worst_dma_put_to_semaphore_ns,
                   event.dma_put_to_event_ns);
    pusher_progress_append(&event);
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_set_enabled(int enabled)
{
    if (enabled && qatomic_load_acquire(&g_coverage_slots) == NULL) {
        XemuDebugToolsPgraphCoverageSlot *slots = g_new0(
            XemuDebugToolsPgraphCoverageSlot, XEMU_DEBUG_TOOLS_PGRAPH_COVERAGE_CAPACITY);
        if (!slots) return;
        qatomic_store_release(&g_coverage_slots, slots);
    }
    if (enabled && g_method_breakdown.slots[0] == NULL) {
        g_method_breakdown.slots[0] = g_new0(
            XemuDebugToolsPgraphPusherMethodBreakdownSlot,
            XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY);
        if (g_method_breakdown.slots[0] == NULL) {
            return;
        }
    }
    qatomic_inc(&g_method_breakdown.generation);
    qatomic_set(&g_method_breakdown.enabled, enabled ? 1 : 0);
    if (!enabled) {
        memset(&g_method_work, 0, sizeof(g_method_work));
    }
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_clear(void)
{
    qatomic_inc(&g_method_breakdown.generation);
    qatomic_inc(&g_coverage_epoch);
    qatomic_set(&g_method_breakdown.total_long_runs, 0);
    qatomic_set(&g_method_breakdown.worst_run_ns, 0);
    qatomic_set(&g_method_breakdown.worst_puller_dispatch_ns, 0);
    qatomic_set(&g_method_breakdown.worst_parser_other_ns, 0);
    qatomic_set(&g_method_breakdown.last_run_ns, 0);
    qatomic_set(&g_method_breakdown.last_puller_dispatch_ns, 0);
    qatomic_set(&g_method_breakdown.last_parser_other_ns, 0);
    qatomic_set(&g_method_breakdown.last_puller_calls, 0);
    qatomic_set(&g_method_breakdown.last_nv097_calls, 0);
    qatomic_set(&g_method_breakdown.last_unique_nv097_methods, 0);
    memset(&g_method_work, 0, sizeof(g_method_work));
    if (g_method_breakdown.slots[0] != NULL) {
        memset(g_method_breakdown.slots[0], 0,
               sizeof(*g_method_breakdown.slots[0]) *
               XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY);
    }
}

void xemu_debug_tools_pgraph_pusher_method_breakdown_trace_get_status(
    XemuDebugToolsPgraphPusherMethodBreakdownStatus *status)
{
    uint64_t total;
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    total = qatomic_read(&g_method_breakdown.total_long_runs);
    status->enabled = qatomic_read(&g_method_breakdown.enabled);
    status->capacity = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY;
    status->threshold_ns = XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_LONG_RUN_NS;
    status->total_long_runs = total;
    status->count = MIN(total,
                        (uint64_t)XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY);
    status->overwritten_events = total > status->capacity
        ? total - status->capacity : 0;
    status->worst_run_ns = qatomic_read(&g_method_breakdown.worst_run_ns);
    status->worst_puller_dispatch_ns =
        qatomic_read(&g_method_breakdown.worst_puller_dispatch_ns);
    status->worst_parser_other_ns =
        qatomic_read(&g_method_breakdown.worst_parser_other_ns);
    status->last_run_ns = qatomic_read(&g_method_breakdown.last_run_ns);
    status->last_puller_dispatch_ns =
        qatomic_read(&g_method_breakdown.last_puller_dispatch_ns);
    status->last_parser_other_ns =
        qatomic_read(&g_method_breakdown.last_parser_other_ns);
    status->last_puller_calls = qatomic_read(&g_method_breakdown.last_puller_calls);
    status->last_nv097_calls = qatomic_read(&g_method_breakdown.last_nv097_calls);
    status->last_unique_nv097_methods =
        qatomic_read(&g_method_breakdown.last_unique_nv097_methods);
}

size_t xemu_debug_tools_pgraph_pusher_method_breakdown_trace_snapshot(
    XemuDebugToolsPgraphPusherMethodBreakdownEvent *events, size_t capacity)
{
    uint64_t total;
    uint64_t available;
    uint64_t first;
    size_t count;
    size_t out = 0;
    if (events == NULL || capacity == 0 || g_method_breakdown.slots[0] == NULL) {
        return 0;
    }
    total = qatomic_read(&g_method_breakdown.total_long_runs);
    available = MIN(total,
                    (uint64_t)XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY);
    count = MIN((uint64_t)capacity, available);
    first = total - count;
    for (size_t i = 0; i < count; ++i) {
        const uint64_t sequence = first + i;
        XemuDebugToolsPgraphPusherMethodBreakdownSlot *slot =
            &g_method_breakdown.slots[0][
                sequence % XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_METHOD_BREAKDOWN_CAPACITY];
        const uint64_t committed = qatomic_read(&slot->committed_sequence_plus_one);
        if (committed != sequence + 1) {
            continue;
        }
        smp_rmb();
        events[out++] = slot->event;
    }
    return out;
}

void xemu_debug_tools_pgraph_pusher_progress_trace_set_enabled(int enabled)
{
    if (enabled) {
        bool ok;
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_pusher_progress.slots,
            XemuDebugToolsPgraphPusherProgressSlot,
            XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY,
            xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier(),
            ok);
        if (!ok) {
            return;
        }
    }
    qatomic_set(&g_pusher_progress.enabled, enabled ? 1 : 0);
}

int xemu_debug_tools_pgraph_pusher_progress_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    bool ok;
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_pusher_progress.slots, XemuDebugToolsPgraphPusherProgressSlot,
        XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY, multiplier, ok);
    if (!ok) {
        return 0;
    }
    qatomic_set(&g_pusher_progress.buffer_multiplier, multiplier);
    xemu_debug_tools_pgraph_pusher_progress_trace_clear();
    return 1;
}

uint32_t xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier(void)
{
    uint32_t multiplier = qatomic_read(&g_pusher_progress.buffer_multiplier);
    return multiplier ? multiplier : 1;
}

size_t xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY,
        xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier());
}

void xemu_debug_tools_pgraph_pusher_progress_trace_clear(void)
{
    qatomic_set(&g_pusher_progress.total_events, 0);
    qatomic_set(&g_pusher_progress.dma_put_events, 0);
    qatomic_set(&g_pusher_progress.pfifo_run_events, 0);
    qatomic_set(&g_pusher_progress.semaphore_release_events, 0);
    qatomic_set(&g_pusher_progress.worst_pfifo_run_ns, 0);
    qatomic_set(&g_pusher_progress.worst_semaphore_release_ns, 0);
    qatomic_set(&g_pusher_progress.worst_dma_put_to_semaphore_ns, 0);
    qatomic_set(&g_pusher_progress.last_dma_put_to_semaphore_ns, 0);
    qatomic_set(&g_pusher_progress.last_dma_put_host_ns, 0);
    qatomic_set(&g_pusher_progress.last_dma_put_channel, 0);
    qatomic_set(&g_pusher_progress.last_dma_get, 0);
    qatomic_set(&g_pusher_progress.last_dma_put, 0);
    qatomic_set(&g_pusher_progress.last_semaphore_phys, 0);
    qatomic_set(&g_pusher_progress.last_semaphore_guest_va, 0);
    qatomic_set(&g_pusher_progress.last_semaphore_value, 0);
    qatomic_set(&g_pusher_progress.last_semaphore_target_valid, 0);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_pusher_progress.slots, XemuDebugToolsPgraphPusherProgressSlot,
        XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY,
        xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_multiplier());
}

void xemu_debug_tools_pgraph_pusher_progress_trace_get_status(
    XemuDebugToolsPgraphPusherProgressStatus *status)
{
    uint64_t total;
    size_t capacity;
    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    total = qatomic_read(&g_pusher_progress.total_events);
    capacity = xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity();
    status->enabled = qatomic_read(&g_pusher_progress.enabled);
    status->total_events = total;
    status->count = MIN(total, (uint64_t)capacity);
    status->overwritten_events = total > capacity ? total - capacity : 0;
    status->dma_put_events = qatomic_read(&g_pusher_progress.dma_put_events);
    status->pfifo_run_events = qatomic_read(&g_pusher_progress.pfifo_run_events);
    status->semaphore_release_events =
        qatomic_read(&g_pusher_progress.semaphore_release_events);
    status->worst_pfifo_run_ns = qatomic_read(&g_pusher_progress.worst_pfifo_run_ns);
    status->worst_semaphore_release_ns =
        qatomic_read(&g_pusher_progress.worst_semaphore_release_ns);
    status->worst_dma_put_to_semaphore_ns =
        qatomic_read(&g_pusher_progress.worst_dma_put_to_semaphore_ns);
    status->last_dma_put_to_semaphore_ns =
        qatomic_read(&g_pusher_progress.last_dma_put_to_semaphore_ns);
    status->last_dma_get = qatomic_read(&g_pusher_progress.last_dma_get);
    status->last_dma_put = qatomic_read(&g_pusher_progress.last_dma_put);
    status->last_semaphore_phys = qatomic_read(&g_pusher_progress.last_semaphore_phys);
    status->last_semaphore_guest_va =
        qatomic_read(&g_pusher_progress.last_semaphore_guest_va);
    status->last_semaphore_value =
        qatomic_read(&g_pusher_progress.last_semaphore_value);
    status->last_semaphore_target_valid =
        qatomic_read(&g_pusher_progress.last_semaphore_target_valid);
}

size_t xemu_debug_tools_pgraph_pusher_progress_trace_snapshot(
    XemuDebugToolsPgraphPusherProgressEvent *events, size_t capacity)
{
    uint64_t total;
    uint64_t available;
    uint64_t first;
    size_t ring_capacity;
    size_t count;
    size_t out = 0;

    if (events == NULL || capacity == 0) {
        return 0;
    }

    total = qatomic_read(&g_pusher_progress.total_events);
    ring_capacity = xemu_debug_tools_pgraph_pusher_progress_trace_get_buffer_capacity();
    available = MIN(total, (uint64_t)ring_capacity);
    count = MIN((uint64_t)capacity, available);
    first = total - count;

    for (size_t i = 0; i < count; ++i) {
        const uint64_t sequence = first + i;
        XemuDebugToolsPgraphPusherProgressSlot *slot =
            &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
                g_pusher_progress.slots,
                XEMU_DEBUG_TOOLS_PGRAPH_PUSHER_PROGRESS_CAPACITY,
                sequence % ring_capacity);
        const uint64_t committed = qatomic_read(&slot->committed_sequence_plus_one);
        if (committed != sequence + 1) {
            continue;
        }
        smp_rmb();
        events[out++] = slot->event;
    }
    return out;
}
