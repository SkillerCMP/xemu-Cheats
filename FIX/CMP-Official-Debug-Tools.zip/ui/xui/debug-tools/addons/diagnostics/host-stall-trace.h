/* Info: Patch 305.4 Windows host-stall / page-fault correlation trace. */
#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct CPUState CPUState;

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_HOST_STALL_SAMPLE_INTERVAL_NS (250 * 1000ULL)
#define XEMU_DEBUG_TOOLS_HOST_STALL_OFFCPU_THRESHOLD_NS (500 * 1000ULL)
#define XEMU_DEBUG_TOOLS_HOST_STALL_BUSY_THRESHOLD_NS (2 * 1000 * 1000ULL)
#define XEMU_DEBUG_TOOLS_HOST_STALL_PROCESS_SAMPLE_NS (2 * 1000 * 1000ULL)
#define XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_CAPACITY 256

typedef enum XemuDebugToolsHostStallEventType {
    XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_NONE = 0,
    XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_VCPU_SAMPLE,
    XEMU_DEBUG_TOOLS_HOST_STALL_EVENT_MAIN_LOOP_WAIT,
} XemuDebugToolsHostStallEventType;

typedef enum XemuDebugToolsHostStallClassification {
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_NONE = 0,
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_HOST_OFFCPU,
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_THREAD_BUSY,
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MIXED,
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_MAIN_LOOP_EXCESS,
    XEMU_DEBUG_TOOLS_HOST_STALL_CLASS_PAGEFAULT_CORRELATED,
} XemuDebugToolsHostStallClassification;

typedef struct XemuDebugToolsHostStallEvent {
    uint64_t sequence;
    uint32_t type;
    uint32_t classification;
    uint32_t thread_id;
    uint32_t platform_counters_valid;

    uint64_t host_before_ns;
    uint64_t host_after_ns;
    uint64_t wall_span_ns;
    uint64_t thread_cpu_ns;
    uint64_t off_cpu_ns;
    uint64_t thread_cycles_delta;
    uint32_t thread_cpu_valid;
    uint32_t thread_cycles_valid;

    int64_t requested_timeout_ns;
    int64_t wait_excess_ns;

    uint64_t qemu_virtual_before_ns;
    uint64_t qemu_virtual_after_ns;
    uint32_t guest_pc_before;
    uint32_t guest_pc_after;

    uint64_t process_sample_age_ns;
    uint64_t page_fault_count_before;
    uint64_t page_fault_count_after;
    uint64_t page_fault_delta;
    uint64_t working_set_before;
    uint64_t working_set_after;
    uint64_t private_usage_before;
    uint64_t private_usage_after;
    uint64_t available_phys_before;
    uint64_t available_phys_after;
    uint32_t memory_load_before;
    uint32_t memory_load_after;
    uint32_t process_memory_valid;

    uint64_t input_sequence;
    uint64_t d3d_sequence;
    uint64_t callback_expected_due_ns;
    int64_t callback_due_delta_ns;
    uint32_t callback_watch_armed;
    uint32_t callback_overdue_latched;
    uint32_t callback_target;
    uint32_t callback_state_valid;

    uint32_t ptimer_irq_active;
    uint64_t ptimer_irq_set_virtual_ns;
    uint64_t ptimer_irq_age_ns;
    uint32_t ptimer_state_valid;
} XemuDebugToolsHostStallEvent;

typedef struct XemuDebugToolsHostStallStatus {
    int enabled;
    int windows_supported;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t vcpu_events;
    uint64_t main_loop_events;
    uint64_t pagefault_correlated_events;
    uint64_t offcpu_events;
    uint64_t busy_events;
    uint64_t worst_vcpu_wall_ns;
    uint64_t worst_vcpu_offcpu_ns;
    uint64_t worst_main_loop_excess_ns;
    uint64_t worst_page_fault_delta;
    uint64_t sample_interval_ns;
    uint64_t offcpu_threshold_ns;
    uint64_t busy_threshold_ns;
    uint64_t process_sample_interval_ns;
} XemuDebugToolsHostStallStatus;

int xemu_debug_tools_host_stall_trace_active(void);
void xemu_debug_tools_host_stall_trace_set_enabled(int enabled);
void xemu_debug_tools_host_stall_trace_clear(void);
void xemu_debug_tools_host_stall_note_vcpu(CPUState *cpu);
void xemu_debug_tools_host_stall_main_loop_wait_begin(int64_t timeout_ns);
void xemu_debug_tools_host_stall_main_loop_wait_end(int64_t timeout_ns);
void xemu_debug_tools_host_stall_trace_get_status(
    XemuDebugToolsHostStallStatus *status);
size_t xemu_debug_tools_host_stall_trace_snapshot(
    XemuDebugToolsHostStallEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
