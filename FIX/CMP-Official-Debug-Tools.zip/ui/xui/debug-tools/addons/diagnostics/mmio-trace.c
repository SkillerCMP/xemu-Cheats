/* Info: MMIO tracing is lock-free and commits only accesses lasting at least 1 ms. */
#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/timer.h"
#include "qemu/thread.h"
#include "hw/core/cpu.h"
#include "system/memory.h"
#include "qom/object.h"

#include "mmio-trace.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsMmioTraceSlot {
    uint64_t committed_sequence_plus_one;
    XemuDebugToolsMmioTraceEvent event;
} XemuDebugToolsMmioTraceSlot;

static struct {
    int enabled;
    uint64_t total_events;
    uint32_t buffer_multiplier;
    XemuDebugToolsMmioTraceSlot *slots[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} mmio_trace = { .buffer_multiplier = 1 };

static void mmio_trace_copy_name(char dst[XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX],
                                 const char *src)
{
    if (src == NULL || src[0] == '\0') {
        g_strlcpy(dst, "<unknown>", XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX);
        return;
    }
    g_strlcpy(dst, src, XEMU_DEBUG_TOOLS_MMIO_TRACE_NAME_MAX);
}

static void mmio_trace_append(XemuDebugToolsMmioTraceEvent *event)
{
    uint64_t sequence;
    XemuDebugToolsMmioTraceSlot *slot;

    sequence = qatomic_fetch_inc(&mmio_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_mmio_trace_get_buffer_capacity();
    slot = &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(mmio_trace.slots, XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY, sequence % trace_capacity);
    qatomic_set(&slot->committed_sequence_plus_one, 0);
    event->sequence = sequence;
    slot->event = *event;
    smp_wmb();
    qatomic_set(&slot->committed_sequence_plus_one, sequence + 1);
}

void xemu_debug_tools_mmio_trace_begin(XemuDebugToolsMmioTraceScope *scope,
                                       const void *memory_region,
                                       uint64_t region_offset,
                                       uint64_t guest_vaddr,
                                       uint64_t guest_paddr,
                                       uint32_t size,
                                       uint32_t access_type)
{
    if (scope == NULL) {
        return;
    }
    scope->active = 0;
    if (!qatomic_read(&mmio_trace.enabled)) {
        return;
    }

    scope->memory_region = memory_region;
    scope->thread_id = qemu_get_thread_id();
    scope->cpu_index = -1;
    scope->guest_pc_start = 0;
    scope->guest_pc_start_valid = 0;
    if (current_cpu != NULL) {
        scope->cpu_index = current_cpu->cpu_index;
        if (current_cpu->cc != NULL && current_cpu->cc->get_pc != NULL) {
            scope->guest_pc_start = current_cpu->cc->get_pc(current_cpu);
            scope->guest_pc_start_valid = 1;
        }
    }
    scope->region_offset = region_offset;
    scope->guest_vaddr = guest_vaddr;
    scope->guest_paddr = guest_paddr;
    scope->size = size;
    scope->access_type = access_type;
    scope->virtual_start_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    scope->host_start_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    scope->active = 1;
}

void xemu_debug_tools_mmio_trace_end(XemuDebugToolsMmioTraceScope *scope)
{
    XemuDebugToolsMmioTraceEvent event = { 0 };
    MemoryRegion *mr;
    CPUState *cpu;
    uint64_t host_end_ns;
    uint64_t virtual_end_ns;
    uint64_t duration_host_ns;
    hwaddr resolved_offset;

    if (scope == NULL || !scope->active) {
        return;
    }
    scope->active = 0;
    if (!qatomic_read(&mmio_trace.enabled)) {
        return;
    }

    host_end_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    if (host_end_ns < scope->host_start_ns) {
        return;
    }
    duration_host_ns = host_end_ns - scope->host_start_ns;
    if (duration_host_ns < XEMU_DEBUG_TOOLS_MMIO_TRACE_LONG_NS) {
        return;
    }
    virtual_end_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

    event.host_start_ns = scope->host_start_ns;
    event.host_end_ns = host_end_ns;
    event.duration_host_ns = duration_host_ns;
    event.qemu_virtual_start_ns = scope->virtual_start_ns;
    event.qemu_virtual_end_ns = virtual_end_ns;
    if (virtual_end_ns >= scope->virtual_start_ns) {
        event.duration_virtual_ns = virtual_end_ns - scope->virtual_start_ns;
    }
    event.guest_vaddr = scope->guest_vaddr;
    event.guest_paddr = scope->guest_paddr;
    event.region_offset = scope->region_offset;
    event.size = scope->size;
    event.access_type = scope->access_type;
    event.thread_id = scope->thread_id;
    event.cpu_index = scope->cpu_index;
    event.guest_pc_start = scope->guest_pc_start;
    event.guest_pc_start_valid = scope->guest_pc_start_valid;

    cpu = current_cpu;
    if (cpu != NULL && cpu->cc != NULL && cpu->cc->get_pc != NULL) {
        event.guest_pc_end = cpu->cc->get_pc(cpu);
        event.guest_pc_end_valid = 1;
    }

    mr = (MemoryRegion *)scope->memory_region;
    resolved_offset = scope->region_offset;
    while (mr != NULL && mr->alias != NULL) {
        resolved_offset += mr->alias_offset;
        mr = mr->alias;
    }
    event.region_offset = resolved_offset;
    if (mr != NULL) {
        mmio_trace_copy_name(event.region_name, memory_region_name(mr));
        if (mr->owner != NULL) {
            mmio_trace_copy_name(event.owner_type,
                                 object_get_typename(OBJECT(mr->owner)));
        } else {
            mmio_trace_copy_name(event.owner_type, "<no-owner>");
        }
    } else {
        mmio_trace_copy_name(event.region_name, "<null-region>");
        mmio_trace_copy_name(event.owner_type, "<null-owner>");
    }

    mmio_trace_append(&event);
}

void xemu_debug_tools_mmio_trace_set_enabled(int enabled)
{
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(mmio_trace.slots, XemuDebugToolsMmioTraceSlot, XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY, xemu_debug_tools_mmio_trace_get_buffer_multiplier(), ok); if (!ok) return; }
    qatomic_set(&mmio_trace.enabled, enabled ? 1 : 0);
}

int xemu_debug_tools_mmio_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(mmio_trace.slots,XemuDebugToolsMmioTraceSlot,XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY,multiplier,ok);
    if (!ok) return 0;
    qatomic_set(&mmio_trace.buffer_multiplier,multiplier);
    xemu_debug_tools_mmio_trace_clear();
    return 1;
}
uint32_t xemu_debug_tools_mmio_trace_get_buffer_multiplier(void){uint32_t m=qatomic_read(&mmio_trace.buffer_multiplier);return m?m:1;}
size_t xemu_debug_tools_mmio_trace_get_buffer_capacity(void){return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY,xemu_debug_tools_mmio_trace_get_buffer_multiplier());}

void xemu_debug_tools_mmio_trace_clear(void)
{
    qatomic_set(&mmio_trace.total_events, 0);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(mmio_trace.slots, XemuDebugToolsMmioTraceSlot, XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY, xemu_debug_tools_mmio_trace_get_buffer_multiplier());
}

void xemu_debug_tools_mmio_trace_get_status(XemuDebugToolsMmioTraceStatus *status)
{
    uint64_t total;

    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    total = qatomic_read(&mmio_trace.total_events);
    status->enabled = qatomic_read(&mmio_trace.enabled);
    status->total_events = total;
    status->count = MIN(total, (uint64_t)xemu_debug_tools_mmio_trace_get_buffer_capacity());
    status->overwritten_events = total > xemu_debug_tools_mmio_trace_get_buffer_capacity()
                                     ? total - xemu_debug_tools_mmio_trace_get_buffer_capacity()
                                     : 0;
    status->long_dispatch_threshold_ns = XEMU_DEBUG_TOOLS_MMIO_TRACE_LONG_NS;
}

size_t xemu_debug_tools_mmio_trace_snapshot(XemuDebugToolsMmioTraceEvent *events,
                                            size_t capacity)
{
    uint64_t total;
    uint64_t available;
    uint64_t first;
    size_t count;
    size_t i;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    total = qatomic_read(&mmio_trace.total_events);
    const size_t trace_capacity=xemu_debug_tools_mmio_trace_get_buffer_capacity();
    available = MIN(total, (uint64_t)trace_capacity);
    count = MIN((uint64_t)capacity, available);
    first = total - count;

    for (i = 0; i < count; ++i) {
        uint64_t sequence = first + i;
        XemuDebugToolsMmioTraceSlot *slot =
            &XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(mmio_trace.slots,XEMU_DEBUG_TOOLS_MMIO_TRACE_CAPACITY,sequence % trace_capacity);
        uint64_t committed = qatomic_read(&slot->committed_sequence_plus_one);
        if (committed != sequence + 1) {
            memset(&events[i], 0, sizeof(events[i]));
            events[i].sequence = sequence;
            continue;
        }
        smp_rmb();
        events[i] = slot->event;
    }
    return count;
}
