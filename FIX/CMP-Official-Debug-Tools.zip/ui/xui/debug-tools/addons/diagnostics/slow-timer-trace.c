/* Info: Record only callbacks already above the configured slow threshold. */
#include "qemu/osdep.h"
#include "qemu/thread.h"

#include "slow-timer-trace.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsSlowTimerTraceState {
    QemuMutex lock;
    bool lock_initialized;
    bool hook_installed;
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;
    XemuDebugToolsSlowTimerTraceEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsSlowTimerTraceState;

static XemuDebugToolsSlowTimerTraceState slow_timer_trace;

static uint64_t slow_timer_clamp_threshold(uint64_t threshold_ns)
{
    return MAX(XEMU_DEBUG_TOOLS_SLOW_TIMER_MIN_THRESHOLD_NS,
               MIN(threshold_ns,
                   XEMU_DEBUG_TOOLS_SLOW_TIMER_MAX_THRESHOLD_NS));
}

static void slow_timer_trace_reset_locked(void)
{
    slow_timer_trace.count = 0;
    slow_timer_trace.write_index = 0;
    slow_timer_trace.total_events = 0;
    slow_timer_trace.overwritten_events = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(slow_timer_trace.events, XemuDebugToolsSlowTimerTraceEvent, XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY, slow_timer_trace.buffer_multiplier);
}

static void slow_timer_trace_append_locked(
    XemuDebugToolsSlowTimerTraceEvent *event)
{
    const size_t trace_capacity = xemu_debug_tools_slow_timer_trace_get_buffer_capacity();
    const size_t slot = slow_timer_trace.write_index;

    event->sequence = slow_timer_trace.total_events++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(slow_timer_trace.events, XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY, slot) = *event;
    slow_timer_trace.write_index = (slot + 1) % trace_capacity;
    if (slow_timer_trace.count < trace_capacity) {
        ++slow_timer_trace.count;
    } else {
        ++slow_timer_trace.overwritten_events;
    }
}

static void slow_timer_observer(
    void *timer,
    uintptr_t callback_address,
    void *opaque,
    int clock_type,
    int64_t scheduled_expire_ns,
    int64_t timer_clock_start_ns,
    int64_t timer_clock_end_ns,
    uint64_t host_start_ns,
    uint64_t host_end_ns,
    uint64_t virtual_start_ns,
    uint64_t virtual_end_ns,
    uint64_t threshold_ns,
    int bql_held_before,
    int bql_held_after,
    const char *callback_name,
    const char *source_file,
    int source_line)
{
    XemuDebugToolsSlowTimerTraceEvent event = { 0 };

    if (!slow_timer_trace.lock_initialized ||
        !qatomic_read(&slow_timer_trace.enabled)) {
        return;
    }

    event.timer_address = (uint64_t)(uintptr_t)timer;
    event.callback_address = (uint64_t)callback_address;
    event.opaque_address = (uint64_t)(uintptr_t)opaque;
    event.host_start_ns = host_start_ns;
    event.host_end_ns = host_end_ns;
    event.host_duration_ns = host_end_ns >= host_start_ns
                                 ? host_end_ns - host_start_ns
                                 : 0;
    event.virtual_start_ns = virtual_start_ns;
    event.virtual_end_ns = virtual_end_ns;
    event.virtual_duration_ns = (int64_t)virtual_end_ns -
                                (int64_t)virtual_start_ns;
    event.scheduled_expire_ns = scheduled_expire_ns;
    event.timer_clock_start_ns = timer_clock_start_ns;
    event.timer_clock_end_ns = timer_clock_end_ns;
    event.dispatch_late_ns = scheduled_expire_ns >= 0
                                 ? timer_clock_start_ns - scheduled_expire_ns
                                 : 0;
    event.threshold_ns = threshold_ns;
    event.clock_type = clock_type;
    event.thread_id = qemu_get_thread_id();
    event.bql_held_before = bql_held_before ? 1 : 0;
    event.bql_held_after = bql_held_after ? 1 : 0;
    event.source_line = source_line;
    g_strlcpy(event.callback_name, callback_name ? callback_name : "<unknown>",
              sizeof(event.callback_name));
    g_strlcpy(event.source_file, source_file ? source_file : "<unknown>",
              sizeof(event.source_file));

    qemu_mutex_lock(&slow_timer_trace.lock);
    if (qatomic_read(&slow_timer_trace.enabled) &&
        threshold_ns == slow_timer_trace.threshold_ns) {
        slow_timer_trace_append_locked(&event);
    }
    qemu_mutex_unlock(&slow_timer_trace.lock);
}

static void slow_timer_trace_init(void)
{
    if (!slow_timer_trace.lock_initialized) {
        qemu_mutex_init(&slow_timer_trace.lock);
        slow_timer_trace.lock_initialized = true;
        slow_timer_trace.threshold_ns =
            XEMU_DEBUG_TOOLS_SLOW_TIMER_DEFAULT_THRESHOLD_NS;
        slow_timer_trace.buffer_multiplier = 1;
    }
    if (!slow_timer_trace.hook_installed) {
        xemu_debug_tools_slow_timer_hook_install(slow_timer_observer);
        slow_timer_trace.hook_installed = true;
        xemu_debug_tools_slow_timer_hook_configure(
            qatomic_read(&slow_timer_trace.enabled),
            slow_timer_trace.threshold_ns);
    }
}

void xemu_debug_tools_slow_timer_trace_set_enabled(int enabled)
{
    slow_timer_trace_init();
    qemu_mutex_lock(&slow_timer_trace.lock);
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(slow_timer_trace.events, XemuDebugToolsSlowTimerTraceEvent, XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY, slow_timer_trace.buffer_multiplier, ok); if (!ok) { qemu_mutex_unlock(&slow_timer_trace.lock); return; } }
    if (enabled && !qatomic_read(&slow_timer_trace.enabled)) {
        slow_timer_trace_reset_locked();
    }
    qatomic_set(&slow_timer_trace.enabled, enabled != 0);
    xemu_debug_tools_slow_timer_hook_configure(
        enabled != 0, slow_timer_trace.threshold_ns);
    qemu_mutex_unlock(&slow_timer_trace.lock);
}

void xemu_debug_tools_slow_timer_trace_set_threshold_ns(uint64_t threshold_ns)
{
    uint64_t clamped;

    slow_timer_trace_init();
    clamped = slow_timer_clamp_threshold(threshold_ns);
    qemu_mutex_lock(&slow_timer_trace.lock);
    if (slow_timer_trace.threshold_ns != clamped) {
        slow_timer_trace.threshold_ns = clamped;
        /* Keep every retained event under one threshold so snapshots remain
         * unambiguous after the user edits the millisecond value. */
        slow_timer_trace_reset_locked();
        xemu_debug_tools_slow_timer_hook_configure(
            qatomic_read(&slow_timer_trace.enabled), clamped);
    }
    qemu_mutex_unlock(&slow_timer_trace.lock);
}

int xemu_debug_tools_slow_timer_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; slow_timer_trace_init(); multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier); qemu_mutex_lock(&slow_timer_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(slow_timer_trace.events, XemuDebugToolsSlowTimerTraceEvent, XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY, multiplier, ok);
    if (ok) { slow_timer_trace.buffer_multiplier=multiplier; slow_timer_trace_reset_locked(); }
    qemu_mutex_unlock(&slow_timer_trace.lock); return ok?1:0;
}
uint32_t xemu_debug_tools_slow_timer_trace_get_buffer_multiplier(void){ return slow_timer_trace.buffer_multiplier?slow_timer_trace.buffer_multiplier:1; }
size_t xemu_debug_tools_slow_timer_trace_get_buffer_capacity(void){ return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY,xemu_debug_tools_slow_timer_trace_get_buffer_multiplier()); }

void xemu_debug_tools_slow_timer_trace_clear(void)
{
    slow_timer_trace_init();
    qemu_mutex_lock(&slow_timer_trace.lock);
    slow_timer_trace_reset_locked();
    qemu_mutex_unlock(&slow_timer_trace.lock);
}

void xemu_debug_tools_slow_timer_trace_get_status(
    XemuDebugToolsSlowTimerTraceStatus *status)
{
    if (!status) {
        return;
    }
    slow_timer_trace_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&slow_timer_trace.lock);
    status->enabled = qatomic_read(&slow_timer_trace.enabled) ? 1 : 0;
    status->threshold_ns = slow_timer_trace.threshold_ns;
    status->count = slow_timer_trace.count;
    status->total_events = slow_timer_trace.total_events;
    status->overwritten_events = slow_timer_trace.overwritten_events;
    qemu_mutex_unlock(&slow_timer_trace.lock);
}

size_t xemu_debug_tools_slow_timer_trace_snapshot(
    XemuDebugToolsSlowTimerTraceEvent *events,
    size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (!events || capacity == 0) {
        return 0;
    }
    slow_timer_trace_init();
    qemu_mutex_lock(&slow_timer_trace.lock);
    to_copy = MIN(capacity, slow_timer_trace.count);
    const size_t trace_capacity=xemu_debug_tools_slow_timer_trace_get_buffer_capacity();
    oldest = slow_timer_trace.count == trace_capacity ? slow_timer_trace.write_index : 0;
    if (to_copy < slow_timer_trace.count) {
        oldest = (oldest + slow_timer_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(slow_timer_trace.events, XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY, (oldest+i)%trace_capacity);
    }
    qemu_mutex_unlock(&slow_timer_trace.lock);
    return to_copy;
}
