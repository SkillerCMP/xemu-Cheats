/* xemu Debug Tools - qemu_main_loop_lock ownership/latency trace. */
#pragma once

#include "lock-trace-common.h"
#include "main-loop-lock-trace-hook.h"

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_CAPACITY \
    XEMU_DEBUG_TOOLS_LOCK_TRACE_CAPACITY
#define XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_LONG_NS \
    XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_NS
#define XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_FILE_MAX \
    XEMU_DEBUG_TOOLS_LOCK_TRACE_FILE_MAX

typedef enum XemuDebugToolsMainLoopLockTraceEventType {
    XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_LONG_WAIT =
        XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_WAIT,
    XEMU_DEBUG_TOOLS_MAIN_LOOP_LOCK_TRACE_LONG_HOLD =
        XEMU_DEBUG_TOOLS_LOCK_TRACE_LONG_HOLD,
} XemuDebugToolsMainLoopLockTraceEventType;

typedef XemuDebugToolsLockTraceEvent XemuDebugToolsMainLoopLockTraceEvent;
typedef XemuDebugToolsLockTraceStatus XemuDebugToolsMainLoopLockTraceStatus;

void xemu_debug_tools_main_loop_lock_trace_set_enabled(int enabled);
void xemu_debug_tools_main_loop_lock_trace_clear(void);
int xemu_debug_tools_main_loop_lock_trace_set_buffer_multiplier(
    uint32_t multiplier);
uint32_t xemu_debug_tools_main_loop_lock_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_main_loop_lock_trace_get_buffer_capacity(void);
void xemu_debug_tools_main_loop_lock_trace_get_status(
    XemuDebugToolsMainLoopLockTraceStatus *status);
size_t xemu_debug_tools_main_loop_lock_trace_snapshot(
    XemuDebugToolsMainLoopLockTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
