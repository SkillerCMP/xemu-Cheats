/* Info: Non-breaking TCG correlation trace for guest timer/deadline research. */

#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/bswap.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/core/cpu.h"
#include "cpu.h"

#include "diagnostics-trace-buffer.h"
#include "guest-timer-deadline-trace.h"
#include "d3d-callback-capture.h"
#include "ptimer-irq-delivery-trace.h"
#include "d3d-timer-state-trace.h"

typedef struct XemuGuestTimerDeadlineTraceState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;

    uint64_t input_sequence;
    uint64_t deadline_sequence;
    uint64_t input_sequences;
    uint64_t deadline_sequences;
    uint64_t deadline_rejects;
    uint64_t deadline_valid;
    uint64_t last_input_virtual_ns;
    int64_t last_deadline_delta_cycles;
    int64_t worst_late_delta_cycles;

    uint64_t callback_schedule_attempts;
    uint64_t callback_schedule_returns;
    uint64_t callback_entries;
    uint64_t callback_returns;
    uint64_t callback_overdue_events;
    uint64_t callback_next_input_entries;
    uint64_t dispatcher_attempts;
    uint64_t dispatcher_pc_events;
    uint64_t dispatcher_successful_attempts;
    uint64_t dispatcher_overdue_attempts;
    uint64_t dispatcher_recovered_overdue_attempts;
    uint64_t dispatcher_current_pc_events;
    uint64_t dispatcher_last_good_pc_events;
    uint64_t dispatcher_last_overdue_pc_events;
    uint64_t dispatcher_last_recovered_pc_events;
    int callback_watch_armed;
    int callback_overdue_fire_pending;
    int callback_overdue_latched;
    uint64_t callback_watch_input_sequence;
    uint64_t callback_schedule_virtual_ns;
    uint64_t callback_expected_due_ns;
    uint64_t callback_relative_delay_cycles;
    int64_t callback_last_delta_ns;
    uint32_t callback_target;
    uint32_t callback_return_pc;
    uint32_t callback_schedule_result_eax;
    int callback_schedule_result_valid;
    int callback_schedule_return_pending;
    int callback_entry_seen;
    int callback_return_seen;
    int callback_next_input_seen;
    uint64_t last_relative_delay;
    int last_relative_valid;

    uint32_t nominal_low;
    uint32_t nominal_high;
    uint32_t lateness_low;
    uint32_t lateness_high;
    uint32_t calculated_low;
    uint32_t calculated_high;
    uint32_t derived_valid_mask;

    uint32_t input_memory_valid_mask;
    uint32_t mem_1a80;
    uint32_t mem_1a84;
    uint32_t mem_1a90;
    uint32_t mem_1a94;
    uint32_t d3d_stack_valid_mask;
    uint32_t stack_14;
    uint32_t stack_18;
    uint32_t stack_20;

    XemuDebugToolsGuestTimerDeadlineTraceEvent *events[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuGuestTimerDeadlineTraceState;

static XemuGuestTimerDeadlineTraceState g_guest_timer_deadline;

static void guest_timer_deadline_init(void)
{
    if (!g_guest_timer_deadline.initialized) {
        qemu_mutex_init(&g_guest_timer_deadline.lock);
        g_guest_timer_deadline.buffer_multiplier = 1;
        g_guest_timer_deadline.initialized = true;
    }
}

static size_t guest_timer_deadline_capacity_locked(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
        g_guest_timer_deadline.buffer_multiplier);
}

size_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_capacity(void)
{
    guest_timer_deadline_init();
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
        qatomic_read(&g_guest_timer_deadline.buffer_multiplier));
}

static void guest_timer_deadline_reset_locked(void)
{
    g_guest_timer_deadline.count = 0;
    g_guest_timer_deadline.write_index = 0;
    g_guest_timer_deadline.total_events = 0;
    g_guest_timer_deadline.overwritten_events = 0;
    g_guest_timer_deadline.input_sequence = 0;
    g_guest_timer_deadline.deadline_sequence = 0;
    g_guest_timer_deadline.input_sequences = 0;
    g_guest_timer_deadline.deadline_sequences = 0;
    g_guest_timer_deadline.deadline_rejects = 0;
    g_guest_timer_deadline.deadline_valid = 0;
    g_guest_timer_deadline.last_input_virtual_ns = 0;
    g_guest_timer_deadline.last_deadline_delta_cycles = 0;
    g_guest_timer_deadline.worst_late_delta_cycles = 0;
    g_guest_timer_deadline.callback_schedule_attempts = 0;
    g_guest_timer_deadline.callback_schedule_returns = 0;
    g_guest_timer_deadline.callback_entries = 0;
    g_guest_timer_deadline.callback_returns = 0;
    g_guest_timer_deadline.callback_overdue_events = 0;
    g_guest_timer_deadline.callback_next_input_entries = 0;
    g_guest_timer_deadline.dispatcher_attempts = 0;
    g_guest_timer_deadline.dispatcher_pc_events = 0;
    g_guest_timer_deadline.dispatcher_successful_attempts = 0;
    g_guest_timer_deadline.dispatcher_overdue_attempts = 0;
    g_guest_timer_deadline.dispatcher_recovered_overdue_attempts = 0;
    g_guest_timer_deadline.dispatcher_current_pc_events = 0;
    g_guest_timer_deadline.dispatcher_last_good_pc_events = 0;
    g_guest_timer_deadline.dispatcher_last_overdue_pc_events = 0;
    g_guest_timer_deadline.dispatcher_last_recovered_pc_events = 0;
    qatomic_set(&g_guest_timer_deadline.callback_watch_armed, 0);
    qatomic_set(&g_guest_timer_deadline.callback_overdue_fire_pending, 0);
    qatomic_set(&g_guest_timer_deadline.callback_overdue_latched, 0);
    g_guest_timer_deadline.callback_watch_input_sequence = 0;
    g_guest_timer_deadline.callback_schedule_virtual_ns = 0;
    qatomic_set(&g_guest_timer_deadline.callback_expected_due_ns, 0);
    g_guest_timer_deadline.callback_relative_delay_cycles = 0;
    g_guest_timer_deadline.callback_last_delta_ns = 0;
    qatomic_set(&g_guest_timer_deadline.callback_target, 0);
    qatomic_set(&g_guest_timer_deadline.callback_return_pc, 0);
    g_guest_timer_deadline.callback_schedule_result_eax = 0;
    g_guest_timer_deadline.callback_schedule_result_valid = 0;
    qatomic_set(&g_guest_timer_deadline.callback_schedule_return_pending, 0);
    g_guest_timer_deadline.callback_entry_seen = 0;
    g_guest_timer_deadline.callback_return_seen = 0;
    g_guest_timer_deadline.callback_next_input_seen = 0;
    g_guest_timer_deadline.last_relative_delay = 0;
    g_guest_timer_deadline.last_relative_valid = 0;
    g_guest_timer_deadline.nominal_low = 0;
    g_guest_timer_deadline.nominal_high = 0;
    g_guest_timer_deadline.lateness_low = 0;
    g_guest_timer_deadline.lateness_high = 0;
    g_guest_timer_deadline.calculated_low = 0;
    g_guest_timer_deadline.calculated_high = 0;
    g_guest_timer_deadline.derived_valid_mask = 0;
    g_guest_timer_deadline.input_memory_valid_mask = 0;
    g_guest_timer_deadline.mem_1a80 = 0;
    g_guest_timer_deadline.mem_1a84 = 0;
    g_guest_timer_deadline.mem_1a90 = 0;
    g_guest_timer_deadline.mem_1a94 = 0;
    g_guest_timer_deadline.d3d_stack_valid_mask = 0;
    g_guest_timer_deadline.stack_14 = 0;
    g_guest_timer_deadline.stack_18 = 0;
    g_guest_timer_deadline.stack_20 = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_guest_timer_deadline.events,
        XemuDebugToolsGuestTimerDeadlineTraceEvent,
        XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
        g_guest_timer_deadline.buffer_multiplier);
}

static uint32_t guest_timer_deadline_event_type(uint32_t pc)
{
    switch (pc) {
    case XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY;
    case 0x000D7E53u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW;
    case 0x000D7E5Bu:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SBB_HIGH;
    case 0x000D7E5Du:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_RESULT;
    case 0x000D7E67u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_STORE_LOW;
    case 0x0021642Au:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT;
    case 0x0021643Du:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_HIGH;
    case 0x00216443u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_LOW_RESULT;
    case 0x00216445u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT;
    case 0x00216459u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID;
    case 0x0021645Fu:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RELATIVE_READY;
    case 0x00216473u:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL;
    default:
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_EVENT_NONE;
    }
}

static bool guest_timer_read_u32(CPUState *cpu, uint32_t address,
                                 uint32_t *value)
{
    uint8_t bytes[4];

    if (cpu == NULL || value == NULL ||
        cpu_memory_rw_debug(cpu, address, bytes, sizeof(bytes), false) != 0) {
        return false;
    }
    *value = ldl_le_p(bytes);
    return true;
}

static void guest_timer_capture_input_memory(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *event, CPUState *cpu)
{
    uint32_t base = event->esi;

    if (guest_timer_read_u32(cpu, base + 0x1A80u, &event->mem_1a80)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A80;
    }
    if (guest_timer_read_u32(cpu, base + 0x1A84u, &event->mem_1a84)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A84;
    }
    if (guest_timer_read_u32(cpu, base + 0x1A90u, &event->mem_1a90)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A90;
    }
    if (guest_timer_read_u32(cpu, base + 0x1A94u, &event->mem_1a94)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A94;
    }
}

static void guest_timer_capture_d3d_stack(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *event, CPUState *cpu)
{
    uint32_t base = event->esp;

    if (guest_timer_read_u32(cpu, base + 0x14u, &event->stack_14)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_14;
    }
    if (guest_timer_read_u32(cpu, base + 0x18u, &event->stack_18)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_18;
    }
    if (guest_timer_read_u32(cpu, base + 0x20u, &event->stack_20)) {
        event->memory_valid_mask |= XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_20;
    }
}

static bool guest_timer_is_input_event(uint32_t event_type)
{
    return event_type >= XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW &&
           event_type <= XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_STORE_LOW;
}

static bool guest_timer_is_d3d_event(uint32_t event_type)
{
    return event_type >= XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT &&
           event_type <= XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL;
}

static int64_t guest_timer_signed_delta(uint64_t requested, uint64_t threshold)
{
    if (requested >= threshold) {
        return (int64_t)(requested - threshold);
    }
    return -(int64_t)(threshold - requested);
}

static uint64_t guest_timer_cycles_to_ns(uint64_t cycles)
{
    if (cycles > XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TSC_HZ * 10ULL) {
        return 0;
    }
    return (cycles * 1000000000ULL) /
           XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TSC_HZ;
}

static void guest_timer_fill_cpu_event(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *event, CPUState *cpu,
    uint32_t guest_pc, uint32_t event_type, uint64_t now)
{
    CPUX86State *env = &X86_CPU(cpu)->env;

    event->qemu_virtual_ns = now;
    event->host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event->event_type = event_type;
    event->guest_pc = guest_pc;
    event->eax = (uint32_t)env->regs[R_EAX];
    event->ebx = (uint32_t)env->regs[R_EBX];
    event->ecx = (uint32_t)env->regs[R_ECX];
    event->edx = (uint32_t)env->regs[R_EDX];
    event->esi = (uint32_t)env->regs[R_ESI];
    event->edi = (uint32_t)env->regs[R_EDI];
    event->esp = (uint32_t)env->regs[R_ESP];
    event->ebp = (uint32_t)env->regs[R_EBP];
    event->eflags = cpu_compute_eflags(env);
}

static void guest_timer_fill_callback_fields_locked(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *event)
{
    event->callback_expected_due_ns =
        g_guest_timer_deadline.callback_expected_due_ns;
    event->callback_delta_ns = g_guest_timer_deadline.callback_last_delta_ns;
    event->callback_target = g_guest_timer_deadline.callback_target;
    event->callback_return_pc = g_guest_timer_deadline.callback_return_pc;
    event->schedule_result_eax =
        g_guest_timer_deadline.callback_schedule_result_eax;
    if (g_guest_timer_deadline.callback_target != 0) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_LINKED;
    }
    if (g_guest_timer_deadline.callback_schedule_result_valid) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RESULT_VALID;
    }
    if (g_guest_timer_deadline.callback_overdue_latched) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE_LATCHED;
    }
    if (g_guest_timer_deadline.callback_entry_seen) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY_SEEN;
    }
    if (g_guest_timer_deadline.callback_return_seen) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN_SEEN;
    }
    if (g_guest_timer_deadline.callback_next_input_seen) {
        event->callback_flags |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_NEXT_INPUT_SEEN;
    }
}

static void guest_timer_store_locked(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *event)
{
    const size_t capacity = guest_timer_deadline_capacity_locked();
    const size_t slot = g_guest_timer_deadline.write_index;

    if (capacity == 0 || g_guest_timer_deadline.events[0] == NULL) {
        return;
    }
    event->sequence = g_guest_timer_deadline.total_events++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_guest_timer_deadline.events,
        XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
        slot) = *event;
    g_guest_timer_deadline.write_index = (slot + 1) % capacity;
    if (g_guest_timer_deadline.count < capacity) {
        ++g_guest_timer_deadline.count;
    } else {
        ++g_guest_timer_deadline.overwritten_events;
    }
}

int xemu_debug_tools_guest_timer_deadline_trace_active(void)
{
    return qatomic_read(&g_guest_timer_deadline.enabled) != 0;
}

int xemu_debug_tools_guest_timer_deadline_trace_should_single_step(
    uint32_t guest_pc)
{
    uint32_t page;
    uint32_t callback_return_pc;

    if (!qatomic_read(&g_guest_timer_deadline.enabled)) {
        return 0;
    }

    /* The watchdog is checked only while one InputBuffer-linked callback is
     * outstanding. Returning true here makes the existing TCG hook split one
     * instruction at the detection point, allowing note_pc() to capture CPU
     * state without installing a breakpoint or pausing the guest. */
    if (xemu_debug_tools_d3d_callback_capture_active() &&
        qatomic_read(&g_guest_timer_deadline.callback_watch_armed)) {
        const uint64_t due =
            qatomic_read(&g_guest_timer_deadline.callback_expected_due_ns);
        const uint64_t now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

        if (due != 0 && now >= due +
                XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_GRACE_NS &&
            !qatomic_read(&g_guest_timer_deadline.callback_overdue_fire_pending)) {
            qatomic_set(&g_guest_timer_deadline.callback_overdue_fire_pending, 1);
            qatomic_set(&g_guest_timer_deadline.callback_overdue_latched, 1);
            qatomic_set(&g_guest_timer_deadline.callback_watch_armed, 0);
            return 1;
        }
    }

    callback_return_pc =
        qatomic_read(&g_guest_timer_deadline.callback_return_pc);
    if (callback_return_pc != 0 && guest_pc == callback_return_pc) {
        return 1;
    }

    /* Patch 305.3 keeps a tiny set of exact dispatcher probes active even
     * while Patch 305.2 suppresses the full 00223000 single-step window. */
    if (xemu_debug_tools_d3d_timer_state_trace_should_probe(guest_pc)) {
        return 1;
    }

    page = guest_pc & XEMU_DEBUG_TOOLS_GUEST_TIMER_PAGE_MASK;
    if (page == XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PAGE &&
        !xemu_debug_tools_ptimer_irq_delivery_trace_active() &&
        qatomic_read(&g_guest_timer_deadline.callback_watch_armed)) {
        const uint64_t due =
            qatomic_read(&g_guest_timer_deadline.callback_expected_due_ns);
        const uint64_t now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

        if (due != 0 &&
            now + XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PRE_NS >= due) {
            return 1;
        }
    }
    return page == XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_PAGE ||
           page == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_PAGE;
}

static uint32_t guest_timer_dynamic_event_type(uint32_t guest_pc)
{
    const uint32_t callback_return_pc =
        qatomic_read(&g_guest_timer_deadline.callback_return_pc);

    if (callback_return_pc != 0 && guest_pc == callback_return_pc) {
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN;
    }
    if (qatomic_read(&g_guest_timer_deadline.callback_schedule_return_pending) &&
        guest_pc >= 0x00216478u && guest_pc <= 0x0021647Fu) {
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN;
    }
    if ((guest_pc & XEMU_DEBUG_TOOLS_GUEST_TIMER_PAGE_MASK) ==
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DISPATCH_PAGE &&
        (qatomic_read(&g_guest_timer_deadline.callback_watch_armed) ||
         xemu_debug_tools_d3d_timer_state_trace_should_probe(guest_pc))) {
        return XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC;
    }
    return guest_timer_deadline_event_type(guest_pc);
}

static void guest_timer_note_overdue(CPUState *cpu, uint32_t guest_pc,
                                     uint64_t now)
{
    XemuDebugToolsGuestTimerDeadlineTraceEvent event = { 0 };
    XemuDebugToolsD3dCallbackCaptureTrigger trigger = { 0 };
    bool fire_capture = false;

    guest_timer_fill_cpu_event(
        &event, cpu, guest_pc, XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_OVERDUE,
        now);

    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    if (qatomic_read(&g_guest_timer_deadline.enabled)) {
        const uint64_t due =
            g_guest_timer_deadline.callback_expected_due_ns;
        const int64_t overdue = due != 0 && now >= due
                                    ? (int64_t)(now - due)
                                    : 0;

        ++g_guest_timer_deadline.callback_overdue_events;
        ++g_guest_timer_deadline.dispatcher_overdue_attempts;
        g_guest_timer_deadline.dispatcher_last_overdue_pc_events =
            g_guest_timer_deadline.dispatcher_current_pc_events;
        g_guest_timer_deadline.callback_last_delta_ns = overdue;
        g_guest_timer_deadline.callback_overdue_latched = 1;
        event.input_sequence = g_guest_timer_deadline.input_sequence;
        event.deadline_sequence = g_guest_timer_deadline.deadline_sequence;
        if (g_guest_timer_deadline.last_input_virtual_ns != 0 &&
            now >= g_guest_timer_deadline.last_input_virtual_ns) {
            event.age_since_input_ns =
                now - g_guest_timer_deadline.last_input_virtual_ns;
        }
        guest_timer_fill_callback_fields_locked(&event);
        guest_timer_store_locked(&event);

        trigger.trigger_virtual_ns = now;
        trigger.trigger_host_ns = event.host_ns;
        trigger.trigger_guest_pc = guest_pc;
        trigger.input_sequence = g_guest_timer_deadline.callback_watch_input_sequence;
        trigger.deadline_sequence = g_guest_timer_deadline.deadline_sequence;
        trigger.schedule_virtual_ns =
            g_guest_timer_deadline.callback_schedule_virtual_ns;
        trigger.expected_due_ns = due;
        trigger.overdue_ns = overdue;
        trigger.relative_delay_cycles =
            g_guest_timer_deadline.callback_relative_delay_cycles;
        trigger.callback_target = g_guest_timer_deadline.callback_target;
        trigger.callback_return_pc = g_guest_timer_deadline.callback_return_pc;
        trigger.schedule_result_eax =
            g_guest_timer_deadline.callback_schedule_result_eax;
        trigger.schedule_result_valid =
            g_guest_timer_deadline.callback_schedule_result_valid;
        fire_capture = true;
    }
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);

    xemu_debug_tools_d3d_timer_state_trace_note(
        cpu, XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_OVERDUE, guest_pc, 0,
        event.input_sequence, event.deadline_sequence);

    if (fire_capture) {
        xemu_debug_tools_d3d_callback_capture_note_overdue(&trigger);
    }
}

void xemu_debug_tools_guest_timer_deadline_trace_note_pc(CPUState *cpu,
                                                          uint32_t guest_pc)
{
    XemuDebugToolsGuestTimerDeadlineTraceEvent event = { 0 };
    uint32_t event_type;
    uint32_t callback_return_candidate = 0;
    bool callback_return_candidate_valid = false;
    bool notify_callback_recovered = false;
    uint64_t recovered_input_sequence = 0;
    uint32_t timer_state_event_type = XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE;
    uint32_t timer_state_object = 0;
    uint64_t timer_state_input_sequence = 0;
    uint64_t timer_state_deadline_sequence = 0;
    uint64_t now;

    if (!qatomic_read(&g_guest_timer_deadline.enabled) || cpu == NULL) {
        return;
    }

    guest_timer_deadline_init();
    now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

    if (qatomic_read(&g_guest_timer_deadline.callback_overdue_fire_pending)) {
        qatomic_set(&g_guest_timer_deadline.callback_overdue_fire_pending, 0);
        guest_timer_note_overdue(cpu, guest_pc, now);
    }

    event_type = guest_timer_dynamic_event_type(guest_pc);
    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_EVENT_NONE) {
        return;
    }

    guest_timer_fill_cpu_event(&event, cpu, guest_pc, event_type, now);

    /* Keep instrumentation light enough not to create the timing failure we
     * are measuring: read guest memory only once per InputBuffer/D3D sequence,
     * plus the callback's single stack return address at 000D7EA0. */
    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW) {
        guest_timer_capture_input_memory(&event, cpu);
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT) {
        guest_timer_capture_d3d_stack(&event, cpu);
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY) {
        callback_return_candidate_valid = guest_timer_read_u32(
            cpu, event.esp, &callback_return_candidate);
    }

    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    if (!qatomic_read(&g_guest_timer_deadline.enabled)) {
        qemu_mutex_unlock(&g_guest_timer_deadline.lock);
        return;
    }

    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SUB_LOW) {
        if (g_guest_timer_deadline.callback_target ==
                XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET &&
            g_guest_timer_deadline.callback_watch_input_sequence ==
                g_guest_timer_deadline.input_sequence &&
            !g_guest_timer_deadline.callback_next_input_seen) {
            g_guest_timer_deadline.callback_next_input_seen = 1;
            ++g_guest_timer_deadline.callback_next_input_entries;
            if (g_guest_timer_deadline.callback_expected_due_ns != 0) {
                g_guest_timer_deadline.callback_last_delta_ns =
                    guest_timer_signed_delta(
                        now, g_guest_timer_deadline.callback_expected_due_ns);
            }
            qatomic_set(&g_guest_timer_deadline.callback_watch_armed, 0);
            /* Once the next InputBuffer cycle is visible, any unresolved
             * D3D call-return probe belongs to the completed prior schedule.
             * Do not let it misclassify an unrelated later PC in the landing
             * window as that schedule's return. */
            qatomic_set(&g_guest_timer_deadline.callback_schedule_return_pending,
                        0);
        }

        ++g_guest_timer_deadline.input_sequence;
        ++g_guest_timer_deadline.input_sequences;
        g_guest_timer_deadline.last_input_virtual_ns = now;
        g_guest_timer_deadline.nominal_low = event.ebx;
        g_guest_timer_deadline.lateness_low = event.eax;
        g_guest_timer_deadline.nominal_high = 0;
        g_guest_timer_deadline.lateness_high = 0;
        g_guest_timer_deadline.calculated_low = 0;
        g_guest_timer_deadline.calculated_high = 0;
        g_guest_timer_deadline.derived_valid_mask = 0;
        g_guest_timer_deadline.input_memory_valid_mask =
            event.memory_valid_mask &
            (XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A80 |
             XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A84 |
             XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A90 |
             XEMU_DEBUG_TOOLS_GUEST_TIMER_MEM_1A94);
        g_guest_timer_deadline.mem_1a80 = event.mem_1a80;
        g_guest_timer_deadline.mem_1a84 = event.mem_1a84;
        g_guest_timer_deadline.mem_1a90 = event.mem_1a90;
        g_guest_timer_deadline.mem_1a94 = event.mem_1a94;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_SBB_HIGH) {
        g_guest_timer_deadline.nominal_high = event.eax;
        g_guest_timer_deadline.lateness_high = event.ecx;
        g_guest_timer_deadline.calculated_low = event.ebx;
        g_guest_timer_deadline.derived_valid_mask |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_NOMINAL |
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_LATENESS;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_INPUT_RESULT) {
        g_guest_timer_deadline.calculated_high = event.eax;
        g_guest_timer_deadline.derived_valid_mask |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_CALCULATED;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT) {
        ++g_guest_timer_deadline.deadline_sequence;
        ++g_guest_timer_deadline.deadline_sequences;
        g_guest_timer_deadline.d3d_stack_valid_mask =
            event.memory_valid_mask &
            (XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_14 |
             XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_18 |
             XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_20);
        g_guest_timer_deadline.stack_14 = event.stack_14;
        g_guest_timer_deadline.stack_18 = event.stack_18;
        g_guest_timer_deadline.stack_20 = event.stack_20;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN) {
        if (g_guest_timer_deadline.callback_schedule_return_pending) {
            ++g_guest_timer_deadline.callback_schedule_returns;
            g_guest_timer_deadline.callback_schedule_result_eax = event.eax;
            g_guest_timer_deadline.callback_schedule_result_valid = 1;
            qatomic_set(&g_guest_timer_deadline.callback_schedule_return_pending,
                        0);
        }
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY) {
        ++g_guest_timer_deadline.callback_entries;
        if (g_guest_timer_deadline.callback_target == guest_pc &&
            g_guest_timer_deadline.callback_watch_input_sequence != 0) {
            const uint64_t due =
                g_guest_timer_deadline.callback_expected_due_ns;
            const bool recovered_overdue =
                g_guest_timer_deadline.callback_overdue_latched != 0;

            g_guest_timer_deadline.callback_entry_seen = 1;
            if (recovered_overdue) {
                notify_callback_recovered = true;
                recovered_input_sequence =
                    g_guest_timer_deadline.callback_watch_input_sequence;
                ++g_guest_timer_deadline.dispatcher_recovered_overdue_attempts;
                g_guest_timer_deadline.dispatcher_last_recovered_pc_events =
                    g_guest_timer_deadline.dispatcher_current_pc_events;
            } else {
                ++g_guest_timer_deadline.dispatcher_successful_attempts;
                g_guest_timer_deadline.dispatcher_last_good_pc_events =
                    g_guest_timer_deadline.dispatcher_current_pc_events;
            }
            if (due != 0) {
                g_guest_timer_deadline.callback_last_delta_ns =
                    now >= due ? (int64_t)(now - due)
                               : -(int64_t)(due - now);
            }
            qatomic_set(&g_guest_timer_deadline.callback_watch_armed, 0);
            /* Callback entry itself proves that the schedule call returned far
             * enough for dispatch. Clear a stale landing-window probe even if
             * the exact post-call PC was not observed. */
            qatomic_set(&g_guest_timer_deadline.callback_schedule_return_pending,
                        0);
            if (callback_return_candidate_valid) {
                qatomic_set(&g_guest_timer_deadline.callback_return_pc,
                            callback_return_candidate);
            }
        }
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC) {
        ++g_guest_timer_deadline.dispatcher_pc_events;
        ++g_guest_timer_deadline.dispatcher_current_pc_events;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_RETURN) {
        ++g_guest_timer_deadline.callback_returns;
        g_guest_timer_deadline.callback_return_seen = 1;
        qatomic_set(&g_guest_timer_deadline.callback_return_pc, 0);
    }

    event.input_sequence = g_guest_timer_deadline.input_sequence;
    event.deadline_sequence = g_guest_timer_deadline.deadline_sequence;
    if (g_guest_timer_deadline.last_input_virtual_ns != 0 &&
        now >= g_guest_timer_deadline.last_input_virtual_ns) {
        event.age_since_input_ns =
            now - g_guest_timer_deadline.last_input_virtual_ns;
    }

    if (guest_timer_is_input_event(event_type)) {
        event.memory_valid_mask = g_guest_timer_deadline.input_memory_valid_mask;
        event.mem_1a80 = g_guest_timer_deadline.mem_1a80;
        event.mem_1a84 = g_guest_timer_deadline.mem_1a84;
        event.mem_1a90 = g_guest_timer_deadline.mem_1a90;
        event.mem_1a94 = g_guest_timer_deadline.mem_1a94;
    } else if (guest_timer_is_d3d_event(event_type) ||
               event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN) {
        event.memory_valid_mask = g_guest_timer_deadline.d3d_stack_valid_mask;
        event.stack_14 = g_guest_timer_deadline.stack_14;
        event.stack_18 = g_guest_timer_deadline.stack_18;
        event.stack_20 = g_guest_timer_deadline.stack_20;
    }

    event.derived_valid_mask = g_guest_timer_deadline.derived_valid_mask;
    event.nominal_interval =
        ((uint64_t)g_guest_timer_deadline.nominal_high << 32) |
        g_guest_timer_deadline.nominal_low;
    event.accumulated_lateness =
        ((uint64_t)g_guest_timer_deadline.lateness_high << 32) |
        g_guest_timer_deadline.lateness_low;
    event.calculated_interval =
        ((uint64_t)g_guest_timer_deadline.calculated_high << 32) |
        g_guest_timer_deadline.calculated_low;

    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RDTSC_RESULT &&
        (event.memory_valid_mask &
         (XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_14 |
          XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_18)) ==
        (XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_14 |
         XEMU_DEBUG_TOOLS_GUEST_TIMER_STACK_18)) {
        const uint64_t current_tsc =
            ((uint64_t)event.edx << 32) | event.eax;
        const uint64_t requested =
            ((uint64_t)event.stack_18 << 32) | event.stack_14;
        const uint64_t threshold = current_tsc + 0x28ULL;
        event.current_tsc = current_tsc;
        event.requested_deadline = requested;
        event.deadline_threshold = threshold;
        event.deadline_delta_cycles =
            guest_timer_signed_delta(requested, threshold);
        event.derived_valid_mask |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_DEADLINE;
    }

    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_HIGH ||
        event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_COMPARE_LOW_RESULT ||
        event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT ||
        event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID) {
        const uint64_t current_tsc =
            ((uint64_t)event.edx << 32) | event.eax;
        const uint64_t requested =
            ((uint64_t)event.esi << 32) | event.ecx;
        const uint64_t threshold = current_tsc + 0x28ULL;
        const int64_t delta = guest_timer_signed_delta(requested, threshold);

        event.current_tsc = current_tsc;
        event.requested_deadline = requested;
        event.deadline_threshold = threshold;
        event.deadline_delta_cycles = delta;
        event.derived_valid_mask |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_DEADLINE;
        if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT ||
            event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID) {
            g_guest_timer_deadline.last_deadline_delta_cycles = delta;
            if (delta < g_guest_timer_deadline.worst_late_delta_cycles) {
                g_guest_timer_deadline.worst_late_delta_cycles = delta;
            }
        }
    }

    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT) {
        ++g_guest_timer_deadline.deadline_rejects;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_VALID) {
        ++g_guest_timer_deadline.deadline_valid;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_RELATIVE_READY) {
        event.relative_delay = ((uint64_t)event.esi << 32) | event.edi;
        event.derived_valid_mask |=
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_RELATIVE;
        g_guest_timer_deadline.last_relative_delay = event.relative_delay;
        g_guest_timer_deadline.last_relative_valid = 1;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL) {
        const bool linked_input_callback =
            event.ebp == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET &&
            event.age_since_input_ns <=
                XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_LINK_MAX_AGE_NS &&
            g_guest_timer_deadline.last_relative_valid;

        if (linked_input_callback) {
            const uint64_t delay_ns = guest_timer_cycles_to_ns(
                g_guest_timer_deadline.last_relative_delay);

            if (delay_ns != 0) {
                ++g_guest_timer_deadline.callback_schedule_attempts;
                ++g_guest_timer_deadline.dispatcher_attempts;
                g_guest_timer_deadline.dispatcher_current_pc_events = 0;
                g_guest_timer_deadline.callback_watch_input_sequence =
                    g_guest_timer_deadline.input_sequence;
                g_guest_timer_deadline.callback_schedule_virtual_ns = now;
                g_guest_timer_deadline.callback_relative_delay_cycles =
                    g_guest_timer_deadline.last_relative_delay;
                qatomic_set(&g_guest_timer_deadline.callback_expected_due_ns,
                            now + delay_ns);
                qatomic_set(&g_guest_timer_deadline.callback_target, event.ebp);
                qatomic_set(&g_guest_timer_deadline.callback_return_pc, 0);
                g_guest_timer_deadline.callback_schedule_result_eax = 0;
                g_guest_timer_deadline.callback_schedule_result_valid = 0;
                g_guest_timer_deadline.callback_entry_seen = 0;
                g_guest_timer_deadline.callback_return_seen = 0;
                g_guest_timer_deadline.callback_next_input_seen = 0;
                g_guest_timer_deadline.callback_last_delta_ns = 0;
                qatomic_set(&g_guest_timer_deadline.callback_overdue_latched, 0);
                qatomic_set(
                    &g_guest_timer_deadline.callback_schedule_return_pending,
                    1);
                qatomic_set(&g_guest_timer_deadline.callback_watch_armed, 1);
                event.relative_delay =
                    g_guest_timer_deadline.callback_relative_delay_cycles;
                event.derived_valid_mask |=
                    XEMU_DEBUG_TOOLS_GUEST_TIMER_DERIVED_RELATIVE;
            }
        }
    }

    if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_CALL &&
        event.ebp == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_TARGET &&
        g_guest_timer_deadline.callback_watch_armed) {
        timer_state_event_type =
            XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_CALL;
        timer_state_object = event.ecx;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_SCHEDULE_RETURN) {
        timer_state_event_type =
            XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_SCHEDULE_RETURN;
    } else if (event_type ==
               XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_DISPATCH_PC) {
        timer_state_event_type = XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_ENTRY) {
        timer_state_event_type =
            XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_CALLBACK_ENTRY;
    } else if (event_type == XEMU_DEBUG_TOOLS_GUEST_TIMER_D3D_REJECT) {
        timer_state_event_type = XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_D3D_REJECT;
    }
    timer_state_input_sequence = g_guest_timer_deadline.input_sequence;
    timer_state_deadline_sequence = g_guest_timer_deadline.deadline_sequence;

    guest_timer_fill_callback_fields_locked(&event);
    guest_timer_store_locked(&event);
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);

    if (timer_state_event_type != XEMU_DEBUG_TOOLS_D3D_TIMER_STATE_NONE ||
        xemu_debug_tools_d3d_timer_state_trace_should_probe(guest_pc)) {
        xemu_debug_tools_d3d_timer_state_trace_note(
            cpu, timer_state_event_type, guest_pc, timer_state_object,
            timer_state_input_sequence, timer_state_deadline_sequence);
    }

    if (notify_callback_recovered) {
        xemu_debug_tools_d3d_callback_capture_note_recovered(
            recovered_input_sequence, now);
    }
}

void xemu_debug_tools_guest_timer_deadline_trace_set_enabled(int enabled)
{
    bool ok;

    guest_timer_deadline_init();
    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_guest_timer_deadline.events,
            XemuDebugToolsGuestTimerDeadlineTraceEvent,
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
            g_guest_timer_deadline.buffer_multiplier, ok);
        if (!ok) {
            qatomic_set(&g_guest_timer_deadline.enabled, 0);
            qemu_mutex_unlock(&g_guest_timer_deadline.lock);
            return;
        }
    }
    qatomic_set(&g_guest_timer_deadline.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);
    xemu_debug_tools_d3d_timer_state_trace_set_enabled(enabled);
}

void xemu_debug_tools_guest_timer_deadline_trace_clear(void)
{
    guest_timer_deadline_init();
    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    guest_timer_deadline_reset_locked();
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);
    xemu_debug_tools_d3d_timer_state_trace_clear();
}

int xemu_debug_tools_guest_timer_deadline_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    bool ok;
    uint32_t clamped;

    guest_timer_deadline_init();
    clamped = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_guest_timer_deadline.events,
        XemuDebugToolsGuestTimerDeadlineTraceEvent,
        XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
        clamped, ok);
    if (ok) {
        g_guest_timer_deadline.buffer_multiplier = clamped;
        guest_timer_deadline_reset_locked();
    }
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_guest_timer_deadline_trace_get_buffer_multiplier(void)
{
    guest_timer_deadline_init();
    return qatomic_read(&g_guest_timer_deadline.buffer_multiplier);
}

void xemu_debug_tools_guest_timer_deadline_trace_get_status(
    XemuDebugToolsGuestTimerDeadlineTraceStatus *status)
{
    if (status == NULL) {
        return;
    }
    guest_timer_deadline_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    status->enabled = qatomic_read(&g_guest_timer_deadline.enabled);
    status->count = g_guest_timer_deadline.count;
    status->total_events = g_guest_timer_deadline.total_events;
    status->overwritten_events = g_guest_timer_deadline.overwritten_events;
    status->input_sequences = g_guest_timer_deadline.input_sequences;
    status->deadline_sequences = g_guest_timer_deadline.deadline_sequences;
    status->deadline_rejects = g_guest_timer_deadline.deadline_rejects;
    status->deadline_valid = g_guest_timer_deadline.deadline_valid;
    status->last_deadline_delta_cycles =
        g_guest_timer_deadline.last_deadline_delta_cycles;
    status->worst_late_delta_cycles =
        g_guest_timer_deadline.worst_late_delta_cycles;
    status->last_input_virtual_ns =
        g_guest_timer_deadline.last_input_virtual_ns;
    status->callback_schedule_attempts =
        g_guest_timer_deadline.callback_schedule_attempts;
    status->callback_schedule_returns =
        g_guest_timer_deadline.callback_schedule_returns;
    status->callback_entries = g_guest_timer_deadline.callback_entries;
    status->callback_returns = g_guest_timer_deadline.callback_returns;
    status->callback_overdue_events =
        g_guest_timer_deadline.callback_overdue_events;
    status->callback_next_input_entries =
        g_guest_timer_deadline.callback_next_input_entries;
    status->dispatcher_attempts = g_guest_timer_deadline.dispatcher_attempts;
    status->dispatcher_pc_events = g_guest_timer_deadline.dispatcher_pc_events;
    status->dispatcher_successful_attempts =
        g_guest_timer_deadline.dispatcher_successful_attempts;
    status->dispatcher_overdue_attempts =
        g_guest_timer_deadline.dispatcher_overdue_attempts;
    status->dispatcher_recovered_overdue_attempts =
        g_guest_timer_deadline.dispatcher_recovered_overdue_attempts;
    status->dispatcher_current_pc_events =
        g_guest_timer_deadline.dispatcher_current_pc_events;
    status->dispatcher_last_good_pc_events =
        g_guest_timer_deadline.dispatcher_last_good_pc_events;
    status->dispatcher_last_overdue_pc_events =
        g_guest_timer_deadline.dispatcher_last_overdue_pc_events;
    status->dispatcher_last_recovered_pc_events =
        g_guest_timer_deadline.dispatcher_last_recovered_pc_events;
    status->callback_watch_armed =
        qatomic_read(&g_guest_timer_deadline.callback_watch_armed);
    status->callback_overdue_latched =
        qatomic_read(&g_guest_timer_deadline.callback_overdue_latched);
    status->callback_watch_input_sequence =
        g_guest_timer_deadline.callback_watch_input_sequence;
    status->callback_schedule_virtual_ns =
        g_guest_timer_deadline.callback_schedule_virtual_ns;
    status->callback_expected_due_ns =
        qatomic_read(&g_guest_timer_deadline.callback_expected_due_ns);
    status->callback_relative_delay_cycles =
        g_guest_timer_deadline.callback_relative_delay_cycles;
    status->callback_last_delta_ns =
        g_guest_timer_deadline.callback_last_delta_ns;
    status->callback_target =
        qatomic_read(&g_guest_timer_deadline.callback_target);
    status->callback_return_pc =
        qatomic_read(&g_guest_timer_deadline.callback_return_pc);
    status->callback_schedule_result_eax =
        g_guest_timer_deadline.callback_schedule_result_eax;
    status->callback_schedule_result_valid =
        g_guest_timer_deadline.callback_schedule_result_valid;
    status->buffer_multiplier = g_guest_timer_deadline.buffer_multiplier;
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);
}

size_t xemu_debug_tools_guest_timer_deadline_trace_snapshot(
    XemuDebugToolsGuestTimerDeadlineTraceEvent *events, size_t capacity)
{
    size_t i;
    size_t out_count;
    size_t trace_capacity;
    size_t first;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    guest_timer_deadline_init();
    qemu_mutex_lock(&g_guest_timer_deadline.lock);
    out_count = MIN(capacity, g_guest_timer_deadline.count);
    trace_capacity = guest_timer_deadline_capacity_locked();
    first = (g_guest_timer_deadline.write_index + trace_capacity -
             g_guest_timer_deadline.count) % trace_capacity;
    if (out_count < g_guest_timer_deadline.count) {
        first = (first + g_guest_timer_deadline.count - out_count) %
                trace_capacity;
    }
    for (i = 0; i < out_count; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_guest_timer_deadline.events,
            XEMU_DEBUG_TOOLS_GUEST_TIMER_DEADLINE_TRACE_CAPACITY,
            (first + i) % trace_capacity);
    }
    qemu_mutex_unlock(&g_guest_timer_deadline.lock);
    return out_count;
}
