/* Info: CPU code emits BQL boundaries; Diagnostics owns timing and ownership. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsBqlTraceContext {
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_NONE = 0,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_VBLANK,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_CREATE,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_HUD_UPDATE,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_FRAMEBUFFER_DESTROY,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_SDL_EVENT,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_COMMIT = 7,
    XEMU_DEBUG_TOOLS_BQL_CONTEXT_UI_INPUT_INIT = 8,
} XemuDebugToolsBqlTraceContext;

typedef enum XemuDebugToolsBqlTraceStage {
    XEMU_DEBUG_TOOLS_BQL_STAGE_NONE = 0,
    XEMU_DEBUG_TOOLS_BQL_STAGE_HUD_CORE,
    XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_TICK,
    XEMU_DEBUG_TOOLS_BQL_STAGE_DEBUG_TOOLS_SDL_EVENT = 4,
} XemuDebugToolsBqlTraceStage;

/* Labels the next BQL acquisition made by the calling thread. */
void xemu_debug_tools_bql_trace_set_next_context(uint32_t context);

/* Optional substage timing while the calling thread owns BQL. */
void xemu_debug_tools_bql_trace_owner_stage_begin(uint32_t stage);
void xemu_debug_tools_bql_trace_owner_stage_end(void);

void xemu_debug_tools_bql_trace_lock_attempt(const char *file, int line);
void xemu_debug_tools_bql_trace_lock_acquired(const char *file, int line);
void xemu_debug_tools_bql_trace_unlock_begin(void);
void xemu_debug_tools_bql_trace_unlock_end(void);

#ifdef __cplusplus
}
#endif
