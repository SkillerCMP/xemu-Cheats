/* Diagnostics-internal per-PFIFO-run aggregation. No guest or renderer access. */
#pragma once
#include <stdint.h>

/* Return a reusable host timestamp, or zero when aggregate recording is inactive. */
uint64_t xemu_debug_tools_pgraph_draw_aggregate_begin(unsigned int stage);
uint64_t xemu_debug_tools_pgraph_draw_aggregate_end(unsigned int stage);
void xemu_debug_tools_pgraph_draw_aggregate_cache(unsigned int outcome);
