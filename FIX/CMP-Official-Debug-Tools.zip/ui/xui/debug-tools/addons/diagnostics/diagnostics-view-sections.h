// Diagnostics view/report selection: no recorder or guest access.
#pragma once
#include <array>
#include <cstddef>

namespace XemuDiagnosticsView {
enum class Group { General, Overview, Cpu, Nv2a, Audio, Watches, History };
enum class Section {
    CurrentGame,
    Overview,
    Background,
    Registers,
    Instructions,
    Stack,
    Clocks,
    InterruptState,
    Ptimer,
    PtimerTrace,
    SlowTimer,
    Ohci,
    Increment,
    FlipStall,
    FlipDelay,
    PusherProgress,
    MethodBreakdown,
    Scheduler,
    IrqLatency,
    IrqDelivery,
    HostStall,
    InputPoll,
    QemuTimer,
    Bql,
    MainLoop,
    Mmio,
    PgraphLock,
    DrawStages,
    ControllerXid,
    GpuWait,
    GuestInput,
    GuestTimer,
    D3dCallback,
    LateCapture,
    D3dTimerState,
    AudioMetrics,
    AudioPacing,
    AvSync,
    Watches,
    History,
    Count
};
struct SectionInfo { Section id; Group group; const char *label; };
inline constexpr std::array<SectionInfo, static_cast<std::size_t>(Section::Count)> kSections{{
    {Section::CurrentGame, Group::General, "Current Game"},
    {Section::Overview, Group::Overview, "Overview"},
    {Section::Background, Group::General, "Debug Tools Background Work"},
    {Section::Registers, Group::Cpu, "CPU Registers"},
    {Section::Instructions, Group::Cpu, "Instruction Stream"},
    {Section::Stack, Group::Cpu, "Stack (ESP)"},
    {Section::Clocks, Group::Cpu, "Clock Domains"},
    {Section::InterruptState, Group::Nv2a, "Interrupt State"},
    {Section::Ptimer, Group::Nv2a, "PTIMER"},
    {Section::PtimerTrace, Group::Nv2a, "Detailed PTIMER Timing Trace"},
    {Section::SlowTimer, Group::Nv2a, "Slow QEMU Timer Callback Detector"},
    {Section::Ohci, Group::Nv2a, "OHCI Slow Frame Stage Profiler"},
    {Section::Increment, Group::Nv2a, "PGRAPH Increment Stage Profiler"},
    {Section::FlipStall, Group::Nv2a, "FLIP_STALL / VBlank Investigator"},
    {Section::FlipDelay, Group::Nv2a, "PGRAPH Flip Delay Breakdown"},
    {Section::PusherProgress, Group::Nv2a, "D3D Pusher / GPU Progress Correlation"},
    {Section::MethodBreakdown, Group::Nv2a, "PFIFO Method-Time Breakdown"},
    {Section::Scheduler, Group::Nv2a, "Xbox Scheduler / Thread Wake Investigator"},
    {Section::IrqLatency, Group::Nv2a, "PTIMER IRQ Service Latency Profiler"},
    {Section::IrqDelivery, Group::Nv2a, "PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)"},
    {Section::HostStall, Group::Nv2a, "Windows Host Stall / Page-Fault Correlation (Patch 305.4)"},
    {Section::InputPoll, Group::Nv2a, "Controller Input Poll Stage Profiler"},
    {Section::QemuTimer, Group::Nv2a, "QEMU Timer Dispatch Flight Recorder"},
    {Section::Bql, Group::Nv2a, "BQL Ownership Trace"},
    {Section::MainLoop, Group::Nv2a, "QEMU Main Loop Lock Ownership Trace"},
    {Section::Mmio, Group::Nv2a, "MMIO Dispatch Trace"},
    {Section::PgraphLock, Group::Nv2a, "PGRAPH Lock Ownership Trace"},
    {Section::DrawStages, Group::Nv2a, "SET_BEGIN_END / Renderer Draw-End Breakdown"},
    {Section::ControllerXid, Group::Nv2a, "Controller / XID / OHCI USB Reconnect Trace"},
    {Section::GpuWait, Group::Nv2a, "GPU Wait / Work State"},
    {Section::GuestInput, Group::Nv2a, "Guest Input Consumer Candidate Trace (TCG)"},
    {Section::GuestTimer, Group::Nv2a, "Guest Timer / Deadline Correlation Trace (TCG)"},
    {Section::D3dCallback, Group::Nv2a, "D3D InputBuffer Callback Dispatch Capture (pinned one-shot)"},
    {Section::LateCapture, Group::Nv2a, "PTIMER Late Callback Capture (pinned one-shot)"},
    {Section::D3dTimerState, Group::Nv2a, "D3D Timer Record / List State Trace"},
    {Section::AudioMetrics, Group::Audio, "Audio / APU State"},
    {Section::AudioPacing, Group::Audio, "Audio Frame Pacing"},
    {Section::AvSync, Group::Audio, "Audio / Video Sync Trace"},
    {Section::Watches, Group::Watches, "Custom Watches"},
    {Section::History, Group::History, "Recent Events"},
}};

struct State {
    std::array<bool, kSections.size()> checked{};
    State() { SetAll(true); }
    void SetAll(bool shown) { checked.fill(shown); }
    bool IsVisible(Section id) const {
        const auto index = static_cast<std::size_t>(id);
        return index < checked.size() && checked[index];
    }
    bool Any(Group group) const {
        for (const auto &section : kSections) {
            if (section.group == group && IsVisible(section.id)) return true;
        }
        return false;
    }
};
} // namespace XemuDiagnosticsView
