/* Info: Correlates changed Xbox input reports with nearby title TCG blocks. */

#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"

#include "diagnostics-trace-buffer.h"
#include "guest-input-consumer-trace.h"

typedef struct XemuGuestInputConsumerTraceState {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t report_changes;
    uint64_t title_tb_candidates;
    uint64_t dropped_candidates;
    uint32_t buffer_multiplier;

    uint8_t last_report[XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX];
    uint32_t last_report_length;
    bool last_report_valid;

    uint64_t current_report_sequence;
    uint64_t last_report_virtual_ns;
    uint64_t capture_until_virtual_ns;
    uint32_t guest_address0;
    uint32_t guest_length0;
    uint32_t guest_address1;
    uint32_t guest_length1;
    uint32_t current_report_length;
    uint8_t current_report[XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX];
    uint32_t current_candidate_count;
    uint32_t seen_pc_count;
    uint32_t seen_pcs[XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_MAX_PCS_PER_REPORT];

    XemuDebugToolsGuestInputConsumerTraceEvent *events[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuGuestInputConsumerTraceState;

static XemuGuestInputConsumerTraceState g_guest_input_consumer;

static void guest_input_consumer_init(void)
{
    if (!g_guest_input_consumer.initialized) {
        qemu_mutex_init(&g_guest_input_consumer.lock);
        g_guest_input_consumer.buffer_multiplier = 1;
        g_guest_input_consumer.initialized = true;
    }
}

static size_t guest_input_consumer_capacity_locked(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
        g_guest_input_consumer.buffer_multiplier);
}

size_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_capacity(void)
{
    guest_input_consumer_init();
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
        qatomic_read(&g_guest_input_consumer.buffer_multiplier));
}

static void guest_input_consumer_store_locked(
    XemuDebugToolsGuestInputConsumerTraceEvent *event)
{
    const size_t capacity = guest_input_consumer_capacity_locked();
    const size_t slot = g_guest_input_consumer.write_index;

    if (capacity == 0 || g_guest_input_consumer.events[0] == NULL) {
        return;
    }

    event->sequence = g_guest_input_consumer.total_events++;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_guest_input_consumer.events,
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
        slot) = *event;
    g_guest_input_consumer.write_index = (slot + 1) % capacity;
    if (g_guest_input_consumer.count < capacity) {
        ++g_guest_input_consumer.count;
    } else {
        ++g_guest_input_consumer.overwritten_events;
    }
}

static void guest_input_consumer_reset_locked(void)
{
    g_guest_input_consumer.count = 0;
    g_guest_input_consumer.write_index = 0;
    g_guest_input_consumer.total_events = 0;
    g_guest_input_consumer.overwritten_events = 0;
    g_guest_input_consumer.report_changes = 0;
    g_guest_input_consumer.title_tb_candidates = 0;
    g_guest_input_consumer.dropped_candidates = 0;
    g_guest_input_consumer.last_report_valid = false;
    g_guest_input_consumer.last_report_length = 0;
    memset(g_guest_input_consumer.last_report, 0,
           sizeof(g_guest_input_consumer.last_report));
    g_guest_input_consumer.current_report_sequence = 0;
    g_guest_input_consumer.last_report_virtual_ns = 0;
    qatomic_set_u64(&g_guest_input_consumer.capture_until_virtual_ns, 0);
    g_guest_input_consumer.guest_address0 = 0;
    g_guest_input_consumer.guest_length0 = 0;
    g_guest_input_consumer.guest_address1 = 0;
    g_guest_input_consumer.guest_length1 = 0;
    g_guest_input_consumer.current_report_length = 0;
    memset(g_guest_input_consumer.current_report, 0,
           sizeof(g_guest_input_consumer.current_report));
    g_guest_input_consumer.current_candidate_count = 0;
    g_guest_input_consumer.seen_pc_count = 0;
    memset(g_guest_input_consumer.seen_pcs, 0,
           sizeof(g_guest_input_consumer.seen_pcs));
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_guest_input_consumer.events,
        XemuDebugToolsGuestInputConsumerTraceEvent,
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
        g_guest_input_consumer.buffer_multiplier);
}

static bool guest_input_consumer_meaningful_change(
    const uint8_t *previous, uint32_t previous_length,
    const uint8_t *report, uint32_t report_length)
{
    uint32_t i;

    if (previous_length != report_length) {
        return true;
    }
    if (report_length == 0 || report == NULL) {
        return false;
    }

    /* XID report header + digital/analog buttons are the strongest signal. */
    const uint32_t button_bytes = MIN(report_length, 12u);
    if (memcmp(previous, report, button_bytes) != 0) {
        return true;
    }

    /* Retain deliberate stick motion while ignoring tiny host-axis jitter. */
    for (i = 12; i + 1 < report_length && i + 1 < 20; i += 2) {
        const int16_t old_axis = (int16_t)((uint16_t)previous[i] |
                                           ((uint16_t)previous[i + 1] << 8));
        const int16_t new_axis = (int16_t)((uint16_t)report[i] |
                                           ((uint16_t)report[i + 1] << 8));
        int delta = (int)new_axis - (int)old_axis;
        if (delta < 0) {
            delta = -delta;
        }
        if (delta >= 1024) {
            return true;
        }
    }
    return false;
}

int xemu_debug_tools_guest_input_consumer_trace_active(void)
{
    return qatomic_read(&g_guest_input_consumer.enabled) != 0;
}

int xemu_debug_tools_guest_input_consumer_trace_capture_active(void)
{
    uint64_t until;
    uint64_t now;

    if (!qatomic_read(&g_guest_input_consumer.enabled)) {
        return 0;
    }
    until = qatomic_read_u64(&g_guest_input_consumer.capture_until_virtual_ns);
    if (until == 0) {
        return 0;
    }
    now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    return now <= until;
}

void xemu_debug_tools_guest_input_consumer_trace_note_report(
    uint32_t guest_address0, uint32_t guest_length0,
    uint32_t guest_address1, uint32_t guest_length1,
    const uint8_t *report, uint32_t report_length)
{
    XemuDebugToolsGuestInputConsumerTraceEvent event = { 0 };
    uint32_t stored_length;
    uint64_t virtual_ns;

    if (!qatomic_read(&g_guest_input_consumer.enabled)) {
        return;
    }
    guest_input_consumer_init();

    stored_length = MIN(
        report_length,
        (uint32_t)XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_MAX);

    qemu_mutex_lock(&g_guest_input_consumer.lock);
    if (!qatomic_read(&g_guest_input_consumer.enabled)) {
        qemu_mutex_unlock(&g_guest_input_consumer.lock);
        return;
    }

    if (g_guest_input_consumer.last_report_valid &&
        !guest_input_consumer_meaningful_change(
            g_guest_input_consumer.last_report,
            g_guest_input_consumer.last_report_length,
            report, stored_length)) {
        if (stored_length != 0 && report != NULL) {
            memcpy(g_guest_input_consumer.last_report, report, stored_length);
        }
        g_guest_input_consumer.last_report_length = stored_length;
        qemu_mutex_unlock(&g_guest_input_consumer.lock);
        return;
    }

    virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    ++g_guest_input_consumer.current_report_sequence;
    ++g_guest_input_consumer.report_changes;
    g_guest_input_consumer.last_report_virtual_ns = virtual_ns;
    qatomic_set_u64(&g_guest_input_consumer.capture_until_virtual_ns,
                    virtual_ns + XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_WINDOW_NS);
    g_guest_input_consumer.guest_address0 = guest_address0;
    g_guest_input_consumer.guest_length0 = guest_length0;
    g_guest_input_consumer.guest_address1 = guest_address1;
    g_guest_input_consumer.guest_length1 = guest_length1;
    g_guest_input_consumer.current_report_length = stored_length;
    memset(g_guest_input_consumer.current_report, 0,
           sizeof(g_guest_input_consumer.current_report));
    if (stored_length != 0 && report != NULL) {
        memcpy(g_guest_input_consumer.current_report, report, stored_length);
    }
    g_guest_input_consumer.current_candidate_count = 0;
    g_guest_input_consumer.seen_pc_count = 0;

    event.qemu_virtual_ns = virtual_ns;
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.report_sequence = g_guest_input_consumer.current_report_sequence;
    event.event_type = XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_REPORT_CHANGE;
    event.guest_address0 = guest_address0;
    event.guest_length0 = guest_length0;
    event.guest_address1 = guest_address1;
    event.guest_length1 = guest_length1;
    event.report_length = stored_length;
    if (stored_length != 0 && report != NULL) {
        memcpy(event.report, report, stored_length);
    }
    guest_input_consumer_store_locked(&event);

    g_guest_input_consumer.last_report_valid = true;
    g_guest_input_consumer.last_report_length = stored_length;
    memset(g_guest_input_consumer.last_report, 0,
           sizeof(g_guest_input_consumer.last_report));
    if (stored_length != 0 && report != NULL) {
        memcpy(g_guest_input_consumer.last_report, report, stored_length);
    }
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
}

void xemu_debug_tools_guest_input_consumer_trace_note_title_tb(uint32_t guest_pc)
{
    XemuDebugToolsGuestInputConsumerTraceEvent event = { 0 };
    uint64_t now;
    uint64_t until;
    uint32_t i;

    if (!qatomic_read(&g_guest_input_consumer.enabled) ||
        guest_pc < 0x00010000u || guest_pc >= 0x80000000u) {
        return;
    }

    now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    until = qatomic_read_u64(&g_guest_input_consumer.capture_until_virtual_ns);
    if (until == 0 || now > until) {
        return;
    }

    qemu_mutex_lock(&g_guest_input_consumer.lock);
    if (!qatomic_read(&g_guest_input_consumer.enabled) ||
        now > g_guest_input_consumer.capture_until_virtual_ns) {
        qemu_mutex_unlock(&g_guest_input_consumer.lock);
        return;
    }

    for (i = 0; i < g_guest_input_consumer.seen_pc_count; ++i) {
        if (g_guest_input_consumer.seen_pcs[i] == guest_pc) {
            qemu_mutex_unlock(&g_guest_input_consumer.lock);
            return;
        }
    }
    if (g_guest_input_consumer.seen_pc_count >=
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_MAX_PCS_PER_REPORT) {
        ++g_guest_input_consumer.dropped_candidates;
        qemu_mutex_unlock(&g_guest_input_consumer.lock);
        return;
    }

    g_guest_input_consumer.seen_pcs[g_guest_input_consumer.seen_pc_count++] =
        guest_pc;
    ++g_guest_input_consumer.current_candidate_count;
    ++g_guest_input_consumer.title_tb_candidates;

    event.qemu_virtual_ns = now;
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.report_sequence = g_guest_input_consumer.current_report_sequence;
    event.age_since_report_ns = now >= g_guest_input_consumer.last_report_virtual_ns
        ? now - g_guest_input_consumer.last_report_virtual_ns : 0;
    event.event_type = XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TITLE_TB;
    event.guest_pc = guest_pc;
    event.guest_address0 = g_guest_input_consumer.guest_address0;
    event.guest_length0 = g_guest_input_consumer.guest_length0;
    event.guest_address1 = g_guest_input_consumer.guest_address1;
    event.guest_length1 = g_guest_input_consumer.guest_length1;
    event.report_length = g_guest_input_consumer.current_report_length;
    event.candidate_ordinal = g_guest_input_consumer.current_candidate_count;
    memcpy(event.report, g_guest_input_consumer.current_report,
           sizeof(event.report));
    guest_input_consumer_store_locked(&event);
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
}

void xemu_debug_tools_guest_input_consumer_trace_set_enabled(int enabled)
{
    bool ok;

    guest_input_consumer_init();
    qemu_mutex_lock(&g_guest_input_consumer.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_guest_input_consumer.events,
            XemuDebugToolsGuestInputConsumerTraceEvent,
            XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
            g_guest_input_consumer.buffer_multiplier, ok);
        if (!ok) {
            qatomic_set(&g_guest_input_consumer.enabled, 0);
            qemu_mutex_unlock(&g_guest_input_consumer.lock);
            return;
        }
    } else {
        qatomic_set_u64(&g_guest_input_consumer.capture_until_virtual_ns, 0);
    }
    qatomic_set(&g_guest_input_consumer.enabled, enabled ? 1 : 0);
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
}

void xemu_debug_tools_guest_input_consumer_trace_clear(void)
{
    guest_input_consumer_init();
    qemu_mutex_lock(&g_guest_input_consumer.lock);
    guest_input_consumer_reset_locked();
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
}

int xemu_debug_tools_guest_input_consumer_trace_set_buffer_multiplier(
    uint32_t multiplier)
{
    bool ok;
    uint32_t clamped;

    guest_input_consumer_init();
    clamped = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_guest_input_consumer.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_guest_input_consumer.events,
        XemuDebugToolsGuestInputConsumerTraceEvent,
        XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
        clamped, ok);
    if (ok) {
        g_guest_input_consumer.buffer_multiplier = clamped;
        guest_input_consumer_reset_locked();
    }
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_guest_input_consumer_trace_get_buffer_multiplier(void)
{
    guest_input_consumer_init();
    return qatomic_read(&g_guest_input_consumer.buffer_multiplier);
}

void xemu_debug_tools_guest_input_consumer_trace_get_status(
    XemuDebugToolsGuestInputConsumerTraceStatus *status)
{
    uint64_t now;

    if (status == NULL) {
        return;
    }
    memset(status, 0, sizeof(*status));
    guest_input_consumer_init();
    qemu_mutex_lock(&g_guest_input_consumer.lock);
    status->enabled = qatomic_read(&g_guest_input_consumer.enabled);
    status->count = g_guest_input_consumer.count;
    status->total_events = g_guest_input_consumer.total_events;
    status->overwritten_events = g_guest_input_consumer.overwritten_events;
    status->report_changes = g_guest_input_consumer.report_changes;
    status->title_tb_candidates = g_guest_input_consumer.title_tb_candidates;
    status->dropped_candidates = g_guest_input_consumer.dropped_candidates;
    status->current_report_sequence =
        g_guest_input_consumer.current_report_sequence;
    status->last_report_virtual_ns = g_guest_input_consumer.last_report_virtual_ns;
    status->capture_until_virtual_ns =
        qatomic_read_u64(&g_guest_input_consumer.capture_until_virtual_ns);
    status->current_candidate_count =
        g_guest_input_consumer.current_candidate_count;
    now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    status->capture_active = status->enabled &&
        status->capture_until_virtual_ns != 0 &&
        now <= status->capture_until_virtual_ns;
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
}

size_t xemu_debug_tools_guest_input_consumer_trace_snapshot(
    XemuDebugToolsGuestInputConsumerTraceEvent *events, size_t capacity)
{
    size_t i;
    size_t out_count;
    size_t trace_capacity;
    size_t first;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    guest_input_consumer_init();
    qemu_mutex_lock(&g_guest_input_consumer.lock);
    out_count = MIN(capacity, g_guest_input_consumer.count);
    trace_capacity = guest_input_consumer_capacity_locked();
    first = (g_guest_input_consumer.write_index + trace_capacity -
             g_guest_input_consumer.count) % trace_capacity;
    if (out_count < g_guest_input_consumer.count) {
        first = (first + g_guest_input_consumer.count - out_count) %
                trace_capacity;
    }
    for (i = 0; i < out_count; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_guest_input_consumer.events,
            XEMU_DEBUG_TOOLS_GUEST_INPUT_CONSUMER_TRACE_CAPACITY,
            (first + i) % trace_capacity);
    }
    qemu_mutex_unlock(&g_guest_input_consumer.lock);
    return out_count;
}
