/* Info: Input/XID core emits observations; Diagnostics owns trace state. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT 6
#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT 8
#define XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX 20

typedef enum XemuDebugToolsControllerXidTraceHookEvent {
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_ADDED = 1,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_OPENED,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_OPEN_FAILED,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_REMOVED,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_BIND,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_UNBIND,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_INPUT_STATE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_REALIZE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_UNREALIZE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_RESET,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_GET_REPORT,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INTERRUPT_IN,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INPUT_STATE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_BOUND_MISSING,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_ATTACH,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_DETACH,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_RHSC,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_RESET,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_SETUP_TD,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_USB_CONTROL_REQUEST,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_PERSISTENT_NEUTRAL,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_PERSISTENT_REATTACHED,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_ON,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_OFF,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_IN_PACKET_COMPLETE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_COMPLETE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_DONE_HEAD,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_WDH_IRQ,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_GUEST_INPUT_WRITE,
    XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT,
} XemuDebugToolsControllerXidTraceHookEvent;

void xemu_debug_tools_controller_xid_trace_init(void);

void xemu_debug_tools_controller_xid_trace_host_lifecycle(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    uint32_t instance_id,
    int32_t save_binding,
    const char *name,
    const char *guid);

void xemu_debug_tools_controller_xid_trace_host_state(
    int32_t port,
    uint32_t instance_id,
    uint32_t buttons,
    const int16_t axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT]);

void xemu_debug_tools_controller_xid_trace_xid_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *xid_device,
    uint32_t value0,
    uint32_t value1);


void xemu_debug_tools_controller_xid_trace_usb_event(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3);

void xemu_debug_tools_controller_xid_trace_input_mode(
    int32_t enabled,
    int32_t nav_active,
    int32_t controller_activity,
    int32_t rebinding,
    int32_t navigating_with_controller);

void xemu_debug_tools_controller_xid_trace_xid_packet_complete(
    int32_t port,
    const void *xid_device,
    int32_t packet_status,
    uint32_t actual_length,
    uint32_t requested_length,
    uint32_t endpoint,
    const uint8_t *report,
    uint32_t report_length);

void xemu_debug_tools_controller_xid_trace_usb_event5(
    XemuDebugToolsControllerXidTraceHookEvent event_type,
    int32_t port,
    const void *usb_device,
    uint32_t value0,
    uint32_t value1,
    uint32_t value2,
    uint32_t value3,
    uint32_t value4);

void xemu_debug_tools_controller_xid_trace_guest_input_write(
    const void *usb_device,
    uint32_t td_address,
    uint32_t guest_address0,
    uint32_t guest_length0,
    uint32_t guest_address1,
    uint32_t guest_length1,
    const uint8_t *report,
    uint32_t report_length);

void xemu_debug_tools_controller_xid_trace_xid_state(
    int32_t port,
    const void *xid_device,
    uint32_t host_buttons,
    const int16_t host_axis[XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_AXIS_COUNT],
    uint16_t xid_buttons,
    const uint8_t xid_analog[XEMU_DEBUG_TOOLS_CONTROLLER_XID_ANALOG_BUTTON_COUNT],
    int16_t thumb_lx,
    int16_t thumb_ly,
    int16_t thumb_rx,
    int16_t thumb_ry);

#ifdef __cplusplus
}
#endif
