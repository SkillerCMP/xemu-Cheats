/* Info: PTIMER core emits events; Diagnostics owns timing and storage. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum XemuDebugToolsPtimerTraceHookEvent {
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_RESET = 1,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_SCHEDULE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_SCHEDULE_DISABLED,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_TIMER_DELETE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_CALLBACK,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_CALLBACK_DISABLED,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_IRQ_SET,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_IRQ_CLEAR,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_INTR_EN_WRITE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_ALARM_WRITE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_NUMERATOR_WRITE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_DENOMINATOR_WRITE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_TIME0_WRITE,
    XEMU_DEBUG_TOOLS_PTIMER_TRACE_TIME1_WRITE,
} XemuDebugToolsPtimerTraceHookEvent;

void xemu_debug_tools_ptimer_trace_init(void);
void xemu_debug_tools_ptimer_trace_record(
    void *nv2a_state,
    XemuDebugToolsPtimerTraceHookEvent event_type,
    uint32_t value,
    uint32_t previous_value);

#ifdef __cplusplus
}
#endif
