/* Info: One-shot pinned forensic capture for overdue D3D InputBuffer callbacks. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "bql-trace.h"
#include "guest-timer-deadline-trace.h"
#include "main-loop-lock-trace.h"
#include "pgraph-lock-trace.h"
#include "qemu-timer-trace.h"
#include "scheduler-trace.h"

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_GRACE_NS XEMU_DEBUG_TOOLS_GUEST_TIMER_CALLBACK_GRACE_NS
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_QTIMER_EVENTS 128
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_BQL_EVENTS 32
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_MAIN_LOOP_LOCK_EVENTS 32
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_PGRAPH_EVENTS 32
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_SCHEDULER_EVENTS 64
#define XEMU_DEBUG_TOOLS_D3D_CALLBACK_GUEST_TIMER_EVENTS 48

typedef struct XemuDebugToolsD3dCallbackCaptureTrigger {
    uint64_t trigger_virtual_ns;
    uint64_t trigger_host_ns;
    uint32_t trigger_guest_pc;
    uint64_t input_sequence;
    uint64_t deadline_sequence;
    uint64_t schedule_virtual_ns;
    uint64_t expected_due_ns;
    int64_t overdue_ns;
    uint64_t relative_delay_cycles;
    uint32_t callback_target;
    uint32_t callback_return_pc;
    uint32_t schedule_result_eax;
    int schedule_result_valid;
} XemuDebugToolsD3dCallbackCaptureTrigger;

typedef struct XemuDebugToolsD3dCallbackCaptureStatus {
    int enabled;
    int latched;
    int capture_in_progress;
    uint64_t capture_count;
    uint64_t transient_recoveries;
    uint64_t last_recovery_virtual_ns;
    int64_t last_recovery_delta_ns;
    int64_t grace_ns;
    XemuDebugToolsD3dCallbackCaptureTrigger trigger;
    uint64_t capture_duration_host_ns;
    size_t qtimer_count;
    size_t bql_count;
    size_t main_loop_lock_count;
    size_t pgraph_count;
    size_t scheduler_count;
    size_t guest_timer_count;
    XemuDebugToolsBqlTraceStatus bql_status;
    XemuDebugToolsMainLoopLockTraceStatus main_loop_lock_status;
    XemuDebugToolsPgraphLockTraceStatus pgraph_status;
    XemuDebugToolsSchedulerTraceStatus scheduler_status;
    XemuDebugToolsGuestTimerDeadlineTraceStatus guest_timer_status;
} XemuDebugToolsD3dCallbackCaptureStatus;

typedef struct XemuDebugToolsD3dCallbackCaptureSnapshot {
    XemuDebugToolsD3dCallbackCaptureStatus status;
    XemuDebugToolsQemuTimerTraceEvent
        qtimer[XEMU_DEBUG_TOOLS_D3D_CALLBACK_QTIMER_EVENTS];
    XemuDebugToolsBqlTraceEvent
        bql[XEMU_DEBUG_TOOLS_D3D_CALLBACK_BQL_EVENTS];
    XemuDebugToolsMainLoopLockTraceEvent
        main_loop_lock[XEMU_DEBUG_TOOLS_D3D_CALLBACK_MAIN_LOOP_LOCK_EVENTS];
    XemuDebugToolsPgraphLockTraceEvent
        pgraph[XEMU_DEBUG_TOOLS_D3D_CALLBACK_PGRAPH_EVENTS];
    XemuDebugToolsSchedulerTraceEvent
        scheduler[XEMU_DEBUG_TOOLS_D3D_CALLBACK_SCHEDULER_EVENTS];
    XemuDebugToolsGuestTimerDeadlineTraceEvent
        guest_timer[XEMU_DEBUG_TOOLS_D3D_CALLBACK_GUEST_TIMER_EVENTS];
} XemuDebugToolsD3dCallbackCaptureSnapshot;

int xemu_debug_tools_d3d_callback_capture_active(void);
void xemu_debug_tools_d3d_callback_capture_set_enabled(int enabled);
void xemu_debug_tools_d3d_callback_capture_clear(void);
void xemu_debug_tools_d3d_callback_capture_note_overdue(
    const XemuDebugToolsD3dCallbackCaptureTrigger *trigger);
void xemu_debug_tools_d3d_callback_capture_note_recovered(
    uint64_t input_sequence, uint64_t callback_entry_virtual_ns);
void xemu_debug_tools_d3d_callback_capture_get_status(
    XemuDebugToolsD3dCallbackCaptureStatus *status);
int xemu_debug_tools_d3d_callback_capture_snapshot(
    XemuDebugToolsD3dCallbackCaptureSnapshot *snapshot);

#ifdef __cplusplus
}
#endif
