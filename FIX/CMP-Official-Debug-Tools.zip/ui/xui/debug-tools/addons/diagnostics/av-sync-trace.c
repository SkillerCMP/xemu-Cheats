#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "qemu/thread.h"
#include "qemu/timer.h"
#include "hw/xbox/mcpx/apu/apu_int.h"

#include "av-sync-trace.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsAvSyncTraceRing {
    QemuMutex lock;
    bool initialized;
    int enabled;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;

    uint64_t marker_count;
    XemuDebugToolsAvSyncMarker markers[XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY];

    uint64_t audio_batches;
    uint64_t audio_samples;
    uint64_t video_vblanks;
    uint64_t video_expected_ns;
    uint64_t last_vblank_interval_ns;
    int32_t last_audio_queue_bytes;

    uint64_t pgraph_flips;
    uint32_t last_pgraph_frame_time;
    bool pgraph_baseline_valid;
    uint64_t last_pgraph_host_ns;
    uint64_t last_pgraph_virtual_ns;
    uint64_t last_pgraph_audio_samples;
    uint64_t last_pgraph_video_vblanks;
    uint64_t last_pgraph_video_expected_ns;
    uint32_t last_pgraph_vblank_delta;
    uint64_t last_pgraph_audio_sample_delta;
    uint64_t last_pgraph_host_interval_ns;
    uint64_t last_pgraph_virtual_interval_ns;
    uint64_t max_pgraph_host_interval_ns;
    uint64_t max_pgraph_virtual_interval_ns;
    uint32_t max_pgraph_vblank_delta;

    bool audio_baseline_valid;
    uint64_t audio_baseline_samples;
    uint64_t audio_baseline_host_ns;
    uint64_t audio_baseline_virtual_ns;
    bool video_baseline_valid;
    uint64_t video_baseline_host_ns;
    uint64_t video_baseline_virtual_ns;

    int64_t audio_host_drift_ns;
    int64_t audio_virtual_drift_ns;
    int64_t video_host_drift_ns;
    int64_t video_virtual_drift_ns;

    XemuDebugToolsAvSyncTraceEvent *events[
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsAvSyncTraceRing;

static XemuDebugToolsAvSyncTraceRing g_av_sync;

static void av_sync_init(void)
{
    if (!g_av_sync.initialized) {
        qemu_mutex_init(&g_av_sync.lock);
        g_av_sync.buffer_multiplier = 1;
        g_av_sync.last_audio_queue_bytes = -1;
        g_av_sync.initialized = true;
    }
}

static void av_sync_reset_locked(void)
{
    g_av_sync.marker_count = 0;
    memset(g_av_sync.markers, 0, sizeof(g_av_sync.markers));
    g_av_sync.count = 0;
    g_av_sync.write_index = 0;
    g_av_sync.total_events = 0;
    g_av_sync.overwritten_events = 0;
    g_av_sync.audio_batches = 0;
    g_av_sync.audio_samples = 0;
    g_av_sync.video_vblanks = 0;
    g_av_sync.video_expected_ns = 0;
    g_av_sync.last_vblank_interval_ns = 0;
    g_av_sync.last_audio_queue_bytes = -1;
    g_av_sync.pgraph_flips = 0;
    g_av_sync.last_pgraph_frame_time = 0;
    g_av_sync.pgraph_baseline_valid = false;
    g_av_sync.last_pgraph_host_ns = 0;
    g_av_sync.last_pgraph_virtual_ns = 0;
    g_av_sync.last_pgraph_audio_samples = 0;
    g_av_sync.last_pgraph_video_vblanks = 0;
    g_av_sync.last_pgraph_video_expected_ns = 0;
    g_av_sync.last_pgraph_vblank_delta = 0;
    g_av_sync.last_pgraph_audio_sample_delta = 0;
    g_av_sync.last_pgraph_host_interval_ns = 0;
    g_av_sync.last_pgraph_virtual_interval_ns = 0;
    g_av_sync.max_pgraph_host_interval_ns = 0;
    g_av_sync.max_pgraph_virtual_interval_ns = 0;
    g_av_sync.max_pgraph_vblank_delta = 0;
    g_av_sync.audio_baseline_valid = false;
    g_av_sync.audio_baseline_samples = 0;
    g_av_sync.audio_baseline_host_ns = 0;
    g_av_sync.audio_baseline_virtual_ns = 0;
    g_av_sync.video_baseline_valid = false;
    g_av_sync.video_baseline_host_ns = 0;
    g_av_sync.video_baseline_virtual_ns = 0;
    g_av_sync.audio_host_drift_ns = 0;
    g_av_sync.audio_virtual_drift_ns = 0;
    g_av_sync.video_host_drift_ns = 0;
    g_av_sync.video_virtual_drift_ns = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(
        g_av_sync.events, XemuDebugToolsAvSyncTraceEvent,
        XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY,
        g_av_sync.buffer_multiplier);
}

static int64_t av_sync_signed_elapsed(uint64_t now, uint64_t baseline)
{
    if (now >= baseline) {
        uint64_t delta = now - baseline;
        return delta > INT64_MAX ? INT64_MAX : (int64_t)delta;
    }
    {
        uint64_t delta = baseline - now;
        return delta > (uint64_t)INT64_MAX ? INT64_MIN : -(int64_t)delta;
    }
}

static uint64_t av_sync_audio_expected_ns(void)
{
    uint64_t samples;
    if (!g_av_sync.audio_baseline_valid ||
        g_av_sync.audio_samples < g_av_sync.audio_baseline_samples) {
        return 0;
    }
    samples = g_av_sync.audio_samples - g_av_sync.audio_baseline_samples;
    return samples * 1000000000ULL / XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_RATE;
}

static void av_sync_update_audio_drift_locked(uint64_t host_ns,
                                              uint64_t virtual_ns)
{
    uint64_t expected_ns = av_sync_audio_expected_ns();
    g_av_sync.audio_host_drift_ns =
        (int64_t)expected_ns -
        av_sync_signed_elapsed(host_ns, g_av_sync.audio_baseline_host_ns);
    g_av_sync.audio_virtual_drift_ns =
        (int64_t)expected_ns -
        av_sync_signed_elapsed(virtual_ns, g_av_sync.audio_baseline_virtual_ns);
}

static void av_sync_update_video_drift_locked(uint64_t host_ns,
                                              uint64_t virtual_ns)
{
    g_av_sync.video_host_drift_ns =
        (int64_t)g_av_sync.video_expected_ns -
        av_sync_signed_elapsed(host_ns, g_av_sync.video_baseline_host_ns);
    g_av_sync.video_virtual_drift_ns =
        (int64_t)g_av_sync.video_expected_ns -
        av_sync_signed_elapsed(virtual_ns, g_av_sync.video_baseline_virtual_ns);
}

static uint64_t av_sync_unsigned_elapsed(uint64_t now, uint64_t baseline)
{
    return now >= baseline ? now - baseline : 0;
}

static uint64_t av_sync_samples_to_ns(uint64_t samples)
{
    return samples * 1000000000ULL / XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_RATE;
}

static void av_sync_fill_pgraph_progress_locked(
    XemuDebugToolsAvSyncTraceEvent *event)
{
    if (!g_av_sync.pgraph_baseline_valid) {
        return;
    }

    event->pgraph_host_age_ns = av_sync_unsigned_elapsed(
        event->host_ns, g_av_sync.last_pgraph_host_ns);
    event->pgraph_virtual_age_ns = av_sync_unsigned_elapsed(
        event->qemu_virtual_ns, g_av_sync.last_pgraph_virtual_ns);
    if (g_av_sync.audio_samples >= g_av_sync.last_pgraph_audio_samples) {
        event->audio_since_pgraph_ns = av_sync_samples_to_ns(
            g_av_sync.audio_samples - g_av_sync.last_pgraph_audio_samples);
    }
    if (g_av_sync.video_expected_ns >=
        g_av_sync.last_pgraph_video_expected_ns) {
        event->vblank_since_pgraph_ns =
            g_av_sync.video_expected_ns -
            g_av_sync.last_pgraph_video_expected_ns;
    }
}

static void av_sync_store_locked(XemuDebugToolsAvSyncTraceEvent *event)
{
    size_t cap = xemu_debug_tools_av_sync_trace_get_buffer_capacity();
    size_t slot = g_av_sync.write_index;
    bool ready = g_av_sync.audio_baseline_valid &&
                 g_av_sync.video_baseline_valid &&
                 g_av_sync.audio_batches > 1 &&
                 g_av_sync.video_vblanks > 1;

    event->sequence = g_av_sync.total_events++;
    event->ready = ready ? 1u : 0u;
    event->audio_batches = g_av_sync.audio_batches;
    event->audio_samples = g_av_sync.audio_samples;
    event->video_vblanks = g_av_sync.video_vblanks;
    event->video_expected_ns = g_av_sync.video_expected_ns;
    event->vblank_interval_ns = g_av_sync.last_vblank_interval_ns;
    event->pgraph_ready =
        (g_av_sync.pgraph_baseline_valid && g_av_sync.pgraph_flips > 1) ? 1u : 0u;
    event->pgraph_flips = g_av_sync.pgraph_flips;
    event->pgraph_frame_time = g_av_sync.last_pgraph_frame_time;
    event->pgraph_last_vblank_delta = g_av_sync.last_pgraph_vblank_delta;
    event->pgraph_last_audio_sample_delta =
        g_av_sync.last_pgraph_audio_sample_delta;
    event->pgraph_last_host_interval_ns =
        g_av_sync.last_pgraph_host_interval_ns;
    event->pgraph_last_virtual_interval_ns =
        g_av_sync.last_pgraph_virtual_interval_ns;
    event->pgraph_max_host_interval_ns = g_av_sync.max_pgraph_host_interval_ns;
    event->pgraph_max_virtual_interval_ns =
        g_av_sync.max_pgraph_virtual_interval_ns;
    event->pgraph_max_vblank_delta = g_av_sync.max_pgraph_vblank_delta;
    av_sync_fill_pgraph_progress_locked(event);
    event->audio_queue_bytes = g_av_sync.last_audio_queue_bytes;
    event->audio_host_drift_ns = g_av_sync.audio_host_drift_ns;
    event->audio_virtual_drift_ns = g_av_sync.audio_virtual_drift_ns;
    event->video_host_drift_ns = g_av_sync.video_host_drift_ns;
    event->video_virtual_drift_ns = g_av_sync.video_virtual_drift_ns;
    event->av_host_drift_ns =
        g_av_sync.audio_host_drift_ns - g_av_sync.video_host_drift_ns;
    event->av_virtual_drift_ns =
        g_av_sync.audio_virtual_drift_ns - g_av_sync.video_virtual_drift_ns;

    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
        g_av_sync.events, XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY,
        slot) = *event;
    g_av_sync.write_index = (slot + 1) % cap;
    if (g_av_sync.count < cap) {
        g_av_sync.count++;
    } else {
        g_av_sync.overwritten_events++;
    }
}

void xemu_debug_tools_av_sync_trace_note_audio_batch(const void *apu_state,
                                                      uint32_t samples)
{
    XemuDebugToolsAvSyncTraceEvent event = { 0 };
    const MCPXAPUState *d = apu_state;

    if (!g_av_sync.initialized || !qatomic_read(&g_av_sync.enabled)) {
        return;
    }

    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.event_type = XEMU_DEBUG_TOOLS_AV_SYNC_AUDIO_BATCH;
    event.audio_batch_samples = samples;

    qemu_mutex_lock(&g_av_sync.lock);
    if (!qatomic_read(&g_av_sync.enabled)) {
        qemu_mutex_unlock(&g_av_sync.lock);
        return;
    }

    g_av_sync.audio_batches++;
    g_av_sync.audio_samples += samples;
    if (d != NULL && d->monitor.stream != NULL) {
        g_av_sync.last_audio_queue_bytes =
            SDL_GetAudioStreamQueued(d->monitor.stream);
    } else {
        g_av_sync.last_audio_queue_bytes = -1;
    }
    if (!g_av_sync.audio_baseline_valid) {
        g_av_sync.audio_baseline_valid = true;
        g_av_sync.audio_baseline_samples = g_av_sync.audio_samples;
        g_av_sync.audio_baseline_host_ns = event.host_ns;
        g_av_sync.audio_baseline_virtual_ns = event.qemu_virtual_ns;
    }
    av_sync_update_audio_drift_locked(event.host_ns, event.qemu_virtual_ns);
    av_sync_store_locked(&event);
    qemu_mutex_unlock(&g_av_sync.lock);
}

void xemu_debug_tools_av_sync_trace_note_vblank(uint64_t interval_ns)
{
    XemuDebugToolsAvSyncTraceEvent event = { 0 };

    if (!g_av_sync.initialized || !qatomic_read(&g_av_sync.enabled)) {
        return;
    }

    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.event_type = XEMU_DEBUG_TOOLS_AV_SYNC_VBLANK;

    qemu_mutex_lock(&g_av_sync.lock);
    if (!qatomic_read(&g_av_sync.enabled)) {
        qemu_mutex_unlock(&g_av_sync.lock);
        return;
    }

    if (!g_av_sync.video_baseline_valid) {
        g_av_sync.video_baseline_valid = true;
        g_av_sync.video_baseline_host_ns = event.host_ns;
        g_av_sync.video_baseline_virtual_ns = event.qemu_virtual_ns;
        g_av_sync.video_expected_ns = 0;
    } else {
        g_av_sync.video_expected_ns += interval_ns;
    }
    g_av_sync.video_vblanks++;
    g_av_sync.last_vblank_interval_ns = interval_ns;
    av_sync_update_video_drift_locked(event.host_ns, event.qemu_virtual_ns);
    av_sync_store_locked(&event);
    qemu_mutex_unlock(&g_av_sync.lock);
}

void xemu_debug_tools_av_sync_trace_note_pgraph_flip(uint32_t frame_time)
{
    XemuDebugToolsAvSyncTraceEvent event = { 0 };

    if (!g_av_sync.initialized || !qatomic_read(&g_av_sync.enabled)) {
        return;
    }

    event.qemu_virtual_ns = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    event.host_ns = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    event.event_type = XEMU_DEBUG_TOOLS_AV_SYNC_PGRAPH_FLIP;

    qemu_mutex_lock(&g_av_sync.lock);
    if (!qatomic_read(&g_av_sync.enabled)) {
        qemu_mutex_unlock(&g_av_sync.lock);
        return;
    }

    if (g_av_sync.pgraph_baseline_valid) {
        uint64_t host_interval = av_sync_unsigned_elapsed(
            event.host_ns, g_av_sync.last_pgraph_host_ns);
        uint64_t virtual_interval = av_sync_unsigned_elapsed(
            event.qemu_virtual_ns, g_av_sync.last_pgraph_virtual_ns);
        uint64_t audio_delta =
            g_av_sync.audio_samples >= g_av_sync.last_pgraph_audio_samples ?
            g_av_sync.audio_samples - g_av_sync.last_pgraph_audio_samples : 0;
        uint64_t vblank_delta64 =
            g_av_sync.video_vblanks >= g_av_sync.last_pgraph_video_vblanks ?
            g_av_sync.video_vblanks - g_av_sync.last_pgraph_video_vblanks : 0;

        g_av_sync.last_pgraph_host_interval_ns = host_interval;
        g_av_sync.last_pgraph_virtual_interval_ns = virtual_interval;
        g_av_sync.last_pgraph_audio_sample_delta = audio_delta;
        g_av_sync.last_pgraph_vblank_delta =
            vblank_delta64 > UINT32_MAX ? UINT32_MAX : (uint32_t)vblank_delta64;
        g_av_sync.max_pgraph_host_interval_ns = MAX(
            g_av_sync.max_pgraph_host_interval_ns, host_interval);
        g_av_sync.max_pgraph_virtual_interval_ns = MAX(
            g_av_sync.max_pgraph_virtual_interval_ns, virtual_interval);
        g_av_sync.max_pgraph_vblank_delta = MAX(
            g_av_sync.max_pgraph_vblank_delta,
            g_av_sync.last_pgraph_vblank_delta);
    } else {
        g_av_sync.pgraph_baseline_valid = true;
    }

    g_av_sync.pgraph_flips++;
    g_av_sync.last_pgraph_frame_time = frame_time;
    g_av_sync.last_pgraph_host_ns = event.host_ns;
    g_av_sync.last_pgraph_virtual_ns = event.qemu_virtual_ns;
    g_av_sync.last_pgraph_audio_samples = g_av_sync.audio_samples;
    g_av_sync.last_pgraph_video_vblanks = g_av_sync.video_vblanks;
    g_av_sync.last_pgraph_video_expected_ns = g_av_sync.video_expected_ns;

    av_sync_store_locked(&event);
    qemu_mutex_unlock(&g_av_sync.lock);
}

void xemu_debug_tools_av_sync_trace_set_enabled(int enabled)
{
    bool ok = true;
    av_sync_init();
    qemu_mutex_lock(&g_av_sync.lock);
    if (enabled) {
        XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
            g_av_sync.events, XemuDebugToolsAvSyncTraceEvent,
            XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY,
            g_av_sync.buffer_multiplier, ok);
        if (!ok) {
            qemu_mutex_unlock(&g_av_sync.lock);
            return;
        }
    }
    if (enabled && !g_av_sync.enabled) {
        av_sync_reset_locked();
    }
    qatomic_set(&g_av_sync.enabled, enabled != 0);
    qemu_mutex_unlock(&g_av_sync.lock);
}

void xemu_debug_tools_av_sync_trace_clear(void)
{
    av_sync_init();
    qemu_mutex_lock(&g_av_sync.lock);
    av_sync_reset_locked();
    qemu_mutex_unlock(&g_av_sync.lock);
}

int xemu_debug_tools_av_sync_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok;
    av_sync_init();
    multiplier = xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier);
    qemu_mutex_lock(&g_av_sync.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(
        g_av_sync.events, XemuDebugToolsAvSyncTraceEvent,
        XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY, multiplier, ok);
    if (ok) {
        g_av_sync.buffer_multiplier = multiplier;
        av_sync_reset_locked();
    }
    qemu_mutex_unlock(&g_av_sync.lock);
    return ok ? 1 : 0;
}

uint32_t xemu_debug_tools_av_sync_trace_get_buffer_multiplier(void)
{
    return g_av_sync.buffer_multiplier ? g_av_sync.buffer_multiplier : 1;
}

size_t xemu_debug_tools_av_sync_trace_get_buffer_capacity(void)
{
    return xemu_debug_tools_trace_buffer_capacity(
        XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY,
        xemu_debug_tools_av_sync_trace_get_buffer_multiplier());
}

void xemu_debug_tools_av_sync_trace_get_status(
    XemuDebugToolsAvSyncTraceStatus *status)
{
    if (status == NULL) {
        return;
    }
    uint64_t host_now;
    uint64_t virtual_now;
    XemuDebugToolsAvSyncTraceEvent progress = { 0 };

    av_sync_init();
    host_now = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    virtual_now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&g_av_sync.lock);
    status->enabled = g_av_sync.enabled;
    status->count = g_av_sync.count;
    status->total_events = g_av_sync.total_events;
    status->overwritten_events = g_av_sync.overwritten_events;
    status->ready = (g_av_sync.audio_baseline_valid &&
                     g_av_sync.video_baseline_valid &&
                     g_av_sync.audio_batches > 1 &&
                     g_av_sync.video_vblanks > 1) ? 1u : 0u;
    status->audio_batches = g_av_sync.audio_batches;
    status->audio_samples = g_av_sync.audio_samples;
    status->video_vblanks = g_av_sync.video_vblanks;
    status->video_expected_ns = g_av_sync.video_expected_ns;
    status->last_vblank_interval_ns = g_av_sync.last_vblank_interval_ns;
    status->last_audio_queue_bytes = g_av_sync.last_audio_queue_bytes;
    status->pgraph_ready =
        (g_av_sync.pgraph_baseline_valid && g_av_sync.pgraph_flips > 1) ? 1u : 0u;
    status->pgraph_flips = g_av_sync.pgraph_flips;
    status->last_pgraph_frame_time = g_av_sync.last_pgraph_frame_time;
    status->last_pgraph_vblank_delta = g_av_sync.last_pgraph_vblank_delta;
    status->last_pgraph_audio_sample_delta =
        g_av_sync.last_pgraph_audio_sample_delta;
    status->last_pgraph_host_interval_ns =
        g_av_sync.last_pgraph_host_interval_ns;
    status->last_pgraph_virtual_interval_ns =
        g_av_sync.last_pgraph_virtual_interval_ns;
    status->max_pgraph_host_interval_ns = g_av_sync.max_pgraph_host_interval_ns;
    status->max_pgraph_virtual_interval_ns =
        g_av_sync.max_pgraph_virtual_interval_ns;
    status->max_pgraph_vblank_delta = g_av_sync.max_pgraph_vblank_delta;
    progress.host_ns = host_now;
    progress.qemu_virtual_ns = virtual_now;
    av_sync_fill_pgraph_progress_locked(&progress);
    status->pgraph_host_age_ns = progress.pgraph_host_age_ns;
    status->pgraph_virtual_age_ns = progress.pgraph_virtual_age_ns;
    status->audio_since_pgraph_ns = progress.audio_since_pgraph_ns;
    status->vblank_since_pgraph_ns = progress.vblank_since_pgraph_ns;
    status->audio_host_drift_ns = g_av_sync.audio_host_drift_ns;
    status->audio_virtual_drift_ns = g_av_sync.audio_virtual_drift_ns;
    status->video_host_drift_ns = g_av_sync.video_host_drift_ns;
    status->video_virtual_drift_ns = g_av_sync.video_virtual_drift_ns;
    status->av_host_drift_ns =
        g_av_sync.audio_host_drift_ns - g_av_sync.video_host_drift_ns;
    status->av_virtual_drift_ns =
        g_av_sync.audio_virtual_drift_ns - g_av_sync.video_virtual_drift_ns;
    qemu_mutex_unlock(&g_av_sync.lock);
}

size_t xemu_debug_tools_av_sync_trace_snapshot(
    XemuDebugToolsAvSyncTraceEvent *events, size_t capacity)
{
    size_t ring_capacity;
    size_t count;
    size_t oldest;
    size_t i;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    av_sync_init();
    qemu_mutex_lock(&g_av_sync.lock);
    ring_capacity = xemu_debug_tools_av_sync_trace_get_buffer_capacity();
    count = MIN(g_av_sync.count, capacity);
    oldest = (g_av_sync.write_index + ring_capacity - g_av_sync.count) %
             ring_capacity;
    if (g_av_sync.count > count) {
        oldest = (oldest + (g_av_sync.count - count)) % ring_capacity;
    }
    for (i = 0; i < count; ++i) {
        size_t index = (oldest + i) % ring_capacity;
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(
            g_av_sync.events, XEMU_DEBUG_TOOLS_AV_SYNC_TRACE_CAPACITY,
            index);
    }
    qemu_mutex_unlock(&g_av_sync.lock);
    return count;
}

int xemu_debug_tools_av_sync_trace_mark(unsigned int kind)
{
    if (kind < XEMU_DEBUG_TOOLS_AV_MARK_CUTSCENE_START ||
        kind > XEMU_DEBUG_TOOLS_AV_MARK_SCENE_END) return 0;
    av_sync_init();
    /* Clock values are taken for this user action, not from a stale UI sample. */
    uint64_t host = qemu_clock_get_ns(QEMU_CLOCK_HOST);
    uint64_t virt = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);
    qemu_mutex_lock(&g_av_sync.lock);
    if (!g_av_sync.enabled) {
        qemu_mutex_unlock(&g_av_sync.lock);
        return 0;
    }
    uint64_t sequence = g_av_sync.marker_count++;
    XemuDebugToolsAvSyncMarker *marker = &g_av_sync.markers[
        sequence % XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY];
    *marker = (XemuDebugToolsAvSyncMarker) {
        .sequence = sequence, .host_ns = host, .virtual_ns = virt,
        .audio_samples = g_av_sync.audio_samples,
        .video_vblanks = g_av_sync.video_vblanks,
        .pgraph_flips = g_av_sync.pgraph_flips, .kind = kind,
    };
    qemu_mutex_unlock(&g_av_sync.lock);
    return 1;
}

size_t xemu_debug_tools_av_sync_trace_markers_snapshot(
    XemuDebugToolsAvSyncMarker *markers, size_t capacity, uint64_t *total)
{
    av_sync_init();
    qemu_mutex_lock(&g_av_sync.lock);
    if (total) *total = g_av_sync.marker_count;
    size_t n = markers ? MIN(capacity, MIN(g_av_sync.marker_count,
                         (uint64_t)XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY)) : 0;
    uint64_t first = g_av_sync.marker_count - n;
    for (size_t i = 0; i < n; i++) {
        markers[i] = g_av_sync.markers[
            (first + i) % XEMU_DEBUG_TOOLS_AV_SYNC_MARKER_CAPACITY];
    }
    qemu_mutex_unlock(&g_av_sync.lock);
    return n;
}
