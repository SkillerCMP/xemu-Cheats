/* Info: Shared PGRAPH/PTIMER latency record layouts avoid bridge duplication. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct XemuDebugToolsPgraphIncrementEvent {
    uint64_t sequence, host_start_ns, host_end_ns, host_duration_ns;
    uint64_t virtual_start_ns, virtual_end_ns;
    int64_t virtual_duration_ns;
    uint64_t threshold_ns;
    uint64_t bql_release_ns, surface_lock_wait_ns, surface_update_ns;
    uint64_t pfifo_kick_ns, bql_reacquire_wait_ns;
    uint32_t value, surface_before, surface_after, read_before, read_after, modulo;
    int32_t thread_id;
    uint32_t had_bql, bql_held_after;
} XemuDebugToolsPgraphIncrementEvent;

typedef struct XemuDebugToolsPtimerIrqLatencyEvent {
    uint64_t sequence, irq_set_host_ns, irq_clear_host_ns, service_latency_ns;
    uint64_t irq_set_virtual_ns, irq_clear_virtual_ns;
    int64_t virtual_latency_ns;
    uint64_t threshold_ns;
    uint64_t clear_guest_pc, clear_rdtsc_reference;
    uint32_t clear_guest_pc_valid, clear_rdtsc_reference_valid;
    uint32_t clear_interrupt_request, clear_eflags, clear_halted;
    uint32_t pending_at_set, enabled_at_set, clear_value;
    int32_t set_thread_id, clear_thread_id;
} XemuDebugToolsPtimerIrqLatencyEvent;

typedef struct XemuDebugToolsLatencyTraceStatus {
    int enabled; uint64_t threshold_ns; size_t count;
    uint64_t total_events, overwritten_events;
} XemuDebugToolsLatencyTraceStatus;

#ifdef __cplusplus
}
#endif
