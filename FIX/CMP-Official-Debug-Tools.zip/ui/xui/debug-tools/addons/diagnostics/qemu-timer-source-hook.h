/* Info: Diagnostics owns timer callback-source capture wrappers. */
#pragma once

/* Included by qemu/timer.h after the normal timer helpers are defined. */

/* Info: Capture callback source identity without changing timer behavior. */
static inline void xemu_timer_debug_set_callback_source(
    QEMUTimer *ts, const char *cb_name, const char *source_file, int source_line)
{
    if (ts) {
        ts->xemu_debug_cb_name = cb_name;
        ts->xemu_debug_cb_file = source_file;
        ts->xemu_debug_cb_line = source_line;
    }
}

static inline void xemu_timer_init_ns_debug(
    QEMUTimer *ts, QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    timer_init_ns(ts, type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
}

static inline void xemu_timer_init_us_debug(
    QEMUTimer *ts, QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    timer_init_us(ts, type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
}

static inline void xemu_timer_init_ms_debug(
    QEMUTimer *ts, QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    timer_init_ms(ts, type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
}

static inline QEMUTimer *xemu_timer_new_debug(
    QEMUClockType type, int scale, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    QEMUTimer *ts = timer_new(type, scale, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
    return ts;
}

static inline QEMUTimer *xemu_timer_new_ns_debug(
    QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    QEMUTimer *ts = timer_new_ns(type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
    return ts;
}

static inline QEMUTimer *xemu_timer_new_us_debug(
    QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    QEMUTimer *ts = timer_new_us(type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
    return ts;
}

static inline QEMUTimer *xemu_timer_new_ms_debug(
    QEMUClockType type, QEMUTimerCB *cb, void *opaque,
    const char *cb_name, const char *source_file, int source_line)
{
    QEMUTimer *ts = timer_new_ms(type, cb, opaque);
    xemu_timer_debug_set_callback_source(ts, cb_name, source_file, source_line);
    return ts;
}

#define timer_init_ns(ts, type, cb, opaque) \
    xemu_timer_init_ns_debug((ts), (type), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_init_us(ts, type, cb, opaque) \
    xemu_timer_init_us_debug((ts), (type), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_init_ms(ts, type, cb, opaque) \
    xemu_timer_init_ms_debug((ts), (type), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_new(type, scale, cb, opaque) \
    xemu_timer_new_debug((type), (scale), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_new_ns(type, cb, opaque) \
    xemu_timer_new_ns_debug((type), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_new_us(type, cb, opaque) \
    xemu_timer_new_us_debug((type), (cb), (opaque), #cb, __FILE__, __LINE__)
#define timer_new_ms(type, cb, opaque) \
    xemu_timer_new_ms_debug((type), (cb), (opaque), #cb, __FILE__, __LINE__)

