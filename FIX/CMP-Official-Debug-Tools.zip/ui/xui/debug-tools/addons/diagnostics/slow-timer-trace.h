/* xemu Debug Tools - Diagnostics-owned slow QEMU timer callback recorder. */
#pragma once

#include "slow-timer-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_SLOW_TIMER_TRACE_CAPACITY 128
#define XEMU_DEBUG_TOOLS_SLOW_TIMER_DEFAULT_THRESHOLD_NS 1000000ULL
#define XEMU_DEBUG_TOOLS_SLOW_TIMER_MIN_THRESHOLD_NS 10000ULL
#define XEMU_DEBUG_TOOLS_SLOW_TIMER_MAX_THRESHOLD_NS 10000000000ULL

typedef struct XemuDebugToolsSlowTimerTraceEvent {
    uint64_t sequence;
    uint64_t timer_address;
    uint64_t callback_address;
    uint64_t opaque_address;
    uint64_t host_start_ns;
    uint64_t host_end_ns;
    uint64_t host_duration_ns;
    uint64_t virtual_start_ns;
    uint64_t virtual_end_ns;
    int64_t virtual_duration_ns;
    int64_t scheduled_expire_ns;
    int64_t timer_clock_start_ns;
    int64_t timer_clock_end_ns;
    int64_t dispatch_late_ns;
    uint64_t threshold_ns;
    int32_t clock_type;
    int32_t thread_id;
    uint32_t bql_held_before;
    uint32_t bql_held_after;
    int32_t source_line;
    char callback_name[128];
    char source_file[192];
} XemuDebugToolsSlowTimerTraceEvent;

typedef struct XemuDebugToolsSlowTimerTraceStatus {
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
} XemuDebugToolsSlowTimerTraceStatus;

void xemu_debug_tools_slow_timer_trace_set_enabled(int enabled);
void xemu_debug_tools_slow_timer_trace_set_threshold_ns(uint64_t threshold_ns);
void xemu_debug_tools_slow_timer_trace_clear(void);
int xemu_debug_tools_slow_timer_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_slow_timer_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_slow_timer_trace_get_buffer_capacity(void);
void xemu_debug_tools_slow_timer_trace_get_status(
    XemuDebugToolsSlowTimerTraceStatus *status);
size_t xemu_debug_tools_slow_timer_trace_snapshot(
    XemuDebugToolsSlowTimerTraceEvent *events,
    size_t capacity);

#ifdef __cplusplus
}
#endif
