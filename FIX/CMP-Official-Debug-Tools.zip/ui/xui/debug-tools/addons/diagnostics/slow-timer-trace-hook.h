/* Info: Timer core emits slow-callback timing; Diagnostics owns filtering and storage. */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*XemuDebugToolsSlowTimerObserver)(
    void *timer,
    uintptr_t callback_address,
    void *opaque,
    int clock_type,
    int64_t scheduled_expire_ns,
    int64_t timer_clock_start_ns,
    int64_t timer_clock_end_ns,
    uint64_t host_start_ns,
    uint64_t host_end_ns,
    uint64_t virtual_start_ns,
    uint64_t virtual_end_ns,
    uint64_t threshold_ns,
    int bql_held_before,
    int bql_held_after,
    const char *callback_name,
    const char *source_file,
    int source_line);

/* Implemented by util/qemu-timer.c as a tiny generic timing bridge. */
void xemu_debug_tools_slow_timer_hook_install(
    XemuDebugToolsSlowTimerObserver observer);
void xemu_debug_tools_slow_timer_hook_configure(
    int enabled, uint64_t threshold_ns);

#ifdef __cplusplus
}
#endif
