/* xemu Debug Tools - Diagnostics-owned OHCI slow-frame stage recorder. */
#include "qemu/osdep.h"
#include "qemu/main-loop.h"
#include "qemu/thread.h"

#include "ohci-slow-frame-trace-hook.h"
#include "diagnostics-trace-buffer.h"

typedef struct XemuDebugToolsOhciSlowFrameTraceState {
    QemuMutex lock;
    bool lock_initialized;
    int enabled;
    uint64_t threshold_ns;
    size_t count;
    size_t write_index;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint32_t buffer_multiplier;
    XemuDebugToolsOhciSlowFrameEvent *events[XEMU_DEBUG_TOOLS_TRACE_BUFFER_MAX_MULTIPLIER];
} XemuDebugToolsOhciSlowFrameTraceState;

static XemuDebugToolsOhciSlowFrameTraceState ohci_slow_frame_trace;

static uint64_t ohci_slow_frame_clamp_threshold(uint64_t threshold_ns)
{
    return MAX(XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_MIN_THRESHOLD_NS,
               MIN(threshold_ns,
                   XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_MAX_THRESHOLD_NS));
}

static void ohci_slow_frame_trace_init(void)
{
    if (!ohci_slow_frame_trace.lock_initialized) {
        qemu_mutex_init(&ohci_slow_frame_trace.lock);
        ohci_slow_frame_trace.threshold_ns =
            XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_DEFAULT_THRESHOLD_NS;
        ohci_slow_frame_trace.lock_initialized = true;
        ohci_slow_frame_trace.buffer_multiplier = 1;
    }
}

static void ohci_slow_frame_trace_reset_locked(void)
{
    ohci_slow_frame_trace.count = 0;
    ohci_slow_frame_trace.write_index = 0;
    ohci_slow_frame_trace.total_events = 0;
    ohci_slow_frame_trace.overwritten_events = 0;
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ZERO(ohci_slow_frame_trace.events, XemuDebugToolsOhciSlowFrameEvent, XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY, ohci_slow_frame_trace.buffer_multiplier);
}

uint64_t xemu_debug_tools_ohci_slow_frame_trace_threshold_ns(void)
{
    if (!ohci_slow_frame_trace.lock_initialized ||
        !qatomic_read(&ohci_slow_frame_trace.enabled)) {
        return 0;
    }
    return qatomic_read(&ohci_slow_frame_trace.threshold_ns);
}

void xemu_debug_tools_ohci_slow_frame_trace_record(
    const XemuDebugToolsOhciSlowFrameEvent *source)
{
    XemuDebugToolsOhciSlowFrameEvent event;
    size_t slot;

    if (source == NULL || !ohci_slow_frame_trace.lock_initialized ||
        !qatomic_read(&ohci_slow_frame_trace.enabled)) {
        return;
    }
    if (source->host_duration_ns < source->threshold_ns) {
        return;
    }

    event = *source;
    event.thread_id = qemu_get_thread_id();
    event.bql_held = bql_locked() ? 1 : 0;

    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    if (!qatomic_read(&ohci_slow_frame_trace.enabled) ||
        source->threshold_ns != ohci_slow_frame_trace.threshold_ns) {
        qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
        return;
    }

    slot = ohci_slow_frame_trace.write_index;
    event.sequence = ohci_slow_frame_trace.total_events++;
    const size_t trace_capacity = xemu_debug_tools_ohci_slow_frame_trace_get_buffer_capacity();
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(ohci_slow_frame_trace.events, XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY, slot) = event;
    ohci_slow_frame_trace.write_index = (slot + 1) % trace_capacity;
    if (ohci_slow_frame_trace.count < trace_capacity) {
        ++ohci_slow_frame_trace.count;
    } else {
        ++ohci_slow_frame_trace.overwritten_events;
    }
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
}

void xemu_debug_tools_ohci_slow_frame_trace_set_enabled(int enabled)
{
    ohci_slow_frame_trace_init();
    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    if (enabled) { bool ok; XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(ohci_slow_frame_trace.events, XemuDebugToolsOhciSlowFrameEvent, XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY, ohci_slow_frame_trace.buffer_multiplier, ok); if (!ok) { qemu_mutex_unlock(&ohci_slow_frame_trace.lock); return; } }
    if (enabled && !qatomic_read(&ohci_slow_frame_trace.enabled)) {
        ohci_slow_frame_trace_reset_locked();
    }
    qatomic_set(&ohci_slow_frame_trace.enabled, enabled != 0);
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
}

void xemu_debug_tools_ohci_slow_frame_trace_set_threshold_ns(uint64_t threshold_ns)
{
    const uint64_t clamped = ohci_slow_frame_clamp_threshold(threshold_ns);

    ohci_slow_frame_trace_init();
    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    if (ohci_slow_frame_trace.threshold_ns != clamped) {
        qatomic_set(&ohci_slow_frame_trace.threshold_ns, clamped);
        ohci_slow_frame_trace_reset_locked();
    }
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
}

int xemu_debug_tools_ohci_slow_frame_trace_set_buffer_multiplier(uint32_t multiplier)
{
    bool ok; ohci_slow_frame_trace_init(); multiplier=xemu_debug_tools_trace_buffer_clamp_multiplier(multiplier); qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    XEMU_DEBUG_TOOLS_TRACE_BUFFER_ENSURE(ohci_slow_frame_trace.events, XemuDebugToolsOhciSlowFrameEvent, XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY, multiplier, ok);
    if (ok) { ohci_slow_frame_trace.buffer_multiplier=multiplier; ohci_slow_frame_trace_reset_locked(); }
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock); return ok?1:0;
}
uint32_t xemu_debug_tools_ohci_slow_frame_trace_get_buffer_multiplier(void){ return ohci_slow_frame_trace.buffer_multiplier?ohci_slow_frame_trace.buffer_multiplier:1; }
size_t xemu_debug_tools_ohci_slow_frame_trace_get_buffer_capacity(void){ return xemu_debug_tools_trace_buffer_capacity(XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY,xemu_debug_tools_ohci_slow_frame_trace_get_buffer_multiplier()); }

void xemu_debug_tools_ohci_slow_frame_trace_clear(void)
{
    ohci_slow_frame_trace_init();
    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    ohci_slow_frame_trace_reset_locked();
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
}

void xemu_debug_tools_ohci_slow_frame_trace_get_status(
    XemuDebugToolsOhciSlowFrameStatus *status)
{
    if (status == NULL) {
        return;
    }
    ohci_slow_frame_trace_init();
    memset(status, 0, sizeof(*status));
    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    status->enabled = qatomic_read(&ohci_slow_frame_trace.enabled) ? 1 : 0;
    status->threshold_ns = ohci_slow_frame_trace.threshold_ns;
    status->count = ohci_slow_frame_trace.count;
    status->total_events = ohci_slow_frame_trace.total_events;
    status->overwritten_events = ohci_slow_frame_trace.overwritten_events;
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
}

size_t xemu_debug_tools_ohci_slow_frame_trace_snapshot(
    XemuDebugToolsOhciSlowFrameEvent *events, size_t capacity)
{
    size_t to_copy;
    size_t oldest;
    size_t i;

    if (events == NULL || capacity == 0) {
        return 0;
    }
    ohci_slow_frame_trace_init();
    qemu_mutex_lock(&ohci_slow_frame_trace.lock);
    to_copy = MIN(capacity, ohci_slow_frame_trace.count);
    const size_t trace_capacity=xemu_debug_tools_ohci_slow_frame_trace_get_buffer_capacity();
    oldest = ohci_slow_frame_trace.count == trace_capacity ? ohci_slow_frame_trace.write_index : 0;
    if (to_copy < ohci_slow_frame_trace.count) {
        oldest = (oldest + ohci_slow_frame_trace.count - to_copy) % trace_capacity;
    }
    for (i = 0; i < to_copy; ++i) {
        events[i] = XEMU_DEBUG_TOOLS_TRACE_BUFFER_AT(ohci_slow_frame_trace.events, XEMU_DEBUG_TOOLS_OHCI_SLOW_FRAME_CAPACITY, (oldest+i)%trace_capacity);
    }
    qemu_mutex_unlock(&ohci_slow_frame_trace.lock);
    return to_copy;
}
