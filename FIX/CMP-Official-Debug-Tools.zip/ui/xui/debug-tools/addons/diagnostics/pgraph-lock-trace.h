/* xemu Debug Tools - Diagnostics-owned NV2A PGRAPH lock ownership trace. */
#pragma once

#include "pgraph-lock-trace-hook.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_CAPACITY 4096
#define XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_NS (1000 * 1000LL)
#define XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX 96
#define XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_RENDERER_MAX 32

typedef enum XemuDebugToolsPgraphLockTraceEventType {
    XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_WAIT = 1,
    XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_LONG_HOLD,
} XemuDebugToolsPgraphLockTraceEventType;

typedef struct XemuDebugToolsPgraphLockMethodContext {
    uint32_t valid;
    uint32_t active;
    uint32_t subchannel;
    uint32_t graphics_class;
    uint32_t method;
    uint32_t parameter;
} XemuDebugToolsPgraphLockMethodContext;

typedef struct XemuDebugToolsPgraphLockStateContext {
    uint32_t pending_interrupts;
    uint32_t enabled_interrupts;
    uint32_t primitive_mode;
    uint32_t waiting_for_nop;
    uint32_t waiting_for_flip;
    uint32_t waiting_for_context_switch;
    uint32_t flush_pending;
    uint32_t sync_pending;
    char renderer[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_RENDERER_MAX];
} XemuDebugToolsPgraphLockStateContext;

typedef struct XemuDebugToolsPgraphLockTraceEvent {
    uint64_t sequence;
    uint64_t qemu_virtual_ns;
    uint64_t host_ns;
    uint64_t wait_ns;
    uint64_t held_ns;
    uint64_t owner_held_at_attempt_ns;
    uint64_t owner_acquire_host_ns;
    uint64_t guest_pc_start;
    uint64_t guest_pc_end;
    uint64_t owner_guest_pc_start;
    int32_t thread_id;
    int32_t owner_thread_id;
    int32_t cpu_index;
    int32_t owner_cpu_index;
    int32_t acquire_line;
    int32_t release_line;
    int32_t owner_acquire_line;
    uint32_t guest_pc_start_valid;
    uint32_t guest_pc_end_valid;
    uint32_t owner_guest_pc_start_valid;
    uint32_t event_type;
    XemuDebugToolsPgraphLockMethodContext method;
    XemuDebugToolsPgraphLockMethodContext owner_method;
    XemuDebugToolsPgraphLockStateContext state;
    char acquire_file[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX];
    char release_file[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX];
    char owner_acquire_file[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX];
} XemuDebugToolsPgraphLockTraceEvent;

typedef struct XemuDebugToolsPgraphLockTraceStatus {
    int enabled;
    size_t count;
    uint64_t total_events;
    uint64_t overwritten_events;
    uint64_t long_wait_threshold_ns;
    int32_t current_owner_thread_id;
    int32_t current_owner_cpu_index;
    uint64_t current_owner_held_ns;
    uint64_t current_owner_guest_pc;
    uint32_t current_owner_guest_pc_valid;
    int32_t current_owner_acquire_line;
    XemuDebugToolsPgraphLockMethodContext current_owner_method;
    char current_owner_acquire_file[XEMU_DEBUG_TOOLS_PGRAPH_LOCK_TRACE_FILE_MAX];
} XemuDebugToolsPgraphLockTraceStatus;

void xemu_debug_tools_pgraph_lock_trace_set_enabled(int enabled);
void xemu_debug_tools_pgraph_lock_trace_clear(void);
int xemu_debug_tools_pgraph_lock_trace_set_buffer_multiplier(uint32_t multiplier);
uint32_t xemu_debug_tools_pgraph_lock_trace_get_buffer_multiplier(void);
size_t xemu_debug_tools_pgraph_lock_trace_get_buffer_capacity(void);
void xemu_debug_tools_pgraph_lock_trace_get_status(
    XemuDebugToolsPgraphLockTraceStatus *status);
size_t xemu_debug_tools_pgraph_lock_trace_snapshot(
    XemuDebugToolsPgraphLockTraceEvent *events, size_t capacity);

#ifdef __cplusplus
}
#endif
