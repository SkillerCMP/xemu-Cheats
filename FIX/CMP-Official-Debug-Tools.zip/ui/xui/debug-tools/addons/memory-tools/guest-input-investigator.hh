#pragma once

void xemu_guest_input_investigator_open();
void xemu_guest_input_investigator_draw();
void xemu_guest_input_investigator_notify_game_reset();
