#pragma once

#include "hw/core/cpu.h"
#include "../../backend/xemu-dbg.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Generic exact instruction-stream transport used by Memory Tools on
 * non-WHPX accelerators. The tiny system/cpus.c hook calls the consume helper
 * whenever QEMU reports EXCP_DEBUG. When an exact trace owns that single-step
 * event it records the next guest PC and lets the vCPU continue; user
 * breakpoints/watchpoints remain normal debugger stops. */
int xemu_memory_tools_exact_trace_start(uint32_t initial_eip,
                                        uint32_t range_start,
                                        uint32_t range_end,
                                        uint64_t max_bytes,
                                        int stop_address_enabled,
                                        uint32_t stop_address);
void xemu_memory_tools_exact_trace_stop(void);
void xemu_memory_tools_exact_trace_get_status(XemuDbgTraceStatus *status);
uint64_t xemu_memory_tools_exact_trace_copy(uint64_t start_index,
                                            uint32_t *entries,
                                            uint64_t entry_capacity);
int xemu_memory_tools_exact_trace_handle_guest_debug(CPUState *cpu);

#ifdef __cplusplus
}
#endif
