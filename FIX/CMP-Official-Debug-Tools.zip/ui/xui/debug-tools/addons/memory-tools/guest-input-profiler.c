/*
 * xemu Debug Tools - TCG guest-input investigation profiler.
 *
 * This is intentionally a short-lived diagnostic profiler rather than a
 * general execution tracer. While active, the TCG hook reports each dispatched
 * basic-block PC. A fixed open-address table counts unique PCs without
 * allocating or taking a mutex on the vCPU hot path.
 */

#include "qemu/osdep.h"
#include "qemu/atomic.h"

#include "guest-input-profiler-hook.h"

#define GUEST_INPUT_PROFILE_CAPACITY (1u << 18)
#define GUEST_INPUT_PROFILE_MASK (GUEST_INPUT_PROFILE_CAPACITY - 1u)

typedef struct GuestInputProfileSlot {
    uint32_t address;
    uint64_t hits;
} GuestInputProfileSlot;

static GuestInputProfileSlot g_guest_input_profile[GUEST_INPUT_PROFILE_CAPACITY];
static uint32_t g_guest_input_range_start;
static uint32_t g_guest_input_range_end;
static uint64_t g_guest_input_total_hits;
static uint64_t g_guest_input_dropped;
static uint64_t g_guest_input_unique_count;
static int g_guest_input_active;

static inline uint32_t guest_input_hash(uint32_t address)
{
    return address * 2654435761u;
}

int xemu_debug_tools_guest_input_profiler_active(void)
{
    return qatomic_read(&g_guest_input_active) != 0;
}

void xemu_debug_tools_guest_input_profiler_record(uint32_t guest_pc)
{
    if (!qatomic_read(&g_guest_input_active) ||
        guest_pc < g_guest_input_range_start ||
        guest_pc > g_guest_input_range_end) {
        return;
    }

    qatomic_fetch_inc(&g_guest_input_total_hits);
    uint32_t index = guest_input_hash(guest_pc) & GUEST_INPUT_PROFILE_MASK;
    for (uint32_t probe = 0; probe < GUEST_INPUT_PROFILE_CAPACITY; ++probe) {
        GuestInputProfileSlot *slot = &g_guest_input_profile[index];
        if (slot->hits == 0) {
            slot->address = guest_pc;
            slot->hits = 1;
            qatomic_fetch_inc(&g_guest_input_unique_count);
            return;
        }
        if (slot->address == guest_pc) {
            ++slot->hits;
            return;
        }
        index = (index + 1u) & GUEST_INPUT_PROFILE_MASK;
    }

    qatomic_fetch_inc(&g_guest_input_dropped);
}

void xemu_debug_tools_guest_input_profiler_start(uint32_t range_start,
                                                 uint32_t range_end)
{
    qatomic_set(&g_guest_input_active, 0);
    memset(g_guest_input_profile, 0, sizeof(g_guest_input_profile));
    g_guest_input_range_start = range_start;
    g_guest_input_range_end = range_end;
    qatomic_set_u64(&g_guest_input_total_hits, 0);
    qatomic_set_u64(&g_guest_input_dropped, 0);
    qatomic_set_u64(&g_guest_input_unique_count, 0);
    qatomic_set(&g_guest_input_active, 1);
}

void xemu_debug_tools_guest_input_profiler_stop(void)
{
    qatomic_set(&g_guest_input_active, 0);
}

void xemu_debug_tools_guest_input_profiler_reset(void)
{
    qatomic_set(&g_guest_input_active, 0);
    memset(g_guest_input_profile, 0, sizeof(g_guest_input_profile));
    g_guest_input_range_start = 0;
    g_guest_input_range_end = 0;
    qatomic_set_u64(&g_guest_input_total_hits, 0);
    qatomic_set_u64(&g_guest_input_dropped, 0);
    qatomic_set_u64(&g_guest_input_unique_count, 0);
}

size_t xemu_debug_tools_guest_input_profiler_copy(
    XemuDebugToolsGuestInputProfileEntry *entries, size_t capacity)
{
    if (entries == NULL || capacity == 0 ||
        qatomic_read(&g_guest_input_active)) {
        return 0;
    }

    size_t copied = 0;
    for (uint32_t i = 0; i < GUEST_INPUT_PROFILE_CAPACITY && copied < capacity; ++i) {
        const GuestInputProfileSlot *slot = &g_guest_input_profile[i];
        if (slot->hits == 0) {
            continue;
        }
        entries[copied].address = slot->address;
        entries[copied].hits = slot->hits;
        ++copied;
    }
    return copied;
}

size_t xemu_debug_tools_guest_input_profiler_unique_count(void)
{
    return (size_t)qatomic_read_u64(&g_guest_input_unique_count);
}

uint64_t xemu_debug_tools_guest_input_profiler_total_hits(void)
{
    return qatomic_read_u64(&g_guest_input_total_hits);
}

uint64_t xemu_debug_tools_guest_input_profiler_dropped(void)
{
    return qatomic_read_u64(&g_guest_input_dropped);
}
