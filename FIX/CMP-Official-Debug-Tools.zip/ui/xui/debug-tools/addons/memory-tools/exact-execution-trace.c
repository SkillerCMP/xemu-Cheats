/*
 * xemu Memory Tools - generic exact instruction trace transport
 *
 * WHPX retains its existing specialized #DB transport. This backend covers
 * QEMU accelerators whose EXCP_DEBUG path reaches cpu_handle_guest_debug(),
 * including TCG, KVM and HVF. All state/recording logic remains in the Memory
 * Tools addon; upstream xemu only owns one small consume hook.
 */

#include "qemu/osdep.h"
#include "qemu/atomic.h"
#include "exec/breakpoint.h"
#include "system/cpus.h"
#include "system/hw_accel.h"

#include "exact-execution-trace.h"

typedef struct XemuMemoryExactTraceState {
    uint32_t *entries;
    uint64_t entry_capacity;
    uint64_t entry_count;
    int active;
    int stop_reason;
    uint32_t range_start;
    uint32_t range_end;
    uint32_t stop_address;
    int stop_address_enabled;
    uint32_t last_eip;
} XemuMemoryExactTraceState;

static XemuMemoryExactTraceState xemu_memory_exact_trace_state;

static bool xemu_memory_exact_trace_address_in_range(uint32_t eip)
{
    return eip >= xemu_memory_exact_trace_state.range_start &&
           eip <= xemu_memory_exact_trace_state.range_end;
}

static int xemu_memory_exact_trace_record(uint32_t eip)
{
    uint64_t count;

    qatomic_set(&xemu_memory_exact_trace_state.last_eip, eip);

    if (xemu_memory_exact_trace_address_in_range(eip)) {
        count = qatomic_read_u64(&xemu_memory_exact_trace_state.entry_count);
        if (count >= xemu_memory_exact_trace_state.entry_capacity) {
            qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                        XEMU_DBG_TRACE_STOP_SIZE_LIMIT);
            qatomic_set(&xemu_memory_exact_trace_state.active, 0);
            return 1;
        }

        xemu_memory_exact_trace_state.entries[count] = eip;
        qatomic_set_u64(&xemu_memory_exact_trace_state.entry_count, count + 1);
    }

    if (xemu_memory_exact_trace_state.stop_address_enabled &&
        eip == xemu_memory_exact_trace_state.stop_address) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_ADDRESS);
        qatomic_set(&xemu_memory_exact_trace_state.active, 0);
        return 1;
    }

    if (qatomic_read_u64(&xemu_memory_exact_trace_state.entry_count) >=
        xemu_memory_exact_trace_state.entry_capacity) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_SIZE_LIMIT);
        qatomic_set(&xemu_memory_exact_trace_state.active, 0);
        return 1;
    }

    return 0;
}

int xemu_memory_tools_exact_trace_start(uint32_t initial_eip,
                                        uint32_t range_start,
                                        uint32_t range_end,
                                        uint64_t max_bytes,
                                        int stop_address_enabled,
                                        uint32_t stop_address)
{
    uint64_t capacity;
    uint32_t *entries;

    if (qatomic_read(&xemu_memory_exact_trace_state.active) ||
        range_start > range_end || max_bytes < sizeof(uint32_t)) {
        return 0;
    }

    capacity = max_bytes / sizeof(uint32_t);
    entries = g_try_new(uint32_t, capacity);
    if (entries == NULL) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_ERROR);
        return 0;
    }

    g_free(xemu_memory_exact_trace_state.entries);
    memset(&xemu_memory_exact_trace_state, 0,
           sizeof(xemu_memory_exact_trace_state));
    xemu_memory_exact_trace_state.entries = entries;
    xemu_memory_exact_trace_state.entry_capacity = capacity;
    xemu_memory_exact_trace_state.range_start = range_start;
    xemu_memory_exact_trace_state.range_end = range_end;
    xemu_memory_exact_trace_state.stop_address_enabled =
        stop_address_enabled != 0;
    xemu_memory_exact_trace_state.stop_address = stop_address;
    qatomic_set(&xemu_memory_exact_trace_state.active, 1);

    /* First entry is the instruction about to execute. Every consumed
     * single-step debug event then contributes its exact successor EIP. */
    xemu_memory_exact_trace_record(initial_eip);
    return 1;
}

void xemu_memory_tools_exact_trace_stop(void)
{
    if (qatomic_xchg(&xemu_memory_exact_trace_state.active, 0)) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_MANUAL);
    }
}

void xemu_memory_tools_exact_trace_get_status(XemuDbgTraceStatus *status)
{
    if (status == NULL) {
        return;
    }

    status->active = qatomic_read(&xemu_memory_exact_trace_state.active);
    status->stop_reason =
        qatomic_read(&xemu_memory_exact_trace_state.stop_reason);
    status->entry_count =
        qatomic_read_u64(&xemu_memory_exact_trace_state.entry_count);
    status->entry_capacity = xemu_memory_exact_trace_state.entry_capacity;
    status->last_eip = qatomic_read(&xemu_memory_exact_trace_state.last_eip);
}

uint64_t xemu_memory_tools_exact_trace_copy(uint64_t start_index,
                                            uint32_t *entries,
                                            uint64_t entry_capacity)
{
    uint64_t count;
    uint64_t copy_count;

    if (entries == NULL || entry_capacity == 0 ||
        xemu_memory_exact_trace_state.entries == NULL) {
        return 0;
    }

    count = qatomic_read_u64(&xemu_memory_exact_trace_state.entry_count);
    if (start_index >= count) {
        return 0;
    }

    copy_count = MIN(entry_capacity, count - start_index);
    memcpy(entries, &xemu_memory_exact_trace_state.entries[start_index],
           copy_count * sizeof(uint32_t));
    return copy_count;
}

int xemu_memory_tools_exact_trace_handle_guest_debug(CPUState *cpu)
{
    uint32_t next_eip;
    int trace_stopped;

    if (!qatomic_read(&xemu_memory_exact_trace_state.active) || cpu == NULL) {
        return 0;
    }

    /* A real debugger breakpoint/watchpoint always wins over the continuous
     * single-step transport. Do not hide it behind the watcher. */
    cpu_synchronize_state(cpu);
    if (cpu->cc == NULL || cpu->cc->get_pc == NULL) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_ERROR);
        qatomic_set(&xemu_memory_exact_trace_state.active, 0);
        cpu_single_step(cpu, 0);
        return 0;
    }

    next_eip = (uint32_t)cpu->cc->get_pc(cpu);
    if (cpu->watchpoint_hit != NULL ||
        cpu_breakpoint_test(cpu, next_eip, BP_GDB)) {
        qatomic_set(&xemu_memory_exact_trace_state.stop_reason,
                    XEMU_DBG_TRACE_STOP_BREAKPOINT);
        qatomic_set(&xemu_memory_exact_trace_state.active, 0);
        cpu_single_step(cpu, 0);
        return 0;
    }

    trace_stopped = xemu_memory_exact_trace_record(next_eip);
    if (trace_stopped) {
        /* Size/address stops mirror the WHPX transport: stop tracing but keep
         * the guest running. The frontend can summarize the completed stream. */
        cpu_single_step(cpu, 0);
    }

    /* Consume this EXCP_DEBUG so cpu_handle_guest_debug() does not pause the
     * VM after every instruction. The accelerator loop will immediately run
     * again while single-step remains armed. */
    return 1;
}
