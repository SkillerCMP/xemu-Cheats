//
// xemu Memory Tools - Guest Input Investigator
//
// Compares short TCG basic-block profiles from a working controller window and
// a failed-after-reconnect window. The tool is intentionally generic: it does
// not know game/title IDs or alter SDL/XID/OHCI behavior.
//

#include "guest-input-investigator.hh"
#include "guest-input-profiler-hook.h"
#include "cheat-engine-memory.h"
#include "current-game.hh"
#include "../../debug-output-paths.hh"
#include "../diagnostics/controller-xid-trace.h"
#include "../common.hh"

#include <glib/gstdio.h>

#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

struct ProfileRow {
    uint32_t address = 0;
    uint64_t hits = 0;
};

struct DiffRow {
    uint32_t address = 0;
    uint64_t working_hits = 0;
    uint64_t failed_hits = 0;
};

struct GuestInputInvestigatorState {
    bool open = false;
    bool focus_requested = false;
    int capture_slot = 0; // 0=None, 1=Working, 2=Failed
    char range_start_text[16] = "00010000";
    char range_end_text[16] = "7FFFFFFF";
    uint64_t working_total = 0;
    uint64_t failed_total = 0;
    uint64_t working_dropped = 0;
    uint64_t failed_dropped = 0;
    bool show_all = false;
    std::string status;
    std::vector<ProfileRow> working_rows;
    std::vector<ProfileRow> failed_rows;
    std::vector<DiffRow> diff_rows;
};

GuestInputInvestigatorState g_input_state;

bool parse_hex_address(const char *text, uint32_t &value)
{
    if (text == nullptr || *text == '\0') {
        return false;
    }
    errno = 0;
    char *end = nullptr;
    const unsigned long parsed = std::strtoul(text, &end, 16);
    if (errno != 0 || end == text || *end != '\0' || parsed > 0xFFFFFFFFul) {
        return false;
    }
    value = (uint32_t)parsed;
    return true;
}

double normalized_rate(uint64_t hits, uint64_t total)
{
    return total == 0 ? 0.0 : (double)hits / (double)total;
}

double normalized_failed_ratio(uint64_t working_hits,
                               uint64_t working_total,
                               uint64_t failed_hits,
                               uint64_t failed_total)
{
    const double working = normalized_rate(working_hits, working_total);
    if (working <= 0.0) {
        return failed_hits == 0 ? 1.0 : 999999.0;
    }
    return normalized_rate(failed_hits, failed_total) / working;
}

void rebuild_diff()
{
    struct Pair {
        uint64_t working = 0;
        uint64_t failed = 0;
    };

    std::unordered_map<uint32_t, Pair> merged;
    merged.reserve(g_input_state.working_rows.size() +
                   g_input_state.failed_rows.size());
    for (const auto &row : g_input_state.working_rows) {
        merged[row.address].working = row.hits;
    }
    for (const auto &row : g_input_state.failed_rows) {
        merged[row.address].failed = row.hits;
    }

    g_input_state.diff_rows.clear();
    g_input_state.diff_rows.reserve(merged.size());
    for (const auto &it : merged) {
        g_input_state.diff_rows.push_back(
            {it.first, it.second.working, it.second.failed});
    }

    const uint64_t working_total = g_input_state.working_total;
    const uint64_t failed_total = g_input_state.failed_total;
    std::sort(g_input_state.diff_rows.begin(), g_input_state.diff_rows.end(),
              [working_total, failed_total](const DiffRow &a, const DiffRow &b) {
                  const double ar = normalized_failed_ratio(
                      a.working_hits, working_total, a.failed_hits, failed_total);
                  const double br = normalized_failed_ratio(
                      b.working_hits, working_total, b.failed_hits, failed_total);
                  if (ar != br) {
                      return ar < br;
                  }
                  if (a.working_hits != b.working_hits) {
                      return a.working_hits > b.working_hits;
                  }
                  return a.address < b.address;
              });
}

bool start_profile(int slot)
{
    if (slot != 1 && slot != 2) {
        g_input_state.status = "Invalid Guest Input capture slot.";
        return false;
    }
    if (g_input_state.capture_slot != 0 ||
        xemu_debug_tools_guest_input_profiler_active()) {
        g_input_state.status = "A Guest Input profile is already running.";
        return false;
    }
    if (xemu_cheat_debug_backend() != XEMU_CHEAT_DEBUG_BACKEND_TCG) {
        g_input_state.status =
            "Guest Input Investigator currently requires the TCG backend.";
        return false;
    }

    uint32_t range_start = 0;
    uint32_t range_end = 0;
    if (!parse_hex_address(g_input_state.range_start_text, range_start) ||
        !parse_hex_address(g_input_state.range_end_text, range_end) ||
        range_start > range_end) {
        g_input_state.status = "Invalid Guest Input profile address range.";
        return false;
    }

    xemu_debug_tools_guest_input_profiler_start(range_start, range_end);
    g_input_state.capture_slot = slot;
    g_input_state.status = slot == 1
        ? "WORKING profile active. Return to the game and repeatedly press the test buttons."
        : "FAILED profile active. Reproduce the dead-input state and press the same buttons.";
    return true;
}

void stop_profile(bool save_snapshot)
{
    const int slot = g_input_state.capture_slot;
    if (slot == 0 && !xemu_debug_tools_guest_input_profiler_active()) {
        return;
    }

    xemu_debug_tools_guest_input_profiler_stop();
    g_input_state.capture_slot = 0;

    if (!save_snapshot || (slot != 1 && slot != 2)) {
        g_input_state.status = "Guest Input profile stopped without saving.";
        return;
    }

    const size_t unique_count =
        xemu_debug_tools_guest_input_profiler_unique_count();
    std::vector<XemuDebugToolsGuestInputProfileEntry> raw(unique_count);
    const size_t copied = xemu_debug_tools_guest_input_profiler_copy(
        raw.data(), raw.size());
    raw.resize(copied);

    std::vector<ProfileRow> snapshot;
    snapshot.reserve(raw.size());
    for (const auto &entry : raw) {
        snapshot.push_back({entry.address, entry.hits});
    }
    std::sort(snapshot.begin(), snapshot.end(),
              [](const ProfileRow &a, const ProfileRow &b) {
                  return a.address < b.address;
              });

    const uint64_t total = xemu_debug_tools_guest_input_profiler_total_hits();
    const uint64_t dropped = xemu_debug_tools_guest_input_profiler_dropped();
    if (slot == 1) {
        g_input_state.working_rows = std::move(snapshot);
        g_input_state.working_total = total;
        g_input_state.working_dropped = dropped;
    } else {
        g_input_state.failed_rows = std::move(snapshot);
        g_input_state.failed_total = total;
        g_input_state.failed_dropped = dropped;
    }

    rebuild_diff();

    char status[224];
    std::snprintf(status, sizeof(status),
                  "%s profile saved: %zu unique basic blocks, %llu executions, %llu dropped.",
                  slot == 1 ? "WORKING" : "FAILED", copied,
                  (unsigned long long)total, (unsigned long long)dropped);
    g_input_state.status = status;
}

void clear_profiles()
{
    if (g_input_state.capture_slot != 0 ||
        xemu_debug_tools_guest_input_profiler_active()) {
        stop_profile(false);
    }
    g_input_state.working_rows.clear();
    g_input_state.failed_rows.clear();
    g_input_state.diff_rows.clear();
    g_input_state.working_total = 0;
    g_input_state.failed_total = 0;
    g_input_state.working_dropped = 0;
    g_input_state.failed_dropped = 0;
    xemu_debug_tools_guest_input_profiler_reset();
    g_input_state.status = "Guest Input profiles cleared.";
}

const char *controller_xid_event_name(uint32_t type)
{
    switch (type) {
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_ADDED: return "HOST_GAMEPAD_ADDED";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_OPENED: return "HOST_GAMEPAD_OPENED";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_OPEN_FAILED: return "HOST_GAMEPAD_OPEN_FAILED";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_GAMEPAD_REMOVED: return "HOST_GAMEPAD_REMOVED";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_BIND: return "HOST_BIND";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_UNBIND: return "HOST_UNBIND";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_INPUT_STATE: return "HOST_INPUT_STATE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_REALIZE: return "XID_REALIZE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_UNREALIZE: return "XID_UNREALIZE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_RESET: return "XID_RESET";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_GET_REPORT: return "GET_REPORT";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INTERRUPT_IN: return "INTERRUPT_IN";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_INPUT_STATE: return "XID_INPUT_STATE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_BOUND_MISSING: return "XID_BOUND_MISSING";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_ATTACH: return "OHCI_PORT_ATTACH";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_DETACH: return "OHCI_PORT_DETACH";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_RHSC: return "OHCI_RHSC";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_STATUS_WRITE: return "OHCI_PORT_STATUS_WRITE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_PORT_RESET: return "OHCI_PORT_RESET";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_SETUP_TD: return "OHCI_SETUP_TD";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_DEVICE_MISSING: return "OHCI_TD_DEVICE_MISSING";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_USB_CONTROL_REQUEST: return "USB_CONTROL_REQUEST";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_PERSISTENT_NEUTRAL: return "HOST_PERSISTENT_NEUTRAL";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_HOST_PERSISTENT_REATTACHED: return "HOST_PERSISTENT_REATTACHED";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_ON: return "INPUT_TEST_MODE_ON";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_INPUT_TEST_MODE_OFF: return "INPUT_TEST_MODE_OFF";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_XID_IN_PACKET_COMPLETE: return "XID_IN_PACKET_COMPLETE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_TD_COMPLETE: return "OHCI_TD_COMPLETE";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_DONE_HEAD: return "OHCI_DONE_HEAD";
    case XEMU_DEBUG_TOOLS_CONTROLLER_XID_OHCI_WDH_IRQ: return "OHCI_WDH_IRQ";
    default: return "UNKNOWN";
    }
}

std::string controller_xid_report_hex(
    const XemuDebugToolsControllerXidTraceEvent &event)
{
    std::ostringstream os;
    const uint32_t count = std::min<uint32_t>(
        event.report_length, XEMU_DEBUG_TOOLS_CONTROLLER_XID_REPORT_MAX);
    os << std::hex << std::uppercase << std::setfill('0');
    for (uint32_t i = 0; i < count; ++i) {
        os << std::setw(2) << static_cast<unsigned>(event.report[i]);
    }
    return os.str();
}

void write_profile_rows(std::ostream &os, const std::vector<ProfileRow> &rows,
                        uint64_t total)
{
    os << "Address Hits RatePer1M\n";
    os << std::hex << std::uppercase << std::setfill('0');
    for (const auto &row : rows) {
        const double rate = normalized_rate(row.hits, total) * 1000000.0;
        os << std::setw(8) << row.address << std::dec << " "
           << row.hits << " " << std::fixed << std::setprecision(3) << rate
           << "\n" << std::hex << std::uppercase << std::setfill('0');
    }
    os << std::dec;
}

bool save_controller_snapshot()
{
    if (g_input_state.capture_slot != 0 ||
        xemu_debug_tools_guest_input_profiler_active()) {
        g_input_state.status =
            "Stop the active INPUT DIFF capture before saving Controller Snapshot.";
        return false;
    }

    std::string error;
    if (!XemuDebugOutput::EnsureDirectory(XemuDebugOutput::Folder::Snapshots,
                                          &error)) {
        g_input_state.status = error;
        return false;
    }

    const auto &game = current_game_manager.Get();
    const std::string game_id = game.valid
        ? CurrentGameManager::FormatDatabaseGameId(game.title_id)
        : "NO-XBE";
    const std::string stem = game_id + "-ControllerSnapshot-" +
                             XemuDebugOutput::Timestamp();
    const std::string output = XemuDebugOutput::UniqueFilePath(
        XemuDebugOutput::Folder::Snapshots, stem, ".txt");
    if (output.empty()) {
        g_input_state.status =
            "Could not create a unique DEBUG/Snapshots Controller Snapshot filename.";
        return false;
    }

    std::ostringstream os;

    XemuDebugToolsControllerXidTraceStatus controller_status{};
    xemu_debug_tools_controller_xid_trace_get_status(&controller_status);
    std::vector<XemuDebugToolsControllerXidTraceEvent> controller_trace(
        controller_status.count);
    if (!controller_trace.empty()) {
        const size_t copied = xemu_debug_tools_controller_xid_trace_snapshot(
            controller_trace.data(), controller_trace.size());
        controller_trace.resize(copied);
    }

    os << "XEMU Controller Snapshot v1.00\n";
    os << "========================================\n";
    if (game.valid) {
        os << "Game: " << game.title_name << "\n";
        os << "Game ID: " << game_id << "\n";
        os << "Title ID: " << CurrentGameManager::FormatTitleId(game.title_id) << "\n";
        os << "Version: " << std::hex << std::uppercase << std::setw(8)
           << std::setfill('0') << game.version << std::dec << "\n";
        os << "XBE Identity SHA-256: " << game.header_sha256 << "\n";
        os << "XBE Legacy Header Identity SHA-256: "
           << game.legacy_header_sha256 << "\n";
        os << "XBE Raw Header SHA-256: " << game.raw_header_sha256 << "\n";
        os << "XBE Disc SHA-256: " << game.disc_xbe_sha256 << "\n";
    } else {
        os << "Game: <not detected>\n";
    }
    os << "Profiler address range: " << g_input_state.range_start_text << "-"
       << g_input_state.range_end_text << "\n";
    os << "WORKING unique/executions/dropped: "
       << g_input_state.working_rows.size() << "/" << g_input_state.working_total
       << "/" << g_input_state.working_dropped << "\n";
    os << "FAILED unique/executions/dropped: "
       << g_input_state.failed_rows.size() << "/" << g_input_state.failed_total
       << "/" << g_input_state.failed_dropped << "\n";
    os << "DIFF addresses: " << g_input_state.diff_rows.size() << "\n";
    os << "Controller trace retained/stored observations/total observations: "
       << controller_trace.size() << "/" << controller_status.stored_events
       << "/" << controller_status.total_observations << "\n\n";

    os << "INPUT DIFF - COMPLETE COMPARISON\n";
    os << "----------------------------------------\n";
    os << "Sorted by normalized FAILED/WORKING ratio, then WORKING hits.\n";
    os << "Every address is exported; this section is not limited by the UI filter.\n";
    os << "Address WorkingHits FailedHits WorkPer1M FailPer1M FailWorkPct Classification\n";
    for (const auto &row : g_input_state.diff_rows) {
        const double work_rate = normalized_rate(
            row.working_hits, g_input_state.working_total);
        const double fail_rate = normalized_rate(
            row.failed_hits, g_input_state.failed_total);
        const double ratio = normalized_failed_ratio(
            row.working_hits, g_input_state.working_total,
            row.failed_hits, g_input_state.failed_total);
        os << std::hex << std::uppercase << std::setw(8) << std::setfill('0')
           << row.address << std::dec << " " << row.working_hits << " "
           << row.failed_hits << " " << std::fixed << std::setprecision(3)
           << work_rate * 1000000.0 << " " << fail_rate * 1000000.0 << " ";
        if (row.failed_hits == 0 && row.working_hits != 0) {
            os << "0.000 WORKING_ONLY";
        } else if (row.working_hits == 0) {
            os << "N/A FAILED_ONLY";
        } else {
            os << std::setprecision(3) << ratio * 100.0 << " BOTH";
        }
        os << "\n";
    }
    os << "\n";

    os << "WORKING RAW PROFILE - COMPLETE\n";
    os << "----------------------------------------\n";
    write_profile_rows(os, g_input_state.working_rows, g_input_state.working_total);
    os << "\nFAILED RAW PROFILE - COMPLETE\n";
    os << "----------------------------------------\n";
    write_profile_rows(os, g_input_state.failed_rows, g_input_state.failed_total);
    os << "\n";

    os << "Controller / XID / OHCI USB Reconnect Trace\n";
    os << "----------------------------------------\n";
    os << "Trace enabled: " << controller_status.enabled << "\n";
    os << "Buffered events: " << controller_status.count << " / "
       << XEMU_DEBUG_TOOLS_CONTROLLER_XID_TRACE_CAPACITY << "\n";
    os << "Stored events: " << controller_status.stored_events << "\n";
    os << "Total observations: " << controller_status.total_observations << "\n";
    os << "Overwritten events: " << controller_status.overwritten_events << "\n";
    os << "Observation counters:\n";
    for (uint32_t type = 1;
         type < XEMU_DEBUG_TOOLS_CONTROLLER_XID_EVENT_COUNT; ++type) {
        os << "  " << controller_xid_event_name(type) << ": "
           << controller_status.observations[type] << "\n";
    }
    os << "Note: event rows are the complete retained ring; counters above cover all observations.\n";
    os << "Columns: seq virtual_ns host_ns event port sdl_id xid_device "
          "host_buttons host_axes[6] xid_buttons analog[8] sticks[4] "
          "value0 value1 value2 value3 value4 report_hex save name guid\n";
    for (const auto &event : controller_trace) {
        os << event.sequence << " " << event.qemu_virtual_ns << " "
           << event.host_ns << " " << controller_xid_event_name(event.event_type)
           << " " << event.port << " " << event.instance_id << " 0x"
           << std::hex << std::uppercase << event.xid_device << std::dec
           << " 0x" << std::hex << std::uppercase << event.host_buttons
           << std::dec;
        for (int axis : event.host_axis) {
            os << " " << axis;
        }
        os << " 0x" << std::hex << std::uppercase << event.xid_buttons
           << std::dec;
        for (unsigned analog : event.xid_analog) {
            os << " " << analog;
        }
        os << " " << event.thumb_lx << " " << event.thumb_ly
           << " " << event.thumb_rx << " " << event.thumb_ry
           << " " << event.value0 << " " << event.value1
           << " " << event.value2 << " " << event.value3
           << " " << event.value4 << " " << controller_xid_report_hex(event)
           << " " << event.save_binding << " \"" << event.name
           << "\" \"" << event.guid << "\"\n";
    }

    const std::string text = os.str();
    FILE *out = g_fopen(output.c_str(), "wb");
    if (out == nullptr) {
        g_input_state.status = "Could not create Controller Snapshot: " + output;
        return false;
    }
    const size_t written = std::fwrite(text.data(), 1, text.size(), out);
    const int close_result = std::fclose(out);
    if (written != text.size() || close_result != 0) {
        g_input_state.status = "Failed while writing Controller Snapshot: " + output;
        return false;
    }

    g_input_state.status = "Controller Snapshot saved: " + output;
    return true;
}

void open_snapshots_folder()
{
    std::string error;
    if (XemuDebugOutput::OpenDirectory(XemuDebugOutput::Folder::Snapshots,
                                       &error)) {
        g_input_state.status = "Opened DEBUG/Snapshots.";
    } else {
        g_input_state.status = error;
    }
}

} // namespace

void xemu_guest_input_investigator_open()
{
    g_input_state.open = true;
    g_input_state.focus_requested = true;
}

void xemu_guest_input_investigator_notify_game_reset()
{
    if (g_input_state.capture_slot != 0 ||
        xemu_debug_tools_guest_input_profiler_active()) {
        xemu_debug_tools_guest_input_profiler_stop();
    }
    g_input_state.capture_slot = 0;
    g_input_state.working_rows.clear();
    g_input_state.failed_rows.clear();
    g_input_state.diff_rows.clear();
    g_input_state.working_total = 0;
    g_input_state.failed_total = 0;
    g_input_state.working_dropped = 0;
    g_input_state.failed_dropped = 0;
    xemu_debug_tools_guest_input_profiler_reset();
    g_input_state.status = "Guest reset: Guest Input profiles cleared.";
}

void xemu_guest_input_investigator_draw()
{
    if (!g_input_state.open) {
        return;
    }

    if (g_input_state.focus_requested) {
        ImGui::SetNextWindowFocus();
        ImGui::SetNextWindowSize(ImVec2(830.0f, 650.0f), ImGuiCond_Appearing);
        g_input_state.focus_requested = false;
    }

    if (!ImGui::Begin("Guest Input Investigator", &g_input_state.open,
                      ImGuiWindowFlags_NoCollapse)) {
        ImGui::End();
        return;
    }

    ImGui::TextUnformatted("TCG basic-block profile comparison for guest controller polling.");
    ImGui::TextWrapped(
        "Capture a short WORKING window while repeatedly pressing a few known buttons. "
        "After the controller reconnects but the game stops responding, capture a FAILED "
        "window while pressing the same buttons. Addresses whose normalized execution "
        "rate disappears or drops sharply are candidates for the game's input/XInput path.");
    ImGui::TextDisabled(
        "While a capture is active, TCG direct TB chaining is disabled so each dispatched "
        "basic block can be observed. This is diagnostic-only and may temporarily reduce performance.");

    ImGui::Separator();
    ImGui::SetNextItemWidth(120.0f);
    ImGui::InputText("Range Start", g_input_state.range_start_text,
                     sizeof(g_input_state.range_start_text),
                     ImGuiInputTextFlags_CharsHexadecimal);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(120.0f);
    ImGui::InputText("Range End", g_input_state.range_end_text,
                     sizeof(g_input_state.range_end_text),
                     ImGuiInputTextFlags_CharsHexadecimal);
    ImGui::SameLine();
    ImGui::TextDisabled("Default excludes Xbox kernel code and focuses on game/XDK code.");

    const bool profile_active = g_input_state.capture_slot != 0 ||
        xemu_debug_tools_guest_input_profiler_active();
    if (!profile_active) {
        if (ImGui::Button("Start WORKING Capture", ImVec2(180.0f, 0.0f))) {
            start_profile(1);
        }
        ImGui::SameLine();
        if (ImGui::Button("Start FAILED Capture", ImVec2(180.0f, 0.0f))) {
            start_profile(2);
        }
    } else {
        const char *slot_name = g_input_state.capture_slot == 1 ? "WORKING" : "FAILED";
        char label[64];
        std::snprintf(label, sizeof(label), "Stop + Save %s", slot_name);
        if (ImGui::Button(label, ImVec2(180.0f, 0.0f))) {
            stop_profile(true);
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel Capture")) {
            stop_profile(false);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("%s: %llu blocks, %zu unique, %llu dropped",
                            slot_name,
                            (unsigned long long)xemu_debug_tools_guest_input_profiler_total_hits(),
                            xemu_debug_tools_guest_input_profiler_unique_count(),
                            (unsigned long long)xemu_debug_tools_guest_input_profiler_dropped());
    }

    ImGui::SameLine();
    if (ImGui::Button("Clear Profiles")) {
        clear_profiles();
    }

    if (profile_active) {
        ImGui::BeginDisabled();
    }
    if (ImGui::Button("Save Controller Snapshot", ImVec2(190.0f, 0.0f))) {
        save_controller_snapshot();
    }
    if (profile_active) {
        ImGui::EndDisabled();
    }
    ImGui::SameLine();
    if (ImGui::Button("Open Snapshots Folder")) {
        open_snapshots_folder();
    }
    ImGui::SameLine();
    ImGui::TextDisabled("Complete INPUT DIFF + raw profiles + Controller/XID/OHCI trace.");

    if (!g_input_state.status.empty()) {
        ImGui::TextWrapped("%s", g_input_state.status.c_str());
    }

    ImGui::Separator();
    ImGui::Text("WORKING: %zu unique / %llu executions / %llu dropped",
                g_input_state.working_rows.size(),
                (unsigned long long)g_input_state.working_total,
                (unsigned long long)g_input_state.working_dropped);
    ImGui::Text("FAILED:  %zu unique / %llu executions / %llu dropped",
                g_input_state.failed_rows.size(),
                (unsigned long long)g_input_state.failed_total,
                (unsigned long long)g_input_state.failed_dropped);

    if (g_input_state.working_rows.empty() || g_input_state.failed_rows.empty()) {
        ImGui::TextDisabled("Save both WORKING and FAILED captures to generate the comparison.");
        ImGui::End();
        return;
    }

    ImGui::Checkbox("Show all addresses", &g_input_state.show_all);
    ImGui::SameLine();
    ImGui::TextDisabled(
        "Off = show addresses whose normalized rate fell by >50%% after reconnect.");

    if (ImGui::BeginTable("guest_input_diff_table", 6,
                          ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg |
                          ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable,
                          ImVec2(0.0f, 390.0f))) {
        ImGui::TableSetupColumn("Address", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Working Hits", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Failed Hits", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Work / 1M", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Fail / 1M", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Fail/Work", ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableHeadersRow();

        int visible_rows = 0;
        for (const auto &row : g_input_state.diff_rows) {
            const double work_rate = normalized_rate(
                row.working_hits, g_input_state.working_total);
            const double fail_rate = normalized_rate(
                row.failed_hits, g_input_state.failed_total);
            const double ratio = normalized_failed_ratio(
                row.working_hits, g_input_state.working_total,
                row.failed_hits, g_input_state.failed_total);
            if (!g_input_state.show_all &&
                (row.working_hits == 0 || ratio >= 0.50)) {
                continue;
            }
            ++visible_rows;

            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            char address_label[32];
            std::snprintf(address_label, sizeof(address_label), "%08X##gi_%08X",
                          row.address, row.address);
            if (ImGui::Selectable(address_label, false)) {
                char clipboard[16];
                std::snprintf(clipboard, sizeof(clipboard), "%08X", row.address);
                ImGui::SetClipboardText(clipboard);
                g_input_state.status = "Candidate address copied. Paste it into x86 Debugger Virtual Address.";
            }
            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("Click to copy this candidate virtual address.");
            }
            ImGui::TableSetColumnIndex(1);
            ImGui::Text("%llu", (unsigned long long)row.working_hits);
            ImGui::TableSetColumnIndex(2);
            ImGui::Text("%llu", (unsigned long long)row.failed_hits);
            ImGui::TableSetColumnIndex(3);
            ImGui::Text("%.1f", work_rate * 1000000.0);
            ImGui::TableSetColumnIndex(4);
            ImGui::Text("%.1f", fail_rate * 1000000.0);
            ImGui::TableSetColumnIndex(5);
            if (row.failed_hits == 0 && row.working_hits != 0) {
                ImGui::TextUnformatted("0%  (WORKING only)");
            } else {
                ImGui::Text("%.1f%%", ratio * 100.0);
            }
        }

        if (visible_rows == 0) {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::TextDisabled("No >50%% normalized drops in this pair. Enable Show all addresses to inspect everything.");
        }
        ImGui::EndTable();
    }

    ImGui::TextWrapped(
        "Interpretation: a WORKING-only address is not automatically XInput. Prefer code that "
        "repeats during equivalent button activity, then use the existing execute breakpoint, "
        "conditions and disassembler to verify what it reads/returns before and after reconnect.");

    ImGui::End();
}
