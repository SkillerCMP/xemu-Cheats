/* Info: TCG emits basic-block starts; Memory Tools owns profiling state. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct XemuDebugToolsGuestInputProfileEntry {
    uint32_t address;
    uint64_t hits;
} XemuDebugToolsGuestInputProfileEntry;

int xemu_debug_tools_guest_input_profiler_active(void);
void xemu_debug_tools_guest_input_profiler_record(uint32_t guest_pc);
void xemu_debug_tools_guest_input_profiler_start(uint32_t range_start,
                                                 uint32_t range_end);
void xemu_debug_tools_guest_input_profiler_stop(void);
void xemu_debug_tools_guest_input_profiler_reset(void);
size_t xemu_debug_tools_guest_input_profiler_copy(
    XemuDebugToolsGuestInputProfileEntry *entries, size_t capacity);
size_t xemu_debug_tools_guest_input_profiler_unique_count(void);
uint64_t xemu_debug_tools_guest_input_profiler_total_hits(void);
uint64_t xemu_debug_tools_guest_input_profiler_dropped(void);

#ifdef __cplusplus
}
#endif
