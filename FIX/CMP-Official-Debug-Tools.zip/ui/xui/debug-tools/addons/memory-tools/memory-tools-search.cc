//
// xemu Memory Viewer / Search / x86 Debugger
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "memory-tools.hh"
#include "memory-tools-internal.hh"
#include "current-game.hh"
#include "cheat-engine-memory.h"
#include "cheat-engine.hh"
#include "../font-manager.hh"
#include "../misc.hh"
#include "../../debug-tools.hh"

#include <algorithm>
#include <array>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <utility>

#include <glib.h>
#include <glib/gstdio.h>

using namespace xemu_memory_tools_internal;

struct MemoryToolsWindow::SearchJob {
    enum class Kind {
        FirstExact,
        NextFromSnapshot,
        NextFromResults,
    };

    MemoryToolsWindow *owner = nullptr;
    uint64_t serial = 0;
    Kind kind = Kind::FirstExact;
    AddressSpace space = AddressSpace::Physical;
    ValueKind value_kind = ValueKind::U32;
    NextScanMode next_mode = NextScanMode::Exact;
    bool aligned = true;
    bool target_mode = false;
    uint32_t target = 0;
    uint32_t start = 0;
    uint32_t end = 0;
    uint64_t pause_us = 0;
    uint64_t capture_us = 0;
    uint64_t worker_us = 0;
    size_t unreadable_pages = 0;

    std::vector<uint8_t> current_snapshot;
    std::vector<uint8_t> current_valid_pages;
    std::vector<uint8_t> previous_snapshot;
    std::vector<uint8_t> previous_valid_pages;
    std::vector<SearchResult> results;
};

size_t MemoryToolsWindow::ValueSizeForKind(ValueKind kind)
{
    switch (kind) {
    case ValueKind::U8:
    case ValueKind::S8:
        return 1;
    case ValueKind::U16:
    case ValueKind::S16:
        return 2;
    case ValueKind::U32:
    case ValueKind::S32:
    case ValueKind::Float32:
        return 4;
    }
    return 4;
}

void MemoryToolsWindow::FormatValue(char *dst, size_t dst_size,
                                    uint32_t raw, ValueKind kind) const
{
    switch (kind) {
    case ValueKind::U8:
        std::snprintf(dst, dst_size, "%u (0x%02X)", raw & 0xFFu, raw & 0xFFu);
        break;
    case ValueKind::U16:
        std::snprintf(dst, dst_size, "%u (0x%04X)", raw & 0xFFFFu, raw & 0xFFFFu);
        break;
    case ValueKind::U32:
        std::snprintf(dst, dst_size, "%u (0x%08X)", raw, raw);
        break;
    case ValueKind::S8:
        std::snprintf(dst, dst_size, "%d (0x%02X)", (int)(int8_t)raw, raw & 0xFFu);
        break;
    case ValueKind::S16:
        std::snprintf(dst, dst_size, "%d (0x%04X)", (int)(int16_t)raw, raw & 0xFFFFu);
        break;
    case ValueKind::S32:
        std::snprintf(dst, dst_size, "%d (0x%08X)", (int32_t)raw, raw);
        break;
    case ValueKind::Float32:
        std::snprintf(dst, dst_size, "%.9g (0x%08X)", raw_to_float(raw), raw);
        break;
    }
}

void MemoryToolsWindow::ResetSearch()
{
    ++m_search_serial;
    m_have_first_scan = false;
    m_snapshot_mode = false;
    m_results.clear();
    // Keep the two large byte buffers allocated/prewarmed. Their contents are
    // logically invalid whenever snapshot_mode is false; retaining storage
    // avoids a large allocation/zero-fill while BQL is held on the next scan.
    m_search_status = "Search reset";
}

void MemoryToolsWindow::NotifySearchGameReset()
{
    ++m_search_serial;
    m_have_first_scan = false;
    m_snapshot_mode = false;
    m_results.clear();
    if (m_search_busy) {
        m_search_status = "Game reset while Memory Search was running; stale results will be discarded.";
    } else {
        m_search_status = "Search reset after game/system reset";
    }
}

bool MemoryToolsWindow::ParseTarget(uint32_t &raw) const
{
    errno = 0;
    char *end = nullptr;
    if (m_value_kind == ValueKind::Float32) {
        float v = std::strtof(m_search_value_text, &end);
        if (errno != 0 || end == m_search_value_text || (end && *end != '\0')) {
            return false;
        }
        std::memcpy(&raw, &v, sizeof(raw));
        return true;
    }

    const int base = m_value_hex ? 16 : 10;
    if (m_value_kind == ValueKind::S8 ||
        m_value_kind == ValueKind::S16 ||
        m_value_kind == ValueKind::S32) {
        long long v = std::strtoll(m_search_value_text, &end, base);
        if (errno != 0 || end == m_search_value_text || (end && *end != '\0')) {
            return false;
        }
        raw = (uint32_t)v;
        return true;
    }

    unsigned long long v = std::strtoull(m_search_value_text, &end, base);
    if (errno != 0 || end == m_search_value_text || (end && *end != '\0') ||
        v > 0xFFFFFFFFull) {
        return false;
    }
    raw = (uint32_t)v;
    return true;
}

bool MemoryToolsWindow::MatchTargetForKind(ValueKind kind, uint32_t raw,
                                           uint32_t target, NextScanMode mode)
{
    switch (kind) {
    case ValueKind::Float32: {
        float a = raw_to_float(raw);
        float b = raw_to_float(target);
        if (std::isnan(a) || std::isnan(b)) {
            return false;
        }
        switch (mode) {
        case NextScanMode::Exact: return a == b;
        case NextScanMode::NotEqual: return a != b;
        case NextScanMode::GreaterThan: return a > b;
        case NextScanMode::LessThan: return a < b;
        default: return false;
        }
    }
    case ValueKind::S8: {
        int8_t a = (int8_t)raw, b = (int8_t)target;
        if (mode == NextScanMode::Exact) return a == b;
        if (mode == NextScanMode::NotEqual) return a != b;
        if (mode == NextScanMode::GreaterThan) return a > b;
        if (mode == NextScanMode::LessThan) return a < b;
        return false;
    }
    case ValueKind::S16: {
        int16_t a = (int16_t)raw, b = (int16_t)target;
        if (mode == NextScanMode::Exact) return a == b;
        if (mode == NextScanMode::NotEqual) return a != b;
        if (mode == NextScanMode::GreaterThan) return a > b;
        if (mode == NextScanMode::LessThan) return a < b;
        return false;
    }
    case ValueKind::S32: {
        int32_t a = (int32_t)raw, b = (int32_t)target;
        if (mode == NextScanMode::Exact) return a == b;
        if (mode == NextScanMode::NotEqual) return a != b;
        if (mode == NextScanMode::GreaterThan) return a > b;
        if (mode == NextScanMode::LessThan) return a < b;
        return false;
    }
    default: {
        const size_t size = ValueSizeForKind(kind);
        uint32_t mask = size == 1 ? 0xFFu : size == 2 ? 0xFFFFu : 0xFFFFFFFFu;
        uint32_t a = raw & mask;
        uint32_t b = target & mask;
        if (mode == NextScanMode::Exact) return a == b;
        if (mode == NextScanMode::NotEqual) return a != b;
        if (mode == NextScanMode::GreaterThan) return a > b;
        if (mode == NextScanMode::LessThan) return a < b;
        return false;
    }
    }
}

bool MemoryToolsWindow::MatchPreviousForKind(ValueKind kind, uint32_t current,
                                             uint32_t previous,
                                             NextScanMode mode)
{
    if (kind == ValueKind::Float32) {
        float a = raw_to_float(current);
        float b = raw_to_float(previous);
        if (std::isnan(a) || std::isnan(b)) {
            return false;
        }
        if (mode == NextScanMode::Changed) return a != b;
        if (mode == NextScanMode::Unchanged) return a == b;
        if (mode == NextScanMode::Increased) return a > b;
        if (mode == NextScanMode::Decreased) return a < b;
        return false;
    }

    if (kind == ValueKind::S8) {
        int8_t a = (int8_t)current, b = (int8_t)previous;
        if (mode == NextScanMode::Changed) return a != b;
        if (mode == NextScanMode::Unchanged) return a == b;
        if (mode == NextScanMode::Increased) return a > b;
        if (mode == NextScanMode::Decreased) return a < b;
        return false;
    }
    if (kind == ValueKind::S16) {
        int16_t a = (int16_t)current, b = (int16_t)previous;
        if (mode == NextScanMode::Changed) return a != b;
        if (mode == NextScanMode::Unchanged) return a == b;
        if (mode == NextScanMode::Increased) return a > b;
        if (mode == NextScanMode::Decreased) return a < b;
        return false;
    }
    if (kind == ValueKind::S32) {
        int32_t a = (int32_t)current, b = (int32_t)previous;
        if (mode == NextScanMode::Changed) return a != b;
        if (mode == NextScanMode::Unchanged) return a == b;
        if (mode == NextScanMode::Increased) return a > b;
        if (mode == NextScanMode::Decreased) return a < b;
        return false;
    }

    const size_t size = ValueSizeForKind(kind);
    uint32_t mask = size == 1 ? 0xFFu : size == 2 ? 0xFFFFu : 0xFFFFFFFFu;
    uint32_t a = current & mask;
    uint32_t b = previous & mask;
    if (mode == NextScanMode::Changed) return a != b;
    if (mode == NextScanMode::Unchanged) return a == b;
    if (mode == NextScanMode::Increased) return a > b;
    if (mode == NextScanMode::Decreased) return a < b;
    return false;
}

bool MemoryToolsWindow::CaptureSnapshotInto(
    std::vector<uint8_t> &snapshot, std::vector<uint8_t> &valid_pages,
    uint64_t &pause_us, uint64_t &capture_us, size_t &unreadable_pages)
{
    pause_us = 0;
    capture_us = 0;
    unreadable_pages = 0;

    const uint64_t length = (uint64_t)m_scan_end - (uint64_t)m_scan_start + 1ull;
    if (m_scan_end < m_scan_start || length == 0 || length > kMaxScanBytes) {
        m_search_status = "Scan range must be 1 byte to 256 MB";
        return false;
    }

    const size_t snapshot_size = (size_t)length;
    const size_t page_count = (snapshot_size + kPageSize - 1) / kPageSize;
    try {
        snapshot.resize(snapshot_size);
        valid_pages.resize(page_count);
        std::fill(valid_pages.begin(), valid_pages.end(), 0);
    } catch (...) {
        m_search_status = "Could not allocate safe scan snapshot";
        return false;
    }

    const gint64 pause_begin = g_get_monotonic_time();
    XemuDebugGuestPauseGuard guest_pause;
    if (!guest_pause.IsValid()) {
        m_search_status = "Could not pause the guest for a coherent Memory Search snapshot";
        return false;
    }

    const gint64 capture_begin = g_get_monotonic_time();
    bool whole_range_ok = false;

    // Physical Xbox RAM is normally one contiguous address-space region. A
    // single bulk read avoids ~16K QEMU dispatches for a normal 64 MB scan.
    // If a custom physical range crosses an unmapped area, fall back to the
    // page-granular behavior so readable pages are still usable.
    if (m_search_space == AddressSpace::Physical) {
        whole_range_ok = Read(m_search_space, m_scan_start,
                              snapshot.data(), snapshot.size());
    }

    if (whole_range_ok) {
        std::fill(valid_pages.begin(), valid_pages.end(), 1);
    } else {
        for (size_t page = 0; page < page_count; ++page) {
            const size_t offset = page * kPageSize;
            const size_t amount = std::min(kPageSize, snapshot_size - offset);
            const uint32_t address = m_scan_start + (uint32_t)offset;
            if (Read(m_search_space, address, snapshot.data() + offset, amount)) {
                valid_pages[page] = 1;
            } else {
                std::memset(snapshot.data() + offset, 0, amount);
                ++unreadable_pages;
            }
        }
    }

    const gint64 capture_end = g_get_monotonic_time();
    guest_pause.Resume();
    const gint64 resume_end = g_get_monotonic_time();

    capture_us = (uint64_t)std::max<gint64>(0, capture_end - capture_begin);
    pause_us = (uint64_t)std::max<gint64>(0, resume_end - pause_begin);
    return true;
}

static bool snapshot_raw_at(const std::vector<uint8_t> &snapshot,
                            const std::vector<uint8_t> &valid_pages,
                            uint32_t range_start, uint32_t address,
                            size_t size, uint32_t &raw)
{
    if (address < range_start) {
        return false;
    }
    const uint64_t offset64 = (uint64_t)address - (uint64_t)range_start;
    if (offset64 + size > snapshot.size()) {
        return false;
    }
    const size_t offset = (size_t)offset64;
    const size_t first_page = offset / kPageSize;
    const size_t last_page = (offset + size - 1) / kPageSize;
    if (first_page >= valid_pages.size() || last_page >= valid_pages.size() ||
        !valid_pages[first_page] || !valid_pages[last_page]) {
        return false;
    }
    raw = load_le(snapshot.data() + offset, size);
    return true;
}

void MemoryToolsWindow::RunSearchJob(void *opaque)
{
    auto *job = static_cast<SearchJob *>(opaque);
    if (!job) {
        return;
    }

    const gint64 worker_begin = g_get_monotonic_time();
    const size_t size = ValueSizeForKind(job->value_kind);
    const uint32_t stride = job->aligned ? (uint32_t)size : 1u;

    if (job->kind == SearchJob::Kind::FirstExact) {
        job->results.clear();
        for (size_t page = 0; page < job->current_valid_pages.size(); ++page) {
            if (!job->current_valid_pages[page]) {
                continue;
            }
            const size_t offset = page * kPageSize;
            if (offset >= job->current_snapshot.size()) {
                break;
            }
            const size_t amount =
                std::min(kPageSize, job->current_snapshot.size() - offset);
            for (size_t off = 0; off + size <= amount; off += stride) {
                const uint32_t raw =
                    load_le(job->current_snapshot.data() + offset + off, size);
                if (MatchTargetForKind(job->value_kind, raw, job->target,
                                       NextScanMode::Exact)) {
                    SearchResult result;
                    result.address = job->start + (uint32_t)offset + (uint32_t)off;
                    result.previous_raw = raw;
                    result.current_raw = raw;
                    job->results.push_back(result);
                    if (job->results.size() >= kMaxSearchResults) {
                        break;
                    }
                }
            }
            if (job->results.size() >= kMaxSearchResults) {
                break;
            }
        }
    } else if (job->kind == SearchJob::Kind::NextFromSnapshot) {
        job->results.clear();
        const size_t page_count = std::min(job->previous_valid_pages.size(),
                                           job->current_valid_pages.size());
        for (size_t page = 0; page < page_count; ++page) {
            if (!job->previous_valid_pages[page] ||
                !job->current_valid_pages[page]) {
                continue;
            }
            const size_t offset = page * kPageSize;
            if (offset >= job->previous_snapshot.size() ||
                offset >= job->current_snapshot.size()) {
                break;
            }
            const size_t amount = std::min(
                kPageSize,
                std::min(job->previous_snapshot.size() - offset,
                         job->current_snapshot.size() - offset));
            for (size_t off = 0; off + size <= amount; off += stride) {
                const uint32_t previous =
                    load_le(job->previous_snapshot.data() + offset + off, size);
                const uint32_t current =
                    load_le(job->current_snapshot.data() + offset + off, size);
                const bool match = job->target_mode
                    ? MatchTargetForKind(job->value_kind, current, job->target,
                                         job->next_mode)
                    : MatchPreviousForKind(job->value_kind, current, previous,
                                           job->next_mode);
                if (match) {
                    SearchResult result;
                    result.address = job->start + (uint32_t)offset + (uint32_t)off;
                    result.previous_raw = previous;
                    result.current_raw = current;
                    job->results.push_back(result);
                    if (job->results.size() >= kMaxSearchResults) {
                        break;
                    }
                }
            }
            if (job->results.size() >= kMaxSearchResults) {
                break;
            }
        }
    } else {
        // Stable in-place compaction preserves result order and reuses the
        // potentially multi-million-entry result allocation. The worker reads
        // only the immutable host snapshot; it never reaches back into guest
        // memory while the VM is running.
        const size_t original_count = job->results.size();
        size_t write_index = 0;
        for (size_t read_index = 0; read_index < original_count; ++read_index) {
            const SearchResult old = job->results[read_index];
            uint32_t current = 0;
            if (!snapshot_raw_at(job->current_snapshot,
                                 job->current_valid_pages,
                                 job->start, old.address, size, current)) {
                continue;
            }
            const bool match = job->target_mode
                ? MatchTargetForKind(job->value_kind, current, job->target,
                                     job->next_mode)
                : MatchPreviousForKind(job->value_kind, current,
                                       old.current_raw, job->next_mode);
            if (match) {
                SearchResult &result = job->results[write_index++];
                result = old;
                result.previous_raw = old.current_raw;
                result.current_raw = current;
                if (write_index >= kMaxSearchResults) {
                    break;
                }
            }
        }
        job->results.resize(write_index);
    }

    const gint64 worker_end = g_get_monotonic_time();
    job->worker_us =
        (uint64_t)std::max<gint64>(0, worker_end - worker_begin);
}

void MemoryToolsWindow::CompleteSearchJob(void *opaque)
{
    auto *job = static_cast<SearchJob *>(opaque);
    if (!job || !job->owner) {
        delete job;
        return;
    }

    MemoryToolsWindow *owner = job->owner;

    // Return the large capture allocations to the window before deleting the
    // job so the next scan can reuse them without a first-click allocation.
    owner->m_capture_snapshot.swap(job->current_snapshot);
    owner->m_capture_valid_pages.swap(job->current_valid_pages);
    if (job->kind == SearchJob::Kind::NextFromSnapshot) {
        owner->m_snapshot.swap(job->previous_snapshot);
        owner->m_snapshot_valid_pages.swap(job->previous_valid_pages);
    }

    owner->m_search_busy = false;

    if (job->serial != owner->m_search_serial) {
        owner->m_search_status =
            "Memory Search finished, but its results were discarded because the guest/search state changed.";
        delete job;
        return;
    }

    owner->m_results = std::move(job->results);
    owner->m_have_first_scan = true;
    owner->m_snapshot_mode = false;
    owner->m_search_last_pause_us = job->pause_us;
    owner->m_search_last_capture_us = job->capture_us;
    owner->m_search_last_worker_us = job->worker_us;
    owner->m_search_last_snapshot_bytes = owner->m_capture_snapshot.size();
    owner->m_search_last_unreadable_pages = job->unreadable_pages;

    char message[320];
    const char *phase = job->kind == SearchJob::Kind::FirstExact
                            ? "First scan"
                            : "Next scan";
    if (owner->m_results.size() >= kMaxSearchResults) {
        std::snprintf(
            message, sizeof(message),
            "%s reached the safety cap of %zu results | safe snapshot %.3f ms, pause window %.3f ms, background filter %.3f ms",
            phase, kMaxSearchResults,
            (double)job->capture_us / 1000.0,
            (double)job->pause_us / 1000.0,
            (double)job->worker_us / 1000.0);
    } else {
        std::snprintf(
            message, sizeof(message),
            "%s complete: %zu result(s) | safe snapshot %.3f ms, pause window %.3f ms, background filter %.3f ms",
            phase, owner->m_results.size(),
            (double)job->capture_us / 1000.0,
            (double)job->pause_us / 1000.0,
            (double)job->worker_us / 1000.0);
    }
    owner->m_search_status = message;
    delete job;
}

bool MemoryToolsWindow::QueueSearchJob(SearchJob *job)
{
    if (!job) {
        return false;
    }
    if (!debug_tools_queue_background_job(&MemoryToolsWindow::RunSearchJob,
                                          job,
                                          &MemoryToolsWindow::CompleteSearchJob)) {
        return false;
    }
    return true;
}

void MemoryToolsWindow::FirstScan()
{
    if (m_search_busy) {
        m_search_status = "Memory Search is already running";
        return;
    }

    uint32_t start = 0, end = 0;
    if (!ParseHexAddress(m_scan_start_text, start) ||
        !ParseHexAddress(m_scan_end_text, end) || end < start) {
        m_search_status = "Invalid scan range";
        return;
    }
    m_scan_start = start;
    m_scan_end = end;

    const uint64_t length = (uint64_t)end - (uint64_t)start + 1ull;
    if (length > kMaxScanBytes) {
        m_search_status = "Scan range is larger than 256 MB";
        return;
    }

    uint32_t target = 0;
    if (m_first_mode == FirstScanMode::Exact && !ParseTarget(target)) {
        m_search_status = "Invalid search value";
        return;
    }

    ++m_search_serial;
    m_results.clear();
    m_have_first_scan = false;
    m_snapshot_mode = false;
    m_search_last_worker_us = 0;

    uint64_t pause_us = 0;
    uint64_t capture_us = 0;
    size_t unreadable_pages = 0;
    if (!CaptureSnapshotInto(m_capture_snapshot, m_capture_valid_pages,
                             pause_us, capture_us, unreadable_pages)) {
        return;
    }

    m_search_last_pause_us = pause_us;
    m_search_last_capture_us = capture_us;
    m_search_last_snapshot_bytes = m_capture_snapshot.size();
    m_search_last_unreadable_pages = unreadable_pages;

    if (m_first_mode == FirstScanMode::UnknownInitial) {
        m_snapshot.swap(m_capture_snapshot);
        m_snapshot_valid_pages.swap(m_capture_valid_pages);
        m_snapshot_start = m_scan_start;
        m_snapshot_end = m_scan_end;
        m_snapshot_kind = m_value_kind;
        m_snapshot_aligned = m_aligned;
        m_have_first_scan = true;
        m_snapshot_mode = true;
        char message[256];
        std::snprintf(
            message, sizeof(message),
            "Unknown-value snapshot captured safely in %.3f ms (pause window %.3f ms). Guest resumed; change the value, then use Next Scan.",
            (double)capture_us / 1000.0, (double)pause_us / 1000.0);
        m_search_status = message;
        return;
    }

    auto *job = new SearchJob();
    job->owner = this;
    job->serial = m_search_serial;
    job->kind = SearchJob::Kind::FirstExact;
    job->space = m_search_space;
    job->value_kind = m_value_kind;
    job->aligned = m_aligned;
    job->target = target;
    job->start = m_scan_start;
    job->end = m_scan_end;
    job->pause_us = pause_us;
    job->capture_us = capture_us;
    job->unreadable_pages = unreadable_pages;
    job->current_snapshot.swap(m_capture_snapshot);
    job->current_valid_pages.swap(m_capture_valid_pages);

    m_search_busy = true;
    m_search_status =
        "Safe snapshot captured; guest resumed. First-scan filtering is running on the Debug Tools worker...";
    if (!QueueSearchJob(job)) {
        m_search_busy = false;
        m_capture_snapshot.swap(job->current_snapshot);
        m_capture_valid_pages.swap(job->current_valid_pages);
        delete job;
        m_search_status = "Debug Tools background worker is unavailable; search was not started";
    }
}

void MemoryToolsWindow::NextScan()
{
    if (m_search_busy) {
        m_search_status = "Memory Search is already running";
        return;
    }
    if (!m_have_first_scan) {
        m_search_status = "Run First Scan first";
        return;
    }

    uint32_t target = 0;
    const bool target_mode = m_next_mode == NextScanMode::Exact ||
                             m_next_mode == NextScanMode::NotEqual ||
                             m_next_mode == NextScanMode::GreaterThan ||
                             m_next_mode == NextScanMode::LessThan;
    if (target_mode && !ParseTarget(target)) {
        m_search_status = "Invalid search value";
        return;
    }

    if (m_snapshot_mode &&
        (m_value_kind != m_snapshot_kind ||
         m_aligned != m_snapshot_aligned ||
         m_scan_start != m_snapshot_start ||
         m_scan_end != m_snapshot_end)) {
        m_search_status = "Value type/alignment/range changed; start a new scan";
        return;
    }

    uint64_t pause_us = 0;
    uint64_t capture_us = 0;
    size_t unreadable_pages = 0;
    if (!CaptureSnapshotInto(m_capture_snapshot, m_capture_valid_pages,
                             pause_us, capture_us, unreadable_pages)) {
        return;
    }

    ++m_search_serial;
    auto *job = new SearchJob();
    job->owner = this;
    job->serial = m_search_serial;
    job->kind = m_snapshot_mode ? SearchJob::Kind::NextFromSnapshot
                                : SearchJob::Kind::NextFromResults;
    job->space = m_search_space;
    job->value_kind = m_value_kind;
    job->next_mode = m_next_mode;
    job->aligned = m_aligned;
    job->target_mode = target_mode;
    job->target = target;
    job->start = m_scan_start;
    job->end = m_scan_end;
    job->pause_us = pause_us;
    job->capture_us = capture_us;
    job->unreadable_pages = unreadable_pages;
    job->current_snapshot.swap(m_capture_snapshot);
    job->current_valid_pages.swap(m_capture_valid_pages);

    if (m_snapshot_mode) {
        job->previous_snapshot.swap(m_snapshot);
        job->previous_valid_pages.swap(m_snapshot_valid_pages);
    } else {
        job->results.swap(m_results);
    }

    m_search_busy = true;
    m_search_last_pause_us = pause_us;
    m_search_last_capture_us = capture_us;
    m_search_last_worker_us = 0;
    m_search_last_snapshot_bytes = job->current_snapshot.size();
    m_search_last_unreadable_pages = unreadable_pages;
    m_search_status =
        "Safe snapshot captured; guest resumed. Next-scan comparison is running on the Debug Tools worker...";

    if (!QueueSearchJob(job)) {
        m_search_busy = false;
        m_capture_snapshot.swap(job->current_snapshot);
        m_capture_valid_pages.swap(job->current_valid_pages);
        if (job->kind == SearchJob::Kind::NextFromSnapshot) {
            m_snapshot.swap(job->previous_snapshot);
            m_snapshot_valid_pages.swap(job->previous_valid_pages);
        } else {
            m_results.swap(job->results);
        }
        delete job;
        m_search_status = "Debug Tools background worker is unavailable; search was not started";
        return;
    }

    /* Info: Worker ownership ends snapshot mode until refinement completes. */    m_snapshot_mode = false;
}

// Memory Search rendering/UI is owned by memory-tools-search-ui.cc.
