//
// xemu Memory Viewer / Search / x86 Debugger
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "memory-tools.hh"
#include "memory-tools-internal.hh"
#include "current-game.hh"
#include "cheat-engine-memory.h"
#include "cheat-engine.hh"
#include "../../debug-output-paths.hh"
#include "../font-manager.hh"
#include "../misc.hh"
#include "../../debug-tools.hh"

#include <algorithm>
#include <array>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <utility>

#include <glib.h>
#include <glib/gstdio.h>

using namespace xemu_memory_tools_internal;

std::string MemoryToolsWindow::DumpDirectory() const
{
    return XemuDebugOutput::Directory(XemuDebugOutput::Folder::RamDumps);
}

std::string MemoryToolsWindow::DumpStem() const
{
    const auto &game = current_game_manager.Get();
    std::string stem;
    if (game.valid) {
        stem = CurrentGameManager::FormatDatabaseGameId(game.title_id);
        if (!game.header_sha256.empty()) {
            stem += "-";
            stem += game.header_sha256.substr(0, std::min<size_t>(16, game.header_sha256.size()));
        }
    } else {
        stem = "NO-XBE";
    }
    stem += "-";
    stem += XemuDebugOutput::Timestamp("00000000-000000");
    return stem;
}

void MemoryToolsWindow::DumpCurrentPage(AddressSpace space, uint32_t address)
{
    XemuDebugGuestPauseGuard guest_pause;

    const std::string directory = DumpDirectory();
    if (directory.empty()) {
        m_dump_status = "Could not determine the xemu RAM dump directory.";
        return;
    }
    if (g_mkdir_with_parents(directory.c_str(), 0755) != 0) {
        m_dump_status = "Could not create RAM dump directory: " + directory;
        return;
    }

    const uint32_t page_base = address & 0xFFFFF000u;
    char filename[192];
    std::snprintf(filename, sizeof(filename), "%s-%s-%08X-PAGE.bin",
                  DumpStem().c_str(),
                  space == AddressSpace::Virtual ? "VIRTUAL" : "PHYSICAL",
                  page_base);
    gchar *path_c = g_build_filename(directory.c_str(), filename, nullptr);
    const std::string path = path_c ? path_c : filename;
    g_free(path_c);

    size_t failed_pages = 0;
    const bool ok = DumpRange(space, page_base, kPageSize, path, failed_pages);

    char message[512];
    if (ok && failed_pages == 0) {
        std::snprintf(message, sizeof(message),
                      "Current %s page %08X-%08X dumped to: %s",
                      space == AddressSpace::Virtual ? "Virtual" : "Physical",
                      page_base, page_base + 0xFFFu, path.c_str());
    } else if (ok) {
        std::snprintf(message, sizeof(message),
                      "Current %s page %08X-%08X dumped with unreadable data zero-filled: %s",
                      space == AddressSpace::Virtual ? "Virtual" : "Physical",
                      page_base, page_base + 0xFFFu, path.c_str());
    } else {
        std::snprintf(message, sizeof(message),
                      "Failed to dump current %s page %08X-%08X.",
                      space == AddressSpace::Virtual ? "Virtual" : "Physical",
                      page_base, page_base + 0xFFFu);
    }
    m_dump_status = message;

}

bool MemoryToolsWindow::DumpRange(AddressSpace space, uint32_t base,
                                  uint64_t size, const std::string &path,
                                  size_t &failed_pages) const
{
    failed_pages = 0;
    FILE *fp = g_fopen(path.c_str(), "wb");
    if (!fp) {
        return false;
    }

    constexpr size_t kDumpPage = 0x1000;
    uint8_t buffer[kDumpPage];
    bool file_ok = true;

    for (uint64_t offset = 0; offset < size; offset += kDumpPage) {
        const size_t amount = (size_t)std::min<uint64_t>(kDumpPage, size - offset);
        const uint32_t address = base + (uint32_t)offset;
        if (!Read(space, address, buffer, amount)) {
            std::memset(buffer, 0, amount);
            ++failed_pages;
        }
        if (std::fwrite(buffer, 1, amount, fp) != amount) {
            file_ok = false;
            break;
        }
    }

    if (std::fclose(fp) != 0) {
        file_ok = false;
    }
    if (!file_ok) {
        g_remove(path.c_str());
    }
    return file_ok;
}

struct MemoryToolsWindow::DumpJob {
    MemoryToolsWindow *owner = nullptr;
    uint64_t serial = 0;
    bool dump_physical = false;
    bool dump_virtual = false;
    uint64_t ram_size = 0;
    uint64_t pause_us = 0;
    uint64_t capture_us = 0;
    uint64_t worker_us = 0;
    size_t physical_unreadable_pages = 0;
    size_t virtual_unreadable_pages = 0;
    bool physical_ok = true;
    bool virtual_ok = true;
    bool map_ok = true;
    bool directory_ok = true;

    std::string directory;
    std::string stem;
    bool game_valid = false;
    std::string game_name;
    std::string game_id;
    uint32_t title_id = 0;
    std::string header_sha256;
    std::string raw_header_sha256;

    std::vector<uint8_t> physical_snapshot;
    std::vector<uint8_t> physical_valid_pages;
    std::vector<VirtualPageMapping> virtual_pages;
    std::vector<VirtualDumpRegion> regions;
    std::vector<std::string> region_files;
    std::string status;
};

static bool write_snapshot_file(const std::string &path,
                                const uint8_t *data, size_t size)
{
    FILE *fp = g_fopen(path.c_str(), "wb");
    if (!fp) {
        return false;
    }
    bool ok = size == 0 || std::fwrite(data, 1, size, fp) == size;
    if (std::fclose(fp) != 0) {
        ok = false;
    }
    if (!ok) {
        g_remove(path.c_str());
    }
    return ok;
}

bool MemoryToolsWindow::WriteDumpVirtualMapIndex(
    const DumpJob &job, const std::string &path)
{
    FILE *fp = g_fopen(path.c_str(), "wb");
    if (!fp) {
        return false;
    }

    bool ok = true;
    auto put = [&](const char *format, auto... args) {
        if (ok && std::fprintf(fp, format, args...) < 0) {
            ok = false;
        }
    };

    put("xemu Mapped Virtual RAM Dump\n");
    put("============================\n\n");
    if (job.game_valid) {
        put("Game: %s\n", job.game_name.c_str());
        put("GameID: %s\n", job.game_id.c_str());
        put("TitleID: %08X\n", job.title_id);
        put("XBE Identity SHA-256: %s\n", job.header_sha256.c_str());
        put("XBE Raw Header SHA-256: %s\n", job.raw_header_sha256.c_str());
    } else {
        put("Game: <no valid XBE detected>\n");
    }
    put("Installed physical RAM: %llu bytes (%llu MB)\n",
        (unsigned long long)job.ram_size,
        (unsigned long long)(job.ram_size / (1024ull * 1024ull)));
    put("Virtual scan range: 00000000-FFFFFFFF\n");
    put("Page size: 00001000\n");
    put("RAM-backed mapped pages: %llu\n",
        (unsigned long long)job.virtual_pages.size());
    put("RAM-backed mapped bytes (aliases included): %llu\n",
        (unsigned long long)(job.virtual_pages.size() * 0x1000ull));
    put("Contiguous virtual regions: %zu\n\n", job.regions.size());
    put("Each .bin starts at file offset 00000000. Add the region's virtual\n");
    put("start address to a file offset to recover the guest virtual address.\n");
    put("Only mappings backed by installed Xbox RAM are included; MMIO/device\n");
    put("mappings are intentionally excluded. Every region file was rebuilt\n");
    put("from the same coherent physical RAM snapshot captured while paused.\n\n");

    put("#   Virtual Start-End       Size (bytes)       File\n");
    put("--  ---------------------   ----------------   ----\n");
    for (size_t i = 0; i < job.regions.size(); ++i) {
        const uint64_t size =
            job.regions[i].end_exclusive - job.regions[i].start;
        const uint64_t end_inclusive = job.regions[i].end_exclusive - 1;
        const char *file = i < job.region_files.size()
                               ? job.region_files[i].c_str()
                               : "<missing>";
        put("%02zu  %08llX-%08llX   %016llX   %s\n",
            i + 1,
            (unsigned long long)job.regions[i].start,
            (unsigned long long)end_inclusive,
            (unsigned long long)size,
            file);
    }

    if (std::fclose(fp) != 0) {
        ok = false;
    }
    if (!ok) {
        g_remove(path.c_str());
    }
    return ok;
}

void MemoryToolsWindow::DumpPhysicalRam()
{
    DumpRam(true, false);
}

void MemoryToolsWindow::DumpMappedVirtualRam()
{
    DumpRam(false, true);
}

void MemoryToolsWindow::DumpFullRam()
{
    DumpRam(true, true);
}

void MemoryToolsWindow::NotifyDumpGameReset()
{
    ++m_dump_serial;
    if (m_dump_busy) {
        m_dump_status =
            "Game reset while a RAM dump is being written; the queued files still represent the coherent pre-reset snapshot.";
    }
}

void MemoryToolsWindow::RunDumpJob(void *opaque)
{
    auto *job = static_cast<DumpJob *>(opaque);
    if (!job) {
        return;
    }

    const gint64 worker_begin = g_get_monotonic_time();
    job->directory_ok =
        g_mkdir_with_parents(job->directory.c_str(), 0755) == 0;
    if (!job->directory_ok) {
        job->physical_ok = false;
        job->virtual_ok = false;
        job->map_ok = false;
    }

    if (job->directory_ok && job->dump_physical) {
        gchar *physical_c = g_build_filename(
            job->directory.c_str(),
            (job->stem + "-PHYSICAL-00000000.bin").c_str(), nullptr);
        const std::string physical_path =
            physical_c ? physical_c : "physical.bin";
        g_free(physical_c);
        job->physical_ok = write_snapshot_file(
            physical_path, job->physical_snapshot.data(),
            (size_t)job->ram_size);
    }

    if (job->directory_ok && job->dump_virtual) {
        constexpr uint64_t kVirtualPage = 0x1000ull;
        job->regions.clear();
        for (const auto &page : job->virtual_pages) {
            const uint64_t virtual_address = page.virtual_page;
            if (!job->regions.empty() &&
                job->regions.back().end_exclusive == virtual_address) {
                job->regions.back().end_exclusive += kVirtualPage;
            } else {
                VirtualDumpRegion region;
                region.start = virtual_address;
                region.end_exclusive = virtual_address + kVirtualPage;
                job->regions.push_back(region);
            }
        }

        job->region_files.clear();
        job->region_files.reserve(job->regions.size());
        size_t mapping_index = 0;
        std::array<uint8_t, 0x1000> zero_page{};

        for (const VirtualDumpRegion &region : job->regions) {
            const uint64_t end_inclusive = region.end_exclusive - 1;
            char filename[160];
            std::snprintf(filename, sizeof(filename),
                          "%s-VIRTUAL-%08llX-%08llX.bin",
                          job->stem.c_str(),
                          (unsigned long long)region.start,
                          (unsigned long long)end_inclusive);
            gchar *path_c =
                g_build_filename(job->directory.c_str(), filename, nullptr);
            const std::string path = path_c ? path_c : filename;
            g_free(path_c);
            job->region_files.emplace_back(filename);

            FILE *fp = g_fopen(path.c_str(), "wb");
            if (!fp) {
                job->virtual_ok = false;
                while (mapping_index < job->virtual_pages.size() &&
                       job->virtual_pages[mapping_index].virtual_page <
                           region.end_exclusive) {
                    ++mapping_index;
                }
                continue;
            }

            bool region_ok = true;
            while (mapping_index < job->virtual_pages.size()) {
                const auto &mapping = job->virtual_pages[mapping_index];
                if (mapping.virtual_page >= region.end_exclusive) {
                    break;
                }
                if (mapping.virtual_page < region.start) {
                    ++mapping_index;
                    continue;
                }

                const size_t physical_page_index =
                    (size_t)(mapping.physical_page / kVirtualPage);
                const bool readable =
                    physical_page_index < job->physical_valid_pages.size() &&
                    job->physical_valid_pages[physical_page_index] &&
                    mapping.physical_page + kVirtualPage <=
                        job->physical_snapshot.size();
                const uint8_t *page_data = readable
                    ? job->physical_snapshot.data() +
                          (size_t)mapping.physical_page
                    : zero_page.data();
                if (!readable) {
                    ++job->virtual_unreadable_pages;
                }
                if (std::fwrite(page_data, 1, (size_t)kVirtualPage, fp) !=
                    kVirtualPage) {
                    region_ok = false;
                    break;
                }
                ++mapping_index;
            }

            if (std::fclose(fp) != 0) {
                region_ok = false;
            }
            if (!region_ok) {
                g_remove(path.c_str());
                job->virtual_ok = false;
            }
        }

        gchar *map_c = g_build_filename(
            job->directory.c_str(),
            (job->stem + "-VIRTUAL-MAP.txt").c_str(), nullptr);
        const std::string map_path = map_c ? map_c : "virtual-map.txt";
        g_free(map_c);
        job->map_ok = WriteDumpVirtualMapIndex(*job, map_path);
    }

    const bool ok = job->directory_ok && job->physical_ok &&
                    job->virtual_ok && job->map_ok;
    char message[768];
    if (!ok) {
        std::snprintf(
            message, sizeof(message),
            "RAM snapshot was captured and the guest resumed, but one or more background dump files failed. Check: %s",
            job->directory.c_str());
    } else if (job->dump_physical && job->dump_virtual) {
        std::snprintf(
            message, sizeof(message),
            "Physical + mapped virtual RAM dump complete from one coherent snapshot. Guest resumed immediately after capture. Physical RAM: %llu MB; mapped virtual: %zu pages in %zu region(s). Physical unreadable pages: %zu; virtual unreadable pages: %zu. Saved to: %s",
            (unsigned long long)(job->ram_size / (1024ull * 1024ull)),
            job->virtual_pages.size(), job->regions.size(),
            job->physical_unreadable_pages,
            job->virtual_unreadable_pages, job->directory.c_str());
    } else if (job->dump_physical) {
        std::snprintf(
            message, sizeof(message),
            "Physical RAM dump complete from a coherent snapshot. Guest resumed immediately after capture. Physical RAM: %llu MB; unreadable pages zero-filled: %zu. Saved to: %s",
            (unsigned long long)(job->ram_size / (1024ull * 1024ull)),
            job->physical_unreadable_pages, job->directory.c_str());
    } else {
        std::snprintf(
            message, sizeof(message),
            "Mapped virtual RAM dump complete from a coherent physical snapshot. Guest resumed immediately after capture. %zu pages in %zu region(s); unreadable pages zero-filled: %zu. Saved to: %s",
            job->virtual_pages.size(), job->regions.size(),
            job->virtual_unreadable_pages, job->directory.c_str());
    }
    job->status = message;

    const gint64 worker_end = g_get_monotonic_time();
    job->worker_us =
        (uint64_t)std::max<gint64>(0, worker_end - worker_begin);
}

void MemoryToolsWindow::CompleteDumpJob(void *opaque)
{
    auto *job = static_cast<DumpJob *>(opaque);
    if (!job || !job->owner) {
        delete job;
        return;
    }

    MemoryToolsWindow *owner = job->owner;
    owner->m_dump_snapshot.swap(job->physical_snapshot);
    owner->m_dump_snapshot_valid_pages.swap(job->physical_valid_pages);
    owner->m_dump_busy = false;
    owner->m_dump_last_pause_us = job->pause_us;
    owner->m_dump_last_capture_us = job->capture_us;
    owner->m_dump_last_worker_us = job->worker_us;
    owner->m_dump_last_snapshot_bytes = owner->m_dump_snapshot.size();

    if (job->serial != owner->m_dump_serial) {
        owner->m_dump_status =
            "RAM dump finished for the previous guest state. Files were written from the coherent snapshot captured before reset.";
    } else {
        owner->m_dump_status = job->status;
    }
    delete job;
}

bool MemoryToolsWindow::QueueDumpJob(DumpJob *job)
{
    if (!job) {
        return false;
    }
    return debug_tools_queue_background_job(
        &MemoryToolsWindow::RunDumpJob, job,
        &MemoryToolsWindow::CompleteDumpJob);
}

void MemoryToolsWindow::DumpRam(bool dump_physical, bool dump_virtual)
{
    if (m_dump_busy) {
        m_dump_status = "A RAM dump is already being written in the background.";
        return;
    }
    if (!dump_physical && !dump_virtual) {
        m_dump_status = "No RAM dump mode was selected.";
        return;
    }

    const uint64_t ram_size = xemu_cheat_ram_size();
    if (ram_size == 0 || ram_size > 0x40000000ull) {
        m_dump_status = "Could not determine a valid Xbox RAM size.";
        return;
    }
    if (dump_virtual && !xemu_cheat_cpu_available()) {
        m_dump_status =
            "Xbox CPU is not available; mapped virtual RAM cannot be captured.";
        return;
    }

    const std::string directory = DumpDirectory();
    if (directory.empty()) {
        m_dump_status = "Could not determine the xemu RAM dump directory.";
        return;
    }

    auto *job = new DumpJob();
    job->owner = this;
    job->serial = ++m_dump_serial;
    job->dump_physical = dump_physical;
    job->dump_virtual = dump_virtual;
    job->ram_size = ram_size;
    job->directory = directory;
    job->stem = DumpStem();

    const auto &game = current_game_manager.Get();
    job->game_valid = game.valid;
    if (game.valid) {
        job->game_name = game.title_name;
        job->game_id = CurrentGameManager::FormatDatabaseGameId(game.title_id);
        job->title_id = game.title_id;
        job->header_sha256 = game.header_sha256;
        job->raw_header_sha256 = game.raw_header_sha256;
    }

    try {
        m_dump_snapshot.resize((size_t)ram_size);
        m_dump_snapshot_valid_pages.resize(
            ((size_t)ram_size + kPageSize - 1) / kPageSize);
        std::fill(m_dump_snapshot_valid_pages.begin(),
                  m_dump_snapshot_valid_pages.end(), 0);
    } catch (...) {
        delete job;
        m_dump_status = "Could not allocate the coherent RAM dump snapshot.";
        return;
    }

    const gint64 pause_begin = g_get_monotonic_time();
    XemuDebugGuestPauseGuard guest_pause;
    if (!guest_pause.IsValid()) {
        delete job;
        m_dump_status = "Could not pause the guest for a coherent RAM dump snapshot.";
        return;
    }

    if (dump_virtual) {
        bool used_page_table_snapshot = false;
        if (!CollectRamVirtualPages(ram_size, job->virtual_pages,
                                    used_page_table_snapshot)) {
            delete job;
            m_dump_status =
                "Could not capture the Xbox virtual RAM mappings. Guest was resumed without writing a dump.";
            return;
        }
    }

    const gint64 capture_begin = g_get_monotonic_time();
    bool whole_ram_ok = Read(AddressSpace::Physical, 0x00000000u,
                             m_dump_snapshot.data(), (size_t)ram_size);
    size_t physical_unreadable = 0;
    if (whole_ram_ok) {
        std::fill(m_dump_snapshot_valid_pages.begin(),
                  m_dump_snapshot_valid_pages.end(), 1);
    } else {
        for (size_t page = 0; page < m_dump_snapshot_valid_pages.size(); ++page) {
            const size_t offset = page * kPageSize;
            const size_t amount =
                std::min(kPageSize, (size_t)ram_size - offset);
            if (Read(AddressSpace::Physical, (uint32_t)offset,
                     m_dump_snapshot.data() + offset, amount)) {
                m_dump_snapshot_valid_pages[page] = 1;
            } else {
                std::memset(m_dump_snapshot.data() + offset, 0, amount);
                ++physical_unreadable;
            }
        }
    }
    const gint64 capture_end = g_get_monotonic_time();
    guest_pause.Resume();
    const gint64 resume_end = g_get_monotonic_time();

    job->capture_us =
        (uint64_t)std::max<gint64>(0, capture_end - capture_begin);
    job->pause_us =
        (uint64_t)std::max<gint64>(0, resume_end - pause_begin);
    job->physical_unreadable_pages = physical_unreadable;
    job->physical_snapshot.swap(m_dump_snapshot);
    job->physical_valid_pages.swap(m_dump_snapshot_valid_pages);

    m_dump_busy = true;
    m_dump_last_pause_us = job->pause_us;
    m_dump_last_capture_us = job->capture_us;
    m_dump_last_worker_us = 0;
    m_dump_last_snapshot_bytes = job->physical_snapshot.size();
    m_dump_status =
        "Coherent RAM snapshot captured; guest resumed. Dump files are being written on the Debug Tools background worker...";

    if (!QueueDumpJob(job)) {
        m_dump_busy = false;
        m_dump_snapshot.swap(job->physical_snapshot);
        m_dump_snapshot_valid_pages.swap(job->physical_valid_pages);
        delete job;
        m_dump_status =
            "Debug Tools background worker is unavailable; RAM snapshot was not written.";
    }
}

// RAM Dump rendering/UI is owned by memory-tools-dump-ui.cc.
