//
// xemu Memory Viewer / Search / x86 Debugger - execution trace
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "memory-tools.hh"
#include "memory-tools-internal.hh"
#include "cheat-engine-memory.h"
#include "../../debug-output-paths.hh"

#include "system/cpus.h"
#include "system/runstate.h"

#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

#include <glib.h>
#include <glib/gstdio.h>

using namespace xemu_memory_tools_internal;

namespace {

constexpr int kTraceMinMb = 1;
constexpr int kTraceMaxMb = 100;
constexpr size_t kTraceCopyChunk = 64 * 1024;

const char *TraceModeName(int mode)
{
    switch (mode) {
    case 0:
        return "Sampled-Full";
    case 1:
        return "Unique";
    case 2:
        return "Control-Flow";
    default:
        return "Trace";
    }
}

} // namespace

const char *MemoryToolsWindow::ExecutionTraceStopReasonText(int reason) const
{
    switch (reason) {
    case XEMU_DBG_TRACE_STOP_NONE:
        return "None";
    case XEMU_DBG_TRACE_STOP_MANUAL:
        return "Stopped by user";
    case XEMU_DBG_TRACE_STOP_SIZE_LIMIT:
        return "Maximum trace size reached";
    case XEMU_DBG_TRACE_STOP_ADDRESS:
        return "Stop address reached";
    case XEMU_DBG_TRACE_STOP_BREAKPOINT:
        return "Debugger breakpoint/watchpoint reached";
    case XEMU_DBG_TRACE_STOP_ERROR:
        return "Trace backend error";
    default:
        return "Unknown";
    }
}

std::string MemoryToolsWindow::ExecutionTraceDirectory() const
{
    return XemuDebugOutput::Directory(XemuDebugOutput::Folder::TraceDumps);
}

void MemoryToolsWindow::ClearExecutionTrace()
{
    if (m_trace_running) {
        return;
    }

    m_trace_samples.clear();
    m_trace_unique_rows.clear();
    m_trace_unique_index.clear();
    m_trace_flow_rows.clear();
    m_trace_flow_index.clear();
    m_trace_event_count = 0;
    m_trace_event_limit = 0;
    m_trace_last_eip = 0;
    m_trace_have_previous = false;
    m_trace_previous_eip = 0;
    m_trace_stop_reason = XEMU_DBG_TRACE_STOP_NONE;
    m_trace_status = "Trace data cleared.";
    m_trace_export_status.clear();
}

void MemoryToolsWindow::RecordExecutionTraceAddress(uint32_t eip)
{
    m_trace_last_eip = eip;

    if (m_trace_stop_address_enabled && eip == m_trace_stop_address) {
        /* Keep the stop address itself in the trace when it is inside the
         * requested capture range. */
        if (eip < m_trace_capture_range_start || eip > m_trace_capture_range_end) {
            m_trace_stop_reason = XEMU_DBG_TRACE_STOP_ADDRESS;
            StopExecutionTrace(false);
            return;
        }
    }

    if (eip < m_trace_capture_range_start || eip > m_trace_capture_range_end) {
        /* Do not create a fake flow edge across code that was filtered out. */
        m_trace_have_previous = false;
        return;
    }

    const uint64_t event_index = m_trace_event_count;
    m_trace_samples.push_back(eip);
    ++m_trace_event_count;

    if (m_trace_capture_mode == ExecutionTraceMode::UniqueAddresses) {
        auto found = m_trace_unique_index.find(eip);
        if (found == m_trace_unique_index.end()) {
            const size_t index = m_trace_unique_rows.size();
            m_trace_unique_index.emplace(eip, index);
            m_trace_unique_rows.push_back({eip, 1, event_index, event_index});
        } else {
            ExecutionTraceUniqueRow &row = m_trace_unique_rows[found->second];
            ++row.hits;
            row.last_event = event_index;
        }
    } else if (m_trace_capture_mode == ExecutionTraceMode::ControlFlow) {
        if (m_trace_have_previous) {
            const uint64_t key = ((uint64_t)m_trace_previous_eip << 32) | eip;
            auto found = m_trace_flow_index.find(key);
            if (found == m_trace_flow_index.end()) {
                const size_t index = m_trace_flow_rows.size();
                m_trace_flow_index.emplace(key, index);
                m_trace_flow_rows.push_back(
                    {m_trace_previous_eip, eip, 1, event_index - 1,
                     event_index - 1});
            } else {
                ExecutionTraceFlowRow &row = m_trace_flow_rows[found->second];
                ++row.hits;
                row.last_event = event_index - 1;
            }
        }
        m_trace_previous_eip = eip;
        m_trace_have_previous = true;
    }

    if (m_trace_stop_address_enabled && eip == m_trace_stop_address) {
        m_trace_stop_reason = XEMU_DBG_TRACE_STOP_ADDRESS;
        StopExecutionTrace(false);
        return;
    }

    if (m_trace_event_limit != 0 && m_trace_event_count >= m_trace_event_limit) {
        m_trace_stop_reason = XEMU_DBG_TRACE_STOP_SIZE_LIMIT;
        StopExecutionTrace(false);
    }
}

bool MemoryToolsWindow::StartExecutionTrace()
{
    uint32_t range_start;
    uint32_t range_end;
    uint32_t stop_address = 0;
    uint32_t initial_eip = 0;

    if (m_trace_running) {
        m_trace_status = "A trace is already running.";
        return false;
    }
    if (!ParseHexAddress(m_trace_range_start_text, range_start) ||
        !ParseHexAddress(m_trace_range_end_text, range_end) ||
        range_start > range_end) {
        m_trace_status = "Invalid trace address range.";
        return false;
    }
    if (m_trace_stop_address_enabled &&
        !ParseHexAddress(m_trace_stop_address_text, stop_address)) {
        m_trace_status = "Invalid trace stop address.";
        return false;
    }

    m_trace_interval_ms = std::clamp(m_trace_interval_ms, 0, 60000);
    m_trace_max_mb = std::clamp(m_trace_max_mb, kTraceMinMb, kTraceMaxMb);
    m_trace_stop_address = stop_address;
    m_trace_capture_mode = m_trace_mode;
    m_trace_capture_interval_ms = m_trace_interval_ms;
    m_trace_capture_max_mb = m_trace_max_mb;
    m_trace_capture_range_start = range_start;
    m_trace_capture_range_end = range_end;
    m_trace_event_limit =
        ((uint64_t)m_trace_capture_max_mb * 1024ull * 1024ull) / sizeof(uint32_t);

    m_trace_samples.clear();
    m_trace_unique_rows.clear();
    m_trace_unique_index.clear();
    m_trace_flow_rows.clear();
    m_trace_flow_index.clear();
    m_trace_event_count = 0;
    m_trace_last_eip = 0;
    m_trace_have_previous = false;
    m_trace_previous_eip = 0;
    m_trace_stop_reason = XEMU_DBG_TRACE_STOP_NONE;
    m_trace_export_status.clear();

    if (m_trace_capture_interval_ms == 0) {
        const bool was_running = runstate_is_running();
        if (!xemu_dbg_trace_full_supported()) {
            m_trace_status =
                "Every-instruction tracing is unavailable on the active debugger backend.";
            return false;
        }

        /* Detached Memory Tools must not call vm_stop()/vm_start() directly.
         * Use the established run-state bridge so main-loop-lock/BQL ordering
         * remains valid on the UI thread. */
        if (was_running && !xemu_cheat_pause_guest()) {
            m_trace_status = "Could not pause the guest to start full tracing.";
            return false;
        }
        if (!xemu_dbg_get_pc(&initial_eip)) {
            m_trace_status = "Could not read EIP before starting full tracing.";
            if (was_running) {
                xemu_cheat_resume_guest();
            }
            return false;
        }

        const uint64_t max_bytes =
            (uint64_t)m_trace_capture_max_mb * 1024ull * 1024ull;
        if (!xemu_dbg_trace_full_start(
                initial_eip, m_trace_capture_range_start,
                m_trace_capture_range_end, max_bytes,
                m_trace_stop_address_enabled ? 1 : 0, m_trace_stop_address)) {
            m_trace_status = "Could not initialize the exact full trace buffer.";
            if (was_running) {
                xemu_cheat_resume_guest();
            }
            return false;
        }

        XemuDbgTraceStatus status = {};
        xemu_dbg_trace_full_get_status(&status);
        m_trace_event_count = status.entry_count;
        m_trace_last_eip = status.last_eip;
        m_trace_full_backend = true;
        m_trace_running = status.active != 0;

        if (!status.active) {
            m_trace_stop_reason = status.stop_reason;
            m_trace_full_backend = false;
            m_trace_status = std::string("Trace stopped immediately: ") +
                             ExecutionTraceStopReasonText(status.stop_reason);
            if (was_running) {
                xemu_cheat_resume_guest();
            }
            return true;
        }

        if (!xemu_cheat_start_single_step()) {
            xemu_dbg_trace_full_stop();
            m_trace_running = false;
            m_trace_full_backend = false;
            m_trace_stop_reason = XEMU_DBG_TRACE_STOP_ERROR;
            m_trace_status = "Could not start continuous debugger single-step tracing.";
            if (was_running) {
                xemu_cheat_resume_guest();
            }
            return false;
        }

        m_trace_status =
            "Every-instruction trace active. The debugger backend is single-stepping the guest.";
        return true;
    }

    if (!xemu_dbg_get_pc(&initial_eip)) {
        m_trace_status = "Could not read EIP to start sampled tracing.";
        return false;
    }

    m_trace_full_backend = false;
    m_trace_running = true;
    m_trace_next_sample_us = g_get_monotonic_time();
    RecordExecutionTraceAddress(initial_eip);
    if (!runstate_is_running() && m_trace_running) {
        xemu_cheat_resume_guest();
    }

    if (m_trace_running) {
        char message[192];
        std::snprintf(message, sizeof(message),
                      "Sampled trace active (%d ms requested interval).",
                      m_trace_capture_interval_ms);
        m_trace_status = message;
    }
    return true;
}

void MemoryToolsWindow::StopExecutionTrace(bool manual_stop)
{
    if (!m_trace_running) {
        return;
    }

    if (m_trace_full_backend) {
        const bool was_running = runstate_is_running();
        if (was_running && !xemu_cheat_pause_guest()) {
            m_trace_status = "Could not pause the guest to stop full tracing.";
            return;
        }
        xemu_dbg_trace_full_stop();
        xemu_cheat_single_step(0);
        if (was_running) {
            xemu_cheat_resume_guest();
        }

        XemuDbgTraceStatus status = {};
        xemu_dbg_trace_full_get_status(&status);
        m_trace_event_count = status.entry_count;
        m_trace_last_eip = status.last_eip;
        m_trace_stop_reason = manual_stop ? XEMU_DBG_TRACE_STOP_MANUAL
                                          : status.stop_reason;
        m_trace_running = false;
        m_trace_full_backend = false;
        RebuildExecutionTraceSummaryFromFullBackend();
    } else {
        m_trace_running = false;
        if (manual_stop || m_trace_stop_reason == XEMU_DBG_TRACE_STOP_NONE) {
            m_trace_stop_reason = XEMU_DBG_TRACE_STOP_MANUAL;
        }
    }

    m_trace_status = std::string("Trace stopped: ") +
                     ExecutionTraceStopReasonText(m_trace_stop_reason);
}

void MemoryToolsWindow::FinalizeFullExecutionTrace()
{
    XemuDbgTraceStatus status = {};
    xemu_dbg_trace_full_get_status(&status);

    m_trace_event_count = status.entry_count;
    m_trace_last_eip = status.last_eip;
    m_trace_stop_reason = status.stop_reason;
    m_trace_running = false;
    m_trace_full_backend = false;
    xemu_cheat_single_step(0);
    RebuildExecutionTraceSummaryFromFullBackend();
    m_trace_status = std::string("Trace stopped: ") +
                     ExecutionTraceStopReasonText(m_trace_stop_reason);
}

void MemoryToolsWindow::RebuildExecutionTraceSummaryFromFullBackend()
{
    if (m_trace_capture_mode == ExecutionTraceMode::SampledFull) {
        return;
    }

    m_trace_unique_rows.clear();
    m_trace_unique_index.clear();
    m_trace_flow_rows.clear();
    m_trace_flow_index.clear();

    std::vector<uint32_t> chunk(kTraceCopyChunk);
    uint64_t offset = 0;
    uint64_t event_index = 0;
    bool have_previous = false;
    uint32_t previous = 0;
    std::unordered_map<uint32_t, uint32_t> fallthrough_cache;

    while (offset < m_trace_event_count) {
        const uint64_t copied = xemu_dbg_trace_full_copy(
            offset, chunk.data(), std::min<uint64_t>(chunk.size(),
                                                     m_trace_event_count - offset));
        if (copied == 0) {
            break;
        }

        for (uint64_t i = 0; i < copied; ++i, ++event_index) {
            const uint32_t eip = chunk[(size_t)i];
            if (m_trace_capture_mode == ExecutionTraceMode::UniqueAddresses) {
                auto found = m_trace_unique_index.find(eip);
                if (found == m_trace_unique_index.end()) {
                    const size_t index = m_trace_unique_rows.size();
                    m_trace_unique_index.emplace(eip, index);
                    m_trace_unique_rows.push_back(
                        {eip, 1, event_index, event_index});
                } else {
                    ExecutionTraceUniqueRow &row =
                        m_trace_unique_rows[found->second];
                    ++row.hits;
                    row.last_event = event_index;
                }
            } else if (m_trace_capture_mode == ExecutionTraceMode::ControlFlow) {
                if (have_previous) {
                    uint32_t expected_fallthrough = previous + 1;
                    auto cached = fallthrough_cache.find(previous);
                    if (cached != fallthrough_cache.end()) {
                        expected_fallthrough = cached->second;
                    } else {
                        XemuCheatDisasmRow row = {};
                        size_t row_count = 0;
                        if (xemu_cheat_disassemble_paired(
                                previous, 1, &row, 1, &row_count) ==
                                XEMU_CHEAT_DISAS_OK &&
                            row_count == 1) {
                            expected_fallthrough =
                                previous + std::max<uint8_t>(row.size, 1);
                        }
                        fallthrough_cache.emplace(previous,
                                                  expected_fallthrough);
                    }

                    /* Full mode can distinguish real non-linear control-flow
                     * edges from ordinary sequential instruction execution. */
                    if (eip != expected_fallthrough) {
                        const uint64_t key = ((uint64_t)previous << 32) | eip;
                        auto found = m_trace_flow_index.find(key);
                        if (found == m_trace_flow_index.end()) {
                            const size_t index = m_trace_flow_rows.size();
                            m_trace_flow_index.emplace(key, index);
                            m_trace_flow_rows.push_back(
                                {previous, eip, 1, event_index - 1,
                                 event_index - 1});
                        } else {
                            ExecutionTraceFlowRow &flow =
                                m_trace_flow_rows[found->second];
                            ++flow.hits;
                            flow.last_event = event_index - 1;
                        }
                    }
                }
                previous = eip;
                have_previous = true;
            }
        }
        offset += copied;
    }
}

void MemoryToolsWindow::TickExecutionTrace()
{
    if (!m_trace_running) {
        return;
    }

    if (m_trace_full_backend) {
        XemuDbgTraceStatus status = {};
        xemu_dbg_trace_full_get_status(&status);
        m_trace_event_count = status.entry_count;
        m_trace_last_eip = status.last_eip;
        if (!status.active) {
            FinalizeFullExecutionTrace();
        }
        return;
    }

    if (!runstate_is_running()) {
        return;
    }

    const int64_t now_us = g_get_monotonic_time();
    if (now_us < m_trace_next_sample_us) {
        return;
    }

    uint32_t eip = 0;
    if (xemu_dbg_get_pc(&eip)) {
        RecordExecutionTraceAddress(eip);
    }
    m_trace_next_sample_us =
        now_us + (int64_t)std::max(m_trace_capture_interval_ms, 1) * 1000;
}

bool MemoryToolsWindow::ExportExecutionTraceText()
{
    if (m_trace_running || m_trace_event_count == 0) {
        m_trace_export_status = "Stop the trace before exporting text.";
        return false;
    }

    const std::string directory = ExecutionTraceDirectory();
    if (directory.empty() || g_mkdir_with_parents(directory.c_str(), 0755) != 0) {
        m_trace_export_status = "Could not create the DEBUG/Trace-Dumps directory.";
        return false;
    }

    const std::string filename =
        DumpStem() + "-TRACE-" + TraceModeName((int)m_trace_capture_mode) + ".txt";
    gchar *path_c = g_build_filename(directory.c_str(), filename.c_str(), nullptr);
    const std::string path = path_c ? path_c : filename;
    g_free(path_c);

    FILE *fp = g_fopen(path.c_str(), "wb");
    if (fp == nullptr) {
        m_trace_export_status = "Could not create trace text file.";
        return false;
    }

    std::fprintf(fp, "XEMU Execution Trace v1\n");
    std::fprintf(fp, "Mode: %s\n", TraceModeName((int)m_trace_capture_mode));
    std::fprintf(fp, "Sample Interval: %d ms (0 = every instruction)\n",
                 m_trace_capture_interval_ms);
    std::fprintf(fp, "Address Range: %08X-%08X\n",
                 m_trace_capture_range_start, m_trace_capture_range_end);
    std::fprintf(fp, "Events: %llu\n",
                 (unsigned long long)m_trace_event_count);
    std::fprintf(fp, "Stop Reason: %s\n\n",
                 ExecutionTraceStopReasonText(m_trace_stop_reason));

    if (m_trace_capture_mode == ExecutionTraceMode::SampledFull) {
        std::fprintf(fp, "Index\tEIP\n");
        if (m_trace_capture_interval_ms == 0) {
            std::vector<uint32_t> chunk(kTraceCopyChunk);
            uint64_t offset = 0;
            while (offset < m_trace_event_count) {
                const uint64_t copied = xemu_dbg_trace_full_copy(
                    offset, chunk.data(),
                    std::min<uint64_t>(chunk.size(),
                                       m_trace_event_count - offset));
                if (copied == 0) {
                    break;
                }
                for (uint64_t i = 0; i < copied; ++i) {
                    std::fprintf(fp, "%llu\t%08X\n",
                                 (unsigned long long)(offset + i),
                                 chunk[(size_t)i]);
                }
                offset += copied;
            }
        } else {
            for (size_t i = 0; i < m_trace_samples.size(); ++i) {
                std::fprintf(fp, "%llu\t%08X\n",
                             (unsigned long long)i, m_trace_samples[i]);
            }
        }
    } else if (m_trace_capture_mode == ExecutionTraceMode::UniqueAddresses) {
        std::vector<ExecutionTraceUniqueRow> rows = m_trace_unique_rows;
        std::sort(rows.begin(), rows.end(),
                  [](const ExecutionTraceUniqueRow &a,
                     const ExecutionTraceUniqueRow &b) {
                      return a.hits != b.hits ? a.hits > b.hits
                                              : a.address < b.address;
                  });
        std::fprintf(fp, "Address\tHits\tFirst Event\tLast Event\n");
        for (const auto &row : rows) {
            std::fprintf(fp, "%08X\t%llu\t%llu\t%llu\n", row.address,
                         (unsigned long long)row.hits,
                         (unsigned long long)row.first_event,
                         (unsigned long long)row.last_event);
        }
    } else {
        std::vector<ExecutionTraceFlowRow> rows = m_trace_flow_rows;
        std::sort(rows.begin(), rows.end(),
                  [](const ExecutionTraceFlowRow &a,
                     const ExecutionTraceFlowRow &b) {
                      if (a.hits != b.hits) {
                          return a.hits > b.hits;
                      }
                      return a.from != b.from ? a.from < b.from : a.to < b.to;
                  });
        std::fprintf(fp, "From\tTo\tHits\tFirst Event\tLast Event\n");
        for (const auto &row : rows) {
            std::fprintf(fp, "%08X\t%08X\t%llu\t%llu\t%llu\n", row.from,
                         row.to, (unsigned long long)row.hits,
                         (unsigned long long)row.first_event,
                         (unsigned long long)row.last_event);
        }
    }

    const bool ok = std::fclose(fp) == 0;
    if (!ok) {
        g_remove(path.c_str());
        m_trace_export_status = "Trace text export failed.";
        return false;
    }
    m_trace_export_status = "Trace text saved to: " + path;
    return true;
}

bool MemoryToolsWindow::ExportExecutionTraceBinary()
{
    if (m_trace_running || m_trace_event_count == 0) {
        m_trace_export_status = "Stop the trace before exporting binary data.";
        return false;
    }

    const std::string directory = ExecutionTraceDirectory();
    if (directory.empty() || g_mkdir_with_parents(directory.c_str(), 0755) != 0) {
        m_trace_export_status = "Could not create the DEBUG/Trace-Dumps directory.";
        return false;
    }

    const std::string filename =
        DumpStem() + "-TRACE-RAW.bin";
    gchar *path_c = g_build_filename(directory.c_str(), filename.c_str(), nullptr);
    const std::string path = path_c ? path_c : filename;
    g_free(path_c);

    FILE *fp = g_fopen(path.c_str(), "wb");
    if (fp == nullptr) {
        m_trace_export_status = "Could not create trace binary file.";
        return false;
    }

    char magic[16] = {};
    std::memcpy(magic, "XEMU-TRACE-V1", 13);
    const uint32_t mode = (uint32_t)m_trace_capture_mode;
    const uint32_t interval = (uint32_t)m_trace_capture_interval_ms;
    const uint32_t stop_reason = (uint32_t)m_trace_stop_reason;
    const uint64_t count = m_trace_event_count;

    bool ok = std::fwrite(magic, 1, sizeof(magic), fp) == sizeof(magic) &&
              std::fwrite(&mode, sizeof(mode), 1, fp) == 1 &&
              std::fwrite(&interval, sizeof(interval), 1, fp) == 1 &&
              std::fwrite(&m_trace_capture_range_start,
                          sizeof(m_trace_capture_range_start), 1, fp) == 1 &&
              std::fwrite(&m_trace_capture_range_end,
                          sizeof(m_trace_capture_range_end), 1, fp) == 1 &&
              std::fwrite(&stop_reason, sizeof(stop_reason), 1, fp) == 1 &&
              std::fwrite(&count, sizeof(count), 1, fp) == 1;

    if (ok && m_trace_capture_interval_ms == 0) {
        std::vector<uint32_t> chunk(kTraceCopyChunk);
        uint64_t offset = 0;
        while (offset < m_trace_event_count) {
            const uint64_t copied = xemu_dbg_trace_full_copy(
                offset, chunk.data(),
                std::min<uint64_t>(chunk.size(), m_trace_event_count - offset));
            if (copied == 0 ||
                std::fwrite(chunk.data(), sizeof(uint32_t), (size_t)copied, fp) !=
                    copied) {
                ok = false;
                break;
            }
            offset += copied;
        }
    } else if (ok) {
        ok = std::fwrite(m_trace_samples.data(), sizeof(uint32_t),
                         m_trace_samples.size(), fp) == m_trace_samples.size();
    }

    if (std::fclose(fp) != 0) {
        ok = false;
    }
    if (!ok) {
        g_remove(path.c_str());
        m_trace_export_status = "Trace binary export failed.";
        return false;
    }

    m_trace_export_status = "Raw trace saved to: " + path;
    return true;
}

void MemoryToolsWindow::NotifyExecutionTraceGameReset()
{
    if (m_trace_running) {
        StopExecutionTrace(true);
        m_trace_status = "Trace stopped because the Xbox was reset.";
    }
}
