//
// xemu Memory Viewer / Search / x86 Debugger - execution trace UI
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "memory-tools.hh"
#include "cheat-engine-memory.h"

#include <algorithm>
#include <cfloat>
#include <cstdio>
#include <vector>

namespace {

constexpr size_t kVisibleTraceRows = 500;

const char *TraceModeLabel(int mode)
{
    switch (mode) {
    case 0:
        return "Sampled / Full";
    case 1:
        return "Unique Addresses";
    case 2:
        return "Basic Block / Control Flow";
    default:
        return "Unknown";
    }
}

} // namespace

void MemoryToolsWindow::DrawExecutionTraceWindow()
{
    if (!m_trace_window_open) {
        return;
    }

    if (m_trace_focus_requested) {
        ImGui::SetNextWindowFocus();
        ImGui::SetNextWindowSize(ImVec2(760.0f, 590.0f), ImGuiCond_Appearing);
        m_trace_focus_requested = false;
    }

    if (!ImGui::Begin("Execution Trace", &m_trace_window_open,
                      ImGuiWindowFlags_NoCollapse)) {
        ImGui::End();
        return;
    }

    const bool config_disabled = m_trace_running;
    const char *trace_modes[] = {
        "Sampled / Full",
        "Unique Addresses",
        "Basic Block / Control Flow",
    };
    int mode = (int)m_trace_mode;

    ImGui::BeginDisabled(config_disabled);
    ImGui::SetNextItemWidth(225.0f);
    if (ImGui::Combo("Mode", &mode, trace_modes, IM_ARRAYSIZE(trace_modes))) {
        m_trace_mode = (ExecutionTraceMode)std::clamp(mode, 0, 2);
    }
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip(
            "Sampled / Full: ordered EIP history\n"
            "Unique Addresses: address + hit counts\n"
            "Basic Block / Control Flow: transitions; with 0 ms, ordinary sequential fall-through is removed");
    }

    ImGui::SetNextItemWidth(110.0f);
    ImGui::InputInt("Sample Interval (ms)", &m_trace_interval_ms, 1, 5);
    m_trace_interval_ms = std::clamp(m_trace_interval_ms, 0, 60000);
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip(
            "Positive values sample EIP periodically.\n"
            "0 = every instruction using WHPX single-step (very slow).\n"
            "Positive intervals are serviced by the Debug Tools tick and can be limited by UI/frame cadence.");
    }
    if (m_trace_interval_ms == 0) {
        ImGui::SameLine();
        ImGui::TextDisabled("WARNING: 0 = every instruction / WHPX full trace");
    }

    ImGui::SetNextItemWidth(118.0f);
    ImGui::InputText("Range Start", m_trace_range_start_text,
                     sizeof(m_trace_range_start_text),
                     ImGuiInputTextFlags_CharsHexadecimal);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(118.0f);
    ImGui::InputText("Range End", m_trace_range_end_text,
                     sizeof(m_trace_range_end_text),
                     ImGuiInputTextFlags_CharsHexadecimal);

    ImGui::SetNextItemWidth(110.0f);
    ImGui::InputInt("Maximum Size (MB)", &m_trace_max_mb, 1, 10);
    m_trace_max_mb = std::clamp(m_trace_max_mb, 1, 100);
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip(
            "1-100 MB. Raw EIP entries are 4 bytes each.\n"
            "10 MB stores about 2.62 million captured addresses.");
    }

    ImGui::Checkbox("Stop at Address", &m_trace_stop_address_enabled);
    if (m_trace_stop_address_enabled) {
        ImGui::SameLine();
        ImGui::SetNextItemWidth(118.0f);
        ImGui::InputText("##trace_stop_address", m_trace_stop_address_text,
                         sizeof(m_trace_stop_address_text),
                         ImGuiInputTextFlags_CharsHexadecimal);
    }
    ImGui::EndDisabled();

    ImGui::Separator();

    if (!m_trace_running) {
        if (m_trace_interval_ms == 0) {
            const bool full_supported = xemu_dbg_trace_full_supported() != 0;
            ImGui::BeginDisabled(!full_supported);
            if (ImGui::Button("Start Trace")) {
                m_trace_full_warning_open = true;
            }
            ImGui::EndDisabled();
            if (!full_supported) {
                ImGui::SameLine();
                ImGui::TextDisabled("Every-instruction mode currently requires WHPX.");
            }
        } else if (ImGui::Button("Start Trace")) {
            StartExecutionTrace();
        }
    } else {
        if (ImGui::Button("Stop Trace")) {
            StopExecutionTrace(true);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("Recording...");
    }

    ImGui::SameLine();
    ImGui::BeginDisabled(m_trace_running);
    if (ImGui::Button("Clear")) {
        ClearExecutionTrace();
    }
    ImGui::EndDisabled();

    ImGui::SameLine();
    ImGui::BeginDisabled(m_trace_running || m_trace_event_count == 0);
    if (ImGui::Button("Export TXT")) {
        ExportExecutionTraceText();
    }
    ImGui::SameLine();
    if (ImGui::Button("Export BIN")) {
        ExportExecutionTraceBinary();
    }
    ImGui::EndDisabled();

    const bool have_capture = m_trace_running || m_trace_event_count != 0;
    const ExecutionTraceMode display_mode =
        have_capture ? m_trace_capture_mode : m_trace_mode;
    const int display_interval_ms =
        have_capture ? m_trace_capture_interval_ms : m_trace_interval_ms;
    const int display_max_mb =
        have_capture ? m_trace_capture_max_mb : m_trace_max_mb;
    const double captured_mb =
        (double)(m_trace_event_count * sizeof(uint32_t)) / (1024.0 * 1024.0);
    const double max_mb = (double)display_max_mb;

    ImGui::Separator();
    ImGui::Text("Mode: %s", TraceModeLabel((int)display_mode));
    ImGui::SameLine();
    ImGui::Text("Captured: %.2f / %.2f MB", captured_mb, max_mb);
    ImGui::SameLine();
    ImGui::Text("Events: %llu", (unsigned long long)m_trace_event_count);
    ImGui::Text("Last EIP: %08X", m_trace_last_eip);
    ImGui::SameLine();
    if (!m_trace_running && m_trace_stop_reason != XEMU_DBG_TRACE_STOP_NONE) {
        ImGui::TextDisabled("Stop: %s",
                            ExecutionTraceStopReasonText(m_trace_stop_reason));
    } else if (m_trace_running && display_interval_ms == 0) {
        ImGui::TextDisabled("FULL TRACE ACTIVE - emulator performance may be heavily reduced");
    }

    if (!m_trace_status.empty()) {
        ImGui::TextWrapped("%s", m_trace_status.c_str());
    }
    if (!m_trace_export_status.empty()) {
        ImGui::TextWrapped("%s", m_trace_export_status.c_str());
    }

    ImGui::Separator();

    if (m_trace_event_count == 0) {
        ImGui::TextDisabled("No trace entries captured yet.");
    } else if (display_mode == ExecutionTraceMode::SampledFull) {
        if (ImGui::BeginTable("trace_sequence", 2,
                              ImGuiTableFlags_Borders |
                                  ImGuiTableFlags_RowBg |
                                  ImGuiTableFlags_ScrollY,
                              ImVec2(0.0f, 280.0f))) {
            ImGui::TableSetupColumn("Index", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableSetupColumn("EIP", ImGuiTableColumnFlags_WidthFixed,
                                    120.0f);
            ImGui::TableHeadersRow();

            if (display_interval_ms == 0) {
                XemuDbgTraceStatus status = {};
                xemu_dbg_trace_full_get_status(&status);
                const uint64_t total = status.entry_count;
                const uint64_t start = total > kVisibleTraceRows
                                           ? total - kVisibleTraceRows
                                           : 0;
                const uint64_t want = total - start;
                std::vector<uint32_t> rows((size_t)want);
                const uint64_t copied = want == 0
                                            ? 0
                                            : xemu_dbg_trace_full_copy(
                                                  start, rows.data(), want);
                for (uint64_t i = 0; i < copied; ++i) {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)(start + i));
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%08X", rows[(size_t)i]);
                }
            } else {
                const size_t start = m_trace_samples.size() > kVisibleTraceRows
                                         ? m_trace_samples.size() - kVisibleTraceRows
                                         : 0;
                for (size_t i = start; i < m_trace_samples.size(); ++i) {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%llu", (unsigned long long)i);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%08X", m_trace_samples[i]);
                }
            }
            ImGui::EndTable();
        }
        ImGui::TextDisabled("Showing the most recent %zu entries. Export preserves the complete trace.",
                            kVisibleTraceRows);
    } else if (display_mode == ExecutionTraceMode::UniqueAddresses) {
        if (display_interval_ms == 0 && m_trace_running) {
            ImGui::TextDisabled(
                "Full trace is recording raw EIPs. Unique-address summary is built when tracing stops.");
        } else if (ImGui::BeginTable("trace_unique", 4,
                                     ImGuiTableFlags_Borders |
                                         ImGuiTableFlags_RowBg |
                                         ImGuiTableFlags_ScrollY,
                                     ImVec2(0.0f, 280.0f))) {
            ImGui::TableSetupColumn("Address", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableSetupColumn("Hits", ImGuiTableColumnFlags_WidthFixed,
                                    120.0f);
            ImGui::TableSetupColumn("First", ImGuiTableColumnFlags_WidthFixed,
                                    120.0f);
            ImGui::TableSetupColumn("Last", ImGuiTableColumnFlags_WidthFixed,
                                    120.0f);
            ImGui::TableHeadersRow();
            ImGuiListClipper clipper;
            clipper.Begin((int)m_trace_unique_rows.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
                    const ExecutionTraceUniqueRow &row =
                        m_trace_unique_rows[(size_t)i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%08X", row.address);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%llu", (unsigned long long)row.hits);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%llu", (unsigned long long)row.first_event);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("%llu", (unsigned long long)row.last_event);
                }
            }
            ImGui::EndTable();
        }
    } else {
        if (display_interval_ms == 0 && m_trace_running) {
            ImGui::TextDisabled(
                "Full trace is recording raw EIPs. Non-linear control-flow summary is built when tracing stops.");
        } else if (ImGui::BeginTable("trace_flow", 5,
                                     ImGuiTableFlags_Borders |
                                         ImGuiTableFlags_RowBg |
                                         ImGuiTableFlags_ScrollY,
                                     ImVec2(0.0f, 280.0f))) {
            ImGui::TableSetupColumn("From", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableSetupColumn("To", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableSetupColumn("Hits", ImGuiTableColumnFlags_WidthFixed,
                                    100.0f);
            ImGui::TableSetupColumn("First", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableSetupColumn("Last", ImGuiTableColumnFlags_WidthFixed,
                                    110.0f);
            ImGui::TableHeadersRow();
            ImGuiListClipper clipper;
            clipper.Begin((int)m_trace_flow_rows.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) {
                    const ExecutionTraceFlowRow &row =
                        m_trace_flow_rows[(size_t)i];
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::Text("%08X", row.from);
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%08X", row.to);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%llu", (unsigned long long)row.hits);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("%llu", (unsigned long long)row.first_event);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::Text("%llu", (unsigned long long)row.last_event);
                }
            }
            ImGui::EndTable();
        }
        if (display_interval_ms > 0) {
            ImGui::TextDisabled(
                "With sampling enabled, rows are sampled EIP transitions. Use 0 ms for exact non-linear instruction flow.");
        }
    }

    if (m_trace_full_warning_open) {
        ImGui::OpenPopup("Full Instruction Trace Warning");
        m_trace_full_warning_open = false;
    }
    if (ImGui::BeginPopupModal("Full Instruction Trace Warning", nullptr,
                               ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("FULL INSTRUCTION TRACE");
        ImGui::Separator();
        ImGui::TextWrapped(
            "A 0 ms interval records every executed guest CPU instruction by continuously single-stepping WHPX. "
            "This can make emulation extremely slow. Use a small address range and trace size when possible.");
        ImGui::Spacing();
        ImGui::TextDisabled(
            "If this mode proves too slow in real use, it can be disabled later without removing sampled, unique, or control-flow tracing.");
        ImGui::Spacing();
        if (ImGui::Button("Cancel", ImVec2(120.0f, 0.0f))) {
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Start Full Trace", ImVec2(160.0f, 0.0f))) {
            StartExecutionTrace();
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }

    ImGui::End();
}
