//
// File Replace Cheat Engine tab.
//
#include "file-replace.hh"

#include "imgui.h"

#include <cstdio>
#include <string>

namespace XemuFileReplace {
namespace {

std::string Hex64(uint64_t value, unsigned width = 0)
{
    char buffer[40];
    if (width) {
        std::snprintf(buffer, sizeof(buffer), "0x%0*llX", static_cast<int>(width),
                      static_cast<unsigned long long>(value));
    } else {
        std::snprintf(buffer, sizeof(buffer), "0x%llX",
                      static_cast<unsigned long long>(value));
    }
    return buffer;
}

const char *PaddingText(PaddingMode mode)
{
    return mode == PaddingMode::Zero ? "ZERO" : "ORIGINAL";
}

} // namespace

void Manager::DrawTab()
{
    ObserveCurrentGame();

    ImGui::TextWrapped(
        "Disc/File replacement mods. The retail ISO remains untouched; selected "
        "choices become active on Reset.");
    ImGui::Separator();

    if (m_game_id.empty() || m_game_identity.empty()) {
        ImGui::TextDisabled("No current XBE identity is available yet.");
        return;
    }

    ImGui::Text("Game: %s", m_game_name.empty() ? "Unknown" : m_game_name.c_str());
    ImGui::SameLine();
    ImGui::TextDisabled("[%s]", m_game_id.c_str());

    const auto active_snapshot = ActiveDiscOverlay();
    const OverlayStats stats = DiscOverlayStats();
    if (active_snapshot) {
        ImGui::TextDisabled("DVD overlay ACTIVE | Read hits: %llu | Replaced bytes: %llu",
                            static_cast<unsigned long long>(stats.read_hits),
                            static_cast<unsigned long long>(stats.bytes_replaced));
    } else {
        ImGui::TextDisabled("DVD overlay: retail/original disc data");
    }
    if (SelectionDiffersFromActive()) {
        ImGui::Text("NEEDS RESET - selected File Replace choices differ from the active disc overlay.");
    }

    if (!m_manifest_status.empty()) {
        ImGui::TextWrapped("Manifest: %s", m_manifest_status.c_str());
    }
    if (!m_runtime_status.empty()) {
        ImGui::TextWrapped("Status: %s", m_runtime_status.c_str());
    }

    if (ImGui::Button("Refresh")) {
        ReloadManifest(true);
    }
    ImGui::SameLine();
    if (ImGui::Button("Open Version Folder")) {
        std::string error;
        if (!OpenVersionFolder(error)) {
            m_runtime_status = error;
        } else {
            m_runtime_status = "Opened exact executable File Replace folder.";
        }
    }
    ImGui::SameLine();
    const bool reload_allowed = active_snapshot && !active_snapshot->RequiresReset();
    if (!reload_allowed) {
        ImGui::BeginDisabled();
    }
    if (ImGui::Button("Reload Active")) {
        std::string error;
        if (!ReloadActive(error)) {
            m_runtime_status = "Reload failed: " + error;
        } else {
            m_runtime_status = "Reloaded active replacement file(s). Future DVD reads use the new buffers.";
        }
    }
    if (!reload_allowed) {
        ImGui::EndDisabled();
    }

    if (active_snapshot && active_snapshot->RequiresReset()) {
        ImGui::TextDisabled("Whole File / Resizable Range: Reload Active is disabled; use Reset.");
    }
    ImGui::Separator();
    if (!m_manifest_loaded) {
        ImGui::TextDisabled("No valid File Replace manifest is loaded for this Game ID.");
        return;
    }
    if (m_groups.empty()) {
        ImGui::TextDisabled("Manifest contains no File Replace groups.");
        return;
    }

    auto draw_option_information = [&](const ReplacementGroup &group,
                                       const ReplacementOption &option) {
        ImGui::TextUnformatted(option.name.c_str());
        ImGui::TextDisabled("Group: %s", group.name.c_str());
        ImGui::Text("Status: %s", OptionStatus(option).c_str());
        if (!option.description.empty()) {
            ImGui::Separator();
            ImGui::TextWrapped("%s", option.description.c_str());
        }
        const std::string credits = OptionCredits(option);
        if (!credits.empty()) {
            ImGui::TextWrapped("Credits: %s", credits.c_str());
        }

        ImGui::SeparatorText("Game / Version");
        ImGui::Text("Game ID: %s", m_game_id.c_str());
        ImGui::TextWrapped("Executable Identity: %s", m_game_identity.c_str());
        ImGui::TextWrapped("Manifest: %s", m_manifest_path.c_str());
        ImGui::TextWrapped("Version Folder: %s", m_version_directory.c_str());

        if (option.replacement_indices.empty()) {
            ImGui::SeparatorText("Replacement Operations");
            ImGui::TextDisabled("Retail/original disc data; no override ranges are armed by this choice.");
            return;
        }

        ImGui::SeparatorText("Replacement Operations");
        for (size_t operation = 0; operation < option.replacement_indices.size(); ++operation) {
            const size_t index = option.replacement_indices[operation];
            if (index >= m_entries.size()) {
                continue;
            }
            const ReplacementEntry &entry = m_entries[index];
            ImGui::PushID(static_cast<int>(operation));
            if (operation != 0) {
                ImGui::Separator();
            }
            ImGui::Text("%zu. %s", operation + 1, entry.name.c_str());
            if (!entry.description.empty() && entry.description != option.description) {
                ImGui::TextWrapped("%s", entry.description.c_str());
            }
            ImGui::Text("Mode: %s", entry.source_type == SourceType::WholeFile ? "Whole File" :
                        entry.size_change ? "Resizable Range" : "Fixed Range");
            if (!entry.fix_size.empty()) ImGui::Text("Known File Size Fixer: %s", entry.fix_size.c_str());
            ImGui::Text("Disc File: %s", entry.disc_file.c_str());
            ImGui::Text("File Offset: %s", Hex64(entry.file_offset, 8).c_str());
            ImGui::Text("%s: %s", entry.size_change ? "Original Size" : "Reserved", Hex64(entry.reserved_size, 8).c_str());
            if (entry.resolved) {
                ImGui::Text("Absolute Disc Offset: %s", Hex64(entry.disc_start).c_str());
            }
            ImGui::TextWrapped("Host: %s", entry.host_path.empty()
                                                   ? entry.replacement_file.c_str()
                                                   : entry.host_path.c_str());
            ImGui::Text("Host Size: %s", Hex64(entry.host_size, 8).c_str());
            if (!entry.size_change && entry.host_size <= entry.reserved_size) {
                ImGui::Text("Unused: %s",
                            Hex64(entry.reserved_size - entry.host_size, 8).c_str());
            }
            if (!entry.size_change) ImGui::Text("Padding: %s", PaddingText(entry.padding));
            ImGui::TextWrapped("Operation Status: %s",
                               entry.status.empty() ? "UNRESOLVED" : entry.status.c_str());
            ImGui::PopID();
        }
        ImGui::TextDisabled(
            "Reload Active swaps validated host data into future DVD reads. It does not "
            "change resource data the game already copied into Xbox RAM.");
    };

    auto open_option_information = [&](const ReplacementGroup &group,
                                       const ReplacementOption &option) {
        m_information_group_id = group.id;
        m_information_option_id = option.id;
        m_information_window_open = true;
    };

    for (size_t group_index = 0; group_index < m_groups.size(); ++group_index) {
        ReplacementGroup &group = m_groups[group_index];
        std::string summary;
        if (group.selection == GroupSelection::Single) {
            const ReplacementOption *active = nullptr;
            const ReplacementOption *pending = nullptr;
            for (const auto &option : group.options) {
                if (option.active) {
                    active = &option;
                }
                if (option.selected && !option.active) {
                    pending = &option;
                }
            }
            if (pending) {
                summary = pending->name + " [NEEDS RESET]";
            } else if (active) {
                summary = active->name + " [ACTIVE]";
            } else {
                summary = "READY";
            }
        } else {
            size_t active_count = 0;
            bool pending = false;
            for (const auto &option : group.options) {
                active_count += option.active ? 1u : 0u;
                pending = pending || (option.selected != option.active);
            }
            if (pending) {
                summary = "Changes [NEEDS RESET]";
            } else if (active_count) {
                summary = std::to_string(active_count) + " ACTIVE";
            } else {
                summary = "READY";
            }
        }

        std::string header = group.name;
        if (!summary.empty()) {
            header += " - " + summary;
        }
        header += "##FileReplaceGroup" + group.id;

        ImGui::PushID(static_cast<int>(group_index));
        if (ImGui::CollapsingHeader(header.c_str())) {
            for (size_t option_index = 0; option_index < group.options.size(); ++option_index) {
                ReplacementOption &option = group.options[option_index];
                ImGui::PushID(static_cast<int>(option_index));

                const std::string dependency = OptionDependencyStatus(option);
                const bool can_choose = dependency == "READY" || option.selected || option.active;
                bool changed = false;
                if (!can_choose) {
                    ImGui::BeginDisabled();
                }
                if (group.selection == GroupSelection::Single) {
                    if (ImGui::RadioButton(option.name.c_str(), option.selected)) {
                        for (auto &other : group.options) {
                            other.selected = false;
                        }
                        option.selected = true;
                        changed = true;
                    }
                } else {
                    bool selected = option.selected;
                    if (ImGui::Checkbox(option.name.c_str(), &selected)) {
                        option.selected = selected;
                        changed = true;
                    }
                }
                if (!can_choose) {
                    ImGui::EndDisabled();
                }

                if (changed) {
                    SyncEntryStateFromOptions();
                    m_runtime_status = group.name + " / " + option.name +
                                       ": selected state changed - RESET REQUIRED.";
                }

                if (ImGui::BeginPopupContextItem("##OptionInfoContext")) {
                    if (ImGui::MenuItem("Information")) {
                        open_option_information(group, option);
                    }
                    ImGui::EndPopup();
                }

                ImGui::SameLine();
                ImGui::TextDisabled("%s", OptionStatus(option).c_str());
                ImGui::SameLine();
                if (ImGui::SmallButton("i")) {
                    open_option_information(group, option);
                }
                if (ImGui::IsItemHovered()) {
                    ImGui::SetTooltip("Replacement information");
                }

                ImGui::PopID();
            }
        }
        ImGui::PopID();
    }

    if (m_information_window_open) {
        const ReplacementGroup *information_group = nullptr;
        const ReplacementOption *information_option = nullptr;
        for (const auto &group : m_groups) {
            if (group.id != m_information_group_id) {
                continue;
            }
            information_group = &group;
            for (const auto &option : group.options) {
                if (option.id == m_information_option_id) {
                    information_option = &option;
                    break;
                }
            }
            break;
        }

        if (!information_group || !information_option) {
            m_information_window_open = false;
            m_information_group_id.clear();
            m_information_option_id.clear();
        } else {
            ImGui::SetNextWindowSize(ImVec2(650, 520), ImGuiCond_FirstUseEver);
            const std::string information_title =
                "File Replace Information - " + information_option->name +
                "###FileReplaceInformation";
            if (ImGui::Begin(information_title.c_str(),
                             &m_information_window_open,
                             ImGuiWindowFlags_NoCollapse)) {
                draw_option_information(*information_group, *information_option);
            }
            ImGui::End();

            if (!m_information_window_open) {
                m_information_group_id.clear();
                m_information_option_id.clear();
            }
        }
    }
}

} // namespace XemuFileReplace
