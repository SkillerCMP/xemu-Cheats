#pragma once
#include "file-replace-disc-overlay.hh"
#include "known-size-fixers.hh"
namespace XemuFileReplace {
struct CompileOperation {
    std::string id;
    uint64_t offset = 0, size = 0;
    bool whole_file = false, size_change = false;
    PaddingMode padding = PaddingMode::Original;
    std::string fix_size;
    SharedBytes bytes;
};
struct CompileFile {
    std::string name;
    uint64_t disc_start = 0, size = 0, directory_entry = 0, filesystem_base = 0;
    std::vector<CompileOperation> operations;
};
// Build locally; the caller publishes only after rechecking the mounted medium.
// Physical ISO bytes are read-only. Original file extents are never copied in full.
bool CompileOverlay(const RawReader &reader, uint64_t disc_length,
                    const std::vector<CompileFile> &files, OverlaySnapshot &out,
                    std::string &error);
}
