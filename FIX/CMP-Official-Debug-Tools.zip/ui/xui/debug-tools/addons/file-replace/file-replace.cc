//
// Generic game/version-scoped DVD File Replace manager.
//
#include "file-replace.hh"
#include "file-replace-compiler.hh"

#include "cheat-engine-memory.h"
#include "current-game.hh"
#include "disc-block-io.h"
#include "disc-block-ref.hh"
#include "xdvdfs-disc.hh"

#include <SDL3/SDL.h>
#include <glib.h>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

namespace XemuFileReplace {
namespace {

using json = nlohmann::json;
namespace fs = std::filesystem;

constexpr uint64_t kMaxReplacementSize = 1024ull * 1024ull * 1024ull;

std::string Upper(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(),
                   [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return value;
}

bool GetString(const json &object, const char *key, std::string &out)
{
    const auto it = object.find(key);
    if (it == object.end() || !it->is_string()) {
        return false;
    }
    out = it->get<std::string>();
    return true;
}

bool GetBool(const json &object, const char *key, bool fallback, bool &out)
{
    const auto it = object.find(key);
    if (it == object.end()) {
        out = fallback;
        return true;
    }
    if (!it->is_boolean()) {
        return false;
    }
    out = it->get<bool>();
    return true;
}

bool ParseUnsignedText(const std::string &text, uint64_t &out)
{
    if (text.empty() || text[0] == '-') {
        return false;
    }
    const char *begin = text.c_str();
    int base = 10;
    if (text.size() > 2 && text[0] == '0' &&
        (text[1] == 'x' || text[1] == 'X')) {
        begin += 2;
        base = 16;
    }
    if (*begin == '\0') {
        return false;
    }
    for (const char *p = begin; *p; ++p) {
        const unsigned char ch = static_cast<unsigned char>(*p);
        if (!(base == 16 ? std::isxdigit(ch) : std::isdigit(ch))) return false;
    }
    errno = 0;
    char *end = nullptr;
    const unsigned long long value = std::strtoull(begin, &end, base);
    if (errno == ERANGE || !end || *end != '\0') {
        return false;
    }
    out = static_cast<uint64_t>(value);
    return true;
}

bool GetUnsigned(const json &object, const char *key, uint64_t &out)
{
    const auto it = object.find(key);
    if (it == object.end()) {
        return false;
    }
    if (it->is_string()) {
        return ParseUnsignedText(it->get<std::string>(), out);
    }
    if (it->is_number_unsigned()) {
        out = it->get<uint64_t>();
        return true;
    }
    if (it->is_number_integer()) {
        const int64_t value = it->get<int64_t>();
        if (value < 0) {
            return false;
        }
        out = static_cast<uint64_t>(value);
        return true;
    }
    return false;
}

std::string JoinPath(const std::string &a, const std::string &b)
{
    return (fs::path(a) / fs::path(b)).string();
}

std::string ExecutableDirectory()
{
    char buffer[4096] = {};
    if (!xemu_cheat_get_executable_dir(buffer, sizeof(buffer))) {
        return ".";
    }
    return buffer;
}

bool SafeRelativeHostPath(const std::string &input, fs::path &out)
{
    std::string normalized = input;
    std::replace(normalized.begin(), normalized.end(), '\\', '/');
    fs::path path(normalized);
    if (normalized.find(':') != std::string::npos || normalized.find('\0') != std::string::npos ||
        path.empty() || path.is_absolute() || path.has_root_name() ||
        path.has_root_directory()) {
        return false;
    }
    fs::path clean;
    for (const auto &component : path) {
        const std::string part = component.string();
        if (part.empty() || part == "." || part == "..") {
            return false;
        }
        clean /= component;
    }
    if (clean.empty()) {
        return false;
    }
    out = clean;
    return true;
}

bool DiscPathComponents(const std::string &input,
                        std::vector<std::string> &components)
{
    components.clear();
    std::string normalized = input;
    std::replace(normalized.begin(), normalized.end(), '\\', '/');
    if (normalized.size() >= 2 &&
        std::isalpha(static_cast<unsigned char>(normalized[0])) &&
        normalized[1] == ':') {
        normalized.erase(0, 2);
    }
    while (!normalized.empty() && normalized.front() == '/') {
        normalized.erase(normalized.begin());
    }
    std::stringstream stream(normalized);
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty() || part == ".") {
            continue;
        }
        if (part == "..") {
            components.clear();
            return false;
        }
        components.push_back(part);
    }
    return !components.empty();
}

bool LoadFile(const std::string &path, std::vector<uint8_t> &data,
              std::string &error)
{
    data.clear();
    std::error_code ec;
    const uint64_t size = fs::file_size(fs::path(path), ec);
    if (ec) {
        error = "Unable to determine replacement file size: " + path;
        return false;
    }
    if (size > kMaxReplacementSize || size > SIZE_MAX) {
        error = "Replacement file exceeds the 1 GiB File Replace safety limit: " + path;
        return false;
    }
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        error = "Unable to open replacement file: " + path;
        return false;
    }
    data.resize(static_cast<size_t>(size));
    if (!data.empty()) {
        input.read(reinterpret_cast<char *>(data.data()),
                   static_cast<std::streamsize>(data.size()));
        if (!input || static_cast<size_t>(input.gcount()) != data.size()) {
            error = "Unable to read complete replacement file: " + path;
            data.clear();
            return false;
        }
    }
    // Detect a host file growing while it was loaded. Published payloads are
    // immutable copies and never reopen a host file during guest reads.
    if (input.peek() != std::char_traits<char>::eof()) {
        error = "Replacement file changed size during validation: " + path;
        data.clear(); return false;
    }
    return true;
}

struct DiscReader {
    XemuDiscBlockHandle disc = nullptr;
    uintptr_t identity = 0;
    uint64_t length = 0;

    bool Read(uint64_t offset, void *buffer, size_t size) const
    {
        if (!disc || !buffer || size > UINT64_MAX - offset ||
            offset + size > length ||
            xemu_disc_block_identity(disc) != identity) {
            return false;
        }
        return xemu_disc_block_pread(disc, offset, buffer, size);
    }
};


} // namespace

Manager file_replace_manager;

void Manager::ObserveCurrentGame()
{
    const auto &game = current_game_manager.Get();
    if (!game.valid || game.header_sha256.empty()) {
        return;
    }

    const std::string game_id =
        Upper(CurrentGameManager::FormatDatabaseGameId(game.title_id));
    const std::string identity = Upper(game.header_sha256);
    const std::string key = game_id + "|" + identity;

    const auto active = ActiveDiscOverlay();
    // A running guest may have cached a relocated file sector. Do not revoke
    // a virtual disc layout during an XBE transition on the same medium. It
    // remains pinned until the next successful reset activation or disc change.
    const bool retained_virtual_layout = active && active->RequiresReset() &&
                                         active->game_identity != identity;
    if (retained_virtual_layout) {
        // Keep the owning manifest too: its Original / Retail option must
        // remain usable even when a replaced XBE has a different identity.
        m_runtime_status = "Virtual DVD layout and its owning manifest retained across "
                           "executable transition. Select Original / Retail and Reset to clear.";
        return;
    }
    if (active && active->game_identity != identity) {
        ClearActive("Active File Replace overlay was cleared because the running executable changed.");
    }

    if (key == m_game_key) {
        return;
    }

    m_game_key = key;
    m_game_id = game_id;
    m_game_name = game.title_name;
    m_game_identity = identity;
    m_root_directory = JoinPath(JoinPath(ExecutableDirectory(), "Cheats"),
                                "File-Replacements");
    const std::string game_dir = JoinPath(m_root_directory, m_game_id);
    m_manifest_path = JoinPath(game_dir, "file-replace.json");
    m_version_directory = JoinPath(JoinPath(game_dir, "Files"), m_game_identity);
    m_runtime_status.clear();

    ReloadManifest(false);
}

bool Manager::ReloadManifest(bool preserve_selection)
{
    std::unordered_map<std::string, bool> old_selected;
    std::unordered_map<std::string, bool> old_active;
    if (preserve_selection) {
        for (const auto &group : m_groups) {
            for (const auto &option : group.options) {
                const std::string key = group.id + "\x1F" + option.id;
                old_selected[key] = option.selected;
                old_active[key] = option.active;
            }
        }
    }

    m_entries.clear();
    m_groups.clear();
    m_manifest_version = 0;
    m_manifest_loaded = false;
    m_manifest_status.clear();
    m_version_folder_exists = false;

    if (m_game_id.empty() || m_game_identity.empty()) {
        m_manifest_status = "No running game identity is available yet.";
        return false;
    }

    std::error_code ec;
    m_version_folder_exists = fs::is_directory(fs::path(m_version_directory), ec) && !ec;

    std::ifstream input(m_manifest_path);
    if (!input) {
        m_manifest_status = "No File Replace manifest for this Game ID: " + m_manifest_path;
        return false;
    }

    json root;
    try {
        input >> root;
    } catch (const std::exception &e) {
        m_manifest_status = std::string("Manifest JSON error: ") + e.what();
        return false;
    }
    if (!root.is_object()) {
        m_manifest_status = "File Replace manifest root must be a JSON object.";
        return false;
    }

    const auto version_it = root.find("version");
    if (version_it == root.end() || !version_it->is_number_integer()) {
        m_manifest_status = "File Replace requires integer manifest version 3.";
        return false;
    }
    if (*version_it != 3) {
        m_manifest_status = "Unsupported manifest version; v3.16 accepts version 3 only.";
        return false;
    }
    m_manifest_version = 3;

    const auto game_it = root.find("game");
    std::string manifest_game_id;
    if (game_it == root.end() || !game_it->is_object() ||
        !GetString(*game_it, "game_id", manifest_game_id)) {
        m_manifest_status = "Manifest requires game.game_id.";
        return false;
    }
    manifest_game_id = Upper(manifest_game_id);
    if (manifest_game_id != m_game_id) {
        m_manifest_status = "Manifest Game ID " + manifest_game_id +
                            " does not match current game " + m_game_id + ".";
        return false;
    }

    const auto replacements_it = root.find("replacements");
    if (replacements_it == root.end() || !replacements_it->is_array()) {
        m_manifest_status = "Manifest requires a replacements array.";
        return false;
    }

    std::unordered_map<std::string, size_t> entry_index_by_id;
    for (const auto &item : *replacements_it) {
        if (!item.is_object()) {
            m_manifest_status = "Each File Replace entry must be a JSON object.";
            m_entries.clear();
            return false;
        }

        ReplacementEntry entry;
        if (!GetString(item, "id", entry.id) || entry.id.empty() ||
            !GetString(item, "name", entry.name) || entry.name.empty()) {
            m_manifest_status = "Every replacement requires non-empty id and name.";
            m_entries.clear();
            return false;
        }
        if (entry_index_by_id.find(entry.id) != entry_index_by_id.end()) {
            m_manifest_status = "Duplicate File Replace id: " + entry.id;
            m_entries.clear();
            return false;
        }

        GetString(item, "description", entry.description);
        GetString(item, "author", entry.author);
        if (!GetBool(item, "requires_reset", true, entry.requires_reset)) {
            m_manifest_status = "requires_reset must be true/false for " + entry.id + ".";
            m_entries.clear();
            return false;
        }
        if (!entry.requires_reset) {
            m_manifest_status = "File Replace currently requires requires_reset=true (entry " +
                                entry.id + ").";
            m_entries.clear();
            return false;
        }

        if (!item.contains("size_change") ||
            !GetBool(item, "size_change", false, entry.size_change)) {
            m_manifest_status = "Manifest v3 requires boolean size_change for " + entry.id;
            m_entries.clear(); return false;
        }
        if (item.contains("fix_size") &&
            (!GetString(item, "fix_size", entry.fix_size) || entry.fix_size.empty() ||
             !FindKnownSizeFixer(entry.fix_size))) {
            m_manifest_status = "Unknown/invalid Known File Size Fixer for " + entry.id;
            m_entries.clear(); return false;
        }
        const auto source_it = item.find("source");
        if (source_it == item.end() || !source_it->is_object()) {
            m_manifest_status = "Replacement " + entry.id + " requires source object.";
            m_entries.clear();
            return false;
        }
        std::string source_type;
        if (!GetString(*source_it, "type", source_type) ||
            !GetString(*source_it, "file", entry.disc_file)) {
            m_manifest_status = "Replacement " + entry.id +
                                " requires source.type and source.file.";
            m_entries.clear();
            return false;
        }
        if (source_type == "disc_range") {
            entry.source_type = SourceType::DiscRange;
            if (!GetUnsigned(*source_it, "offset", entry.file_offset) ||
                !GetUnsigned(*source_it, "size", entry.reserved_size) ||
                (!entry.size_change && entry.reserved_size == 0)) {
                m_manifest_status = "disc_range " + entry.id +
                                    " requires valid offset/size (Fixed Range size must be nonzero).";
                m_entries.clear();
                return false;
            }
        } else if (source_type == "file") {
            entry.source_type = SourceType::WholeFile;
            if (source_it->contains("offset") || source_it->contains("size")) {
                m_manifest_status = "Whole File source must omit offset/size: " + entry.id;
                m_entries.clear(); return false;
            }
            entry.file_offset = 0;
            entry.reserved_size = 0;
        } else {
            m_manifest_status = "Unsupported source.type for " + entry.id + ": " + source_type;
            m_entries.clear();
            return false;
        }

        if ((entry.source_type == SourceType::WholeFile && !entry.size_change) ||
            (!entry.fix_size.empty() && (!entry.size_change || entry.source_type != SourceType::DiscRange))) {
            m_manifest_status = "Whole File requires size_change=true; fix_size requires Resizable Range: " + entry.id;
            m_entries.clear(); return false;
        }
        const auto replacement_it = item.find("replacement");
        std::string padding;
        if (replacement_it == item.end() || !replacement_it->is_object() ||
            !GetString(*replacement_it, "file", entry.replacement_file)) {
            m_manifest_status = "Replacement " + entry.id +
                                " requires replacement.file.";
            m_entries.clear();
            return false;
        }
        if (replacement_it->contains("padding") && entry.size_change) {
            m_manifest_status = "padding applies only to Fixed Range: " + entry.id;
            m_entries.clear(); return false;
        }
        if (replacement_it->contains("padding") && !GetString(*replacement_it, "padding", padding)) {
            m_manifest_status = "padding must be original/zero for " + entry.id;
            m_entries.clear(); return false;
        }
        if (padding.empty()) padding = "original";
        if (padding == "zero") {
            entry.padding = PaddingMode::Zero;
        } else if (padding == "original") {
            entry.padding = PaddingMode::Original;
        } else {
            m_manifest_status = "Unsupported padding for " + entry.id + ": " + padding;
            m_entries.clear();
            return false;
        }

        fs::path replacement_relative;
        if (!SafeRelativeHostPath(entry.replacement_file, replacement_relative)) {
            m_manifest_status = "replacement.file must be a safe relative path for " + entry.id + ".";
            m_entries.clear();
            return false;
        }
        entry.replacement_file = replacement_relative.generic_string();

        entry_index_by_id[entry.id] = m_entries.size();
        m_entries.push_back(std::move(entry));
    }

    {
        const auto groups_it = root.find("groups");
        if (groups_it == root.end() || !groups_it->is_array()) {
            m_manifest_status = "Manifest version 3 requires a groups array.";
            m_entries.clear();
            return false;
        }

        std::unordered_set<std::string> seen_group_ids;
        std::vector<unsigned> reference_counts(m_entries.size(), 0);
        for (const auto &group_item : *groups_it) {
            if (!group_item.is_object()) {
                m_manifest_status = "Each File Replace group must be a JSON object.";
                m_entries.clear();
                m_groups.clear();
                return false;
            }

            ReplacementGroup group;
            std::string selection;
            if (!GetString(group_item, "id", group.id) || group.id.empty() ||
                !GetString(group_item, "name", group.name) || group.name.empty() ||
                !GetString(group_item, "selection", selection)) {
                m_manifest_status = "Every group requires non-empty id, name and selection.";
                m_entries.clear();
                m_groups.clear();
                return false;
            }
            if (!seen_group_ids.insert(group.id).second) {
                m_manifest_status = "Duplicate File Replace group id: " + group.id;
                m_entries.clear();
                m_groups.clear();
                return false;
            }
            if (selection == "single") {
                group.selection = GroupSelection::Single;
            } else if (selection == "multiple") {
                group.selection = GroupSelection::Multiple;
            } else {
                m_manifest_status = "Unsupported group selection for " + group.id + ": " + selection;
                m_entries.clear();
                m_groups.clear();
                return false;
            }

            bool show_original = group.selection == GroupSelection::Single;
            if (!GetBool(group_item, "show_original", show_original, show_original)) {
                m_manifest_status = "show_original must be true/false for group " + group.id + ".";
                m_entries.clear();
                m_groups.clear();
                return false;
            }
            if (show_original && group.selection == GroupSelection::Single) {
                ReplacementOption original;
                original.id = "__original";
                original.name = "Original / Retail";
                GetString(group_item, "original_name", original.name);
                const std::string key = group.id + "\x1F" + original.id;
                if (preserve_selection) {
                    const auto selected_it = old_selected.find(key);
                    const auto active_it = old_active.find(key);
                    original.selected = selected_it != old_selected.end() && selected_it->second;
                    original.active = active_it != old_active.end() && active_it->second;
                } else {
                    original.selected = true;
                    original.active = true;
                }
                group.options.push_back(std::move(original));
            }

            const auto options_it = group_item.find("options");
            if (options_it == group_item.end() || !options_it->is_array()) {
                m_manifest_status = "Group " + group.id + " requires an options array.";
                m_entries.clear();
                m_groups.clear();
                return false;
            }

            std::unordered_set<std::string> seen_option_ids;
            seen_option_ids.insert("__original");
            for (const auto &option_item : *options_it) {
                if (!option_item.is_object()) {
                    m_manifest_status = "Each option in group " + group.id + " must be an object.";
                    m_entries.clear();
                    m_groups.clear();
                    return false;
                }
                ReplacementOption option;
                if (!GetString(option_item, "id", option.id) || option.id.empty() ||
                    !GetString(option_item, "name", option.name) || option.name.empty()) {
                    m_manifest_status = "Every option in group " + group.id +
                                        " requires non-empty id and name.";
                    m_entries.clear();
                    m_groups.clear();
                    return false;
                }
                if (!seen_option_ids.insert(option.id).second) {
                    m_manifest_status = "Duplicate option id in group " + group.id + ": " + option.id;
                    m_entries.clear();
                    m_groups.clear();
                    return false;
                }
                GetString(option_item, "description", option.description);
                GetString(option_item, "author", option.author);

                const auto refs_it = option_item.find("replacements");
                if (refs_it == option_item.end() || !refs_it->is_array() || refs_it->empty()) {
                    m_manifest_status = "Option " + group.id + "/" + option.id +
                                        " requires at least one replacement id.";
                    m_entries.clear();
                    m_groups.clear();
                    return false;
                }
                std::unordered_set<std::string> seen_refs;
                for (const auto &ref : *refs_it) {
                    if (!ref.is_string()) {
                        m_manifest_status = "Replacement references for " + group.id + "/" +
                                            option.id + " must be strings.";
                        m_entries.clear();
                        m_groups.clear();
                        return false;
                    }
                    const std::string replacement_id = ref.get<std::string>();
                    const auto found = entry_index_by_id.find(replacement_id);
                    if (found == entry_index_by_id.end()) {
                        m_manifest_status = "Option " + group.id + "/" + option.id +
                                            " references unknown replacement: " + replacement_id;
                        m_entries.clear();
                        m_groups.clear();
                        return false;
                    }
                    if (!seen_refs.insert(replacement_id).second) {
                        continue;
                    }
                    option.replacement_ids.push_back(replacement_id);
                    option.replacement_indices.push_back(found->second);
                    ++reference_counts[found->second];
                }

                const std::string key = group.id + "\x1F" + option.id;
                if (preserve_selection) {
                    option.selected = old_selected[key];
                    option.active = old_active[key];
                }
                group.options.push_back(std::move(option));
            }

            if (group.options.empty()) {
                m_manifest_status = "Group " + group.id + " has no choices.";
                m_entries.clear();
                m_groups.clear();
                return false;
            }

            if (group.selection == GroupSelection::Single) {
                bool selected_seen = false;
                bool active_seen = false;
                ReplacementOption *retail = nullptr;
                for (auto &option : group.options) {
                    if (!retail && option.replacement_indices.empty()) {
                        retail = &option;
                    }
                    if (option.selected) {
                        if (selected_seen) {
                            option.selected = false;
                        } else {
                            selected_seen = true;
                        }
                    }
                    if (option.active) {
                        if (active_seen) {
                            option.active = false;
                        } else {
                            active_seen = true;
                        }
                    }
                }
                if (!selected_seen && retail) {
                    retail->selected = true;
                }
                if (!active_seen && retail && !ActiveDiscOverlay()) {
                    retail->active = true;
                }
            }
            m_groups.push_back(std::move(group));
        }

        for (size_t i = 0; i < reference_counts.size(); ++i) {
            if (reference_counts[i] == 0) {
                m_manifest_status = "Replacement " + m_entries[i].id +
                                    " is not referenced by any version 3 option.";
                m_entries.clear();
                m_groups.clear();
                return false;
            }
        }
    }

    SyncEntryStateFromOptions();
    m_manifest_loaded = true;
    m_manifest_status = m_version_folder_exists
                            ? "Manifest loaded for exact executable identity."
                            : "Manifest loaded, but no replacement folder exists for this exact executable identity.";

    std::string resolve_error;
    ResolveEntries(false, resolve_error);
    if (!resolve_error.empty()) {
        m_manifest_status += " " + resolve_error;
    }
    return true;
}

bool Manager::ResolveEntries(bool, std::string &error)
{
    error.clear();
    if (!m_manifest_loaded) {
        return false;
    }

    XemuDiscBlockRef disc("ide0-cd1");
    if (!disc || !xemu_disc_block_is_available(disc.Get())) {
        error = "Xbox DVD (ide0-cd1) is not available.";
        for (auto &entry : m_entries) {
            entry.resolved = false;
            entry.status = error;
        }
        return false;
    }
    const int64_t signed_length = xemu_disc_block_get_length(disc.Get());
    if (signed_length <= 0) {
        error = "Unable to determine mounted DVD size.";
        return false;
    }

    DiscReader reader;
    reader.disc = disc.Get();
    reader.identity = xemu_disc_block_identity(disc.Get());
    reader.length = static_cast<uint64_t>(signed_length);

    XemuXdvdfs::Disc xdvdfs;
    std::string parse_error;
    if (!XemuXdvdfs::Parse(
            [&reader](uint64_t offset, void *buffer, size_t size) {
                return reader.Read(offset, buffer, size);
            },
            reader.length, xdvdfs, parse_error)) {
        error = parse_error.empty() ? "Unable to parse mounted XDVDFS disc." : parse_error;
        for (auto &entry : m_entries) {
            entry.resolved = false;
            entry.status = error;
        }
        return false;
    }

    m_disc_identity = reader.identity;
    m_disc_length = reader.length;
    std::error_code ec;
    m_version_folder_exists = fs::is_directory(fs::path(m_version_directory), ec) && !ec;

    for (auto &entry : m_entries) {
        entry.resolved = false;
        entry.disc_start = 0;
        entry.disc_file_size = 0;
        entry.host_size = 0;
        entry.host_path.clear();
        entry.status.clear();

        std::vector<std::string> components;
        if (!DiscPathComponents(entry.disc_file, components)) {
            entry.status = "Invalid XDVDFS source path.";
            continue;
        }
        const XemuXdvdfs::Entry *disc_entry = XemuXdvdfs::FindEntry(xdvdfs, components);
        if (!disc_entry || disc_entry->IsDirectory()) {
            entry.status = "Disc file was not found in XDVDFS.";
            continue;
        }
        entry.disc_file_size = disc_entry->size;
        entry.directory_entry = disc_entry->directory_entry_offset;
        entry.filesystem_base = xdvdfs.filesystem_base;
        if (entry.source_type == SourceType::WholeFile) {
            entry.file_offset = 0;
            entry.reserved_size = disc_entry->size;
        }
        if (!entry.size_change && entry.reserved_size == 0) {
            entry.status = "Resolved disc replacement range has zero size.";
            continue;
        }
        if (entry.file_offset > disc_entry->size ||
            entry.reserved_size > static_cast<uint64_t>(disc_entry->size) - entry.file_offset) {
            entry.status = "Requested range exceeds the original disc file.";
            continue;
        }
        if (entry.file_offset > UINT64_MAX - disc_entry->disc_offset) {
            entry.status = "Disc range address overflows.";
            continue;
        }
        entry.disc_start = disc_entry->disc_offset + entry.file_offset;
        if (entry.reserved_size > reader.length - std::min(reader.length, entry.disc_start)) {
            entry.status = "Resolved range exceeds the mounted DVD image.";
            continue;
        }

        fs::path relative;
        if (!SafeRelativeHostPath(entry.replacement_file, relative)) {
            entry.status = "Replacement path is unsafe.";
            continue;
        }
        entry.host_path = (fs::path(m_version_directory) / relative).string();
        ec.clear();
        if (!fs::is_regular_file(fs::path(entry.host_path), ec) || ec) {
            entry.status = "Replacement file is missing for this executable identity.";
            entry.resolved = true;
            continue;
        }
        entry.host_size = fs::file_size(fs::path(entry.host_path), ec);
        if (ec) {
            entry.status = "Unable to determine replacement file size.";
            entry.host_size = 0;
            entry.resolved = true;
            continue;
        }
        if (!entry.size_change && entry.host_size > entry.reserved_size) {
            entry.status = "Replacement exceeds the reserved disc range.";
            entry.resolved = true;
            continue;
        }
        if (entry.host_size > kMaxReplacementSize) {
            entry.status = "Replacement exceeds the 1 GiB host payload limit.";
            entry.resolved = true; continue;
        }
        entry.resolved = true;
        entry.status = "READY";
    }
    return true;
}

bool Manager::BuildAndInstall(bool use_selected_state, bool update_active_state,
                              std::string &error)
{
    error.clear();
    if (!m_manifest_loaded) {
        error = "No valid File Replace manifest is loaded.";
        return false;
    }
    std::string resolve_error;
    if (!ResolveEntries(true, resolve_error)) {
        error = resolve_error;
        return false;
    }

    auto snapshot = std::make_shared<OverlaySnapshot>();
    snapshot->disc_identity = m_disc_identity;
    snapshot->game_identity = m_game_identity;

    const std::vector<size_t> desired_indices = DesiredEntryIndices(use_selected_state);
    if (desired_indices.empty()) {
        ClearDiscOverlay();
        if (update_active_state) {
            ApplySelectedToActive();
        }
        SyncEntryStateFromOptions();
        m_runtime_status = "Retail disc data is active; no replacement ranges are armed.";
        return true;
    }

    std::vector<CompileFile> files;
    uint64_t payload_total = 0;
    for (size_t index : desired_indices) {
        ReplacementEntry &entry = m_entries[index];
        if (!entry.resolved || entry.status != "READY") {
            error = entry.name + ": " + (entry.status.empty() ? "entry is not ready." : entry.status);
            return false;
        }
        auto bytes = std::make_shared<Bytes>();
        if (!LoadFile(entry.host_path, *bytes, error)) return false;
        if (bytes->size() > kMaxReplacementSize - std::min(kMaxReplacementSize, payload_total)) {
            error = "Combined replacement payload exceeds the 1 GiB safety limit.";
            return false;
        }
        payload_total += bytes->size();
        auto found = std::find_if(files.begin(), files.end(), [&](const CompileFile &f) {
            return f.directory_entry == entry.directory_entry;
        });
        if (found == files.end()) {
            CompileFile target;
            target.name = entry.disc_file;
            target.disc_start = entry.disc_start - entry.file_offset;
            target.size = entry.disc_file_size;
            target.directory_entry = entry.directory_entry;
            target.filesystem_base = entry.filesystem_base;
            files.push_back(std::move(target));
            found = files.end() - 1;
        }
        found->operations.push_back({entry.id, entry.file_offset, entry.reserved_size,
                                     entry.source_type == SourceType::WholeFile, entry.size_change,
                                     entry.padding, entry.fix_size, bytes});
    }
    // Hold the original backend while planning. All validation reads bypass the
    // active overlay; publication happens only after a final identity check.
    XemuDiscBlockRef disc("ide0-cd1");
    if (!disc || xemu_disc_block_identity(disc.Get()) != m_disc_identity) {
        error = "Mounted DVD changed during validation."; return false;
    }
    DiscReader reader{disc.Get(), m_disc_identity, m_disc_length};
    if (!CompileOverlay([&](uint64_t off, void *buf, size_t n) { return reader.Read(off, buf, n); },
                        m_disc_length, files, *snapshot, error)) return false;
    if (!xemu_disc_block_is_available(disc.Get()) ||
        xemu_disc_block_identity(disc.Get()) != m_disc_identity ||
        xemu_disc_block_get_length(disc.Get()) != static_cast<int64_t>(m_disc_length)) {
        error = "Mounted DVD changed before activation."; return false;
    }

    InstallDiscOverlay(snapshot);
    if (update_active_state) {
        ApplySelectedToActive();
    }
    SyncEntryStateFromOptions();
    m_runtime_status = "ACTIVE: " + std::to_string(snapshot->ranges.size()) + " fixed/metadata range(s), " +
                       std::to_string(snapshot->files.size()) + " virtual file(s) armed for this executable/disc.";
    return true;
}

bool Manager::ReloadActive(std::string &error)
{
    const auto active = ActiveDiscOverlay();
    if (active && active->RequiresReset()) {
        error = "Whole File/Resizable Range overlays require Reset; live reload is disabled.";
        return false;
    }
    for (size_t i : DesiredEntryIndices(false)) if (m_entries[i].size_change) {
        error = "The manifest now includes a size-changing mode; Reset is required.";
        return false;
    }
    try { return BuildAndInstall(false, false, error); }
    catch (const std::exception &e) { error = e.what(); return false; }
}

void Manager::NotifyGameResetRequested()
{
    ObserveCurrentGame();
    if (m_game_id.empty() || m_game_identity.empty()) {
        ClearActive("File Replace was not armed: no current executable identity.");
        return;
    }
    std::string error;
    bool ok = false;
    try { ok = BuildAndInstall(true, true, error); }
    catch (const std::exception &e) { error = e.what(); }
    if (!ok) {
        // Keep the last complete active snapshot. Never publish part of a set,
        // nor silently drop its old virtual layout on a validation failure.
        m_runtime_status = "File Replace arm failed (previous snapshot preserved): " + error;
    }
}

void Manager::RequestManifestReload()
{
    m_manifest_reload_requested = true;
}

void Manager::Tick()
{
    ObserveCurrentGame();
    if (m_manifest_reload_requested) {
        m_manifest_reload_requested = false;
        ReloadManifest(true);
    }

    const auto active = ActiveDiscOverlay();
    if (!active) {
        return;
    }
    XemuDiscBlockRef disc("ide0-cd1");
    if (!disc || !xemu_disc_block_is_available(disc.Get()) ||
        xemu_disc_block_identity(disc.Get()) != active->disc_identity) {
        ClearActive("Active File Replace overlay was cleared because the mounted DVD changed.");
    }
}

void Manager::Shutdown()
{
    ClearDiscOverlay();
    m_entries.clear();
    m_groups.clear();
    m_game_key.clear();
    m_game_id.clear();
    m_game_name.clear();
    m_game_identity.clear();
    m_manifest_loaded = false;
    m_manifest_reload_requested = false;
    m_information_window_open = false;
    m_information_group_id.clear();
    m_information_option_id.clear();
}

void Manager::ClearActive(const std::string &reason)
{
    ClearDiscOverlay();
    for (auto &group : m_groups) {
        bool retail_set = false;
        for (auto &option : group.options) {
            option.active = false;
            if (!retail_set && group.selection == GroupSelection::Single &&
                option.replacement_indices.empty()) {
                option.active = true;
                retail_set = true;
            }
        }
    }
    SyncEntryStateFromOptions();
    if (!reason.empty()) {
        m_runtime_status = reason;
    }
}

bool Manager::SelectionDiffersFromActive() const
{
    const auto active = ActiveDiscOverlay();
    if (active && active->RequiresReset() && active->game_identity != m_game_identity) return true;
    for (const auto &group : m_groups) {
        for (const auto &option : group.options) {
            if (option.selected != option.active) {
                return true;
            }
        }
    }
    return false;
}

bool Manager::HasResetRequired() const
{
    return SelectionDiffersFromActive();
}

std::vector<size_t> Manager::DesiredEntryIndices(bool use_selected_state) const
{
    std::vector<bool> wanted(m_entries.size(), false);
    for (const auto &group : m_groups) {
        for (const auto &option : group.options) {
            const bool desired = use_selected_state ? option.selected : option.active;
            if (!desired) {
                continue;
            }
            for (size_t index : option.replacement_indices) {
                if (index < wanted.size()) {
                    wanted[index] = true;
                }
            }
        }
    }

    std::vector<size_t> result;
    for (size_t i = 0; i < wanted.size(); ++i) {
        if (wanted[i]) {
            result.push_back(i);
        }
    }
    return result;
}

void Manager::SyncEntryStateFromOptions()
{
    for (auto &entry : m_entries) {
        entry.selected = false;
        entry.active = false;
    }
    for (const auto &group : m_groups) {
        for (const auto &option : group.options) {
            for (size_t index : option.replacement_indices) {
                if (index >= m_entries.size()) {
                    continue;
                }
                if (option.selected) {
                    m_entries[index].selected = true;
                }
                if (option.active) {
                    m_entries[index].active = true;
                }
            }
        }
    }
}

void Manager::ApplySelectedToActive()
{
    for (auto &group : m_groups) {
        for (auto &option : group.options) {
            option.active = option.selected;
        }
    }
}

std::string Manager::OptionDependencyStatus(const ReplacementOption &option) const
{
    if (option.replacement_indices.empty()) {
        return "READY";
    }
    if (!m_version_folder_exists) {
        return "UNAVAILABLE";
    }
    for (size_t index : option.replacement_indices) {
        if (index >= m_entries.size() || m_entries[index].status != "READY") {
            return "ERROR";
        }
    }
    return "READY";
}

std::string Manager::OptionStatus(const ReplacementOption &option) const
{
    if (option.active) {
        return "ACTIVE";
    }
    const std::string dependency = OptionDependencyStatus(option);
    if (dependency != "READY") {
        return dependency;
    }
    if (option.selected != option.active) {
        return "NEEDS RESET";
    }
    return "READY";
}

std::string Manager::OptionCredits(const ReplacementOption &option) const
{
    if (!option.author.empty()) {
        return option.author;
    }
    std::vector<std::string> authors;
    for (size_t index : option.replacement_indices) {
        if (index >= m_entries.size() || m_entries[index].author.empty()) {
            continue;
        }
        if (std::find(authors.begin(), authors.end(), m_entries[index].author) ==
            authors.end()) {
            authors.push_back(m_entries[index].author);
        }
    }
    std::string result;
    for (const auto &author : authors) {
        if (!result.empty()) {
            result += " / ";
        }
        result += author;
    }
    return result;
}

void Manager::AppendActiveRecordingDetails(std::vector<std::string> &names,
                                           std::vector<std::string> &credits,
                                           std::vector<std::string> &groups) const
{
    for (const auto &group : m_groups) {
        for (const auto &option : group.options) {
            if (!option.active || option.replacement_indices.empty()) {
                continue;
            }
            names.push_back(option.name);
            credits.push_back(OptionCredits(option));
            groups.push_back(group.name);
        }
    }
}

bool Manager::OpenVersionFolder(std::string &error)
{
    error.clear();
    if (m_version_directory.empty()) {
        error = "No current executable identity folder is available.";
        return false;
    }
    std::error_code ec;
    fs::create_directories(fs::path(m_version_directory), ec);
    if (ec) {
        error = "Unable to create File Replace folder: " + ec.message();
        return false;
    }
    m_version_folder_exists = true;

    GError *uri_error = nullptr;
    gchar *absolute = g_canonicalize_filename(m_version_directory.c_str(), nullptr);
    gchar *uri = absolute ? g_filename_to_uri(absolute, nullptr, &uri_error) : nullptr;
    const bool ok = uri != nullptr && SDL_OpenURL(uri);
    if (!ok) {
        error = "Unable to open File Replace folder: ";
        error += uri_error ? uri_error->message : SDL_GetError();
    }
    if (uri_error) {
        g_error_free(uri_error);
    }
    g_free(uri);
    g_free(absolute);
    return ok;
}

} // namespace XemuFileReplace
