// QEMU C bridge. This header must not be included from C++ frontend sources.
#pragma once
#include "system/block-backend-io.h"

#ifdef __cplusplus
extern "C" {
#endif

int xemu_file_replace_pread(BlockBackend *blk, int64_t offset, int64_t size,
                            void *buffer, BdrvRequestFlags flags);
BlockAIOCB *xemu_file_replace_aio_preadv(BlockBackend *blk, int64_t offset,
                                        QEMUIOVector *qiov, BdrvRequestFlags flags,
                                        BlockCompletionFunc *cb, void *opaque);

#ifdef __cplusplus
}
#endif
