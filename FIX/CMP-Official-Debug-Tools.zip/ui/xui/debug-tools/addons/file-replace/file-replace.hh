//
// Generic game/version-scoped DVD File Replace manager.
//
#pragma once

#include "file-replace-disc-overlay.hh"

#include <cstdint>
#include <string>
#include <vector>

namespace XemuFileReplace {

enum class SourceType {
    DiscRange,
    WholeFile,
};

enum class GroupSelection {
    Single,
    Multiple,
};

struct ReplacementEntry {
    std::string id;
    std::string name;
    std::string description;
    std::string author;
    SourceType source_type = SourceType::DiscRange;
    std::string disc_file;
    uint64_t file_offset = 0;
    uint64_t reserved_size = 0;
    std::string replacement_file;
    PaddingMode padding = PaddingMode::Original;
    bool requires_reset = true;
    bool size_change = false;
    std::string fix_size;

    bool selected = false;
    bool active = false;
    bool resolved = false;
    uint64_t disc_start = 0;
    uint64_t disc_file_size = 0;
    uint64_t directory_entry = 0;
    uint64_t filesystem_base = 0;
    uint64_t host_size = 0;
    std::string host_path;
    std::string status;
};

struct ReplacementOption {
    std::string id;
    std::string name;
    std::string description;
    std::string author;
    std::vector<std::string> replacement_ids;
    std::vector<size_t> replacement_indices;
    bool selected = false;
    bool active = false;
};

struct ReplacementGroup {
    std::string id;
    std::string name;
    GroupSelection selection = GroupSelection::Multiple;
    std::vector<ReplacementOption> options;
};

class Manager
{
public:
    void Tick();
    void NotifyGameResetRequested();
    void RequestManifestReload();
    void Shutdown();
    void DrawTab();
    void AppendActiveRecordingDetails(std::vector<std::string> &names,
                                      std::vector<std::string> &credits,
                                      std::vector<std::string> &groups) const;
    bool HasResetRequired() const;

private:
    std::string m_game_key;
    std::string m_game_id;
    std::string m_game_name;
    std::string m_game_identity;
    std::string m_root_directory;
    std::string m_manifest_path;
    std::string m_version_directory;
    std::string m_manifest_status;
    std::string m_runtime_status;
    int m_manifest_version = 0;
    bool m_manifest_loaded = false;
    bool m_version_folder_exists = false;
    uintptr_t m_disc_identity = 0;
    uint64_t m_disc_length = 0;
    std::vector<ReplacementEntry> m_entries;
    std::vector<ReplacementGroup> m_groups;
    bool m_information_window_open = false;
    bool m_manifest_reload_requested = false;
    std::string m_information_group_id;
    std::string m_information_option_id;

    void ObserveCurrentGame();
    bool ReloadManifest(bool preserve_selection = true);
    bool ResolveEntries(bool require_replacement_files, std::string &error);
    bool BuildAndInstall(bool use_selected_state, bool update_active_state,
                         std::string &error);
    bool ReloadActive(std::string &error);
    bool OpenVersionFolder(std::string &error);
    void ClearActive(const std::string &reason = {});
    bool SelectionDiffersFromActive() const;
    std::vector<size_t> DesiredEntryIndices(bool use_selected_state) const;
    void SyncEntryStateFromOptions();
    void ApplySelectedToActive();
    std::string OptionDependencyStatus(const ReplacementOption &option) const;
    std::string OptionStatus(const ReplacementOption &option) const;
    std::string OptionCredits(const ReplacementOption &option) const;
};

extern Manager file_replace_manager;

} // namespace XemuFileReplace
