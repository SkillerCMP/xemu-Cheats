#include "known-size-fixers.hh"
namespace XemuFileReplace {
KnownSizeFixer FindKnownSizeFixer(const std::string &name)
{
    // Extend this table with additional validated format planners.
    static const struct { const char *name; KnownSizeFixer plan; } registry[] = {
        {"olk", PlanOlkSizeFix},
    };
    for (const auto &fixer : registry) if (name == fixer.name) return fixer.plan;
    return nullptr;
}
}
