#include "file-replace-compiler.hh"
#include <algorithm>
#include <set>

namespace XemuFileReplace {
namespace {
constexpr uint64_t Sector = 2048;
constexpr uint64_t MaxPayload = 1024ull * 1024 * 1024;
void Put32(Bytes &b, size_t at, uint32_t v)
{
    for (unsigned i = 0; i < 4; ++i) b[at+i] = uint8_t(v >> (8*i));
}
}
bool CompileOverlay(const RawReader &reader, uint64_t disc_length,
                    const std::vector<CompileFile> &files, OverlaySnapshot &out,
                    std::string &error)
{
    out.ranges.clear(); out.files.clear();
    out.raw_length = disc_length; out.effective_length = disc_length;
    uint64_t cursor, payload_total = 0;
    if (!AlignChecked(disc_length, Sector, cursor) || cursor / Sector > INT32_MAX) {
        error = "Disc length is unsupported by the signed ATAPI LBA range."; return false;
    }
    std::set<uint64_t> file_records;
    for (const auto &file : files) {
        if (file.size > UINT32_MAX || file.disc_start > disc_length ||
            file.size > disc_length - file.disc_start || file.directory_entry > disc_length ||
            14 > disc_length - file.directory_entry || !file_records.insert(file.directory_entry).second) {
            error = "Invalid or duplicate XDVDFS source file: " + file.name; return false;
        }
        bool virtualize = false, whole = false;
        std::string fixer;
        std::vector<const CompileOperation *> sorted;
        for (const auto &op : file.operations) {
            if (!op.bytes || op.bytes->size() > MaxPayload - std::min(MaxPayload, payload_total)) {
                error = "Combined replacement payload exceeds the 1 GiB safety limit."; return false;
            }
            payload_total += op.bytes->size();
            if (op.offset > file.size || op.size > file.size - op.offset ||
                (!op.size_change && op.bytes->size() > op.size) ||
                (op.whole_file && (!op.size_change || op.offset || op.size != file.size))) {
                error = "Invalid source extent/replacement size: " + op.id; return false;
            }
            if (!op.fix_size.empty()) {
                if (!op.size_change || op.whole_file || !FindKnownSizeFixer(op.fix_size) ||
                    (!fixer.empty() && fixer != op.fix_size)) {
                    error = "Invalid/incompatible Known File Size Fixer: " + op.id; return false;
                }
                fixer = op.fix_size;
            }
            virtualize |= op.size_change;
            whole |= op.whole_file;
            sorted.push_back(&op);
        }
        if (whole && sorted.size() != 1) {
            error = "Whole File cannot be combined with another operation on " + file.name; return false;
        }
        std::sort(sorted.begin(), sorted.end(), [](const CompileOperation *a, const CompileOperation *b) {
            return a->offset < b->offset;
        });
        for (size_t i = 1; i < sorted.size(); ++i) {
            if (sorted[i]->offset < sorted[i-1]->offset + sorted[i-1]->size ||
                sorted[i]->offset == sorted[i-1]->offset) {
                error = "Active File Replace ranges overlap: " + sorted[i-1]->id + " and " + sorted[i]->id;
                return false;
            }
        }
        if (!virtualize) {
            for (const auto *op : sorted) {
                if (!op->size) { error = "Fixed Range must reserve nonzero bytes: " + op->id; return false; }
                out.ranges.push_back({file.disc_start + op->offset, op->size,
                                      *op->bytes, op->padding, op->id});
            }
            continue;
        }
        std::vector<ImageEdit> edits;
        std::vector<SizeFixRequest> fixes;
        for (const auto *op : sorted) {
            if (!op->fix_size.empty()) {
                fixes.push_back({op->offset, op->size, op->bytes, op->id});
            } else if (op->size_change) {
                if (!fixer.empty()) {
                    error = "Cannot mix unrecognized resizes with a Known File Size Fixer in " + file.name;
                    return false;
                }
                edits.push_back({op->offset, op->size, op->bytes->size(), op->bytes, op->id});
            } else {
                uint64_t span = op->padding == PaddingMode::Zero ? op->size : op->bytes->size();
                if (span) edits.push_back({op->offset, span, span, op->bytes, op->id});
            }
        }
        RawReader relative = [&](uint64_t off, void *buf, size_t n) {
            return off <= file.size && n <= file.size - off && reader(file.disc_start + off, buf, n);
        };
        if (!fixer.empty() && !FindKnownSizeFixer(fixer)(relative, file.size, fixes, edits, error)) return false;
        VirtualFile vf;
        vf.id = file.name;
        if (!BuildFileImage(file.disc_start, file.size, edits, vf.image, error)) return false;
        if (!fixer.empty()) {
            RawReader effective = [&](uint64_t off, void *buf, size_t n) {
                return ReadFileImage(vf.image, reader, off, buf, n);
            };
            std::vector<ImageEdit> check;
            if (!FindKnownSizeFixer(fixer)(effective, vf.image.size, {}, check, error)) return false;
        }
        vf.disc_start = cursor;
        uint64_t end;
        if (cursor < file.filesystem_base || (cursor - file.filesystem_base) % Sector ||
            !AlignChecked(std::max<uint64_t>(vf.image.size, 1), Sector, vf.reserved_size) ||
            !AddChecked(cursor, vf.reserved_size, end) || end / Sector > INT32_MAX ||
            (cursor - file.filesystem_base) / Sector > UINT32_MAX) {
            error = "Virtual file allocation exceeds the supported DVD address space."; return false;
        }
        OverlayRange metadata;
        metadata.disc_start = file.directory_entry + 4;
        metadata.reserved_size = 8; metadata.padding = PaddingMode::Original;
        metadata.id = "XDVDFS sector/size: " + file.name;
        metadata.replacement.resize(8);
        Put32(metadata.replacement, 0, uint32_t((cursor - file.filesystem_base) / Sector));
        Put32(metadata.replacement, 4, uint32_t(vf.image.size));
        out.ranges.push_back(std::move(metadata));
        out.files.push_back(std::move(vf));
        cursor = end;
    }
    if (!out.files.empty()) out.effective_length = cursor;
    std::sort(out.ranges.begin(), out.ranges.end(), [](const OverlayRange &a, const OverlayRange &b) {
        return a.disc_start < b.disc_start;
    });
    for (size_t i = 0; i < out.ranges.size(); ++i) {
        const auto &r = out.ranges[i];
        if (r.disc_start > disc_length || r.reserved_size > disc_length - r.disc_start ||
            (i && r.disc_start < out.ranges[i-1].disc_start + out.ranges[i-1].reserved_size)) {
            error = "Fixed/metadata overlays overlap or exceed the original DVD."; return false;
        }
    }
    return true;
}
}
