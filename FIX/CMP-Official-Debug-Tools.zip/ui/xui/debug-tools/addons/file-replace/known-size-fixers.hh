// Registry boundary for format-specific offset/size repairs. No game IDs here.
#pragma once
#include "file-replace-image.hh"
namespace XemuFileReplace {
struct SizeFixRequest {
    uint64_t offset = 0, size = 0;
    SharedBytes replacement;
    std::string id;
};
// Reader offsets are relative to the original target file. Successful planning
// appends validated payload splices and metadata edits in ORIGINAL coordinates.
using KnownSizeFixer = bool (*)(const RawReader &, uint64_t,
                               const std::vector<SizeFixRequest> &,
                               std::vector<ImageEdit> &, std::string &);
KnownSizeFixer FindKnownSizeFixer(const std::string &name);
bool PlanOlkSizeFix(const RawReader &, uint64_t,
                    const std::vector<SizeFixRequest> &,
                    std::vector<ImageEdit> &, std::string &);
}
