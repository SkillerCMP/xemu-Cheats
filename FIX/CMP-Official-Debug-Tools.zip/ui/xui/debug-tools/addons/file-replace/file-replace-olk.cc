// Known File Size Fixer: little-endian "olnk" OLK containers (including nesting).
// Only whole existing nonempty entries are resized; this is not a PKG/VMX fixer.
#include "known-size-fixers.hh"
#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <unordered_set>

namespace XemuFileReplace {
namespace {
uint32_t U32(const uint8_t *p)
{
    return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
SharedBytes Word(uint32_t v)
{
    auto b = std::make_shared<Bytes>(4);
    for (unsigned i = 0; i < 4; ++i) (*b)[i] = uint8_t(v >> (8 * i));
    return b;
}
struct OlkEntry {
    uint64_t table, start, size, allocation;
    uint32_t relative;
};
struct OlkNode {
    uint64_t start, size, data_start;
    uint32_t alignment, data_size, declared_data_size;
    std::vector<OlkEntry> entries;
};
struct OlkParser {
    const RawReader &read;
    uint64_t file_size;
    std::string &error;
    std::vector<OlkNode> nodes;
    std::unordered_set<uint64_t> seen;
    size_t total_entries = 0;
    bool Fail(const std::string &s) { error = "OLK: " + s; return false; }
    bool Parse(uint64_t start, uint64_t size, unsigned depth)
    {
        if (depth > 16 || nodes.size() >= 4096 || !seen.insert(start).second)
            return Fail("container nesting/cycle limit exceeded.");
        if (size < 32 || start > file_size || size > file_size - start)
            return Fail("truncated container header.");
        std::array<uint8_t, 32> h{};
        if (!read(start, h.data(), h.size()) || std::memcmp(h.data() + 4, "olnk", 4))
            return Fail("expected little-endian olnk header.");
        uint32_t count = U32(h.data()), align = U32(h.data() + 8);
        uint32_t data_offset = U32(h.data() + 16), data_size = U32(h.data() + 20);
        if (count > 100000 || total_entries + count > 200000 ||
            !align || align > 0x100000 || (align & (align - 1)) ||
            U32(h.data() + 12) != 0 || U32(h.data() + 28) != 0 ||
            data_offset < 32ull + 16ull * count || data_offset % align ||
            data_offset > size || data_size > size - data_offset)
            return Fail("invalid count/alignment/data bounds or unsupported header flags.");
        total_entries += count;
        Bytes table(size_t(count) * 16);
        if (!table.empty() && !read(start + 32, table.data(), table.size()))
            return Fail("table read failed.");
        // Some shipped OLKs leave the optional payload-span word zero even
        // with live entries. Bound those entries by the containing OLK extent,
        // and preserve the zero sentinel rather than inventing a value.
        const uint32_t declared_data_size = data_size;
        if (!data_size) data_size = static_cast<uint32_t>(size - data_offset);
        OlkNode node{start, size, start + data_offset, align, data_size, declared_data_size, {}};
        uint64_t previous_end = 0;
        for (uint32_t i = 0; i < count; ++i) {
            const uint8_t *p = table.data() + size_t(i) * 16;
            uint32_t rel = U32(p), len = U32(p + 4);
            uint64_t allocation;
            if (rel % align || rel > data_size || len > data_size - rel ||
                U32(p + 12) != 0 || !AlignChecked(len, align, allocation) ||
                allocation > data_size - rel || rel < previous_end)
                return Fail("unaligned, overlapping, out-of-bounds or unsupported entry table.");
            // Empty entries may share an offset; nonempty allocations may not alias.
            previous_end = uint64_t(rel) + allocation;
            node.entries.push_back({start + 32ull + 16ull * i,
                                    node.data_start + rel, len, allocation, rel});
        }
        nodes.push_back(node);
        for (const auto &e : node.entries) {
            if (e.size < 8) continue;
            std::array<uint8_t, 8> sig{};
            if (!read(e.start, sig.data(), sig.size())) return Fail("entry signature read failed.");
            if (!std::memcmp(sig.data() + 4, "olnk", 4) && !Parse(e.start, e.size, depth + 1))
                return false;
        }
        return true;
    }
};
struct Change {
    uint64_t start, allocation, payload_size, new_allocation;
    int64_t delta;
    uint64_t table;
    const SizeFixRequest *request;
};
int64_t DeltaBefore(const std::vector<Change> &changes, uint64_t position)
{
    int64_t d = 0;
    for (const auto &c : changes) if (c.start + c.allocation <= position) d += c.delta;
    return d;
}
bool Adjust(uint64_t value, int64_t delta, uint32_t &out)
{
    const int64_t result = static_cast<int64_t>(value) + delta;
    if (result < 0 || result > UINT32_MAX) return false;
    out = static_cast<uint32_t>(result); return true;
}
}
bool PlanOlkSizeFix(const RawReader &reader, uint64_t original_size,
                    const std::vector<SizeFixRequest> &requests,
                    std::vector<ImageEdit> &edits, std::string &error)
{
    OlkParser parser{reader, original_size, error, {}, {}, 0};
    if (!parser.Parse(0, original_size, 0)) return false;
    std::vector<Change> changes;
    for (const auto &request : requests) {
        const OlkNode *owner = nullptr;
        const OlkEntry *target = nullptr;
        for (const auto &node : parser.nodes) for (const auto &entry : node.entries) {
            if (entry.start == request.offset && entry.size == request.size) {
                if (target) { error = "OLK: ambiguous target entry: " + request.id; return false; }
                owner = &node; target = &entry;
            }
        }
        if (!target || !target->size || !request.replacement) {
            error = "OLK: range must exactly match one existing nonempty table entry: " + request.id;
            return false;
        }
        // Replacing a nested OLK wholesale would require validation of its new
        // internal structure and is deliberately rejected in this first fixer.
        for (const auto &node : parser.nodes) if (node.start == target->start) {
            error = "OLK: choose a leaf entry, not a nested container: " + request.id; return false;
        }
        uint64_t allocation;
        if (!AlignChecked(request.replacement->size(), owner->alignment, allocation) || allocation > UINT32_MAX) {
            error = "OLK: resized allocation overflows."; return false;
        }
        // A zero-size leaf is valid after shrinking; preserve its old sector's
        // position and shift all later entries back by the removed allocation.
        changes.push_back({target->start, target->allocation, request.replacement->size(),
                           allocation, int64_t(allocation) - int64_t(target->allocation),
                           target->table, &request});
    }
    std::sort(changes.begin(), changes.end(), [](const Change &a, const Change &b) {
        return a.start < b.start;
    });
    for (size_t i = 1; i < changes.size(); ++i) if (changes[i].start < changes[i-1].start + changes[i-1].allocation) {
        error = "OLK: resized leaf allocations overlap."; return false;
    }
    std::vector<ImageEdit> planned;
    for (const auto &c : changes)
        planned.push_back({c.start, c.allocation, c.new_allocation, c.request->replacement, c.request->id});
    auto patch = [&](uint64_t location, uint32_t old, uint64_t value, int64_t delta) {
        uint32_t result;
        if (!Adjust(value, delta, result)) { error = "OLK: repaired metadata overflows."; return false; }
        if (result != old) planned.push_back({location, 4, 4, Word(result), "olk metadata"});
        return true;
    };
    for (const auto &node : parser.nodes) {
        int64_t contained = 0;
        for (const auto &c : changes) if (c.start >= node.data_start &&
            c.start + c.allocation <= node.data_start + node.data_size) contained += c.delta;
        if (node.declared_data_size &&
            !patch(node.start + 20, node.declared_data_size, node.declared_data_size, contained)) return false;
        for (const auto &entry : node.entries) {
            int64_t before = DeltaBefore(changes, entry.start) - DeltaBefore(changes, node.data_start);
            if (!patch(entry.table, entry.relative, entry.relative, before)) return false;
            int64_t inside = 0;
            bool replaced = false;
            for (const auto &c : changes) {
                if (c.table == entry.table) {
                    if (!patch(entry.table + 4, static_cast<uint32_t>(entry.size), c.payload_size, 0)) return false;
                    replaced = true; break;
                }
                if (c.start >= entry.start && c.start + c.allocation <= entry.start + entry.size)
                    inside += c.delta;
            }
            if (!replaced && !patch(entry.table + 4, static_cast<uint32_t>(entry.size), entry.size, inside)) return false;
        }
    }
    FileImage image;
    if (!BuildFileImage(0, original_size, planned, image, error)) return false;
    // Validate the repaired hierarchy against the planned sparse image, not
    // just arithmetic. This also catches incompatible parent/child alignments.
    RawReader effective = [&](uint64_t off, void *buf, size_t n) {
        return ReadFileImage(image, reader, off, buf, n);
    };
    OlkParser check{effective, image.size, error, {}, {}, 0};
    if (!check.Parse(0, image.size, 0)) return false;
    edits.insert(edits.end(), planned.begin(), planned.end());
    return true;
}
}
