// File Replace v3: immutable sparse file images. All offsets are bytes.
#pragma once
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace XemuFileReplace {
using Bytes = std::vector<uint8_t>;
using SharedBytes = std::shared_ptr<const Bytes>;
using RawReader = std::function<bool(uint64_t, void *, size_t)>;
enum class ExtentKind { Disc, Bytes, Zero };
struct ImageExtent {
    uint64_t start = 0, size = 0;
    ExtentKind kind = ExtentKind::Zero;
    uint64_t source = 0; // Absolute physical-disc offset, or offset into bytes.
    SharedBytes bytes;
};
struct FileImage {
    uint64_t size = 0;
    std::vector<ImageExtent> extents;
};
// A splice at an ORIGINAL file coordinate. allocation includes output padding;
// payload->size() is the logical replacement length, which may be zero.
struct ImageEdit {
    uint64_t offset = 0, erase = 0, allocation = 0;
    SharedBytes payload;
    std::string id;
};
bool AddChecked(uint64_t a, uint64_t b, uint64_t &out);
bool AlignChecked(uint64_t n, uint64_t alignment, uint64_t &out);
bool BuildFileImage(uint64_t disc_start, uint64_t original_size,
                    std::vector<ImageEdit> edits, FileImage &out, std::string &error);
bool ReadFileImage(const FileImage &image, const RawReader &reader,
                   uint64_t offset, void *buffer, size_t size);
}
