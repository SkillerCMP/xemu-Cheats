//
// File Replace immutable effective-disc snapshot.
//
#pragma once

#include "file-replace-image.hh"

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace XemuFileReplace {

enum class PaddingMode {
    Original,
    Zero,
};

struct OverlayRange {
    uint64_t disc_start = 0;
    uint64_t reserved_size = 0;
    std::vector<uint8_t> replacement;
    PaddingMode padding = PaddingMode::Original;
    std::string id;
};

struct VirtualFile {
    uint64_t disc_start = 0, reserved_size = 0;
    FileImage image;
    std::string id;
};

struct OverlaySnapshot {
    uintptr_t disc_identity = 0;
    std::string game_identity;
    std::vector<OverlayRange> ranges;
    uint64_t raw_length = 0, effective_length = 0;
    std::vector<VirtualFile> files;
    bool RequiresReset() const { return !files.empty(); }
};

struct OverlayStats {
    uint64_t read_hits = 0;
    uint64_t bytes_replaced = 0;
};

void InstallDiscOverlay(std::shared_ptr<const OverlaySnapshot> snapshot);
void ClearDiscOverlay();
std::shared_ptr<const OverlaySnapshot> ActiveDiscOverlay();
OverlayStats DiscOverlayStats();

} // namespace XemuFileReplace
