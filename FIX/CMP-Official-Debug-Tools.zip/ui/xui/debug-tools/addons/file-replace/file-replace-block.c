/* File Replace v3: physical/virtual DVD reads with immutable per-request plans.
 * Follows QEMU's blk_aio_prwv completion/in-flight convention. The IDE core
 * still owns its buffered request, orphan handling and reset cancellation.
 */
#include "qemu/osdep.h"
#include "qemu/memalign.h"
#include "qemu/coroutine.h"
#include "qemu/main-loop.h"
#include "qemu/iov.h"
#include "system/replay.h"
#include "file-replace-block.h"
#include "file-replace-disc-overlay.h"

int xemu_file_replace_pread(BlockBackend *blk, int64_t offset, int64_t size,
                            void *buffer, BdrvRequestFlags flags)
{
    XemuFileReplaceReadPlan *plan = NULL;
    uintptr_t identity = (uintptr_t)blk_bs(blk);
    int ret;
    if (offset < 0 || size < 0 || (uint64_t)size > SIZE_MAX) return -EINVAL;
    if (!size) return 0;
    ret = xemu_file_replace_plan_create(identity, offset, size, &plan);
    if (!ret) return blk_pread(blk, offset, size, buffer, flags);
    if (ret < 0) return ret;
    ret = 0;
    for (size_t i = 0; i < xemu_file_replace_plan_count(plan); ++i) {
        const XemuFileReplaceReadPiece *p = xemu_file_replace_plan_piece(plan, i);
        uint8_t *dst = (uint8_t *)buffer + p->output_offset;
        if ((uintptr_t)blk_bs(blk) != identity) { ret = -ENOMEDIUM; break; }
        if (p->kind == XEMU_FR_DISC) {
            ret = blk_pread(blk, p->disc_offset, p->size, dst, flags);
            if (ret < 0) break;
        } else if (p->kind == XEMU_FR_BYTES) memcpy(dst, p->bytes, p->size);
        else memset(dst, 0, p->size);
    }
    if (ret >= 0 && (uintptr_t)blk_bs(blk) != identity) ret = -ENOMEDIUM;
    if (ret >= 0) xemu_file_replace_plan_completed(plan);
    xemu_file_replace_plan_release(plan);
    return ret;
}

typedef struct FileReplaceAIOCB {
    BlockAIOCB common;
    BlockBackend *blk;
    uintptr_t identity;
    QEMUIOVector *qiov;
    XemuFileReplaceReadPlan *plan;
    BdrvRequestFlags flags;
    uint8_t *buffer;
    int ret;
    bool returned, done;
} FileReplaceAIOCB;

static const AIOCBInfo file_replace_aiocb_info = {
    .aiocb_size = sizeof(FileReplaceAIOCB),
};

static void file_replace_complete(void *opaque)
{
    FileReplaceAIOCB *acb = opaque;
    if (!acb->returned) return;
    if (!acb->ret) {
        qemu_iovec_from_buf(acb->qiov, 0, acb->buffer, acb->qiov->size);
        xemu_file_replace_plan_completed(acb->plan);
    }
    xemu_file_replace_plan_release(acb->plan);
    qemu_vfree(acb->buffer);
    acb->common.cb(acb->common.opaque, acb->ret);
    blk_dec_in_flight(acb->blk);
    qemu_aio_unref(acb);
}

static void coroutine_fn file_replace_read_entry(void *opaque)
{
    FileReplaceAIOCB *acb = opaque;
    acb->ret = 0;
    for (size_t i = 0; i < xemu_file_replace_plan_count(acb->plan); ++i) {
        const XemuFileReplaceReadPiece *p = xemu_file_replace_plan_piece(acb->plan, i);
        uint8_t *dst = acb->buffer + p->output_offset;
        if ((uintptr_t)blk_bs(acb->blk) != acb->identity) { acb->ret = -ENOMEDIUM; break; }
        if (p->kind == XEMU_FR_DISC) {
            acb->ret = blk_co_pread(acb->blk, p->disc_offset, p->size, dst, acb->flags);
            if (acb->ret < 0) break;
        } else if (p->kind == XEMU_FR_BYTES) memcpy(dst, p->bytes, p->size);
        else memset(dst, 0, p->size);
    }
    if (acb->ret >= 0 && (uintptr_t)blk_bs(acb->blk) != acb->identity) acb->ret = -ENOMEDIUM;
    if (acb->ret >= 0) acb->ret = 0;
    acb->done = true;
    file_replace_complete(acb);
}

BlockAIOCB *xemu_file_replace_aio_preadv(BlockBackend *blk, int64_t offset,
                                        QEMUIOVector *qiov, BdrvRequestFlags flags,
                                        BlockCompletionFunc *cb, void *opaque)
{
    XemuFileReplaceReadPlan *plan = NULL;
    FileReplaceAIOCB *acb;
    Coroutine *co;
    uintptr_t identity = (uintptr_t)blk_bs(blk);
    int ret = offset < 0 ? -EINVAL : xemu_file_replace_plan_create(identity, offset, qiov->size, &plan);
    if (offset >= 0 && !qiov->size) return blk_abort_aio_request(blk, cb, opaque, 0);
    if (!ret) return blk_aio_preadv(blk, offset, qiov, flags, cb, opaque);
    if (ret < 0) return blk_abort_aio_request(blk, cb, opaque, ret);
    uint8_t *buffer = blk_try_blockalign(blk, qiov->size);
    if (!buffer) {
        xemu_file_replace_plan_release(plan);
        return blk_abort_aio_request(blk, cb, opaque, -ENOMEM);
    }
    blk_inc_in_flight(blk);
    acb = blk_aio_get(&file_replace_aiocb_info, blk, cb, opaque);
    acb->blk = blk; acb->identity = identity; acb->qiov = qiov;
    acb->plan = plan; acb->flags = flags; acb->buffer = buffer;
    acb->returned = false; acb->done = false; acb->ret = 0;
    co = qemu_coroutine_create(file_replace_read_entry, acb);
    aio_co_enter(qemu_get_current_aio_context(), co);
    acb->returned = true;
    if (acb->done) {
        replay_bh_schedule_oneshot_event(qemu_get_current_aio_context(), file_replace_complete, acb);
    }
    return &acb->common;
}
