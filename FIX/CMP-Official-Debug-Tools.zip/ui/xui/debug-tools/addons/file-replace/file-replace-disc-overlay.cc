//
// File Replace immutable effective-disc snapshot.
//
#include "file-replace-disc-overlay.hh"
#include "file-replace-disc-overlay.h"

#include <algorithm>
#include <atomic>
#include <cstring>
#include <memory>

namespace XemuFileReplace {
namespace {

std::shared_ptr<const OverlaySnapshot> g_active_snapshot;
std::atomic<uint64_t> g_read_hits{0};
std::atomic<uint64_t> g_bytes_replaced{0};

} // namespace

void InstallDiscOverlay(std::shared_ptr<const OverlaySnapshot> snapshot)
{
    g_read_hits.store(0, std::memory_order_relaxed);
    g_bytes_replaced.store(0, std::memory_order_relaxed);
    std::atomic_store_explicit(&g_active_snapshot, std::move(snapshot),
                               std::memory_order_release);
}

void ClearDiscOverlay()
{
    InstallDiscOverlay(nullptr);
}

std::shared_ptr<const OverlaySnapshot> ActiveDiscOverlay()
{
    return std::atomic_load_explicit(&g_active_snapshot,
                                     std::memory_order_acquire);
}

OverlayStats DiscOverlayStats()
{
    OverlayStats stats;
    stats.read_hits = g_read_hits.load(std::memory_order_relaxed);
    stats.bytes_replaced = g_bytes_replaced.load(std::memory_order_relaxed);
    return stats;
}

void RecordDiscOverlayStats(size_t changed)
{
    if (changed != 0) {
        g_read_hits.fetch_add(1, std::memory_order_relaxed);
        g_bytes_replaced.fetch_add(changed, std::memory_order_relaxed);
    }
}

} // namespace XemuFileReplace

extern "C" size_t xemu_file_replace_disc_overlay_apply(
    uintptr_t disc_identity, uint64_t disc_offset, void *buffer, size_t size)
{
    if (!buffer || size == 0) {
        return 0;
    }

    const auto snapshot = XemuFileReplace::ActiveDiscOverlay();
    if (!snapshot || snapshot->disc_identity == 0 ||
        snapshot->disc_identity != disc_identity || snapshot->ranges.empty()) {
        return 0;
    }

    if (size > UINT64_MAX - disc_offset) {
        return 0;
    }
    const uint64_t read_end = disc_offset + static_cast<uint64_t>(size);
    auto *out = static_cast<uint8_t *>(buffer);
    size_t changed = 0;

    const auto &ranges = snapshot->ranges;
    auto it = std::lower_bound(
        ranges.begin(), ranges.end(), disc_offset,
        [](const XemuFileReplace::OverlayRange &range, uint64_t offset) {
            if (range.reserved_size > UINT64_MAX - range.disc_start) {
                return false;
            }
            return range.disc_start + range.reserved_size <= offset;
        });

    for (; it != ranges.end(); ++it) {
        const auto &range = *it;
        if (range.disc_start >= read_end || range.reserved_size == 0 ||
            range.reserved_size > UINT64_MAX - range.disc_start) {
            break;
        }
        const uint64_t range_end = range.disc_start + range.reserved_size;
        const uint64_t overlap_start = std::max(disc_offset, range.disc_start);
        const uint64_t overlap_end = std::min(read_end, range_end);
        if (overlap_start >= overlap_end) {
            continue;
        }

        const uint64_t rel_start = overlap_start - range.disc_start;
        const uint64_t rel_end = overlap_end - range.disc_start;
        const uint64_t replacement_end =
            std::min<uint64_t>(rel_end, range.replacement.size());

        if (rel_start < replacement_end) {
            const size_t count = static_cast<size_t>(replacement_end - rel_start);
            std::memcpy(out + static_cast<size_t>(overlap_start - disc_offset),
                        range.replacement.data() + static_cast<size_t>(rel_start),
                        count);
            changed += count;
        }

        const uint64_t pad_start =
            std::max<uint64_t>(rel_start, range.replacement.size());
        if (range.padding == XemuFileReplace::PaddingMode::Zero &&
            pad_start < rel_end) {
            const size_t count = static_cast<size_t>(rel_end - pad_start);
            const uint64_t absolute_pad_start = range.disc_start + pad_start;
            std::memset(out + static_cast<size_t>(absolute_pad_start - disc_offset),
                        0, count);
            changed += count;
        }
    }

    XemuFileReplace::RecordDiscOverlayStats(changed);
    return changed;
}

#include <cerrno>
#include <new>

struct XemuFileReplaceReadPlan {
    std::shared_ptr<const XemuFileReplace::OverlaySnapshot> snapshot;
    std::vector<XemuFileReplaceReadPiece> pieces;
    size_t changed = 0;
};

extern "C" int xemu_file_replace_plan_create(uintptr_t identity, uint64_t offset,
                                             size_t size, XemuFileReplaceReadPlan **out)
{
    using namespace XemuFileReplace;
    if (!out) return -EINVAL;
    *out = nullptr;
    if (!size) return 0;
    if (size > UINT64_MAX - offset) return -EIO;
    const auto snapshot = ActiveDiscOverlay();
    if (!snapshot || !identity || snapshot->disc_identity != identity) return 0;
    const uint64_t end = offset + size;
    if (end > snapshot->effective_length) return -EIO;
    try {
        auto plan = std::make_unique<XemuFileReplaceReadPlan>();
        plan->snapshot = snapshot;
        uint64_t cursor = offset;
        while (cursor < end) {
            XemuFileReplaceReadPiece piece{};
            piece.output_offset = static_cast<size_t>(cursor - offset);
            uint64_t limit = end;
            const auto vf = std::lower_bound(snapshot->files.begin(), snapshot->files.end(), cursor,
                [](const VirtualFile &f, uint64_t at) { return f.disc_start + f.reserved_size <= at; });
            bool changed = false;
            if (vf != snapshot->files.end() && vf->disc_start <= cursor) {
                const uint64_t rel = cursor - vf->disc_start;
                limit = std::min(limit, vf->disc_start + vf->reserved_size);
                if (rel >= vf->image.size) {
                    piece.kind = XEMU_FR_ZERO;
                } else {
                    const auto ex = std::lower_bound(vf->image.extents.begin(), vf->image.extents.end(), rel,
                        [](const ImageExtent &e, uint64_t at) { return e.start + e.size <= at; });
                    if (ex == vf->image.extents.end() || rel < ex->start) return -EIO;
                    limit = std::min(limit, vf->disc_start + ex->start + ex->size);
                    const uint64_t source = ex->source + rel - ex->start;
                    if (ex->kind == ExtentKind::Disc) {
                        piece.kind = XEMU_FR_DISC; piece.disc_offset = source;
                    } else if (ex->kind == ExtentKind::Bytes) {
                        if (!ex->bytes || source > ex->bytes->size() || limit - cursor > ex->bytes->size() - source)
                            return -EIO;
                        piece.kind = XEMU_FR_BYTES; piece.bytes = ex->bytes->data() + source;
                    } else piece.kind = XEMU_FR_ZERO;
                }
                changed = true;
            } else {
                if (vf != snapshot->files.end()) limit = std::min(limit, vf->disc_start);
                if (cursor >= snapshot->raw_length) {
                    piece.kind = XEMU_FR_ZERO; changed = true;
                } else {
                    limit = std::min(limit, snapshot->raw_length);
                    const auto range = std::lower_bound(snapshot->ranges.begin(), snapshot->ranges.end(), cursor,
                        [](const OverlayRange &r, uint64_t at) { return r.disc_start + r.reserved_size <= at; });
                    piece.kind = XEMU_FR_DISC; piece.disc_offset = cursor;
                    if (range != snapshot->ranges.end()) {
                        if (range->disc_start > cursor) limit = std::min(limit, range->disc_start);
                        else {
                            limit = std::min(limit, range->disc_start + range->reserved_size);
                            uint64_t rel = cursor - range->disc_start;
                            if (rel < range->replacement.size()) {
                                limit = std::min<uint64_t>(limit, range->disc_start + range->replacement.size());
                                piece.kind = XEMU_FR_BYTES;
                                piece.bytes = range->replacement.data() + rel;
                                changed = true;
                            } else if (range->padding == PaddingMode::Zero) {
                                piece.kind = XEMU_FR_ZERO; changed = true;
                            }
                        }
                    }
                }
            }
            if (limit <= cursor) return -EIO;
            piece.size = static_cast<size_t>(limit - cursor);
            if (changed) plan->changed += piece.size;
            plan->pieces.push_back(piece);
            cursor = limit;
        }
        if (!plan->changed) return 0;
        *out = plan.release();
        return 1;
    } catch (const std::bad_alloc &) { return -ENOMEM; }
    catch (...) { return -EIO; }
}
extern "C" size_t xemu_file_replace_plan_count(const XemuFileReplaceReadPlan *plan)
{
    return plan ? plan->pieces.size() : 0;
}
extern "C" const XemuFileReplaceReadPiece *xemu_file_replace_plan_piece(
    const XemuFileReplaceReadPlan *plan, size_t index)
{
    return plan && index < plan->pieces.size() ? &plan->pieces[index] : nullptr;
}
extern "C" void xemu_file_replace_plan_release(XemuFileReplaceReadPlan *plan) { delete plan; }
extern "C" void xemu_file_replace_plan_completed(const XemuFileReplaceReadPlan *plan)
{
    if (plan) XemuFileReplace::RecordDiscOverlayStats(plan->changed);
}
extern "C" uint64_t xemu_file_replace_disc_sectors(uintptr_t identity, uint64_t physical)
{
    const auto snapshot = XemuFileReplace::ActiveDiscOverlay();
    return snapshot && identity && snapshot->disc_identity == identity
        ? std::max(physical, snapshot->effective_length / 2048) : physical;
}
