# File Replace — XEMU Cheats 3.16 / manifests v3 + v4

XEMU Cheats accepts both manifest **version 3** and the new compact **version 4**.
v3 remains fully supported for backwards compatibility. v4 is the preferred authoring
format: it removes repeated replacement ids/objects and expands internally into the same
Fixed Range / Whole File / Resizable Range model used by v3. Runtime overlay behavior,
reset rules, validation and safety limits are unchanged. Older v1/v2 manifests remain
unsupported.

## Compact manifest v4

The common case is written directly under the UI option that owns it. Top-level `source`
and `author` are defaults. A group with `single: true` is a radio group; `original` adds
the retail choice. A group without `single: true` is multi-select. Group and option `name`
fields are optional: when omitted, XEMU humanizes the object key (`replace_spawn_with` ->
`Replace Spawn With`).

```json
{
  "version": 4,
  "game": "AB1234",
  "source": "root.olk",
  "author": "Example Author",
  "groups": {
    "replace_character": {
      "single": true,
      "original": "Original / Retail",
      "options": {
        "alternate": {
          "ranges": [
            ["0x1000", "0x20", "table.bin"],
            ["0x2000", "0x400", "model.pkg"]
          ]
        }
      }
    },
    "whole_file_mod": {
      "options": {
        "on": {
          "whole": ["other.olk", "replacement.olk"]
        }
      }
    }
  }
}
```

A compact three-value range means:

```text
[offset, original_reserved_size, replacement_file]
```

XEMU expands it as a Fixed Range on the default `source`, with original-byte padding and
`requires_reset=true`. Internal replacement ids are generated automatically from the
group/option/range position; v4 authors do not maintain a second replacement-id list.

`whole: ["original_file", "replacement_file"]` means Whole File replacement. The source
file is explicit instead of inherited from the top-level `source`. Whole File always permits the
replacement to grow or shrink, uses the real replacement length, and requires Reset. Do not add
`resize`: size change is implicit for Whole File.

For the less-common Resizable Range or a non-default setting, use the extended object
form inside `ranges`:

```json
{
  "range": ["0x3000", "0x800"],
  "with": "resized.pkg",
  "resize": true,
  "fix_size": "olk"
}
```

Extended ranges may override `source`, `author`, `name`, `description`, and Fixed Range
`padding` (`original`/`zero`). `reset` may be written explicitly only as `true`; current
File Replace activation still requires Reset. `fix_size` is valid only with a Resizable
Range and must name a registered Known File Size Fixer.

The complete schema is `file-replace-v4.schema.json`; a non-autoloaded example is
`examples/compact-v4.json`.

## Manifest v3 compatibility

v3 keeps the existing explicit `replacements` array plus `groups` references. Its three
modes remain:

| Mode | `source.type` | `size_change` | Guest behavior |
|---|---|---|---|
| Fixed Range | `disc_range` | `false` | Raw DVD overlay; host bytes must fit the reserved source range. |
| Whole File | `file` | `true` | Complete XDVDFS file replaced, including its directory-record sector and actual byte length. |
| Resizable Range | `disc_range` | `true` | Original-file-coordinate splice; containing file grows or shrinks and is virtually relocated. |

v3 still requires top-level boolean `size_change` on each replacement and the existing
source/replacement objects. Its schema remains `file-replace-v3.schema.json`.

For both versions, source offsets are original-file coordinates. Fixed Range supports
original/zero padding. Size-changing modes use the actual replacement length and do not
pad back to the old length. All host replacement paths are safe relative paths beneath
the exact XBE identity folder.

## Known File Size Fixers

`known-size-fixers.hh/.cc` owns the format registry and a planning interface.
`file-replace-olk.cc` is its first implementation. A fixer plans sparse content
edits plus metadata edits; it does not write into the ISO. An unknown fixer name
is rejected, not silently ignored.

The first OLK fixer recognizes little-endian `olnk` containers with validated
headers, power-of-two alignment and ordered nonoverlapping entries, including
nested containers. Each requested range must match exactly **one existing,
nonempty leaf entry's offset and actual size**. It updates that leaf size,
sector-aligned allocation, following relative offsets, enclosing entry sizes
and nonzero container payload spans. Valid zero span sentinels and timestamps
are preserved. It revalidates the resulting virtual hierarchy before activation.
Multiple disjoint leaf replacements and shrinking a leaf to zero are supported.

This first fixer does **not** add/remove table slots, invent alias relationships,
repair pointers internal to an arbitrary PKG/VMX, accept ambiguous/overlapping
OLK entries, or replace an entire nested OLK as one leaf. It fails explicitly on
unsupported layouts. These limits are important: raw Resizable Range without a
fixer deliberately does not promise format-level pointer repair.

The supplied SCII A/B/C migration retains all six manual `.tbl` payloads. They
redirect resource entries into donor/embedded storage, not just resize them.
They therefore remain Fixed Range operations; replacing them with `fix_size`
would not reproduce their role. See the SCII migration audit in the delivery.

## Effective DVD layout and read lifetime

The compiler creates one immutable snapshot for the entire selected set. Fixed
ranges remain at their original DVD locations. Each Whole File / resized target
gets a sector-aligned virtual allocation after the physical ISO's end, so growth
cannot overwrite a following disc file. Eight directory-record bytes are
virtually patched for the new sector and byte size; READ CAPACITY/TOC and read
bounds use the effective capacity. Untouched data in a resized file is represented
by sparse references to original ISO extents, not copied into a giant rebuilt OLK.

The addon C bridge intercepts synchronous and IDE buffered asynchronous DVD
reads. It captures one read plan at request submission. Host bytes and old
snapshots stay alive until that request finishes, even after a new snapshot is
published or an old one cleared. Asynchronous reads assemble into a private
buffer and copy to the IDE iovec only after the complete read succeeds. Original
span failures or a changed mounted medium fail the read rather than returning a
mixed/partial asynchronous result. Existing IDE orphan/reset ownership remains
in the IDE core.

Validation reads use the unmodified mounted backend. Runtime source writes,
`blk_pwrite`, writable ISO reopen, ISO replacement and on-disc directory edits are
not part of this feature. The original ISO remains unchanged.

## Reset, reload and safety

- All choices require Reset to activate/deactivate. Fixed Range alone retains
  live **Reload Active** of already-active payloads, with atomic publication.
- Whole File and Resizable Range disable live reload, even for equal-size data.
- One invalid selected entry rejects the complete new set. The previous complete
  snapshot remains active; no new subset is armed. The runtime status explains it.
- Mounted-medium changes clear the active overlay. A virtual layout is retained
  across an executable transition on the same medium, because the guest may have
  cached virtual sectors. Its owning manifest also stays available, so Original /
  Retail plus Reset can clear it even when a replaced XBE has a different hash.
  A successful reset activation can replace it; an invalid set cannot silently
  revoke the old virtual layout.
- Whole File cannot be combined with another operation on that file. Overlaps,
  metadata conflicts, mixed unknown resizes with a known fixer, integer overflow,
  and malformed formats are rejected before publication.
- Combined host payloads are limited to **1 GiB** per active set. This permits a
  whole-file replacement of the supplied approximately 662 MiB retail OLK while
  retaining an explicit host-memory bound. Host bytes are snapshotted in memory;
  larger payload sets are rejected. Individual virtual files also obey XDVDFS's
  32-bit length and the implementation's signed-ATAPI-sector bounds.

This candidate does not establish save-state migration between different active
virtual layouts. Keep the same active set when loading a state; use a normal
reset to switch sets. Raw-LBA consumers which bypass directory lookups may still
use old sectors; choose Fixed Range for such a consumer or repair its own index.

## Ownership and building

All planning, OLK, snapshot and I/O implementation lives in this addon directory.
Shared XDVDFS parsing only adds the original directory-record address. Meson
wires the new sources and the no-main profile gets no-op plan/capacity symbols.
Patch 300 contains the DVD read/capacity call sites; patches 10–60 are unchanged.
The v4 compact-parser addition itself is addon-only relative to the current XEMU Cheats
3.16 baseline: Patch 300 does not change for v4. A source tree older than the existing
v3.16 File Replace integration still needs the current Patch 300 hooks.

## Reproducible validation

From this directory, with Python 3, a C compiler and a C++17 compiler:

```sh
python3 tests/run-v316.py
python3 tests/run-v316.py --sanitizers --retail-olk /path/to/retail/root.olk
```

The native core tests and legacy byte-overlay/XDVDFS tests use actual production
C++ sources. The C adapter tests execute the production C adapter with a clearly
isolated fake QEMU API (not an emulator). The manager/UI checks use declaration
stubs and prove C++17 syntax only, not full dependency compatibility. A full
Windows/Linux/macOS XEMU build and in-game startup/reset/playback are separate
acceptance tests, not claimed by these standalone tests.
