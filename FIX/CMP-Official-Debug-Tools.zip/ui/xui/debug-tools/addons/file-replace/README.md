# File Replace — XEMU Cheats v3.16 / manifest v3

v3.16 accepts **version 3 only**. Older v1/v2 manifests are deliberately rejected.
The UI remains a grouped File Replace tab. Choices are selected first and armed
by Reset Game; selection itself does not change guest reads.

## Three modes

| Mode | `source.type` | `size_change` | Guest behavior |
|---|---|---|---|
| Fixed Range | `disc_range` | `false` | Old raw DVD overlay; host bytes must fit the reserved source range. |
| Whole File | `file` | `true` | Complete XDVDFS file replaced, including its directory-record sector and actual byte length. |
| Resizable Range | `disc_range` | `true` | Original-file-coordinate splice; containing file grows or shrinks and is virtually relocated. |

`size_change` is a required **top-level boolean** on each replacement. It selects
a mode, not a prediction of whether a particular payload has a different length.
Whole File requires `true` even for equal-size payloads. `source.file` is an
XDVDFS path. `replacement.file` is a safe relative host path under the exact XBE
identity folder. Whole File omits source offset/size. Disc ranges require both;
source size is the original length removed, not the replacement length.

Fixed Range retains `replacement.padding: "original"` (default) or `"zero"`.
Padding is forbidden for either size-changing mode: replacement length is real,
not silently padded back to the original file size. Virtual DVD sector tails are
zero-filled, but the guest directory size does not include those tail bytes.
All operations in a file use **original source offsets**, not offsets already
shifted by another operation.

Example operation, Whole File:

```json
{
  "id": "new_data",
  "name": "New data file",
  "source": {"type": "file", "file": "media/data.bin"},
  "size_change": true,
  "replacement": {"file": "data-new.bin"},
  "requires_reset": true
}
```

Example operation, recognized OLK leaf resize:

```json
{
  "id": "new_leaf",
  "name": "Resize one OLK leaf",
  "source": {"type": "disc_range", "file": "root.olk",
             "offset": "0x28B62000", "size": "0x001A8A00"},
  "size_change": true,
  "fix_size": "olk",
  "replacement": {"file": "new-leaf.pkg"},
  "requires_reset": true
}
```

The OLK numbers above are an example from the supplied retail layout, not a
universal address. The implementation contains no game ID, game filename, leaf
address or character-specific rule. Always resolve your own original extent.
Complete non-autoloaded examples are in `examples/`; the JSON schema is
`file-replace-v3.schema.json`. Runtime validation additionally checks source
existence, group references, payload files, overlaps and the complete OLK layout.
Unknown fields are not a substitute for supported mode settings.

## Known File Size Fixers

`known-size-fixers.hh/.cc` owns the format registry and a planning interface.
`file-replace-olk.cc` is its first implementation. A fixer plans sparse content
edits plus metadata edits; it does not write into the ISO. An unknown fixer name
is rejected, not silently ignored.

The first OLK fixer recognizes little-endian `olnk` containers with validated
headers, power-of-two alignment and ordered nonoverlapping entries, including
nested containers. Each requested range must match exactly **one existing,
nonempty leaf entry's offset and actual size**. It updates that leaf size,
sector-aligned allocation, following relative offsets, enclosing entry sizes
and nonzero container payload spans. Valid zero span sentinels and timestamps
are preserved. It revalidates the resulting virtual hierarchy before activation.
Multiple disjoint leaf replacements and shrinking a leaf to zero are supported.

This first fixer does **not** add/remove table slots, invent alias relationships,
repair pointers internal to an arbitrary PKG/VMX, accept ambiguous/overlapping
OLK entries, or replace an entire nested OLK as one leaf. It fails explicitly on
unsupported layouts. These limits are important: raw Resizable Range without a
fixer deliberately does not promise format-level pointer repair.

The supplied SCII A/B/C migration retains all six manual `.tbl` payloads. They
redirect resource entries into donor/embedded storage, not just resize them.
They therefore remain Fixed Range operations; replacing them with `fix_size`
would not reproduce their role. See the SCII migration audit in the delivery.

## Effective DVD layout and read lifetime

The compiler creates one immutable snapshot for the entire selected set. Fixed
ranges remain at their original DVD locations. Each Whole File / resized target
gets a sector-aligned virtual allocation after the physical ISO's end, so growth
cannot overwrite a following disc file. Eight directory-record bytes are
virtually patched for the new sector and byte size; READ CAPACITY/TOC and read
bounds use the effective capacity. Untouched data in a resized file is represented
by sparse references to original ISO extents, not copied into a giant rebuilt OLK.

The addon C bridge intercepts synchronous and IDE buffered asynchronous DVD
reads. It captures one read plan at request submission. Host bytes and old
snapshots stay alive until that request finishes, even after a new snapshot is
published or an old one cleared. Asynchronous reads assemble into a private
buffer and copy to the IDE iovec only after the complete read succeeds. Original
span failures or a changed mounted medium fail the read rather than returning a
mixed/partial asynchronous result. Existing IDE orphan/reset ownership remains
in the IDE core.

Validation reads use the unmodified mounted backend. Runtime source writes,
`blk_pwrite`, writable ISO reopen, ISO replacement and on-disc directory edits are
not part of this feature. The original ISO remains unchanged.

## Reset, reload and safety

- All choices require Reset to activate/deactivate. Fixed Range alone retains
  live **Reload Active** of already-active payloads, with atomic publication.
- Whole File and Resizable Range disable live reload, even for equal-size data.
- One invalid selected entry rejects the complete new set. The previous complete
  snapshot remains active; no new subset is armed. The runtime status explains it.
- Mounted-medium changes clear the active overlay. A virtual layout is retained
  across an executable transition on the same medium, because the guest may have
  cached virtual sectors. Its owning manifest also stays available, so Original /
  Retail plus Reset can clear it even when a replaced XBE has a different hash.
  A successful reset activation can replace it; an invalid set cannot silently
  revoke the old virtual layout.
- Whole File cannot be combined with another operation on that file. Overlaps,
  metadata conflicts, mixed unknown resizes with a known fixer, integer overflow,
  and malformed formats are rejected before publication.
- Combined host payloads are limited to **1 GiB** per active set. This permits a
  whole-file replacement of the supplied approximately 662 MiB retail OLK while
  retaining an explicit host-memory bound. Host bytes are snapshotted in memory;
  larger payload sets are rejected. Individual virtual files also obey XDVDFS's
  32-bit length and the implementation's signed-ATAPI-sector bounds.

This candidate does not establish save-state migration between different active
virtual layouts. Keep the same active set when loading a state; use a normal
reset to switch sets. Raw-LBA consumers which bypass directory lookups may still
use old sectors; choose Fixed Range for such a consumer or repair its own index.

## Ownership and building

All planning, OLK, snapshot and I/O implementation lives in this addon directory.
Shared XDVDFS parsing only adds the original directory-record address. Meson
wires the new sources and the no-main profile gets no-op plan/capacity symbols.
Patch 300 contains the DVD read/capacity call sites; patches 10–60 are unchanged.
**Install both the new Patch 300 and new Debug Tools ZIP.** An addon-only swap
cannot supply the new upstream hooks.

## Reproducible validation

From this directory, with Python 3, a C compiler and a C++17 compiler:

```sh
python3 tests/run-v316.py
python3 tests/run-v316.py --sanitizers --retail-olk /path/to/retail/root.olk
```

The native core tests and legacy byte-overlay/XDVDFS tests use actual production
C++ sources. The C adapter tests execute the production C adapter with a clearly
isolated fake QEMU API (not an emulator). The manager/UI checks use declaration
stubs and prove C++17 syntax only, not full dependency compatibility. A full
Windows/Linux/macOS XEMU build and in-game startup/reset/playback are separate
acceptance tests, not claimed by these standalone tests.
