/* TEST ONLY: match QEMU's direct aligned-free declaration ownership. */
#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void qemu_vfree(void *);
#ifdef __cplusplus
}
#endif
