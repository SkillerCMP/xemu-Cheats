// Declaration-only ImGui facade for syntax tests, not a UI/runtime test.
#pragma once
struct ImVec2 {float x,y;ImVec2(float a,float b):x(a),y(b){}};
constexpr int ImGuiCond_FirstUseEver=0;
constexpr int ImGuiWindowFlags_NoCollapse=0;
namespace ImGui {
template<class... Args> bool Begin(Args...);
template<class... Args> bool BeginDisabled(Args...);
template<class... Args> bool BeginPopupContextItem(Args...);
template<class... Args> bool Button(Args...);
template<class... Args> bool Checkbox(Args...);
template<class... Args> bool CollapsingHeader(Args...);
template<class... Args> bool End(Args...);
template<class... Args> bool EndDisabled(Args...);
template<class... Args> bool EndPopup(Args...);
template<class... Args> bool IsItemHovered(Args...);
template<class... Args> bool MenuItem(Args...);
template<class... Args> bool PopID(Args...);
template<class... Args> bool PushID(Args...);
template<class... Args> bool RadioButton(Args...);
template<class... Args> bool SameLine(Args...);
template<class... Args> bool Separator(Args...);
template<class... Args> bool SeparatorText(Args...);
template<class... Args> bool SetNextWindowSize(Args...);
template<class... Args> bool SetTooltip(Args...);
template<class... Args> bool SmallButton(Args...);
template<class... Args> bool Text(Args...);
template<class... Args> bool TextDisabled(Args...);
template<class... Args> bool TextUnformatted(Args...);
template<class... Args> bool TextWrapped(Args...);
}
