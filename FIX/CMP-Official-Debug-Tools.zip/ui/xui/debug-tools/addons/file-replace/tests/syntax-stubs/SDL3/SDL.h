#pragma once
bool SDL_OpenURL(const char *);const char *SDL_GetError();
