/* Test-only declarations: not a substitute for a full QEMU build. */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#define coroutine_fn
#ifdef __cplusplus
extern "C" {
#endif
typedef int BdrvRequestFlags;
typedef void BlockCompletionFunc(void *, int);
typedef void CoroutineEntry(void *);
typedef struct BlockDriverState { int value; } BlockDriverState;
typedef struct BlockBackend { BlockDriverState *bs; int in_flight; } BlockBackend;
typedef struct BlockAIOCB { BlockCompletionFunc *cb; void *opaque; } BlockAIOCB;
typedef struct AIOCBInfo { size_t aiocb_size; } AIOCBInfo;
typedef struct QEMUIOVector { size_t size; void *data; } QEMUIOVector;
typedef struct Coroutine { CoroutineEntry *entry; void *opaque; } Coroutine;
typedef void AioContext;
BlockDriverState *blk_bs(BlockBackend *);
int blk_pread(BlockBackend *, int64_t, int64_t, void *, BdrvRequestFlags);
int blk_co_pread(BlockBackend *, int64_t, int64_t, void *, BdrvRequestFlags);
void *blk_try_blockalign(BlockBackend *, size_t);
void *blk_aio_get(const AIOCBInfo *, BlockBackend *, BlockCompletionFunc *, void *);
void qemu_aio_unref(void *);
void blk_inc_in_flight(BlockBackend *);
void blk_dec_in_flight(BlockBackend *);
BlockAIOCB *blk_abort_aio_request(BlockBackend *, BlockCompletionFunc *, void *, int);
BlockAIOCB *blk_aio_preadv(BlockBackend *, int64_t, QEMUIOVector *, BdrvRequestFlags, BlockCompletionFunc *, void *);
size_t qemu_iovec_from_buf(QEMUIOVector *, size_t, const void *, size_t);
Coroutine *qemu_coroutine_create(CoroutineEntry *, void *);
AioContext *qemu_get_current_aio_context(void);
void aio_co_enter(AioContext *, Coroutine *);
void replay_bh_schedule_oneshot_event(AioContext *, void (*)(void *), void *);
#ifdef __cplusplus
}
#endif
