#pragma once
#include <cstddef>
extern "C" bool xemu_cheat_get_executable_dir(char *, size_t);
