#pragma once
using gchar=char;struct GError {const char *message;};
void g_free(void *);char *g_filename_to_uri(const char *,const char *,GError **);void g_error_free(GError *);
char *g_canonicalize_filename(const char *,const char *);
