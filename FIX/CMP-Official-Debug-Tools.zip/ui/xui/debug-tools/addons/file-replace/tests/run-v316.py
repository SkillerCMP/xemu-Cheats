#!/usr/bin/env python3
"""Standalone v3.16 regression suite; not a full XEMU build.

No third-party Python package is needed for the native/syntax tests. QEMU,
SDL, ImGui and nlohmann declaration fakes are strictly test-local and are never
in the production include paths. Use --retail-olk for an additional real-input
OLK structural/resize check. This script never changes that input.
"""
from pathlib import Path
import argparse, os, shutil, subprocess, tempfile

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--compiler',default=os.environ.get('CXX','g++'))
    p.add_argument('--cc',default=os.environ.get('CC','cc'))
    p.add_argument('--sanitizers',action='store_true')
    p.add_argument('--retail-olk',type=Path)
    args=p.parse_args()
    a=Path(__file__).resolve().parents[1]; dt=a.parents[1]; tests=a/'tests'
    for c in [args.compiler,args.cc]:
        if not shutil.which(c):p.error('Compiler not found: '+c)
    cpp=[args.compiler,'-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-pthread']
    cc=[args.cc,'-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror']
    if args.sanitizers:
        sanitizer=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
        cpp+=sanitizer;cc+=sanitizer
    impl=[a/n for n in ['file-replace-image.cc','file-replace-compiler.cc','file-replace-olk.cc','known-size-fixers.cc','file-replace-disc-overlay.cc']]
    def run(cmd):
        print('+',' '.join(map(str,cmd)),flush=True)
        subprocess.run(list(map(str,cmd)),check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    with tempfile.TemporaryDirectory(prefix='xemu-fr316-') as tmp:
        tmp=Path(tmp)
        includes=['-I'+str(a),'-I'+str(dt)]
        run(cpp+includes+[a/'tests-core.cpp',*impl,dt/'xdvdfs-disc.cc','-o',tmp/'core'])
        run([tmp/'core']+([args.retail_olk.resolve()] if args.retail_olk else []))
        bridge_includes=['-I'+str(tests/'bridge-stubs'),*includes]
        run(cc+bridge_includes+['-c',a/'file-replace-block.c','-o',tmp/'bridge-c.o'])
        run(cpp+bridge_includes+[tests/'bridge.cpp',tmp/'bridge-c.o',*impl,'-o',tmp/'bridge'])
        run([tmp/'bridge'])
        for name,sources in [
          ('legacy-overlay',[dt/'tests/file-replace-overlay-golden.cpp',a/'file-replace-disc-overlay.cc']),
          ('xdvdfs',[dt/'tests/xdvdfs-golden.cpp',dt/'xdvdfs-disc.cc'])]:
            run(cpp+includes+sources+['-o',tmp/name]);run([tmp/name])
        # The main implementation stays under the addon; shared/no-main hooks
        # are type-checked separately without linking a fake emulator.
        run(cc+['-I'+str(dt.parents[2]),'-c',dt/'addons/stubs/file-replace-disc-overlay-stub.c','-o',tmp/'no-main.o'])
        run(cpp+['-fsyntax-only','-I'+str(tests/'syntax-stubs'),*includes,a/'file-replace.cc',a/'file-replace-ui.cc'])
    print('PASS: v3.16 native core, isolated C bridge, legacy Fixed Range, XDVDFS and declaration-stub syntax checks')
    print('NOT PERFORMED: full XEMU dependency build or in-game runtime validation')
if __name__=='__main__': main()
