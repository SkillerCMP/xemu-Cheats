// Optional fixture generated from the user's migrated SCII manifest. Scans the
// actual entire retail OLK for every option, comparing v3 read plans with an
// independent Fixed Range byte-substitution model. No disc file is written.
#include "file-replace-compiler.hh"
#include "file-replace-disc-overlay.h"
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
using namespace XemuFileReplace;
static void need(bool b,const char *s) { if(!b)throw std::runtime_error(s); }
static uint64_t word(std::istream &s) { uint8_t b[8];s.read((char *)b,8);need(bool(s),"truncated fixture");uint64_t v=0;for(unsigned i=0;i<8;++i)v|=uint64_t(b[i])<<(8*i);return v; }
int main(int argc,char **argv) {
 try {
    need(argc==3,"usage: equivalence retail-root.olk fixture.bin");
    std::ifstream source(argv[1],std::ios::binary),fixture(argv[2],std::ios::binary);need(bool(source)&&bool(fixture),"input open");
    source.seekg(0,std::ios::end);const uint64_t size=uint64_t(source.tellg());source.seekg(0);
    RawReader raw=[&](uint64_t o,void *p,size_t n){if(o>size||n>size-o)return false;source.clear();source.seekg(o);source.read((char *)p,n);return bool(source);};
    const uint64_t group_count=word(fixture);need(group_count==3,"expected A/B/C fixture");uint64_t compared=0,windows=0;
    for(uint64_t group=0;group<group_count;++group) {
        CompileFile file;file.name="root.olk";file.disc_start=0;file.size=size;file.directory_entry=0;
        const uint64_t count=word(fixture);need(count<1000,"fixture operation limit");
        for(uint64_t i=0;i<count;++i){
            CompileOperation op;op.id=std::to_string(i);op.offset=word(fixture);op.size=word(fixture);op.padding=word(fixture)?PaddingMode::Zero:PaddingMode::Original;
            auto payload=std::make_shared<Bytes>(word(fixture));fixture.read((char *)payload->data(),payload->size());need(bool(fixture),"fixture payload");op.bytes=payload;file.operations.push_back(op);
        }
        auto snapshot=std::make_shared<OverlaySnapshot>();snapshot->disc_identity=0x1234;std::string error;
        need(CompileOverlay(raw,size,{file},*snapshot,error),error.c_str());InstallDiscOverlay(snapshot);
        for(uint64_t off=0;off<size;off+=131071){
            size_t n=std::min<uint64_t>(131071,size-off);Bytes expected(n),actual(n);need(raw(off,expected.data(),n),"original read");
            for(const auto &op:file.operations){
                uint64_t lo=std::max(off,op.offset),hi=std::min(off+n,op.offset+op.size);
                for(uint64_t at=lo;at<hi;++at){uint64_t rel=at-op.offset;if(rel<op.bytes->size())expected[at-off]=(*op.bytes)[rel];else if(op.padding==PaddingMode::Zero)expected[at-off]=0;}
            }
            XemuFileReplaceReadPlan *plan=nullptr;int rc=xemu_file_replace_plan_create(0x1234,off,n,&plan);need(rc>=0,"plan error");
            if(!rc)need(raw(off,actual.data(),n),"pass-through read");
            else {
                for(size_t i=0;i<xemu_file_replace_plan_count(plan);++i){const auto *p=xemu_file_replace_plan_piece(plan,i);auto *dst=actual.data()+p->output_offset;
                    if(p->kind==XEMU_FR_DISC)need(raw(p->disc_offset,dst,p->size),"plan original read");else if(p->kind==XEMU_FR_BYTES)std::memcpy(dst,p->bytes,p->size);else std::memset(dst,0,p->size);
                }
                xemu_file_replace_plan_release(plan);
            }
            need(actual==expected,"Fixed Range differs from independent reference");compared+=n;++windows;
        }
        ClearDiscOverlay();std::cout<<"PASS SCII option "<<char('A'+group)<<": "<<count<<" fixed operations over "<<size<<" bytes\n";
    }
    std::cout<<"PASS SCII v3 fixed equivalence: "<<compared<<" bytes, "<<windows<<" unaligned windows compared\n";
    return 0;
 }catch(const std::exception &e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
