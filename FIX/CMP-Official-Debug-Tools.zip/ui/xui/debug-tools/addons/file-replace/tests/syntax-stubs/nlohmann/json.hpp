// Declarations only, for isolated syntax checks. NOT the JSON dependency.
#pragma once
#include <string>
#include <cstdint>
#include <istream>
namespace nlohmann { class json {
 public:
 class const_iterator { public: const json &operator*() const; const json *operator->() const;
 const_iterator &operator++(); bool operator!=(const const_iterator &) const; bool operator==(const const_iterator &) const; };
 const_iterator find(const char *) const; const_iterator begin() const; const_iterator end() const;
 bool contains(const char *) const; bool is_string() const; bool is_object() const; bool is_array() const;
 bool is_number_unsigned() const; bool is_number_integer() const; bool is_boolean() const; bool empty() const;
 bool operator!=(int) const; template<class T> T get() const;
 }; std::istream &operator>>(std::istream &,json &); }
