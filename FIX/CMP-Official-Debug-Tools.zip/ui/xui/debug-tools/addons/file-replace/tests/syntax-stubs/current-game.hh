#pragma once
#include <cstdint>
#include <string>
class CurrentGameManager { public: struct GameInfo { bool valid; uint32_t title_id; std::string title_name,header_sha256; };
 const GameInfo &Get() const; static std::string FormatDatabaseGameId(uint32_t); };
extern CurrentGameManager current_game_manager;
