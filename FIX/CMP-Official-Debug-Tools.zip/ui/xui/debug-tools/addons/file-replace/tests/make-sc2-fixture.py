#!/usr/bin/env python3
"""Create temporary equivalence input from an existing SCII v3 manifest.
Usage: make-sc2-fixture.py manifest.json executable-identity output.bin
Never modifies the input manifest or payloads.
"""
import json,struct,sys
from pathlib import Path
if len(sys.argv)!=4:raise SystemExit(__doc__)
p=Path(sys.argv[1]);m=json.loads(p.read_text());assert m['version']==3
identity=sys.argv[2];assert len(identity)==64 and all(c in '0123456789abcdefABCDEF' for c in identity)
ops={e['id']:e for e in m['replacements']};opts=m['groups'][0]['options'];assert [o['id'] for o in opts]==['a','b','c']
number=lambda n:int(n,0) if isinstance(n,str) else n
with Path(sys.argv[3]).open('wb') as out:
 def word(n):out.write(struct.pack('<Q',n))
 word(len(opts))
 for o in opts:
  entries=[ops[i] for i in dict.fromkeys(o['replacements'])];word(len(entries))
  for e in entries:
   assert e['source']['type']=='disc_range' and e['size_change'] is False
   path=Path(e['replacement']['file']);assert not path.is_absolute() and '..' not in path.parts
   b=(p.parent/'Files'/identity/path).read_bytes();word(number(e['source']['offset']));word(number(e['source']['size']));word(e['replacement'].get('padding','original')=='zero');word(len(b));out.write(b)
