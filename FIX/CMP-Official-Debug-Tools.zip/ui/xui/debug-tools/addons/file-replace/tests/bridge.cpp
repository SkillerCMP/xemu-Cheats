// Execute the real C read adapter and C++ plan engine against an isolated fake
// QEMU API. Immediate/deferred coroutines and BH ordering are modeled; this is
// NOT an emulator, coroutine implementation or a hardware runtime test.
#include "fake-qemu.h"
#include "qemu/memalign.h"
#include "file-replace-block.h"
#include "file-replace-compiler.hh"
#include <algorithm>
#include <cstring>
#include <deque>
#include <functional>
#include <iostream>
#include <vector>
using namespace XemuFileReplace;
static int checks, allocations, aiocbs, physical_reads;
static bool deferred, fail_alloc, fail_read;
static std::deque<std::function<void()>> queue;
static std::function<void()> during_read;
static Bytes raw(65536, 0x77);
#define CHECK(x) do { ++checks; if (!(x)) { std::cerr << "FAIL bridge line " << __LINE__ << ": " #x << '\n'; std::abort(); }} while(0)
extern "C" {
BlockDriverState *blk_bs(BlockBackend *b) { return b->bs; }
int blk_pread(BlockBackend *b, int64_t o, int64_t n, void *p, BdrvRequestFlags) {
    ++physical_reads;
    if (!b->bs) return -ENOMEDIUM;
    if (fail_read) return -EIO;
    if (o < 0 || n < 0 || uint64_t(o) > raw.size() || uint64_t(n) > raw.size()-uint64_t(o)) return -EIO;
    std::memcpy(p, raw.data()+o, n);
    if (during_read) { auto f=std::move(during_read); during_read={}; f(); }
    return 0;
}
int blk_co_pread(BlockBackend *b, int64_t o, int64_t n, void *p, BdrvRequestFlags f) { return blk_pread(b,o,n,p,f); }
void *blk_try_blockalign(BlockBackend *, size_t n) { if (fail_alloc) return nullptr; ++allocations; return std::malloc(n); }
void qemu_vfree(void *p) { if (p) { --allocations; std::free(p); } }
void *blk_aio_get(const AIOCBInfo *i, BlockBackend *, BlockCompletionFunc *cb, void *o) {
    auto a=static_cast<BlockAIOCB *>(std::calloc(1,i->aiocb_size)); a->cb=cb; a->opaque=o; ++aiocbs; return a;
}
void qemu_aio_unref(void *p) { --aiocbs; std::free(p); }
void blk_inc_in_flight(BlockBackend *b) { ++b->in_flight; }
void blk_dec_in_flight(BlockBackend *b) { CHECK(b->in_flight>0); --b->in_flight; }
size_t qemu_iovec_from_buf(QEMUIOVector *q,size_t o,const void *p,size_t n) { CHECK(o+n<=q->size); std::memcpy(static_cast<uint8_t *>(q->data)+o,p,n); return n; }
Coroutine *qemu_coroutine_create(CoroutineEntry *e,void *p) { return new Coroutine{e,p}; }
AioContext *qemu_get_current_aio_context() { return nullptr; }
void aio_co_enter(AioContext *,Coroutine *co) {
    auto run=[co] { co->entry(co->opaque); delete co; };
    if (deferred) queue.push_back(run); else run();
}
void replay_bh_schedule_oneshot_event(AioContext *,void (*f)(void *),void *p) { queue.push_back([=]{ f(p); }); }
BlockAIOCB *blk_abort_aio_request(BlockBackend *b,BlockCompletionFunc *cb,void *o,int ret) {
    const AIOCBInfo info{sizeof(BlockAIOCB)}; auto a=static_cast<BlockAIOCB *>(blk_aio_get(&info,b,cb,o));
    blk_inc_in_flight(b);queue.push_back([=]{ blk_dec_in_flight(b);cb(o,ret);qemu_aio_unref(a); });return a;
}
BlockAIOCB *blk_aio_preadv(BlockBackend *b,int64_t o,QEMUIOVector *q,BdrvRequestFlags f,BlockCompletionFunc *cb,void *p) {
    int ret=blk_pread(b,o,q->size,q->data,f); return blk_abort_aio_request(b,cb,p,ret);
}
}
struct Completion { int calls=0, result=42; bool *returned=nullptr; };
static void done(void *p,int ret) { auto &c=*static_cast<Completion *>(p);CHECK(*c.returned);++c.calls;c.result=ret; }
static void drain() { while(!queue.empty()) { auto f=queue.front();queue.pop_front();f(); } CHECK(!allocations && !aiocbs); }
static std::shared_ptr<OverlaySnapshot> make_snapshot(BlockBackend &b,bool virtual_file) {
    auto s=std::make_shared<OverlaySnapshot>();s->disc_identity=(uintptr_t)b.bs;
    auto data=std::make_shared<Bytes>(32,0xAA); CompileFile file;
    file.disc_start=4096;file.size=2048;file.directory_entry=128;file.filesystem_base=0;file.name="data.bin";
    file.operations.push_back({"test",32,16,false,virtual_file,PaddingMode::Original,"",data});
    if (!virtual_file) file.operations[0].size=32;
    std::string error;CHECK(CompileOverlay([](uint64_t o,void *p,size_t n){ if(o+n>raw.size())return false;std::memcpy(p,raw.data()+o,n);return true;},raw.size(),{file},*s,error));return s;
}
int main() {
    BlockDriverState bs{1},bs2{2};BlockBackend b{&bs,0};Bytes result(80,0xCC);
    for(bool virt:{false,true}) for(bool delayed:{false,true}) {
        deferred=delayed;auto snap=make_snapshot(b,virt);InstallDiscOverlay(snap);
        uint64_t offset=virt?snap->files[0].disc_start:4096;
        Bytes expected(80,0x77);std::fill(expected.begin()+32,expected.begin()+64,0xAA);
        CHECK(xemu_file_replace_pread(&b,offset,80,result.data(),0)==0);CHECK(result==expected);
        bool returned=false;Completion c{0,42,&returned};QEMUIOVector q{80,result.data()};result.assign(80,0xCC);
        CHECK(xemu_file_replace_aio_preadv(&b,offset,&q,0,done,&c));CHECK(!c.calls);returned=true;
        // Even a request not yet entered must retain the pre-reset snapshot.
        ClearDiscOverlay();drain();CHECK(c.calls==1 && c.result==0);CHECK(result==expected);CHECK(!b.in_flight);
        InstallDiscOverlay(snap);during_read=[] { ClearDiscOverlay(); };result.assign(80,0);
        CHECK(xemu_file_replace_pread(&b,offset,80,result.data(),0)==0);CHECK(result==expected);
        // A mid-read medium change must return an error, not copy a partial
        // private buffer into the caller's iovec.
        InstallDiscOverlay(snap);during_read=[&] { b.bs=&bs2; };
        returned=false;c={0,42,&returned};result.assign(80,0xCC);
        CHECK(xemu_file_replace_aio_preadv(&b,offset,&q,0,done,&c));returned=true;drain();
        CHECK(c.calls==1 && c.result==-ENOMEDIUM);CHECK(result==Bytes(80,0xCC));b.bs=&bs;
        // OOM and failed original-span reads complete once and release resources.
        for(int failure=0;failure<2;++failure) {
            InstallDiscOverlay(snap);fail_alloc=failure==0;fail_read=failure==1;
            returned=false;c={0,42,&returned};result.assign(80,0xCC);
            CHECK(xemu_file_replace_aio_preadv(&b,offset,&q,0,done,&c));returned=true;drain();
            CHECK(c.calls==1 && c.result==(failure==0?-ENOMEM:-EIO));CHECK(result==Bytes(80,0xCC));
            fail_alloc=false;fail_read=false;
        }
        // Outstanding request/orphan cleanup: caller-owned iovec remains alive
        // until the callback, exactly as ide_buffered_readv retains req->qiov.
        returned=false;c={0,42,&returned};result.assign(80,0xCC);
        CHECK(xemu_file_replace_aio_preadv(&b,offset,&q,0,done,&c));returned=true;
        ClearDiscOverlay();drain();CHECK(c.calls==1);CHECK(!b.in_flight);
    }
    ClearDiscOverlay();CHECK(xemu_file_replace_pread(&b,0,80,result.data(),0)==0);CHECK(result==Bytes(80,0x77));
    CHECK(xemu_file_replace_pread(&b,-1,80,result.data(),0)==-EINVAL);
    CHECK(xemu_file_replace_pread(&b,0,0,nullptr,0)==0);
    bool returned=false;Completion c{0,42,&returned};QEMUIOVector q{0,nullptr};
    CHECK(xemu_file_replace_aio_preadv(&b,0,&q,0,done,&c));returned=true;drain();CHECK(c.calls==1 && c.result==0);
    CHECK(!b.in_flight);
    std::cout<<"PASS v3.16 isolated C read bridge: "<<checks<<" assertions, "<<physical_reads<<" physical-span reads\n";
}
