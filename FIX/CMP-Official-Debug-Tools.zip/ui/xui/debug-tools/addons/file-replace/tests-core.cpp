// Native v3.16 regression tests; no QEMU/UI dependencies.
#include "file-replace-compiler.hh"
#include "file-replace-disc-overlay.h"
#include "xdvdfs-disc.hh"
#include <algorithm>
#include <atomic>
#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <random>
#include <thread>

using namespace XemuFileReplace;
static size_t checks;
#define CHECK(x) do { ++checks; if (!(x)) { std::cerr << "FAIL line " << __LINE__ << ": " #x "\n"; std::abort(); } } while (0)
static void put(Bytes &b, size_t off, uint32_t v) { for (unsigned i=0;i<4;++i) b.at(off+i)=uint8_t(v>>(i*8)); }
static uint32_t get(const Bytes &b, size_t off) { uint32_t v=0; for (unsigned i=0;i<4;++i) v|=uint32_t(b.at(off+i))<<(i*8); return v; }
static SharedBytes bytes(Bytes b) { return std::make_shared<const Bytes>(std::move(b)); }
static Bytes olk(std::vector<Bytes> children, uint32_t align=0x800) {
    uint64_t data_start; CHECK(AlignChecked(32+children.size()*16,align,data_start));
    Bytes result(static_cast<size_t>(data_start), 0); uint64_t cursor=0;
    put(result,0,uint32_t(children.size())); std::memcpy(result.data()+4,"olnk",4);
    put(result,8,align); put(result,16,uint32_t(data_start)); put(result,24,0x12345678);
    for(size_t i=0;i<children.size();++i) {
        put(result,32+16*i,uint32_t(cursor)); put(result,36+16*i,uint32_t(children[i].size()));
        put(result,40+16*i,0x55667788+uint32_t(i));
        uint64_t allocation; CHECK(AlignChecked(children[i].size(),align,allocation));
        result.resize(size_t(data_start+cursor+allocation));
        std::copy(children[i].begin(),children[i].end(),result.begin()+data_start+cursor);
        cursor+=allocation;
    }
    put(result,20,uint32_t(cursor)); return result;
}
static bool memory_read(const Bytes &b, uint64_t off, void *p, size_t n) {
    if (off>b.size() || n>b.size()-off) return false;
    if(n) std::memcpy(p,b.data()+off,n);
    return true;
}
static bool planned_read(uintptr_t identity,const RawReader &raw,uint64_t off,void *buffer,size_t n,
                         XemuFileReplaceReadPlan *retained=nullptr) {
    if (!n) return true;
    XemuFileReplaceReadPlan *p=retained;
    int status=p?1:xemu_file_replace_plan_create(identity,off,n,&p);
    if(status<0) return false;
    if(!status) return raw(off,buffer,n);
    bool ok=true;
    for(size_t i=0;i<xemu_file_replace_plan_count(p);++i) {
        auto *e=xemu_file_replace_plan_piece(p,i);
        auto *dst=static_cast<uint8_t*>(buffer)+e->output_offset;
        if(e->kind==XEMU_FR_DISC) { if(!raw(e->disc_offset,dst,e->size)) {ok=false;break;} }
        else if(e->kind==XEMU_FR_BYTES) std::memcpy(dst,e->bytes,e->size);
        else std::memset(dst,0,e->size);
    }
    if(ok) xemu_file_replace_plan_completed(p);
    if(!retained) xemu_file_replace_plan_release(p);
    return ok;
}
static CompileFile target(uint64_t start,uint64_t size,uint64_t entry=0x10800) {
    CompileFile f; f.name="sample.bin"; f.disc_start=start; f.size=size; f.directory_entry=entry; return f;
}
static Bytes make_iso(const Bytes &file) {
    Bytes iso(0x20000+file.size()); uint64_t aligned; CHECK(AlignChecked(iso.size(),2048,aligned)); iso.resize(aligned);
    std::memcpy(iso.data()+0x10000,"MICROSOFT*XBOX*MEDIA",20);
    std::memcpy(iso.data()+0x107ec,"MICROSOFT*XBOX*MEDIA",20);
    put(iso,0x10014,33); put(iso,0x10018,2048);
    put(iso,0x10804,0x20000/2048); put(iso,0x10808,uint32_t(file.size()));
    iso[0x1080c]=0x20; iso[0x1080d]=10; std::memcpy(iso.data()+0x1080e,"sample.bin",10);
    std::copy(file.begin(),file.end(),iso.begin()+0x20000); return iso;
}
static std::shared_ptr<OverlaySnapshot> compile(const Bytes &iso,const CompileFile &f) {
    auto s=std::make_shared<OverlaySnapshot>();s->disc_identity=123;
    std::string error;
    bool success=CompileOverlay([&](uint64_t o,void *p,size_t n){return memory_read(iso,o,p,n);},iso.size(),{f},*s,error);
    if(!success) std::cerr << error << "\n";
    CHECK(success);
    return s;
}
static void fixed_and_whole_tests() {
    Bytes original(5000); for(size_t i=0;i<original.size();++i)original[i]=uint8_t(i*17);
    Bytes iso=make_iso(original),before=iso;
    RawReader raw=[&](uint64_t o,void*p,size_t n){return memory_read(iso,o,p,n);};
    CompileFile f=target(0x20000,original.size());
    f.operations.push_back({"fixed",5,10,false,false,PaddingMode::Original,"",bytes({1,2,3})});
    auto s=compile(iso,f); InstallDiscOverlay(s); Bytes read(32);
    CHECK(planned_read(123,raw,0x20000,read.data(),read.size()));
    Bytes expected(original.begin(),original.begin()+32);std::copy_n(Bytes{1,2,3}.data(),3,expected.data()+5);CHECK(read==expected);
    f.operations[0].padding=PaddingMode::Zero;s=compile(iso,f);InstallDiscOverlay(s);
    CHECK(planned_read(123,raw,0x20000,read.data(),read.size()));std::fill(expected.begin()+8,expected.begin()+15,0);CHECK(read==expected);
    std::string error; OverlaySnapshot invalid;
    f.operations[0].bytes=bytes(Bytes(11));CHECK(!CompileOverlay(raw,iso.size(),{f},invalid,error));CHECK(ActiveDiscOverlay()==s);
    for(size_t replacement_size : {size_t(5000),size_t(27),size_t(14000),size_t(0)}) {
        Bytes replacement(replacement_size,0x72);
        f.operations={{"whole",0,original.size(),true,true,PaddingMode::Original,"",bytes(replacement)}};
        s=compile(iso,f);InstallDiscOverlay(s);
        CHECK(s->RequiresReset());CHECK(s->files.size()==1);CHECK(s->files[0].image.size==replacement_size);
        RawReader effective=[&](uint64_t o,void*p,size_t n){return planned_read(123,raw,o,p,n);};
        XemuXdvdfs::Disc parsed;CHECK(XemuXdvdfs::Parse(effective,s->effective_length,parsed,error));
        auto *entry=XemuXdvdfs::FindRootFile(parsed,"sample.bin");CHECK(entry);CHECK(entry->size==replacement_size);
        CHECK(entry->disc_offset==s->files[0].disc_start);CHECK(entry->directory_entry_offset==0x10800);
        read.assign(s->files[0].reserved_size,0xaa);CHECK(effective(entry->disc_offset,read.data(),read.size()));
        CHECK(std::equal(replacement.begin(),replacement.end(),read.begin()));CHECK(std::all_of(read.begin()+replacement_size,read.end(),[](uint8_t v){return !v;}));
        CHECK(xemu_file_replace_disc_sectors(123,iso.size()/2048)==s->effective_length/2048);
        CHECK(xemu_file_replace_disc_sectors(124,iso.size()/2048)==iso.size()/2048);
        XemuFileReplaceReadPlan *pin=nullptr;CHECK(xemu_file_replace_plan_create(123,entry->disc_offset,read.size(),&pin)==1);
        ClearDiscOverlay();std::fill(read.begin(),read.end(),0xaa);
        CHECK(planned_read(123,raw,entry->disc_offset,read.data(),read.size(),pin));CHECK(std::equal(replacement.begin(),replacement.end(),read.begin()));
        xemu_file_replace_plan_release(pin);
        CHECK(iso==before);
    }
    CHECK(!CompileOverlay(raw,iso.size(),{f,f},invalid,error));
    f.operations.push_back({"bad overlap",5,3,false,false,PaddingMode::Original,"",bytes({1})});
    CHECK(!CompileOverlay(raw,iso.size(),{f},invalid,error));
}
static void raw_resize_fuzz() {
    std::mt19937 rng(316);
    for(int iteration=0;iteration<150;++iteration) {
        Bytes original(7000);for(auto &v:original)v=uint8_t(rng());
        Bytes iso=make_iso(original);RawReader raw=[&](uint64_t o,void*p,size_t n){return memory_read(iso,o,p,n);};
        CompileFile f=target(0x20000,original.size());Bytes expected=original;
        uint64_t offset=rng()%6000, oldsize=rng()%1000;Bytes replacement(rng()%3000);for(auto&v:replacement)v=uint8_t(rng());
        f.operations={{"splice",offset,oldsize,false,true,PaddingMode::Original,"",bytes(replacement)}};
        expected.erase(expected.begin()+offset,expected.begin()+offset+oldsize);
        expected.insert(expected.begin()+offset,replacement.begin(),replacement.end());
        auto s=compile(iso,f);InstallDiscOverlay(s);CHECK(s->files[0].image.size==expected.size());
        for(int j=0;j<20;++j) {
            size_t off=rng()%(expected.size()+1),n=std::min<size_t>(rng()%5000,expected.size()-off);Bytes b(n);
            CHECK(planned_read(123,raw,s->files[0].disc_start+off,b.data(),n));CHECK(std::equal(b.begin(),b.end(),expected.begin()+off));
        }
    }
}
static void olk_tests() {
    Bytes child=olk({Bytes(2048,0xa1),Bytes(3500,0xb2),{},Bytes(2500,0xc3)});
    Bytes original=olk({Bytes(2200,0x91),child,Bytes(2048,0xd4)});
    const uint64_t nested=2048+4096,leaf=nested+2048;
    Bytes iso=make_iso(original);
    RawReader raw=[&](uint64_t o,void*p,size_t n){return memory_read(iso,o,p,n);};
    CompileFile f=target(0x20000,original.size());
    f.operations={{"grow",leaf,2048,false,true,PaddingMode::Original,"olk",bytes(Bytes(5000,0xef))},
                  {"shrink",leaf+2048,3500,false,true,PaddingMode::Original,"olk",bytes(Bytes(100,0x72))}};
    auto s=compile(iso,f);InstallDiscOverlay(s);
    // +4096 first allocation, -2048 second allocation => +2048 at both levels.
    Bytes result(s->files[0].image.size);CHECK(planned_read(123,raw,s->files[0].disc_start,result.data(),result.size()));
    CHECK(result.size()==original.size()+2048);CHECK(get(result,20)==get(original,20)+2048);
    CHECK(get(result,36+16)==child.size()+2048);CHECK(get(result,32+32)==get(original,32+32)+2048);
    CHECK(get(result,nested+20)==get(original,nested+20)+2048);
    CHECK(get(result,nested+36)==5000);CHECK(get(result,nested+32+16)==6144);CHECK(get(result,nested+36+16)==100);
    CHECK(get(result,nested+32+32)==8192);CHECK(get(result,nested+32+48)==8192);
    CHECK(get(result,nested+40)==get(original,nested+40));
    CHECK(std::all_of(result.begin()+leaf,result.begin()+leaf+5000,[](uint8_t v){return v==0xef;}));
    CHECK(std::all_of(result.begin()+leaf+5000,result.begin()+leaf+6144,[](uint8_t v){return !v;}));
    CHECK(result.back()==0xd4);
    // Multiple malformed or ambiguous inputs reject without changing active data.
    std::string error;OverlaySnapshot fail;auto active=ActiveDiscOverlay();
    auto bad=f;bad.operations[0].offset++;CHECK(!CompileOverlay(raw,iso.size(),{bad},fail,error));CHECK(active==ActiveDiscOverlay());
    bad=f;bad.operations[0].size--;CHECK(!CompileOverlay(raw,iso.size(),{bad},fail,error));
    bad=f;bad.operations[0].fix_size="unknown";CHECK(!CompileOverlay(raw,iso.size(),{bad},fail,error));
    bad=f;bad.operations[0].fix_size.clear();CHECK(!CompileOverlay(raw,iso.size(),{bad},fail,error));
    bad=f;bad.operations.push_back({"manual table conflict",nested+36,4,false,false,PaddingMode::Zero,"",bytes({1,2,3,4})});
    CHECK(!CompileOverlay(raw,iso.size(),{bad},fail,error));
    Bytes corrupt=iso;put(corrupt,0x20000+nested+32+16,0);RawReader corrupted=[&](uint64_t o,void*p,size_t n){return memory_read(corrupt,o,p,n);};
    CHECK(!CompileOverlay(corrupted,corrupt.size(),{f},fail,error));
    // Shrink to zero stays structurally valid.
    f.operations.resize(1);f.operations[0].bytes=bytes({});s=compile(iso,f);CHECK(s->files[0].image.size==original.size()-2048);
}
static void retained_concurrency() {
    Bytes iso=make_iso(Bytes(2048,0x55));RawReader raw=[&](uint64_t o,void*p,size_t n){return memory_read(iso,o,p,n);};
    auto f=target(0x20000,2048);f.operations={{"whole",0,2048,true,true,PaddingMode::Zero,"",bytes(Bytes(4096,0x11))}};
    auto a=compile(iso,f);f.operations[0].bytes=bytes(Bytes(4096,0x22));auto b=compile(iso,f);
    std::atomic<bool> ok{true};InstallDiscOverlay(a);
    std::thread publish([&]{for(int i=0;i<2000;++i)InstallDiscOverlay(i%2?a:b);});
    std::thread consume([&]{for(int i=0;i<2000;++i){Bytes data(4096);if(!planned_read(123,raw,a->files[0].disc_start,data.data(),data.size()) ||
         !std::all_of(data.begin(),data.end(),[&](uint8_t v){return v==data[0];}) || (data[0]!=0x11 && data[0]!=0x22))ok=false;}});
    publish.join();consume.join();CHECK(ok);ClearDiscOverlay();
}
static void retail_olk(const char *path) {
    std::ifstream file(path,std::ios::binary);CHECK(bool(file));file.seekg(0,std::ios::end);auto size=uint64_t(file.tellg());
    RawReader read=[&](uint64_t o,void*p,size_t n){file.clear();file.seekg(std::streamoff(o));file.read(static_cast<char*>(p),std::streamsize(n));return size_t(file.gcount())==n;};
    std::vector<ImageEdit> edits;std::string error;
    bool ok=PlanOlkSizeFix(read,size,{},edits,error);if(!ok)std::cerr<<error<<"\n";CHECK(ok);CHECK(edits.empty());
    // Retail File5 / File952; growth crosses its original allocation.
    SizeFixRequest request{0x28b62000,0x1a8a00,bytes(Bytes(0x1b0001,0xa5)),"retail File952 growth"};
    CHECK(PlanOlkSizeFix(read,size,{request},edits,error));FileImage image;CHECK(BuildFileImage(0,size,edits,image,error));
    CHECK(image.size>size);std::cout<<"PASS real retail OLK metadata/leaf-resize validation ("<<size<<" original bytes)\n";
}
int main(int argc,char **argv) {
    fixed_and_whole_tests();raw_resize_fuzz();olk_tests();retained_concurrency();
    if(argc>1)retail_olk(argv[1]);
    std::cout<<"PASS v3.16 native core: "<<checks<<" assertions\n";
}
