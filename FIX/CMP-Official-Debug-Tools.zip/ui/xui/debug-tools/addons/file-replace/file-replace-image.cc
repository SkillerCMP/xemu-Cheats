#include "file-replace-image.hh"
#include <algorithm>
#include <cstring>
#include <limits>

namespace XemuFileReplace {
bool AddChecked(uint64_t a, uint64_t b, uint64_t &out)
{
    if (b > UINT64_MAX - a) return false;
    out = a + b;
    return true;
}
bool AlignChecked(uint64_t n, uint64_t alignment, uint64_t &out)
{
    if (!alignment || (alignment & (alignment - 1)) ||
        n > UINT64_MAX - (alignment - 1)) return false;
    out = (n + alignment - 1) & ~(alignment - 1);
    return true;
}
bool BuildFileImage(uint64_t disc_start, uint64_t original_size,
                    std::vector<ImageEdit> edits, FileImage &out, std::string &error)
{
    out = {};
    uint64_t physical_end;
    if (!AddChecked(disc_start, original_size, physical_end)) {
        error = "Original file extent overflows."; return false;
    }
    std::sort(edits.begin(), edits.end(), [](const ImageEdit &a, const ImageEdit &b) {
        return a.offset < b.offset;
    });
    uint64_t original_cursor = 0, output_cursor = 0;
    bool first = true;
    uint64_t last_offset = 0;
    auto append = [&](uint64_t count, ExtentKind kind, uint64_t source,
                      SharedBytes bytes = {}) {
        if (!count) return true;
        uint64_t end;
        if (!AddChecked(output_cursor, count, end) || end > UINT32_MAX) return false;
        out.extents.push_back({output_cursor, count, kind, source, std::move(bytes)});
        output_cursor = end;
        return true;
    };
    for (const auto &edit : edits) {
        const uint64_t payload_size = edit.payload ? edit.payload->size() : 0;
        if (edit.offset > original_size || edit.erase > original_size - edit.offset ||
            edit.offset < original_cursor || (!first && edit.offset == last_offset) ||
            payload_size > edit.allocation) {
            error = "Overlapping/out-of-bounds or invalid file edits: " + edit.id;
            out = {}; return false;
        }
        if (!append(edit.offset - original_cursor, ExtentKind::Disc,
                    disc_start + original_cursor) ||
            !append(payload_size, ExtentKind::Bytes, 0, edit.payload) ||
            !append(edit.allocation - payload_size, ExtentKind::Zero, 0)) {
            error = "Virtual file exceeds the XDVDFS 32-bit file-size limit.";
            out = {}; return false;
        }
        original_cursor = edit.offset + edit.erase;
        last_offset = edit.offset; first = false;
    }
    if (!append(original_size - original_cursor, ExtentKind::Disc,
                disc_start + original_cursor)) {
        error = "Virtual file exceeds the XDVDFS 32-bit file-size limit.";
        out = {}; return false;
    }
    out.size = output_cursor;
    return true;
}
bool ReadFileImage(const FileImage &image, const RawReader &reader,
                   uint64_t offset, void *buffer, size_t size)
{
    if (offset > image.size || size > image.size - offset || (!buffer && size)) return false;
    auto *dst = static_cast<uint8_t *>(buffer);
    const uint64_t end = offset + size;
    uint64_t covered = 0;
    for (const auto &e : image.extents) {
        const uint64_t lo = std::max(offset, e.start), hi = std::min(end, e.start + e.size);
        if (lo >= hi) continue;
        size_t count = static_cast<size_t>(hi - lo);
        uint64_t source = e.source + lo - e.start;
        if (e.kind == ExtentKind::Disc) {
            if (!reader(source, dst + lo - offset, count)) return false;
        } else if (e.kind == ExtentKind::Bytes) {
            if (!e.bytes || source > e.bytes->size() || count > e.bytes->size() - source) return false;
            std::memcpy(dst + lo - offset, e.bytes->data() + source, count);
        } else {
            std::memset(dst + lo - offset, 0, count);
        }
        covered += count;
    }
    return covered == size;
}
}
