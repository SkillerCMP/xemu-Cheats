//
// Generic DVD read overlay hook used by the File Replace add-on.
//
#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Apply active replacement bytes to an already-successful raw DVD payload.
 * disc_identity is the mounted BlockDriverState identity. The function is a
 * no-op when the active overlay was armed for a different disc. Returns the
 * number of bytes substituted/filled. */
size_t xemu_file_replace_disc_overlay_apply(uintptr_t disc_identity,
                                            uint64_t disc_offset,
                                            void *buffer, size_t size);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
/* One retained snapshot per submitted read. A plan never observes subsequent
 * activation/reload/clear operations. Return 0 for physical passthrough, 1 for
 * a planned read, or a negative errno. Release once after completion/cancel. */
typedef struct XemuFileReplaceReadPlan XemuFileReplaceReadPlan;
enum { XEMU_FR_DISC = 0, XEMU_FR_BYTES = 1, XEMU_FR_ZERO = 2 };
typedef struct XemuFileReplaceReadPiece {
    unsigned kind;
    uint64_t disc_offset;
    const uint8_t *bytes;
    size_t output_offset, size;
} XemuFileReplaceReadPiece;
int xemu_file_replace_plan_create(uintptr_t disc_identity, uint64_t offset,
                                  size_t size, XemuFileReplaceReadPlan **out);
size_t xemu_file_replace_plan_count(const XemuFileReplaceReadPlan *plan);
const XemuFileReplaceReadPiece *xemu_file_replace_plan_piece(
    const XemuFileReplaceReadPlan *plan, size_t index);
void xemu_file_replace_plan_release(XemuFileReplaceReadPlan *plan);
void xemu_file_replace_plan_completed(const XemuFileReplaceReadPlan *plan);
uint64_t xemu_file_replace_disc_sectors(uintptr_t disc_identity,
                                       uint64_t physical_sectors);
#ifdef __cplusplus
}
#endif
