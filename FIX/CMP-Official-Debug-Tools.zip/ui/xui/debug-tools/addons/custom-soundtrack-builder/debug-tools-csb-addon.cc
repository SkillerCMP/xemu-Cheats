#include "custom-soundtrack-builder.hh"

void debug_tools_register_csb_addition()
{
    XemuCsb::custom_soundtrack_builder.Register();
}
