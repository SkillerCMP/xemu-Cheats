#pragma once

#include "custom-soundtrack-hdd.hh"
#include "custom-soundtrack-builder-core.hh"

#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace XemuCsb {

class CustomSoundtrackBuilder {
public:
    bool is_open = false;

    void Register();
    void Tick();
    void Draw(bool detached);
    void Shutdown();
    void ProcessDeferredActions();
    void OnReset();

    void QueueDroppedFile(const char *path);

private:
    struct Track {
        std::string source_path;
        std::string title;
        uint32_t duration_ms = 0;
        std::string output_name;
        uint16_t song_id = 0;
        bool from_hdd = false;
        bool hdd_present = false;
    };

public:
    struct BuildTrack {
        std::string source_path;
        std::string title;
        uint16_t song_id = 0;
        uint32_t duration_ms = 0;
        bool from_hdd = false;
    };

private:
    struct BuildJob {
        CustomSoundtrackBuilder *owner = nullptr;
        std::vector<BuildTrack> tracks;
        std::vector<StDbSoundtrack> base_soundtracks;
        StDbWriteOptions db_write_options;
        std::string soundtrack_name;
        HddDestination destination;
        HddSoundtrackEdit edit;
        std::string ffmpeg;
        std::string staging_root;
        std::atomic<bool> cancel_requested{false};
        bool conversion_done = false;
        bool install_started = false;
        bool delete_soundtrack = false;
        uint16_t soundtrack_id = 0;
        std::atomic<unsigned int> completed{0};
        unsigned int conversion_total = 0;
        bool success = false;
        std::string status;
        std::string final_music_dir;
        std::vector<uint32_t> durations;
    };

    void AddTrack(const std::string &path);
    void RemoveTrack(size_t index);
    // A drop uses an insertion boundary (0..size), not a new Xbox song ID.
    bool ReorderTrack(uint16_t song_id, size_t insertion, uint64_t revision);
    void MarkEditorChanged();
    bool UiBusy() const;
    bool EditorReadOnly() const;
    bool EditorMatchesCatalog() const;
    enum class EditorAction { None, Select, New, Clear, Delete };
    void RequestEditorAction(EditorAction action, int soundtrack_id = -1);
    void ApplyEditorAction(EditorAction action, int soundtrack_id);
    void RequestTrackRename(uint16_t song_id);
    void DrawMenuBar();
    void DrawEditorPanel();
    void DrawDialogs();
    void BrowseForTrack();
    void FinishBuild(bool success, const std::string &status);
    bool ValidateBeforeBuild(std::string &error) const;
    void StartBuild();
    void StartDelete(uint16_t soundtrack_id);
    void OpenLastOutput();
    void DrawTrackTable();
    void DrawExistingCatalog();
    void LoadExistingSoundtrack(uint16_t soundtrack_id);
    void StartNewSoundtrack();
    uint16_t NextAvailableSongId() const;
    int NextAvailableSoundtrackId() const;
    const HddExistingSoundtrack *FindExisting(uint16_t soundtrack_id) const;
    std::vector<StDbSoundtrack> CatalogAsStDb() const;
    void RequestCatalogRefresh();

    static void BuildWorker(void *opaque);
    static void BuildComplete(void *opaque);

    std::vector<Track> m_tracks;
    // 64 UTF-16 code units from ST.DB may require more than 128 UTF-8 bytes.
    char m_soundtrack_name[256] = "XEMU Custom Soundtrack";
    HddDestination m_destination;
    HddDestination m_last_destination;
    HddSoundtrackInstaller m_installer;
    // CSB always leases TEST8 Fast Stream. Other HDD frontends are unchanged.
    bool m_editor_dirty = false;
    bool m_viewing_orphan = false;
    uint64_t m_editor_revision = 1;
    int m_selected_soundtrack_id = -1;
    int m_selected_song_id = -1;
    EditorAction m_pending_action = EditorAction::None;
    int m_pending_action_id = -1;
    HddMusicFingerprint m_pending_action_fingerprint;
    HddDestination m_pending_action_destination;
    HddMusicFingerprint m_delete_fingerprint;
    HddDestination m_delete_destination;
    std::string m_delete_name;
    int m_rename_song_id = -1;
    uint64_t m_rename_revision = 0;
    char m_rename_title[256] = {};
    bool m_open_output_requested = false;
    std::string m_ffmpeg_display;
    uint64_t m_next_ffmpeg_refresh = 0;
    int m_stream_chunk_index = kCsbDefaultStreamChunkIndex;
    HddMusicCatalog m_catalog;
    HddMusicFingerprint m_editor_fingerprint;
    HddDestination m_editor_destination;
    bool m_editor_catalog_valid = false;
    bool m_catalog_loaded = false;
    std::string m_catalog_status = "Soundtrack list has not been read yet.";
    bool m_catalog_refresh_requested = true;
    uint64_t m_next_catalog_refresh = 0;
    bool m_build_requested = false;
    bool m_cancel_requested = false;
    uint64_t m_next_destination_refresh = 0;
    int m_soundtrack_id = 0;
    int m_editing_existing_id = -1;
    int m_pending_delete_id = -1;
    bool m_delete_requested = false;
    std::string m_status = "Drop audio files here or use File > Add File.";
    std::string m_last_output;
    BuildJob *m_active_job = nullptr;

    std::mutex m_drop_mutex;
    std::vector<std::string> m_drop_queue;
    bool m_event_watch_installed = false;
};

extern CustomSoundtrackBuilder custom_soundtrack_builder;

} // namespace XemuCsb
