#include "custom-soundtrack-builder.hh"
#include "custom-soundtrack-builder-core.hh"

#include "../../debug-tools-module.hh"
#include "../../debug-tools.hh"
#include "../../detached-tools.hh"

#include "../../../common.hh"
#include "../../../misc.hh"

#include <SDL3/SDL.h>
#include <glib.h>
#include <imgui.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <set>
#include <utility>

#ifdef _WIN32
#include <windows.h>
#endif


namespace XemuCsb {
namespace {

namespace fs = std::filesystem;

bool HasSupportedAudioExtension(const std::string &path)
{
    std::string ext = fs::path(path).extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    static const std::array<const char *, 13> kExtensions = {
        ".mp3", ".wav", ".flac", ".m4a", ".mp4", ".aac", ".ogg",
        ".opus", ".wma", ".aif", ".aiff", ".mka", ".webm"
    };
    return std::find(kExtensions.begin(), kExtensions.end(), ext) != kExtensions.end();
}

std::string StemTitle(const std::string &path)
{
    std::string stem = fs::path(path).stem().u8string();
    if (stem.empty()) stem = "Track";
    return stem;
}

std::string JoinPath(const std::string &a, const std::string &b)
{
    gchar *joined = g_build_filename(a.c_str(), b.c_str(), nullptr);
    if (!joined) return {};
    std::string result(joined);
    g_free(joined);
    return result;
}

std::string FindFfmpeg()
{
    const char *base = SDL_GetBasePath();
    if (base && base[0]) {
#ifdef _WIN32
        const std::string adjacent = JoinPath(base, "ffmpeg.exe");
#else
        const std::string adjacent = JoinPath(base, "ffmpeg");
#endif
        if (!adjacent.empty() && g_file_test(adjacent.c_str(), G_FILE_TEST_IS_EXECUTABLE)) {
            return adjacent;
        }
    }

#ifdef _WIN32
    gchar *found = g_find_program_in_path("ffmpeg.exe");
#else
    gchar *found = g_find_program_in_path("ffmpeg");
#endif
    if (!found) return {};
    std::string result(found);
    g_free(found);
    return result;
}

#ifdef _WIN32
std::wstring Utf8ToWide(const std::string &text)
{
    if (text.empty()) return {};
    const int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS,
                                          text.c_str(), -1, nullptr, 0);
    if (count <= 0) return {};
    std::wstring wide(static_cast<size_t>(count), L'\0');
    if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.c_str(), -1,
                            wide.data(), count) <= 0) {
        return {};
    }
    wide.resize(static_cast<size_t>(count - 1));
    return wide;
}

std::wstring QuoteWindowsArg(const std::wstring &arg)
{
    if (arg.empty()) return L"\"\"";
    const bool needs_quotes = arg.find_first_of(L" \t\n\v\"") != std::wstring::npos;
    if (!needs_quotes) return arg;

    std::wstring quoted = L"\"";
    size_t backslashes = 0;
    for (wchar_t c : arg) {
        if (c == L'\\') {
            ++backslashes;
            continue;
        }
        if (c == L'\"') {
            quoted.append(backslashes * 2 + 1, L'\\');
            quoted.push_back(L'\"');
            backslashes = 0;
            continue;
        }
        quoted.append(backslashes, L'\\');
        backslashes = 0;
        quoted.push_back(c);
    }
    quoted.append(backslashes * 2, L'\\');
    quoted.push_back(L'\"');
    return quoted;
}

bool RunFfmpegConvertWindows(const std::vector<std::string> &args,
                             std::string &error)
{
    if (args.empty()) {
        error = "Unable to launch FFmpeg: empty command line";
        return false;
    }

    const std::wstring executable = Utf8ToWide(args.front());
    if (executable.empty()) {
        error = "Unable to launch FFmpeg: invalid executable path";
        return false;
    }

    std::wstring command_line;
    for (const std::string &arg : args) {
        const std::wstring wide = Utf8ToWide(arg);
        if (!arg.empty() && wide.empty()) {
            error = "Unable to launch FFmpeg: invalid UTF-8 command argument";
            return false;
        }
        if (!command_line.empty()) command_line.push_back(L' ');
        command_line += QuoteWindowsArg(wide);
    }

    SECURITY_ATTRIBUTES security = {};
    security.nLength = sizeof(security);
    security.bInheritHandle = TRUE;

    HANDLE stderr_read = nullptr;
    HANDLE stderr_write = nullptr;
    if (!CreatePipe(&stderr_read, &stderr_write, &security, 0)) {
        error = "Unable to launch FFmpeg: CreatePipe failed (Windows error " +
                std::to_string(GetLastError()) + ")";
        return false;
    }
    SetHandleInformation(stderr_read, HANDLE_FLAG_INHERIT, 0);

    HANDLE null_input = CreateFileW(L"NUL", GENERIC_READ,
                                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                                    &security, OPEN_EXISTING,
                                    FILE_ATTRIBUTE_NORMAL, nullptr);
    if (null_input == INVALID_HANDLE_VALUE) null_input = nullptr;

    HANDLE null_output = CreateFileW(L"NUL", GENERIC_WRITE,
                                     FILE_SHARE_READ | FILE_SHARE_WRITE,
                                     &security, OPEN_EXISTING,
                                     FILE_ATTRIBUTE_NORMAL, nullptr);
    if (null_output == INVALID_HANDLE_VALUE) null_output = nullptr;

    STARTUPINFOW startup = {};
    startup.cb = sizeof(startup);
    startup.dwFlags = STARTF_USESTDHANDLES;
    startup.hStdInput = null_input ? null_input : GetStdHandle(STD_INPUT_HANDLE);
    startup.hStdOutput = null_output ? null_output : GetStdHandle(STD_OUTPUT_HANDLE);
    startup.hStdError = stderr_write;

    PROCESS_INFORMATION process = {};
    const BOOL created = CreateProcessW(
        executable.c_str(), command_line.data(), nullptr, nullptr, TRUE,
        CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process);
    const DWORD create_error = created ? ERROR_SUCCESS : GetLastError();

    CloseHandle(stderr_write);
    if (null_input) CloseHandle(null_input);
    if (null_output) CloseHandle(null_output);

    if (!created) {
        CloseHandle(stderr_read);
        error = "Unable to launch FFmpeg: CreateProcessW failed (Windows error " +
                std::to_string(create_error) + ")";
        return false;
    }

    std::string standard_error;
    std::array<char, 4096> buffer = {};
    for (;;) {
        DWORD got = 0;
        if (!ReadFile(stderr_read, buffer.data(),
                      static_cast<DWORD>(buffer.size()), &got, nullptr) || got == 0) {
            break;
        }
        standard_error.append(buffer.data(), static_cast<size_t>(got));
    }
    CloseHandle(stderr_read);

    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD exit_code = 1;
    GetExitCodeProcess(process.hProcess, &exit_code);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);

    while (!standard_error.empty() &&
           (standard_error.back() == '\r' || standard_error.back() == '\n')) {
        standard_error.pop_back();
    }

    if (exit_code != 0) {
        error = "FFmpeg conversion failed";
        if (!standard_error.empty()) {
            error += ": ";
            error += standard_error;
        } else {
            error += " (exit code " + std::to_string(exit_code) + ")";
        }
        return false;
    }
    return true;
}
#endif

bool RunFfmpegConvert(const std::string &ffmpeg,
                      const std::string &input,
                      const std::string &output,
                      std::string &error)
{
    std::vector<std::string> args = {
        ffmpeg,
        "-hide_banner", "-loglevel", "error", "-y",
        "-i", input,
        "-map_metadata", "-1",
        "-vn",
        "-ac", "2",
        "-ar", "44100",
        "-c:a", "wmav2",
        "-b:a", "128k",
        output,
    };

#ifdef _WIN32
    // GLib's g_spawn_sync() requires gspawn-win64-helper.exe on Windows.
    // xemu's static Windows package does not ship that helper, so execute
    // FFmpeg directly through Win32 instead.
    return RunFfmpegConvertWindows(args, error);
#else
    std::vector<gchar *> argv;
    argv.reserve(args.size() + 1);
    for (std::string &arg : args) argv.push_back(arg.data());
    argv.push_back(nullptr);

    gchar *standard_error = nullptr;
    gint exit_status = -1;
    GError *spawn_error = nullptr;
    const gboolean spawned = g_spawn_sync(
        nullptr, argv.data(), nullptr,
        static_cast<GSpawnFlags>(G_SPAWN_STDOUT_TO_DEV_NULL),
        nullptr, nullptr, nullptr, &standard_error, &exit_status, &spawn_error);
    if (!spawned) {
        error = "Unable to launch FFmpeg: ";
        error += spawn_error ? spawn_error->message : "unknown process error";
        if (spawn_error) g_error_free(spawn_error);
        g_free(standard_error);
        return false;
    }

    GError *status_error = nullptr;
    const gboolean ok = g_spawn_check_wait_status(exit_status, &status_error);
    if (!ok) {
        error = "FFmpeg conversion failed";
        if (standard_error && standard_error[0]) {
            error += ": ";
            error += standard_error;
        } else if (status_error) {
            error += ": ";
            error += status_error->message;
        }
        if (status_error) g_error_free(status_error);
        g_free(standard_error);
        return false;
    }
    if (status_error) g_error_free(status_error);
    g_free(standard_error);
    return true;
#endif
}

bool RemoveTree(const std::string &path, std::string &error)
{
    std::error_code ec;
    fs::remove_all(fs::u8path(path), ec);
    if (ec) {
        error = "Unable to remove staging folder: " + ec.message();
        return false;
    }
    return true;
}


std::string EscapeJson(const std::string &text)
{
    std::ostringstream out;
    for (unsigned char c : text) {
        switch (c) {
        case '\\': out << "\\\\"; break;
        case '"': out << "\\\""; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default:
            if (c < 0x20) {
                char buf[8];
                std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                out << buf;
            } else {
                out << static_cast<char>(c);
            }
            break;
        }
    }
    return out.str();
}

bool WriteBuildManifest(const std::string &path,
                        const std::string &soundtrack_name,
                        uint16_t soundtrack_id,
                        const std::vector<CustomSoundtrackBuilder::BuildTrack> &tracks,
                        const std::vector<uint32_t> &durations,
                        std::string &error)
{
    std::ofstream out(fs::u8path(path), std::ios::binary | std::ios::trunc);
    if (!out) {
        error = "Unable to create CSB build manifest.";
        return false;
    }
    out << "{\n  \"format\": \"xemu-csb-1\",\n"
        << "  \"soundtrack_name\": \"" << EscapeJson(soundtrack_name) << "\",\n"
        << "  \"soundtrack_id\": " << soundtrack_id << ",\n"
        << "  \"tracks\": [\n";
    for (size_t i = 0; i < tracks.size(); ++i) {
        const auto &t = tracks[i];
        out << "    {\"song_id\": " << t.song_id
            << ", \"title\": \"" << EscapeJson(t.title)
            << "\", \"source\": \"" << EscapeJson(t.source_path)
            << "\", \"output\": \"" << XboxSoundtrackFileName(soundtrack_id, t.song_id)
            << "\", \"duration_ms\": " << durations[i] << "}";
        if (i + 1 != tracks.size()) out << ',';
        out << '\n';
    }
    out << "  ]\n}\n";
    if (!out) {
        error = "Unable to finish CSB build manifest.";
        return false;
    }
    return true;
}

bool SDLCALL CsbEventWatch(void *userdata, SDL_Event *event)
{
    auto *builder = static_cast<CustomSoundtrackBuilder *>(userdata);
    if (!builder || !event) return true;
    if (event->type == SDL_EVENT_DROP_FILE && event->drop.data) {
        builder->QueueDroppedFile(event->drop.data);
    }
    return true;
}

void DrawCsbDetached()
{
    custom_soundtrack_builder.Draw(true);
}

void TickCsb()
{
    custom_soundtrack_builder.Tick();
}

void ProcessCsbDeferred()
{
    custom_soundtrack_builder.ProcessDeferredActions();
}

void ResetCsb()
{
    custom_soundtrack_builder.OnReset();
}

void CleanupCsb()
{
    custom_soundtrack_builder.Shutdown();
}

} // namespace

CustomSoundtrackBuilder custom_soundtrack_builder;

void CustomSoundtrackBuilder::Register()
{
    if (!m_event_watch_installed) {
        SDL_AddEventWatch(CsbEventWatch, this);
        m_event_watch_installed = true;
    }

    debug_tools_register_menu_item(250, "CSB", &is_open);
    debug_tools_register_tick(225, TickCsb);
    debug_tools_register_cleanup(225, CleanupCsb);
    debug_tools_register_deferred_action(225, ProcessCsbDeferred);
    debug_tools_register_reset(225, ResetCsb);
    detached_tools_register({
        "xemu - Custom Soundtrack Builder",
        1480, 820,
        1100, 620,
        &is_open,
        DrawCsbDetached,
        250,
        false,
    });
}

void CustomSoundtrackBuilder::Shutdown()
{
    m_build_requested = false;
    m_delete_requested = false;
    m_installer.Shutdown();
    delete m_active_job;
    m_active_job = nullptr;
    if (m_event_watch_installed) {
        SDL_RemoveEventWatch(CsbEventWatch, this);
        m_event_watch_installed = false;
    }
}

void CustomSoundtrackBuilder::QueueDroppedFile(const char *path)
{
    if (!path || !path[0]) return;
    std::lock_guard<std::mutex> lock(m_drop_mutex);
    m_drop_queue.emplace_back(path);
}

void CustomSoundtrackBuilder::Tick()
{
    std::vector<std::string> pending;
    {
        std::lock_guard<std::mutex> lock(m_drop_mutex);
        pending.swap(m_drop_queue);
    }
    if (!is_open) return;
    for (const std::string &path : pending) AddTrack(path);
}

void CustomSoundtrackBuilder::RequestCatalogRefresh()
{
    m_catalog_refresh_requested = true;
    m_next_catalog_refresh = 0;
}

const HddExistingSoundtrack *CustomSoundtrackBuilder::FindExisting(uint16_t id) const
{
    for (const auto &soundtrack : m_catalog.soundtracks) {
        if (soundtrack.soundtrack_id == id) return &soundtrack;
    }
    return nullptr;
}

int CustomSoundtrackBuilder::NextAvailableSoundtrackId() const
{
    const uint32_t preferred = m_catalog.database_valid ? m_catalog.next_soundtrack_id : 0;
    const uint32_t first = std::min<uint32_t>(preferred, 0xFFFFu);
    for (uint32_t id = first; id <= 0xFFFFu; ++id) {
        if (!FindExisting(static_cast<uint16_t>(id))) return static_cast<int>(id);
    }
    for (uint32_t id = 0; id < first; ++id) {
        if (!FindExisting(static_cast<uint16_t>(id))) return static_cast<int>(id);
    }
    return 0;
}

uint16_t CustomSoundtrackBuilder::NextAvailableSongId() const
{
    auto used = [&](uint16_t candidate) {
        for (const auto &soundtrack : m_catalog.soundtracks) {
            if (!soundtrack.listed_in_database) continue;
            for (const auto &track : soundtrack.tracks)
                if (track.song_id == candidate) return true;
        }
        for (const auto &track : m_tracks)
            if (track.song_id == candidate) return true;
        return false;
    };
    const uint32_t preferred = m_catalog.database_valid ? m_catalog.next_song_id : 0;
    const uint32_t first = std::min<uint32_t>(preferred, 0xFFFFu);
    for (uint32_t id = first; id <= 0xFFFFu; ++id)
        if (!used(static_cast<uint16_t>(id))) return static_cast<uint16_t>(id);
    for (uint32_t id = 0; id < first; ++id)
        if (!used(static_cast<uint16_t>(id))) return static_cast<uint16_t>(id);
    return 0;
}

std::vector<StDbSoundtrack> CustomSoundtrackBuilder::CatalogAsStDb() const
{
    std::vector<StDbSoundtrack> result;
    if (!m_catalog.database_valid) return result;
    for (const auto &soundtrack : m_catalog.soundtracks) {
        if (!soundtrack.listed_in_database) continue;
        StDbSoundtrack out;
        out.soundtrack_id = soundtrack.soundtrack_id;
        out.name = soundtrack.name;
        for (const auto &track : soundtrack.tracks) {
            out.tracks.push_back({track.song_id, track.duration_ms, track.title});
        }
        result.push_back(std::move(out));
    }
    return result;
}

void CustomSoundtrackBuilder::StartNewSoundtrack()
{
    if (UiBusy()) return;
    m_tracks.clear();
    m_editor_dirty = false;
    m_viewing_orphan = false;
    m_selected_soundtrack_id = -1;
    m_selected_song_id = -1;
    m_rename_song_id = -1;
    ++m_editor_revision;
    m_editing_existing_id = -1;
    m_pending_delete_id = -1;
    m_soundtrack_id = NextAvailableSoundtrackId();
    m_editor_fingerprint = m_catalog.fingerprint;
    m_editor_destination = m_destination;
    m_editor_catalog_valid = m_catalog_loaded;
    std::snprintf(m_soundtrack_name, sizeof(m_soundtrack_name), "%s", "XEMU Custom Soundtrack");
    m_status = "New soundtrack editor ready. The first unused ID was selected automatically.";
}

void CustomSoundtrackBuilder::LoadExistingSoundtrack(uint16_t id)
{
    if (UiBusy() || !m_catalog_loaded) return;
    const auto *soundtrack = FindExisting(id);
    if (!soundtrack) { m_status = "That soundtrack is no longer in the current HDD catalog."; return; }
    m_viewing_orphan = !soundtrack->listed_in_database;
    m_editor_dirty = false;
    m_selected_soundtrack_id = id;
    m_selected_song_id = -1;
    m_rename_song_id = -1;
    ++m_editor_revision;
    m_tracks.clear();
    m_soundtrack_id = id;
    m_editing_existing_id = m_viewing_orphan ? -1 : id;
    m_editor_fingerprint = m_catalog.fingerprint;
    m_editor_destination = m_destination;
    m_editor_catalog_valid = true;
    m_pending_delete_id = -1;
    std::snprintf(m_soundtrack_name, sizeof(m_soundtrack_name), "%s", soundtrack->name.c_str());
    for (const auto &item : soundtrack->tracks) {
        Track track;
        track.title = item.title;
        track.duration_ms = item.duration_ms;
        track.song_id = item.song_id;
        track.output_name = item.file_name;
        track.from_hdd = true;
        track.hdd_present = item.file_present;
        track.source_path = "E:\\TDATA\\fffe0000\\music\\" +
                            XboxSoundtrackFolderName(id) + "\\" + item.file_name;
        m_tracks.push_back(std::move(track));
    }
    m_status = m_viewing_orphan
        ? "Unlisted/orphan folder: files are shown read-only. CSB will not invent ST.DB entries or overwrite this ID. Right-click the soundtrack to delete it with confirmation."
        : "Loaded soundtrack ID " + std::to_string(id) + " from the mounted HDD. Changes are pending until SAVE.";
}

void CustomSoundtrackBuilder::AddTrack(const std::string &path)
{
    if (EditorReadOnly()) { m_status = "Finish the current operation/dialog or select an editable soundtrack before adding files."; return; }
    if (!g_file_test(path.c_str(), G_FILE_TEST_IS_REGULAR)) { m_status = "Dropped path is not a regular file: " + path; return; }
    if (!HasSupportedAudioExtension(path)) {
        m_status = "Unsupported extension. CSB accepts MP3, WAV, FLAC, M4A/MP4, AAC, OGG, Opus, WMA, AIFF, MKA and WebM audio.";
        return;
    }
    if (m_tracks.size() >= 504) { m_status = "The Xbox ST.DB format allows at most 504 songs in one soundtrack."; return; }
    Track track;
    track.source_path = path;
    track.title = StemTitle(path);
    track.song_id = NextAvailableSongId();
    track.output_name = XboxSoundtrackFileName(static_cast<uint16_t>(std::clamp(m_soundtrack_id, 0, 65535)), track.song_id);
    m_selected_song_id = track.song_id;
    m_tracks.push_back(std::move(track));
    MarkEditorChanged();
    m_status = "Added " + fs::path(path).filename().u8string() + " to the editor.";
}

void CustomSoundtrackBuilder::RemoveTrack(size_t index)
{
    if (index >= m_tracks.size() || EditorReadOnly()) return;
    const bool was_hdd = m_tracks[index].from_hdd;
    const std::string name = m_tracks[index].title;
    if (m_selected_song_id == m_tracks[index].song_id) m_selected_song_id = -1;
    m_tracks.erase(m_tracks.begin() + static_cast<std::ptrdiff_t>(index));
    MarkEditorChanged();
    m_status = was_hdd ? ("Removed '" + name + "' from the pending soundtrack update. The HDD file is untouched until SAVE.")
                       : ("Removed '" + name + "' from the pending list.");
}

bool CustomSoundtrackBuilder::UiBusy() const
{
    return m_active_job != nullptr || m_build_requested || m_delete_requested;
}

bool CustomSoundtrackBuilder::EditorReadOnly() const
{
    return UiBusy() || m_viewing_orphan || m_pending_action != EditorAction::None ||
           m_pending_delete_id >= 0 || m_rename_song_id >= 0;
}

bool CustomSoundtrackBuilder::EditorMatchesCatalog() const
{
    return m_catalog_loaded && m_editor_catalog_valid &&
           SameCsbHddDestination(m_editor_destination, m_destination) &&
           m_editor_fingerprint == m_catalog.fingerprint;
}

void CustomSoundtrackBuilder::MarkEditorChanged()
{
    m_editor_dirty = true;
    ++m_editor_revision; // Invalidates drags/rename dialogs from a prior list.
}

bool CustomSoundtrackBuilder::ReorderTrack(uint16_t song_id, size_t insertion,
                                           uint64_t revision)
{
    if (EditorReadOnly() || revision != m_editor_revision || insertion > m_tracks.size())
        return false;
    const auto it = std::find_if(m_tracks.begin(), m_tracks.end(),
                                [song_id](const Track &t) { return t.song_id == song_id; });
    if (it == m_tracks.end()) return false;
    const size_t from = static_cast<size_t>(it - m_tracks.begin());
    const size_t to = insertion > from ? insertion - 1 : insertion;
    if (to == from) return false;
    // Move the WHOLE row: filename, stable song ID, duration and source follow it.
    if (to < from) std::rotate(m_tracks.begin() + to, it, it + 1);
    else std::rotate(it, it + 1, m_tracks.begin() + to + 1);
    m_selected_song_id = song_id;
    MarkEditorChanged();
    m_status = "Track order updated in the editor. Xbox file IDs are preserved; SAVE applies the new order.";
    return true;
}

void CustomSoundtrackBuilder::RequestEditorAction(EditorAction action, int id)
{
    if (UiBusy() || m_pending_action != EditorAction::None ||
        m_pending_delete_id >= 0 || m_rename_song_id >= 0) return;
    if (action == EditorAction::Select && id == m_selected_soundtrack_id &&
        EditorMatchesCatalog()) return; // Clicking the current row must not erase edits.
    if ((action == EditorAction::Select || action == EditorAction::Delete) &&
        (id < 0 || id > 65535 || !m_catalog_loaded || !FindExisting(static_cast<uint16_t>(id)))) {
        m_status = "Refresh HDD Music before selecting or deleting that soundtrack.";
        return;
    }
    if (m_editor_dirty && action != EditorAction::Clear) {
        m_pending_action = action;
        m_pending_action_id = id;
        m_pending_action_fingerprint = m_catalog.fingerprint;
        m_pending_action_destination = m_destination;
        return;
    }
    // Clear is itself a pending edit, but it still requires confirmation when nonempty.
    if (action == EditorAction::Clear && !m_tracks.empty()) {
        m_pending_action = action;
        m_pending_action_id = id;
        m_pending_action_fingerprint = m_catalog.fingerprint;
        m_pending_action_destination = m_destination;
        return;
    }
    ApplyEditorAction(action, id);
}

void CustomSoundtrackBuilder::ApplyEditorAction(EditorAction action, int id)
{
    if (UiBusy()) return;
    switch (action) {
    case EditorAction::Select:
        LoadExistingSoundtrack(static_cast<uint16_t>(id));
        break;
    case EditorAction::New:
        StartNewSoundtrack();
        break;
    case EditorAction::Clear:
        if (m_viewing_orphan || m_tracks.empty()) break;
        m_tracks.clear();
        m_selected_song_id = -1;
        MarkEditorChanged();
        m_status = "Editor track list cleared. No HDD files were deleted. Add tracks before SAVE, or right-click the soundtrack to delete it entirely.";
        break;
    case EditorAction::Delete: {
        const auto *existing = id >= 0 && id <= 65535 ? FindExisting(static_cast<uint16_t>(id)) : nullptr;
        if (!m_catalog_loaded || !existing) { m_status = "That soundtrack is no longer in the catalog. Refresh first."; break; }
        // Show exactly the soundtrack being confirmed, not another editor's tracks.
        LoadExistingSoundtrack(static_cast<uint16_t>(id));
        m_pending_delete_id = id;
        m_delete_name = existing->name;
        m_delete_fingerprint = m_catalog.fingerprint;
        m_delete_destination = m_destination;
        break;
    }
    case EditorAction::None:
        break;
    }
}

void CustomSoundtrackBuilder::RequestTrackRename(uint16_t song_id)
{
    if (EditorReadOnly()) return;
    for (const auto &track : m_tracks) if (track.song_id == song_id) {
        m_rename_song_id = song_id;
        m_rename_revision = m_editor_revision;
        std::snprintf(m_rename_title, sizeof(m_rename_title), "%s", track.title.c_str());
        return;
    }
}

void CustomSoundtrackBuilder::BrowseForTrack()
{
    static const SDL_DialogFileFilter filters[] = {
        {"Audio Files", "mp3;wav;flac;m4a;mp4;aac;ogg;opus;wma;aif;aiff;mka;webm"},
        {"All Files", "*"},
    };
    ShowOpenFileDialog(filters, 2, nullptr, [this](const char *path) {
        if (path && path[0]) AddTrack(path);
    });
}

void CustomSoundtrackBuilder::OnReset()
{
    m_build_requested = false;
    m_delete_requested = false;
    m_next_destination_refresh = 0;
    m_pending_action = EditorAction::None;
    m_pending_delete_id = -1;
    m_rename_song_id = -1;
    ++m_editor_revision;
    RequestCatalogRefresh();
    if (m_active_job) m_active_job->cancel_requested.store(true);
    m_installer.Cancel("Xbox reset during soundtrack installation; remaining work was cancelled. Inspect retained staging/backup in HDD Directory before retrying.", false);
}

void CustomSoundtrackBuilder::ProcessDeferredActions()
{
    if (m_cancel_requested) {
        m_cancel_requested = false;
        if (m_active_job) m_active_job->cancel_requested.store(true);
        m_installer.Cancel("Cancelled by the user.");
        m_status = "Cancel requested. An active conversion/kernel call must finish safely; no forced stack unwind is used.";
    }
    const uint64_t now = SDL_GetTicks();
    if (is_open && now >= m_next_ffmpeg_refresh) {
        m_ffmpeg_display = FindFfmpeg();
        m_next_ffmpeg_refresh = now + 2000;
    }
    if (is_open || m_active_job || m_build_requested || m_delete_requested) {
        if (now >= m_next_destination_refresh || m_build_requested || m_delete_requested) {
            HddDestination detected = DetectCsbHddDestination();
            const bool changed = detected.source != m_destination.source ||
                                 detected.identity != m_destination.identity ||
                                 detected.selected_path != m_destination.selected_path ||
                                 detected.mounted_path != m_destination.mounted_path ||
                                 detected.available != m_destination.available;
            m_destination = std::move(detected);
            m_next_destination_refresh = now + 250;
            if (changed) RequestCatalogRefresh();
        }
    }

    if (is_open && !m_active_job && !m_installer.Busy() &&
        (m_catalog_refresh_requested || now >= m_next_catalog_refresh)) {
        m_catalog_refresh_requested = false;
        m_next_catalog_refresh = now + 1500;
        if (!m_destination.available) {
            m_catalog = {};
            m_catalog_loaded = false;
            m_catalog_status = m_destination.reason.empty() ? "No active HDD soundtrack source." : m_destination.reason;
        } else {
            std::string error;
            HddMusicCatalog catalog;
            if (ReadCsbHddMusicCatalog(m_destination, catalog, error)) {
                m_catalog = std::move(catalog);
                m_catalog_loaded = true;
                if (!m_editor_catalog_valid) {
                    m_editor_fingerprint = m_catalog.fingerprint;
                    m_editor_destination = m_destination;
                    m_editor_catalog_valid = true;
                    if (m_tracks.empty() && m_editing_existing_id < 0)
                        m_soundtrack_id = NextAvailableSoundtrackId();
                }
                if (!m_catalog.music_exists) m_catalog_status = "No existing E:\\TDATA\\fffe0000\\music folder. A new collection can be created.";
                else if (m_catalog.empty_music_directory) m_catalog_status = "The music directory is empty. A new collection can be created.";
                else if (m_catalog.database_valid) m_catalog_status = "Loaded " + std::to_string(m_catalog.soundtracks.size()) + " soundtrack folder/record(s) from the active HDD.";
                else m_catalog_status = "Music folder found, but ST.DB is missing/invalid. Existing folders are shown read-only except DELETE.";
            } else {
                m_catalog_loaded = false;
                m_catalog_status = "Unable to read existing HDD soundtracks: " + error;
            }
        }
    }

    if (m_active_job && m_active_job->conversion_done) {
        BuildJob *job = m_active_job;
        if (!job->success) {
            FinishBuild(false, job->status);
        } else if (job->cancel_requested.load() && !job->install_started) {
            FinishBuild(false, "CSB operation cancelled. Local output kept at " + job->final_music_dir);
        } else if (!job->install_started) {
            std::string error;
            if (!m_installer.Start(job->destination, job->final_music_dir, job->edit, error)) {
                FinishBuild(false, error + " Local output kept at " + job->final_music_dir);
            } else {
                job->install_started = true;
                m_status = m_installer.Status();
            }
        } else {
            m_installer.Tick();
            m_status = m_installer.Status();
            if (!m_installer.Busy()) FinishBuild(m_installer.Succeeded(), m_status);
        }
    }
    if (m_build_requested) { m_build_requested = false; StartBuild(); }
    if (m_delete_requested) {
        m_delete_requested = false;
        if (m_pending_delete_id >= 0) StartDelete(static_cast<uint16_t>(m_pending_delete_id));
        m_pending_delete_id = -1;
    }
    if (m_open_output_requested) {
        m_open_output_requested = false;
        OpenLastOutput();
    }
}

void CustomSoundtrackBuilder::FinishBuild(bool success, const std::string &status)
{
    m_status = status;
    RequestCatalogRefresh();
    BuildJob *job = m_active_job;
    if (!job) return;
    if (success) {
        m_editor_dirty = false;
        m_viewing_orphan = false;
        ++m_editor_revision;
        m_selected_soundtrack_id = job->delete_soundtrack ? -1 : job->soundtrack_id;
        m_last_destination = job->destination;
        m_last_output = m_installer.OutputPath();
        if (!job->delete_soundtrack) {
            for (size_t i = 0; i < m_tracks.size() && i < job->durations.size(); ++i) {
                auto &track = m_tracks[i];
                track.duration_ms = job->durations[i];
                track.from_hdd = true;
                track.hdd_present = true;
                track.output_name = XboxSoundtrackFileName(job->soundtrack_id, track.song_id);
                track.source_path = "E:/TDATA/fffe0000/music/" +
                    XboxSoundtrackFolderName(job->soundtrack_id) + "/" + track.output_name;
            }
        }
        std::string cleanup_error;
        if (!job->staging_root.empty() && !RemoveTree(job->staging_root, cleanup_error))
            m_status += " Local staging cleanup failed: " + cleanup_error;
        m_editor_catalog_valid = false;
        RequestCatalogRefresh();
        m_catalog_loaded = false;
        if (job->delete_soundtrack) {
            m_tracks.clear(); m_editing_existing_id = -1; m_pending_delete_id = -1;
            m_selected_song_id = -1;
        } else m_editing_existing_id = job->soundtrack_id;
    }
    m_active_job = nullptr;
    delete job;
}

bool CustomSoundtrackBuilder::ValidateBeforeBuild(std::string &error) const
{
    if (m_active_job) { error = "A CSB operation is already running."; return false; }
    if (m_viewing_orphan || m_pending_action != EditorAction::None || m_pending_delete_id >= 0 || m_rename_song_id >= 0) {
        error = "Select an editable soundtrack and finish the open dialog before saving."; return false;
    }
    if (!m_catalog_loaded) { error = "Wait for CSB to read the existing HDD soundtrack list, or press REFRESH HDD MUSIC."; return false; }
    if (m_catalog.music_exists && !m_catalog.database_valid && !m_catalog.empty_music_directory) {
        error = "Existing music cannot be safely merged because ST.DB is missing or invalid. Delete/repair the orphan collection in HDD Directory first.";
        return false;
    }
    if (m_tracks.empty()) { error = "Add at least one track. To remove an entire existing soundtrack, right-click it and choose Delete."; return false; }
    if (m_soundtrack_name[0] == '\0') { error = "Enter a soundtrack name."; return false; }
    if (!m_destination.available) { error = m_destination.reason.empty() ? "No active HDD destination." : m_destination.reason; return false; }
    if (!CsbHddReady(error)) return false;
    if (m_soundtrack_id < 0 || m_soundtrack_id > 65535) { error = "Soundtrack ID must be between 0 and 65535."; return false; }
    const auto *existing = FindExisting(static_cast<uint16_t>(m_soundtrack_id));
    const bool editing = m_editing_existing_id == m_soundtrack_id;
    if (existing && !editing) {
        error = existing->listed_in_database ? "That soundtrack ID already exists. Click that soundtrack to edit it instead of overwriting it."
                                             : "That ID already has an unlisted/orphan folder. Delete or inspect it before creating a soundtrack with this ID.";
        return false;
    }
    if (editing && (!existing || !existing->listed_in_database)) { error = "The soundtrack being edited is no longer present in ST.DB. Refresh first."; return false; }
    bool needs_ffmpeg = false;
    for (const Track &track : m_tracks) {
        if (track.title.empty()) { error = "Every track must have a display name."; return false; }
        if (track.from_hdd) {
            if (!track.hdd_present) { error = "An existing track file is missing on the HDD. Remove that broken row before SAVE or restore its WMA first."; return false; }
        } else {
            needs_ffmpeg = true;
            if (!g_file_test(track.source_path.c_str(), G_FILE_TEST_IS_REGULAR)) { error = "Source file no longer exists: " + track.source_path; return false; }
        }
    }
    if (needs_ffmpeg && FindFfmpeg().empty()) { error = "FFmpeg was not found. Put ffmpeg/ffmpeg.exe beside xemu or add it to PATH."; return false; }
    return true;
}

void CustomSoundtrackBuilder::StartBuild()
{
    std::string error;
    if (!ValidateBeforeBuild(error)) { m_status = error; return; }
    if (!m_editor_catalog_valid || !SameCsbHddDestination(m_editor_destination, m_destination) ||
        !(m_editor_fingerprint == m_catalog.fingerprint)) {
        m_status = "HDD music changed while these edits were pending. Refresh and select the soundtrack again (or New Soundtrack); pending edits will not overwrite a changed collection.";
        return;
    }
    auto *job = new BuildJob;
    job->owner = this;
    job->soundtrack_name = m_soundtrack_name;
    job->destination = m_destination;
    job->ffmpeg = FindFfmpeg();
    job->soundtrack_id = static_cast<uint16_t>(m_soundtrack_id);
    job->base_soundtracks = CatalogAsStDb();
    job->db_write_options.minimum_next_soundtrack_id = m_catalog.next_soundtrack_id;
    job->db_write_options.minimum_next_song_id = m_catalog.next_song_id;
    job->edit.fast_stream = true; // Always TEST8 Fast Stream for CSB.
    job->edit.stream_chunk_bytes = kCsbStreamChunks[
        m_stream_chunk_index >= 0 && m_stream_chunk_index < 4 ?
            m_stream_chunk_index : kCsbDefaultStreamChunkIndex];
    job->edit.soundtrack_id = job->soundtrack_id;
    job->edit.target_existed = m_editing_existing_id == m_soundtrack_id;
    job->edit.expected_fingerprint = m_editor_fingerprint;
    job->tracks.reserve(m_tracks.size());
    job->durations.resize(m_tracks.size(), 0);
    for (size_t i = 0; i < m_tracks.size(); ++i) {
        const Track &track = m_tracks[i];
        job->tracks.push_back({track.source_path, track.title, track.song_id, track.duration_ms, track.from_hdd});
        job->durations[i] = track.duration_ms;
        if (track.from_hdd) job->edit.retained_song_ids.push_back(track.song_id);
        else { job->edit.local_song_ids.push_back(track.song_id); ++job->conversion_total; }
    }
    m_active_job = job;
    m_status = job->conversion_total ? "Converting new tracks to Xbox WMAudio2..." : "Rebuilding ST.DB for the pending soundtrack changes...";
    if (!debug_tools_queue_background_job(BuildWorker, job, BuildComplete, false)) {
        m_active_job = nullptr; delete job; m_status = "Debug Tools background worker is unavailable.";
    }
}

void CustomSoundtrackBuilder::StartDelete(uint16_t soundtrack_id)
{
    if (m_active_job) return;
    if (!m_catalog_loaded) { m_status = "Refresh the HDD soundtrack list before deleting."; return; }
    if (m_pending_delete_id != soundtrack_id ||
        !SameCsbHddDestination(m_delete_destination, m_destination) ||
        !(m_delete_fingerprint == m_catalog.fingerprint)) {
        m_status = "HDD music/source changed after the delete confirmation opened. Refresh and confirm again; no delete was started.";
        return;
    }
    const auto *existing = FindExisting(soundtrack_id);
    if (!existing) { m_status = "That soundtrack no longer exists; refresh first."; return; }
    if (!m_destination.available) { m_status = m_destination.reason; return; }
    std::string ready;
    if (!CsbHddReady(ready)) { m_status = ready; return; }
    auto *job = new BuildJob;
    job->owner = this;
    job->destination = m_destination;
    job->soundtrack_id = soundtrack_id;
    job->delete_soundtrack = true;
    job->base_soundtracks = CatalogAsStDb();
    job->db_write_options.minimum_next_soundtrack_id = m_catalog.next_soundtrack_id;
    job->db_write_options.minimum_next_song_id = m_catalog.next_song_id;
    job->edit.fast_stream = true; // Always TEST8 Fast Stream for CSB.
    job->edit.stream_chunk_bytes = kCsbStreamChunks[
        m_stream_chunk_index >= 0 && m_stream_chunk_index < 4 ?
            m_stream_chunk_index : kCsbDefaultStreamChunkIndex];
    job->edit.soundtrack_id = soundtrack_id;
    job->edit.delete_soundtrack = true;
    job->edit.target_existed = true;
    job->edit.preserve_database = !existing->listed_in_database && !m_catalog.database_valid;
    job->edit.expected_fingerprint = m_catalog.fingerprint;
    m_active_job = job;
    m_status = "Preparing safe deletion of soundtrack ID " + std::to_string(soundtrack_id) + "...";
    if (!debug_tools_queue_background_job(BuildWorker, job, BuildComplete, false)) {
        m_active_job = nullptr; delete job; m_status = "Debug Tools background worker is unavailable.";
    }
}

void CustomSoundtrackBuilder::BuildWorker(void *opaque)
{
    auto *job = static_cast<BuildJob *>(opaque);
    if (!job) return;
    try {
        GError *temp_error = nullptr;
        gchar *temp = g_dir_make_tmp("xemu-csb-XXXXXX", &temp_error);
        if (!temp) {
            job->status = std::string("Unable to create CSB staging: ") + (temp_error ? temp_error->message : "unknown error");
            if (temp_error) g_error_free(temp_error);
            return;
        }
        job->staging_root = temp; g_free(temp);
        const std::string staging = JoinPath(job->staging_root, "music");
        job->final_music_dir = staging;
        std::error_code ec; fs::create_directories(fs::u8path(staging), ec);
        std::string error;
        if (ec) error = "Unable to create CSB staging folders: " + ec.message();

        std::vector<StDbTrack> target_tracks;
        const std::string track_folder = JoinPath(staging, XboxSoundtrackFolderName(job->soundtrack_id));
        if (!job->delete_soundtrack && !job->edit.local_song_ids.empty()) {
            fs::create_directories(fs::u8path(track_folder), ec);
            if (ec) error = "Unable to create local soundtrack staging folder: " + ec.message();
        }
        for (size_t i = 0; error.empty() && i < job->tracks.size(); ++i) {
            if (job->cancel_requested.load()) { error = "CSB conversion cancelled."; break; }
            const BuildTrack &track = job->tracks[i];
            uint32_t duration_ms = track.duration_ms;
            if (!track.from_hdd) {
                const std::string output = JoinPath(track_folder, XboxSoundtrackFileName(job->soundtrack_id, track.song_id));
                if (!RunFfmpegConvert(job->ffmpeg, track.source_path, output, error)) break;
                if (!ValidateWma2XboxProfile(output, error)) { error = "Converted WMA validation failed for '" + track.title + "': " + error; break; }
                if (!ReadAsfDurationMs(output, duration_ms, error)) { error = "Unable to read converted duration for '" + track.title + "': " + error; break; }
                ++job->completed;
            }
            job->durations[i] = duration_ms;
            target_tracks.push_back({track.song_id, duration_ms, track.title});
        }

        std::vector<StDbSoundtrack> merged = job->base_soundtracks;
        auto it = std::find_if(merged.begin(), merged.end(), [&](const auto &s) { return s.soundtrack_id == job->soundtrack_id; });
        if (job->delete_soundtrack) {
            if (it != merged.end()) merged.erase(it);
        } else {
            StDbSoundtrack replacement{job->soundtrack_id, job->soundtrack_name, target_tracks};
            if (it != merged.end()) *it = std::move(replacement); else merged.push_back(std::move(replacement));
        }
        if (error.empty() && !job->edit.preserve_database &&
            !WriteStDb(JoinPath(staging, "ST.DB"), merged, error,
                       job->db_write_options)) {
            if (error.empty()) error = "Unable to build merged ST.DB.";
        }
        if (error.empty() && !WriteBuildManifest(JoinPath(staging, "CSB-BUILD.json"),
                job->delete_soundtrack ? std::string("DELETE") : job->soundtrack_name,
                job->soundtrack_id, job->tracks, job->durations, error)) {
            if (error.empty()) error = "Unable to build CSB manifest.";
        }
        if (!error.empty()) {
            std::string cleanup_error; RemoveTree(job->staging_root, cleanup_error);
            job->status = error; if (!cleanup_error.empty()) job->status += " " + cleanup_error; return;
        }
        job->success = true;
        job->status = job->delete_soundtrack ? "Deletion plan built; preparing HDD update..." : "Converted/rebuilt ST.DB; preparing HDD update...";
    } catch (const std::exception &error) {
        job->status = std::string("CSB operation failed: ") + error.what();
        std::string cleanup_error; if (!job->staging_root.empty()) RemoveTree(job->staging_root, cleanup_error);
    }
}

void CustomSoundtrackBuilder::BuildComplete(void *opaque)
{
    auto *job = static_cast<BuildJob *>(opaque);
    if (!job || !job->owner) { delete job; return; }
    job->conversion_done = true;
    job->owner->m_status = job->status;
}

void CustomSoundtrackBuilder::OpenLastOutput()
{
    if (!m_last_output.empty() && m_last_destination.source == HddSource::Image) {
        if (!SameCsbHddDestination(m_last_destination, m_destination)) {
            m_status = "Last output belongs to a different HDD: " + m_last_destination.mounted_path; return;
        }
        OpenCsbHddDirectory();
        m_status = "Open E:\\TDATA\\fffe0000\\music in HDD Directory.";
        return;
    }
    if (m_last_output.empty()) { m_status = "No completed CSB output is available yet."; return; }
    GError *uri_error = nullptr;
    gchar *absolute = g_canonicalize_filename(m_last_output.c_str(), nullptr);
    gchar *uri = absolute ? g_filename_to_uri(absolute, nullptr, &uri_error) : nullptr;
    if (uri && SDL_OpenURL(uri)) m_status = "Opened " + m_last_output;
    else { m_status = "Unable to open output folder: "; m_status += uri_error ? uri_error->message : SDL_GetError(); }
    if (uri_error) g_error_free(uri_error);
    g_free(uri);
    g_free(absolute);
}

namespace {
struct CsbTrackDrag {
    uint64_t revision = 0;
    uint16_t song_id = 0;
};
constexpr const char *kCsbTrackDragType = "XEMU_CSB_TRACK_ORDER";

std::string CsbSizeText(uint64_t bytes)
{
    char text[48];
    if (bytes >= 1024u * 1024u)
        std::snprintf(text, sizeof(text), "%.2f MiB", bytes / (1024.0 * 1024.0));
    else if (bytes >= 1024u)
        std::snprintf(text, sizeof(text), "%.1f KiB", bytes / 1024.0);
    else std::snprintf(text, sizeof(text), "%llu B", static_cast<unsigned long long>(bytes));
    return text;
}

std::string CsbDurationText(uint32_t duration_ms)
{
    if (!duration_ms) return "--:--";
    const uint32_t seconds = duration_ms / 1000u;
    char text[32];
    if (seconds >= 3600u)
        std::snprintf(text, sizeof(text), "%u:%02u:%02u", seconds / 3600u, (seconds / 60u) % 60u, seconds % 60u);
    else std::snprintf(text, sizeof(text), "%u:%02u", seconds / 60u, seconds % 60u);
    return text;
}

void CsbTextTooltip(const char *text)
{
    ImGui::TextUnformatted(text);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", text);
}
} // namespace

void CustomSoundtrackBuilder::DrawMenuBar()
{
    if (!ImGui::BeginMenuBar()) return;
    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("Open Last Output", nullptr, false, !m_last_output.empty()))
            m_open_output_requested = true; // HDD navigation is deferred, not an unlocked Draw write.
        ImGui::Separator();
        if (ImGui::MenuItem("Add File", nullptr, false, !EditorReadOnly())) BrowseForTrack();
        if (ImGui::MenuItem("Clear Editor", nullptr, false, !EditorReadOnly() && !m_tracks.empty()))
            RequestEditorAction(EditorAction::Clear);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Options")) {
        if (ImGui::BeginMenu("Maximum Write Chunk", !UiBusy())) {
            static const char *labels[] = {"512 KiB", "1 MiB", "2 MiB", "4 MiB (default)"};
            for (int i = 0; i < 4; ++i) {
                if (ImGui::MenuItem(labels[i], nullptr, m_stream_chunk_index == i))
                    m_stream_chunk_index = i;
            }
            ImGui::EndMenu();
        }
        ImGui::Separator();
        ImGui::TextDisabled("Fast staged-file streaming is always enabled.");
        ImGui::EndMenu();
    }
    ImGui::EndMenuBar();
}

void CustomSoundtrackBuilder::DrawEditorPanel()
{
    ImGui::TextUnformatted(m_viewing_orphan ? "Unlisted Folder" :
                           m_editing_existing_id >= 0 ? "Edit Soundtrack" : "New Soundtrack");
    ImGui::Separator();
    ImGui::BeginDisabled(EditorReadOnly());
    ImGui::TextUnformatted("Soundtrack Name");
    ImGui::SetNextItemWidth(-1.0f);
    if (ImGui::InputText("##soundtrack_name", m_soundtrack_name, sizeof(m_soundtrack_name)))
        MarkEditorChanged();
    ImGui::TextUnformatted("ID (decimal)");
    ImGui::BeginDisabled(m_editing_existing_id >= 0);
    ImGui::SetNextItemWidth(-1.0f);
    if (ImGui::InputInt("##soundtrack_id", &m_soundtrack_id)) {
        m_soundtrack_id = std::clamp(m_soundtrack_id, 0, 65535);
        for (auto &track : m_tracks) if (!track.from_hdd)
            track.output_name = XboxSoundtrackFileName(static_cast<uint16_t>(m_soundtrack_id), track.song_id);
        MarkEditorChanged();
    }
    ImGui::EndDisabled();
    ImGui::EndDisabled();
    ImGui::TextDisabled("Xbox folder: %04X", m_soundtrack_id);
    if (m_editing_existing_id >= 0)
        ImGui::TextWrapped("Existing ID is locked. Use New Soundtrack for a different ID.");
    if (m_viewing_orphan)
        ImGui::TextWrapped("Not listed in ST.DB. Files are read-only; CSB will not silently adopt or overwrite them.");
    ImGui::Separator();
    ImGui::Text("%zu song(s) in editor", m_tracks.size());
    if (m_editor_dirty) ImGui::TextUnformatted("Unsaved changes");
    else ImGui::TextDisabled(m_viewing_orphan ? "Read-only view" : "No pending changes");
    if (m_editor_catalog_valid && !EditorMatchesCatalog())
        ImGui::TextWrapped("HDD catalog/source changed or is unavailable. Pending edits are kept; reselect after Refresh to reload before saving.");
    ImGui::BeginDisabled(EditorReadOnly() || m_tracks.empty() || !m_destination.available || !m_catalog_loaded ||
                         (m_editing_existing_id >= 0 && !m_editor_dirty &&
                          m_catalog.soundtrack_id_index_consistent));
    if (ImGui::Button(m_destination.ButtonLabel(), ImVec2(-1, ImGui::GetFrameHeight() * 1.5f)))
        m_build_requested = true;
    ImGui::EndDisabled();
    ImGui::TextWrapped("Track changes and order are pending until SAVE. Right-click a soundtrack to delete it with confirmation.");
    if (m_editing_existing_id >= 0 && !m_catalog.soundtrack_id_index_consistent)
        ImGui::TextWrapped("ST.DB dashboard soundtrack index needs repair. SAVE is enabled even with no track edits; it preserves this soundtrack and rewrites the index using the existing guarded transaction.");
    ImGui::Separator();
    ImGui::Text("Source: %s", m_destination.source == HddSource::Folder ? "Folder HDD" :
                              m_destination.source == HddSource::Image ? "Disk Image" : "Unavailable");
    const int chunk = m_stream_chunk_index >= 0 && m_stream_chunk_index < 4 ? m_stream_chunk_index : kCsbDefaultStreamChunkIndex;
    static const char *chunk_labels[] = {"512 KiB", "1 MiB", "2 MiB", "4 MiB"};
    ImGui::TextDisabled("Fast Stream: %s", chunk_labels[chunk]);
    if (!m_destination.available) ImGui::TextWrapped("%s", m_destination.reason.c_str());
    if (ImGui::CollapsingHeader("Destination / FFmpeg")) {
        ImGui::TextWrapped("Selected: %s", m_destination.selected_path.c_str());
        ImGui::TextWrapped("Mounted: %s", m_destination.mounted_path.c_str());
        ImGui::TextWrapped("Xbox: E:\\TDATA\\fffe0000\\music\\");
        ImGui::TextWrapped("FFmpeg: %s", m_ffmpeg_display.empty() ? "Not found. Put ffmpeg.exe beside XEMU or on PATH to add new audio." : m_ffmpeg_display.c_str());
        ImGui::TextWrapped("One open/flush/close per file, final verification, and the TEST8 kernel safety checks. A transfer can make the game hesitate. Cancel waits for a running call to finish safely.");
    }
}

void CustomSoundtrackBuilder::DrawExistingCatalog()
{
    ImGui::TextUnformatted("Existing HDD Soundtracks");
    ImGui::BeginDisabled(UiBusy() || m_pending_action != EditorAction::None || m_pending_delete_id >= 0 || m_rename_song_id >= 0);
    if (ImGui::SmallButton("REFRESH HDD MUSIC")) RequestCatalogRefresh();
    ImGui::SameLine();
    if (ImGui::SmallButton("NEW SOUNDTRACK")) RequestEditorAction(EditorAction::New);
    ImGui::EndDisabled();
    ImGui::TextDisabled("%zu soundtrack(s) on HDD", m_catalog.soundtracks.size());
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", m_catalog_status.c_str());
    if (!m_catalog_loaded) ImGui::TextWrapped("%s", m_catalog_status.c_str());
    if (!m_catalog.warnings.empty() && ImGui::CollapsingHeader("Catalog warnings"))
        for (const auto &warning : m_catalog.warnings) ImGui::TextWrapped("%s", warning.c_str());

    const float em = ImGui::GetFontSize();
    const auto flags = ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable |
                       ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX | ImGuiTableFlags_SizingFixedFit;
    if (!ImGui::BeginTable("##csb_existing", 4, flags,
                          ImVec2(0, std::max(5.0f * em, ImGui::GetContentRegionAvail().y)), std::max(24.0f * em, ImGui::GetContentRegionAvail().x))) return;
    ImGui::TableSetupColumn("ID", ImGuiTableColumnFlags_WidthFixed, 3.2f * em);
    ImGui::TableSetupColumn("Sound Track Name", ImGuiTableColumnFlags_WidthStretch, 1.0f);
    ImGui::TableSetupColumn("Songs Count", ImGuiTableColumnFlags_WidthFixed, 6.2f * em);
    ImGui::TableSetupColumn("Size", ImGuiTableColumnFlags_WidthFixed, 5.6f * em);
    ImGui::TableSetupScrollFreeze(0, 1);
    ImGui::TableHeadersRow();
    int select_id = -1, delete_id = -1;
    for (const auto &soundtrack : m_catalog.soundtracks) {
        ImGui::PushID(static_cast<int>(soundtrack.soundtrack_id));
        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        char label[40]; std::snprintf(label, sizeof(label), "%04X###soundtrack", soundtrack.soundtrack_id);
        const bool selected = m_selected_soundtrack_id == soundtrack.soundtrack_id &&
                              SameCsbHddDestination(m_editor_destination, m_destination);
        ImGui::BeginDisabled(UiBusy() || !m_catalog_loaded);
        if (ImGui::Selectable(label, selected, ImGuiSelectableFlags_SpanAllColumns))
            select_id = soundtrack.soundtrack_id;
        if (ImGui::BeginPopupContextItem("##soundtrack_context")) {
            if (ImGui::MenuItem("Delete")) delete_id = soundtrack.soundtrack_id;
            ImGui::EndPopup();
        }
        ImGui::EndDisabled();
        ImGui::TableSetColumnIndex(1);
        CsbTextTooltip(soundtrack.name.empty() ? "(unnamed soundtrack)" : soundtrack.name.c_str());
        ImGui::TableSetColumnIndex(2); ImGui::Text("%zu", soundtrack.tracks.size());
        ImGui::TableSetColumnIndex(3);
        if (!soundtrack.folder_present) {
            ImGui::TextDisabled("Missing");
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Listed in ST.DB, but its HDD folder is missing.");
        } else {
            ImGui::TextUnformatted(CsbSizeText(soundtrack.folder_bytes).c_str());
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("%llu bytes in this HDD folder%s. Size is the installed folder size, not a pending estimate.",
                    static_cast<unsigned long long>(soundtrack.folder_bytes),
                    soundtrack.listed_in_database ? "" : " (orphan: not listed in ST.DB)");
        }
        ImGui::PopID();
    }
    ImGui::EndTable();
    // Apply actions after iteration; never invalidate an active row reference.
    if (delete_id >= 0) RequestEditorAction(EditorAction::Delete, delete_id);
    else if (select_id >= 0) RequestEditorAction(EditorAction::Select, select_id);
}

void CustomSoundtrackBuilder::DrawTrackTable()
{
    ImGui::TextUnformatted(m_selected_soundtrack_id >= 0 ? "Soundtrack Songs" : "New Soundtrack Songs");
    ImGui::TextDisabled(m_viewing_orphan ? "Unlisted folder: read-only files" : "Drag rows to reorder. Right-click: Rename / Delete.");
    ImGui::TextDisabled("%zu song(s)  |  %s", m_tracks.size(), m_editor_dirty ? "Pending changes" : "Current editor");
    const float em = ImGui::GetFontSize();
    const auto flags = ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable |
                       ImGuiTableFlags_ScrollY | ImGuiTableFlags_ScrollX | ImGuiTableFlags_SizingFixedFit;
    if (!ImGui::BeginTable("##csb_tracks", 5, flags,
                          ImVec2(0, std::max(5.0f * em, ImGui::GetContentRegionAvail().y)), std::max(32.0f * em, ImGui::GetContentRegionAvail().x))) return;
    ImGui::TableSetupColumn("#", ImGuiTableColumnFlags_WidthFixed, 2.8f * em);
    ImGui::TableSetupColumn("Track Name", ImGuiTableColumnFlags_WidthStretch, 1.0f);
    ImGui::TableSetupColumn("Xbox File", ImGuiTableColumnFlags_WidthFixed, 8.5f * em);
    ImGui::TableSetupColumn("Duration", ImGuiTableColumnFlags_WidthFixed, 5.0f * em);
    ImGui::TableSetupColumn("Source", ImGuiTableColumnFlags_WidthFixed, 5.7f * em);
    ImGui::TableSetupScrollFreeze(0, 1);
    ImGui::TableHeadersRow();
    int remove_index = -1, rename_id = -1;
    bool move = false;
    size_t insertion = 0;
    CsbTrackDrag dropped{};
    const bool editable = !EditorReadOnly();
    for (size_t i = 0; i < m_tracks.size(); ++i) {
        const Track &track = m_tracks[i];
        ImGui::PushID(static_cast<int>(track.song_id));
        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        char label[40]; std::snprintf(label, sizeof(label), "%zu###song", i + 1);
        if (ImGui::Selectable(label, m_selected_song_id == track.song_id,
                              ImGuiSelectableFlags_SpanAllColumns | ImGuiSelectableFlags_AllowDoubleClick)) {
            m_selected_song_id = track.song_id;
            if (editable && ImGui::IsMouseDoubleClicked(0)) rename_id = track.song_id;
        }
        const ImVec2 row_min = ImGui::GetItemRectMin(), row_max = ImGui::GetItemRectMax();
        if (editable && ImGui::BeginDragDropSource()) {
            CsbTrackDrag payload{};
            payload.revision = m_editor_revision;
            payload.song_id = track.song_id;
            ImGui::SetDragDropPayload(kCsbTrackDragType, &payload, sizeof(payload));
            ImGui::Text("Move #%zu: %s", i + 1, track.title.c_str());
            ImGui::EndDragDropSource();
        }
        if (editable && ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload *payload = ImGui::AcceptDragDropPayload(kCsbTrackDragType, ImGuiDragDropFlags_AcceptBeforeDelivery)) {
                if (payload->DataSize == static_cast<int>(sizeof(CsbTrackDrag))) {
                    CsbTrackDrag candidate{}; std::memcpy(&candidate, payload->Data, sizeof(candidate));
                    if (candidate.revision == m_editor_revision) {
                        const bool after = ImGui::GetIO().MousePos.y >= (row_min.y + row_max.y) * 0.5f;
                        const float line_y = after ? row_max.y : row_min.y;
                        ImGui::GetWindowDrawList()->AddLine(ImVec2(row_min.x, line_y), ImVec2(row_max.x, line_y), ImGui::GetColorU32(ImGuiCol_DragDropTarget), 2.0f);
                        if (payload->IsDelivery()) { move = true; dropped = candidate; insertion = i + (after ? 1u : 0u); }
                    }
                }
            }
            ImGui::EndDragDropTarget();
        }
        if (ImGui::BeginPopupContextItem("##track_context")) {
            m_selected_song_id = track.song_id;
            if (ImGui::MenuItem("Rename", nullptr, false, editable)) rename_id = track.song_id;
            if (ImGui::MenuItem("Delete", nullptr, false, editable)) remove_index = static_cast<int>(i);
            if (m_viewing_orphan) ImGui::TextDisabled("Orphan files are read-only.");
            ImGui::EndPopup();
        }
        ImGui::TableSetColumnIndex(1); CsbTextTooltip(track.title.c_str());
        ImGui::TableSetColumnIndex(2); CsbTextTooltip(track.output_name.c_str());
        ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(CsbDurationText(track.duration_ms).c_str());
        if (!track.duration_ms && ImGui::IsItemHovered())
            ImGui::SetTooltip(track.from_hdd ? "Duration is not available from ST.DB." : "Duration is populated after conversion on SAVE.");
        ImGui::TableSetColumnIndex(4);
        ImGui::TextUnformatted(track.from_hdd ? (track.hdd_present ? "HDD" : "HDD missing") : "Local file");
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", track.source_path.c_str());
        ImGui::PopID();
    }
    ImGui::TableNextRow(); ImGui::TableSetColumnIndex(0);
    if (m_tracks.empty()) {
        ImGui::TableSetColumnIndex(1);
        ImGui::TextUnformatted("No songs. Use File > Add File or drop audio here.");
    } else {
        ImGui::Selectable("Drop here to move to the end##end", false, ImGuiSelectableFlags_SpanAllColumns);
        if (editable && ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload *payload = ImGui::AcceptDragDropPayload(kCsbTrackDragType)) {
                if (payload->IsDelivery() && payload->DataSize == static_cast<int>(sizeof(CsbTrackDrag))) {
                    std::memcpy(&dropped, payload->Data, sizeof(dropped)); move = true; insertion = m_tracks.size();
                }
            }
            ImGui::EndDragDropTarget();
        }
    }
    // While dragging, scroll the table at its top/bottom edge for longer lists.
    if (editable && ImGui::GetDragDropPayload() &&
        ImGui::GetDragDropPayload()->IsDataType(kCsbTrackDragType) &&
        ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem)) {
        const float mouse_y = ImGui::GetIO().MousePos.y;
        const float top = ImGui::GetWindowPos().y + 3.0f * em;
        const float bottom = ImGui::GetWindowPos().y + ImGui::GetWindowSize().y - 1.5f * em;
        const float scroll = 24.0f * em * ImGui::GetIO().DeltaTime;
        if (mouse_y < top) ImGui::SetScrollY(std::max(0.0f, ImGui::GetScrollY() - scroll));
        else if (mouse_y > bottom) ImGui::SetScrollY(std::min(ImGui::GetScrollMaxY(), ImGui::GetScrollY() + scroll));
    }
    ImGui::EndTable();
    if (remove_index >= 0) RemoveTrack(static_cast<size_t>(remove_index));
    else if (move) ReorderTrack(dropped.song_id, insertion, dropped.revision);
    else if (rename_id >= 0) RequestTrackRename(static_cast<uint16_t>(rename_id));
}

void CustomSoundtrackBuilder::DrawDialogs()
{
    if (m_pending_action != EditorAction::None) ImGui::OpenPopup("Unsaved soundtrack changes");
    ImGui::SetNextWindowSize(ImVec2(34.0f * ImGui::GetFontSize(), 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal("Unsaved soundtrack changes", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (m_pending_action == EditorAction::None) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
        else {
            const bool clear = m_pending_action == EditorAction::Clear;
            ImGui::TextWrapped(clear
                ? "Clear all tracks from this editor? This is only a pending edit; no HDD files are deleted now."
                : "Discard the pending name, track or order changes before continuing? No HDD files have been changed by these edits.");
            ImGui::BeginDisabled(UiBusy());
            if (ImGui::Button(clear ? "CLEAR EDITOR" : "DISCARD CHANGES")) {
                const auto action = m_pending_action;
                const int id = m_pending_action_id;
                const auto &before = m_pending_action_destination;
                const bool local_only = action == EditorAction::Clear || action == EditorAction::New;
                const bool same_selection = before.source == m_destination.source &&
                    before.identity == m_destination.identity && before.available == m_destination.available &&
                    before.selected_path == m_destination.selected_path && before.mounted_path == m_destination.mounted_path;
                const bool unchanged = (SameCsbHddDestination(before, m_destination) || (local_only && same_selection)) &&
                                       m_pending_action_fingerprint == m_catalog.fingerprint;
                m_pending_action = EditorAction::None;
                ImGui::CloseCurrentPopup();
                if (unchanged) ApplyEditorAction(action, id);
                else m_status = "HDD catalog/source changed while the dialog was open. Pending edits were kept. Review the new catalog and try again.";
            }
            ImGui::SameLine();
            if (ImGui::Button("KEEP EDITING")) { m_pending_action = EditorAction::None; ImGui::CloseCurrentPopup(); }
            ImGui::EndDisabled(); ImGui::EndPopup();
        }
    }
    if (m_pending_delete_id >= 0 && !UiBusy()) ImGui::OpenPopup("Delete soundtrack");
    ImGui::SetNextWindowSize(ImVec2(36.0f * ImGui::GetFontSize(), 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal("Delete soundtrack", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (m_pending_delete_id < 0) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
        else {
            ImGui::Text("Delete ID %04X?", m_pending_delete_id);
            ImGui::TextWrapped("%s", m_delete_name.c_str());
            ImGui::TextWrapped("This removes the selected soundtrack/folder from the active music collection. Other soundtracks are preserved. The existing TEST8 affected-item backup and ST.DB-last publication are retained.");
            ImGui::BeginDisabled(UiBusy() || !m_destination.available || !m_catalog_loaded);
            if (ImGui::Button("CONFIRM DELETE SOUNDTRACK")) { m_delete_requested = true; ImGui::CloseCurrentPopup(); }
            ImGui::EndDisabled(); ImGui::SameLine();
            if (ImGui::Button("CANCEL DELETE")) { m_pending_delete_id = -1; ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        }
    }
    if (m_rename_song_id >= 0) ImGui::OpenPopup("Rename track");
    ImGui::SetNextWindowSize(ImVec2(32.0f * ImGui::GetFontSize(), 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal("Rename track", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (m_rename_song_id < 0) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
        else {
            ImGui::TextUnformatted("Track Name"); ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##rename_track", m_rename_title, sizeof(m_rename_title));
            ImGui::BeginDisabled(UiBusy() || !m_rename_title[0]);
            if (ImGui::Button("APPLY NAME")) {
                if (m_rename_revision == m_editor_revision && !m_viewing_orphan)
                    for (auto &track : m_tracks) if (track.song_id == m_rename_song_id) {
                        if (track.title != m_rename_title) { track.title = m_rename_title; MarkEditorChanged(); }
                        break;
                    }
                m_rename_song_id = -1; ImGui::CloseCurrentPopup();
            }
            ImGui::EndDisabled(); ImGui::SameLine();
            if (ImGui::Button("CANCEL RENAME")) { m_rename_song_id = -1; ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        }
    }
}

void CustomSoundtrackBuilder::Draw(bool detached)
{
    if (!is_open) return;
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_MenuBar;
    const char *window_name = "Custom Soundtrack Builder";
    bool *window_open = &is_open;
    if (detached) {
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Always);
        flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings;
        window_name = "##DetachedCustomSoundtrackBuilder";
        window_open = nullptr;
    } else {
        ImGui::SetNextWindowSize(ImVec2(1480, 820), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSizeConstraints(ImVec2(1100, 620), ImVec2(100000, 100000));
    }
    if (!ImGui::Begin(window_name, window_open, flags)) { ImGui::End(); return; }
    DrawMenuBar();
    ImGui::TextUnformatted("Custom Soundtrack Builder");
    const float em = ImGui::GetFontSize();
    // Independent scroll regions; the status/transfer footer cannot push the tables offscreen.
    const float workspace_height = std::max(12.0f * em, ImGui::GetContentRegionAvail().y - 8.5f * em);
    if (ImGui::BeginTable("##csb_workspace", 3,
                          ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV,
                          ImVec2(0, workspace_height))) {
        ImGui::TableSetupColumn("Editor", ImGuiTableColumnFlags_WidthFixed, 14.0f * em);
        ImGui::TableSetupColumn("HDD Soundtracks", ImGuiTableColumnFlags_WidthStretch, 0.85f);
        ImGui::TableSetupColumn("Songs", ImGuiTableColumnFlags_WidthStretch, 1.35f);
        ImGui::TableNextRow();
        ImGui::TableSetColumnIndex(0);
        if (ImGui::BeginChild("##csb_editor_panel", ImVec2(0, workspace_height))) DrawEditorPanel();
        ImGui::EndChild();
        ImGui::TableSetColumnIndex(1);
        if (ImGui::BeginChild("##csb_catalog_panel", ImVec2(0, workspace_height))) DrawExistingCatalog();
        ImGui::EndChild();
        ImGui::TableSetColumnIndex(2);
        if (ImGui::BeginChild("##csb_track_panel", ImVec2(0, workspace_height))) DrawTrackTable();
        ImGui::EndChild();
        ImGui::EndTable();
    }
    if (ImGui::BeginChild("##csb_status", ImVec2(0, 0), ImGuiChildFlags_Borders)) {
        if (m_active_job && m_active_job->install_started) {
            ImGui::ProgressBar(m_installer.Progress(), ImVec2(-1, 0));
        } else if (m_active_job) {
            const unsigned completed = m_active_job->completed.load();
            const unsigned total = std::max(1u, m_active_job->conversion_total);
            ImGui::ProgressBar(m_active_job->conversion_total ? static_cast<float>(completed) / total : 0.25f, ImVec2(-1, 0));
        }
        if (m_active_job) {
            if (ImGui::Button("CANCEL CSB OPERATION")) m_cancel_requested = true;
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Cancellation is handled at safe boundaries. A conversion/kernel call already running finishes first.");
        }
        ImGui::TextWrapped("%s", m_status.c_str());
        if ((!m_active_job || m_active_job->install_started) && !m_installer.TransferSummary().empty() &&
            ImGui::CollapsingHeader(m_active_job ? "Current HDD transfer" : "Last HDD transfer"))
            ImGui::TextWrapped("%s", m_installer.TransferSummary().c_str());
    }
    ImGui::EndChild();
    DrawDialogs();
    ImGui::End();
}

} // namespace XemuCsb
