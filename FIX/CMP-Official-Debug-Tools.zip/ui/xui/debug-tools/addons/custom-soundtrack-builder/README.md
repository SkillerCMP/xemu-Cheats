# Custom Soundtrack Builder — CSB TEST12 Dashboard ST.DB Format Fix

Built directly from CSB TEST11 isolated recovery, which itself was built from the
exact TEST9 side-by-side manager package (SHA-256
`A0B29D3CEC24DF8944C02EBC692657480BA26D87689BBE6D2A3C279F8C253A38`).
TEST12 keeps TEST11's `E:/TDATA/CSBBACKUP` guarded transaction, TEST9's side-by-side
manager/drag/drop/context menus/external-FFmpeg behavior, and the TEST8 4 MiB Fast
Stream writer. TEST10's audio-preview/player/WMA-import work remains intentionally
absent. The production changes here are the ST.DB dashboard index/counter handling
and the UI/controller plumbing required to repair an already malformed index.
The GUI and live Xbox-dashboard behavior still require the normal Windows runtime test.

## Workspace and menus

The workspace has three resizable columns with independent scroll regions:

- Far left: selected soundtrack Name and ID, pending-edit state, source-aware
  SAVE, and collapsed destination/FFmpeg details. Existing IDs are locked. Input
  IDs are decimal; Xbox folder/table IDs are shown as four uppercase hex digits.
- HDD list beside it: `ID | Sound Track Name | Songs Count | Size`. **REFRESH HDD
  MUSIC** and **NEW SOUNDTRACK** remain above this left-hand table. Size is the
  currently installed soundtrack folder's bytes (displayed in B/KiB/MiB), not a
  compressed-image allocation or pending-change estimate. Warnings are expandable.
- Right: `# | Track Name | Xbox File | Duration | Source`. Clicking a soundtrack
  loads its current songs here. Orphan folders can be inspected but stay read-only.
  Missing HDD files remain explicit. Hover Source for the full path. Unknown
  durations show `--:--`; new audio duration is populated after conversion.

The name edit buffer preserves the full UTF-8 encoding of valid ST.DB names;
reordering does not truncate long non-ASCII soundtrack names in the editor.

The window-local **File** menu contains **Open Last Output**, **Add File** and
**Clear Editor**. **Options > Maximum Write Chunk** offers 512 KiB, 1 MiB, 2 MiB
and 4 MiB; **4 MiB remains the default**. CSB always leases Fast Stream now; the
comparison checkbox is removed from CSB only. Other HDD frontends and the backend
conservative implementation are unchanged. Chunk changes are disabled while a
save/delete is queued or running. Current/last transfer statistics are retained
in an expandable, independently scrolling status footer.

### Editing, dragging and deletion

Drag a song row above/below another row; the insertion marker shows the boundary.
Dropping after the last row moves to the end. The table scrolls near its edges
while dragging. Only delivery changes order, not hovering. The complete row moves:
its stable Xbox song ID, filename, source and duration are NOT renumbered. `#` is
the editable playlist position, not the on-disk file number. Stale drag payloads
are rejected after list changes/reset, and queued/active jobs lock mutations.

Right-click a song for **Rename** or **Delete**. Double-click also opens Rename.
Deleting a song only removes it from the pending editor; SAVE is still required
before the HDD changes. Clear Editor asks before clearing a nonempty track list
and also remains a pending edit. An empty editor cannot be saved; right-click the
soundtrack to delete the entire soundtrack instead. Unchanged loaded soundtracks normally do not enable the SAVE button. The one exception
is a catalog whose ST.DB `soundtrackIds[]` header disagrees with its soundtrack
records: TEST12 enables SAVE for the selected listed soundtrack so the existing
guarded transaction can repair that index without inventing a track edit.

Clicking another soundtrack or New with unsaved edits asks **Discard Changes**
or **Keep Editing**. Catalog refresh does not silently discard/rebase pending
edits. A source/catalog change while a discard dialog is open preserves the
editor and asks the user to review again. Read-only orphan folders are never
adopted into ST.DB by viewing them.

Right-click a soundtrack and choose **Delete** for a separate confirmation with
its exact ID and name. Confirmation captures the HDD/catalog fingerprint; a
change before deferred deletion rejects the operation rather than retargeting
it. TEST11 isolated-recovery staging, verification and publication rules apply.
Dialogs/drag intents are invalidated on reset. FFmpeg discovery for display is
cached in deferred processing, rather than filesystem-probed on every paint.
Open Last Output navigation is deferred as well. Rendering uses cached catalog
and editor records; it does not read/write HDD data to select or reorder rows.

## Fast staged-file streaming

A normal staging-file transfer has one exclusive, create-only Xbox file handle,
a maximum of the selected payload per write, and one final flush/close. A file's
last write uses only its remaining bytes; small files are not padded to 4 MiB.
The chunk policy is frozen when the HDD sequence is claimed and cannot change
mid-file or be taken over by another frontend. Unspecified backend callers retain
the previous 512 KiB default; unrelated HDD frontends do not opt in to fast mode.

Choose **Options > Maximum Write Chunk** before SAVE. CSB always enables the
TEST8 fast staged-file path. There is no silent fallback or automatic retry
after a possibly completed write. Recover any
reported unsafe state before choosing a smaller size and retrying.

### The 4 MiB mapping boundary

An exact 4 MiB payload plus the 8 KiB code/results/objects header needs a
`0x402000`-byte guest arena. This exceeds one non-PAE 4 MiB page-table window.
TEST8 explicitly reserves two page tables, checks both required adjacent PDEs
are unused, and validates all owned PDEs and active PTEs before continuations.
The rest of each active page table must remain unmapped. Original nonpresent
PDE values are restored exactly, including after partial installation errors.
Cleanup prevalidates all attempted entries before modifying either one and
retains ownership when it cannot prove a safe restore. Uncertain cleanup is
not permission to reuse or free the mapping.

The host MemoryRegion reserves `0x404000` bytes: two 4 KiB page tables plus the
maximum arena. It is emulator-owned backing, not an allocation request to the
Xbox game's normal heap. The active guest mapping is page-rounded to the
8 KiB header plus the smaller of file size and chosen chunk. Small files avoid
mapping/clearing a full payload arena, though the host region's maximum backing
reservation remains. Legacy unsized arena callers still request 64 KiB.

### Transfer-path optimizations

The stream rebuilds only its 8 KiB header. A bounded, prevalidated two-span refill
copies the header and the already-loaded source chunk directly into private RAM,
with one code/translation synchronization. It does not allocate and zero a
second multi-MiB vector or make the additional full-payload copy for every call.
Equal-sized host reads reuse their existing buffer. Sequential reads reuse the
open host stream without redundant seeks; nonsequential offsets still seek.
Read failures clear the exposed output buffer, so stale data is not submitted.
The fast nonempty-host path avoids a duplicate metadata check immediately before
the loader's identical path/type/size/time validation. Initial source hashing,
per-chunk metadata checks, rolling source hash and final source checks remain.

No destination FATX snapshot is built after each fast write. One complete
coherent content verification follows successful flush/close, before the file
may be published. Retained FATX sources retain their identity checks and final
source/destination byte comparison; source-side snapshots are not removed.

The stream retains **the same borrowed guest execution context for the entire
file**, so its open handle cannot migrate into a different title thread.
Between checked calls XEMU is paused while the next buffer is loaded. The game
can hesitate during a large transfer. This is not a background Xbox worker or
a promise of uninterrupted gameplay. Each call still requires PASSIVE_LEVEL,
owned mappings, preserved registers and the same mounted HDD/title.

Short writes, mismatched status/byte counts, host changes and final mismatches
cannot publish a file. A normal cancel/error closes a known handle at a checked
boundary. Pending/uncertain requests, failed Close, timeout or lost context
retain ownership and leave XEMU paused for reset/restart rather than reusing
potentially live memory. A 4 MiB call can exceed the unchanged three-second
in-flight watchdog on a slow/stalled emulator. That protection is not removed.

A 20 MiB payload requires 40 / 20 / 10 / 5 data writes at 512 KiB / 1 MiB /
2 MiB / 4 MiB respectively, versus 394 at 52 KiB. These are operation counts,
**not measured speedups**. Final verification, source reads, publication, safe-point
availability and image synchronization can still dominate total install time.
There is no new raw QCOW/FATX or host-folder bypass, and emulator-level block
stop/drain/flush behavior is not removed.

### Transfer measurements

Current/last transfer statistics show the frozen maximum chunk size, written and
planned MiB, HDD-install wall time, end-to-end MiB/s, observed file RPC/open/write/
flush/close counts, safe-point samples, and source-load / **refill** / safe-point-
wait / RPC-wall / final-readback time. Refill covers protocol preparation, buffer
copy/synchronization and associated validation, not only memory-copy time.
File counters exclude directory/rename RPCs. Aggregate time begins when the
installer claims the sequence after initial catalog/synchronization checks and
includes later publication/synchronization; FFmpeg conversion is excluded.
RPC wall time includes emulator scheduling and polling. These are not isolated
disk benchmarks, and detailed phases need not sum to the total. The backend
conservative mode remains available to existing non-CSB callers, not as a CSB UI option.

## Automatic HDD source

| Hard Disk Source | Main action | Destination |
| --- | --- | --- |
| Disk Image | SAVE TO MOUNTED HDD IMAGE | FATX `E:` in the currently mounted image |
| Folder Backed FATX (CMP) | SAVE TO FOLDER HDD | Active Folder-HDD `E:` backing image, followed by its normal host `E/` mirror synchronization |
| Missing, unavailable or read-only | Disabled with explanation | No installation |

Both modes still use HDD Directory's Guest Kernel RPC filesystem operations.
There is no independent QCOW2/FATX writer, and the loose Folder-HDD mirror is not
used to bypass the live mounted image. Selected and mounted source paths must
agree. Changing settings does not hot-mount another image; activate the selected
source normally before saving. Source changes abort pending work instead of
redirecting it into another HDD.

Start a game/dashboard XBE and leave it **running and resumed**. Opening a game
menu is fine; pausing XEMU prevents safe-point execution. Reduced profiles
without the HDD services remain linkable and explain that installation is
unavailable.


## Dashboard ST.DB compatibility fix

The Xbox dashboard capture used for TEST12 exposed two format/allocation defects in
the previous CSB writer. The main ST.DB header contains a `soundtrackIds[100]`
index, but earlier CSB wrote only the maximum soundtrack ID into its first element.
For the user's post-dashboard-copy collection the live record table contained IDs
`0, 1, 3, 4` while the header index was `3, 0, 0, 4`. TEST12 writes every active
record ID into the corresponding header slot and validates the index when reading.

The dashboard-created ID `0004` also demonstrated that the low 16-bit song serial
is allocated from the database-wide `nextSongId` counter. Its files were
`0004001F.WMA` through `0004002C.WMA`, consuming serials 31 through 44 and advancing
`nextSongId` to 45. TEST12 therefore starts new-song allocation at the existing
`nextSongId` and checks that serial against every listed soundtrack, rather than
starting again inside the selected soundtrack. New soundtrack IDs likewise start
from `nextSoundtrackId`. Existing song IDs are preserved when a soundtrack is
reordered or otherwise retained.

The packed song value remains the dashboard-observed 32-bit form
`(soundtrackId << 16) | songSerial`; the physical directory remains the four-hex
soundtrack ID, and the six-song records remain ST.DB metadata groups. TEST12 does
not change those already-correct TEST11 behaviors. Counter values are monotonic:
editing/deleting a soundtrack does not move `nextSoundtrackId` or `nextSongId`
backward merely because the highest current record disappeared.

As an authoring-side oracle, the production TEST12 reader/writer was run against
the captured post-XMB-copy ST.DB (58,368 bytes, SHA-256
`825CD9D162787C649C5A3E62816ABF2C3CF78B3E2928979CDEC9B7D18FED007F`). The
rewritten file kept the same size, preserved `nextSoundtrackId=5` and
`nextSongId=45`, and was byte-for-byte identical from offset `0x200` onward. Only
three header bytes changed, correcting `soundtrackIds[]` from `[3,0,0,4]` to
`[0,1,3,4]`. This is a format regression oracle, not a claim of live-dashboard
acceptance. The dashboard-created `Soundtrack 1` itself genuinely contains blank
title fields for tracks 2-14, so TEST12 deliberately does not synthesize names for
those records.

## Existing Soundtracks manager

`REFRESH HDD MUSIC` reads `E:/TDATA/fffe0000/music/ST.DB` and its folders. The
window shows soundtrack IDs, names, track counts, missing-file warnings and
four-hex-digit **orphan folders** not listed in ST.DB.

Clicking a soundtrack loads its current tracks. Its ID is locked.
Retain, reorder or remove existing tracks and add new local audio, then SAVE.
Editor row changes do not immediately mutate the HDD. **NEW SOUNDTRACK** begins at ST.DB `nextSoundtrackId` and skips any listed/orphan
collision; existing IDs and orphan folders are never silently reused. New song
serials begin at the database-wide `nextSongId` and are checked across all listed
soundtracks before use.
**DELETE**, followed by **CONFIRM DELETE SOUNDTRACK**, removes the selected ID
from the live collection, retaining its recovery backup. A malformed/orphan
collection is not automatically adopted into ST.DB.

An editor keeps the catalog/source fingerprint from when a soundtrack or NEW was
selected. Automatic refresh does not silently rebase pending edits onto another
collection. If the catalog changes, refresh and reselect the soundtrack (or NEW) before
saving, explicitly discarding stale pending edits when prompted. After a successful save, newly converted tracks become HDD-backed rows;
saving them again does not unnecessarily run FFmpeg again.

A genuinely empty `music` directory is accepted as a fresh collection. A
nonempty collection with a missing/invalid ST.DB still requires repair or
intentional orphan removal before a normal add/edit.

## Incremental publication

For example, adding ID `0001` while `0000` already exists still leaves unrelated
ID `0000` in place:

```text
E:/TDATA/fffe0000/music/
  ST.DB                 # updated to contain IDs 0000 + 0001
  0000/
    00000000.WMA        # remains in place; not copied or re-encoded
  0001/
    0001000E.WMA        # example: next global song serial 14
```

TEST12 retains TEST11's rule that all temporary staging and rollback material stays outside `fffe0000`:

```text
E:/TDATA/CSBBACKUP/CSB-<unique-transaction>/
  stage/
    0001/...            # replacement selected soundtrack only
    database.new        # validated merged database; never named ST.DB here
  backup/
    0001/...            # previous selected folder, only if it existed
    database.bak        # previous live database, only if it existed
```

No temporary or recovery file named `ST.DB` is created under `CSBBACKUP`, and
TEST12 creates no `music.CSB-stage-*` or `music.CSB-backup-*` directories under
`E:/TDATA/fffe0000`. Legacy folders with those old names are deliberately neither
scanned for cleanup nor deleted because they may contain needed recovery data.

New audio is converted in private host temporary storage first. The new database
is captured privately as `database.new`. Before any live item is disturbed, the
selected soundtrack replacement and `database.new` are staged through the same
source-aware HDD Directory writer and verified. Existing tracks retained within
the selected soundtrack are copied and verified into that replacement; unrelated
soundtracks are not copied, renamed or backed up. Their metadata is still checked
for stale edits, but their WMA bytes are not read for the transaction.

After staging verification, publication uses at most four guarded moves:

1. Move the old selected ID folder to `backup/<ID>`, if present.
2. Move `stage/<ID>` into the live `music` directory, unless deleting.
3. Move live `music/ST.DB` to `backup/database.bak`, if present/replaced.
4. Move `stage/database.new` to live `music/ST.DB` **last**.

The installed selected soundtrack is then freshly read back and hashed, and the
published database is freshly read, hashed and parsed. Folder-HDD synchronization
(if active) runs only after that fresh E: verification. Only after both succeed is
the current transaction proven safe to remove. `E:/TDATA/CSBBACKUP` itself is
removed only when it is empty; unrelated/manual recovery material is preserved.

If staging, publication, fresh verification or synchronization fails, TEST12
retains the current recovery transaction. Publication failures and fresh-verify
failures attempt guarded reverse rollback. If the move result or recovery state
cannot be proven safe, automatic recovery stops rather than overwriting uncertain
data, and status reports the exact transaction, stage, backup, `database.new` and
`database.bak` paths that exist. Cleanup failure after a verified/synchronized
install is reported as a successful install with retained recovery material.

The merged database is still checked for preservation of every unrelated
soundtrack record. The validated database hash is fixed before import and checked
again before publication. Case-correct FATX names, source identity, free-space,
create-only/occupied-destination checks, cancellation protection and the existing
HDD ownership/watchdog rules remain in force. `CSB-BUILD.json` remains local
diagnostic data and is not uploaded by CSB.

## Safe-point waiting and cancellation

CSB's owned HDD sequence opts into **WAITING FOR SAFE HDD WRITE** rather than
failing after five seconds. Status includes elapsed time, sample count, last
sampled EIP and IRQL where available. Sampling uses small varied intervals to
avoid a fixed polling cadence. A title that never reaches a usable execution
point can still keep waiting; this change does not bypass the title/context or
`KeGetCurrentIrql == 0` checks.

**CANCEL CSB OPERATION** requests a stop between safe operations. A running
FFmpeg conversion completes its current process first. An already-running Xbox
kernel call must reach its verified completion before cancellation is handled;
CSB does not kill its handle, unwind its stack or unmap its return address.
During rollback, pressing Cancel again stops recovery at a safe boundary and
retains the staging/backup paths for inspection.

The retained non-CSB conservative backend uses TEST6 continuations from
a just-restored, verified title context in
bounded groups: at most four operations, with no further continuation once
50 ms has elapsed. These are separate checked stubs, not one large guest loop.
Every stub still checks IRQL, closes its handle and returns through the normal
completion verification. The time rule is a decision to stop starting more
operations, **not a guaranteed 50 ms duration for a kernel call**. Existing
52 KiB chunks, per-file limits, flushes, hashing and readback verification remain.

The **separate three-second in-flight kernel-call timeout remains fail-closed**.
A stuck or unexpectedly stopped syscall leaves XEMU paused with the RPC mapping
owned and requires reset; it is not safe to turn that into an arbitrary cancel.
The legacy five-second safe-point policy for non-CSB frontends is unchanged.

## Recovery, synchronization and limitations

Each install writes `CSB-INSTALL-RECOVERY.txt` in its local staging directory,
recording the HDD, target ID, paths, planned moves and completed publication
steps. It is retained after a failed/cancelled operation; normal success may
clean up the local staging directory.

On an ordinary publication failure, CSB checks **both source and destination**
to determine whether the move actually happened, then reverses completed moves
when the original source and kernel state are still safe. It refuses recovery
if a restore destination is occupied, a backup identity changed, the HDD
changed, a snapshot is unreadable or cleanup is still owned. It reports paths
instead of guessing. Reset, shutdown and power loss may require manual recovery.

Publication is a recoverable multi-step operation, **not power-loss atomic**.
There is a brief interval in which a target folder or ST.DB is moved. Do not
assume an interrupted update completed or rolled back. In particular, a wait
that issued no call may follow earlier successful staging writes. Use the
reported receipt/paths; do not blindly delete backups or mix an old ST.DB with
unrelated later edits.

Folder-HDD keeps its existing synchronization before an operation and after
successful publication (or completed rollback). A mirror synchronization failure
is explicitly reported as an already-published HDD change, not as an undo.
An entirely successful SAVE requires no additional manual HDD Refresh.

Current limits: 100 soundtrack records, up to 504 tracks per soundtrack in the
existing ST.DB core, and at most 64 MiB per newly imported or retained/copied
file. An unrelated existing WMA above that size is not recopied and does not
block an otherwise valid update. Staging requires free space for the selected
soundtrack plus ST.DB, not a second copy of the entire library. Backups still
consume capacity until intentionally removed after verification.

## FFmpeg and validation

FFmpeg remains external: put `ffmpeg.exe` beside XEMU or on `PATH`. TEST3's
Windows `CreateProcessW` fix is retained. New/local audio converts to `wmav2`,
44.1 kHz, stereo, 128 kbps. Existing HDD tracks are not transcoded.

See `../../tests/csb-hdd/VALIDATION.md` for executed native/simulated checks,
remaining Windows/emulator acceptance tests and the exact change boundary.
