// Profiles without HDD Directory must remain linkable, never fall back to a
// second raw-image writer or an unrelated output directory.
#include "custom-soundtrack-hdd.hh"
namespace XemuCsb {
namespace { const std::string unavailable = "This build profile omits HDD Directory. Build with full or main+hdd for CSB HDD installation."; }
struct HddSoundtrackInstaller::Impl {};
HddDestination DetectCsbHddDestination() { HddDestination d; d.reason = unavailable; return d; }
bool SameCsbHddDestination(const HddDestination &, const HddDestination &) { return false; }
bool CsbHddReady(std::string &reason) { reason = unavailable; return false; }
void OpenCsbHddDirectory() {}
bool ReadCsbHddMusicCatalog(const HddDestination &, HddMusicCatalog &catalog, std::string &error) { catalog = {}; error = unavailable; return false; }
HddSoundtrackInstaller::HddSoundtrackInstaller() : m_impl(new Impl) {}
HddSoundtrackInstaller::~HddSoundtrackInstaller() = default;
bool HddSoundtrackInstaller::Start(const HddDestination &, const std::string &,
                                   const HddSoundtrackEdit &, std::string &error) { error = unavailable; return false; }
void HddSoundtrackInstaller::Tick() {}
void HddSoundtrackInstaller::Cancel(const std::string &, bool) {}
void HddSoundtrackInstaller::Shutdown() {}
bool HddSoundtrackInstaller::Busy() const { return false; }
bool HddSoundtrackInstaller::Succeeded() const { return false; }
float HddSoundtrackInstaller::Progress() const { return 0; }
const std::string &HddSoundtrackInstaller::Status() const { return unavailable; }
const std::string &HddSoundtrackInstaller::TransferSummary() const { static const std::string empty; return empty; }
std::string HddSoundtrackInstaller::OutputPath() const { return {}; }
} // namespace XemuCsb
