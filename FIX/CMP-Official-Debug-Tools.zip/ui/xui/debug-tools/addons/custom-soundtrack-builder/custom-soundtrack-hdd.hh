// CSB orchestration over the existing HDD Directory / Kernel RPC services.
// No QCOW2 or FATX writer lives in CSB. All methods run on the UI/deferred
// thread, never in an unlocked Draw callback or the conversion worker.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace XemuCsb {
constexpr uint32_t kCsbStreamChunks[] = {512u*1024u, 1024u*1024u,
                                        2u*1024u*1024u, 4u*1024u*1024u};
constexpr int kCsbDefaultStreamChunkIndex = 3;
enum class HddSource { None, Image, Folder };
struct HddDestination {
    HddSource source = HddSource::None;
    std::string selected_path;
    std::string mounted_path;
    uintptr_t identity = 0;
    bool available = false;
    std::string reason;
    const char *ButtonLabel() const
    {
        if (source == HddSource::Folder) return "SAVE TO FOLDER HDD";
        if (source == HddSource::Image) return "SAVE TO MOUNTED HDD IMAGE";
        return "NO HDD DESTINATION";
    }
};

struct HddMusicFingerprint {
    bool music_exists = false;
    bool database_exists = false;
    uint32_t database_size = 0;
    uint32_t database_first_cluster = 0;
    uint64_t database_hash = 0;
    uint64_t tree_identity_hash = 0;
    bool operator==(const HddMusicFingerprint &b) const
    {
        return music_exists == b.music_exists && database_exists == b.database_exists &&
            database_size == b.database_size && database_first_cluster == b.database_first_cluster &&
            database_hash == b.database_hash && tree_identity_hash == b.tree_identity_hash;
    }
};

struct HddExistingTrack {
    uint16_t song_id = 0;
    uint32_t duration_ms = 0;
    std::string title;
    std::string file_name;
    bool file_present = false;
    uint32_t file_size = 0;
};

struct HddExistingSoundtrack {
    uint16_t soundtrack_id = 0;
    std::string name;
    bool listed_in_database = false;
    bool folder_present = false;
    uint64_t folder_bytes = 0;
    std::vector<HddExistingTrack> tracks;
};

struct HddMusicCatalog {
    bool music_exists = false;
    bool empty_music_directory = false;
    bool database_exists = false;
    bool database_valid = false;
    uint32_t next_soundtrack_id = 0;
    uint32_t next_song_id = 0;
    bool soundtrack_id_index_consistent = true;
    HddMusicFingerprint fingerprint;
    std::vector<HddExistingSoundtrack> soundtracks;
    std::vector<std::string> warnings;
};

struct HddSoundtrackEdit {
    uint16_t soundtrack_id = 0;
    bool delete_soundtrack = false;
    bool fast_stream = true;
    uint32_t stream_chunk_bytes = kCsbStreamChunks[kCsbDefaultStreamChunkIndex];
    bool target_existed = false;
    bool preserve_database = false;
    HddMusicFingerprint expected_fingerprint;
    // Existing WMA files to retain from the target soundtrack. Other soundtrack
    // folders/files are preserved automatically from the mounted music tree.
    std::vector<uint16_t> retained_song_ids;
    // Newly converted WMA files available under local_music/<ID>/... .
    std::vector<uint16_t> local_song_ids;
};

HddDestination DetectCsbHddDestination();
bool SameCsbHddDestination(const HddDestination &a, const HddDestination &b);
bool CsbHddReady(std::string &reason);
void OpenCsbHddDirectory();
bool ReadCsbHddMusicCatalog(const HddDestination &destination,
                            HddMusicCatalog &catalog, std::string &error);

class HddSoundtrackInstaller {
public:
    HddSoundtrackInstaller();
    ~HddSoundtrackInstaller();
    HddSoundtrackInstaller(const HddSoundtrackInstaller &) = delete;
    HddSoundtrackInstaller &operator=(const HddSoundtrackInstaller &) = delete;
    bool Start(const HddDestination &destination, const std::string &music_dir,
               const HddSoundtrackEdit &edit, std::string &error);
    void Tick();
    void Cancel(const std::string &reason, bool recover = true);
    void Shutdown();
    bool Busy() const;
    bool Succeeded() const;
    float Progress() const;
    const std::string &Status() const;
    const std::string &TransferSummary() const;
    std::string OutputPath() const;
private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};
} // namespace XemuCsb
