#include "custom-soundtrack-hdd.hh"
#include "custom-soundtrack-builder-core.hh"
#include "../../disc-block-ref.hh"
#include "../../detached-tools.hh"
#include "../Folder-HDD/folder-hdd.h"
#include "../hdd/guest-kernel-rpc.hh"
#include "../hdd/hdd-directory.hh"
#include "../hdd/hdd-snapshot-service.hh"
#include "../../../../xemu-settings.h"

#include <glib.h>
#include <SDL3/SDL.h>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <filesystem>
#include <functional>
#include <fstream>
#include <set>
#include <utility>
#include <vector>

extern struct config g_config;

namespace XemuCsb {
namespace {
namespace fs = std::filesystem;
using Path = std::vector<std::string>;
const Path kMusicParent = {"TDATA", "fffe0000"};
const Path kMusic = {"TDATA", "fffe0000", "music"};
const Path kRecoveryParent = {"TDATA", "CSBBACKUP"};

std::string NormalizePath(const std::string &path)
{
    if (path.empty()) return {};
    gchar *absolute = g_canonicalize_filename(path.c_str(), nullptr);
    std::string result = absolute ? absolute : path;
    g_free(absolute);
#ifdef _WIN32
    std::replace(result.begin(), result.end(), '\\', '/');
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return static_cast<char>(g_ascii_tolower(c)); });
#endif
    while (result.size() > 1 && result.back() == '/') result.pop_back();
    return result;
}

bool EqualsNoCase(const std::string &a, const std::string &b)
{
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i])) !=
            std::tolower(static_cast<unsigned char>(b[i]))) return false;
    }
    return true;
}

Path Append(Path path, const std::string &leaf)
{
    path.push_back(leaf);
    return path;
}
std::string DisplayPath(const Path &path)
{
    return XemuKernelFs::FatxPathForPartition('E', path);
}

bool Snapshot(XemuFatxHdd::Snapshot &snapshot, std::string &error)
{
    if (!hdd_snapshot_service.BuildRawPartitionSnapshot('E', snapshot, error)) return false;
    const auto *partition = XemuFatxHdd::FindPartition(snapshot, 'E');
    if (!partition || !partition->available) {
        error = "The mounted HDD has no readable FATX E: partition.";
        return false;
    }
    return true;
}

const XemuFatxHdd::Entry *Find(const XemuFatxHdd::Snapshot &snapshot,
                              const Path &path, Path *resolved = nullptr)
{
    if (resolved) resolved->clear();
    const auto *partition = XemuFatxHdd::FindPartition(snapshot, 'E');
    if (!partition) return nullptr;
    const auto *children = &partition->entries;
    const XemuFatxHdd::Entry *entry = nullptr;
    for (const auto &part : path) {
        entry = XemuKernelFs::FindChildNoCase(*children, part);
        if (!entry) return nullptr;
        if (resolved) resolved->push_back(entry->name);
        children = &entry->children;
    }
    return entry;
}

bool ReadEntryBytes(const XemuFatxHdd::Entry &entry, const Path &path,
                    std::vector<uint8_t> &bytes, std::string &error)
{
    bytes.clear();
    if (entry.directory || entry.file_size == 0) {
        error = "Expected a nonempty FATX file: " + DisplayPath(path);
        return false;
    }
    uint64_t offset = 0;
    while (offset < entry.file_size) {
        std::vector<uint8_t> chunk;
        if (!hdd_snapshot_service.ReadFatxFileChunk(
                'E', path, entry.directory_entry_offset, entry.first_cluster,
                entry.modified_time, entry.modified_date, entry.attributes,
                entry.file_size, offset, 1024u * 1024u, chunk, error)) return false;
        if (chunk.empty() || chunk.size() > entry.file_size - offset) {
            error = "Short FATX read: " + DisplayPath(path);
            return false;
        }
        bytes.insert(bytes.end(), chunk.begin(), chunk.end());
        offset += chunk.size();
    }
    return true;
}

uint64_t ContentHash(const std::vector<uint8_t> &bytes)
{
    return XemuKernelFs::UpdateContentHash(XemuKernelFs::kContentHashBasis,
                                            bytes.data(), bytes.size());
}

bool HashEntryContent(const XemuFatxHdd::Entry &entry, const Path &path,
                      uint64_t &hash, std::string &error)
{
    if (entry.directory || entry.file_size == 0) {
        error = "Expected a nonempty FATX file: " + DisplayPath(path);
        return false;
    }
    uint64_t offset = 0;
    hash = XemuKernelFs::kContentHashBasis;
    while (offset < entry.file_size) {
        std::vector<uint8_t> chunk;
        if (!hdd_snapshot_service.ReadFatxFileChunk(
                'E', path, entry.directory_entry_offset, entry.first_cluster,
                entry.modified_time, entry.modified_date, entry.attributes,
                entry.file_size, offset, 1024u * 1024u, chunk, error)) return false;
        if (chunk.empty() || chunk.size() > entry.file_size - offset) {
            error = "Short FATX read: " + DisplayPath(path);
            return false;
        }
        hash = XemuKernelFs::UpdateContentHash(hash, chunk.data(), chunk.size());
        offset += chunk.size();
    }
    return true;
}

bool ParseHex4(const std::string &name, uint16_t &value)
{
    if (name.size() != 4) return false;
    unsigned int v = 0;
    for (char c : name) {
        v <<= 4;
        if (c >= '0' && c <= '9') v |= static_cast<unsigned int>(c - '0');
        else if (c >= 'a' && c <= 'f') v |= static_cast<unsigned int>(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v |= static_cast<unsigned int>(c - 'A' + 10);
        else return false;
    }
    value = static_cast<uint16_t>(v);
    return true;
}

bool ParseWmaFileName(const std::string &name, uint16_t folder_id, uint16_t &song_id)
{
    if (name.size() != 12 || name[8] != '.') return false;
    if (!EqualsNoCase(name.substr(9), "WMA")) return false;
    unsigned long value = 0;
    for (size_t i = 0; i < 8; ++i) {
        const char c = name[i]; value <<= 4;
        if (c >= '0' && c <= '9') value |= static_cast<unsigned long>(c - '0');
        else if (c >= 'a' && c <= 'f') value |= static_cast<unsigned long>(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') value |= static_cast<unsigned long>(c - 'A' + 10);
        else return false;
    }
    if (static_cast<uint16_t>(value >> 16) != folder_id) return false;
    song_id = static_cast<uint16_t>(value & 0xFFFFu);
    return true;
}

uint64_t TreeBytes(const XemuFatxHdd::Entry &entry)
{
    if (!entry.directory) return entry.file_size;
    uint64_t total = 0;
    for (const auto &child : entry.children) total += TreeBytes(child);
    return total;
}

// Metadata-only tree identity. Root-name/time changes caused by relocating a
// directory do not invalidate its identity; descendants must remain unchanged.
uint64_t TreeIdentityHash(const XemuFatxHdd::Entry &entry)
{
    uint64_t hash = XemuKernelFs::kContentHashBasis;
    const auto add = [&](const void *data, size_t size) {
        hash = XemuKernelFs::UpdateContentHash(hash, data, size);
    };
    add(&entry.first_cluster, sizeof(entry.first_cluster));
    add(&entry.directory, sizeof(entry.directory));
    if (!entry.directory) add(&entry.file_size, sizeof(entry.file_size));
    std::vector<const XemuFatxHdd::Entry *> children;
    for (const auto &child : entry.children) children.push_back(&child);
    std::sort(children.begin(), children.end(), [](const auto *a, const auto *b) { return a->name < b->name; });
    for (const auto *child : children) {
        add(child->name.c_str(), child->name.size() + 1);
        add(&child->modified_time, sizeof(child->modified_time));
        add(&child->modified_date, sizeof(child->modified_date));
        const uint64_t child_hash = TreeIdentityHash(*child); add(&child_hash, sizeof(child_hash));
    }
    return hash;
}

bool FingerprintFromSnapshot(const XemuFatxHdd::Snapshot &snapshot,
                             const Path &music_path,
                             HddMusicFingerprint &fingerprint,
                             std::string &error)
{
    fingerprint = {};
    Path resolved;
    const auto *music = Find(snapshot, music_path, &resolved);
    if (!music) return true;
    if (!music->directory) { error = "The music path is no longer a directory."; return false; }
    fingerprint.music_exists = true;
    fingerprint.tree_identity_hash = TreeIdentityHash(*music);
    const auto *db = XemuKernelFs::FindChildNoCase(music->children, "ST.DB");
    if (!db) return true;
    if (db->directory) { error = "ST.DB changed into a directory."; return false; }
    Path db_path = resolved; db_path.push_back(db->name);
    std::vector<uint8_t> bytes;
    if (!ReadEntryBytes(*db, db_path, bytes, error)) return false;
    fingerprint.database_exists = true;
    fingerprint.database_size = db->file_size;
    fingerprint.database_first_cluster = db->first_cluster;
    fingerprint.database_hash = ContentHash(bytes);
    return true;
}

bool SameFingerprint(const HddMusicFingerprint &a, const HddMusicFingerprint &b)
{
    return a.music_exists == b.music_exists &&
           a.database_exists == b.database_exists &&
           a.database_size == b.database_size &&
           a.database_first_cluster == b.database_first_cluster &&
           a.database_hash == b.database_hash &&
           a.tree_identity_hash == b.tree_identity_hash;
}

} // namespace

HddDestination DetectCsbHddDestination()
{
    HddDestination result;
    const bool folder = (int)g_config.sys.files.hdd_type == CONFIG_SYS_FILES_HDD_TYPE_FOLDER;
    const char *selected = folder ? g_config.sys.files.hdd_folder_path : g_config.sys.files.hdd_path;
    result.selected_path = selected ? selected : "";
    if (result.selected_path.empty()) {
        result.reason = "No HDD destination is selected in Settings -> System.";
        return result;
    }
    result.source = folder ? HddSource::Folder : HddSource::Image;
    XemuDiscBlockRef hdd("ide0-hd0");
    if (!hdd || !xemu_disc_block_is_available(hdd.Get())) {
        result.reason = "The selected HDD is not mounted. Start/restart xemu with that HDD.";
        return result;
    }
    result.identity = xemu_disc_block_identity(hdd.Get());
    const bool active_folder = cmp_folder_hdd_is_active();
    char *path = active_folder ? cmp_folder_hdd_get_active_root()
                              : xemu_disc_block_source_path(hdd.Get());
    result.mounted_path = path ? path : "";
    g_free(path);
    if (folder != active_folder || result.mounted_path.empty() ||
        NormalizePath(result.selected_path) != NormalizePath(result.mounted_path)) {
        result.reason = "HDD settings differ from the mounted source. Restart xemu to activate the selected HDD; CSB will not write to the old one.";
        return result;
    }
    if (xemu_disc_block_is_read_only(hdd.Get())) {
        result.reason = "The mounted HDD is read-only.";
        return result;
    }
    result.available = result.identity != 0;
    if (!result.available) result.reason = "The mounted HDD has no stable block-source identity.";
    return result;
}

bool SameCsbHddDestination(const HddDestination &a, const HddDestination &b)
{
    return a.available && b.available && a.source == b.source &&
           a.identity == b.identity &&
           NormalizePath(a.selected_path) == NormalizePath(b.selected_path) &&
           NormalizePath(a.mounted_path) == NormalizePath(b.mounted_path);
}
bool CsbHddReady(std::string &reason)
{
    return guest_kernel_rpc_manager.FilesystemReady(reason);
}
void OpenCsbHddDirectory()
{
    detached_tools_open_or_focus(&hdd_directory_window.is_open);
}

bool ReadCsbHddMusicCatalog(const HddDestination &destination,
                            HddMusicCatalog &catalog, std::string &error)
{
    catalog = {}; error.clear();
    if (!SameCsbHddDestination(destination, DetectCsbHddDestination())) {
        error = "The HDD source changed while CSB was refreshing its soundtrack list.";
        return false;
    }
    XemuFatxHdd::Snapshot snapshot;
    if (!Snapshot(snapshot, error)) return false;
    Path resolved_music;
    const auto *music = Find(snapshot, kMusic, &resolved_music);
    if (!music) return true;
    if (!music->directory) { error = "E:\\TDATA\\fffe0000\\music exists but is not a directory."; return false; }
    catalog.music_exists = true;
    catalog.empty_music_directory = music->children.empty();
    catalog.fingerprint.music_exists = true;
    catalog.fingerprint.tree_identity_hash = TreeIdentityHash(*music);

    const auto *db = XemuKernelFs::FindChildNoCase(music->children, "ST.DB");
    std::vector<StDbSoundtrack> parsed;
    StDbMetadata db_metadata;
    if (db) {
        catalog.database_exists = true;
        catalog.fingerprint.database_exists = true;
        if (db->directory) {
            catalog.warnings.push_back("ST.DB exists as a directory, so soundtrack records cannot be read.");
        } else {
            Path db_path = resolved_music; db_path.push_back(db->name);
            std::vector<uint8_t> bytes;
            if (!ReadEntryBytes(*db, db_path, bytes, error)) return false;
            catalog.fingerprint.database_size = db->file_size;
            catalog.fingerprint.database_first_cluster = db->first_cluster;
            catalog.fingerprint.database_hash = ContentHash(bytes);
            std::string parse_error;
            if (ReadStDb(bytes, parsed, parse_error, &db_metadata)) {
                catalog.database_valid = true;
                catalog.next_soundtrack_id = db_metadata.next_soundtrack_id;
                catalog.next_song_id = db_metadata.next_song_id;
                catalog.soundtrack_id_index_consistent =
                    db_metadata.soundtrack_id_index_matches_records;
                if (!db_metadata.soundtrack_id_index_matches_records)
                    catalog.warnings.push_back(
                        "ST.DB soundtrackIds[] does not match the soundtrack records. "
                        "CSB can read the records and will rewrite the dashboard index on the next successful SAVE/DELETE.");
                if (!db_metadata.next_soundtrack_id_covers_records)
                    catalog.warnings.push_back("ST.DB nextSoundtrackId is behind the active soundtrack IDs; new IDs will be allocated safely above existing records.");
                if (!db_metadata.next_song_id_covers_records)
                    catalog.warnings.push_back("ST.DB nextSongId is behind the active song serials; new songs will be allocated safely above existing records.");
            } else catalog.warnings.push_back("ST.DB could not be parsed safely: " + parse_error);
        }
    } else {
        catalog.warnings.push_back("The music folder has no ST.DB. Folder IDs are shown as unlisted/orphan soundtracks.");
    }

    std::set<uint16_t> database_ids;
    for (const auto &soundtrack : parsed) {
        database_ids.insert(soundtrack.soundtrack_id);
        HddExistingSoundtrack out;
        out.soundtrack_id = soundtrack.soundtrack_id;
        out.name = soundtrack.name;
        out.listed_in_database = true;
        const std::string folder_name = XboxSoundtrackFolderName(soundtrack.soundtrack_id);
        const auto *folder = XemuKernelFs::FindChildNoCase(music->children, folder_name);
        out.folder_present = folder && folder->directory;
        if (folder && folder->directory) out.folder_bytes = TreeBytes(*folder);
        else catalog.warnings.push_back("Soundtrack ID " + std::to_string(soundtrack.soundtrack_id) + " is listed in ST.DB but its folder is missing.");
        for (const auto &track : soundtrack.tracks) {
            HddExistingTrack item;
            item.song_id = track.song_id;
            item.duration_ms = track.duration_ms;
            item.title = track.title;
            item.file_name = XboxSoundtrackFileName(soundtrack.soundtrack_id, track.song_id);
            if (folder && folder->directory) {
                const auto *file = XemuKernelFs::FindChildNoCase(folder->children, item.file_name);
                item.file_present = file && !file->directory;
                if (item.file_present) item.file_size = file->file_size;
            }
            if (!item.file_present) catalog.warnings.push_back("Missing WMA for soundtrack " + std::to_string(soundtrack.soundtrack_id) + ", song " + std::to_string(track.song_id) + ".");
            out.tracks.push_back(std::move(item));
        }
        catalog.soundtracks.push_back(std::move(out));
    }

    // Also surface four-hex FATX folders that are not represented by ST.DB.
    for (const auto &child : music->children) {
        if (!child.directory) continue;
        uint16_t id = 0;
        if (!ParseHex4(child.name, id) || database_ids.count(id)) continue;
        HddExistingSoundtrack out;
        out.soundtrack_id = id;
        out.name = "(unlisted folder)";
        out.folder_present = true;
        out.folder_bytes = TreeBytes(child);
        for (const auto &file : child.children) {
            if (file.directory) continue;
            uint16_t song_id = 0;
            if (!ParseWmaFileName(file.name, id, song_id)) continue;
            HddExistingTrack track;
            track.song_id = song_id;
            track.title = "(unlisted) " + file.display_name;
            track.file_name = file.name;
            track.file_present = true;
            track.file_size = file.file_size;
            out.tracks.push_back(std::move(track));
        }
        std::sort(out.tracks.begin(), out.tracks.end(), [](const auto &a, const auto &b) { return a.song_id < b.song_id; });
        catalog.warnings.push_back("Folder " + child.display_name + " is not referenced by ST.DB; CSB will not adopt it automatically.");
        catalog.soundtracks.push_back(std::move(out));
    }
    std::sort(catalog.soundtracks.begin(), catalog.soundtracks.end(), [](const auto &a, const auto &b) {
        return a.soundtrack_id < b.soundtrack_id;
    });
    return true;
}

struct HddSoundtrackInstaller::Impl {
    enum class Phase {
        Idle, Parents, TransactionDirectory, StageDirectory, BackupDirectory,
        Directories, Files, VerifyHost, FingerprintCheck, MusicDirectory,
        PrepareCommit, Commit, Rollback, PublishedCheck, Sync, CleanupTransaction,
        CleanupRoot, Finalize, Done
    };
    enum class FileKind { CopyFatx, ImportHost };
    struct FileOp {
        FileKind kind = FileKind::ImportHost;
        Path source;
        std::string host_path;
        Path relative;
        uint64_t size = 0, hash = 0;
    };
    struct MoveOp {
        Path source, destination;
        XemuFatxHdd::Entry identity;
        uint64_t content_hash = 0;
        bool check_content = false;
    };
    Phase phase = Phase::Idle, after_rpc = Phase::Idle;
    bool waiting = false, claimed = false, success = false, committed = false;
    bool old_music = false, rolling_back = false, transaction_deleted = false;
    bool hard_cancel = false, abort_recovery = false;
    HddDestination destination;
    HddSoundtrackEdit edit;
    std::string local_music, status, failure, cancel, warning;
    Path music_parent = kMusicParent, music_path = kMusic, recovery_parent = kRecoveryParent;
    Path transaction_path, stage_path, backup_path, database_new_path, database_backup_path;
    std::vector<Path> parent_paths;
    std::vector<Path> directories;
    std::vector<FileOp> files;
    std::vector<MoveOp> moves;
    size_t dir_index = 0, file_index = 0, move_index = 0, applied_moves = 0;
    size_t parent_index = 0;
    uint64_t total_bytes = 0, completed_bytes = 0;
    uint64_t validated_database_hash = 0;
    std::string validated_database_source;
    uint64_t verify_offset = 0, verify_hash = XemuKernelFs::kContentHashBasis;
    bool have_verify_entry = false;
    XemuFatxHdd::Entry verify_entry;
    uint32_t transaction_cluster = 0, stage_cluster = 0, backup_cluster = 0;
    fs::path host_temp_dir;
    GuestKernelRpcManager::HddOperationProgress transfer_totals;
    uint64_t transfer_started_ms = 0;
    std::string transfer_summary;
    static void AddMetrics(GuestKernelRpcManager::HddOperationProgress &a,
                           const GuestKernelRpcManager::HddOperationProgress &b) {
        a.completed_bytes+=b.completed_bytes; a.rpc_calls+=b.rpc_calls;
        a.open_calls+=b.open_calls; a.write_calls+=b.write_calls; a.flush_calls+=b.flush_calls; a.close_calls+=b.close_calls;
        a.wait_ms+=b.wait_ms; a.source_ms+=b.source_ms; a.refill_ms+=b.refill_ms; a.rpc_ms+=b.rpc_ms; a.verify_ms+=b.verify_ms;
        a.safe_point_samples+=b.safe_point_samples;
    }
    void UpdateTransferSummary(bool finished_call=false) {
        auto all=transfer_totals;
        std::string current;
        if(waiting && phase==Phase::Files) {
            auto p=guest_kernel_rpc_manager.GetHddOperationProgress();
            if(finished_call && !p.fast_stream && guest_kernel_rpc_manager.LastFilesystemOperationSucceeded())
                p.completed_bytes=files[file_index].size;
            AddMetrics(all,p);current=p.transfer_phase;
            if(finished_call)transfer_totals=all;
        }
        const double seconds=(SDL_GetTicks()-transfer_started_ms)/1000.0;
        char text[1024];
        const std::string mode = edit.fast_stream ?
            std::string("FAST STREAM (")+XemuKernelStream::ChunkLabel(edit.stream_chunk_bytes)+" max)" :
            "Conservative (52 KiB; detailed counts unavailable)";
        std::snprintf(text,sizeof(text),
            "%s | Written %.2f / %.2f MiB | End-to-end %.2f MiB/s | Elapsed %.1f s\n"
            "File RPCs %llu | Open %llu / Write %llu / Flush %llu / Close %llu | Safe-point samples %llu\n"
            "Source %.3f s | Refill %.3f s | Safe-point wait %.3f s | RPC wall %.3f s | Final readback %.3f s | %s",
            mode.c_str(),
            all.completed_bytes/1048576.0,total_bytes/1048576.0,seconds>0?all.completed_bytes/1048576.0/seconds:0.0,seconds,
            static_cast<unsigned long long>(all.rpc_calls),static_cast<unsigned long long>(all.open_calls),
            static_cast<unsigned long long>(all.write_calls),static_cast<unsigned long long>(all.flush_calls),
            static_cast<unsigned long long>(all.close_calls),static_cast<unsigned long long>(all.safe_point_samples),
            all.source_ms/1000.0,all.refill_ms/1000.0,all.wait_ms/1000.0,all.rpc_ms/1000.0,all.verify_ms/1000.0,current.c_str());
        transfer_summary=text;
    }

    bool Active() const { return phase != Phase::Idle && phase != Phase::Done; }
    bool SameSource() const { return SameCsbHddDestination(destination, DetectCsbHddDestination()); }
    void Release() { if (claimed) guest_kernel_rpc_manager.ReleaseFilesystemSequence(this); claimed = false; }
    void CleanupHostTemp()
    {
        if (host_temp_dir.empty()) return;
        std::error_code ec;
        fs::remove_all(host_temp_dir, ec);
        host_temp_dir.clear();
    }
    void Stop(const std::string &message, bool ok = false)
    {
        status = message; success = ok; phase = Phase::Done; waiting = false;
        UpdateTransferSummary();
        CleanupHostTemp();
        hdd_snapshot_service.NotifyFilesystemChanged(); Release();
    }
    void Fail(const std::string &why)
    {
        std::string text = "CSB soundtrack update stopped: " + why;
        if (!local_music.empty()) text += " Local build/recovery notes: " + local_music + ".";
        if (!transaction_deleted && !transaction_path.empty()) {
            text += " Recovery transaction: " + DisplayPath(transaction_path) + ".";
            if (!stage_path.empty()) text += " Staging: " + DisplayPath(stage_path) + ".";
            if (!backup_path.empty()) text += " Backup: " + DisplayPath(backup_path) + ".";
            if (!edit.preserve_database && !database_new_path.empty())
                text += " New database recovery copy: " + DisplayPath(database_new_path) + ".";
            if (edit.expected_fingerprint.database_exists && !database_backup_path.empty())
                text += " Previous database recovery copy: " + DisplayPath(database_backup_path) + ".";
        }
        if (committed) text += " The new soundtrack update was already published; do not assume it was undone.";
        Stop(text);
    }
    bool WriteReceipt(const std::string &event, std::string &error) const
    {
        std::ofstream out(fs::u8path(local_music) / "CSB-INSTALL-RECOVERY.txt", std::ios::app);
        out << event << "\nHDD: " << destination.mounted_path
            << "\nTarget ID: " << XboxSoundtrackFolderName(edit.soundtrack_id)
            << "\nTransaction: " << DisplayPath(transaction_path)
            << "\nStaging: " << DisplayPath(stage_path)
            << "\nBackup: " << DisplayPath(backup_path)
            << "\nDatabase new: " << DisplayPath(database_new_path)
            << "\nDatabase backup: " << DisplayPath(database_backup_path)
            << "\nCompleted publication moves: " << applied_moves << "/" << moves.size() << '\n';
        for (const auto &move : moves)
            out << DisplayPath(move.source) << " -> " << DisplayPath(move.destination) << '\n';
        out << '\n'; out.flush();
        if (!out.good()) { error = "Unable to write the local CSB recovery receipt."; return false; }
        return true;
    }
    bool BeginDirectory(const Path &path, Phase next, std::string &error)
    {
        Path parent = path; const std::string leaf = parent.back(); parent.pop_back();
        XemuKernelFs::ImportPlan plan;
        if (!guest_kernel_rpc_manager.PrepareHddCreateDirectory(leaf, 'E', parent, plan, error)) return false;
        if (!guest_kernel_rpc_manager.StartHddImport(plan, this)) { error = guest_kernel_rpc_manager.Status(); return false; }
        waiting = true; after_rpc = next; status = "Creating " + DisplayPath(path); return true;
    }
    bool Matches(const XemuFatxHdd::Entry *entry, const MoveOp &move,
                 const Path &path, std::string &error) const
    {
        if (!entry || entry->directory != move.identity.directory ||
            entry->first_cluster != move.identity.first_cluster ||
            (!entry->directory && entry->file_size != move.identity.file_size) ||
            (entry->directory && TreeIdentityHash(*entry) != TreeIdentityHash(move.identity))) {
            error = "Publication/backup identity changed: " + DisplayPath(path); return false;
        }
        if (move.check_content) {
            std::vector<uint8_t> bytes;
            if (!ReadEntryBytes(*entry, path, bytes, error)) return false;
            if (ContentHash(bytes) != move.content_hash) {
                error = "Database content changed: " + DisplayPath(path); return false;
            }
        }
        return true;
    }
    // A kernel rename can have taken effect even if its later verification or
    // cleanup failed. Observe BOTH names before deciding whether to undo it.
    bool ReconcileMove(const MoveOp &move, bool reverse, bool &applied, std::string &error)
    {
        XemuFatxHdd::Snapshot snapshot;
        if (!Snapshot(snapshot, error)) return false;
        const Path &from = reverse ? move.destination : move.source;
        const Path &to = reverse ? move.source : move.destination;
        Path resolved_from, resolved_to;
        const auto *a = Find(snapshot, from, &resolved_from);
        const auto *b = Find(snapshot, to, &resolved_to);
        if (a && !b && Matches(a, move, resolved_from, error)) { applied = false; return true; }
        if (!a && b && Matches(b, move, resolved_to, error)) { applied = true; return true; }
        error = "Ambiguous publication result; automatic recovery refused for " + DisplayPath(from) + " -> " + DisplayPath(to) + ". " + error;
        return false;
    }
    bool BeginMove(const MoveOp &move, bool reverse, std::string &error)
    {
        const Path &from = reverse ? move.destination : move.source;
        const Path &to = reverse ? move.source : move.destination;
        XemuFatxHdd::Snapshot snapshot; Path resolved;
        if (!Snapshot(snapshot, error)) return false;
        const auto *entry = Find(snapshot, from, &resolved);
        if (!Matches(entry, move, resolved, error)) return false;
        if (Find(snapshot, to)) { error = "Refusing to overwrite an occupied publication/recovery path: " + DisplayPath(to); return false; }
        Path parent = to; const std::string leaf = parent.back(); parent.pop_back();
        XemuKernelFs::RelocatePlan plan;
        if (!XemuKernelFs::BuildRelocatePlan(snapshot, 'E', resolved, move.identity.directory,
                                              parent, leaf, plan, error)) return false;
        if (plan.destination_components.size() != to.size() ||
            !std::equal(to.begin(), to.end(), plan.destination_components.begin(), EqualsNoCase)) {
            error = "Unexpected destination in the HDD move/rename plan."; return false;
        }
        if (!guest_kernel_rpc_manager.StartHddRelocate(plan, this)) { error = guest_kernel_rpc_manager.Status(); return false; }
        waiting = true; after_rpc = reverse ? Phase::Rollback : Phase::Commit;
        status = std::string(reverse ? "Restoring " : "Publishing ") + DisplayPath(to);
        return true;
    }
    void TryRestore(const std::string &why)
    {
        failure = why;
        if (!applied_moves) { Fail(why + " Existing soundtracks were not replaced."); return; }
        std::string error;
        if (hard_cancel || !SameSource() || !guest_kernel_rpc_manager.FilesystemReady(error, this)) {
            Fail(why + " Automatic recovery could not safely start. " + error); return;
        }
        rolling_back = true; phase = Phase::Rollback;
        status = "Restoring the affected soundtrack and ST.DB; unrelated soundtracks are untouched...";
    }
    bool VerifyHostChunk(std::string &error)
    {
        FileOp &file = files[file_index];
        Path path = stage_path; path.insert(path.end(), file.relative.begin(), file.relative.end());
        if (!have_verify_entry) {
            XemuFatxHdd::Snapshot snapshot; if (!Snapshot(snapshot, error)) return false;
            const auto *entry = Find(snapshot, path);
            if (!entry || entry->directory || entry->file_size != file.size) { error = "Imported file has wrong type/size: " + DisplayPath(path); return false; }
            verify_entry = *entry; have_verify_entry = true; verify_offset = 0; verify_hash = XemuKernelFs::kContentHashBasis;
        }
        std::vector<uint8_t> chunk;
        if (!hdd_snapshot_service.ReadFatxFileChunk('E', path, verify_entry.directory_entry_offset,
                verify_entry.first_cluster, verify_entry.modified_time, verify_entry.modified_date,
                verify_entry.attributes, file.size, verify_offset, 1024u * 1024u, chunk, error)) return false;
        if (chunk.empty() || chunk.size() > file.size - verify_offset) { error = "Invalid verification read: " + DisplayPath(path); return false; }
        verify_hash = XemuKernelFs::UpdateContentHash(verify_hash, chunk.data(), chunk.size());
        verify_offset += chunk.size();
        status = "Verifying " + DisplayPath(path) + " (" + std::to_string(verify_offset) + "/" + std::to_string(file.size) + ")";
        if (verify_offset == file.size) {
            if (verify_hash != file.hash) { error = "Imported bytes do not match source: " + DisplayPath(path); return false; }
            completed_bytes += file.size; ++file_index; have_verify_entry = false; verify_offset = 0; phase = Phase::Files;
        }
        return true;
    }
    bool FingerprintStillMatches(std::string &error)
    {
        XemuFatxHdd::Snapshot snapshot; HddMusicFingerprint now;
        if (!Snapshot(snapshot, error) || !FingerprintFromSnapshot(snapshot, music_path, now, error)) return false;
        if (!SameFingerprint(edit.expected_fingerprint, now)) {
            error = "The existing music directory/database changed since it was shown in CSB. Refresh before saving."; return false;
        }
        return true;
    }
    bool BuildCommitMoves(std::string &error)
    {
        // Parent/staging setup runs over several ticks. Recheck the original
        // music tree immediately before building the publication journal.
        if (old_music && !FingerprintStillMatches(error)) return false;
        XemuFatxHdd::Snapshot snapshot;
        if (!Snapshot(snapshot, error)) return false;
        if (!old_music) {
            const auto *root = Find(snapshot, music_path);
            if (!root || !root->directory || !root->children.empty()) {
                error = "The newly created music directory was populated by another writer; refresh CSB."; return false;
            }
        }
        const auto *transaction = Find(snapshot, transaction_path);
        const auto *stage = Find(snapshot, stage_path);
        const auto *backup = Find(snapshot, backup_path);
        if (!transaction || !transaction->directory || !stage || !stage->directory ||
            !backup || !backup->directory) {
            error = "CSB recovery transaction/staging disappeared before publication."; return false;
        }
        transaction_cluster = transaction->first_cluster;
        stage_cluster = stage->first_cluster;
        backup_cluster = backup->first_cluster;
        auto same_path = [](const Path &a, const Path &b) {
            if (a.size() != b.size()) return false;
            for (size_t i = 0; i < a.size(); ++i) if (!EqualsNoCase(a[i], b[i])) return false;
            return true;
        };
        auto append = [&](const Path &source, const Path &destination, bool db) {
            Path resolved; const auto *entry = Find(snapshot, source, &resolved);
            if (!entry) { error = "Missing publication source: " + DisplayPath(source); return false; }
            const bool scheduled_to_vacate = std::any_of(moves.begin(), moves.end(),
                [&](const MoveOp &move) { return same_path(move.source, destination); });
            if (Find(snapshot, destination) && !scheduled_to_vacate) {
                error = "Publication/recovery destination is already occupied and is not journaled to move away first: " + DisplayPath(destination); return false;
            }
            MoveOp move; move.source = resolved; move.destination = destination;
            move.identity = *entry; move.check_content = db;
            if (db) {
                std::vector<uint8_t> bytes;
                if (!ReadEntryBytes(*entry, resolved, bytes, error)) return false;
                move.content_hash = ContentHash(bytes);
                if (source == database_new_path && move.content_hash != validated_database_hash) {
                    error = "Staged database.new changed after validation; nothing new will be published."; return false;
                }
            }
            moves.push_back(std::move(move)); return true;
        };
        const std::string id = XboxSoundtrackFolderName(edit.soundtrack_id);
        // Only the selected ID and database are ever moved. No unrelated WMA is
        // copied, renamed or backed up by this transaction.
        if (Find(snapshot, Append(music_path, id)) &&
            !append(Append(music_path, id), Append(backup_path, id), false)) return false;
        if (!edit.delete_soundtrack &&
            !append(Append(stage_path, id), Append(music_path, id), false)) return false;
        if (!edit.preserve_database) {
            if (Find(snapshot, Append(music_path, "ST.DB")) &&
                !append(Append(music_path, "ST.DB"), database_backup_path, true)) return false;
            if (!append(database_new_path, Append(music_path, "ST.DB"), true)) return false;
        }
        return WriteReceipt("Publication planned from E:\\TDATA\\CSBBACKUP; the selected soundtrack is published before music\\ST.DB. Temporary databases are database.new/database.bak.", error);
    }
    bool VerifyPublishedInstall(std::string &error)
    {
        XemuFatxHdd::Snapshot snapshot;
        if (!Snapshot(snapshot, error)) return false;
        for (const auto &move : moves) {
            Path resolved; const auto *entry = Find(snapshot, move.destination, &resolved);
            if (!Matches(entry, move, resolved, error)) return false;
        }
        const std::string id = XboxSoundtrackFolderName(edit.soundtrack_id);
        const Path live_target = Append(music_path, id);
        const auto *target = Find(snapshot, live_target);
        if (edit.delete_soundtrack) {
            if (target) { error = "Deleted soundtrack folder reappeared before final verification: " + DisplayPath(live_target); return false; }
        } else {
            if (!target || !target->directory) { error = "Published soundtrack folder is missing: " + DisplayPath(live_target); return false; }
            for (const auto &file : files) {
                if (file.relative == Path{"database.new"}) continue;
                Path live = music_path; live.insert(live.end(), file.relative.begin(), file.relative.end());
                Path resolved; const auto *entry = Find(snapshot, live, &resolved);
                if (!entry || entry->directory || entry->file_size != file.size) {
                    error = "Published soundtrack file has wrong type/size: " + DisplayPath(live); return false;
                }
                uint64_t hash = 0;
                if (!HashEntryContent(*entry, resolved, hash, error)) return false;
                if (hash != file.hash) {
                    error = "Published soundtrack file failed fresh FATX readback verification: " + DisplayPath(live); return false;
                }
            }
        }
        Path db_path = Append(music_path, "ST.DB"), resolved_db;
        const auto *db = Find(snapshot, db_path, &resolved_db);
        if (edit.preserve_database) {
            if (edit.expected_fingerprint.database_exists != (db != nullptr)) {
                error = "The preserved ST.DB presence changed during the transaction."; return false;
            }
            if (db) {
                if (db->directory || db->file_size != edit.expected_fingerprint.database_size ||
                    db->first_cluster != edit.expected_fingerprint.database_first_cluster) {
                    error = "The preserved ST.DB identity changed during the transaction."; return false;
                }
                uint64_t hash = 0;
                if (!HashEntryContent(*db, resolved_db, hash, error)) return false;
                if (hash != edit.expected_fingerprint.database_hash) {
                    error = "The preserved ST.DB bytes changed during the transaction."; return false;
                }
            }
        } else {
            if (!db || db->directory) { error = "Published music\\ST.DB is missing after publication."; return false; }
            std::vector<uint8_t> bytes;
            if (!ReadEntryBytes(*db, resolved_db, bytes, error)) return false;
            if (ContentHash(bytes) != validated_database_hash) {
                error = "Published music\\ST.DB failed fresh FATX readback verification."; return false;
            }
            std::vector<StDbSoundtrack> parsed;
            if (!ReadStDb(bytes, parsed, error)) {
                error = "Published music\\ST.DB no longer parses safely: " + error; return false;
            }
        }
        return true;
    }
    bool TransactionSafeToDelete(std::string &error)
    {
        XemuFatxHdd::Snapshot snapshot;
        if (!Snapshot(snapshot, error)) return false;
        const auto *transaction = Find(snapshot, transaction_path);
        if (!transaction) return true;
        if (!transaction->directory || transaction->first_cluster != transaction_cluster) {
            error = "Recovery transaction identity changed; retained instead of deleting " + DisplayPath(transaction_path); return false;
        }
        const auto *stage = Find(snapshot, stage_path);
        const auto *backup = Find(snapshot, backup_path);
        if (!stage || !backup || !stage->directory || !backup->directory ||
            stage->first_cluster != stage_cluster || backup->first_cluster != backup_cluster) {
            error = "Recovery transaction subdirectory identity changed; retained instead of deleting " + DisplayPath(transaction_path); return false;
        }
        if (!stage->children.empty()) {
            error = "Staging is not empty after publication; retained instead of deleting " + DisplayPath(transaction_path); return false;
        }
        std::set<std::string> allowed;
        const std::string id = XboxSoundtrackFolderName(edit.soundtrack_id);
        if (edit.target_existed) allowed.insert(id);
        if (!edit.preserve_database && edit.expected_fingerprint.database_exists) allowed.insert("database.bak");
        for (const auto &child : backup->children) {
            bool ok = false;
            for (const auto &name : allowed) if (EqualsNoCase(child.name, name)) { ok = true; break; }
            if (!ok) {
                error = "Unexpected recovery item found; retained instead of deleting " + DisplayPath(transaction_path); return false;
            }
        }
        return true;
    }
    void Tick()
    {
        if (!Active()) return;
        const bool same_source = SameSource();
        if (waiting && guest_kernel_rpc_manager.FilesystemOperationRunning()) {
            if (!same_source || hard_cancel || (!rolling_back && !cancel.empty()) || abort_recovery)
                guest_kernel_rpc_manager.CancelFilesystemOperation(this,
                    !same_source ? "HDD source changed; cancel pending CSB work." : cancel);
            status = (rolling_back ? "RECOVERY: " : "") + guest_kernel_rpc_manager.Status();
            UpdateTransferSummary();
            if (phase == Phase::Files) {
                const auto progress = guest_kernel_rpc_manager.GetHddOperationProgress();
                status += " File " + std::to_string(file_index + 1) + "/" + std::to_string(files.size()) +
                    ": " + std::to_string(progress.completed_bytes) + "/" + std::to_string(progress.total_bytes) + " byte(s) written.";
            }
            return;
        }
        const bool completed_rpc = waiting;
        const bool rpc_ok = completed_rpc && guest_kernel_rpc_manager.LastFilesystemOperationSucceeded();
        if (!same_source) { Fail("HDD source/settings changed. No new operation or recovery was sent to the new source."); return; }
        if (completed_rpc) {
            UpdateTransferSummary(true);
            waiting = false;
            std::string error;
            bool phase_forced = false;
            if (phase == Phase::Commit || phase == Phase::Rollback) {
                bool applied = false;
                const size_t index = rolling_back ? applied_moves - 1 : move_index;
                if (!ReconcileMove(moves[index], rolling_back, applied, error)) { Fail(error); return; }
                if (applied) {
                    if (rolling_back) --applied_moves;
                    else { ++applied_moves; ++move_index; }
                }
                if (!rpc_ok || !applied) {
                    error = guest_kernel_rpc_manager.Status() + (applied ? " The move did take effect." : " The move was not published.");
                    if (rolling_back) { Fail(failure + " Recovery stopped: " + error); return; }
                    TryRestore(error); return;
                }
                if (!WriteReceipt(rolling_back ? "Recovery move verified." : "Publication move verified.", error)) {
                    if (rolling_back) { Fail(failure + " " + error); return; }
                    TryRestore(error); return;
                }
            } else if (!rpc_ok) {
                if (committed && phase == Phase::CleanupTransaction) {
                    warning = " Verified install succeeded, but this transaction could not be removed and was retained at " +
                        DisplayPath(transaction_path) + ": " + guest_kernel_rpc_manager.Status();
                    phase = Phase::Finalize; phase_forced = true;
                } else if (committed && phase == Phase::CleanupRoot) {
                    warning = " Verified install succeeded, but empty " + DisplayPath(recovery_parent) +
                        " could not be removed: " + guest_kernel_rpc_manager.Status();
                    phase = Phase::Finalize; phase_forced = true;
                } else { TryRestore(guest_kernel_rpc_manager.Status()); return; }
            }
            // A host import may use the TEST9 fast-stream backend's own full
            // readback proof. Retained FATX copies are always re-read here so
            // they are compared with the hash captured before staging.
            if (rpc_ok && phase == Phase::Files && files[file_index].kind == FileKind::ImportHost &&
                guest_kernel_rpc_manager.LastImportContentsVerified()) {
                completed_bytes += files[file_index].size; ++file_index; after_rpc = Phase::Files;
            }
            if (rpc_ok && phase == Phase::CleanupTransaction) transaction_deleted = true;
            if (!phase_forced) phase = after_rpc;
        }
        if (hard_cancel || abort_recovery) { Fail(cancel + " Recovery was not continued; inspect retained recovery transaction."); return; }
        if (!cancel.empty() && !rolling_back && !committed) { TryRestore(cancel); return; }
        std::string error;
        switch (phase) {
        case Phase::Parents: {
            if (parent_index >= parent_paths.size()) { phase = Phase::TransactionDirectory; break; }
            const Path path = parent_paths[parent_index++];
            XemuFatxHdd::Snapshot snapshot; if (!Snapshot(snapshot, error)) { Fail(error); break; }
            if (const auto *entry = Find(snapshot, path)) {
                if (!entry->directory) Fail("Parent path is a file: " + DisplayPath(path));
            } else if (!BeginDirectory(path, Phase::Parents, error)) Fail(error);
            break;
        }
        case Phase::TransactionDirectory:
            if (!BeginDirectory(transaction_path, Phase::StageDirectory, error)) Fail(error);
            break;
        case Phase::StageDirectory:
            if (!BeginDirectory(stage_path, Phase::BackupDirectory, error)) Fail(error);
            break;
        case Phase::BackupDirectory:
            if (!BeginDirectory(backup_path, Phase::Directories, error)) Fail(error);
            break;
        case Phase::Directories:
            if (dir_index >= directories.size()) { phase = Phase::Files; break; }
            else {
                Path path = stage_path; path.insert(path.end(), directories[dir_index].begin(), directories[dir_index].end());
                ++dir_index; if (!BeginDirectory(path, Phase::Directories, error)) Fail(error);
            }
            break;
        case Phase::Files: {
            if (file_index >= files.size()) { phase = Phase::FingerprintCheck; break; }
            FileOp &file = files[file_index];
            Path parent = stage_path; parent.insert(parent.end(), file.relative.begin(), file.relative.end() - 1);
            XemuKernelFs::ImportPlan plan;
            if (file.kind == FileKind::CopyFatx) {
                if (!guest_kernel_rpc_manager.PrepareHddCopy('E', file.source, false, 'E', parent, false, plan, error)) { Fail(error); break; }
            } else {
                if (file.relative == Path{"database.new"}) {
                    XemuKernelFs::ImportPlan source_check;
                    if (validated_database_source.empty() ||
                        !guest_kernel_rpc_manager.PrepareHddImport(validated_database_source, false, 'E', stage_path, source_check, error) ||
                        source_check.entries.size() != 1 || source_check.entries[0].directory ||
                        source_check.entries[0].host_content_hash != validated_database_hash) {
                        Fail("Local ST.DB changed after merge validation. Rebuild the soundtrack update. " + error); break;
                    }
                }
                if (!guest_kernel_rpc_manager.PrepareHddImport(file.host_path, false, 'E', parent, plan, error)) { Fail(error); break; }
                if (plan.entries.size() != 1 || plan.entries[0].directory || plan.entries[0].file_size != file.size ||
                    !EqualsNoCase(plan.entries[0].components.back(), file.relative.back())) {
                    Fail("Local CSB file changed or resolved to an unexpected FATX name before import: " + file.host_path); break;
                }
                file.hash = plan.entries[0].host_content_hash;
                if (file.relative == Path{"database.new"} && file.hash != validated_database_hash) {
                    Fail("Temporary database.new changed after merge validation. Rebuild the soundtrack update."); break;
                }
            }
            if (!guest_kernel_rpc_manager.StartHddImport(plan, this)) { Fail(guest_kernel_rpc_manager.Status()); break; }
            waiting = true; after_rpc = Phase::VerifyHost;
            status = (file.kind == FileKind::CopyFatx ? "Staging retained soundtrack file " : "Staging ") + DisplayPath(plan.entries.back().components);
            break;
        }
        case Phase::VerifyHost:
            if (!VerifyHostChunk(error)) Fail(error);
            break;
        case Phase::FingerprintCheck:
            if (!FingerprintStillMatches(error)) Fail(error); else phase = Phase::MusicDirectory;
            break;
        case Phase::MusicDirectory:
            if (old_music) phase = Phase::PrepareCommit;
            else if (!BeginDirectory(music_path, Phase::PrepareCommit, error)) Fail(error);
            break;
        case Phase::PrepareCommit:
            if (!BuildCommitMoves(error)) Fail(error); else phase = Phase::Commit;
            break;
        case Phase::Commit:
            if (move_index == moves.size()) { phase = Phase::PublishedCheck; break; }
            if (!BeginMove(moves[move_index], false, error)) TryRestore(error);
            break;
        case Phase::Rollback:
            if (!applied_moves) {
                if (destination.source == HddSource::Folder && !hdd_snapshot_service.RescanFolderHdd(error))
                    warning = " Recovery finished in E:, but mirror synchronization failed: " + error;
                Fail(failure + " The previous affected soundtrack/database was restored." + warning);
            } else if (!BeginMove(moves[applied_moves - 1], true, error)) Fail(failure + " Recovery refused: " + error);
            break;
        case Phase::PublishedCheck:
            if (!VerifyPublishedInstall(error)) TryRestore("Fresh publication verification failed: " + error);
            else { committed = true; phase = Phase::Sync; }
            break;
        case Phase::CleanupTransaction: {
            if (!TransactionSafeToDelete(error)) {
                warning = " Verified install succeeded, but this transaction was retained at " +
                    DisplayPath(transaction_path) + ": " + error;
                phase = Phase::Finalize; break;
            }
            XemuFatxHdd::Snapshot snapshot;
            if (!Snapshot(snapshot, error)) {
                warning = " Verified install succeeded, but transaction cleanup could not be proven safe; retained " +
                    DisplayPath(transaction_path) + ": " + error;
                phase = Phase::Finalize; break;
            }
            if (!Find(snapshot, transaction_path)) {
                transaction_deleted = true; phase = Phase::CleanupRoot; break;
            }
            std::vector<XemuKernelFs::DeleteEntry> plan;
            if (!guest_kernel_rpc_manager.PrepareHddDelete('E', transaction_path, true, plan, error) ||
                !guest_kernel_rpc_manager.StartHddDelete('E', transaction_path, true, plan, this)) {
                warning = " Verified install succeeded, but this transaction was retained at " +
                    DisplayPath(transaction_path) + ": " + error;
                phase = Phase::Finalize;
            } else {
                waiting = true; after_rpc = Phase::CleanupRoot;
                status = "Removing this verified CSB transaction only: " + DisplayPath(transaction_path);
            }
            break;
        }
        case Phase::CleanupRoot: {
            XemuFatxHdd::Snapshot snapshot;
            if (!Snapshot(snapshot, error)) {
                warning += " Could not inspect " + DisplayPath(recovery_parent) + " for empty-root cleanup: " + error;
                phase = Phase::Finalize; break;
            }
            const auto *root = Find(snapshot, recovery_parent);
            if (!root) { phase = Phase::Finalize; break; }
            if (!root->directory) {
                warning += " " + DisplayPath(recovery_parent) + " is not a directory and was not touched.";
                phase = Phase::Finalize; break;
            }
            if (!root->children.empty()) { phase = Phase::Finalize; break; }
            std::vector<XemuKernelFs::DeleteEntry> plan;
            if (!guest_kernel_rpc_manager.PrepareHddDelete('E', recovery_parent, true, plan, error) ||
                !guest_kernel_rpc_manager.StartHddDelete('E', recovery_parent, true, plan, this)) {
                warning += " Empty " + DisplayPath(recovery_parent) + " could not be removed: " + error;
                phase = Phase::Finalize;
            } else {
                waiting = true; after_rpc = Phase::Finalize;
                status = "Removing empty " + DisplayPath(recovery_parent) + "...";
            }
            break;
        }
        case Phase::Sync:
            if (destination.source == HddSource::Folder && !hdd_snapshot_service.RescanFolderHdd(error)) {
                Fail("Soundtrack update was published and freshly verified in E:, but Folder-HDD mirror synchronization failed: " + error); break;
            }
            phase = Phase::CleanupTransaction;
            break;
        case Phase::Finalize:
            {
                std::string text = edit.delete_soundtrack ? "Deleted soundtrack ID " : (edit.target_existed ? "Updated soundtrack ID " : "Added soundtrack ID ");
                text += XboxSoundtrackFolderName(edit.soundtrack_id) +
                    ". Only that soundtrack and the required database state were changed; unrelated soundtracks were preserved. Fresh FATX readback verified the installed result.";
                if (transaction_deleted) text += " This transaction's staging/backup data was removed.";
                if (destination.source == HddSource::Folder) text += " Folder-HDD mirror synchronized.";
                Stop(text + warning, true);
            }
            break;
        default: break;
        }
    }
};

HddSoundtrackInstaller::HddSoundtrackInstaller() : m_impl(new Impl) {}
HddSoundtrackInstaller::~HddSoundtrackInstaller() = default;

bool HddSoundtrackInstaller::Start(const HddDestination &destination,
                                   const std::string &music_dir,
                                   const HddSoundtrackEdit &edit,
                                   std::string &error)
{
    error.clear();
    if (Busy()) { error = "A CSB HDD operation is already running."; return false; }
    if (edit.fast_stream && !XemuKernelStream::SupportedChunkBytes(edit.stream_chunk_bytes)) {
        error="Invalid CSB stream chunk size. Select 512 KiB, 1 MiB, 2 MiB or 4 MiB.";
        return false;
    }
    if (!SameCsbHddDestination(destination, DetectCsbHddDestination())) { error = "HDD source/settings changed since CSB prepared this operation."; return false; }
    if (!CsbHddReady(error)) return false;
    std::error_code ec;
    if (!fs::is_directory(fs::symlink_status(fs::u8path(music_dir), ec)) || ec) { error = "CSB local staging root is not a real directory."; return false; }
    if (destination.source == HddSource::Folder && !hdd_snapshot_service.RescanFolderHdd(error)) return false;
    HddMusicCatalog catalog;
    if (!ReadCsbHddMusicCatalog(destination, catalog, error)) return false;
    if (!SameFingerprint(edit.expected_fingerprint, catalog.fingerprint)) {
        error = "The music directory/database changed since it was shown in CSB. Refresh before saving."; return false;
    }
    if (catalog.music_exists && !catalog.database_valid && !catalog.empty_music_directory && !edit.preserve_database) {
        error = "Existing ST.DB is missing/invalid. CSB will not replace an unknown collection."; return false;
    }
    const auto target = std::find_if(catalog.soundtracks.begin(), catalog.soundtracks.end(), [&](const auto &s) { return s.soundtrack_id == edit.soundtrack_id; });
    const bool target_exists = target != catalog.soundtracks.end();
    if (edit.target_existed != target_exists || (edit.delete_soundtrack && !target_exists)) {
        error = "That soundtrack ID appeared/disappeared. Refresh and explicitly edit/delete the current entry."; return false;
    }
    if (edit.preserve_database && (!edit.delete_soundtrack || !target_exists || target->listed_in_database)) {
        error = "ST.DB may be left unchanged only when deleting an unlisted/orphan folder."; return false;
    }
    if (!edit.delete_soundtrack && edit.local_song_ids.empty() && edit.retained_song_ids.empty()) { error = "A soundtrack must contain at least one track."; return false; }
    if (target_exists && !target->listed_in_database && !edit.delete_soundtrack) { error = "Orphan folders cannot be silently adopted/overwritten."; return false; }

    auto next = std::make_unique<Impl>(); next->destination = destination; next->edit = edit; next->local_music = music_dir;
    gchar *uuid = g_uuid_string_random(); std::string token = uuid ? uuid : ""; g_free(uuid);
    token.erase(std::remove(token.begin(), token.end(), '-'), token.end());
    if (token.size() < 16) { error = "Unable to allocate unique CSB staging name."; return false; }
    token.resize(16);
    if (!guest_kernel_rpc_manager.ClaimFilesystemSequence(next.get(), error, true, edit.fast_stream, edit.stream_chunk_bytes)) return false;
    next->claimed = true;
    next->transfer_started_ms=SDL_GetTicks();
    const auto reject = [&]() { next->CleanupHostTemp(); next->Release(); return false; };
    XemuFatxHdd::Snapshot snapshot; if (!Snapshot(snapshot, error)) return reject();

    // Resolve only the canonical parents we own. Legacy music.CSB-stage-* and
    // music.CSB-backup-* siblings under fffe0000 are deliberately ignored:
    // older builds may have left recovery data there and this update never
    // guesses that it is safe to delete or reuse it.
    Path tdata = {next->music_parent.front()}, resolved_tdata;
    if (const auto *entry = Find(snapshot, tdata, &resolved_tdata)) {
        if (!entry->directory) { error = "CSB TDATA parent is a file."; return reject(); }
        next->music_parent[0] = resolved_tdata[0];
        next->recovery_parent[0] = resolved_tdata[0];
    }
    Path resolved_parent;
    if (const auto *entry = Find(snapshot, next->music_parent, &resolved_parent)) {
        if (!entry->directory) { error = "CSB music parent is a file: " + DisplayPath(next->music_parent); return reject(); }
        next->music_parent = resolved_parent;
    }
    Path resolved_recovery;
    if (const auto *entry = Find(snapshot, next->recovery_parent, &resolved_recovery)) {
        if (!entry->directory) { error = "CSB recovery parent is a file: " + DisplayPath(next->recovery_parent); return reject(); }
        next->recovery_parent = resolved_recovery;
    }
    next->parent_paths = {{next->music_parent.front()}, next->music_parent, next->recovery_parent};
    next->music_path = Append(next->music_parent, "music");
    next->transaction_path = Append(next->recovery_parent, "CSB-" + token);
    next->stage_path = Append(next->transaction_path, "stage");
    next->backup_path = Append(next->transaction_path, "backup");
    next->database_new_path = Append(next->stage_path, "database.new");
    next->database_backup_path = Append(next->backup_path, "database.bak");
    if (Find(snapshot, next->transaction_path)) { error = "CSB recovery transaction name collision; retry."; return reject(); }
    Path resolved_music;
    const auto *music = Find(snapshot, next->music_path, &resolved_music);
    if (music) {
        if (!music->directory) { error = "The Xbox music path is occupied by a file."; return reject(); }
        next->old_music = true; next->music_path = resolved_music;
    }
    const std::string id = XboxSoundtrackFolderName(edit.soundtrack_id);
    const auto *target_folder = Find(snapshot, Append(next->music_path, id));
    if (target_folder && !target_folder->directory) { error = "The target soundtrack name is occupied by a file."; return reject(); }
    auto add_host = [&](Path rel, const fs::path &override_host = fs::path()) {
        fs::path host = override_host;
        if (host.empty()) {
            host = fs::u8path(music_dir);
            for (const auto &part : rel) host /= fs::u8path(part);
        }
        std::error_code e;
        if (fs::is_symlink(fs::symlink_status(host, e)) || e || !fs::is_regular_file(host, e) || e) {
            error = "Missing/unreadable local CSB file: " + host.u8string(); return false;
        }
        const uint64_t size = fs::file_size(host, e);
        if (e || !size || size > XemuKernelFs::kImportMaxTotalBytes) {
            error = "Each new CSB file must be nonempty and at most 64 MiB: " + host.u8string(); return false;
        }
        next->files.push_back({Impl::FileKind::ImportHost, {}, host.u8string(), rel, size, 0});
        next->total_bytes += size; return true;
    };
    if (!edit.delete_soundtrack) {
        next->directories.push_back({id});
        std::set<uint16_t> seen;
        for (uint16_t song : edit.retained_song_ids) {
            if (!seen.insert(song).second) { error = "Duplicate retained song ID."; return reject(); }
            Path source = Append(Append(next->music_path, id), XboxSoundtrackFileName(edit.soundtrack_id, song)), resolved;
            const auto *entry = Find(snapshot, source, &resolved);
            if (!entry || entry->directory || !entry->file_size || entry->file_size > XemuKernelFs::kImportMaxTotalBytes) {
                error = "Retained target track is missing/invalid or exceeds the HDD copy limit."; return reject();
            }
            uint64_t source_hash = 0;
            if (!HashEntryContent(*entry, resolved, source_hash, error)) return reject();
            next->files.push_back({Impl::FileKind::CopyFatx, resolved, {}, {id, entry->name}, entry->file_size, source_hash});
            next->total_bytes += entry->file_size;
        }
        for (uint16_t song : edit.local_song_ids) {
            if (!seen.insert(song).second) { error = "Duplicate local/retained song ID."; return reject(); }
            if (!add_host({id, XboxSoundtrackFileName(edit.soundtrack_id, song)})) return reject();
        }
    }
    // CSB-BUILD.json is a host-side diagnostic, not a soundtrack. Do not copy
    // it (or any unrelated existing file) to the live music directory.
    if (!edit.preserve_database) {
        const fs::path source_db = fs::u8path(music_dir) / "ST.DB";
        std::error_code db_ec;
        if (fs::is_symlink(fs::symlink_status(source_db, db_ec)) || db_ec ||
            !fs::is_regular_file(source_db, db_ec) || db_ec) {
            error = "Missing/unreadable local CSB ST.DB: " + source_db.u8string(); return reject();
        }
        const uint64_t source_db_size = fs::file_size(source_db, db_ec);
        if (db_ec || !source_db_size || source_db_size > XemuKernelFs::kImportMaxTotalBytes) {
            error = "Local CSB ST.DB must be nonempty and at most 64 MiB."; return reject();
        }
        std::ifstream input(source_db, std::ios::binary);
        const std::vector<uint8_t> bytes{std::istreambuf_iterator<char>(input), {}};
        std::vector<StDbSoundtrack> updated;
        if (input.bad() || bytes.size() != source_db_size || !ReadStDb(bytes, updated, error)) {
            error = "Local ST.DB is invalid: " + error; return reject();
        }
        next->validated_database_hash = ContentHash(bytes);
        next->validated_database_source = source_db.u8string();
        auto same_record = [](const HddExistingSoundtrack &a, const StDbSoundtrack &b) {
            if (a.name != b.name || a.tracks.size() != b.tracks.size()) return false;
            for (size_t i = 0; i < a.tracks.size(); ++i)
                if (a.tracks[i].song_id != b.tracks[i].song_id || a.tracks[i].title != b.tracks[i].title ||
                    a.tracks[i].duration_ms != b.tracks[i].duration_ms) return false;
            return true;
        };
        size_t expected_records = edit.delete_soundtrack ? 0u : 1u;
        for (const auto &old : catalog.soundtracks) {
            if (!old.listed_in_database || old.soundtrack_id == edit.soundtrack_id) continue;
            ++expected_records;
            const auto it = std::find_if(updated.begin(), updated.end(), [&](const auto &item) { return item.soundtrack_id == old.soundtrack_id; });
            if (it == updated.end() || !same_record(old, *it)) {
                error = "Local ST.DB would change an unrelated soundtrack. Refresh and rebuild."; return reject();
            }
        }
        const auto record = std::find_if(updated.begin(), updated.end(), [&](const auto &item) { return item.soundtrack_id == edit.soundtrack_id; });
        if (updated.size() != expected_records || (record == updated.end()) != edit.delete_soundtrack) {
            error = "Local ST.DB does not match the selected add/edit/delete operation."; return reject();
        }
        if (!edit.delete_soundtrack) {
            std::set<uint16_t> planned(edit.retained_song_ids.begin(), edit.retained_song_ids.end());
            planned.insert(edit.local_song_ids.begin(), edit.local_song_ids.end());
            std::set<uint16_t> recorded;
            for (const auto &track : record->tracks) recorded.insert(track.song_id);
            if (planned != recorded) { error = "Local ST.DB song IDs do not match the staged/retained files."; return reject(); }
        }

        // Capture the already-validated database bytes in a private host temp
        // file whose basename is database.new. This keeps every temporary FATX
        // database outside fffe0000 and prevents duplicate ST.DB discovery.
        const fs::path temp_root = fs::temp_directory_path(db_ec);
        if (db_ec || temp_root.empty()) { error = "Unable to locate a host temporary directory for database.new."; return reject(); }
        next->host_temp_dir = temp_root / fs::u8path("xemu-csb-" + token);
        if (!fs::create_directory(next->host_temp_dir, db_ec) || db_ec) {
            error = "Unable to create the private CSB host database staging directory."; return reject();
        }
        const fs::path temp_db = next->host_temp_dir / "database.new";
        {
            std::ofstream output(temp_db, std::ios::binary | std::ios::trunc);
            output.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
            output.flush();
            if (!output.good()) { error = "Unable to create private host database.new."; return reject(); }
        }
        if (!add_host({"database.new"}, temp_db)) return reject();
    }
    HddSnapshotService::CapacityInfo capacity;
    if (!hdd_snapshot_service.QueryPartitionCapacity('E', capacity, error)) return reject();
    const uint64_t cluster = capacity.bytes_per_cluster;
    if (!cluster) { error = "Invalid FATX cluster size."; return reject(); }
    uint64_t required = cluster * (12 + next->directories.size());
    for (const auto &file : next->files) required += ((file.size + cluster - 1) / cluster) * cluster;
    if (required > capacity.free_bytes) { error = "Not enough free E: space for the selected soundtrack and new ST.DB. Required approximately " + std::to_string(required) + "; free " + std::to_string(capacity.free_bytes) + "."; return reject(); }
    if (!next->WriteReceipt("CSB TEST11 isolated recovery transaction prepared under E:\\TDATA\\CSBBACKUP. Live music is untouched until staging verification completes.", error)) return reject();
    next->phase = Impl::Phase::Parents;
    next->status = "Staging soundtrack ID " + id + " and database.new under " + DisplayPath(next->transaction_path) + " through the existing HDD Directory writer...";
    m_impl = std::move(next); return true;
}

void HddSoundtrackInstaller::Tick() { m_impl->Tick(); }
void HddSoundtrackInstaller::Cancel(const std::string &reason, bool recover)
{
    if (!Busy()) return;
    if (m_impl->rolling_back && !m_impl->cancel.empty()) m_impl->abort_recovery = true;
    m_impl->cancel = reason;
    if (!recover) m_impl->hard_cancel = true;
}
void HddSoundtrackInstaller::Shutdown()
{
    if (!Busy()) return;
    guest_kernel_rpc_manager.CancelFilesystemOperation(m_impl.get(), "CSB shutdown.");
    m_impl->Stop("CSB stopped during xemu shutdown. Retained staging/backup may require recovery.");
}
bool HddSoundtrackInstaller::Busy() const { return m_impl->Active(); }
bool HddSoundtrackInstaller::Succeeded() const { return m_impl->success; }
float HddSoundtrackInstaller::Progress() const
{
    if (Succeeded()) return 1.0f;
    if (m_impl->phase == Impl::Phase::Commit || m_impl->committed) return 0.95f;
    if (!m_impl->total_bytes) return 0.0f;
    // Import bytes are visible while a long file is still being written. Read-
    // back verification is separate; do not misleadingly double-count it.
    uint64_t active_bytes = 0;
    if (m_impl->waiting && m_impl->phase == Impl::Phase::Files && m_impl->file_index < m_impl->files.size()) {
        const auto progress = guest_kernel_rpc_manager.GetHddOperationProgress();
        active_bytes = std::min(progress.completed_bytes, m_impl->files[m_impl->file_index].size);
    } else if (m_impl->phase == Impl::Phase::VerifyHost && m_impl->file_index < m_impl->files.size()) {
        active_bytes = m_impl->files[m_impl->file_index].size;
    }
    return static_cast<float>(0.90 * std::min<double>(1.0,
        static_cast<double>(m_impl->completed_bytes + active_bytes) / static_cast<double>(m_impl->total_bytes)));
}
const std::string &HddSoundtrackInstaller::TransferSummary() const { return m_impl->transfer_summary; }
const std::string &HddSoundtrackInstaller::Status() const { return m_impl->status; }
std::string HddSoundtrackInstaller::OutputPath() const
{
    if (!Succeeded()) return {};
    const Path &path = m_impl->music_path;
    if (m_impl->destination.source != HddSource::Folder) return DisplayPath(path);
    fs::path host = fs::u8path(m_impl->destination.mounted_path) / "E";
    for (const auto &part : path) host /= fs::u8path(part);
    return host.u8string();
}
} // namespace XemuCsb
