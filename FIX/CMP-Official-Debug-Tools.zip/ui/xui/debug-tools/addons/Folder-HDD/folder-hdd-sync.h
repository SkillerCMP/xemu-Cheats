#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Private C/C++ bridge for Folder-HDD write-back. */
bool cmp_folder_hdd_sync_effective_read(void *opaque, uint64_t offset,
                                        void *buffer, size_t size);
/* Return details for the most recent failed effective read on this thread.
 * Caller owns the returned string. */
char *cmp_folder_hdd_sync_effective_read_error(void);

bool cmp_folder_hdd_sync_init(void *opaque, const char *root_path,
                              char **error_text);
void cmp_folder_hdd_sync_close(void *opaque);
bool cmp_folder_hdd_sync_refresh_baseline(void *opaque, const char *root_path,
                                           char **error_text);
bool cmp_folder_hdd_sync_host_changed(void *opaque, const char *root_path,
                                      bool *changed, char **error_text);
bool cmp_folder_hdd_sync_guest_to_host(void *opaque, const char *root_path,
                                       uint64_t image_size,
                                       char **status_text);
/* Extended write-back result used by the image-backed C/E bridge. */
bool cmp_folder_hdd_sync_guest_to_host_ex(void *opaque, const char *root_path,
                                          uint64_t image_size,
                                          size_t *host_additions_preserved,
                                          char **status_text);

typedef struct CMPFolderHddAllocationHint {
    char *host_path;
    uint32_t first_cluster;
    uint32_t cluster_count;
    bool directory;
} CMPFolderHddAllocationHint;

/* Collect the live image's current FATX cluster assignments so a host import
 * can rebuild the image without needlessly moving existing paths. */
bool cmp_folder_hdd_sync_collect_allocation_hints(
    void *opaque, const char *root_path, char partition,
    CMPFolderHddAllocationHint **hints, size_t *hint_count,
    uint32_t *high_water_cluster, char **error_text);
void cmp_folder_hdd_sync_free_allocation_hints(
    CMPFolderHddAllocationHint *hints, size_t hint_count);

/* Cross-session image/mirror convergence state. The manifest records the last
 * host tree known to match C.img/E.img; the dirty marker is created before the
 * first guest image write and removed only after a successful mirror commit. */
bool cmp_folder_hdd_sync_persistent_state(const char *root_path,
                                           bool *has_manifest,
                                           bool *host_changed,
                                           bool *image_dirty,
                                           char **error_text);
bool cmp_folder_hdd_sync_mark_image_dirty(const char *root_path,
                                           char **error_text);
bool cmp_folder_hdd_sync_mark_converged(void *opaque, const char *root_path,
                                        char **error_text);

#ifdef __cplusplus
}
#endif
