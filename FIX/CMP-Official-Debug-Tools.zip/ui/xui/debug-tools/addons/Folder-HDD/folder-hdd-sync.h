#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Private C/C++ bridge for Folder-HDD write-back. */
bool cmp_folder_hdd_sync_effective_read(void *opaque, uint64_t offset,
                                        void *buffer, size_t size);

bool cmp_folder_hdd_sync_init(void *opaque, const char *root_path,
                              char **error_text);
void cmp_folder_hdd_sync_close(void *opaque);
bool cmp_folder_hdd_sync_refresh_baseline(void *opaque, const char *root_path,
                                           char **error_text);
bool cmp_folder_hdd_sync_host_changed(void *opaque, const char *root_path,
                                      bool *changed, char **error_text);
bool cmp_folder_hdd_sync_guest_to_host(void *opaque, const char *root_path,
                                       uint64_t image_size,
                                       char **status_text);

#ifdef __cplusplus
}
#endif
