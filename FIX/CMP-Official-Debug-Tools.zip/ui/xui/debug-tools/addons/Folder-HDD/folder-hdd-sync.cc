/* Persistent guest FATX to host-folder synchronization for Folder-HDD. */
#include <glib.h>
#include <glib/gstdio.h>

#include <cerrno>
#include <cstdint>
#include <sys/stat.h>

#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "ui/xui/debug-tools/addons/Folder-HDD/folder-hdd-sync.h"
#include "ui/xui/debug-tools/addons/hdd/fatx-hdd.hh"

namespace {

struct HostEntry {
    bool directory = false;
    uint64_t size = 0;
    int64_t mtime = 0;
};

using HostManifest = std::unordered_map<std::string, HostEntry>;

struct SyncState {
    HostManifest baseline;
};

std::mutex g_sync_states_lock;
std::unordered_map<void *, SyncState> g_sync_states;
uint64_t g_temp_serial = 0;

static bool SameHostEntry(const HostEntry &a, const HostEntry &b)
{
    if (a.directory != b.directory) {
        return false;
    }
    /* Directory mtimes change when children are added/removed and do not
     * represent directory payload in FATX. Child entries carry the actual
     * namespace change, so comparing directory mtimes creates false conflicts. */
    return a.directory || (a.size == b.size && a.mtime == b.mtime);
}

static bool SameManifest(const HostManifest &a, const HostManifest &b)
{
    if (a.size() != b.size()) {
        return false;
    }
    for (const auto &it : a) {
        const auto found = b.find(it.first);
        if (found == b.end() || !SameHostEntry(it.second, found->second)) {
            return false;
        }
    }
    return true;
}

static bool HostWritebackAllowsAdditionsOnly(
    const HostManifest &baseline, const HostManifest &current,
    std::vector<std::string> *additions, std::string &error)
{
    if (additions) {
        additions->clear();
    }
    for (const auto &item : baseline) {
        const auto found = current.find(item.first);
        if (found == current.end()) {
            error = std::string("Folder-HDD host path was removed while Xbox writes were pending: ") +
                    item.first + ". No host files were overwritten.";
            return false;
        }
        if (!SameHostEntry(item.second, found->second)) {
            error = std::string("Folder-HDD host path changed while Xbox writes were pending: ") +
                    item.first + ". No host files were overwritten.";
            return false;
        }
    }
    for (const auto &item : current) {
        if (baseline.find(item.first) == baseline.end()) {
            if (additions) {
                additions->push_back(item.first);
            }
        }
    }
    if (additions) {
        std::sort(additions->begin(), additions->end());
    }
    return true;
}

static std::string JoinRelative(const std::string &parent,
                                const std::string &name)
{
    return parent.empty() ? name : parent + "/" + name;
}

static std::string BuildHostPath(const char *root, const std::string &relative)
{
    gchar *path = g_strdup(root ? root : "");
    size_t start = 0;
    while (start < relative.size()) {
        const size_t slash = relative.find('/', start);
        const size_t end = slash == std::string::npos ? relative.size() : slash;
        const std::string part = relative.substr(start, end - start);
        gchar *next = g_build_filename(path, part.c_str(), nullptr);
        g_free(path);
        path = next;
        if (slash == std::string::npos) {
            break;
        }
        start = slash + 1;
    }
    std::string result = path ? path : "";
    g_free(path);
    return result;
}

static bool ScanHostDirectory(const char *root, const std::string &relative,
                              HostManifest &manifest, unsigned depth,
                              std::string &error)
{
    if (depth > 64) {
        error = "Folder-HDD host directory nesting exceeds the safety limit.";
        return false;
    }

    const std::string full = BuildHostPath(root, relative);
    GStatBuf st;
    if (g_stat(full.c_str(), &st) != 0) {
        error = std::string("Folder-HDD cannot stat host path '") + full +
                "': " + g_strerror(errno);
        return false;
    }
    if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) {
        error = std::string("Folder-HDD host path is not a regular file/directory: ") +
                full;
        return false;
    }

    HostEntry item;
    item.directory = S_ISDIR(st.st_mode);
    item.size = item.directory ? 0 : static_cast<uint64_t>(st.st_size);
    item.mtime = static_cast<int64_t>(st.st_mtime);
    manifest[relative] = item;
    if (!item.directory) {
        return true;
    }

    GError *gerr = nullptr;
    GDir *dir = g_dir_open(full.c_str(), 0, &gerr);
    if (!dir) {
        error = std::string("Folder-HDD cannot open host directory '") + full +
                "': " + (gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        return false;
    }

    std::vector<std::string> names;
    const char *name = nullptr;
    while ((name = g_dir_read_name(dir)) != nullptr) {
        if (!strcmp(name, ".") || !strcmp(name, "..")) {
            continue;
        }
        names.emplace_back(name);
    }
    g_dir_close(dir);
    std::sort(names.begin(), names.end(), [](const std::string &a,
                                             const std::string &b) {
        return g_ascii_strcasecmp(a.c_str(), b.c_str()) < 0;
    });

    for (const std::string &child : names) {
        if (!ScanHostDirectory(root, JoinRelative(relative, child), manifest,
                               depth + 1, error)) {
            return false;
        }
    }
    return true;
}

static bool ScanHostManifest(const char *root, HostManifest &manifest,
                             std::string &error)
{
    static const char *const partitions[] = { "C", "E" };
    manifest.clear();
    error.clear();
    for (const char *letter : partitions) {
        const std::string full = BuildHostPath(root, letter);
        GStatBuf st;
        if (g_stat(full.c_str(), &st) != 0) {
            if (errno == ENOENT) {
                continue;
            }
            error = std::string("Folder-HDD cannot stat host partition '") +
                    full + "': " + g_strerror(errno);
            return false;
        }
        if (!S_ISDIR(st.st_mode)) {
            error = std::string("Folder-HDD partition path is not a directory: ") +
                    full;
            return false;
        }
        if (!ScanHostDirectory(root, letter, manifest, 0, error)) {
            return false;
        }
    }
    return true;
}

static bool SetStatus(char **status_text, const std::string &text, bool result)
{
    if (status_text) {
        g_free(*status_text);
        *status_text = g_strdup(text.c_str());
    }
    return result;
}

static bool ValidGuestName(const std::string &name, std::string &error)
{
    if (name.empty() || name == "." || name == ".." || name.size() > 42) {
        error = "FATX guest created an invalid host filename.";
        return false;
    }
    if (!g_utf8_validate(name.c_str(), static_cast<gssize>(name.size()), nullptr)) {
        error = "FATX filename is not valid UTF-8 and cannot be written safely to the host.";
        return false;
    }
    for (unsigned char c : name) {
        if (c < 0x20 || c == '/' || c == '\\' || c == ':' || c == '*' ||
            c == '?' || c == '"' || c == '<' || c == '>' || c == '|') {
            error = std::string("FATX filename cannot be represented safely on the host: ") +
                    name;
            return false;
        }
    }
    if (name.back() == ' ' || name.back() == '.') {
        error = std::string("FATX filename ends in a Windows-unsafe character: ") + name;
        return false;
    }

    std::string base = name;
    const size_t dot = base.find('.');
    if (dot != std::string::npos) {
        base.resize(dot);
    }
    std::transform(base.begin(), base.end(), base.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    const bool reserved = base == "CON" || base == "PRN" || base == "AUX" ||
                          base == "NUL" ||
                          (base.size() == 4 &&
                           ((base.compare(0, 3, "COM") == 0) ||
                            (base.compare(0, 3, "LPT") == 0)) &&
                           base[3] >= '1' && base[3] <= '9');
    if (reserved) {
        error = std::string("FATX filename is a reserved Windows device name: ") + name;
        return false;
    }
    return true;
}

struct GuestNode {
    const XemuFatxHdd::Partition *partition = nullptr;
    const XemuFatxHdd::Entry *entry = nullptr;
    bool directory = false;
};

using GuestManifest = std::unordered_map<std::string, GuestNode>;

static bool AddGuestEntries(const XemuFatxHdd::Partition &partition,
                            const std::vector<XemuFatxHdd::Entry> &entries,
                            const std::string &parent,
                            GuestManifest &manifest, std::string &error)
{
    for (const XemuFatxHdd::Entry &entry : entries) {
        if (!ValidGuestName(entry.name, error)) {
            return false;
        }
        const std::string relative = JoinRelative(parent, entry.name);
        if (!manifest.emplace(relative,
                              GuestNode{&partition, &entry, entry.directory}).second) {
            error = std::string("Duplicate FATX path encountered during host write-back: ") +
                    relative;
            return false;
        }
        if (entry.directory &&
            !AddGuestEntries(partition, entry.children, relative, manifest,
                             error)) {
            return false;
        }
    }
    return true;
}

static bool BuildGuestManifest(XemuFatxHdd::Snapshot &snapshot,
                               GuestManifest &manifest, std::string &error)
{
    manifest.clear();
    for (XemuFatxHdd::Partition &partition : snapshot.partitions) {
        if (!partition.available ||
            (partition.letter != 'C' && partition.letter != 'E')) {
            continue;
        }
        const std::string root(1, partition.letter);
        manifest.emplace(root, GuestNode{&partition, nullptr, true});
        if (!AddGuestEntries(partition, partition.entries, root, manifest,
                             error)) {
            return false;
        }
    }
    return true;
}

static size_t PathDepth(const std::string &path)
{
    return static_cast<size_t>(std::count(path.begin(), path.end(), '/'));
}

static bool FlushHostFile(FILE *fp, std::string &error)
{
    if (fflush(fp) != 0) {
        error = std::string("Host write flush failed: ") + g_strerror(errno);
        return false;
    }
#ifdef _WIN32
    if (_commit(_fileno(fp)) != 0) {
#else
    if (fsync(fileno(fp)) != 0) {
#endif
        error = std::string("Host write durable flush failed: ") + g_strerror(errno);
        return false;
    }
    return true;
}

static bool CreateTransactionDirectory(const char *root,
                                       std::string &temp_root,
                                       std::string &temp_dir,
                                       std::string &error)
{
    temp_root = BuildHostPath(root, ".cmp-folder-hdd-tmp");
    if (g_mkdir_with_parents(temp_root.c_str(), 0700) != 0) {
        error = std::string("Could not create Folder-HDD write-back staging directory: ") +
                g_strerror(errno);
        return false;
    }

    gchar *pattern = g_build_filename(temp_root.c_str(), "txn-XXXXXX", nullptr);
    if (!g_mkdtemp(pattern)) {
        error = std::string("Could not create Folder-HDD write-back transaction directory: ") +
                g_strerror(errno);
        g_free(pattern);
        return false;
    }
    temp_dir = pattern;
    g_free(pattern);
    return true;
}

struct StagedFile {
    std::string relative;
    std::string target;
    std::string temp;
};

struct BackupFile {
    std::string target;
    std::string backup;
};

struct RemovedDirectory {
    std::string path;
};

struct CreatedDirectory {
    std::string path;
};

struct InstalledFile {
    std::string path;
};

static bool MoveHostFileToBackup(const std::string &target,
                                 const std::string &temp_dir,
                                 std::vector<BackupFile> &backups,
                                 std::string &error)
{
    const uint64_t serial = ++g_temp_serial;
    gchar *backup_raw = g_strdup_printf("backup-%" G_GUINT64_FORMAT ".tmp",
                                        static_cast<guint64>(serial));
    gchar *backup_path_raw =
        g_build_filename(temp_dir.c_str(), backup_raw, nullptr);
    std::string backup = backup_path_raw;
    g_free(backup_path_raw);
    g_free(backup_raw);

    if (g_rename(target.c_str(), backup.c_str()) != 0) {
        error = std::string("Could not stage existing host file '") + target +
                "' for rollback: " + g_strerror(errno);
        return false;
    }
    backups.push_back({target, std::move(backup)});
    return true;
}

static bool InstallStagedFile(StagedFile &file, const std::string &temp_dir,
                              std::vector<BackupFile> &backups,
                              std::vector<InstalledFile> &installed,
                              std::string &error)
{
    GStatBuf st;
    if (g_stat(file.target.c_str(), &st) == 0) {
        if (!S_ISREG(st.st_mode)) {
            error = std::string("Host destination unexpectedly became a non-file during write-back: ") +
                    file.target;
            return false;
        }
        if (!MoveHostFileToBackup(file.target, temp_dir, backups, error)) {
            return false;
        }
    } else if (errno != ENOENT) {
        error = std::string("Could not stat host destination '") + file.target +
                "': " + g_strerror(errno);
        return false;
    }

    if (g_rename(file.temp.c_str(), file.target.c_str()) != 0) {
        const int saved = errno;
        /* Restore this target; rollback handles earlier operations. */
        if (!backups.empty() && backups.back().target == file.target &&
            g_rename(backups.back().backup.c_str(), file.target.c_str()) == 0) {
            backups.pop_back();
        }
        error = std::string("Could not install host file '") + file.target +
                "': " + g_strerror(saved);
        return false;
    }
    file.temp.clear();
    installed.push_back({file.target});
    return true;
}

static bool RollbackHostChanges(std::vector<InstalledFile> &installed,
                                std::vector<CreatedDirectory> &created_dirs,
                                std::vector<RemovedDirectory> &removed_dirs,
                                std::vector<BackupFile> &backups,
                                std::string &rollback_error)
{
    bool ok = true;
    std::string first_error;

    for (auto it = installed.rbegin(); it != installed.rend(); ++it) {
        if (g_remove(it->path.c_str()) != 0 && errno != ENOENT) {
            if (first_error.empty()) {
                first_error = std::string("could not remove installed file '") +
                              it->path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(created_dirs.begin(), created_dirs.end(),
              [](const CreatedDirectory &a, const CreatedDirectory &b) {
        if (PathDepth(a.path) != PathDepth(b.path)) {
            return PathDepth(a.path) > PathDepth(b.path);
        }
        return a.path.size() > b.path.size();
    });
    for (const CreatedDirectory &dir : created_dirs) {
        if (g_rmdir(dir.path.c_str()) != 0 && errno != ENOENT) {
            if (first_error.empty()) {
                first_error = std::string("could not remove created directory '") +
                              dir.path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(removed_dirs.begin(), removed_dirs.end(),
              [](const RemovedDirectory &a, const RemovedDirectory &b) {
        if (PathDepth(a.path) != PathDepth(b.path)) {
            return PathDepth(a.path) < PathDepth(b.path);
        }
        return a.path.size() < b.path.size();
    });
    for (const RemovedDirectory &dir : removed_dirs) {
        GStatBuf st;
        if (g_stat(dir.path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            continue;
        }
        if (g_mkdir(dir.path.c_str(), 0755) != 0 && errno != EEXIST) {
            if (first_error.empty()) {
                first_error = std::string("could not restore directory '") +
                              dir.path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(backups.begin(), backups.end(),
              [](const BackupFile &a, const BackupFile &b) {
        if (PathDepth(a.target) != PathDepth(b.target)) {
            return PathDepth(a.target) < PathDepth(b.target);
        }
        return a.target.size() < b.target.size();
    });
    for (const BackupFile &backup : backups) {
        if (g_rename(backup.backup.c_str(), backup.target.c_str()) != 0) {
            if (first_error.empty()) {
                first_error = std::string("could not restore host file '") +
                              backup.target + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    rollback_error = first_error;
    return ok;
}

static void FinalizeBackups(const std::vector<BackupFile> &backups)
{
    for (const BackupFile &backup : backups) {
        (void)g_remove(backup.backup.c_str());
    }
}

static bool StageGuestFile(void *opaque, uint64_t image_size,
                           const GuestNode &node, const std::string &target,
                           const std::string &temp_dir,
                           std::string &staged_temp, std::string &error)
{
    staged_temp.clear();
    if (!node.partition || !node.entry || node.directory) {
        error = "Invalid FATX file write-back node.";
        return false;
    }

    GStatBuf host_st;
    const bool host_exists = g_stat(target.c_str(), &host_st) == 0;
    const bool can_compare = host_exists && S_ISREG(host_st.st_mode) &&
                             static_cast<uint64_t>(host_st.st_size) ==
                                 node.entry->file_size;
    FILE *existing = can_compare ? g_fopen(target.c_str(), "rb") : nullptr;

    const uint64_t serial = ++g_temp_serial;
    gchar *temp_name_raw = g_strdup_printf("write-%" G_GUINT64_FORMAT ".tmp",
                                           static_cast<guint64>(serial));
    gchar *temp_path_raw = g_build_filename(temp_dir.c_str(), temp_name_raw, nullptr);
    std::string temp = temp_path_raw;
    g_free(temp_path_raw);
    g_free(temp_name_raw);

    FILE *out = g_fopen(temp.c_str(), "wb");
    if (!out) {
        if (existing) {
            fclose(existing);
        }
        error = std::string("Could not create Folder-HDD temporary host file: ") +
                g_strerror(errno);
        return false;
    }

    bool same = existing != nullptr;
    XemuFatxHdd::FileReadCursor cursor;
    uint64_t offset = 0;
    std::vector<uint8_t> guest;
    std::vector<uint8_t> host;
    while (offset < node.entry->file_size) {
        const size_t wanted = static_cast<size_t>(std::min<uint64_t>(
            1024u * 1024u, static_cast<uint64_t>(node.entry->file_size) - offset));
        std::string read_error;
        if (!XemuFatxHdd::ReadFileRangeSequential(
                cmp_folder_hdd_sync_effective_read, opaque, image_size,
                *node.partition, *node.entry, offset, wanted, cursor, guest,
                read_error)) {
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            char *effective_error = cmp_folder_hdd_sync_effective_read_error();
            error = std::string("Could not read guest FATX file '") + target +
                    "': " + (effective_error && effective_error[0]
                                  ? effective_error
                                  : read_error.c_str());
            g_free(effective_error);
            return false;
        }
        if (!guest.empty() && fwrite(guest.data(), 1, guest.size(), out) != guest.size()) {
            const int saved = errno;
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            error = std::string("Could not stage host file '") + target +
                    "': " + g_strerror(saved ? saved : EIO);
            return false;
        }
        if (same) {
            host.resize(guest.size());
            const size_t got = guest.empty() ? 0 :
                fread(host.data(), 1, host.size(), existing);
            if (got != guest.size() ||
                (!guest.empty() && memcmp(host.data(), guest.data(), guest.size()) != 0)) {
                same = false;
            }
        }
        offset += guest.size();
        if (guest.empty() && offset < node.entry->file_size) {
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            error = "Guest FATX file read made no progress.";
            return false;
        }
    }

    if (!FlushHostFile(out, error)) {
        fclose(out);
        if (existing) {
            fclose(existing);
        }
        (void)g_remove(temp.c_str());
        return false;
    }
    if (fclose(out) != 0) {
        if (existing) {
            fclose(existing);
        }
        (void)g_remove(temp.c_str());
        error = std::string("Could not close Folder-HDD temporary file: ") +
                g_strerror(errno);
        return false;
    }
    if (existing) {
        if (same && fgetc(existing) != EOF) {
            same = false;
        }
        fclose(existing);
    }

    if (same) {
        (void)g_remove(temp.c_str());
        return true;
    }
    staged_temp = std::move(temp);
    return true;
}

static void CleanupStagedFiles(const std::vector<StagedFile> &staged)
{
    for (const StagedFile &file : staged) {
        if (!file.temp.empty()) {
            (void)g_remove(file.temp.c_str());
        }
    }
}

static bool MirrorGuestToHost(void *opaque, const char *root,
                              uint64_t image_size,
                              const HostManifest &baseline,
                              XemuFatxHdd::Snapshot &snapshot,
                              size_t &files_changed, size_t &paths_deleted,
                              size_t &dirs_created,
                              size_t &host_additions_preserved,
                              std::string &error)
{
    GuestManifest guest;
    if (!BuildGuestManifest(snapshot, guest, error)) {
        return false;
    }

    /* Never interpret an unreadable guest partition as a host delete. */
    for (const char letter : std::string("CE")) {
        const std::string root_path(1, letter);
        if (baseline.find(root_path) != baseline.end() &&
            guest.find(root_path) == guest.end()) {
            error = std::string("Folder-HDD refused host write-back because FATX ") +
                    letter + ": is not readable at the commit boundary.";
            return false;
        }
    }

    std::string temp_root;
    std::string temp_dir;
    if (!CreateTransactionDirectory(root, temp_root, temp_dir, error)) {
        return false;
    }

    /* Stage all guest file data before changing the host namespace. */
    std::vector<std::pair<std::string, GuestNode>> files;
    for (const auto &item : guest) {
        if (!item.second.directory) {
            files.emplace_back(item.first, item.second);
        }
    }
    std::sort(files.begin(), files.end(), [](const auto &a, const auto &b) {
        return a.first < b.first;
    });

    std::vector<StagedFile> staged;
    for (const auto &item : files) {
        const std::string full = BuildHostPath(root, item.first);
        std::string temp;
        if (!StageGuestFile(opaque, image_size, item.second, full, temp_dir,
                            temp, error)) {
            CleanupStagedFiles(staged);
            (void)g_rmdir(temp_dir.c_str());
            (void)g_rmdir(temp_root.c_str());
            return false;
        }
        if (!temp.empty()) {
            staged.push_back({item.first, full, std::move(temp)});
        }
    }

    /* Re-check the host baseline after staging, before namespace changes. */
    HostManifest before_apply;
    std::string scan_error;
    if (!ScanHostManifest(root, before_apply, scan_error)) {
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        error = scan_error;
        return false;
    }
    std::vector<std::string> host_additions;
    if (!HostWritebackAllowsAdditionsOnly(baseline, before_apply,
                                           &host_additions, error)) {
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        return false;
    }

    /* New host-only paths are safe to preserve as long as the Xbox is not
     * independently trying to create a different object at the same path.
     * StageGuestFile omits a temp file when the guest bytes already match the
     * new host file, which is a converged (non-conflicting) result. */
    std::unordered_map<std::string, const StagedFile *> staged_by_relative;
    for (const StagedFile &file : staged) {
        staged_by_relative.emplace(file.relative, &file);
    }
    for (const std::string &relative : host_additions) {
        const auto host_it = before_apply.find(relative);
        const auto guest_it = guest.find(relative);
        if (guest_it == guest.end()) {
            continue;
        }
        if (host_it == before_apply.end() ||
            host_it->second.directory != guest_it->second.directory) {
            CleanupStagedFiles(staged);
            (void)g_rmdir(temp_dir.c_str());
            (void)g_rmdir(temp_root.c_str());
            error = std::string(
                "Folder-HDD host/Xbox addition conflict at '") + relative +
                "'; neither side was overwritten.";
            return false;
        }
        if (!guest_it->second.directory &&
            staged_by_relative.find(relative) != staged_by_relative.end()) {
            CleanupStagedFiles(staged);
            (void)g_rmdir(temp_dir.c_str());
            (void)g_rmdir(temp_root.c_str());
            error = std::string(
                "Folder-HDD host/Xbox file-addition conflict at '") + relative +
                "'; the two new files differ and neither side was overwritten.";
            return false;
        }
    }
    host_additions_preserved = host_additions.size();

    std::vector<BackupFile> backups;
    std::vector<RemovedDirectory> removed_dirs;
    std::vector<CreatedDirectory> created_dirs;
    std::vector<InstalledFile> installed;
    auto fail_with_rollback = [&](const std::string &primary_error) {
        std::string rollback_error;
        const bool rolled_back = RollbackHostChanges(
            installed, created_dirs, removed_dirs, backups, rollback_error);
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        if (rolled_back) {
            error = primary_error + " Host changes from this commit were rolled back.";
        } else {
            error = primary_error +
                    " Automatic rollback was incomplete: " +
                    (rollback_error.empty() ? std::string("unknown rollback error")
                                            : rollback_error) +
                    ". Stop xemu and inspect .cmp-folder-hdd-tmp before continuing.";
        }
        return false;
    };

    std::vector<std::string> deletions;
    deletions.reserve(baseline.size());
    for (const auto &item : baseline) {
        const auto found = guest.find(item.first);
        const bool partition_root = item.first.size() == 1;
        if (partition_root) {
            continue;
        }
        if (found == guest.end() ||
            found->second.directory != item.second.directory) {
            deletions.push_back(item.first);
        }
    }
    std::sort(deletions.begin(), deletions.end(), [](const std::string &a,
                                                      const std::string &b) {
        if (PathDepth(a) != PathDepth(b)) {
            return PathDepth(a) > PathDepth(b);
        }
        return a.size() > b.size();
    });
    for (const std::string &relative : deletions) {
        const std::string full = BuildHostPath(root, relative);
        const auto base = baseline.find(relative);
        if (base == baseline.end()) {
            continue;
        }
        if (base->second.directory) {
            if (g_rmdir(full.c_str()) != 0) {
                const std::string why =
                    std::string("Could not remove host directory '") + full +
                    "' during FATX write-back: " + g_strerror(errno);
                return fail_with_rollback(why);
            }
            removed_dirs.push_back({full});
        } else {
            if (!MoveHostFileToBackup(full, temp_dir, backups, error)) {
                return fail_with_rollback(error);
            }
        }
        ++paths_deleted;
    }

    std::vector<std::string> directories;
    for (const auto &item : guest) {
        if (item.second.directory) {
            directories.push_back(item.first);
        }
    }
    std::sort(directories.begin(), directories.end(), [](const std::string &a,
                                                          const std::string &b) {
        if (PathDepth(a) != PathDepth(b)) {
            return PathDepth(a) < PathDepth(b);
        }
        return a.size() < b.size();
    });
    for (const std::string &relative : directories) {
        const std::string full = BuildHostPath(root, relative);
        GStatBuf st;
        if (g_stat(full.c_str(), &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                continue;
            }
            return fail_with_rollback(
                std::string("Host path unexpectedly remained a file while creating directory '") +
                full + "'.");
        }
        if (errno != ENOENT) {
            return fail_with_rollback(
                std::string("Could not stat host directory '") + full +
                "': " + g_strerror(errno));
        }
        if (g_mkdir(full.c_str(), 0755) != 0) {
            return fail_with_rollback(
                std::string("Could not create host directory '") + full +
                "': " + g_strerror(errno));
        }
        created_dirs.push_back({full});
        ++dirs_created;
    }

    for (StagedFile &file : staged) {
        gchar *parent_raw = g_path_get_dirname(file.target.c_str());
        const std::string parent = parent_raw ? parent_raw : "";
        g_free(parent_raw);
        GStatBuf parent_st;
        if (g_stat(parent.c_str(), &parent_st) != 0 ||
            !S_ISDIR(parent_st.st_mode)) {
            return fail_with_rollback(
                std::string("Host parent directory is unavailable while installing '") +
                file.target + "'.");
        }
        if (!InstallStagedFile(file, temp_dir, backups, installed, error)) {
            return fail_with_rollback(error);
        }
        ++files_changed;
    }

    /* Keep backups until the full commit succeeds. */
    FinalizeBackups(backups);
    CleanupStagedFiles(staged);
    (void)g_rmdir(temp_dir.c_str());
    (void)g_rmdir(temp_root.c_str());
    return true;
}

static bool ReadEffective(void *opaque, uint64_t offset, void *buffer,
                          size_t size)
{
    return cmp_folder_hdd_sync_effective_read(opaque, offset, buffer, size);
}

static bool BuildPersistentSnapshot(void *opaque, uint64_t image_size,
                                    XemuFatxHdd::Snapshot &snapshot,
                                    std::string &error)
{
    snapshot = {};
    snapshot.hdd_available = true;
    snapshot.image_size = image_size;
    for (const char letter : std::string("CE")) {
        XemuFatxHdd::Snapshot one;
        if (!XemuFatxHdd::BuildPartitionSnapshot(
                ReadEffective, opaque, image_size, letter, one)) {
            error = one.status.empty()
                ? std::string("Folder-HDD could not parse FATX ") + letter +
                      ": for host write-back."
                : one.status;
            snapshot = {};
            return false;
        }
        for (XemuFatxHdd::Partition &partition : one.partitions) {
            snapshot.partitions.push_back(std::move(partition));
        }
    }
    snapshot.status = "Persistent C/E FATX snapshot captured.";
    return true;
}

static bool GetBaseline(void *opaque, HostManifest &baseline)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    const auto it = g_sync_states.find(opaque);
    if (it == g_sync_states.end()) {
        return false;
    }
    baseline = it->second.baseline;
    return true;
}

static void SetBaseline(void *opaque, HostManifest manifest)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    g_sync_states[opaque].baseline = std::move(manifest);
}

static std::string ImageMetadataPath(const char *root, const char *name)
{
    gchar *images = g_build_filename(root ? root : "", "Images", nullptr);
    gchar *path = g_build_filename(images, name, nullptr);
    std::string result = path ? path : "";
    g_free(path);
    g_free(images);
    return result;
}

static bool SaveHostManifestFile(const char *root, const HostManifest &manifest,
                                 std::string &error)
{
    const std::string target = ImageMetadataPath(root, "ce-sync-baseline.tsv");
    const std::string temp = target + ".tmp";
    GString *text = g_string_new("CMP-CE-IMAGE-MANIFEST-1\n");
    std::vector<std::string> paths;
    paths.reserve(manifest.size());
    for (const auto &item : manifest) {
        paths.push_back(item.first);
    }
    std::sort(paths.begin(), paths.end());
    for (const std::string &path : paths) {
        const HostEntry &entry = manifest.at(path);
        gchar *encoded = g_base64_encode(
            reinterpret_cast<const guchar *>(path.data()), path.size());
        if (entry.directory) {
            g_string_append_printf(text, "D\t%s\n", encoded ? encoded : "");
        } else {
            g_string_append_printf(text, "F\t%s\t%" G_GUINT64_FORMAT
                                         "\t%" G_GINT64_FORMAT "\n",
                                   encoded ? encoded : "",
                                   static_cast<guint64>(entry.size),
                                   static_cast<gint64>(entry.mtime));
        }
        g_free(encoded);
    }

    GError *gerr = nullptr;
    const bool wrote = g_file_set_contents(temp.c_str(), text->str,
                                            static_cast<gssize>(text->len),
                                            &gerr);
    g_string_free(text, TRUE);
    if (!wrote) {
        error = std::string("Folder-HDD could not write C/E sync manifest: ") +
                (gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        (void)g_remove(temp.c_str());
        return false;
    }
    if (g_rename(temp.c_str(), target.c_str()) != 0) {
        error = std::string("Folder-HDD could not install C/E sync manifest '") +
                target + "': " + g_strerror(errno);
        (void)g_remove(temp.c_str());
        return false;
    }
    return true;
}

static bool LoadHostManifestFile(const char *root, HostManifest &manifest,
                                 bool &present, std::string &error)
{
    const std::string path = ImageMetadataPath(root, "ce-sync-baseline.tsv");
    manifest.clear();
    present = false;
    gchar *contents = nullptr;
    gsize length = 0;
    GError *gerr = nullptr;
    if (!g_file_get_contents(path.c_str(), &contents, &length, &gerr)) {
        if (gerr && gerr->domain == G_FILE_ERROR &&
            gerr->code == G_FILE_ERROR_NOENT) {
            g_clear_error(&gerr);
            return true;
        }
        error = std::string("Folder-HDD could not read C/E sync manifest: ") +
                (gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        return false;
    }
    present = true;
    gchar **lines = g_strsplit(contents, "\n", -1);
    g_free(contents);
    if (!lines || !lines[0] ||
        strcmp(lines[0], "CMP-CE-IMAGE-MANIFEST-1") != 0) {
        g_strfreev(lines);
        error = "Folder-HDD C/E sync manifest has an unsupported format.";
        return false;
    }
    for (gsize i = 1; lines[i] && lines[i][0]; ++i) {
        gchar **parts = g_strsplit(lines[i], "\t", -1);
        const gsize n = g_strv_length(parts);
        if (n < 2 || (strcmp(parts[0], "D") && strcmp(parts[0], "F"))) {
            g_strfreev(parts);
            g_strfreev(lines);
            error = "Folder-HDD C/E sync manifest contains a malformed entry.";
            return false;
        }
        gsize decoded_len = 0;
        guchar *decoded = g_base64_decode(parts[1], &decoded_len);
        std::string relative(reinterpret_cast<char *>(decoded), decoded_len);
        g_free(decoded);
        HostEntry entry;
        entry.directory = !strcmp(parts[0], "D");
        if (!entry.directory) {
            if (n != 4) {
                g_strfreev(parts);
                g_strfreev(lines);
                error = "Folder-HDD C/E sync manifest file entry is malformed.";
                return false;
            }
            gchar *end = nullptr;
            entry.size = g_ascii_strtoull(parts[2], &end, 10);
            if (!end || *end) {
                g_strfreev(parts);
                g_strfreev(lines);
                error = "Folder-HDD C/E sync manifest size is malformed.";
                return false;
            }
            end = nullptr;
            entry.mtime = g_ascii_strtoll(parts[3], &end, 10);
            if (!end || *end) {
                g_strfreev(parts);
                g_strfreev(lines);
                error = "Folder-HDD C/E sync manifest timestamp is malformed.";
                return false;
            }
        }
        if (!manifest.emplace(relative, entry).second) {
            g_strfreev(parts);
            g_strfreev(lines);
            error = "Folder-HDD C/E sync manifest contains a duplicate path.";
            return false;
        }
        g_strfreev(parts);
    }
    g_strfreev(lines);
    return true;
}

static bool FatValueIsEnd(uint32_t value, uint8_t fat_bits)
{
    return fat_bits == 16 ? value >= 0xfff8u : value >= 0xfffffff8u;
}

static bool ReadLiveFatEntry(void *opaque, const XemuFatxHdd::Partition &p,
                             uint32_t cluster, uint32_t &value,
                             std::string &error)
{
    const uint32_t entry_bytes = p.fat_bits / 8;
    uint8_t raw[4] = {};
    if ((entry_bytes != 2 && entry_bytes != 4) || cluster == 0) {
        error = "Folder-HDD image has unsupported FAT geometry.";
        return false;
    }
    const uint64_t offset = p.offset + 4096u +
                            static_cast<uint64_t>(cluster) * entry_bytes;
    if (!ReadEffective(opaque, offset, raw, entry_bytes)) {
        error = "Folder-HDD could not read the live C/E image FAT.";
        return false;
    }
    value = static_cast<uint32_t>(raw[0]) |
            (static_cast<uint32_t>(raw[1]) << 8);
    if (entry_bytes == 4) {
        value |= static_cast<uint32_t>(raw[2]) << 16;
        value |= static_cast<uint32_t>(raw[3]) << 24;
    }
    return true;
}

static bool CountLiveChain(void *opaque, const XemuFatxHdd::Partition &p,
                           uint32_t first_cluster, uint32_t &count,
                           uint32_t &high_water, std::string &error)
{
    count = 0;
    if (first_cluster == 0) {
        return true;
    }
    const uint64_t capacity_entries = p.size / p.bytes_per_cluster + 1u;
    const uint64_t fat_size =
        ((capacity_entries * (p.fat_bits / 8u)) + 4095u) & ~4095u;
    const uint64_t cluster_offset = 4096u + fat_size;
    const uint32_t max_clusters = static_cast<uint32_t>(
        (p.size - cluster_offset) / p.bytes_per_cluster + 1u);
    std::unordered_set<uint32_t> visited;
    uint32_t cluster = first_cluster;
    while (cluster > 0 && cluster <= max_clusters) {
        if (!visited.insert(cluster).second) {
            error = "Folder-HDD live C/E image contains a FAT cycle.";
            return false;
        }
        ++count;
        high_water = std::max(high_water, cluster);
        uint32_t next = 0;
        if (!ReadLiveFatEntry(opaque, p, cluster, next, error)) {
            return false;
        }
        if (FatValueIsEnd(next, p.fat_bits)) {
            return true;
        }
        if (next == 0 || next > max_clusters) {
            error = "Folder-HDD live C/E image contains an invalid FAT chain.";
            return false;
        }
        cluster = next;
        if (count > max_clusters) {
            error = "Folder-HDD live C/E image FAT chain exceeds partition bounds.";
            return false;
        }
    }
    error = "Folder-HDD live C/E image FAT chain starts outside partition bounds.";
    return false;
}

struct AllocationHintTmp {
    std::string host_path;
    uint32_t first_cluster = 0;
    uint32_t cluster_count = 0;
    bool directory = false;
};

static bool CollectEntryHints(void *opaque, const char *root,
                              const XemuFatxHdd::Partition &partition,
                              const std::vector<XemuFatxHdd::Entry> &entries,
                              const std::string &parent,
                              std::vector<AllocationHintTmp> &hints,
                              uint32_t &high_water, std::string &error)
{
    for (const XemuFatxHdd::Entry &entry : entries) {
        if (!ValidGuestName(entry.name, error)) {
            return false;
        }
        const std::string relative = JoinRelative(parent, entry.name);
        AllocationHintTmp hint;
        hint.host_path = BuildHostPath(root, relative);
        hint.first_cluster = entry.first_cluster;
        hint.directory = entry.directory;
        if (!CountLiveChain(opaque, partition, entry.first_cluster,
                            hint.cluster_count, high_water, error)) {
            return false;
        }
        hints.push_back(std::move(hint));
        if (entry.directory &&
            !CollectEntryHints(opaque, root, partition, entry.children,
                               relative, hints, high_water, error)) {
            return false;
        }
    }
    return true;
}

} // namespace

extern "C" bool cmp_folder_hdd_sync_init(void *opaque, const char *root_path,
                                          char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest manifest;
    std::string error;
    if (!ScanHostManifest(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    if (opaque) {
        SetBaseline(opaque, std::move(manifest));
    }
    return true;
}

extern "C" void cmp_folder_hdd_sync_close(void *opaque)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    g_sync_states.erase(opaque);
}

extern "C" bool cmp_folder_hdd_sync_refresh_baseline(void *opaque,
                                                       const char *root_path,
                                                       char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest manifest;
    std::string error;
    if (!ScanHostManifest(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    SetBaseline(opaque, std::move(manifest));
    return true;
}

extern "C" bool cmp_folder_hdd_sync_host_changed(void *opaque,
                                                   const char *root_path,
                                                   bool *changed,
                                                   char **error_text)
{
    if (changed) {
        *changed = false;
    }
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest baseline;
    if (!GetBaseline(opaque, baseline)) {
        return SetStatus(error_text,
                         "Folder-HDD host baseline is not initialized.", false);
    }
    HostManifest current;
    std::string error;
    if (!ScanHostManifest(root_path, current, error)) {
        return SetStatus(error_text, error, false);
    }
    if (changed) {
        *changed = !SameManifest(baseline, current);
    }
    return true;
}

extern "C" bool cmp_folder_hdd_sync_guest_to_host_ex(
    void *opaque, const char *root_path, uint64_t image_size,
    size_t *host_additions_preserved_out, char **status_text)
{
    if (host_additions_preserved_out) {
        *host_additions_preserved_out = 0;
    }
    if (status_text) {
        *status_text = nullptr;
    }
    HostManifest baseline;
    if (!GetBaseline(opaque, baseline)) {
        return SetStatus(status_text,
                         "Folder-HDD host baseline is not initialized.", false);
    }

    HostManifest current;
    std::string error;
    if (!ScanHostManifest(root_path, current, error)) {
        return SetStatus(status_text, error, false);
    }
    if (!HostWritebackAllowsAdditionsOnly(baseline, current, nullptr, error)) {
        return SetStatus(status_text, error, false);
    }

    XemuFatxHdd::Snapshot snapshot;
    if (!BuildPersistentSnapshot(opaque, image_size, snapshot, error)) {
        return SetStatus(status_text,
                         error.empty()
                             ? "Folder-HDD could not parse C/E for host write-back."
                             : error,
                         false);
    }

    size_t files_changed = 0;
    size_t paths_deleted = 0;
    size_t dirs_created = 0;
    size_t host_additions_preserved = 0;
    if (!MirrorGuestToHost(opaque, root_path, image_size, baseline, snapshot,
                           files_changed, paths_deleted, dirs_created,
                           host_additions_preserved, error)) {
        return SetStatus(status_text, error, false);
    }

    HostManifest committed;
    if (!ScanHostManifest(root_path, committed, error)) {
        return SetStatus(status_text,
                         std::string("Folder-HDD write-back completed, but the new host baseline could not be captured: ") +
                             error,
                         false);
    }
    SetBaseline(opaque, std::move(committed));
    if (host_additions_preserved_out) {
        *host_additions_preserved_out = host_additions_preserved;
    }

    char text[320];
    snprintf(text, sizeof(text),
             "Folder-HDD host write-back complete: %zu file(s) changed, %zu path(s) removed, %zu director%s created, %zu host-only addition%s preserved.",
             files_changed, paths_deleted, dirs_created,
             dirs_created == 1 ? "y" : "ies", host_additions_preserved,
             host_additions_preserved == 1 ? "" : "s");
    return SetStatus(status_text, text, true);
}

extern "C" bool cmp_folder_hdd_sync_guest_to_host(void *opaque,
                                                    const char *root_path,
                                                    uint64_t image_size,
                                                    char **status_text)
{
    return cmp_folder_hdd_sync_guest_to_host_ex(
        opaque, root_path, image_size, nullptr, status_text);
}

extern "C" bool cmp_folder_hdd_sync_collect_allocation_hints(
    void *opaque, const char *root_path, char partition_letter,
    CMPFolderHddAllocationHint **hints_out, size_t *hint_count,
    uint32_t *high_water_cluster, char **error_text)
{
    if (hints_out) {
        *hints_out = nullptr;
    }
    if (hint_count) {
        *hint_count = 0;
    }
    if (high_water_cluster) {
        *high_water_cluster = 0;
    }
    if (error_text) {
        *error_text = nullptr;
    }
    if (!opaque || !root_path || !hints_out || !hint_count ||
        !high_water_cluster) {
        return SetStatus(error_text,
                         "Folder-HDD allocation-hint request is invalid.", false);
    }

    const char letter = static_cast<char>(
        std::toupper(static_cast<unsigned char>(partition_letter)));
    if (letter != 'C' && letter != 'E') {
        return SetStatus(error_text,
                         "Folder-HDD allocation hints support only C: and E:.",
                         false);
    }

    XemuFatxHdd::Snapshot snapshot;
    if (!XemuFatxHdd::BuildPartitionSnapshot(ReadEffective, opaque,
                                              0x1DD156000ULL, letter,
                                              snapshot)) {
        return SetStatus(
            error_text,
            snapshot.status.empty()
                ? std::string("Folder-HDD could not parse live ") + letter +
                      ": image for allocation-preserving import."
                : snapshot.status,
            false);
    }
    const XemuFatxHdd::Partition *partition =
        XemuFatxHdd::FindPartition(snapshot, letter);
    if (!partition || !partition->available) {
        return SetStatus(error_text,
                         std::string("Folder-HDD live ") + letter +
                             ": image is unavailable.",
                         false);
    }

    std::vector<AllocationHintTmp> temp;
    std::string error;
    uint32_t high_water = 0;
    const std::string root_relative(1, letter);
    AllocationHintTmp root_hint;
    root_hint.host_path = BuildHostPath(root_path, root_relative);
    root_hint.first_cluster = partition->root_cluster;
    root_hint.directory = true;
    if (!CountLiveChain(opaque, *partition, partition->root_cluster,
                        root_hint.cluster_count, high_water, error)) {
        return SetStatus(error_text, error, false);
    }
    temp.push_back(std::move(root_hint));
    if (!CollectEntryHints(opaque, root_path, *partition, partition->entries,
                           root_relative, temp, high_water, error)) {
        return SetStatus(error_text, error, false);
    }

    CMPFolderHddAllocationHint *result =
        g_new0(CMPFolderHddAllocationHint, temp.size());
    for (size_t i = 0; i < temp.size(); ++i) {
        result[i].host_path = g_strdup(temp[i].host_path.c_str());
        result[i].first_cluster = temp[i].first_cluster;
        result[i].cluster_count = temp[i].cluster_count;
        result[i].directory = temp[i].directory;
    }
    *hints_out = result;
    *hint_count = temp.size();
    *high_water_cluster = high_water;
    return true;
}

extern "C" void cmp_folder_hdd_sync_free_allocation_hints(
    CMPFolderHddAllocationHint *hints, size_t hint_count)
{
    if (!hints) {
        return;
    }
    for (size_t i = 0; i < hint_count; ++i) {
        g_free(hints[i].host_path);
    }
    g_free(hints);
}

extern "C" bool cmp_folder_hdd_sync_persistent_state(
    const char *root_path, bool *has_manifest, bool *host_changed,
    bool *image_dirty, char **error_text)
{
    if (has_manifest) {
        *has_manifest = false;
    }
    if (host_changed) {
        *host_changed = false;
    }
    if (image_dirty) {
        *image_dirty = false;
    }
    if (error_text) {
        *error_text = nullptr;
    }
    if (!root_path || !has_manifest || !host_changed || !image_dirty) {
        return SetStatus(error_text,
                         "Folder-HDD persistent C/E state request is invalid.",
                         false);
    }

    HostManifest saved;
    bool present = false;
    std::string error;
    if (!LoadHostManifestFile(root_path, saved, present, error)) {
        return SetStatus(error_text, error, false);
    }
    HostManifest current;
    if (!ScanHostManifest(root_path, current, error)) {
        return SetStatus(error_text, error, false);
    }
    *has_manifest = present;
    *host_changed = !present || !SameManifest(saved, current);
    const std::string dirty = ImageMetadataPath(root_path, "ce-image-dirty.flag");
    *image_dirty = g_file_test(dirty.c_str(), G_FILE_TEST_EXISTS);
    return true;
}

extern "C" bool cmp_folder_hdd_sync_mark_image_dirty(const char *root_path,
                                                       char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    if (!root_path) {
        return SetStatus(error_text,
                         "Folder-HDD cannot mark C/E images dirty without a root.",
                         false);
    }
    const std::string dirty = ImageMetadataPath(root_path, "ce-image-dirty.flag");
    GError *gerr = nullptr;
    if (!g_file_set_contents(dirty.c_str(), "dirty\n", -1, &gerr)) {
        const std::string error =
            std::string("Folder-HDD could not persist the C/E image dirty marker: ") +
            (gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        return SetStatus(error_text, error, false);
    }
    return true;
}

extern "C" bool cmp_folder_hdd_sync_mark_converged(void *opaque,
                                                     const char *root_path,
                                                     char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest manifest;
    std::string error;
    if (!ScanHostManifest(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    if (!SaveHostManifestFile(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    const std::string dirty = ImageMetadataPath(root_path, "ce-image-dirty.flag");
    if (g_remove(dirty.c_str()) != 0 && errno != ENOENT) {
        return SetStatus(
            error_text,
            std::string("Folder-HDD synchronized C/E but could not clear the dirty marker: ") +
                g_strerror(errno),
            false);
    }
    if (opaque) {
        SetBaseline(opaque, std::move(manifest));
    }
    return true;
}
