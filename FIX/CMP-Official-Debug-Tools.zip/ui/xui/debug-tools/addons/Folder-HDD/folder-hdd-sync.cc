/* Persistent guest FATX to host-folder synchronization for Folder-HDD. */
#include <glib.h>
#include <glib/gstdio.h>

#include <cerrno>
#include <cstdint>
#include <sys/stat.h>

#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "ui/xui/debug-tools/addons/Folder-HDD/folder-hdd-sync.h"
#include "ui/xui/debug-tools/addons/hdd/fatx-hdd.hh"

namespace {

struct HostEntry {
    bool directory = false;
    uint64_t size = 0;
    int64_t mtime = 0;
};

using HostManifest = std::unordered_map<std::string, HostEntry>;

struct SyncState {
    HostManifest baseline;
};

std::mutex g_sync_states_lock;
std::unordered_map<void *, SyncState> g_sync_states;
uint64_t g_temp_serial = 0;

static bool SameHostEntry(const HostEntry &a, const HostEntry &b)
{
    return a.directory == b.directory && a.size == b.size &&
           a.mtime == b.mtime;
}

static bool SameManifest(const HostManifest &a, const HostManifest &b)
{
    if (a.size() != b.size()) {
        return false;
    }
    for (const auto &it : a) {
        const auto found = b.find(it.first);
        if (found == b.end() || !SameHostEntry(it.second, found->second)) {
            return false;
        }
    }
    return true;
}

static std::string JoinRelative(const std::string &parent,
                                const std::string &name)
{
    return parent.empty() ? name : parent + "/" + name;
}

static std::string BuildHostPath(const char *root, const std::string &relative)
{
    gchar *path = g_strdup(root ? root : "");
    size_t start = 0;
    while (start < relative.size()) {
        const size_t slash = relative.find('/', start);
        const size_t end = slash == std::string::npos ? relative.size() : slash;
        const std::string part = relative.substr(start, end - start);
        gchar *next = g_build_filename(path, part.c_str(), nullptr);
        g_free(path);
        path = next;
        if (slash == std::string::npos) {
            break;
        }
        start = slash + 1;
    }
    std::string result = path ? path : "";
    g_free(path);
    return result;
}

static bool ScanHostDirectory(const char *root, const std::string &relative,
                              HostManifest &manifest, unsigned depth,
                              std::string &error)
{
    if (depth > 64) {
        error = "Folder-HDD host directory nesting exceeds the safety limit.";
        return false;
    }

    const std::string full = BuildHostPath(root, relative);
    GStatBuf st;
    if (g_stat(full.c_str(), &st) != 0) {
        error = std::string("Folder-HDD cannot stat host path '") + full +
                "': " + g_strerror(errno);
        return false;
    }
    if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) {
        error = std::string("Folder-HDD host path is not a regular file/directory: ") +
                full;
        return false;
    }

    HostEntry item;
    item.directory = S_ISDIR(st.st_mode);
    item.size = item.directory ? 0 : static_cast<uint64_t>(st.st_size);
    item.mtime = static_cast<int64_t>(st.st_mtime);
    manifest[relative] = item;
    if (!item.directory) {
        return true;
    }

    GError *gerr = nullptr;
    GDir *dir = g_dir_open(full.c_str(), 0, &gerr);
    if (!dir) {
        error = std::string("Folder-HDD cannot open host directory '") + full +
                "': " + (gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        return false;
    }

    std::vector<std::string> names;
    const char *name = nullptr;
    while ((name = g_dir_read_name(dir)) != nullptr) {
        if (!strcmp(name, ".") || !strcmp(name, "..")) {
            continue;
        }
        names.emplace_back(name);
    }
    g_dir_close(dir);
    std::sort(names.begin(), names.end(), [](const std::string &a,
                                             const std::string &b) {
        return g_ascii_strcasecmp(a.c_str(), b.c_str()) < 0;
    });

    for (const std::string &child : names) {
        if (!ScanHostDirectory(root, JoinRelative(relative, child), manifest,
                               depth + 1, error)) {
            return false;
        }
    }
    return true;
}

static bool ScanHostManifest(const char *root, HostManifest &manifest,
                             std::string &error)
{
    static const char *const partitions[] = { "C", "E" };
    manifest.clear();
    error.clear();
    for (const char *letter : partitions) {
        const std::string full = BuildHostPath(root, letter);
        GStatBuf st;
        if (g_stat(full.c_str(), &st) != 0) {
            if (errno == ENOENT) {
                continue;
            }
            error = std::string("Folder-HDD cannot stat host partition '") +
                    full + "': " + g_strerror(errno);
            return false;
        }
        if (!S_ISDIR(st.st_mode)) {
            error = std::string("Folder-HDD partition path is not a directory: ") +
                    full;
            return false;
        }
        if (!ScanHostDirectory(root, letter, manifest, 0, error)) {
            return false;
        }
    }
    return true;
}

static bool SetStatus(char **status_text, const std::string &text, bool result)
{
    if (status_text) {
        g_free(*status_text);
        *status_text = g_strdup(text.c_str());
    }
    return result;
}

static bool ValidGuestName(const std::string &name, std::string &error)
{
    if (name.empty() || name == "." || name == ".." || name.size() > 42) {
        error = "FATX guest created an invalid host filename.";
        return false;
    }
    if (!g_utf8_validate(name.c_str(), static_cast<gssize>(name.size()), nullptr)) {
        error = "FATX filename is not valid UTF-8 and cannot be written safely to the host.";
        return false;
    }
    for (unsigned char c : name) {
        if (c < 0x20 || c == '/' || c == '\\' || c == ':' || c == '*' ||
            c == '?' || c == '"' || c == '<' || c == '>' || c == '|') {
            error = std::string("FATX filename cannot be represented safely on the host: ") +
                    name;
            return false;
        }
    }
    if (name.back() == ' ' || name.back() == '.') {
        error = std::string("FATX filename ends in a Windows-unsafe character: ") + name;
        return false;
    }

    std::string base = name;
    const size_t dot = base.find('.');
    if (dot != std::string::npos) {
        base.resize(dot);
    }
    std::transform(base.begin(), base.end(), base.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    const bool reserved = base == "CON" || base == "PRN" || base == "AUX" ||
                          base == "NUL" ||
                          (base.size() == 4 &&
                           ((base.compare(0, 3, "COM") == 0) ||
                            (base.compare(0, 3, "LPT") == 0)) &&
                           base[3] >= '1' && base[3] <= '9');
    if (reserved) {
        error = std::string("FATX filename is a reserved Windows device name: ") + name;
        return false;
    }
    return true;
}

struct GuestNode {
    const XemuFatxHdd::Partition *partition = nullptr;
    const XemuFatxHdd::Entry *entry = nullptr;
    bool directory = false;
};

using GuestManifest = std::unordered_map<std::string, GuestNode>;

static bool AddGuestEntries(const XemuFatxHdd::Partition &partition,
                            const std::vector<XemuFatxHdd::Entry> &entries,
                            const std::string &parent,
                            GuestManifest &manifest, std::string &error)
{
    for (const XemuFatxHdd::Entry &entry : entries) {
        if (!ValidGuestName(entry.name, error)) {
            return false;
        }
        const std::string relative = JoinRelative(parent, entry.name);
        if (!manifest.emplace(relative,
                              GuestNode{&partition, &entry, entry.directory}).second) {
            error = std::string("Duplicate FATX path encountered during host write-back: ") +
                    relative;
            return false;
        }
        if (entry.directory &&
            !AddGuestEntries(partition, entry.children, relative, manifest,
                             error)) {
            return false;
        }
    }
    return true;
}

static bool BuildGuestManifest(XemuFatxHdd::Snapshot &snapshot,
                               GuestManifest &manifest, std::string &error)
{
    manifest.clear();
    for (XemuFatxHdd::Partition &partition : snapshot.partitions) {
        if (!partition.available ||
            (partition.letter != 'C' && partition.letter != 'E')) {
            continue;
        }
        const std::string root(1, partition.letter);
        manifest.emplace(root, GuestNode{&partition, nullptr, true});
        if (!AddGuestEntries(partition, partition.entries, root, manifest,
                             error)) {
            return false;
        }
    }
    return true;
}

static size_t PathDepth(const std::string &path)
{
    return static_cast<size_t>(std::count(path.begin(), path.end(), '/'));
}

static bool FlushHostFile(FILE *fp, std::string &error)
{
    if (fflush(fp) != 0) {
        error = std::string("Host write flush failed: ") + g_strerror(errno);
        return false;
    }
#ifdef _WIN32
    if (_commit(_fileno(fp)) != 0) {
#else
    if (fsync(fileno(fp)) != 0) {
#endif
        error = std::string("Host write durable flush failed: ") + g_strerror(errno);
        return false;
    }
    return true;
}

static bool CreateTransactionDirectory(const char *root,
                                       std::string &temp_root,
                                       std::string &temp_dir,
                                       std::string &error)
{
    temp_root = BuildHostPath(root, ".cmp-folder-hdd-tmp");
    if (g_mkdir_with_parents(temp_root.c_str(), 0700) != 0) {
        error = std::string("Could not create Folder-HDD write-back staging directory: ") +
                g_strerror(errno);
        return false;
    }

    gchar *pattern = g_build_filename(temp_root.c_str(), "txn-XXXXXX", nullptr);
    if (!g_mkdtemp(pattern)) {
        error = std::string("Could not create Folder-HDD write-back transaction directory: ") +
                g_strerror(errno);
        g_free(pattern);
        return false;
    }
    temp_dir = pattern;
    g_free(pattern);
    return true;
}

struct StagedFile {
    std::string target;
    std::string temp;
};

struct BackupFile {
    std::string target;
    std::string backup;
};

struct RemovedDirectory {
    std::string path;
};

struct CreatedDirectory {
    std::string path;
};

struct InstalledFile {
    std::string path;
};

static bool MoveHostFileToBackup(const std::string &target,
                                 const std::string &temp_dir,
                                 std::vector<BackupFile> &backups,
                                 std::string &error)
{
    const uint64_t serial = ++g_temp_serial;
    gchar *backup_raw = g_strdup_printf("backup-%" G_GUINT64_FORMAT ".tmp",
                                        static_cast<guint64>(serial));
    gchar *backup_path_raw =
        g_build_filename(temp_dir.c_str(), backup_raw, nullptr);
    std::string backup = backup_path_raw;
    g_free(backup_path_raw);
    g_free(backup_raw);

    if (g_rename(target.c_str(), backup.c_str()) != 0) {
        error = std::string("Could not stage existing host file '") + target +
                "' for rollback: " + g_strerror(errno);
        return false;
    }
    backups.push_back({target, std::move(backup)});
    return true;
}

static bool InstallStagedFile(StagedFile &file, const std::string &temp_dir,
                              std::vector<BackupFile> &backups,
                              std::vector<InstalledFile> &installed,
                              std::string &error)
{
    GStatBuf st;
    if (g_stat(file.target.c_str(), &st) == 0) {
        if (!S_ISREG(st.st_mode)) {
            error = std::string("Host destination unexpectedly became a non-file during write-back: ") +
                    file.target;
            return false;
        }
        if (!MoveHostFileToBackup(file.target, temp_dir, backups, error)) {
            return false;
        }
    } else if (errno != ENOENT) {
        error = std::string("Could not stat host destination '") + file.target +
                "': " + g_strerror(errno);
        return false;
    }

    if (g_rename(file.temp.c_str(), file.target.c_str()) != 0) {
        const int saved = errno;
        /* Restore this target; rollback handles earlier operations. */
        if (!backups.empty() && backups.back().target == file.target &&
            g_rename(backups.back().backup.c_str(), file.target.c_str()) == 0) {
            backups.pop_back();
        }
        error = std::string("Could not install host file '") + file.target +
                "': " + g_strerror(saved);
        return false;
    }
    file.temp.clear();
    installed.push_back({file.target});
    return true;
}

static bool RollbackHostChanges(std::vector<InstalledFile> &installed,
                                std::vector<CreatedDirectory> &created_dirs,
                                std::vector<RemovedDirectory> &removed_dirs,
                                std::vector<BackupFile> &backups,
                                std::string &rollback_error)
{
    bool ok = true;
    std::string first_error;

    for (auto it = installed.rbegin(); it != installed.rend(); ++it) {
        if (g_remove(it->path.c_str()) != 0 && errno != ENOENT) {
            if (first_error.empty()) {
                first_error = std::string("could not remove installed file '") +
                              it->path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(created_dirs.begin(), created_dirs.end(),
              [](const CreatedDirectory &a, const CreatedDirectory &b) {
        if (PathDepth(a.path) != PathDepth(b.path)) {
            return PathDepth(a.path) > PathDepth(b.path);
        }
        return a.path.size() > b.path.size();
    });
    for (const CreatedDirectory &dir : created_dirs) {
        if (g_rmdir(dir.path.c_str()) != 0 && errno != ENOENT) {
            if (first_error.empty()) {
                first_error = std::string("could not remove created directory '") +
                              dir.path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(removed_dirs.begin(), removed_dirs.end(),
              [](const RemovedDirectory &a, const RemovedDirectory &b) {
        if (PathDepth(a.path) != PathDepth(b.path)) {
            return PathDepth(a.path) < PathDepth(b.path);
        }
        return a.path.size() < b.path.size();
    });
    for (const RemovedDirectory &dir : removed_dirs) {
        GStatBuf st;
        if (g_stat(dir.path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            continue;
        }
        if (g_mkdir(dir.path.c_str(), 0755) != 0 && errno != EEXIST) {
            if (first_error.empty()) {
                first_error = std::string("could not restore directory '") +
                              dir.path + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    std::sort(backups.begin(), backups.end(),
              [](const BackupFile &a, const BackupFile &b) {
        if (PathDepth(a.target) != PathDepth(b.target)) {
            return PathDepth(a.target) < PathDepth(b.target);
        }
        return a.target.size() < b.target.size();
    });
    for (const BackupFile &backup : backups) {
        if (g_rename(backup.backup.c_str(), backup.target.c_str()) != 0) {
            if (first_error.empty()) {
                first_error = std::string("could not restore host file '") +
                              backup.target + "': " + g_strerror(errno);
            }
            ok = false;
        }
    }

    rollback_error = first_error;
    return ok;
}

static void FinalizeBackups(const std::vector<BackupFile> &backups)
{
    for (const BackupFile &backup : backups) {
        (void)g_remove(backup.backup.c_str());
    }
}

static bool StageGuestFile(void *opaque, uint64_t image_size,
                           const GuestNode &node, const std::string &target,
                           const std::string &temp_dir,
                           std::string &staged_temp, std::string &error)
{
    staged_temp.clear();
    if (!node.partition || !node.entry || node.directory) {
        error = "Invalid FATX file write-back node.";
        return false;
    }

    GStatBuf host_st;
    const bool host_exists = g_stat(target.c_str(), &host_st) == 0;
    const bool can_compare = host_exists && S_ISREG(host_st.st_mode) &&
                             static_cast<uint64_t>(host_st.st_size) ==
                                 node.entry->file_size;
    FILE *existing = can_compare ? g_fopen(target.c_str(), "rb") : nullptr;

    const uint64_t serial = ++g_temp_serial;
    gchar *temp_name_raw = g_strdup_printf("write-%" G_GUINT64_FORMAT ".tmp",
                                           static_cast<guint64>(serial));
    gchar *temp_path_raw = g_build_filename(temp_dir.c_str(), temp_name_raw, nullptr);
    std::string temp = temp_path_raw;
    g_free(temp_path_raw);
    g_free(temp_name_raw);

    FILE *out = g_fopen(temp.c_str(), "wb");
    if (!out) {
        if (existing) {
            fclose(existing);
        }
        error = std::string("Could not create Folder-HDD temporary host file: ") +
                g_strerror(errno);
        return false;
    }

    bool same = existing != nullptr;
    XemuFatxHdd::FileReadCursor cursor;
    uint64_t offset = 0;
    std::vector<uint8_t> guest;
    std::vector<uint8_t> host;
    while (offset < node.entry->file_size) {
        const size_t wanted = static_cast<size_t>(std::min<uint64_t>(
            1024u * 1024u, static_cast<uint64_t>(node.entry->file_size) - offset));
        std::string read_error;
        if (!XemuFatxHdd::ReadFileRangeSequential(
                cmp_folder_hdd_sync_effective_read, opaque, image_size,
                *node.partition, *node.entry, offset, wanted, cursor, guest,
                read_error)) {
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            error = std::string("Could not read guest FATX file '") + target +
                    "': " + read_error;
            return false;
        }
        if (!guest.empty() && fwrite(guest.data(), 1, guest.size(), out) != guest.size()) {
            const int saved = errno;
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            error = std::string("Could not stage host file '") + target +
                    "': " + g_strerror(saved ? saved : EIO);
            return false;
        }
        if (same) {
            host.resize(guest.size());
            const size_t got = guest.empty() ? 0 :
                fread(host.data(), 1, host.size(), existing);
            if (got != guest.size() ||
                (!guest.empty() && memcmp(host.data(), guest.data(), guest.size()) != 0)) {
                same = false;
            }
        }
        offset += guest.size();
        if (guest.empty() && offset < node.entry->file_size) {
            fclose(out);
            if (existing) {
                fclose(existing);
            }
            (void)g_remove(temp.c_str());
            error = "Guest FATX file read made no progress.";
            return false;
        }
    }

    if (!FlushHostFile(out, error)) {
        fclose(out);
        if (existing) {
            fclose(existing);
        }
        (void)g_remove(temp.c_str());
        return false;
    }
    if (fclose(out) != 0) {
        if (existing) {
            fclose(existing);
        }
        (void)g_remove(temp.c_str());
        error = std::string("Could not close Folder-HDD temporary file: ") +
                g_strerror(errno);
        return false;
    }
    if (existing) {
        if (same && fgetc(existing) != EOF) {
            same = false;
        }
        fclose(existing);
    }

    if (same) {
        (void)g_remove(temp.c_str());
        return true;
    }
    staged_temp = std::move(temp);
    return true;
}

static void CleanupStagedFiles(const std::vector<StagedFile> &staged)
{
    for (const StagedFile &file : staged) {
        if (!file.temp.empty()) {
            (void)g_remove(file.temp.c_str());
        }
    }
}

static bool MirrorGuestToHost(void *opaque, const char *root,
                              uint64_t image_size,
                              const HostManifest &baseline,
                              XemuFatxHdd::Snapshot &snapshot,
                              size_t &files_changed, size_t &paths_deleted,
                              size_t &dirs_created, std::string &error)
{
    GuestManifest guest;
    if (!BuildGuestManifest(snapshot, guest, error)) {
        return false;
    }

    /* Never interpret an unreadable guest partition as a host delete. */
    for (const char letter : std::string("CE")) {
        const std::string root_path(1, letter);
        if (baseline.find(root_path) != baseline.end() &&
            guest.find(root_path) == guest.end()) {
            error = std::string("Folder-HDD refused host write-back because FATX ") +
                    letter + ": is not readable at the commit boundary.";
            return false;
        }
    }

    std::string temp_root;
    std::string temp_dir;
    if (!CreateTransactionDirectory(root, temp_root, temp_dir, error)) {
        return false;
    }

    /* Stage all guest file data before changing the host namespace. */
    std::vector<std::pair<std::string, GuestNode>> files;
    for (const auto &item : guest) {
        if (!item.second.directory) {
            files.emplace_back(item.first, item.second);
        }
    }
    std::sort(files.begin(), files.end(), [](const auto &a, const auto &b) {
        return a.first < b.first;
    });

    std::vector<StagedFile> staged;
    for (const auto &item : files) {
        const std::string full = BuildHostPath(root, item.first);
        std::string temp;
        if (!StageGuestFile(opaque, image_size, item.second, full, temp_dir,
                            temp, error)) {
            CleanupStagedFiles(staged);
            (void)g_rmdir(temp_dir.c_str());
            (void)g_rmdir(temp_root.c_str());
            return false;
        }
        if (!temp.empty()) {
            staged.push_back({full, std::move(temp)});
        }
    }

    /* Re-check the host baseline after staging, before namespace changes. */
    HostManifest before_apply;
    std::string scan_error;
    if (!ScanHostManifest(root, before_apply, scan_error)) {
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        error = scan_error;
        return false;
    }
    if (!SameManifest(baseline, before_apply)) {
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        error =
            "Folder-HDD host tree changed while guest files were being staged; no namespace changes were applied.";
        return false;
    }

    std::vector<BackupFile> backups;
    std::vector<RemovedDirectory> removed_dirs;
    std::vector<CreatedDirectory> created_dirs;
    std::vector<InstalledFile> installed;
    auto fail_with_rollback = [&](const std::string &primary_error) {
        std::string rollback_error;
        const bool rolled_back = RollbackHostChanges(
            installed, created_dirs, removed_dirs, backups, rollback_error);
        CleanupStagedFiles(staged);
        (void)g_rmdir(temp_dir.c_str());
        (void)g_rmdir(temp_root.c_str());
        if (rolled_back) {
            error = primary_error + " Host changes from this commit were rolled back.";
        } else {
            error = primary_error +
                    " Automatic rollback was incomplete: " +
                    (rollback_error.empty() ? std::string("unknown rollback error")
                                            : rollback_error) +
                    ". Stop xemu and inspect .cmp-folder-hdd-tmp before continuing.";
        }
        return false;
    };

    std::vector<std::string> deletions;
    deletions.reserve(baseline.size());
    for (const auto &item : baseline) {
        const auto found = guest.find(item.first);
        const bool partition_root = item.first.size() == 1;
        if (partition_root) {
            continue;
        }
        if (found == guest.end() ||
            found->second.directory != item.second.directory) {
            deletions.push_back(item.first);
        }
    }
    std::sort(deletions.begin(), deletions.end(), [](const std::string &a,
                                                      const std::string &b) {
        if (PathDepth(a) != PathDepth(b)) {
            return PathDepth(a) > PathDepth(b);
        }
        return a.size() > b.size();
    });
    for (const std::string &relative : deletions) {
        const std::string full = BuildHostPath(root, relative);
        const auto base = baseline.find(relative);
        if (base == baseline.end()) {
            continue;
        }
        if (base->second.directory) {
            if (g_rmdir(full.c_str()) != 0) {
                const std::string why =
                    std::string("Could not remove host directory '") + full +
                    "' during FATX write-back: " + g_strerror(errno);
                return fail_with_rollback(why);
            }
            removed_dirs.push_back({full});
        } else {
            if (!MoveHostFileToBackup(full, temp_dir, backups, error)) {
                return fail_with_rollback(error);
            }
        }
        ++paths_deleted;
    }

    std::vector<std::string> directories;
    for (const auto &item : guest) {
        if (item.second.directory) {
            directories.push_back(item.first);
        }
    }
    std::sort(directories.begin(), directories.end(), [](const std::string &a,
                                                          const std::string &b) {
        if (PathDepth(a) != PathDepth(b)) {
            return PathDepth(a) < PathDepth(b);
        }
        return a.size() < b.size();
    });
    for (const std::string &relative : directories) {
        const std::string full = BuildHostPath(root, relative);
        GStatBuf st;
        if (g_stat(full.c_str(), &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                continue;
            }
            return fail_with_rollback(
                std::string("Host path unexpectedly remained a file while creating directory '") +
                full + "'.");
        }
        if (errno != ENOENT) {
            return fail_with_rollback(
                std::string("Could not stat host directory '") + full +
                "': " + g_strerror(errno));
        }
        if (g_mkdir(full.c_str(), 0755) != 0) {
            return fail_with_rollback(
                std::string("Could not create host directory '") + full +
                "': " + g_strerror(errno));
        }
        created_dirs.push_back({full});
        ++dirs_created;
    }

    for (StagedFile &file : staged) {
        gchar *parent_raw = g_path_get_dirname(file.target.c_str());
        const std::string parent = parent_raw ? parent_raw : "";
        g_free(parent_raw);
        GStatBuf parent_st;
        if (g_stat(parent.c_str(), &parent_st) != 0 ||
            !S_ISDIR(parent_st.st_mode)) {
            return fail_with_rollback(
                std::string("Host parent directory is unavailable while installing '") +
                file.target + "'.");
        }
        if (!InstallStagedFile(file, temp_dir, backups, installed, error)) {
            return fail_with_rollback(error);
        }
        ++files_changed;
    }

    /* Keep backups until the full commit succeeds. */
    FinalizeBackups(backups);
    CleanupStagedFiles(staged);
    (void)g_rmdir(temp_dir.c_str());
    (void)g_rmdir(temp_root.c_str());
    return true;
}

static bool ReadEffective(void *opaque, uint64_t offset, void *buffer,
                          size_t size)
{
    return cmp_folder_hdd_sync_effective_read(opaque, offset, buffer, size);
}

static bool BuildPersistentSnapshot(void *opaque, uint64_t image_size,
                                    XemuFatxHdd::Snapshot &snapshot,
                                    std::string &error)
{
    snapshot = {};
    snapshot.hdd_available = true;
    snapshot.image_size = image_size;
    for (const char letter : std::string("CE")) {
        XemuFatxHdd::Snapshot one;
        if (!XemuFatxHdd::BuildPartitionSnapshot(
                ReadEffective, opaque, image_size, letter, one)) {
            error = one.status.empty()
                ? std::string("Folder-HDD could not parse FATX ") + letter +
                      ": for host write-back."
                : one.status;
            snapshot = {};
            return false;
        }
        for (XemuFatxHdd::Partition &partition : one.partitions) {
            snapshot.partitions.push_back(std::move(partition));
        }
    }
    snapshot.status = "Persistent C/E FATX snapshot captured.";
    return true;
}

static bool GetBaseline(void *opaque, HostManifest &baseline)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    const auto it = g_sync_states.find(opaque);
    if (it == g_sync_states.end()) {
        return false;
    }
    baseline = it->second.baseline;
    return true;
}

static void SetBaseline(void *opaque, HostManifest manifest)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    g_sync_states[opaque].baseline = std::move(manifest);
}

} // namespace

extern "C" bool cmp_folder_hdd_sync_init(void *opaque, const char *root_path,
                                          char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest manifest;
    std::string error;
    if (!ScanHostManifest(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    SetBaseline(opaque, std::move(manifest));
    return true;
}

extern "C" void cmp_folder_hdd_sync_close(void *opaque)
{
    std::lock_guard<std::mutex> guard(g_sync_states_lock);
    g_sync_states.erase(opaque);
}

extern "C" bool cmp_folder_hdd_sync_refresh_baseline(void *opaque,
                                                       const char *root_path,
                                                       char **error_text)
{
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest manifest;
    std::string error;
    if (!ScanHostManifest(root_path, manifest, error)) {
        return SetStatus(error_text, error, false);
    }
    SetBaseline(opaque, std::move(manifest));
    return true;
}

extern "C" bool cmp_folder_hdd_sync_host_changed(void *opaque,
                                                   const char *root_path,
                                                   bool *changed,
                                                   char **error_text)
{
    if (changed) {
        *changed = false;
    }
    if (error_text) {
        *error_text = nullptr;
    }
    HostManifest baseline;
    if (!GetBaseline(opaque, baseline)) {
        return SetStatus(error_text,
                         "Folder-HDD host baseline is not initialized.", false);
    }
    HostManifest current;
    std::string error;
    if (!ScanHostManifest(root_path, current, error)) {
        return SetStatus(error_text, error, false);
    }
    if (changed) {
        *changed = !SameManifest(baseline, current);
    }
    return true;
}

extern "C" bool cmp_folder_hdd_sync_guest_to_host(void *opaque,
                                                    const char *root_path,
                                                    uint64_t image_size,
                                                    char **status_text)
{
    if (status_text) {
        *status_text = nullptr;
    }
    HostManifest baseline;
    if (!GetBaseline(opaque, baseline)) {
        return SetStatus(status_text,
                         "Folder-HDD host baseline is not initialized.", false);
    }

    HostManifest current;
    std::string error;
    if (!ScanHostManifest(root_path, current, error)) {
        return SetStatus(status_text, error, false);
    }
    if (!SameManifest(baseline, current)) {
        return SetStatus(
            status_text,
            "Folder-HDD host write-back was deferred because C/E changed on the host while Xbox writes were pending. No host files were overwritten; let the host tree settle and retry/restart xemu to reconcile safely.",
            false);
    }

    XemuFatxHdd::Snapshot snapshot;
    if (!BuildPersistentSnapshot(opaque, image_size, snapshot, error)) {
        return SetStatus(status_text,
                         error.empty()
                             ? "Folder-HDD could not parse C/E for host write-back."
                             : error,
                         false);
    }

    size_t files_changed = 0;
    size_t paths_deleted = 0;
    size_t dirs_created = 0;
    if (!MirrorGuestToHost(opaque, root_path, image_size, baseline, snapshot,
                           files_changed, paths_deleted, dirs_created, error)) {
        return SetStatus(status_text, error, false);
    }

    HostManifest committed;
    if (!ScanHostManifest(root_path, committed, error)) {
        return SetStatus(status_text,
                         std::string("Folder-HDD write-back completed, but the new host baseline could not be captured: ") +
                             error,
                         false);
    }
    SetBaseline(opaque, std::move(committed));

    char text[256];
    snprintf(text, sizeof(text),
             "Folder-HDD host write-back complete: %zu file(s) changed, %zu path(s) removed, %zu director%s created.",
             files_changed, paths_deleted, dirs_created,
             dirs_created == 1 ? "y" : "ies");
    return SetStatus(status_text, text, true);
}
