#include "folder-hdd-ui.hh"
#include "folder-hdd.h"

#include "../../../common.hh"
#include "../../../widgets.hh"
#include "../../../../xemu-notifications.h"
#include "../../../../xemu-settings.h"

#include <glib.h>

extern struct config g_config;

extern "C" void cmp_folder_hdd_make_folders_action(void *opaque)
{
    const char *root = static_cast<const char *>(opaque);
    char *error_text = nullptr;
    if (cmp_folder_hdd_ensure_layout(root, &error_text)) {
        char *msg = g_strdup_printf(
            "XEMU-HDD image-backed C/E layout created at '%s'. Restart xemu to use Folder Backed FATX (CMP).",
            root);
        xemu_queue_notification(msg);
        g_free(msg);
    } else {
        xemu_queue_error_message(error_text ? error_text :
            "Could not create the XEMU-HDD layout.");
    }
    g_free(error_text);
}

void cmp_folder_hdd_draw_settings(bool *dirty)
{
    static const SDL_DialogFileFilter qcow_file_filters[] = {
        { ".qcow2 Files", "qcow2" },
        { "All Files", "*" }
    };

    if (ChevronCombo(
            "Hard Disk Source", &g_config.sys.files.hdd_type,
            "Disk Image (Default)\0Folder Backed FATX (CMP)\0",
            "Select the Xbox hard disk source")) {
        if ((int)g_config.sys.files.hdd_type == CONFIG_SYS_FILES_HDD_TYPE_FOLDER &&
            !cmp_folder_hdd_is_configured()) {
            g_config.sys.files.hdd_type = CONFIG_SYS_FILES_HDD_TYPE_IMAGE;
            xemu_queue_error_message(
                "Folder-HDD support is not included in this build profile.");
        } else if ((int)g_config.sys.files.hdd_type == CONFIG_SYS_FILES_HDD_TYPE_FOLDER &&
                   (!g_config.sys.files.hdd_folder_path ||
                    !g_config.sys.files.hdd_folder_path[0])) {
            char *default_root = cmp_folder_hdd_get_default_root();
            char *layout_error = nullptr;
            if (!default_root ||
                !cmp_folder_hdd_ensure_layout(default_root, &layout_error)) {
                g_config.sys.files.hdd_type = CONFIG_SYS_FILES_HDD_TYPE_IMAGE;
                xemu_queue_error_message(
                    layout_error ? layout_error :
                    "Could not create the default XEMU-HDD folder layout beside the xemu executable.");
            } else {
                xemu_settings_set_string(&g_config.sys.files.hdd_folder_path,
                                         default_root);
                char *msg = g_strdup_printf("XEMU-HDD C/E images + mirror folders created: %s", default_root);
                xemu_queue_notification(msg);
                g_free(msg);
            }
            g_free(layout_error);
            g_free(default_root);
        }
        if (dirty) { *dirty = true; }
    }

    if ((int)g_config.sys.files.hdd_type == CONFIG_SYS_FILES_HDD_TYPE_FOLDER) {
        FilePicker("Folder HDD Root", g_config.sys.files.hdd_folder_path,
                   nullptr, 0, true, [dirty](const char *path) {
                       xemu_settings_set_string(
                           &g_config.sys.files.hdd_folder_path, path);
                       if (dirty) { *dirty = true; }
                   });
    } else {
        FilePicker("Hard Disk", g_config.sys.files.hdd_path,
                   qcow_file_filters, 2, false, [dirty](const char *path) {
                       xemu_settings_set_string(&g_config.sys.files.hdd_path, path);
                       if (dirty) { *dirty = true; }
                   });
    }
}
