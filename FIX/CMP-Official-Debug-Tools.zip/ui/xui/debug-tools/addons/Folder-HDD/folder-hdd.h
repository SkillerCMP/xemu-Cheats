#pragma once

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Folder-HDD bridge used by xemu integration and optional HDD tools. */
bool cmp_folder_hdd_is_configured(void);
bool cmp_folder_hdd_is_active(void);
char *cmp_folder_hdd_make_uri(const char *root_path);
/* Return the default Folder-HDD root. Caller owns the returned string. */
char *cmp_folder_hdd_get_default_root(void);
/* Create/validate the C/E mirror folders, Images/C.img + E.img, and the
 * existing X/Y/Z cache image for Folder-HDD. */
bool cmp_folder_hdd_ensure_layout(const char *root_path, char **error_text);
bool cmp_folder_hdd_root_is_usable(const char *root_path, char **error_text);
/* UI callback used by the small upstream startup/error hook. */
void cmp_folder_hdd_make_folders_action(void *opaque);

/* Return the latest active C/E image/mirror or cache-flush error. Caller owns it. */
char *cmp_folder_hdd_get_last_sync_error(void);
/* Force C/E image/mirror convergence. Pending guest image writes export first. */
bool cmp_folder_hdd_rescan_active(char **status_text);

#ifdef __cplusplus
}
#endif
