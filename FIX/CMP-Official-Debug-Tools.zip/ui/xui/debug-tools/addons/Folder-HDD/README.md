# CMP Folder-HDD

**Folder Backed FATX (CMP)** now uses stable FATX images for Xbox C: and E:
while keeping the normal host `C/` and `E/` directories as user-accessible
mirrors. X/Y/Z continue to use the existing shared cache image.

The Xbox still sees one normal C/E/X/Y/Z hard disk, but guest sector I/O no
longer reads loose C/E files directly while the emulator is running.

```text
XEMU-HDD/
  Images/
    C.img
    E.img
    ce-sync-baseline.tsv
    ce-image-dirty.flag        # present only while C/E images need mirroring
  C/                           # PC/user mirror
  E/                           # PC/user mirror
  Cache/
    xbox_cache.img             # X/Y/Z Hybrid cache
```

`C.img` and `E.img` use the normal Xbox FATX partition sizes. They are marked
sparse where the host filesystem supports sparse files, so their logical size
can be much larger than the physical space currently occupied.

## C/E synchronization

- **Xbox reads/writes:** C/E guest sectors come only from `Images/C.img` and
  `Images/E.img`. The loose C/E folders are not live block backing.
- **Xbox -> PC:** after C/E image writes settle for about one second, on FLUSH,
  and on close, Folder-HDD parses the images and transactionally mirrors the
  changed FATX files into the loose C/E folders.
- **PC -> Xbox:** when the image side is clean, Folder-HDD checks the loose C/E
  mirror during HDD activity. Host changes are rebuilt into the image while
  preserving existing FATX cluster assignments where possible.
- **Manual REFRESH:** pending Xbox image changes are mirrored out first. If the
  host mirror then differs, it is imported into C.img/E.img before the HDD
  Directory display snapshot is refreshed.
- **Cross-session recovery:** `ce-sync-baseline.tsv` records the last known
  converged host tree. A dirty marker is written before the first Xbox C/E image
  write and removed only after image and host mirror converge. On startup,
  Folder-HDD finishes a one-sided interrupted export/import when it can prove
  which side changed; if both sides changed after an interrupted write, it
  stops rather than overwriting either copy.

The image files are authoritative for the running Xbox. This avoids the old
problem where an Xbox overlay could depend on an obsolete loose host file while
write-back was reconstructing FATX data.

## Conflict rules

Folder-HDD remains conservative around simultaneous changes:

- New unrelated host files/folders can coexist with pending Xbox writes.
- A host-only addition is preserved and imported back into the images after the
  Xbox-side mirror commit.
- Different host/Xbox additions at the same path are a conflict.
- Modification or removal of an existing baseline path while Xbox C/E changes
  are pending is still treated as a conflict; neither side is silently
  overwritten.

A full path-level three-way merge for simultaneous edits of an existing file is
not implemented by this prototype.

## X/Y/Z Hybrid cache

X/Y/Z remain unchanged. Their sector I/O goes directly to
`Cache/xbox_cache.img`; cache-only activity does not trigger C/E mirror export.
Legacy loose host `X/`, `Y/`, and `Z/` directories are ignored.

## Safety and prototype boundary

Live PC -> image imports preserve existing cluster assignments where possible,
but they still rebuild FATX metadata in the image while the block device is
mounted. This is a prototype of the image-backed architecture, not yet the
stronger future design where every live PC-side mutation is replayed through
the Xbox kernel filesystem RPC layer. Runtime testing should therefore focus on
save/load correctness as well as whether new/changed PC files become visible.

FATX names longer than 42 bytes or host-unsafe names remain rejected. Image
replacement uses staged files and rollback backups so a failed import does not
silently discard the previous image.

## Build profiles

`folder-hdd` remains the dedicated **XEMU + Folder-HDD / Video Recorder**
profile. The image-backed C/E runtime does not require Current Game, HDD
Directory, Memory Tools, or Diagnostics, so profile 5 remains supported.

`full` builds **XEMU + all addons and Debug Tools**.
