# CMP Folder-HDD

**Folder Backed FATX (CMP)** keeps Xbox C/E as host folders and stores the
X/Y/Z cache partitions in one automatically created FATX cache image. The Xbox
still sees the normal C/E/X/Y/Z volumes through one HDD block device.

On first selection, xemu creates this layout beside the executable. Linux
AppImage builds create it beside the `.AppImage` itself. A custom root remains
supported.

```text
XEMU-HDD/
  C/
  E/
  Cache/
    xbox_cache.img
```

## Behavior

- C/E host changes are detected automatically during HDD activity.
- C/E guest writes use the sparse transaction overlay and persist to the host
  folders after about one second of write inactivity, immediately on FLUSH,
  and again on close.
- X/Y/Z sector I/O goes directly to `Cache/xbox_cache.img` and does not trigger
  C/E host-folder write-back.
- The cache image is created and FATX-formatted automatically when missing; it is sparse where the host filesystem supports sparse files.
- Concurrent C/E host edits are refused rather than overwritten.
- C/E file replacements are staged and rolled back if a commit fails partway
  through.
- Structural C/E FATX changes may keep the committed overlay active until
  restart so cluster mappings cannot change under the running Xbox.
- Legacy host `X/`, `Y/`, and `Z/` directories are ignored by this layout.
- FATX names longer than 42 bytes or host-unsafe C/E guest names are rejected.

The HDD Directory tool continues to see X/Y/Z through the normal Xbox HDD.
Export reads the combined FATX block view, while Import/Rename/Delete/Move use
Xbox kernel filesystem operations against partitions 3/4/5 and therefore write
to the cache image through the same HDD backend.

## Build profiles

`folder-hdd` is the dedicated **XEMU + Folder-HDD / Video Recorder** profile. It builds the Folder-HDD runtime support, shared FATX parser, and Video Recorder without Current Game/Cheat Engine, HDD Directory, Memory Tools, or Diagnostics.
`full` builds **XEMU + all addons and Debug Tools**.
