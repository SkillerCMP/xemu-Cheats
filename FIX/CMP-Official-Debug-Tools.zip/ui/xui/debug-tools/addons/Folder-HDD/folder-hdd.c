/* CMP image-backed C/E mirrors plus X/Y/Z cache-image FATX block device. */
#include "qemu/osdep.h"

#include <glib/gstdio.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <io.h>
#include <winioctl.h>
#else
#include <unistd.h>
#endif

#include "block/block-io.h"
#include "block/block_int.h"
#include "block/qdict.h"
#include "qapi/error.h"
#include "qemu/cutils.h"
#include "qemu/error-report.h"
#include "qemu/module.h"
#include "qemu/option.h"
#include "qobject/qdict.h"
#include "ui/xui/debug-tools/addons/Folder-HDD/folder-hdd.h"
#include "ui/xui/debug-tools/addons/Folder-HDD/folder-hdd-sync.h"

#define CMP_FATX_SIGNATURE 0x58544146u
#define CMP_SECTOR_SIZE 512u
#define CMP_CLUSTER_SIZE (16u * 1024u)
#define CMP_SECTORS_PER_CLUSTER (CMP_CLUSTER_SIZE / CMP_SECTOR_SIZE)
#define CMP_SUPERBLOCK_SIZE 4096u
#define CMP_FAT_OFFSET 4096u
#define CMP_DIR_ENTRY_SIZE 64u
#define CMP_MAX_FILENAME 42u
#define CMP_ATTR_DIRECTORY 0x10u
#define CMP_FAT_END 0xffffffffu
#define CMP_DISK_SIZE 0x1DD156000ULL
#define CMP_CACHE_DISK_START 0x00080000ULL
#define CMP_CACHE_DISK_END   0x8CA80000ULL
#define CMP_CACHE_IMAGE_SIZE (CMP_CACHE_DISK_END - CMP_CACHE_DISK_START)
#define CMP_CACHE_DIRECTORY "Cache"
#define CMP_CACHE_FILENAME "xbox_cache.img"
#define CMP_IMAGES_DIRECTORY "Images"
#define CMP_C_IMAGE_FILENAME "C.img"
#define CMP_E_IMAGE_FILENAME "E.img"
#define CMP_OVERLAY_PAGE_SIZE 4096u
#define CMP_OVERLAY_SECTORS_PER_PAGE (CMP_OVERLAY_PAGE_SIZE / CMP_SECTOR_SIZE)
#define CMP_AUTO_RESCAN_INTERVAL_US G_GINT64_CONSTANT(1000000)
#define CMP_AUTO_WRITEBACK_IDLE_US G_GINT64_CONSTANT(1000000)

typedef struct CMPFolderEntry CMPFolderEntry;

typedef enum CMPClusterKind {
    CMP_CLUSTER_UNUSED = 0,
    CMP_CLUSTER_DIRECTORY,
    CMP_CLUSTER_FILE,
} CMPClusterKind;

typedef struct CMPClusterMap {
    CMPClusterKind kind;
    CMPFolderEntry *entry;
    uint64_t file_offset;
    uint8_t *dir_bytes;
} CMPClusterMap;

struct CMPFolderEntry {
    char *name;
    char *host_path;
    bool directory;
    uint64_t size;
    uint32_t first_cluster;
    uint32_t cluster_count;
    GPtrArray *children;
};

typedef struct CMPOverlayPage {
    uint8_t valid_mask;
    uint8_t data[CMP_OVERLAY_PAGE_SIZE];
} CMPOverlayPage;

typedef struct CMPAllocationHint {
    uint32_t first_cluster;
    uint32_t cluster_count;
    bool directory;
} CMPAllocationHint;

typedef struct CMPFolderPartition {
    char letter;
    const char *label;
    uint64_t offset;
    uint64_t size;
    uint32_t volume_id;
    uint32_t fat_bits;
    uint64_t fat_size;
    uint64_t cluster_offset;
    uint32_t max_clusters;
    GArray *fat;
    GPtrArray *cluster_map;
    uint32_t next_cluster;
    CMPFolderEntry root;
    bool present;
} CMPFolderPartition;

typedef struct BDRVCMPFolderHDDState {
    char *root_path;
    char *cache_path;
    FILE *cache_fp;
    bool cache_dirty;
    char *ce_image_paths[2];
    FILE *ce_image_fps[2];
    bool ce_image_dirty[2];
    bool ce_mirror_dirty;
    bool ce_host_import_pending;
    bool ce_sync_blocked;
    uint64_t ce_write_count;
    uint64_t cache_write_count;
    GHashTable *overlay_pages;
    GMutex overlay_lock;
    bool overlay_lock_initialized;
    GMutex io_lock;
    bool io_lock_initialized;
    uint64_t overlay_written_sectors;
    bool overlay_dirty;
    int64_t next_auto_rescan_check_us;
    uint64_t rescan_generation;
    uint64_t rescan_count;
    uint64_t auto_rescan_count;
    uint64_t writeback_count;
    uint64_t writeback_failures;
    uint64_t overlay_collapse_count;
    GMutex auto_writeback_lock;
    bool auto_writeback_lock_initialized;
    GCond auto_writeback_cond;
    bool auto_writeback_cond_initialized;
    GThread *auto_writeback_thread;
    bool auto_writeback_stop;
    int64_t auto_writeback_deadline_us;
    uint64_t auto_writeback_count;
    uint64_t auto_writeback_failures;
    char *last_sync_error;
} BDRVCMPFolderHDDState;

G_LOCK_DEFINE_STATIC(cmp_folder_hdd_active);
static BDRVCMPFolderHDDState *cmp_folder_hdd_active_state;

/* The Folder-HDD C++ synchronizer consumes this on the same thread immediately
 * after an effective FATX read fails. Keeping it thread-local avoids adding
 * cross-thread diagnostic state to the block backend. */
static GPrivate cmp_effective_read_error_key = G_PRIVATE_INIT(g_free);

/* io_lock protects this diagnostic text together with the C/E write-back state. */
static void cmp_set_last_sync_error_locked(BDRVCMPFolderHDDState *s,
                                           const char *text)
{
    g_free(s->last_sync_error);
    s->last_sync_error = text && text[0] ? g_strdup(text) : NULL;
}

static const struct {
    char letter;
    const char *label;
    uint64_t offset;
    uint64_t size;
} cmp_partition_layout[] = {
    { 'C', "System", 0x8CA80000ULL, 0x01F400000ULL },
    { 'E', "Data",   0xABE80000ULL, 0x1312D6000ULL },
    { 'X', "Cache",  0x00080000ULL, 0x02EE00000ULL },
    { 'Y', "Cache",  0x2EE80000ULL, 0x02EE00000ULL },
    { 'Z', "Cache",  0x5DC80000ULL, 0x02EE00000ULL },
};

static inline void cmp_put_le16(uint8_t *p, uint16_t v)
{
    p[0] = v & 0xff;
    p[1] = v >> 8;
}

static inline void cmp_put_le32(uint8_t *p, uint32_t v)
{
    p[0] = v & 0xff;
    p[1] = (v >> 8) & 0xff;
    p[2] = (v >> 16) & 0xff;
    p[3] = (v >> 24) & 0xff;
}

static uint64_t cmp_round_up_4096(uint64_t v)
{
    return (v + 4095ULL) & ~4095ULL;
}

static uint32_t cmp_get_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void cmp_partition_init_geometry(CMPFolderPartition *p, size_t index)
{
    uint64_t capacity_entries;

    p->letter = cmp_partition_layout[index].letter;
    p->label = cmp_partition_layout[index].label;
    p->offset = cmp_partition_layout[index].offset;
    p->size = cmp_partition_layout[index].size;
    p->volume_id = 0x434d5000u | (uint8_t)p->letter;
    capacity_entries = p->size / CMP_CLUSTER_SIZE + 1;
    p->fat_bits = capacity_entries < 0xfff0ULL ? 16 : 32;
    p->fat_size = cmp_round_up_4096(capacity_entries * (p->fat_bits / 8));
    p->cluster_offset = CMP_FAT_OFFSET + p->fat_size;
    p->max_clusters = (uint32_t)((p->size - p->cluster_offset) /
                                 CMP_CLUSTER_SIZE + 1);
}

static void cmp_entry_free(gpointer opaque)
{
    CMPFolderEntry *entry = opaque;
    if (!entry) {
        return;
    }
    if (entry->children) {
        g_ptr_array_free(entry->children, true);
    }
    g_free(entry->name);
    g_free(entry->host_path);
    g_free(entry);
}

static gint cmp_entry_name_compare(gconstpointer a, gconstpointer b)
{
    const CMPFolderEntry *ea = *(CMPFolderEntry * const *)a;
    const CMPFolderEntry *eb = *(CMPFolderEntry * const *)b;
    return g_ascii_strcasecmp(ea->name, eb->name);
}

static bool cmp_valid_host_name(const char *name)
{
    size_t len;
    if (!name || !name[0] || !strcmp(name, ".") || !strcmp(name, "..")) {
        return false;
    }
    len = strlen(name);
    return len <= CMP_MAX_FILENAME;
}

static CMPFolderEntry *cmp_scan_entry(const char *path, const char *name,
                                      Error **errp);

static bool cmp_scan_children(CMPFolderEntry *dir, Error **errp)
{
    GDir *gd;
    const char *name;
    GError *gerr = NULL;

    dir->children = g_ptr_array_new_with_free_func(cmp_entry_free);
    gd = g_dir_open(dir->host_path, 0, &gerr);
    if (!gd) {
        error_setg(errp, "Folder-HDD: cannot open '%s': %s", dir->host_path,
                   gerr ? gerr->message : "unknown error");
        g_clear_error(&gerr);
        return false;
    }

    while ((name = g_dir_read_name(gd)) != NULL) {
        char *child_path;
        CMPFolderEntry *child;
        if (!cmp_valid_host_name(name)) {
            error_setg(errp,
                       "Folder-HDD: FATX name '%s' in '%s' exceeds 42 bytes or is invalid",
                       name, dir->host_path);
            g_dir_close(gd);
            return false;
        }
        child_path = g_build_filename(dir->host_path, name, NULL);
        child = cmp_scan_entry(child_path, name, errp);
        g_free(child_path);
        if (!child) {
            g_dir_close(gd);
            return false;
        }
        g_ptr_array_add(dir->children, child);
    }
    g_dir_close(gd);
    g_ptr_array_sort(dir->children, cmp_entry_name_compare);
    return true;
}

static CMPFolderEntry *cmp_scan_entry(const char *path, const char *name,
                                      Error **errp)
{
    GStatBuf st;
    CMPFolderEntry *entry;
    if (g_stat(path, &st) != 0) {
        error_setg_errno(errp, errno, "Folder-HDD: cannot stat '%s'", path);
        return NULL;
    }
    if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) {
        error_setg(errp, "Folder-HDD: unsupported host item '%s'", path);
        return NULL;
    }

    entry = g_new0(CMPFolderEntry, 1);
    entry->name = g_strdup(name);
    entry->host_path = g_strdup(path);
    entry->directory = S_ISDIR(st.st_mode);
    entry->size = entry->directory ? 0 : (uint64_t)st.st_size;
    if (entry->directory && !cmp_scan_children(entry, errp)) {
        cmp_entry_free(entry);
        return NULL;
    }
    return entry;
}

static CMPClusterMap *cmp_cluster_map_get(CMPFolderPartition *p,
                                          uint32_t cluster)
{
    if (!p->cluster_map || cluster >= p->cluster_map->len) {
        return NULL;
    }
    return g_ptr_array_index(p->cluster_map, cluster);
}

static void cmp_collect_allocation_hints(const CMPFolderEntry *entry,
                                         GHashTable *hints)
{
    CMPAllocationHint *hint;

    if (!entry || !entry->host_path) {
        return;
    }
    if (entry->cluster_count > 0) {
        hint = g_new0(CMPAllocationHint, 1);
        hint->first_cluster = entry->first_cluster;
        hint->cluster_count = entry->cluster_count;
        hint->directory = entry->directory;
        g_hash_table_insert(hints, g_strdup(entry->host_path), hint);
    }
    if (!entry->directory || !entry->children) {
        return;
    }
    for (guint i = 0; i < entry->children->len; ++i) {
        cmp_collect_allocation_hints(g_ptr_array_index(entry->children, i),
                                     hints);
    }
}

static bool cmp_cluster_arrays_resize(CMPFolderPartition *p, uint32_t count,
                                      Error **errp)
{
    if ((uint64_t)count > (uint64_t)p->max_clusters + 1ULL) {
        error_setg(errp,
                   "Folder-HDD %c: host contents exceed virtual partition capacity",
                   p->letter);
        return false;
    }
    if (p->fat->len < count) {
        g_array_set_size(p->fat, count);
    }
    if (p->cluster_map->len < count) {
        g_ptr_array_set_size(p->cluster_map, count);
    }
    return true;
}

static bool cmp_assign_chain(CMPFolderPartition *p, CMPFolderEntry *entry,
                             uint32_t count, CMPClusterKind kind,
                             const CMPAllocationHint *hint, Error **errp)
{
    uint32_t first;

    if (count == 0) {
        entry->first_cluster = 0;
        entry->cluster_count = 0;
        return true;
    }

    /* Preserve stable cluster assignments for unchanged host entries. */
    if (hint && hint->directory == entry->directory &&
        hint->first_cluster > 0 && hint->cluster_count >= count) {
        first = hint->first_cluster;
        count = hint->cluster_count;
    } else {
        first = MAX(1U, p->next_cluster);
        p->next_cluster = first + count;
    }

    if (!cmp_cluster_arrays_resize(p, first + count, errp)) {
        return false;
    }
    for (uint32_t i = 0; i < count; ++i) {
        if (g_ptr_array_index(p->cluster_map, first + i) != NULL) {
            error_setg(errp,
                       "Folder-HDD %c: live-rescan allocation collision at cluster %u",
                       p->letter, first + i);
            return false;
        }
    }

    entry->first_cluster = first;
    entry->cluster_count = count;
    for (uint32_t i = 0; i < count; ++i) {
        uint32_t value = (i + 1 == count) ? CMP_FAT_END : first + i + 1;
        CMPClusterMap *map = g_new0(CMPClusterMap, 1);
        map->kind = kind;
        map->entry = entry;
        map->file_offset = (uint64_t)i * CMP_CLUSTER_SIZE;
        g_array_index(p->fat, uint32_t, first + i) = value;
        g_ptr_array_index(p->cluster_map, first + i) = map;
    }
    p->next_cluster = MAX(p->next_cluster, first + count);
    return true;
}

static bool cmp_allocate_tree(CMPFolderPartition *p, CMPFolderEntry *entry,
                              GHashTable *hints, Error **errp)
{
    const CMPAllocationHint *hint = NULL;
    uint32_t count;

    if (hints && entry->host_path) {
        hint = g_hash_table_lookup(hints, entry->host_path);
    }
    if (entry->directory) {
        uint64_t bytes = ((uint64_t)entry->children->len + 1ULL) * CMP_DIR_ENTRY_SIZE;
        count = MAX(1U, (uint32_t)((bytes + CMP_CLUSTER_SIZE - 1) /
                                  CMP_CLUSTER_SIZE));
        if (!cmp_assign_chain(p, entry, count, CMP_CLUSTER_DIRECTORY, hint,
                              errp)) {
            return false;
        }
        for (guint i = 0; i < entry->children->len; ++i) {
            if (!cmp_allocate_tree(p, g_ptr_array_index(entry->children, i),
                                   hints, errp)) {
                return false;
            }
        }
    } else {
        count = entry->size ? (uint32_t)((entry->size + CMP_CLUSTER_SIZE - 1) /
                                         CMP_CLUSTER_SIZE) : 0;
        if (!cmp_assign_chain(p, entry, count, CMP_CLUSTER_FILE, hint, errp)) {
            return false;
        }
    }
    return true;
}

static void cmp_fill_dir_entry(uint8_t *raw, CMPFolderEntry *entry)
{
    size_t len = strlen(entry->name);
    memset(raw, 0xff, CMP_DIR_ENTRY_SIZE);
    raw[0] = (uint8_t)len;
    raw[1] = entry->directory ? CMP_ATTR_DIRECTORY : 0;
    memcpy(raw + 2, entry->name, len);
    memset(raw + 2 + len, 0xff, CMP_MAX_FILENAME - len);
    cmp_put_le32(raw + 44, entry->first_cluster);
    cmp_put_le32(raw + 48, entry->directory ? 0 : (uint32_t)MIN(entry->size,
                                                               UINT32_MAX));
    /* FATX DOS timestamps: deterministic zero is valid and avoids host-time churn. */
    cmp_put_le16(raw + 52, 0);
    cmp_put_le16(raw + 54, 0);
    cmp_put_le16(raw + 56, 0);
    cmp_put_le16(raw + 58, 0);
    cmp_put_le16(raw + 60, 0);
    cmp_put_le16(raw + 62, 0);
}

static bool cmp_materialize_directories(CMPFolderPartition *p,
                                        CMPFolderEntry *entry, Error **errp)
{
    uint64_t total;
    uint8_t *bytes;
    if (!entry->directory) {
        return true;
    }
    total = (uint64_t)entry->cluster_count * CMP_CLUSTER_SIZE;
    bytes = g_malloc0(total);
    memset(bytes, 0xff, total);
    for (guint i = 0; i < entry->children->len; ++i) {
        cmp_fill_dir_entry(bytes + (uint64_t)i * CMP_DIR_ENTRY_SIZE,
                           g_ptr_array_index(entry->children, i));
    }
    bytes[(uint64_t)entry->children->len * CMP_DIR_ENTRY_SIZE] = 0xff;

    for (uint32_t i = 0; i < entry->cluster_count; ++i) {
        CMPClusterMap *map = cmp_cluster_map_get(p, entry->first_cluster + i);
        if (!map) {
            error_setg(errp, "Folder-HDD %c: internal directory mapping failure",
                       p->letter);
            g_free(bytes);
            return false;
        }
        map->dir_bytes = bytes + (uint64_t)i * CMP_CLUSTER_SIZE;
    }
    /* First mapping owns allocation; close() frees unique directory bases. */
    cmp_cluster_map_get(p, entry->first_cluster)->file_offset = (uintptr_t)bytes;

    for (guint i = 0; i < entry->children->len; ++i) {
        if (!cmp_materialize_directories(p, g_ptr_array_index(entry->children, i), errp)) {
            return false;
        }
    }
    return true;
}

static void cmp_partition_cleanup(CMPFolderPartition *p)
{
    if (p->cluster_map) {
        for (guint i = 1; i < p->cluster_map->len; ++i) {
            CMPClusterMap *map = g_ptr_array_index(p->cluster_map, i);
            if (map && map->kind == CMP_CLUSTER_DIRECTORY && map->entry &&
                map->entry->first_cluster == i && map->file_offset) {
                g_free((void *)(uintptr_t)map->file_offset);
                map->file_offset = 0;
            }
        }
        g_ptr_array_free(p->cluster_map, true);
        p->cluster_map = NULL;
    }
    if (p->fat) {
        g_array_free(p->fat, true);
        p->fat = NULL;
    }
    if (p->root.children) {
        g_ptr_array_free(p->root.children, true);
        p->root.children = NULL;
    }
    g_free(p->root.name);
    g_free(p->root.host_path);
    memset(&p->root, 0, sizeof(p->root));
}

static bool cmp_partition_build_with_hints(CMPFolderPartition *p,
                                            const char *root, size_t index,
                                            GHashTable *hints,
                                            uint32_t previous_high_water,
                                            Error **errp)
{
    char subdir[2] = { cmp_partition_layout[index].letter, 0 };
    char *path = NULL;
    GStatBuf st;
    bool ok = false;

    cmp_partition_init_geometry(p, index);

    /* X/Y/Z are backed by the cache image, not host directories. */
    if (p->letter == 'X' || p->letter == 'Y' || p->letter == 'Z') {
        return true;
    }

    path = g_build_filename(root, subdir, NULL);

    if (g_stat(path, &st) != 0) {
        /* Missing partitions are deliberately exposed as unformatted/zeroed. */
        g_free(path);
        return true;
    }
    if (!S_ISDIR(st.st_mode)) {
        error_setg(errp, "Folder-HDD: '%s' must be a directory", path);
        g_free(path);
        return false;
    }

    p->fat = g_array_sized_new(false, true, sizeof(uint32_t),
                               MAX(64U, previous_high_water + 1));
    p->cluster_map = g_ptr_array_new_with_free_func(g_free);
    if (!cmp_cluster_arrays_resize(p, previous_high_water + 1, errp)) {
        goto out;
    }
    if (p->fat->len == 0) {
        if (!cmp_cluster_arrays_resize(p, 1, errp)) {
            goto out;
        }
    }
    /* Do not reuse deleted clusters during a live session/import. */
    g_array_index(p->fat, uint32_t, 0) = CMP_FAT_END;
    p->next_cluster = MAX(1U, previous_high_water + 1);

    p->root.name = g_strdup("");
    p->root.host_path = path;
    path = NULL;
    p->root.directory = true;
    if (!cmp_scan_children(&p->root, errp) ||
        !cmp_allocate_tree(p, &p->root, hints, errp) ||
        p->root.first_cluster != 1 ||
        !cmp_materialize_directories(p, &p->root, errp)) {
        goto out;
    }
    p->present = true;
    ok = true;
out:
    g_free(path);
    return ok;
}

static bool cmp_partition_build(CMPFolderPartition *p, const char *root,
                                size_t index,
                                const CMPFolderPartition *previous,
                                Error **errp)
{
    GHashTable *hints =
        g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    uint32_t previous_high_water = 0;
    if (previous && previous->present && previous->cluster_map) {
        previous_high_water = previous->cluster_map->len > 0
            ? previous->cluster_map->len - 1
            : 0;
        cmp_collect_allocation_hints(&previous->root, hints);
    }
    const bool ok = cmp_partition_build_with_hints(
        p, root, index, hints, previous_high_water, errp);
    g_hash_table_destroy(hints);
    return ok;
}

static void cmp_set_backing_read_error(char **error_text,
                                       const CMPFolderEntry *entry,
                                       const char *operation, int errnum)
{
    if (!error_text || *error_text) {
        return;
    }
    *error_text = g_strdup_printf(
        "Folder-HDD could not %s host backing file '%s': %s",
        operation, entry && entry->host_path ? entry->host_path : "<unknown>",
        g_strerror(errnum ? errnum : EIO));
}

static int cmp_file_read(CMPFolderEntry *entry, uint64_t offset,
                         uint8_t *buf, size_t bytes, char **error_text)
{
    FILE *fp;
    size_t got;
    memset(buf, 0, bytes);
    if (!entry || offset >= entry->size || bytes == 0) {
        return 0;
    }
    fp = g_fopen(entry->host_path, "rb");
    if (!fp) {
        const int e = errno ? errno : EIO;
        cmp_set_backing_read_error(error_text, entry, "open", e);
        return -e;
    }
#ifdef _WIN32
    if (_fseeki64(fp, (__int64)offset, SEEK_SET) != 0) {
#else
    if (fseeko(fp, (off_t)offset, SEEK_SET) != 0) {
#endif
        const int e = errno ? errno : EIO;
        cmp_set_backing_read_error(error_text, entry, "seek", e);
        fclose(fp);
        return -e;
    }
    got = fread(buf, 1, MIN((uint64_t)bytes, entry->size - offset), fp);
    if (ferror(fp)) {
        const int e = errno ? errno : EIO;
        cmp_set_backing_read_error(error_text, entry, "read", e);
        fclose(fp);
        return -e;
    }
    fclose(fp);
    (void)got;
    return 0;
}

static void cmp_read_superblock(CMPFolderPartition *p, uint64_t rel,
                                uint8_t *buf, size_t bytes)
{
    uint8_t super[CMP_SUPERBLOCK_SIZE];
    memset(super, 0xff, sizeof(super));
    cmp_put_le32(super + 0, CMP_FATX_SIGNATURE);
    cmp_put_le32(super + 4, p->volume_id);
    cmp_put_le32(super + 8, CMP_SECTORS_PER_CLUSTER);
    cmp_put_le32(super + 12, 1);
    memcpy(buf, super + rel, bytes);
}

static void cmp_read_fat(CMPFolderPartition *p, uint64_t rel,
                         uint8_t *buf, size_t bytes)
{
    uint32_t entry_bytes = p->fat_bits / 8;
    memset(buf, 0, bytes);
    for (size_t pos = 0; pos < bytes; ++pos) {
        uint64_t absolute = rel + pos;
        uint32_t cluster = absolute / entry_bytes;
        uint32_t byte_index = absolute % entry_bytes;
        uint32_t value = 0;
        if (cluster < p->fat->len) {
            value = g_array_index(p->fat, uint32_t, cluster);
            if (value == CMP_FAT_END && p->fat_bits == 16) {
                value = 0xffffu;
            }
        }
        buf[pos] = (uint8_t)(value >> (byte_index * 8));
    }
}


static int cmp_cache_seek(FILE *fp, uint64_t offset)
{
#ifdef _WIN32
    return _fseeki64(fp, (__int64)offset, SEEK_SET);
#else
    return fseeko(fp, (off_t)offset, SEEK_SET);
#endif
}

static bool cmp_cache_flush_file(FILE *fp, char **error_text)
{
    if (!fp) {
        return true;
    }
    if (fflush(fp) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf("Folder-HDD cache flush failed: %s",
                                          g_strerror(errno));
        }
        return false;
    }
#ifdef _WIN32
    if (_commit(_fileno(fp)) != 0) {
#else
    if (fsync(fileno(fp)) != 0) {
#endif
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cache durable flush failed: %s", g_strerror(errno));
        }
        return false;
    }
    return true;
}

static void cmp_cache_mark_sparse(FILE *fp)
{
#ifdef _WIN32
    DWORD returned = 0;
    const intptr_t handle = _get_osfhandle(_fileno(fp));
    if (handle != -1) {
        (void)DeviceIoControl((HANDLE)handle, FSCTL_SET_SPARSE, NULL, 0, NULL,
                              0, &returned, NULL);
    }
#else
    (void)fp;
#endif
}

static bool cmp_cache_set_length(FILE *fp, uint64_t size, char **error_text)
{
#ifdef _WIN32
    const int fd = _fileno(fp);
#else
    const int fd = fileno(fp);
#endif
    if (ftruncate(fd, (int64_t)size) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot size cache image: %s", g_strerror(errno));
        }
        return false;
    }
    return true;
}

static bool cmp_cache_write_at(FILE *fp, uint64_t offset, const void *buffer,
                               size_t size, char **error_text)
{
    if (cmp_cache_seek(fp, offset) != 0 ||
        (size && fwrite(buffer, 1, size, fp) != size)) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cache write failed at 0x%" PRIx64 ": %s",
                offset, g_strerror(errno ? errno : EIO));
        }
        return false;
    }
    return true;
}

static int cmp_cache_read(BDRVCMPFolderHDDState *s, uint64_t disk_offset,
                          uint8_t *buffer, size_t size)
{
    if (!s->cache_fp || disk_offset < CMP_CACHE_DISK_START ||
        disk_offset > CMP_CACHE_DISK_END ||
        size > CMP_CACHE_DISK_END - disk_offset) {
        return -EINVAL;
    }
    const uint64_t image_offset = disk_offset - CMP_CACHE_DISK_START;
    if (cmp_cache_seek(s->cache_fp, image_offset) != 0) {
        return -errno;
    }
    if (size && fread(buffer, 1, size, s->cache_fp) != size) {
        return -(errno ? errno : EIO);
    }
    return 0;
}

static int cmp_cache_write(BDRVCMPFolderHDDState *s, uint64_t disk_offset,
                           const uint8_t *buffer, size_t size)
{
    if (!s->cache_fp || disk_offset < CMP_CACHE_DISK_START ||
        disk_offset > CMP_CACHE_DISK_END ||
        size > CMP_CACHE_DISK_END - disk_offset) {
        return -EINVAL;
    }
    const uint64_t image_offset = disk_offset - CMP_CACHE_DISK_START;
    if (cmp_cache_seek(s->cache_fp, image_offset) != 0 ||
        (size && fwrite(buffer, 1, size, s->cache_fp) != size)) {
        return -(errno ? errno : EIO);
    }
    s->cache_dirty = true;
    s->cache_write_count += size / CMP_SECTOR_SIZE;
    return 0;
}

static bool cmp_cache_partition_header_valid(FILE *fp, size_t index)
{
    uint8_t header[16];
    const uint64_t image_offset =
        cmp_partition_layout[index].offset - CMP_CACHE_DISK_START;
    if (cmp_cache_seek(fp, image_offset) != 0 ||
        fread(header, 1, sizeof(header), fp) != sizeof(header)) {
        return false;
    }
    return cmp_get_le32(header + 0) == CMP_FATX_SIGNATURE &&
           cmp_get_le32(header + 8) == CMP_SECTORS_PER_CLUSTER &&
           cmp_get_le32(header + 12) == 1;
}

static bool cmp_cache_format_partition(FILE *fp, size_t index,
                                       char **error_text)
{
    CMPFolderPartition p = { 0 };
    uint8_t super[CMP_SUPERBLOCK_SIZE];
    uint8_t fat_end[8];
    uint8_t root_cluster[CMP_CLUSTER_SIZE];
    const uint64_t image_offset =
        cmp_partition_layout[index].offset - CMP_CACHE_DISK_START;

    cmp_partition_init_geometry(&p, index);
    memset(super, 0xff, sizeof(super));
    cmp_put_le32(super + 0, CMP_FATX_SIGNATURE);
    cmp_put_le32(super + 4, p.volume_id);
    cmp_put_le32(super + 8, CMP_SECTORS_PER_CLUSTER);
    cmp_put_le32(super + 12, 1);
    if (!cmp_cache_write_at(fp, image_offset, super, sizeof(super), error_text)) {
        return false;
    }

    memset(fat_end, 0xff, sizeof(fat_end));
    const size_t fat_bytes = p.fat_bits == 16 ? 4 : 8;
    if (!cmp_cache_write_at(fp, image_offset + CMP_FAT_OFFSET, fat_end,
                            fat_bytes, error_text)) {
        return false;
    }

    memset(root_cluster, 0xff, sizeof(root_cluster));
    if (!cmp_cache_write_at(fp, image_offset + p.cluster_offset, root_cluster,
                            sizeof(root_cluster), error_text)) {
        return false;
    }
    return true;
}

static bool cmp_cache_prepare(const char *root, FILE **opened_fp,
                              char **opened_path, char **error_text)
{
    char *cache_dir = NULL;
    char *cache_path = NULL;
    FILE *fp = NULL;
    GStatBuf st;
    bool created = false;
    bool ok = false;

    if (error_text) {
        *error_text = NULL;
    }
    cache_dir = g_build_filename(root, CMP_CACHE_DIRECTORY, NULL);
    if (g_stat(cache_dir, &st) == 0) {
        if (!S_ISDIR(st.st_mode)) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cache path '%s' exists but is not a directory.",
                    cache_dir);
            }
            goto out;
        }
    } else if (errno != ENOENT) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot inspect cache directory '%s': %s",
                cache_dir, g_strerror(errno));
        }
        goto out;
    } else if (g_mkdir_with_parents(cache_dir, 0755) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot create cache directory '%s': %s",
                cache_dir, g_strerror(errno));
        }
        goto out;
    }

    cache_path = g_build_filename(cache_dir, CMP_CACHE_FILENAME, NULL);
    if (g_stat(cache_path, &st) != 0) {
        if (errno != ENOENT) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot inspect cache image '%s': %s",
                    cache_path, g_strerror(errno));
            }
            goto out;
        }
        fp = g_fopen(cache_path, "w+b");
        if (!fp) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot create cache image '%s': %s",
                    cache_path, g_strerror(errno));
            }
            goto out;
        }
        created = true;
        cmp_cache_mark_sparse(fp);
        if (!cmp_cache_set_length(fp, CMP_CACHE_IMAGE_SIZE, error_text)) {
            goto out;
        }
        for (size_t i = 2; i < G_N_ELEMENTS(cmp_partition_layout); ++i) {
            if (!cmp_cache_format_partition(fp, i, error_text)) {
                goto out;
            }
        }
        if (!cmp_cache_flush_file(fp, error_text)) {
            goto out;
        }
    } else {
        if (!S_ISREG(st.st_mode)) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cache image path '%s' is not a regular file.",
                    cache_path);
            }
            goto out;
        }
        if ((uint64_t)st.st_size < CMP_CACHE_IMAGE_SIZE) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cache image '%s' is too small. Delete it to let xemu create a fresh cache image.",
                    cache_path);
            }
            goto out;
        }
        fp = g_fopen(cache_path, "r+b");
        if (!fp) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot open cache image '%s': %s",
                    cache_path, g_strerror(errno));
            }
            goto out;
        }
        for (size_t i = 2; i < G_N_ELEMENTS(cmp_partition_layout); ++i) {
            if (!cmp_cache_partition_header_valid(fp, i)) {
                if (error_text) {
                    *error_text = g_strdup_printf(
                        "Folder-HDD cache image '%s' is not a valid X/Y/Z FATX cache image. Delete it to let xemu recreate it.",
                        cache_path);
                }
                goto out;
            }
        }
    }

    if (opened_fp) {
        *opened_fp = fp;
        fp = NULL;
    }
    if (opened_path) {
        *opened_path = cache_path;
        cache_path = NULL;
    }
    ok = true;
out:
    if (fp) {
        fclose(fp);
    }
    if (!ok && created && cache_path) {
        (void)g_remove(cache_path);
    }
    g_free(cache_path);
    g_free(cache_dir);
    return ok;
}


static const char *cmp_ce_image_filename(size_t index)
{
    return index == 0 ? CMP_C_IMAGE_FILENAME : CMP_E_IMAGE_FILENAME;
}

static bool cmp_ce_image_flush_file(FILE *fp, const char *path,
                                    char **error_text)
{
    if (!fp) {
        return true;
    }
    if (fflush(fp) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD C/E image flush failed for '%s': %s",
                path ? path : "<unknown>", g_strerror(errno ? errno : EIO));
        }
        return false;
    }
#ifdef _WIN32
    if (_commit(_fileno(fp)) != 0) {
#else
    if (fsync(fileno(fp)) != 0) {
#endif
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD C/E image durable flush failed for '%s': %s",
                path ? path : "<unknown>", g_strerror(errno ? errno : EIO));
        }
        return false;
    }
    return true;
}

static bool cmp_ce_image_set_length(FILE *fp, uint64_t size,
                                    const char *path, char **error_text)
{
#ifdef _WIN32
    const int fd = _fileno(fp);
#else
    const int fd = fileno(fp);
#endif
    if (ftruncate(fd, (int64_t)size) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot size C/E image '%s': %s",
                path ? path : "<unknown>", g_strerror(errno ? errno : EIO));
        }
        return false;
    }
    return true;
}

static bool cmp_ce_image_write_at(FILE *fp, uint64_t offset,
                                  const void *buffer, size_t size,
                                  const char *path, char **error_text)
{
    if (cmp_cache_seek(fp, offset) != 0 ||
        (size && fwrite(buffer, 1, size, fp) != size)) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD C/E image write failed for '%s' at 0x%" PRIx64
                ": %s",
                path ? path : "<unknown>", offset,
                g_strerror(errno ? errno : EIO));
        }
        return false;
    }
    return true;
}

static bool cmp_ce_image_write_generated(FILE *fp, const char *path,
                                         CMPFolderPartition *p,
                                         char **error_text)
{
    uint8_t *buffer = NULL;
    bool ok = false;

    if (!fp || !p || !p->present) {
        if (error_text) {
            *error_text = g_strdup("Folder-HDD cannot build a missing C/E partition image.");
        }
        return false;
    }
    cmp_cache_mark_sparse(fp);
    if (!cmp_ce_image_set_length(fp, p->size, path, error_text)) {
        return false;
    }

    buffer = g_try_malloc(CMP_CLUSTER_SIZE);
    if (!buffer) {
        if (error_text) {
            *error_text = g_strdup("Folder-HDD cannot allocate the C/E image staging buffer.");
        }
        return false;
    }

    cmp_read_superblock(p, 0, buffer, CMP_SUPERBLOCK_SIZE);
    if (!cmp_ce_image_write_at(fp, 0, buffer, CMP_SUPERBLOCK_SIZE,
                               path, error_text)) {
        goto out;
    }

    for (uint64_t rel = 0; rel < p->fat_size;) {
        const size_t chunk = (size_t)MIN((uint64_t)CMP_CLUSTER_SIZE,
                                        p->fat_size - rel);
        cmp_read_fat(p, rel, buffer, chunk);
        if (!cmp_ce_image_write_at(fp, CMP_FAT_OFFSET + rel, buffer, chunk,
                                   path, error_text)) {
            goto out;
        }
        rel += chunk;
    }

    for (guint cluster = 1; p->cluster_map && cluster < p->cluster_map->len;
         ++cluster) {
        CMPClusterMap *map = g_ptr_array_index(p->cluster_map, cluster);
        if (!map) {
            continue;
        }
        if (map->kind == CMP_CLUSTER_DIRECTORY) {
            memcpy(buffer, map->dir_bytes, CMP_CLUSTER_SIZE);
        } else if (map->kind == CMP_CLUSTER_FILE) {
            char *read_error = NULL;
            const int ret = cmp_file_read(map->entry, map->file_offset,
                                          buffer, CMP_CLUSTER_SIZE,
                                          &read_error);
            if (ret < 0) {
                if (error_text) {
                    *error_text = read_error ? read_error : g_strdup(
                        "Folder-HDD could not read a host file while building C/E image.");
                    read_error = NULL;
                }
                g_free(read_error);
                goto out;
            }
        } else {
            continue;
        }
        const uint64_t image_offset = p->cluster_offset +
            ((uint64_t)cluster - 1ULL) * CMP_CLUSTER_SIZE;
        if (!cmp_ce_image_write_at(fp, image_offset, buffer, CMP_CLUSTER_SIZE,
                                   path, error_text)) {
            goto out;
        }
    }

    if (!cmp_ce_image_flush_file(fp, path, error_text)) {
        goto out;
    }
    ok = true;
out:
    g_free(buffer);
    return ok;
}

static bool cmp_ce_image_header_valid(FILE *fp, size_t index)
{
    uint8_t header[16];
    CMPFolderPartition p = { 0 };
    if (!fp || index >= 2) {
        return false;
    }
    cmp_partition_init_geometry(&p, index);
    if (cmp_cache_seek(fp, 0) != 0 ||
        fread(header, 1, sizeof(header), fp) != sizeof(header)) {
        return false;
    }
    return cmp_get_le32(header) == CMP_FATX_SIGNATURE &&
           cmp_get_le32(header + 4) == p.volume_id &&
           cmp_get_le32(header + 8) == CMP_SECTORS_PER_CLUSTER &&
           cmp_get_le32(header + 12) != 0;
}

static bool cmp_ce_image_prepare_one(const char *root, size_t index,
                                     FILE **opened_fp, char **opened_path,
                                     bool *created, char **error_text)
{
    CMPFolderPartition generated = { 0 };
    Error *local_err = NULL;
    char *images_dir = NULL;
    char *path = NULL;
    char *backup = NULL;
    char *temp = NULL;
    FILE *fp = NULL;
    GStatBuf st;
    int stat_result;
    int stat_error;
    bool made = false;
    bool ok = false;

    if (created) {
        *created = false;
    }
    images_dir = g_build_filename(root, CMP_IMAGES_DIRECTORY, NULL);
    if (g_mkdir_with_parents(images_dir, 0755) != 0 && errno != EEXIST) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot create C/E image directory '%s': %s",
                images_dir, g_strerror(errno));
        }
        goto out;
    }
    path = g_build_filename(images_dir, cmp_ce_image_filename(index), NULL);
    backup = g_strdup_printf("%s.cmp-old", path);

    /* Recover a transaction interrupted after the old image was moved aside. */
    stat_result = g_stat(path, &st);
    stat_error = stat_result == 0 ? 0 : errno;
    if (stat_result != 0 && stat_error == ENOENT &&
        g_file_test(backup, G_FILE_TEST_IS_REGULAR)) {
        if (g_rename(backup, path) != 0) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot recover C/E image '%s': %s",
                    path, g_strerror(errno));
            }
            goto out;
        }
        stat_result = g_stat(path, &st);
        stat_error = stat_result == 0 ? 0 : errno;
    }

    if (stat_result == 0) {
        CMPFolderPartition geometry = { 0 };
        cmp_partition_init_geometry(&geometry, index);
        if (!S_ISREG(st.st_mode) || (uint64_t)st.st_size < geometry.size) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD C/E image '%s' is missing data or is too small.",
                    path);
            }
            goto out;
        }
        fp = g_fopen(path, "r+b");
        if (!fp || !cmp_ce_image_header_valid(fp, index)) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD C/E image '%s' is not a valid FATX image.", path);
            }
            goto out;
        }
        if (g_file_test(backup, G_FILE_TEST_EXISTS)) {
            (void)g_remove(backup);
        }
    } else if (stat_error == ENOENT) {
        if (!cmp_partition_build(&generated, root, index, NULL, &local_err)) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot create %c.img from the host mirror: %s",
                    cmp_partition_layout[index].letter,
                    local_err ? error_get_pretty(local_err) : "unknown error");
            }
            goto out;
        }
        temp = g_strdup_printf("%s.cmp-new-%08x", path, g_random_int());
        fp = g_fopen(temp, "w+b");
        if (!fp) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot create temporary C/E image '%s': %s",
                    temp, g_strerror(errno));
            }
            goto out;
        }
        if (!cmp_ce_image_write_generated(fp, temp, &generated, error_text)) {
            goto out;
        }
        fclose(fp);
        fp = NULL;
        if (g_rename(temp, path) != 0) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD cannot install C/E image '%s': %s",
                    path, g_strerror(errno));
            }
            goto out;
        }
        (void)g_remove(temp);
        made = true;
        fp = g_fopen(path, "r+b");
        if (!fp || !cmp_ce_image_header_valid(fp, index)) {
            if (error_text) {
                *error_text = g_strdup_printf(
                    "Folder-HDD could not reopen newly created C/E image '%s'.",
                    path);
            }
            goto out;
        }
    } else {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot inspect C/E image '%s': %s",
                path, g_strerror(stat_error));
        }
        goto out;
    }

    if (opened_fp) {
        *opened_fp = fp;
        fp = NULL;
    }
    if (opened_path) {
        *opened_path = path;
        path = NULL;
    }
    if (created) {
        *created = made;
    }
    ok = true;
out:
    error_free(local_err);
    cmp_partition_cleanup(&generated);
    if (fp) {
        fclose(fp);
    }
    if (!ok && temp) {
        (void)g_remove(temp);
    }
    g_free(temp);
    g_free(backup);
    g_free(path);
    g_free(images_dir);
    return ok;
}

static bool cmp_ce_images_prepare(BDRVCMPFolderHDDState *s, const char *root,
                                  unsigned *created_mask, char **error_text)
{
    FILE *fps[2] = { NULL, NULL };
    char *paths[2] = { NULL, NULL };
    bool created[2] = { false, false };
    if (created_mask) {
        *created_mask = 0;
    }
    for (size_t i = 0; i < 2; ++i) {
        if (!cmp_ce_image_prepare_one(root, i, &fps[i], &paths[i],
                                      &created[i], error_text)) {
            for (size_t j = 0; j < 2; ++j) {
                if (fps[j]) {
                    fclose(fps[j]);
                }
                g_free(paths[j]);
            }
            return false;
        }
    }
    if (created_mask) {
        *created_mask = (created[0] ? 1u : 0u) | (created[1] ? 2u : 0u);
    }
    if (s) {
        for (size_t i = 0; i < 2; ++i) {
            s->ce_image_fps[i] = fps[i];
            s->ce_image_paths[i] = paths[i];
        }
    } else {
        for (size_t i = 0; i < 2; ++i) {
            fclose(fps[i]);
            g_free(paths[i]);
        }
    }
    return true;
}

static void cmp_ce_images_close(BDRVCMPFolderHDDState *s)
{
    if (!s) {
        return;
    }
    for (size_t i = 0; i < 2; ++i) {
        if (s->ce_image_fps[i]) {
            fclose(s->ce_image_fps[i]);
            s->ce_image_fps[i] = NULL;
        }
        g_clear_pointer(&s->ce_image_paths[i], g_free);
        s->ce_image_dirty[i] = false;
    }
}

static int cmp_ce_image_read(BDRVCMPFolderHDDState *s, size_t index,
                             uint64_t rel, uint8_t *buffer, size_t size)
{
    if (!s || index >= 2 || !s->ce_image_fps[index] ||
        rel > cmp_partition_layout[index].size ||
        size > cmp_partition_layout[index].size - rel) {
        return -EINVAL;
    }
    if (cmp_cache_seek(s->ce_image_fps[index], rel) != 0) {
        return -(errno ? errno : EIO);
    }
    if (size && fread(buffer, 1, size, s->ce_image_fps[index]) != size) {
        return -(errno ? errno : EIO);
    }
    return 0;
}

static int cmp_ce_image_write(BDRVCMPFolderHDDState *s, size_t index,
                              uint64_t rel, const uint8_t *buffer, size_t size)
{
    if (!s || index >= 2 || !s->ce_image_fps[index] ||
        rel > cmp_partition_layout[index].size ||
        size > cmp_partition_layout[index].size - rel) {
        return -EINVAL;
    }
    if (cmp_cache_seek(s->ce_image_fps[index], rel) != 0 ||
        (size && fwrite(buffer, 1, size, s->ce_image_fps[index]) != size)) {
        return -(errno ? errno : EIO);
    }
    s->ce_image_dirty[index] = true;
    s->ce_write_count += size / CMP_SECTOR_SIZE;
    return 0;
}

static bool cmp_ce_images_flush_locked(BDRVCMPFolderHDDState *s,
                                       char **error_text)
{
    for (size_t i = 0; i < 2; ++i) {
        if (!s->ce_image_dirty[i]) {
            continue;
        }
        if (!cmp_ce_image_flush_file(s->ce_image_fps[i],
                                     s->ce_image_paths[i], error_text)) {
            return false;
        }
        s->ce_image_dirty[i] = false;
    }
    return true;
}

static bool cmp_ce_build_host_partition_from_live_image(
    BDRVCMPFolderHDDState *s, size_t index, CMPFolderPartition *rebuilt,
    Error **errp)
{
    CMPFolderHddAllocationHint *raw_hints = NULL;
    size_t hint_count = 0;
    uint32_t high_water = 0;
    char *hint_error = NULL;
    GHashTable *hints = NULL;
    bool ok = false;

    if (!cmp_folder_hdd_sync_collect_allocation_hints(
            s, s->root_path, cmp_partition_layout[index].letter, &raw_hints,
            &hint_count, &high_water, &hint_error)) {
        error_setg(errp, "Folder-HDD cannot preserve live %c: allocation: %s",
                   cmp_partition_layout[index].letter,
                   hint_error ? hint_error : "unknown error");
        goto out;
    }

    hints = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    for (size_t i = 0; i < hint_count; ++i) {
        CMPAllocationHint *hint = g_new0(CMPAllocationHint, 1);
        hint->first_cluster = raw_hints[i].first_cluster;
        hint->cluster_count = raw_hints[i].cluster_count;
        hint->directory = raw_hints[i].directory;
        g_hash_table_insert(hints, g_strdup(raw_hints[i].host_path), hint);
    }
    ok = cmp_partition_build_with_hints(rebuilt, s->root_path, index, hints,
                                        high_water, errp);
out:
    if (hints) {
        g_hash_table_destroy(hints);
    }
    cmp_folder_hdd_sync_free_allocation_hints(raw_hints, hint_count);
    g_free(hint_error);
    return ok;
}

static bool cmp_ce_stage_partition_image(CMPFolderPartition *partition,
                                         const char *target,
                                         char **temp_path,
                                         char **error_text)
{
    char *temp = g_strdup_printf("%s.cmp-new-%08x", target, g_random_int());
    FILE *fp = g_fopen(temp, "w+b");
    if (!fp) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot create staged C/E image '%s': %s",
                temp, g_strerror(errno));
        }
        g_free(temp);
        return false;
    }
    const bool ok = cmp_ce_image_write_generated(fp, temp, partition,
                                                  error_text);
    fclose(fp);
    if (!ok) {
        (void)g_remove(temp);
        g_free(temp);
        return false;
    }
    *temp_path = temp;
    return true;
}

static bool cmp_ce_replace_partition_image_locked(BDRVCMPFolderHDDState *s,
                                                   size_t index,
                                                   const char *temp,
                                                   char **error_text)
{
    char *backup = g_strdup_printf("%s.cmp-old", s->ce_image_paths[index]);
    FILE *reopened = NULL;
    bool old_moved = false;
    bool ok = false;

    if (s->ce_image_fps[index]) {
        fclose(s->ce_image_fps[index]);
        s->ce_image_fps[index] = NULL;
    }
    (void)g_remove(backup);
    if (g_rename(s->ce_image_paths[index], backup) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot stage old %c.img for replacement: %s",
                cmp_partition_layout[index].letter, g_strerror(errno));
        }
        goto reopen;
    }
    old_moved = true;
    if (g_rename(temp, s->ce_image_paths[index]) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot install rebuilt %c.img: %s",
                cmp_partition_layout[index].letter, g_strerror(errno));
        }
        (void)g_rename(backup, s->ce_image_paths[index]);
        old_moved = false;
        goto reopen;
    }
    reopened = g_fopen(s->ce_image_paths[index], "r+b");
    if (!reopened || !cmp_ce_image_header_valid(reopened, index)) {
        if (reopened) {
            fclose(reopened);
            reopened = NULL;
        }
        (void)g_remove(s->ce_image_paths[index]);
        if (old_moved) {
            (void)g_rename(backup, s->ce_image_paths[index]);
            old_moved = false;
        }
        if (error_text && !*error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD rebuilt %c.img could not be reopened safely.",
                cmp_partition_layout[index].letter);
        }
        goto reopen;
    }
    s->ce_image_fps[index] = reopened;
    reopened = NULL;
    s->ce_image_dirty[index] = false;
    (void)g_remove(backup);
    old_moved = false;
    ok = true;
    goto out;

reopen:
    if (!s->ce_image_fps[index]) {
        s->ce_image_fps[index] = g_fopen(s->ce_image_paths[index], "r+b");
    }
out:
    if (reopened) {
        fclose(reopened);
    }
    g_free(backup);
    return ok;
}

static bool cmp_ce_images_import_host_locked(BDRVCMPFolderHDDState *s,
                                             char **status_text)
{
    CMPFolderPartition rebuilt[2] = { 0 };
    char *staged[2] = { NULL, NULL };
    Error *local_err = NULL;
    char *error_text = NULL;
    bool ok = false;

    if (status_text) {
        *status_text = NULL;
    }
    for (size_t i = 0; i < 2; ++i) {
        if (!cmp_ce_build_host_partition_from_live_image(s, i, &rebuilt[i],
                                                         &local_err)) {
            error_text = g_strdup_printf(
                "Folder-HDD could not import host %c: into its image: %s",
                cmp_partition_layout[i].letter,
                local_err ? error_get_pretty(local_err) : "unknown error");
            goto out;
        }
        error_free(local_err);
        local_err = NULL;
        if (!cmp_ce_stage_partition_image(&rebuilt[i], s->ce_image_paths[i],
                                          &staged[i], &error_text)) {
            goto out;
        }
    }
    for (size_t i = 0; i < 2; ++i) {
        if (!cmp_ce_replace_partition_image_locked(s, i, staged[i],
                                                   &error_text)) {
            goto out;
        }
        g_clear_pointer(&staged[i], g_free);
    }
    s->rescan_generation++;
    s->rescan_count++;
    if (status_text) {
        *status_text = g_strdup_printf(
            "Folder-HDD imported the host C/E mirror into C.img/E.img while preserving existing FATX cluster assignments where possible (generation %" PRIu64 ").",
            s->rescan_generation);
    }
    ok = true;
out:
    error_free(local_err);
    for (size_t i = 0; i < 2; ++i) {
        cmp_partition_cleanup(&rebuilt[i]);
        if (staged[i]) {
            (void)g_remove(staged[i]);
            g_free(staged[i]);
        }
    }
    if (!ok && status_text) {
        g_free(*status_text);
        *status_text = error_text ? error_text : g_strdup(
            "Folder-HDD host C/E image import failed.");
        error_text = NULL;
    }
    g_free(error_text);
    return ok;
}


static int cmp_disk_read(BDRVCMPFolderHDDState *s, uint64_t offset,
                         uint8_t *buf, size_t bytes, char **error_text)
{
    int ret = 0;
    memset(buf, 0, bytes);

    /* C: and E: are stable sparse FATX images. The loose folders are mirrors,
     * never guest-sector backing, so normal Xbox reads cannot race host edits. */
    for (size_t i = 0; i < 2; ++i) {
        const uint64_t start = cmp_partition_layout[i].offset;
        const uint64_t end = start + cmp_partition_layout[i].size;
        const uint64_t read_start = MAX(offset, start);
        const uint64_t read_end = MIN(offset + bytes, end);
        if (read_start < read_end) {
            ret = cmp_ce_image_read(s, i, read_start - start,
                                    buf + (read_start - offset),
                                    (size_t)(read_end - read_start));
            if (ret < 0) {
                if (error_text && !*error_text) {
                    *error_text = g_strdup_printf(
                        "Folder-HDD could not read %c.img at partition offset 0x%" PRIx64 ": %s",
                        cmp_partition_layout[i].letter, read_start - start,
                        g_strerror(-ret));
                }
                return ret;
            }
        }
    }

    const uint64_t read_start = MAX(offset, CMP_CACHE_DISK_START);
    const uint64_t read_end = MIN(offset + bytes, CMP_CACHE_DISK_END);
    if (read_start < read_end) {
        ret = cmp_cache_read(s, read_start, buf + (read_start - offset),
                             (size_t)(read_end - read_start));
    }
    return ret;
}


static CMPOverlayPage *cmp_overlay_get_page(BDRVCMPFolderHDDState *s,
                                             uint64_t page_index, bool create)
{
    CMPOverlayPage *page;

    page = g_hash_table_lookup(s->overlay_pages, &page_index);
    if (!page && create) {
        uint64_t *key = g_new(uint64_t, 1);
        *key = page_index;
        page = g_new0(CMPOverlayPage, 1);
        g_hash_table_insert(s->overlay_pages, key, page);
    }
    return page;
}

static int cmp_overlay_write(BDRVCMPFolderHDDState *s, uint64_t offset,
                             const uint8_t *buf, size_t bytes)
{
    g_mutex_lock(&s->overlay_lock);
    while (bytes) {
        uint64_t sector = offset / CMP_SECTOR_SIZE;
        uint64_t page_index = sector / CMP_OVERLAY_SECTORS_PER_PAGE;
        uint32_t slot = sector % CMP_OVERLAY_SECTORS_PER_PAGE;
        CMPOverlayPage *page = cmp_overlay_get_page(s, page_index, true);
        uint8_t bit = (uint8_t)(1u << slot);

        if (!(page->valid_mask & bit)) {
            s->overlay_written_sectors++;
        }
        memcpy(page->data + (size_t)slot * CMP_SECTOR_SIZE, buf,
               CMP_SECTOR_SIZE);
        page->valid_mask |= bit;
        offset += CMP_SECTOR_SIZE;
        buf += CMP_SECTOR_SIZE;
        bytes -= CMP_SECTOR_SIZE;
    }
    g_mutex_unlock(&s->overlay_lock);
    return 0;
}

static int cmp_effective_disk_read(BDRVCMPFolderHDDState *s, uint64_t offset,
                                   uint8_t *buf, size_t bytes,
                                   char **error_text)
{
    const size_t sector_count = bytes / CMP_SECTOR_SIZE;
    size_t i = 0;
    int ret = 0;

    if (!QEMU_IS_ALIGNED(offset, CMP_SECTOR_SIZE) ||
        !QEMU_IS_ALIGNED(bytes, CMP_SECTOR_SIZE)) {
        if (error_text && !*error_text) {
            *error_text = g_strdup("Folder-HDD effective read is not sector aligned.");
        }
        return -EINVAL;
    }

    /* Overlay and base are stable here because both public callers already own
     * io_lock. Walk contiguous covered/uncovered runs instead of allocating a
     * per-read bitmap. Complete overlay sectors never touch stale host backing. */
    while (i < sector_count && ret == 0) {
        size_t first = i;
        bool covered;

        g_mutex_lock(&s->overlay_lock);
        {
            const uint64_t sector = offset / CMP_SECTOR_SIZE + i;
            const uint64_t page_index =
                sector / CMP_OVERLAY_SECTORS_PER_PAGE;
            const uint32_t slot = sector % CMP_OVERLAY_SECTORS_PER_PAGE;
            CMPOverlayPage *page =
                cmp_overlay_get_page(s, page_index, false);
            covered = page && (page->valid_mask & (1u << slot));
        }

        while (i < sector_count) {
            const uint64_t sector = offset / CMP_SECTOR_SIZE + i;
            const uint64_t page_index =
                sector / CMP_OVERLAY_SECTORS_PER_PAGE;
            const uint32_t slot = sector % CMP_OVERLAY_SECTORS_PER_PAGE;
            CMPOverlayPage *page =
                cmp_overlay_get_page(s, page_index, false);
            const bool this_covered =
                page && (page->valid_mask & (1u << slot));
            if (this_covered != covered) {
                break;
            }
            if (covered) {
                memcpy(buf + i * CMP_SECTOR_SIZE,
                       page->data + (size_t)slot * CMP_SECTOR_SIZE,
                       CMP_SECTOR_SIZE);
            }
            ++i;
        }
        g_mutex_unlock(&s->overlay_lock);

        if (!covered) {
            ret = cmp_disk_read(s, offset + first * CMP_SECTOR_SIZE,
                                buf + first * CMP_SECTOR_SIZE,
                                (i - first) * CMP_SECTOR_SIZE, error_text);
        }
    }
    return ret;
}

static int cmp_disk_write(BDRVCMPFolderHDDState *s, uint64_t offset,
                          const uint8_t *buf, size_t bytes,
                          bool *ce_image_written,
                          bool *session_overlay_written)
{
    const uint64_t end = offset + bytes;
    uint64_t pos = offset;
    const uint8_t *src = buf;

    if (ce_image_written) {
        *ce_image_written = false;
    }
    if (session_overlay_written) {
        *session_overlay_written = false;
    }

    while (pos < end) {
        bool handled = false;

        for (size_t i = 0; i < 2; ++i) {
            const uint64_t part_start = cmp_partition_layout[i].offset;
            const uint64_t part_end = part_start + cmp_partition_layout[i].size;
            if (pos >= part_start && pos < part_end) {
                const size_t chunk = (size_t)MIN(end - pos, part_end - pos);
                const int ret = cmp_ce_image_write(s, i, pos - part_start,
                                                   src, chunk);
                if (ret < 0) {
                    return ret;
                }
                if (ce_image_written) {
                    *ce_image_written = true;
                }
                pos += chunk;
                src += chunk;
                handled = true;
                break;
            }
        }
        if (handled) {
            continue;
        }

        if (pos >= CMP_CACHE_DISK_START && pos < CMP_CACHE_DISK_END) {
            const size_t chunk = (size_t)MIN(end - pos,
                                             CMP_CACHE_DISK_END - pos);
            const int ret = cmp_cache_write(s, pos, src, chunk);
            if (ret < 0) {
                return ret;
            }
            pos += chunk;
            src += chunk;
            continue;
        }

        uint64_t next_boundary = end;
        if (pos < CMP_CACHE_DISK_START) {
            next_boundary = MIN(next_boundary, CMP_CACHE_DISK_START);
        }
        if (pos < cmp_partition_layout[0].offset) {
            next_boundary = MIN(next_boundary, cmp_partition_layout[0].offset);
        }
        const size_t chunk = (size_t)(next_boundary - pos);
        if (!chunk || cmp_overlay_write(s, pos, src, chunk) < 0) {
            return -EIO;
        }
        if (session_overlay_written) {
            *session_overlay_written = true;
        }
        pos += chunk;
        src += chunk;
    }
    return 0;
}

static void cmp_overlay_cleanup(BDRVCMPFolderHDDState *s)
{
    if (s->overlay_pages) {
        g_hash_table_destroy(s->overlay_pages);
        s->overlay_pages = NULL;
    }
    if (s->overlay_lock_initialized) {
        g_mutex_clear(&s->overlay_lock);
        s->overlay_lock_initialized = false;
    }
    s->overlay_written_sectors = 0;
    s->overlay_dirty = false;
}


static bool cmp_writeback_pending_locked(BDRVCMPFolderHDDState *s,
                                         char **status_text)
{
    char *sync_status = NULL;
    char *image_status = NULL;
    char *state_error = NULL;
    size_t host_additions_preserved = 0;

    if (status_text) {
        *status_text = NULL;
    }
    if (!s->ce_mirror_dirty && !s->ce_host_import_pending) {
        return true;
    }

    /* If a previous host-addition merge failed after guest data was already
     * exported, do not run guest->host again: the host contains the good guest
     * data and the image needs only the pending host->image convergence step. */
    if (s->ce_host_import_pending && !s->ce_mirror_dirty) {
        if (!cmp_ce_images_import_host_locked(s, &image_status)) {
            s->ce_sync_blocked = true;
            cmp_set_last_sync_error_locked(
                s, image_status ? image_status
                                : "Folder-HDD pending host C/E image import failed.");
            if (status_text) {
                *status_text = image_status;
                image_status = NULL;
            }
            g_free(image_status);
            return false;
        }
        s->ce_host_import_pending = false;
        if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path,
                                                &state_error)) {
            s->ce_sync_blocked = true;
            cmp_set_last_sync_error_locked(
                s, state_error ? state_error
                               : "Folder-HDD could not persist converged C/E state.");
            if (status_text) {
                *status_text = state_error;
                state_error = NULL;
            }
            g_free(image_status);
            g_free(state_error);
            return false;
        }
        s->ce_sync_blocked = false;
        cmp_set_last_sync_error_locked(s, NULL);
        if (status_text) {
            *status_text = image_status;
            image_status = NULL;
        }
        g_free(image_status);
        g_free(state_error);
        return true;
    }

    if (!cmp_ce_images_flush_locked(s, &sync_status)) {
        s->writeback_failures++;
        cmp_set_last_sync_error_locked(
            s, sync_status ? sync_status : "Folder-HDD C/E image flush failed.");
        if (status_text) {
            *status_text = sync_status;
            sync_status = NULL;
        }
        g_free(sync_status);
        return false;
    }

    if (!cmp_folder_hdd_sync_guest_to_host_ex(
            s, s->root_path, CMP_DISK_SIZE, &host_additions_preserved,
            &sync_status)) {
        s->writeback_failures++;
        cmp_set_last_sync_error_locked(
            s, sync_status ? sync_status : "Folder-HDD host write-back failed.");
        if (status_text) {
            *status_text = sync_status;
            sync_status = NULL;
        }
        g_free(sync_status);
        return false;
    }

    /* Guest changes are now present in the loose host mirror. If the PC added
     * unrelated paths while the guest was writing, fold those additions back
     * into C.img/E.img before declaring both representations converged. */
    s->ce_mirror_dirty = false;
    s->writeback_count++;
    if (host_additions_preserved > 0) {
        s->ce_host_import_pending = true;
        if (!cmp_ce_images_import_host_locked(s, &image_status)) {
            s->ce_sync_blocked = true;
            cmp_set_last_sync_error_locked(
                s, image_status ? image_status
                                : "Folder-HDD could not merge preserved host additions into C/E images.");
            if (status_text) {
                *status_text = g_strdup_printf(
                    "%s Host additions were preserved, but image convergence failed: %s",
                    sync_status ? sync_status :
                                  "Folder-HDD host write-back complete.",
                    image_status ? image_status : "unknown error");
            }
            g_free(sync_status);
            g_free(image_status);
            return false;
        }
        s->ce_host_import_pending = false;
    }

    if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path, &state_error)) {
        s->ce_sync_blocked = true;
        cmp_set_last_sync_error_locked(
            s, state_error ? state_error
                           : "Folder-HDD could not persist converged C/E state.");
        if (status_text) {
            *status_text = g_strdup_printf(
                "%s C/E data converged, but sync-state persistence failed: %s",
                sync_status ? sync_status : "Folder-HDD host write-back complete.",
                state_error ? state_error : "unknown error");
        }
        g_free(sync_status);
        g_free(image_status);
        g_free(state_error);
        return false;
    }

    s->ce_sync_blocked = false;
    cmp_set_last_sync_error_locked(s, NULL);
    if (status_text) {
        if (image_status) {
            *status_text = g_strdup_printf("%s %s",
                sync_status ? sync_status : "Folder-HDD host write-back complete.",
                image_status);
        } else {
            *status_text = g_strdup(sync_status ? sync_status
                                                : "Folder-HDD C/E images and host mirror are synchronized.");
        }
    }
    g_free(sync_status);
    g_free(image_status);
    g_free(state_error);
    return true;
}

static void cmp_auto_writeback_cancel_locked(BDRVCMPFolderHDDState *s)
{
    if (!s->auto_writeback_lock_initialized) {
        return;
    }
    g_mutex_lock(&s->auto_writeback_lock);
    s->auto_writeback_deadline_us = 0;
    if (s->auto_writeback_cond_initialized) {
        g_cond_signal(&s->auto_writeback_cond);
    }
    g_mutex_unlock(&s->auto_writeback_lock);
}

static void cmp_auto_writeback_schedule_locked(BDRVCMPFolderHDDState *s)
{
    if (!s->auto_writeback_lock_initialized) {
        return;
    }
    g_mutex_lock(&s->auto_writeback_lock);
    if (!s->auto_writeback_stop) {
        s->auto_writeback_deadline_us =
            g_get_monotonic_time() + CMP_AUTO_WRITEBACK_IDLE_US;
        if (s->auto_writeback_cond_initialized) {
            g_cond_signal(&s->auto_writeback_cond);
        }
    }
    g_mutex_unlock(&s->auto_writeback_lock);
}

static gpointer cmp_auto_writeback_worker(gpointer opaque)
{
    BDRVCMPFolderHDDState *s = opaque;

    for (;;) {
        int64_t deadline = 0;

        g_mutex_lock(&s->auto_writeback_lock);
        while (!s->auto_writeback_stop &&
               s->auto_writeback_deadline_us == 0) {
            g_cond_wait(&s->auto_writeback_cond, &s->auto_writeback_lock);
        }
        while (!s->auto_writeback_stop &&
               s->auto_writeback_deadline_us != 0) {
            deadline = s->auto_writeback_deadline_us;
            const int64_t now = g_get_monotonic_time();
            if (now >= deadline) {
                break;
            }
            g_cond_wait_until(&s->auto_writeback_cond,
                              &s->auto_writeback_lock, deadline);
        }
        const bool stop = s->auto_writeback_stop;
        g_mutex_unlock(&s->auto_writeback_lock);
        if (stop) {
            break;
        }

        /* A racing guest write may extend the idle deadline. */
        g_mutex_lock(&s->io_lock);
        g_mutex_lock(&s->auto_writeback_lock);
        const int64_t now = g_get_monotonic_time();
        if (s->auto_writeback_stop ||
            s->auto_writeback_deadline_us == 0 ||
            now < s->auto_writeback_deadline_us) {
            g_mutex_unlock(&s->auto_writeback_lock);
            g_mutex_unlock(&s->io_lock);
            continue;
        }
        s->auto_writeback_deadline_us = 0;
        g_mutex_unlock(&s->auto_writeback_lock);

        if (s->ce_mirror_dirty || s->ce_host_import_pending) {
            char *status = NULL;
            if (cmp_writeback_pending_locked(s, &status)) {
                s->auto_writeback_count++;
            } else {
                s->auto_writeback_failures++;
                warn_report("Folder-HDD idle host write-back failed: %s",
                            status ? status : "unknown error");
            }
            g_free(status);
        }
        g_mutex_unlock(&s->io_lock);
    }
    return NULL;
}

static bool cmp_auto_writeback_start(BDRVCMPFolderHDDState *s, Error **errp)
{
    g_mutex_init(&s->auto_writeback_lock);
    s->auto_writeback_lock_initialized = true;
    g_cond_init(&s->auto_writeback_cond);
    s->auto_writeback_cond_initialized = true;
    s->auto_writeback_stop = false;
    s->auto_writeback_deadline_us = 0;
    s->auto_writeback_thread =
        g_thread_try_new("folder-hdd-writeback", cmp_auto_writeback_worker,
                         s, NULL);
    if (!s->auto_writeback_thread) {
        error_setg(errp, "Folder-HDD: cannot start idle write-back worker");
        return false;
    }
    return true;
}

static void cmp_auto_writeback_stop(BDRVCMPFolderHDDState *s)
{
    if (!s->auto_writeback_lock_initialized) {
        return;
    }
    g_mutex_lock(&s->auto_writeback_lock);
    s->auto_writeback_stop = true;
    s->auto_writeback_deadline_us = 0;
    if (s->auto_writeback_cond_initialized) {
        g_cond_signal(&s->auto_writeback_cond);
    }
    g_mutex_unlock(&s->auto_writeback_lock);
    if (s->auto_writeback_thread) {
        g_thread_join(s->auto_writeback_thread);
        s->auto_writeback_thread = NULL;
    }
}

static void cmp_auto_writeback_cleanup(BDRVCMPFolderHDDState *s)
{
    if (s->auto_writeback_cond_initialized) {
        g_cond_clear(&s->auto_writeback_cond);
        s->auto_writeback_cond_initialized = false;
    }
    if (s->auto_writeback_lock_initialized) {
        g_mutex_clear(&s->auto_writeback_lock);
        s->auto_writeback_lock_initialized = false;
    }
}

static void cmp_folder_hdd_maybe_auto_rescan_locked(BDRVCMPFolderHDDState *s)
{
    const int64_t now = g_get_monotonic_time();
    bool changed = false;
    char *scan_error = NULL;
    char *import_status = NULL;
    char *state_error = NULL;

    if (now < s->next_auto_rescan_check_us) {
        return;
    }
    s->next_auto_rescan_check_us = now + CMP_AUTO_RESCAN_INTERVAL_US;

    /* Never import PC changes over guest image data that has not yet reached
     * the mirror, or while a previous convergence failure is latched. */
    if (s->ce_mirror_dirty || s->ce_host_import_pending ||
        s->ce_sync_blocked) {
        return;
    }
    if (!cmp_folder_hdd_sync_host_changed(s, s->root_path, &changed,
                                          &scan_error)) {
        warn_report("Folder-HDD automatic host check failed: %s",
                    scan_error ? scan_error : "unknown error");
        g_free(scan_error);
        return;
    }
    g_free(scan_error);
    if (!changed) {
        return;
    }

    if (!cmp_ce_images_import_host_locked(s, &import_status)) {
        cmp_set_last_sync_error_locked(
            s, import_status ? import_status
                             : "Folder-HDD automatic host C/E import failed.");
        warn_report("Folder-HDD automatic host C/E import failed: %s",
                    import_status ? import_status : "unknown error");
        g_free(import_status);
        return;
    }
    if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path, &state_error)) {
        s->ce_sync_blocked = true;
        cmp_set_last_sync_error_locked(
            s, state_error ? state_error
                           : "Folder-HDD could not persist automatic C/E convergence.");
        warn_report("Folder-HDD automatic C/E import completed but sync-state persistence failed: %s",
                    state_error ? state_error : "unknown error");
        g_free(import_status);
        g_free(state_error);
        return;
    }
    cmp_set_last_sync_error_locked(s, NULL);
    s->auto_rescan_count++;
    g_free(import_status);
    g_free(state_error);
}

static QemuOptsList cmp_runtime_opts = {
    .name = "fatxdir",
    .head = QTAILQ_HEAD_INITIALIZER(cmp_runtime_opts.head),
    .desc = {
        { .name = "root", .type = QEMU_OPT_STRING,
          .help = "Host mirror root containing C/E, Images/C.img + E.img, and Cache/xbox_cache.img" },
        { }
    },
};

static void cmp_folder_hdd_parse_filename(const char *filename, QDict *options,
                                          Error **errp)
{
    const char *root = NULL;
    if (!strstart(filename, "fatxdir:", &root) || !root || !root[0]) {
        error_setg(errp, "Folder-HDD URI must be fatxdir:<host-directory>");
        return;
    }
    qdict_put_str(options, "root", root);
}

static int cmp_folder_hdd_open(BlockDriverState *bs, QDict *options, int flags,
                               Error **errp)
{
    BDRVCMPFolderHDDState *s = bs->opaque;
    QemuOpts *opts;
    const char *root;
    GStatBuf st;
    int ret = -EINVAL;
    unsigned ce_created_mask = 0;
    bool have_manifest = false;
    bool host_changed = false;
    bool image_dirty = false;
    char *sync_error = NULL;
    char *reconcile_status = NULL;

    (void)flags;
    GRAPH_RDLOCK_GUARD_MAINLOOP();
    opts = qemu_opts_create(&cmp_runtime_opts, NULL, 0, &error_abort);
    if (!qemu_opts_absorb_qdict(opts, options, errp)) {
        goto out;
    }
    root = qemu_opt_get(opts, "root");
    if (!root || g_stat(root, &st) != 0 || !S_ISDIR(st.st_mode)) {
        error_setg(errp, "Folder-HDD root '%s' is not a readable directory",
                   root ? root : "");
        goto out;
    }
    s->root_path = g_strdup(root);
    g_mutex_init(&s->overlay_lock);
    s->overlay_lock_initialized = true;
    g_mutex_init(&s->io_lock);
    s->io_lock_initialized = true;
    s->overlay_pages = g_hash_table_new_full(g_int64_hash, g_int64_equal,
                                             g_free, g_free);

    char *cache_error = NULL;
    if (!cmp_cache_prepare(root, &s->cache_fp, &s->cache_path, &cache_error)) {
        error_setg(errp, "Folder-HDD: %s",
                   cache_error ? cache_error : "cannot initialize cache image");
        g_free(cache_error);
        goto out;
    }
    g_free(cache_error);

    char *ce_error = NULL;
    if (!cmp_ce_images_prepare(s, root, &ce_created_mask, &ce_error)) {
        error_setg(errp, "Folder-HDD: %s",
                   ce_error ? ce_error : "cannot initialize C/E images");
        g_free(ce_error);
        goto out;
    }
    g_free(ce_error);

    /* C/E guest I/O is served directly by C.img/E.img. X/Y/Z remains owned
     * by the existing cache image. No synthesized partition tree stays live. */

    bs->total_sectors = CMP_DISK_SIZE / BDRV_SECTOR_SIZE;
    s->rescan_generation = 1;
    s->next_auto_rescan_check_us =
        g_get_monotonic_time() + CMP_AUTO_RESCAN_INTERVAL_US;

    if (!cmp_folder_hdd_sync_init(s, s->root_path, &sync_error)) {
        error_setg(errp, "Folder-HDD: cannot initialize host mirror baseline: %s",
                   sync_error ? sync_error : "unknown error");
        g_free(sync_error);
        sync_error = NULL;
        goto out;
    }
    g_free(sync_error);
    sync_error = NULL;

    if (!cmp_folder_hdd_sync_persistent_state(
            s->root_path, &have_manifest, &host_changed, &image_dirty,
            &sync_error)) {
        error_setg(errp, "Folder-HDD: cannot inspect persistent C/E sync state: %s",
                   sync_error ? sync_error : "unknown error");
        g_free(sync_error);
        sync_error = NULL;
        goto out;
    }
    g_free(sync_error);
    sync_error = NULL;

    if (!have_manifest) {
        if (ce_created_mask != 3u) {
            error_setg(errp,
                       "Folder-HDD found a pre-existing or partially recovered C.img/E.img pair without a C/E sync manifest. To avoid overwriting unknown image or host changes, preserve the Images folder and reconcile it manually before retrying.");
            goto out;
        }
        /* First image-backed mount: both images were synthesized from the
         * current loose mirror, so both sides are already converged. */
        if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path, &sync_error)) {
            error_setg(errp, "Folder-HDD: cannot record initial C/E sync state: %s",
                       sync_error ? sync_error : "unknown error");
            g_free(sync_error);
            sync_error = NULL;
            goto out;
        }
        g_free(sync_error);
        sync_error = NULL;
    } else if (image_dirty) {
        if (host_changed) {
            error_setg(errp,
                       "Folder-HDD C/E recovery conflict: C.img/E.img contain Xbox changes that were not fully mirrored before the previous shutdown, and the loose C/E folders also changed afterward. No side was overwritten. Restore one side or use a conflict-recovery build before launching.");
            goto out;
        }
        /* The mirror still matches the last converged manifest, so the image is
         * the only changed side. Finish that interrupted Xbox->PC export now. */
        s->ce_mirror_dirty = true;
        if (!cmp_writeback_pending_locked(s, &reconcile_status)) {
            error_setg(errp,
                       "Folder-HDD could not recover pending Xbox C/E image changes: %s",
                       reconcile_status ? reconcile_status : "unknown error");
            g_free(reconcile_status);
            reconcile_status = NULL;
            goto out;
        }
        g_free(reconcile_status);
        reconcile_status = NULL;
    } else if (host_changed) {
        /* Xemu was previously clean and only the PC mirror changed while Xemu
         * was closed. Import it into the image before any Xbox CPU can run. */
        if (!cmp_ce_images_import_host_locked(s, &reconcile_status)) {
            error_setg(errp,
                       "Folder-HDD could not import offline host C/E changes into the images: %s",
                       reconcile_status ? reconcile_status : "unknown error");
            g_free(reconcile_status);
            reconcile_status = NULL;
            goto out;
        }
        g_free(reconcile_status);
        reconcile_status = NULL;
        if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path, &sync_error)) {
            error_setg(errp,
                       "Folder-HDD imported offline host C/E changes but could not persist convergence state: %s",
                       sync_error ? sync_error : "unknown error");
            g_free(sync_error);
            sync_error = NULL;
            goto out;
        }
        g_free(sync_error);
        sync_error = NULL;
    }

    if (!cmp_auto_writeback_start(s, errp)) {
        goto out;
    }
    G_LOCK(cmp_folder_hdd_active);
    cmp_folder_hdd_active_state = s;
    G_UNLOCK(cmp_folder_hdd_active);
    ret = 0;
out:
    qemu_opts_del(opts);
    g_free(sync_error);
    g_free(reconcile_status);
    if (ret < 0) {
        cmp_auto_writeback_stop(s);
        cmp_auto_writeback_cleanup(s);
        cmp_folder_hdd_sync_close(s);
        cmp_ce_images_close(s);
        if (s->cache_fp) {
            fclose(s->cache_fp);
            s->cache_fp = NULL;
        }
        g_clear_pointer(&s->cache_path, g_free);
        cmp_overlay_cleanup(s);
        g_clear_pointer(&s->last_sync_error, g_free);
        if (s->io_lock_initialized) {
            g_mutex_clear(&s->io_lock);
            s->io_lock_initialized = false;
        }
        g_clear_pointer(&s->root_path, g_free);
    }
    return ret;
}

static void cmp_folder_hdd_close(BlockDriverState *bs)
{
    BDRVCMPFolderHDDState *s = bs->opaque;

    G_LOCK(cmp_folder_hdd_active);
    if (cmp_folder_hdd_active_state == s) {
        cmp_folder_hdd_active_state = NULL;
    }
    G_UNLOCK(cmp_folder_hdd_active);

    cmp_auto_writeback_stop(s);
    if (s->io_lock_initialized) {
        g_mutex_lock(&s->io_lock);
        if (s->ce_mirror_dirty || s->ce_host_import_pending) {
            char *writeback_status = NULL;
            if (!cmp_writeback_pending_locked(s, &writeback_status)) {
                warn_report("Folder-HDD final host/image synchronization failed: %s",
                            writeback_status ? writeback_status : "unknown error");
            }
            g_free(writeback_status);
        } else {
            char *ce_flush_error = NULL;
            if (!cmp_ce_images_flush_locked(s, &ce_flush_error)) {
                warn_report("Folder-HDD final C/E image flush failed: %s",
                            ce_flush_error ? ce_flush_error : "unknown error");
            }
            g_free(ce_flush_error);
        }
        g_mutex_unlock(&s->io_lock);
    }
    cmp_folder_hdd_sync_close(s);
    cmp_auto_writeback_cleanup(s);
    cmp_ce_images_close(s);
    if (s->cache_fp) {
        char *cache_error = NULL;
        if (s->cache_dirty && !cmp_cache_flush_file(s->cache_fp, &cache_error)) {
            warn_report("Folder-HDD final cache flush failed: %s",
                        cache_error ? cache_error : "unknown error");
        }
        g_free(cache_error);
        fclose(s->cache_fp);
        s->cache_fp = NULL;
    }
    g_clear_pointer(&s->cache_path, g_free);

    cmp_overlay_cleanup(s);
    g_clear_pointer(&s->last_sync_error, g_free);
    if (s->io_lock_initialized) {
        g_mutex_clear(&s->io_lock);
        s->io_lock_initialized = false;
    }
    g_clear_pointer(&s->root_path, g_free);
}

static int coroutine_fn GRAPH_RDLOCK
cmp_folder_hdd_co_preadv(BlockDriverState *bs, int64_t offset, int64_t bytes,
                         QEMUIOVector *qiov, BdrvRequestFlags flags)
{
    BDRVCMPFolderHDDState *s = bs->opaque;
    uint8_t *tmp;
    int ret;
    (void)flags;
    if (offset < 0 || bytes < 0 ||
        !QEMU_IS_ALIGNED(offset, BDRV_SECTOR_SIZE) ||
        !QEMU_IS_ALIGNED(bytes, BDRV_SECTOR_SIZE) ||
        (uint64_t)offset > CMP_DISK_SIZE ||
        (uint64_t)bytes > CMP_DISK_SIZE - (uint64_t)offset) {
        return -EINVAL;
    }
    if (bytes == 0) {
        return 0;
    }
    tmp = g_try_malloc(bytes);
    if (bytes && !tmp) {
        return -ENOMEM;
    }
    g_mutex_lock(&s->io_lock);
    cmp_folder_hdd_maybe_auto_rescan_locked(s);
    ret = cmp_effective_disk_read(s, offset, tmp, bytes, NULL);
    if (ret == 0) {
        qemu_iovec_from_buf(qiov, 0, tmp, bytes);
    }
    g_mutex_unlock(&s->io_lock);
    g_free(tmp);
    return ret;
}

static int coroutine_fn GRAPH_RDLOCK
cmp_folder_hdd_co_pwritev(BlockDriverState *bs, int64_t offset, int64_t bytes,
                          QEMUIOVector *qiov, BdrvRequestFlags flags)
{
    BDRVCMPFolderHDDState *s = bs->opaque;
    uint8_t *tmp;
    int ret;
    (void)flags;

    if (offset < 0 || bytes < 0 ||
        !QEMU_IS_ALIGNED(offset, BDRV_SECTOR_SIZE) ||
        !QEMU_IS_ALIGNED(bytes, BDRV_SECTOR_SIZE) ||
        (uint64_t)offset > CMP_DISK_SIZE ||
        (uint64_t)bytes > CMP_DISK_SIZE - (uint64_t)offset) {
        return -EINVAL;
    }
    if (bytes == 0) {
        return 0;
    }
    tmp = g_try_malloc(bytes);
    if (bytes && !tmp) {
        return -ENOMEM;
    }
    qemu_iovec_to_buf(qiov, 0, tmp, bytes);
    g_mutex_lock(&s->io_lock);
    cmp_folder_hdd_maybe_auto_rescan_locked(s);

    const uint64_t write_start = (uint64_t)offset;
    const uint64_t write_end = write_start + (uint64_t)bytes;
    const bool touches_ce =
        (write_start < cmp_partition_layout[0].offset + cmp_partition_layout[0].size &&
         write_end > cmp_partition_layout[0].offset) ||
        (write_start < cmp_partition_layout[1].offset + cmp_partition_layout[1].size &&
         write_end > cmp_partition_layout[1].offset);
    bool newly_marked_dirty = false;
    char *state_error = NULL;

    if (touches_ce && (s->ce_sync_blocked || s->ce_host_import_pending)) {
        cmp_set_last_sync_error_locked(
            s, "Folder-HDD C/E guest write is temporarily blocked because the image and host mirror have not converged safely.");
        ret = -EIO;
        goto write_out;
    }
    if (touches_ce && !s->ce_mirror_dirty) {
        if (!cmp_folder_hdd_sync_mark_image_dirty(s->root_path, &state_error)) {
            cmp_set_last_sync_error_locked(
                s, state_error ? state_error
                               : "Folder-HDD could not persist the C/E image dirty marker.");
            ret = -EIO;
            goto write_out;
        }
        newly_marked_dirty = true;
    }

    bool ce_image_written = false;
    bool session_overlay_written = false;
    ret = cmp_disk_write(s, offset, tmp, bytes, &ce_image_written,
                         &session_overlay_written);
    if (ce_image_written) {
        s->ce_mirror_dirty = true;
        cmp_auto_writeback_schedule_locked(s);
    } else if (newly_marked_dirty) {
        /* Nothing reached C/E after the marker was created. Restore the clean
         * cross-session state instead of leaving a false recovery conflict. */
        char *clear_error = NULL;
        if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path,
                                                &clear_error)) {
            s->ce_sync_blocked = true;
            cmp_set_last_sync_error_locked(
                s, clear_error ? clear_error
                               : "Folder-HDD could not clear an unused C/E dirty marker.");
        }
        g_free(clear_error);
    }
    if (session_overlay_written) {
        s->overlay_dirty = true;
    }

write_out:
    g_free(state_error);
    g_mutex_unlock(&s->io_lock);
    g_free(tmp);
    return ret;
}

static int coroutine_fn GRAPH_RDLOCK
cmp_folder_hdd_co_flush_to_disk(BlockDriverState *bs)
{
    BDRVCMPFolderHDDState *s = bs->opaque;
    char *status = NULL;
    int ret = 0;

    g_mutex_lock(&s->io_lock);
    cmp_auto_writeback_cancel_locked(s);
    if (s->cache_dirty) {
        char *cache_status = NULL;
        if (!cmp_cache_flush_file(s->cache_fp, &cache_status)) {
            ret = -EIO;
            status = cache_status;
            cache_status = NULL;
        } else {
            s->cache_dirty = false;
        }
        g_free(cache_status);
    }
    if (ret == 0) {
        char *ce_status = NULL;
        if (!cmp_ce_images_flush_locked(s, &ce_status)) {
            ret = -EIO;
            status = ce_status;
            ce_status = NULL;
        }
        g_free(ce_status);
    }
    if (ret == 0 && (s->ce_mirror_dirty || s->ce_host_import_pending) &&
        !cmp_writeback_pending_locked(s, &status)) {
        ret = -EIO;
    }
    if (ret < 0) {
        cmp_set_last_sync_error_locked(
            s, status ? status : "Folder-HDD disk flush failed.");
    } else {
        cmp_set_last_sync_error_locked(s, NULL);
    }
    g_mutex_unlock(&s->io_lock);

    if (ret < 0) {
        warn_report("Folder-HDD FLUSH failed: %s",
                    status ? status : "unknown error");
    }
    g_free(status);
    return ret;
}

bool cmp_folder_hdd_sync_effective_read(void *opaque, uint64_t offset,
                                        void *buffer, size_t size)
{
    BDRVCMPFolderHDDState *s = opaque;
    uint8_t *out = buffer;
    uint64_t aligned_start;
    uint64_t aligned_end;
    size_t aligned_size;
    uint8_t *tmp;
    int ret;

    if (!s || (!buffer && size != 0) || offset > CMP_DISK_SIZE ||
        size > CMP_DISK_SIZE - offset) {
        return false;
    }
    if (size == 0) {
        return true;
    }
    aligned_start = offset & ~(uint64_t)(CMP_SECTOR_SIZE - 1);
    aligned_end = (offset + size + CMP_SECTOR_SIZE - 1) &
                  ~(uint64_t)(CMP_SECTOR_SIZE - 1);
    aligned_size = (size_t)(aligned_end - aligned_start);
    tmp = g_try_malloc(aligned_size);
    if (!tmp) {
        return false;
    }

    g_private_replace(&cmp_effective_read_error_key, NULL);
    char *read_error = NULL;
    ret = cmp_effective_disk_read(s, aligned_start, tmp, aligned_size,
                                  &read_error);
    if (ret == 0) {
        memcpy(out, tmp + (offset - aligned_start), size);
    } else {
        if (!read_error) {
            read_error = g_strdup_printf(
                "Folder-HDD base read failed at disk range 0x%" PRIx64
                "..0x%" PRIx64 ": %s",
                aligned_start, aligned_end, g_strerror(-ret));
        }
        g_private_replace(&cmp_effective_read_error_key, read_error);
        read_error = NULL;
    }
    g_free(read_error);
    g_free(tmp);
    return ret == 0;
}

char *cmp_folder_hdd_sync_effective_read_error(void)
{
    const char *error = g_private_get(&cmp_effective_read_error_key);
    return error ? g_strdup(error) : NULL;
}

static const char *const cmp_strong_runtime_opts[] = { "root", NULL };

static BlockDriver bdrv_cmp_folder_hdd = {
    .format_name = "fatxdir",
    .protocol_name = "fatxdir",
    .instance_size = sizeof(BDRVCMPFolderHDDState),
    .bdrv_parse_filename = cmp_folder_hdd_parse_filename,
    .bdrv_open = cmp_folder_hdd_open,
    .bdrv_close = cmp_folder_hdd_close,
    .bdrv_co_preadv = cmp_folder_hdd_co_preadv,
    .bdrv_co_pwritev = cmp_folder_hdd_co_pwritev,
    .bdrv_co_flush_to_disk = cmp_folder_hdd_co_flush_to_disk,
    .strong_runtime_opts = cmp_strong_runtime_opts,
};

static void cmp_folder_hdd_register(void)
{
    bdrv_register(&bdrv_cmp_folder_hdd);
}
block_init(cmp_folder_hdd_register);

bool cmp_folder_hdd_is_configured(void)
{
    return true;
}

bool cmp_folder_hdd_is_active(void)
{
    bool active;

    G_LOCK(cmp_folder_hdd_active);
    active = cmp_folder_hdd_active_state != NULL;
    G_UNLOCK(cmp_folder_hdd_active);
    return active;
}

char *cmp_folder_hdd_get_last_sync_error(void)
{
    char *result = NULL;

    G_LOCK(cmp_folder_hdd_active);
    BDRVCMPFolderHDDState *s = cmp_folder_hdd_active_state;
    if (s && s->io_lock_initialized) {
        g_mutex_lock(&s->io_lock);
        result = g_strdup(s->last_sync_error);
        g_mutex_unlock(&s->io_lock);
    }
    G_UNLOCK(cmp_folder_hdd_active);
    return result;
}

bool cmp_folder_hdd_rescan_active(char **status_text)
{
    BDRVCMPFolderHDDState *s;
    char *writeback_status = NULL;
    char *scan_error = NULL;
    char *import_status = NULL;
    char *state_error = NULL;
    bool changed = false;
    bool ok = false;

    if (status_text) {
        *status_text = NULL;
    }

    /* Keep state valid across the explicit image/mirror convergence boundary. */
    G_LOCK(cmp_folder_hdd_active);
    s = cmp_folder_hdd_active_state;
    if (!s) {
        G_UNLOCK(cmp_folder_hdd_active);
        if (status_text) {
            *status_text = g_strdup("Folder-HDD is not the active Xbox HDD backend.");
        }
        return false;
    }

    g_mutex_lock(&s->io_lock);
    cmp_auto_writeback_cancel_locked(s);
    if ((s->ce_mirror_dirty || s->ce_host_import_pending) &&
        !cmp_writeback_pending_locked(s, &writeback_status)) {
        if (status_text) {
            *status_text = g_strdup_printf(
                "Folder-HDD refresh was deferred because Xbox C/E image changes could not be synchronized safely: %s",
                writeback_status ? writeback_status : "unknown error");
        }
        goto out;
    }

    if (!cmp_folder_hdd_sync_host_changed(s, s->root_path, &changed,
                                          &scan_error)) {
        if (status_text) {
            *status_text = g_strdup_printf(
                "Folder-HDD could not compare the C/E host mirror with its synchronized baseline: %s",
                scan_error ? scan_error : "unknown error");
        }
        goto out;
    }

    if (changed) {
        if (!cmp_ce_images_import_host_locked(s, &import_status)) {
            if (status_text) {
                *status_text = g_strdup_printf(
                    "Folder-HDD could not import host C/E changes into C.img/E.img: %s",
                    import_status ? import_status : "unknown error");
            }
            goto out;
        }
    }

    if (!cmp_folder_hdd_sync_mark_converged(s, s->root_path, &state_error)) {
        s->ce_sync_blocked = true;
        cmp_set_last_sync_error_locked(
            s, state_error ? state_error
                           : "Folder-HDD could not persist refreshed C/E convergence state.");
        if (status_text) {
            *status_text = g_strdup_printf(
                "Folder-HDD C/E data converged but the sync manifest could not be saved: %s",
                state_error ? state_error : "unknown error");
        }
        goto out;
    }

    s->ce_sync_blocked = false;
    cmp_set_last_sync_error_locked(s, NULL);
    if (status_text) {
        if (changed) {
            *status_text = g_strdup_printf(
                "%s C.img/E.img are now the Xbox backing store and the loose C/E folders are synchronized mirrors.",
                import_status ? import_status
                              : "Folder-HDD imported host C/E changes into the images.");
        } else if (writeback_status) {
            *status_text = g_strdup_printf(
                "%s C.img/E.img and the loose C/E mirror are synchronized.",
                writeback_status);
        } else {
            *status_text = g_strdup(
                "Folder-HDD C.img/E.img and the loose C/E mirror are already synchronized.");
        }
    }
    ok = true;

out:
    g_free(writeback_status);
    g_free(scan_error);
    g_free(import_status);
    g_free(state_error);
    g_mutex_unlock(&s->io_lock);
    G_UNLOCK(cmp_folder_hdd_active);
    return ok;
}

char *cmp_folder_hdd_make_uri(const char *root_path)
{
    return root_path && root_path[0] ? g_strdup_printf("fatxdir:%s", root_path)
                                     : NULL;
}

char *cmp_folder_hdd_get_default_root(void)
{
    char *exe_dir = NULL;
    char *root = NULL;

#if defined(__linux__)
    /* APPIMAGE points to the user-visible file, not the temporary mount. */
    const char *appimage = g_getenv("APPIMAGE");
    if (appimage && appimage[0]) {
        char *absolute_appimage = g_canonicalize_filename(appimage, NULL);
        if (absolute_appimage && absolute_appimage[0]) {
            exe_dir = g_path_get_dirname(absolute_appimage);
        }
        g_free(absolute_appimage);
    }
#endif

    if (!exe_dir) {
        /* Use the initialized executable directory on normal builds. */
        exe_dir = get_relocated_path(CONFIG_BINDIR);
    }
    if (!exe_dir || !exe_dir[0]) {
        g_free(exe_dir);
        return NULL;
    }

    root = g_build_filename(exe_dir, "XEMU-HDD", NULL);
    g_free(exe_dir);
    return root;
}

static bool cmp_folder_hdd_ensure_directory(const char *path,
                                             const char *description,
                                             char **error_text)
{
    GStatBuf st;

    if (g_stat(path, &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            return true;
        }
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD %s path '%s' exists but is not a directory.",
                description, path);
        }
        return false;
    }
    if (errno != ENOENT) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot inspect %s path '%s': %s",
                description, path, g_strerror(errno));
        }
        return false;
    }
    if (g_mkdir_with_parents(path, 0755) != 0) {
        if (error_text) {
            *error_text = g_strdup_printf(
                "Folder-HDD cannot create %s directory '%s': %s",
                description, path, g_strerror(errno));
        }
        return false;
    }
    return true;
}

bool cmp_folder_hdd_ensure_layout(const char *root_path, char **error_text)
{
    static const char *const partitions[] = { "C", "E" };

    if (error_text) {
        *error_text = NULL;
    }
    if (!root_path || !root_path[0]) {
        if (error_text) {
            *error_text = g_strdup("No Folder-HDD root directory was provided.");
        }
        return false;
    }
    if (!cmp_folder_hdd_ensure_directory(root_path, "root", error_text)) {
        return false;
    }

    for (size_t i = 0; i < G_N_ELEMENTS(partitions); ++i) {
        char *partition_path = g_build_filename(root_path, partitions[i], NULL);
        const bool ok = cmp_folder_hdd_ensure_directory(
            partition_path, partitions[i], error_text);
        g_free(partition_path);
        if (!ok) {
            return false;
        }
    }

    unsigned ce_created_mask = 0;
    if (!cmp_ce_images_prepare(NULL, root_path, &ce_created_mask, error_text)) {
        return false;
    }
    if (ce_created_mask == 3u) {
        char *state_error = NULL;
        if (!cmp_folder_hdd_sync_mark_converged(NULL, root_path,
                                                &state_error)) {
            if (error_text) {
                *error_text = state_error;
                state_error = NULL;
            }
            g_free(state_error);
            return false;
        }
        g_free(state_error);
    }

    return cmp_cache_prepare(root_path, NULL, NULL, error_text);
}

bool cmp_folder_hdd_root_is_usable(const char *root_path, char **error_text)
{
    GStatBuf st;
    if (error_text) {
        *error_text = NULL;
    }
    if (!root_path || !root_path[0]) {
        if (error_text) {
            *error_text = g_strdup("No Folder-HDD root directory is configured.");
        }
        return false;
    }
    if (g_stat(root_path, &st) != 0 || !S_ISDIR(st.st_mode)) {
        if (error_text) {
            *error_text = g_strdup_printf("Folder-HDD root '%s' does not exist or is not a directory.", root_path);
        }
        return false;
    }
    return true;
}
