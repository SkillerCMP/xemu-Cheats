#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/* Callback used by xemu's error notification hook. */
void cmp_folder_hdd_make_folders_action(void *opaque);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
/* Draw HDD source/path controls and mark restart-required settings dirty. */
void cmp_folder_hdd_draw_settings(bool *dirty);
#endif
