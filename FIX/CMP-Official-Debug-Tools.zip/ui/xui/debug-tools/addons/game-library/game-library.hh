// xemu Debug Tools - host Game Library addition.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <epoxy/gl.h>

namespace XemuGameLibrary {

struct GameEntry {
    std::string path;
    std::string display_name;
    std::string game_id;
    std::string region;
    std::string executable_identity;
    std::string cover_path;
    uint32_t title_id = 0;
    uint32_t version = 0;
    uint32_t disc_number = 0;
    uint64_t file_size = 0;
    int64_t modified_ns = 0;
    bool metadata_valid = false;
};

class GameLibraryManager {
public:
    bool is_open = false;

    void Register();
    void Tick();
    void Cleanup();

    // Home -> Games integration. These methods never touch guest memory/CPU
    // state; scanning is queued on the existing Debug Tools host worker.
    void PrepareQuickMenu();
    void OpenFullLibrary();
    void Refresh();
    size_t QuickMenuCount() const;
    bool GetQuickMenuEntry(size_t index, std::string &label) const;
    bool QuickMenuScanning() const;
    bool LaunchQuickMenuEntry(size_t index);

private:
    struct Preferences {
        std::string last_played;
        std::string last_selected;
        std::vector<std::string> extra_roots;
        std::unordered_set<std::string> favorites;
        std::unordered_map<std::string, int64_t> last_played_us;
    };

    enum class ViewMode {
        All,
        Favorites,
        Recent,
    };

    void LoadPreferences();
    void SavePreferences();
    void RequestScan();
    void OpenIfNeeded();
    void Close(bool resume_guest);
    void Draw();
    void DrawTopBar();
    void DrawSelectedGame(const std::vector<size_t> &visible);
    void DrawLibrarySettings();
    void HandleController(const std::vector<size_t> &visible);
    bool LaunchGame(const GameEntry &game);
    void LaunchSelected(const std::vector<size_t> &visible);
    void ToggleFavorite(const std::vector<size_t> &visible);
    void AddRoot(const std::string &path);
    void RemoveRoot(size_t index);
    std::vector<size_t> BuildVisibleIndices() const;
    size_t SelectedVisiblePosition(const std::vector<size_t> &visible) const;
    void MoveSelection(const std::vector<size_t> &visible, int delta);
    void SelectByPath(const std::string &path);
    void EnsureSelectedCover();
    void ReleaseCover();
    void RebuildQuickMenu();
    void ApplyScanResult(std::vector<GameEntry> &&entries,
                         const std::string &status);

    Preferences m_preferences;
    std::vector<GameEntry> m_games;
    std::vector<size_t> m_quick_menu_indices;
    std::string m_selected_path;
    std::string m_search;
    std::string m_scan_status;
    bool m_preferences_loaded = false;
    bool m_scan_requested = false;
    bool m_scan_in_flight = false;
    bool m_previous_open = false;
    bool m_resume_guest_on_close = false;
    bool m_request_focus = false;
    bool m_show_settings = false;
    ViewMode m_view_mode = ViewMode::All;

    GLuint m_cover_texture = 0;
    int m_cover_width = 0;
    int m_cover_height = 0;
    std::string m_cover_loaded_path;
};

extern GameLibraryManager game_library_manager;

} // namespace XemuGameLibrary
