#include "game-library.hh"

#include "../../binary-utils.hh"
#include "../../cheat-engine-memory.h"
#include "../../debug-tools.hh"
#include "../../debug-tools-module.hh"
#include "../cheat-db/cheat-db.hh"
#include "../../xdvdfs-disc.hh"

#include "../../../actions.hh"
#include "../../../common.hh"
#include "../../../misc.hh"
#include "../../../xemu-hud.h"
#include "../../../../xemu-notifications.h"
#include "xemu-xbe.h"

#include <glib.h>
#include <glib/gstdio.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <limits>
#include <set>
#include <sstream>
#include <system_error>
#include <utility>

namespace XemuGameLibrary {

GameLibraryManager game_library_manager;

namespace {

using XemuDebugBinaryUtils::range_inside;
using XemuDebugBinaryUtils::read_le16;
using XemuDebugBinaryUtils::read_le32;

constexpr size_t kMaxDiscImages = 8192;
constexpr size_t kMaxXbeHeaders = 4 * 1024 * 1024;
constexpr size_t kXbeSectionHeaderSize = 56;
constexpr size_t kXbeSectionDigestOffset = 36;
constexpr uint32_t kXbeMagic = 0x48454258u; // "XBEH" little-endian

std::string Lower(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return value;
}

bool ContainsCaseInsensitive(const std::string &haystack,
                             const std::string &needle)
{
    if (needle.empty()) {
        return true;
    }
    return Lower(haystack).find(Lower(needle)) != std::string::npos;
}

std::string ExecutableDirectory()
{
    char buffer[4096] = {};
    if (!xemu_cheat_get_executable_dir(buffer, sizeof(buffer))) {
        return {};
    }
    return buffer;
}

std::string LibraryDirectory()
{
    const std::string exe = ExecutableDirectory();
    if (exe.empty()) {
        return {};
    }
    gchar *path = g_build_filename(exe.c_str(), "DEBUG", "Game-Library", nullptr);
    std::string result = path ? path : "";
    g_free(path);
    return result;
}

std::string PreferencesPath()
{
    const std::string dir = LibraryDirectory();
    if (dir.empty()) {
        return {};
    }
    gchar *path = g_build_filename(dir.c_str(), "game-library.ini", nullptr);
    std::string result = path ? path : "";
    g_free(path);
    return result;
}

std::string GetKeyString(GKeyFile *key_file, const char *group,
                         const char *key)
{
    GError *error = nullptr;
    gchar *value = g_key_file_get_string(key_file, group, key, &error);
    if (error) {
        g_error_free(error);
        return {};
    }
    std::string result = value ? value : "";
    g_free(value);
    return result;
}

int GetKeyInteger(GKeyFile *key_file, const char *group, const char *key,
                  int fallback)
{
    GError *error = nullptr;
    const int value = g_key_file_get_integer(key_file, group, key, &error);
    if (error) {
        g_error_free(error);
        return fallback;
    }
    return value;
}

int64_t GetKeyInt64(GKeyFile *key_file, const char *group, const char *key,
                    int64_t fallback)
{
    const std::string text = GetKeyString(key_file, group, key);
    if (text.empty()) {
        return fallback;
    }
    char *end = nullptr;
    const gint64 value = g_ascii_strtoll(text.c_str(), &end, 10);
    return end && *end == '\0' ? (int64_t)value : fallback;
}

std::string CanonicalPath(const std::filesystem::path &path)
{
    std::error_code ec;
    std::filesystem::path absolute = std::filesystem::absolute(path, ec);
    if (ec) {
        absolute = path;
        ec.clear();
    }
    std::filesystem::path canonical =
        std::filesystem::weakly_canonical(absolute, ec);
    if (ec) {
        canonical = absolute;
    }
#if defined(_WIN32)
    // MinGW/XEMU path APIs consume UTF-8 char paths.
    return canonical.u8string();
#else
    return canonical.string();
#endif
}

std::string PathKey(const std::string &path)
{
#if defined(_WIN32)
    // Windows paths are case-insensitive. Preserve case-sensitive host semantics
    // on Linux/macOS so two distinct game images are not collapsed.
    return Lower(path);
#else
    return path;
#endif
}

std::string FormatGameId(uint32_t title_id)
{
    const unsigned char a = (unsigned char)((title_id >> 24) & 0xFFu);
    const unsigned char b = (unsigned char)((title_id >> 16) & 0xFFu);
    char buffer[24] = {};
    if (a >= 0x21 && a <= 0x7E && b >= 0x21 && b <= 0x7E) {
        std::snprintf(buffer, sizeof(buffer), "%c%c%04X", a, b,
                      title_id & 0xFFFFu);
    } else {
        std::snprintf(buffer, sizeof(buffer), "%08X", title_id);
    }
    return buffer;
}

std::string FormatRegion(uint32_t region)
{
    std::string result;
    auto append = [&](const char *name) {
        if (!result.empty()) {
            result += " + ";
        }
        result += name;
    };
    if (region & 0x00000001u) append("North America");
    if (region & 0x00000002u) append("Japan");
    if (region & 0x00000004u) append("Rest of World");
    if (region & 0x80000000u) append("Manufacturing");
    if (result.empty()) {
        char buffer[24] = {};
        std::snprintf(buffer, sizeof(buffer), "0x%08X", region);
        result = buffer;
    }
    return result;
}

std::string FormatBytes(uint64_t bytes)
{
    char buffer[64] = {};
    if (bytes >= 1024ull * 1024ull * 1024ull) {
        std::snprintf(buffer, sizeof(buffer), "%.2f GiB",
                      bytes / (1024.0 * 1024.0 * 1024.0));
    } else if (bytes >= 1024ull * 1024ull) {
        std::snprintf(buffer, sizeof(buffer), "%.2f MiB",
                      bytes / (1024.0 * 1024.0));
    } else if (bytes >= 1024ull) {
        std::snprintf(buffer, sizeof(buffer), "%.2f KiB", bytes / 1024.0);
    } else {
        std::snprintf(buffer, sizeof(buffer), "%llu B",
                      (unsigned long long)bytes);
    }
    return buffer;
}

void AppendU32(std::vector<uint8_t> &bytes, uint32_t value)
{
    bytes.push_back((uint8_t)(value & 0xFFu));
    bytes.push_back((uint8_t)((value >> 8) & 0xFFu));
    bytes.push_back((uint8_t)((value >> 16) & 0xFFu));
    bytes.push_back((uint8_t)((value >> 24) & 0xFFu));
}

std::string Sha256(const std::vector<uint8_t> &bytes)
{
    if (bytes.empty()) {
        return {};
    }
    gchar *sum = g_compute_checksum_for_data(
        G_CHECKSUM_SHA256, reinterpret_cast<const guchar *>(bytes.data()),
        bytes.size());
    if (!sum) {
        return {};
    }
    std::string result = sum;
    g_free(sum);
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return (char)std::toupper(c); });
    return result;
}

std::string ExecutableIdentity(const std::vector<uint8_t> &headers,
                               size_t cert_offset)
{
    if (headers.size() < sizeof(xbe_header) ||
        !range_inside(cert_offset, sizeof(xbe_certificate), headers.size())) {
        return {};
    }
    const uint8_t *h = headers.data();
    const uint32_t base = read_le32(h + offsetof(xbe_header, m_base));
    const uint32_t image_size = read_le32(h + offsetof(xbe_header, m_sizeof_image));
    const uint32_t entry = read_le32(h + offsetof(xbe_header, m_entry));
    const uint32_t tls = read_le32(h + offsetof(xbe_header, m_tls_addr));
    const uint32_t thunk = read_le32(h + offsetof(xbe_header, m_kernel_image_thunk_addr));
    const uint32_t imports = read_le32(h + offsetof(xbe_header, m_nonkernel_import_dir_addr));
    const uint32_t sections = read_le32(h + offsetof(xbe_header, m_sections));
    const uint32_t section_va =
        read_le32(h + offsetof(xbe_header, m_section_headers_addr));
    const uint32_t title_id = read_le32(
        headers.data() + cert_offset + offsetof(xbe_certificate, m_titleid));
    if (sections == 0 || sections > 512 || section_va < base) {
        return {};
    }
    const size_t section_offset = (size_t)(section_va - base);
    const size_t section_size = (size_t)sections * kXbeSectionHeaderSize;
    if (!range_inside(section_offset, section_size, headers.size())) {
        return {};
    }

    static constexpr char kDomain[] = "XEMU-XBE-CODE-IDENTITY-V1";
    std::vector<uint8_t> identity;
    identity.reserve(sizeof(kDomain) - 1 + 8 * 4 + sections * 36);
    identity.insert(identity.end(), kDomain, kDomain + sizeof(kDomain) - 1);
    AppendU32(identity, title_id);
    AppendU32(identity, base);
    AppendU32(identity, image_size);
    AppendU32(identity, entry);
    AppendU32(identity, tls);
    AppendU32(identity, thunk);
    AppendU32(identity, imports);
    AppendU32(identity, sections);
    for (uint32_t i = 0; i < sections; ++i) {
        const uint8_t *sh = headers.data() + section_offset +
                            (size_t)i * kXbeSectionHeaderSize;
        AppendU32(identity, read_le32(sh + 0));
        AppendU32(identity, read_le32(sh + 4));
        AppendU32(identity, read_le32(sh + 8));
        AppendU32(identity, read_le32(sh + 16));
        identity.insert(identity.end(), sh + kXbeSectionDigestOffset,
                        sh + kXbeSectionDigestOffset + 20);
    }
    return Sha256(identity);
}

bool ReadAt(std::ifstream &file, uint64_t offset, void *buffer, size_t size)
{
    if (size == 0) {
        return true;
    }
    if (offset > (uint64_t)std::numeric_limits<std::streamoff>::max()) {
        return false;
    }
    file.clear();
    file.seekg((std::streamoff)offset, std::ios::beg);
    if (!file) {
        return false;
    }
    file.read(reinterpret_cast<char *>(buffer), (std::streamsize)size);
    return file.good() || file.gcount() == (std::streamsize)size;
}

bool InspectXbeHeaders(std::ifstream &file, uint64_t xbe_offset,
                       uint32_t xbe_size, GameEntry &entry)
{
    std::array<uint8_t, sizeof(xbe_header)> first = {};
    if (xbe_size < first.size() || !ReadAt(file, xbe_offset, first.data(), first.size())) {
        return false;
    }
    if (read_le32(first.data()) != kXbeMagic) {
        return false;
    }
    const uint32_t base = read_le32(first.data() + offsetof(xbe_header, m_base));
    const uint32_t header_size =
        read_le32(first.data() + offsetof(xbe_header, m_sizeof_headers));
    const uint32_t cert_va =
        read_le32(first.data() + offsetof(xbe_header, m_certificate_addr));
    if (header_size < sizeof(xbe_header) || header_size > kMaxXbeHeaders ||
        header_size > xbe_size || cert_va < base) {
        return false;
    }
    const size_t cert_offset = (size_t)(cert_va - base);
    if (!range_inside(cert_offset, sizeof(xbe_certificate), header_size)) {
        return false;
    }

    std::vector<uint8_t> headers(header_size);
    if (!ReadAt(file, xbe_offset, headers.data(), headers.size())) {
        return false;
    }
    const uint8_t *cert = headers.data() + cert_offset;
    entry.title_id = read_le32(cert + offsetof(xbe_certificate, m_titleid));
    entry.version = read_le32(cert + offsetof(xbe_certificate, m_version));
    entry.disc_number = read_le32(cert + offsetof(xbe_certificate, m_disk_number));
    entry.region = FormatRegion(
        read_le32(cert + offsetof(xbe_certificate, m_game_region)));
    entry.game_id = FormatGameId(entry.title_id);

    std::array<gunichar2, 41> title = {};
    const size_t title_offset = offsetof(xbe_certificate, m_title_name);
    for (size_t i = 0; i < 40; ++i) {
        title[i] = (gunichar2)read_le16(cert + title_offset + i * 2);
    }
    GError *utf_error = nullptr;
    gchar *utf8 = g_utf16_to_utf8(title.data(), -1, nullptr, nullptr, &utf_error);
    if (utf8 && utf8[0]) {
        entry.display_name = utf8;
    }
    if (utf_error) {
        g_error_free(utf_error);
    }
    g_free(utf8);

    entry.executable_identity = ExecutableIdentity(headers, cert_offset);
    entry.metadata_valid = true;
    return true;
}

std::string FindCover(const std::filesystem::path &image_path)
{
    std::error_code ec;
    const std::filesystem::path dir = image_path.parent_path();
    if (!std::filesystem::is_directory(dir, ec)) {
        return {};
    }
    const std::string stem_lower = Lower(image_path.stem().u8string());
    for (const auto &item : std::filesystem::directory_iterator(
             dir, std::filesystem::directory_options::skip_permission_denied, ec)) {
        if (ec) {
            break;
        }
        if (!item.is_regular_file(ec)) {
            ec.clear();
            continue;
        }
        const std::filesystem::path p = item.path();
        const std::string ext = Lower(p.extension().u8string());
        if (ext != ".png" && ext != ".jpg" && ext != ".jpeg" &&
            ext != ".bmp" && ext != ".tga") {
            continue;
        }
        const std::string name = Lower(p.stem().u8string());
        if (name == "cover" || name == "folder" || name == stem_lower) {
            return CanonicalPath(p);
        }
    }
    return {};
}

GameEntry InspectDiscImage(const std::filesystem::path &path)
{
    GameEntry entry;
    entry.path = CanonicalPath(path);
    entry.display_name = path.stem().u8string();
    entry.cover_path = FindCover(path);

    std::error_code ec;
    entry.file_size = std::filesystem::file_size(path, ec);
    if (ec || entry.file_size == 0) {
        return entry;
    }
    const auto write_time = std::filesystem::last_write_time(path, ec);
    if (!ec) {
        entry.modified_ns = (int64_t)write_time.time_since_epoch().count();
    }

    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return entry;
    }
    XemuXdvdfs::Disc disc;
    std::string parse_error;
    XemuXdvdfs::Reader reader = [&](uint64_t offset, void *buffer, size_t size) {
        return ReadAt(file, offset, buffer, size);
    };
    if (!XemuXdvdfs::Parse(reader, entry.file_size, disc, parse_error)) {
        return entry;
    }
    const XemuXdvdfs::Entry *default_xbe =
        XemuXdvdfs::FindRootFile(disc, "default.xbe");
    if (!default_xbe) {
        return entry;
    }
    InspectXbeHeaders(file, default_xbe->disc_offset, default_xbe->size, entry);
    return entry;
}

struct ScanJob {
    std::vector<std::string> roots;
    std::vector<GameEntry> entries;
    std::string status;
};

void ScanLibrary(ScanJob &job)
{
    std::set<std::string> seen_paths;
    size_t inaccessible_roots = 0;
    for (const std::string &root_text : job.roots) {
        if (root_text.empty()) {
            continue;
        }
        std::filesystem::path root(root_text);
        std::error_code ec;
        if (!std::filesystem::is_directory(root, ec)) {
            ++inaccessible_roots;
            continue;
        }
        std::filesystem::recursive_directory_iterator it(
            root, std::filesystem::directory_options::skip_permission_denied, ec);
        const std::filesystem::recursive_directory_iterator end;
        while (it != end && job.entries.size() < kMaxDiscImages) {
            if (ec) {
                ec.clear();
                it.increment(ec);
                continue;
            }
            const auto &dir_entry = *it;
            if (dir_entry.is_regular_file(ec)) {
                const std::filesystem::path p = dir_entry.path();
                const std::string ext = Lower(p.extension().u8string());
                if (ext == ".iso" || ext == ".xiso") {
                    const std::string canonical = CanonicalPath(p);
                    if (seen_paths.insert(PathKey(canonical)).second) {
                        job.entries.push_back(InspectDiscImage(p));
                    }
                }
            }
            ec.clear();
            it.increment(ec);
        }
        if (job.entries.size() >= kMaxDiscImages) {
            break;
        }
    }

    std::stable_sort(job.entries.begin(), job.entries.end(),
                     [](const GameEntry &a, const GameEntry &b) {
        const std::string an = Lower(a.display_name);
        const std::string bn = Lower(b.display_name);
        if (an != bn) {
            return an < bn;
        }
        return Lower(a.path) < Lower(b.path);
    });

    std::ostringstream status;
    status << "Found " << job.entries.size() << " disc image";
    if (job.entries.size() != 1) {
        status << 's';
    }
    status << '.';
    if (inaccessible_roots) {
        status << ' ' << inaccessible_roots << " library root";
        if (inaccessible_roots != 1) {
            status << 's';
        }
        status << " unavailable.";
    }
    if (job.entries.size() >= kMaxDiscImages) {
        status << " Scan limit reached.";
    }
    job.status = status.str();
}

bool SamePath(const std::string &a, const std::string &b)
{
#if defined(_WIN32)
    return Lower(a) == Lower(b);
#else
    return a == b;
#endif
}

} // namespace

void GameLibraryManager::LoadPreferences()
{
    if (m_preferences_loaded) {
        return;
    }
    m_preferences_loaded = true;
    const std::string path = PreferencesPath();
    if (path.empty()) {
        return;
    }

    GKeyFile *key_file = g_key_file_new();
    GError *error = nullptr;
    if (!g_key_file_load_from_file(key_file, path.c_str(), G_KEY_FILE_NONE,
                                   &error)) {
        if (error) {
            g_error_free(error);
        }
        g_key_file_unref(key_file);
        return;
    }

    m_preferences.last_played =
        GetKeyString(key_file, "History", "LastPlayed");
    if (m_preferences.last_played.empty()) {
        // One-time migration from the removed startup-dashboard experiment.
        m_preferences.last_played =
            GetKeyString(key_file, "Startup", "LastPlayed");
    }
    m_preferences.last_selected =
        GetKeyString(key_file, "UI", "LastSelected");

    const int root_count = std::clamp(
        GetKeyInteger(key_file, "Roots", "Count", 0), 0, 128);
    for (int i = 0; i < root_count; ++i) {
        const std::string key = "Path" + std::to_string(i);
        const std::string value = GetKeyString(key_file, "Roots", key.c_str());
        if (!value.empty()) {
            m_preferences.extra_roots.push_back(value);
        }
    }

    const int favorite_count = std::clamp(
        GetKeyInteger(key_file, "Favorites", "Count", 0), 0, 8192);
    for (int i = 0; i < favorite_count; ++i) {
        const std::string key = "Path" + std::to_string(i);
        const std::string value =
            GetKeyString(key_file, "Favorites", key.c_str());
        if (!value.empty()) {
            m_preferences.favorites.insert(value);
        }
    }

    const int history_count = std::clamp(
        GetKeyInteger(key_file, "History", "Count", 0), 0, 8192);
    for (int i = 0; i < history_count; ++i) {
        const std::string path_key = "Path" + std::to_string(i);
        const std::string time_key = "Time" + std::to_string(i);
        const std::string value =
            GetKeyString(key_file, "History", path_key.c_str());
        const int64_t timestamp =
            GetKeyInt64(key_file, "History", time_key.c_str(), 0);
        if (!value.empty() && timestamp > 0) {
            m_preferences.last_played_us[value] = timestamp;
        }
    }

    g_key_file_unref(key_file);
}

void GameLibraryManager::SavePreferences()
{
    if (!m_preferences_loaded) {
        return;
    }
    const std::string dir = LibraryDirectory();
    const std::string path = PreferencesPath();
    if (dir.empty() || path.empty() || g_mkdir_with_parents(dir.c_str(), 0755) != 0) {
        return;
    }

    GKeyFile *key_file = g_key_file_new();
    g_key_file_set_string(key_file, "History", "LastPlayed",
                          m_preferences.last_played.c_str());
    g_key_file_set_string(key_file, "UI", "LastSelected",
                          m_selected_path.c_str());

    g_key_file_set_integer(key_file, "Roots", "Count",
                           (gint)m_preferences.extra_roots.size());
    for (size_t i = 0; i < m_preferences.extra_roots.size(); ++i) {
        const std::string key = "Path" + std::to_string(i);
        g_key_file_set_string(key_file, "Roots", key.c_str(),
                              m_preferences.extra_roots[i].c_str());
    }

    std::vector<std::string> favorites(m_preferences.favorites.begin(),
                                       m_preferences.favorites.end());
    std::sort(favorites.begin(), favorites.end());
    g_key_file_set_integer(key_file, "Favorites", "Count",
                           (gint)favorites.size());
    for (size_t i = 0; i < favorites.size(); ++i) {
        const std::string key = "Path" + std::to_string(i);
        g_key_file_set_string(key_file, "Favorites", key.c_str(),
                              favorites[i].c_str());
    }

    std::vector<std::pair<std::string, int64_t>> history(
        m_preferences.last_played_us.begin(),
        m_preferences.last_played_us.end());
    std::sort(history.begin(), history.end(), [](const auto &a, const auto &b) {
        return a.second > b.second;
    });
    if (history.size() > 512) {
        history.resize(512);
    }
    g_key_file_set_integer(key_file, "History", "Count", (gint)history.size());
    for (size_t i = 0; i < history.size(); ++i) {
        const std::string path_key = "Path" + std::to_string(i);
        const std::string time_key = "Time" + std::to_string(i);
        g_key_file_set_string(key_file, "History", path_key.c_str(),
                              history[i].first.c_str());
        g_key_file_set_string(key_file, "History", time_key.c_str(),
                              std::to_string(history[i].second).c_str());
    }

    gsize length = 0;
    GError *error = nullptr;
    gchar *data = g_key_file_to_data(key_file, &length, &error);
    if (data && !error) {
        const std::string temp = path + ".tmp";
        if (g_file_set_contents(temp.c_str(), data, (gssize)length, nullptr)) {
            if (g_rename(temp.c_str(), path.c_str()) != 0) {
                g_remove(path.c_str());
                g_rename(temp.c_str(), path.c_str());
            }
        }
    }
    if (error) {
        g_error_free(error);
    }
    g_free(data);
    g_key_file_unref(key_file);
}

void GameLibraryManager::Register()
{
    // Do not alter XEMU startup/auto-boot. The library is opened explicitly
    // from Home -> Games or from the Debug Tools overlay menu.
    is_open = false;
    m_scan_requested = false;

    debug_tools_register_overlay_menu_item(50, "Game Library", &is_open);
    debug_tools_register_tick(50, []() { game_library_manager.Tick(); });
    debug_tools_register_cleanup(50, []() { game_library_manager.Cleanup(); });
}

void GameLibraryManager::RequestScan()
{
    m_scan_requested = true;
}

void GameLibraryManager::PrepareQuickMenu()
{
    LoadPreferences();
    if (m_selected_path.empty()) {
        m_selected_path = !m_preferences.last_selected.empty()
                              ? m_preferences.last_selected
                              : m_preferences.last_played;
    }
    if (m_games.empty() && !m_scan_in_flight) {
        RequestScan();
    }
    RebuildQuickMenu();
}

void GameLibraryManager::OpenFullLibrary()
{
    LoadPreferences();
    if (m_selected_path.empty()) {
        m_selected_path = !m_preferences.last_selected.empty()
                              ? m_preferences.last_selected
                              : m_preferences.last_played;
    }
    is_open = true;
}

void GameLibraryManager::Refresh()
{
    LoadPreferences();
    RequestScan();
}

size_t GameLibraryManager::QuickMenuCount() const
{
    return m_quick_menu_indices.size();
}

bool GameLibraryManager::GetQuickMenuEntry(size_t index,
                                            std::string &label) const
{
    if (index >= m_quick_menu_indices.size()) {
        return false;
    }
    const size_t game_index = m_quick_menu_indices[index];
    if (game_index >= m_games.size()) {
        return false;
    }
    const GameEntry &game = m_games[game_index];
    label = game.display_name;
    if (m_preferences.favorites.count(game.path)) {
        label += "  [Favorite]";
    }
    return true;
}

bool GameLibraryManager::QuickMenuScanning() const
{
    return m_scan_requested || m_scan_in_flight;
}

bool GameLibraryManager::LaunchQuickMenuEntry(size_t index)
{
    if (index >= m_quick_menu_indices.size()) {
        return false;
    }
    const size_t game_index = m_quick_menu_indices[index];
    if (game_index >= m_games.size()) {
        return false;
    }
    return LaunchGame(m_games[game_index]);
}

void GameLibraryManager::OpenIfNeeded()
{
    if (is_open && !m_previous_open) {
        LoadPreferences();
        if (m_selected_path.empty()) {
            m_selected_path = !m_preferences.last_selected.empty()
                                  ? m_preferences.last_selected
                                  : m_preferences.last_played;
        }
        m_request_focus = true;
        if (runstate_is_running()) {
            vm_stop(RUN_STATE_PAUSED);
            m_resume_guest_on_close = true;
        } else {
            m_resume_guest_on_close = false;
        }
        RequestScan();
    } else if (!is_open && m_previous_open) {
        Close(true);
    }
    m_previous_open = is_open;
}

void GameLibraryManager::Close(bool resume_guest)
{
    is_open = false;
    if (resume_guest && m_resume_guest_on_close && !runstate_is_running()) {
        vm_start();
    }
    m_resume_guest_on_close = false;
    m_show_settings = false;
    SavePreferences();
}

void GameLibraryManager::Tick()
{
    OpenIfNeeded();

    if (m_scan_requested && !m_scan_in_flight &&
        debug_tools_background_worker_is_running()) {
        m_scan_requested = false;
        m_scan_in_flight = true;
        auto *job = new ScanJob();
        if (g_config.general.games_dir && g_config.general.games_dir[0]) {
            job->roots.emplace_back(g_config.general.games_dir);
        }
        for (const std::string &root : m_preferences.extra_roots) {
            bool duplicate = false;
            for (const std::string &existing : job->roots) {
                if (SamePath(existing, root)) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                job->roots.push_back(root);
            }
        }
        m_scan_status = "Scanning game library...";
        const bool queued = debug_tools_queue_background_job(
            [](void *opaque) {
                ScanLibrary(*static_cast<ScanJob *>(opaque));
            },
            job,
            [](void *opaque) {
                auto *completed = static_cast<ScanJob *>(opaque);
                game_library_manager.ApplyScanResult(
                    std::move(completed->entries), completed->status);
                delete completed;
            });
        if (!queued) {
            delete job;
            m_scan_in_flight = false;
            m_scan_status = "Background worker unavailable; scan not started.";
        }
    }

    if (is_open) {
        Draw();
    }
}

void GameLibraryManager::ApplyScanResult(std::vector<GameEntry> &&entries,
                                         const std::string &status)
{
    m_games = std::move(entries);
    m_scan_status = status;
    m_scan_in_flight = false;
    if (!m_selected_path.empty()) {
        SelectByPath(m_selected_path);
    }
    RebuildQuickMenu();
    if (m_selected_path.empty() && !m_games.empty()) {
        m_selected_path = m_games.front().path;
    }
    EnsureSelectedCover();
}

void GameLibraryManager::RebuildQuickMenu()
{
    m_quick_menu_indices.clear();
    m_quick_menu_indices.reserve(m_games.size());
    for (size_t i = 0; i < m_games.size(); ++i) {
        m_quick_menu_indices.push_back(i);
    }

    auto history_time = [&](const GameEntry &game) -> int64_t {
        auto it = m_preferences.last_played_us.find(game.path);
        return it == m_preferences.last_played_us.end() ? 0 : it->second;
    };
    auto rank = [&](const GameEntry &game) {
        if (m_preferences.favorites.count(game.path)) {
            return 0;
        }
        return history_time(game) > 0 ? 1 : 2;
    };

    std::sort(m_quick_menu_indices.begin(), m_quick_menu_indices.end(),
              [&](size_t a, size_t b) {
                  const GameEntry &ga = m_games[a];
                  const GameEntry &gb = m_games[b];
                  const int ra = rank(ga);
                  const int rb = rank(gb);
                  if (ra != rb) {
                      return ra < rb;
                  }
                  if (ra <= 1) {
                      const int64_t ta = history_time(ga);
                      const int64_t tb = history_time(gb);
                      if (ta != tb) {
                          return ta > tb;
                      }
                  }
                  const std::string la = Lower(ga.display_name);
                  const std::string lb = Lower(gb.display_name);
                  if (la != lb) {
                      return la < lb;
                  }
                  return PathKey(ga.path) < PathKey(gb.path);
              });

    // Keep the Home popup compact; the full browser remains available below.
    constexpr size_t kQuickMenuLimit = 12;
    if (m_quick_menu_indices.size() > kQuickMenuLimit) {
        m_quick_menu_indices.resize(kQuickMenuLimit);
    }
}

std::vector<size_t> GameLibraryManager::BuildVisibleIndices() const
{
    std::vector<size_t> indices;
    indices.reserve(m_games.size());
    for (size_t i = 0; i < m_games.size(); ++i) {
        const GameEntry &game = m_games[i];
        if (m_view_mode == ViewMode::Favorites &&
            m_preferences.favorites.find(game.path) ==
                m_preferences.favorites.end()) {
            continue;
        }
        if (m_view_mode == ViewMode::Recent &&
            m_preferences.last_played_us.find(game.path) ==
                m_preferences.last_played_us.end()) {
            continue;
        }
        if (!ContainsCaseInsensitive(game.display_name, m_search) &&
            !ContainsCaseInsensitive(game.game_id, m_search) &&
            !ContainsCaseInsensitive(game.path, m_search)) {
            continue;
        }
        indices.push_back(i);
    }
    if (m_view_mode == ViewMode::Recent) {
        std::stable_sort(indices.begin(), indices.end(), [&](size_t a, size_t b) {
            auto ita = m_preferences.last_played_us.find(m_games[a].path);
            auto itb = m_preferences.last_played_us.find(m_games[b].path);
            const int64_t ta = ita == m_preferences.last_played_us.end()
                                   ? 0 : ita->second;
            const int64_t tb = itb == m_preferences.last_played_us.end()
                                   ? 0 : itb->second;
            return ta > tb;
        });
    }
    return indices;
}

size_t GameLibraryManager::SelectedVisiblePosition(
    const std::vector<size_t> &visible) const
{
    for (size_t pos = 0; pos < visible.size(); ++pos) {
        if (SamePath(m_games[visible[pos]].path, m_selected_path)) {
            return pos;
        }
    }
    return visible.empty() ? 0 : 0;
}

void GameLibraryManager::MoveSelection(const std::vector<size_t> &visible,
                                       int delta)
{
    if (visible.empty() || delta == 0) {
        return;
    }
    size_t pos = SelectedVisiblePosition(visible);
    const int count = (int)visible.size();
    int next = ((int)pos + delta) % count;
    if (next < 0) {
        next += count;
    }
    const std::string next_path = m_games[visible[(size_t)next]].path;
    if (!SamePath(next_path, m_selected_path)) {
        m_selected_path = next_path;
        EnsureSelectedCover();
        SavePreferences();
    }
}

void GameLibraryManager::SelectByPath(const std::string &path)
{
    for (const GameEntry &game : m_games) {
        if (SamePath(game.path, path)) {
            m_selected_path = game.path;
            return;
        }
    }
}

void GameLibraryManager::ReleaseCover()
{
    if (m_cover_texture != 0) {
        glDeleteTextures(1, &m_cover_texture);
        m_cover_texture = 0;
    }
    m_cover_width = 0;
    m_cover_height = 0;
    m_cover_loaded_path.clear();
}

void GameLibraryManager::EnsureSelectedCover()
{
    const GameEntry *selected = nullptr;
    for (const GameEntry &game : m_games) {
        if (SamePath(game.path, m_selected_path)) {
            selected = &game;
            break;
        }
    }
    const std::string desired = selected ? selected->cover_path : std::string();
    if (SamePath(desired, m_cover_loaded_path)) {
        return;
    }
    ReleaseCover();
    if (desired.empty()) {
        return;
    }

    int channels = 0;
    unsigned char *pixels = stbi_load(desired.c_str(), &m_cover_width,
                                      &m_cover_height, &channels, 4);
    if (!pixels || m_cover_width <= 0 || m_cover_height <= 0) {
        stbi_image_free(pixels);
        m_cover_width = m_cover_height = 0;
        return;
    }
    glGenTextures(1, &m_cover_texture);
    glBindTexture(GL_TEXTURE_2D, m_cover_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, m_cover_width, m_cover_height, 0,
                 GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(pixels);
    m_cover_loaded_path = desired;
}

bool GameLibraryManager::LaunchGame(const GameEntry &game)
{
    Error *error = nullptr;
    xemu_load_disc(game.path.c_str(), &error);
    if (error) {
        xemu_queue_error_message(error_get_pretty(error));
        error_free(error);
        return false;
    }

    m_selected_path = game.path;
    m_preferences.last_played = game.path;
    m_preferences.last_played_us[game.path] = g_get_real_time();
    RebuildQuickMenu();
    SavePreferences();

    is_open = false;
    m_previous_open = false;
    m_resume_guest_on_close = false;
    ReleaseCover();
    ActionReset();
    if (!runstate_is_running()) {
        vm_start();
    }

    std::string message = "Launching " + game.display_name;
    xemu_queue_notification(message.c_str());
    return true;
}

void GameLibraryManager::LaunchSelected(const std::vector<size_t> &visible)
{
    if (visible.empty()) {
        return;
    }
    const size_t pos = SelectedVisiblePosition(visible);
    LaunchGame(m_games[visible[pos]]);
}

void GameLibraryManager::ToggleFavorite(const std::vector<size_t> &visible)
{
    if (visible.empty()) {
        return;
    }
    const GameEntry &game = m_games[visible[SelectedVisiblePosition(visible)]];
    auto it = m_preferences.favorites.find(game.path);
    if (it == m_preferences.favorites.end()) {
        m_preferences.favorites.insert(game.path);
    } else {
        m_preferences.favorites.erase(it);
    }
    RebuildQuickMenu();
    SavePreferences();
}

void GameLibraryManager::AddRoot(const std::string &path)
{
    if (path.empty()) {
        return;
    }
    const std::string canonical = CanonicalPath(path);
    if (!g_config.general.games_dir || !g_config.general.games_dir[0]) {
        xemu_settings_set_string(&g_config.general.games_dir, canonical.c_str());
    } else if (!SamePath(g_config.general.games_dir, canonical)) {
        bool exists = false;
        for (const std::string &root : m_preferences.extra_roots) {
            if (SamePath(root, canonical)) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            m_preferences.extra_roots.push_back(canonical);
        }
    }
    SavePreferences();
    RequestScan();
}

void GameLibraryManager::RemoveRoot(size_t index)
{
    if (index >= m_preferences.extra_roots.size()) {
        return;
    }
    m_preferences.extra_roots.erase(m_preferences.extra_roots.begin() + index);
    SavePreferences();
    RequestScan();
}

void GameLibraryManager::HandleController(const std::vector<size_t> &visible)
{
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadDpadLeft) ||
        ImGui::IsKeyPressed(ImGuiKey_LeftArrow)) {
        MoveSelection(visible, -1);
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadDpadRight) ||
        ImGui::IsKeyPressed(ImGuiKey_RightArrow)) {
        MoveSelection(visible, 1);
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadL1) ||
        ImGui::IsKeyPressed(ImGuiKey_PageUp)) {
        MoveSelection(visible, -10);
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadR1) ||
        ImGui::IsKeyPressed(ImGuiKey_PageDown)) {
        MoveSelection(visible, 10);
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadFaceDown) ||
        ImGui::IsKeyPressed(ImGuiKey_Enter)) {
        LaunchSelected(visible);
        return;
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadFaceRight) ||
        ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        Close(true);
        return;
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadFaceLeft)) {
        ToggleFavorite(visible);
    }
    if (ImGui::IsKeyPressed(ImGuiKey_GamepadFaceUp)) {
        RequestScan();
    }
}

void GameLibraryManager::DrawTopBar()
{
    ImGui::TextUnformatted("XEMU GAME LIBRARY");
    ImGui::SameLine();
    ImGui::TextDisabled("  Debug Tools host dashboard");

    const auto mode_button = [&](const char *label, ViewMode mode) {
        if (m_view_mode == mode) {
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 1.0f);
        }
        if (ImGui::Button(label)) {
            m_view_mode = mode;
        }
        if (m_view_mode == mode) {
            ImGui::PopStyleVar();
        }
    };
    mode_button("All", ViewMode::All);
    ImGui::SameLine();
    mode_button("Favorites", ViewMode::Favorites);
    ImGui::SameLine();
    mode_button("Recent", ViewMode::Recent);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(260.0f);
    ImGui::InputTextWithHint("##game-library-search", "Search title / ID / path",
                             &m_search);
    ImGui::SameLine();
    if (ImGui::Button("Refresh (Y)")) {
        RequestScan();
    }
    ImGui::SameLine();
    if (ImGui::Button("Library Settings")) {
        m_show_settings = !m_show_settings;
    }
    ImGui::Separator();
}

void GameLibraryManager::DrawSelectedGame(const std::vector<size_t> &visible)
{
    if (visible.empty()) {
        const char *games_dir = g_config.general.games_dir;
        ImGui::Dummy(ImVec2(0, 30));
        ImGui::TextWrapped("No Xbox disc images match the current view.");
        if (!games_dir || !games_dir[0]) {
            ImGui::TextDisabled("No stock Games directory is configured.");
        }
        if (ImGui::Button("Add Games Folder...")) {
            ShowOpenFolderDialog(games_dir && games_dir[0] ? games_dir : nullptr,
                                 [](const char *path) {
                if (path) {
                    game_library_manager.AddRoot(path);
                }
            });
        }
        return;
    }

    size_t pos = SelectedVisiblePosition(visible);
    if (pos >= visible.size()) {
        pos = 0;
    }
    const GameEntry &game = m_games[visible[pos]];
    if (!SamePath(game.path, m_selected_path)) {
        m_selected_path = game.path;
        EnsureSelectedCover();
    }

    const float width = ImGui::GetContentRegionAvail().x;
    const float cover_width = std::min(300.0f, width * 0.28f);
    const float cover_height = cover_width * 1.42f;

    ImGui::BeginChild("##cover", ImVec2(cover_width, cover_height), true,
                      ImGuiWindowFlags_NoScrollbar);
    if (m_cover_texture != 0 && m_cover_width > 0 && m_cover_height > 0) {
        const float scale = std::min(
            (cover_width - 18.0f) / (float)m_cover_width,
            (cover_height - 18.0f) / (float)m_cover_height);
        const ImVec2 size(m_cover_width * scale, m_cover_height * scale);
        ImGui::SetCursorPosX((cover_width - size.x) * 0.5f);
        ImGui::SetCursorPosY((cover_height - size.y) * 0.5f);
        ImGui::Image((ImTextureID)(intptr_t)m_cover_texture, size, ImVec2(0, 0),
                     ImVec2(1, 1));
    } else {
        ImGui::Dummy(ImVec2(0, cover_height * 0.33f));
        const char *placeholder = "NO COVER ART";
        const float text_width = ImGui::CalcTextSize(placeholder).x;
        ImGui::SetCursorPosX(std::max(8.0f, (cover_width - text_width) * 0.5f));
        ImGui::TextDisabled("%s", placeholder);
    }
    ImGui::EndChild();

    ImGui::SameLine(0, 28.0f);
    ImGui::BeginGroup();
    ImGui::Dummy(ImVec2(0, 12));
    ImGui::TextWrapped("%s", game.display_name.c_str());
    ImGui::Spacing();
    ImGui::Text("%zu / %zu", pos + 1, visible.size());
    if (game.metadata_valid) {
        ImGui::Text("Game ID: %s", game.game_id.c_str());
        ImGui::Text("Title ID: %08X", game.title_id);
        ImGui::Text("Region: %s", game.region.c_str());
        ImGui::Text("XBE Version: %08X", game.version);
        ImGui::Text("Disc: %u", game.disc_number);
        if (!game.executable_identity.empty()) {
            ImGui::Text("Identity: %.16s...",
                        game.executable_identity.c_str());
        }
    } else {
        ImGui::TextDisabled("default.xbe metadata unavailable");
    }
    ImGui::Text("Image: %s", FormatBytes(game.file_size).c_str());
    ImGui::TextWrapped("%s", game.path.c_str());

    const bool favorite =
        m_preferences.favorites.find(game.path) != m_preferences.favorites.end();
    ImGui::Spacing();
    if (ImGui::Button("<  Previous", ImVec2(130, 34))) {
        MoveSelection(visible, -1);
    }
    ImGui::SameLine();
    if (ImGui::Button("PLAY  (A)", ImVec2(160, 42))) {
        LaunchSelected(visible);
        ImGui::EndGroup();
        return;
    }
    ImGui::SameLine();
    if (ImGui::Button("Next  >", ImVec2(130, 34))) {
        MoveSelection(visible, 1);
    }
    if (ImGui::Button(favorite ? "Remove Favorite (X)" : "Add Favorite (X)")) {
        ToggleFavorite(visible);
    }
    ImGui::SameLine();
    XemuCheatDb::GameRef cheat_game;
    cheat_game.title_id = game.title_id;
    cheat_game.game_id = game.game_id;
    cheat_game.name = game.display_name;
    cheat_game.executable_identity = game.executable_identity;
    const std::string cheat_button =
        XemuCheatDb::cheat_db_manager.GameLibraryButtonLabel(cheat_game);
    if (ImGui::Button(cheat_button.c_str())) {
        XemuCheatDb::cheat_db_manager.OpenForGame(cheat_game);
    }
    if (ImGui::IsItemHovered()) {
        const std::string cheat_status =
            XemuCheatDb::cheat_db_manager.GameStatusText(cheat_game);
        ImGui::SetTooltip("%s", cheat_status.c_str());
    }
    ImGui::SameLine();
    if (ImGui::Button("Back / Resume (B)")) {
        Close(true);
        ImGui::EndGroup();
        return;
    }

    ImGui::Dummy(ImVec2(0, 8));
    ImGui::TextDisabled(
        "D-pad/Left-Right: cycle   White/Black: jump 10   A: play   X: favorite   Y: refresh   B: back");
    ImGui::EndGroup();
}

void GameLibraryManager::DrawLibrarySettings()
{
    if (!m_show_settings) {
        return;
    }
    ImGui::SeparatorText("Library Settings");

    ImGui::Text("Primary Games directory: %s",
                g_config.general.games_dir && g_config.general.games_dir[0]
                    ? g_config.general.games_dir : "<not configured>");
    if (ImGui::Button("Add Library Root...")) {
        ShowOpenFolderDialog(g_config.general.games_dir,
                             [](const char *path) {
            if (path) {
                game_library_manager.AddRoot(path);
            }
        });
    }

    for (size_t i = 0; i < m_preferences.extra_roots.size(); ++i) {
        ImGui::PushID((int)i);
        ImGui::TextWrapped("Extra: %s", m_preferences.extra_roots[i].c_str());
        ImGui::SameLine();
        if (ImGui::SmallButton("Remove")) {
            RemoveRoot(i);
            ImGui::PopID();
            break;
        }
        ImGui::PopID();
    }
    ImGui::TextDisabled(
        "Scans .iso and .xiso recursively on the Debug Tools background worker. Cover art: cover.*, folder.*, or image-name.* beside the disc image.");
}

void GameLibraryManager::Draw()
{
    ImGuiViewport *viewport = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(viewport->Pos);
    ImGui::SetNextWindowSize(viewport->Size);
    if (m_request_focus) {
        ImGui::SetNextWindowFocus();
        m_request_focus = false;
    }

    constexpr ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoCollapse;
    bool open = is_open;
    if (!ImGui::Begin("XEMU Game Library##DebugTools", &open, flags)) {
        ImGui::End();
        if (!open) {
            Close(true);
        }
        return;
    }
    if (!open) {
        ImGui::End();
        Close(true);
        return;
    }

    DrawTopBar();
    const std::vector<size_t> visible = BuildVisibleIndices();
    HandleController(visible);
    if (!is_open) {
        ImGui::End();
        return;
    }
    DrawSelectedGame(visible);
    if (!is_open) {
        ImGui::End();
        return;
    }
    DrawLibrarySettings();

    ImGui::SetCursorPosY(std::max(ImGui::GetCursorPosY(),
                                  ImGui::GetWindowHeight() - 36.0f));
    ImGui::Separator();
    ImGui::TextDisabled("%s%s",
                        m_scan_in_flight ? "Scanning...  " : "",
                        m_scan_status.empty() ? "Ready" : m_scan_status.c_str());
    ImGui::End();
}

void GameLibraryManager::Cleanup()
{
    SavePreferences();
    ReleaseCover();
    m_games.clear();
    m_preferences = {};
    m_preferences_loaded = false;
    m_scan_requested = false;
    m_scan_in_flight = false;
    is_open = false;
    m_previous_open = false;
    m_resume_guest_on_close = false;
}

} // namespace XemuGameLibrary
