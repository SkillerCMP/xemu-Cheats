#include "game-library-menu-hook.h"
#include "game-library.hh"

#include <cstdio>
#include <string>

extern "C" bool xemu_debug_tools_game_library_menu_available(void)
{
    return true;
}

extern "C" void xemu_debug_tools_game_library_menu_prepare(void)
{
    XemuGameLibrary::game_library_manager.PrepareQuickMenu();
}

extern "C" size_t xemu_debug_tools_game_library_menu_count(void)
{
    return XemuGameLibrary::game_library_manager.QuickMenuCount();
}

extern "C" bool xemu_debug_tools_game_library_menu_get_label(
    size_t index, char *label, size_t label_size)
{
    if (!label || label_size == 0) {
        return false;
    }
    std::string value;
    if (!XemuGameLibrary::game_library_manager.GetQuickMenuEntry(index, value)) {
        label[0] = '\0';
        return false;
    }
    std::snprintf(label, label_size, "%s", value.c_str());
    return true;
}

extern "C" bool xemu_debug_tools_game_library_menu_launch(size_t index)
{
    return XemuGameLibrary::game_library_manager.LaunchQuickMenuEntry(index);
}

extern "C" bool xemu_debug_tools_game_library_menu_scanning(void)
{
    return XemuGameLibrary::game_library_manager.QuickMenuScanning();
}

extern "C" void xemu_debug_tools_game_library_menu_open_full(void)
{
    XemuGameLibrary::game_library_manager.OpenFullLibrary();
}

extern "C" void xemu_debug_tools_game_library_menu_refresh(void)
{
    XemuGameLibrary::game_library_manager.Refresh();
}
