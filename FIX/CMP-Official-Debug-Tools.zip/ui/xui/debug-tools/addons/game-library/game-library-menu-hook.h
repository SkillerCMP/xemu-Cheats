// xemu Debug Tools - Home -> Games library bridge.
#pragma once

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

bool xemu_debug_tools_game_library_menu_available(void);
void xemu_debug_tools_game_library_menu_prepare(void);
size_t xemu_debug_tools_game_library_menu_count(void);
bool xemu_debug_tools_game_library_menu_get_label(size_t index,
                                                   char *label,
                                                   size_t label_size);
bool xemu_debug_tools_game_library_menu_launch(size_t index);
bool xemu_debug_tools_game_library_menu_scanning(void);
void xemu_debug_tools_game_library_menu_open_full(void);
void xemu_debug_tools_game_library_menu_refresh(void);

#ifdef __cplusplus
}
#endif
