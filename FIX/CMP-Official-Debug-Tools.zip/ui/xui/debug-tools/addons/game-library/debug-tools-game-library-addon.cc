#include "../../debug-tools-module.hh"
#include "game-library.hh"

void debug_tools_register_game_library_addition()
{
    XemuGameLibrary::game_library_manager.Register();
}
