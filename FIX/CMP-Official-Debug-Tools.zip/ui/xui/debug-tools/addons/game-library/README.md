# Game Library add-on

The Game Library is a host-side Debug Tools add-on for the `full` profile.

## Ownership

- Patch 300 contains only the small `ui/xui/popup-menu.cc` hook that lets the
  stock Home -> Games submenu query this add-on.
- Recursive game scanning, XDVDFS `default.xbe` parsing, XBE identity, cover
  art, Favorites, Recent history, extra roots, the quick Home list, and the
  full-screen browser live here.
- Non-full profiles link a tiny menu-hook/registration stub and keep XEMU's
  stock Games submenu behavior.

## Runtime model

XEMU startup and configured-disc auto-boot are untouched. The library is only
activated after the user opens Home -> Games or explicitly opens Game Library
from Debug Tools. Host directory scanning is queued on the existing Debug Tools
background worker and never reads guest RAM/CPU state.

Home -> Games shows a compact list (Favorites first, then Recent, then the
remaining library), plus **Open Full Game Library** and **Refresh Library**.
Selecting a library entry mounts it through XEMU's normal disc path and requests
a normal guest reset.

State is stored under `DEBUG/Game-Library/game-library.ini`. Legacy startup-mode
keys from the retired v3.14ae/af experiment are ignored and disappear the next
time the file is saved; `Startup/LastPlayed` is read once only to migrate recent
history.
