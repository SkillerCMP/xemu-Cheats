// CSB TEST8 single-file, synchronous Xbox stream RPC protocol (up to 4 MiB).
// A live handle never crosses a title safe-point search: the host retains the
// SAME borrowed title context and private mapping until verified Close returns.
#pragma once
#include "kernel-rpc-utils.hh"
namespace XemuKernelStream {
// The legacy default is retained for callers without an explicit policy.
constexpr uint32_t kChunkBytes=512u*1024u, kMaxChunkBytes=4u*1024u*1024u;
constexpr uint32_t kResult=0x1000u, kHandle=0x1020u;
constexpr uint32_t kIoStatus=0x1080u, kByteOffset=0x1090u;
constexpr uint32_t kAnsi=0x1100u, kObjects=0x1120u, kPath=0x1200u, kData=0x2000u;
constexpr uint32_t kArenaBytes=kData+kChunkBytes, kNotCalled=0xccccccccu, kPending=0x103u;
enum class Action { OpenWrite, Write, FlushClose, CloseOnly };
enum Call : uint32_t { Create=1u, Write=2u, Flush=4u, Close=8u };
struct Exports { uint32_t irql_fn=0,create_fn=0,write_fn=0,flush_fn=0,close_fn=0; };
struct Stub { std::vector<uint8_t> bytes; uint32_t completion_address=0; };
struct Result {
    uint32_t irql=0xffffffffu,create_status=kNotCalled,write_status=kNotCalled,flush_status=kNotCalled,close_status=kNotCalled;
    uint32_t calls=0,information=0,write_iosb=kNotCalled,handle=0,other_iosb=kNotCalled;
};
inline Result ParseResult(const uint8_t *p) {
    using XemuKernelRpc::Le32;
    return {Le32(p),Le32(p+4),Le32(p+8),Le32(p+12),Le32(p+16),Le32(p+20),Le32(p+24),Le32(p+28),Le32(p+32),Le32(p+36)};
}
inline bool SupportedChunkBytes(uint32_t n) {
    return n==kChunkBytes || n==1024u*1024u || n==2u*1024u*1024u || n==kMaxChunkBytes;
}
inline uint32_t ArenaBytesForFile(uint64_t n, uint32_t chunk) {
    if (!SupportedChunkBytes(chunk)) return 0;
    const uint32_t data=static_cast<uint32_t>(n < chunk ? n : chunk);
    return (kData+data+4095u)&~4095u;
}
inline uint64_t OperationCount(uint64_t n, uint32_t chunk=kChunkBytes) {
    if (!SupportedChunkBytes(chunk)) return 0;
    return (n ? n/chunk+(n%chunk!=0) : 1u)+1u;
}
inline const char *ChunkLabel(uint32_t n) {
    switch (n) {
    case 512u*1024u: return "512 KiB";
    case 1024u*1024u: return "1 MiB";
    case 2u*1024u*1024u: return "2 MiB";
    case 4u*1024u*1024u: return "4 MiB";
    default: return "INVALID";
    }
}
inline bool HasPending(const Result &r) {
    return ((r.calls&Create)&&(r.create_status==kPending||r.other_iosb==kPending)) ||
           ((r.calls&Write)&&(r.write_status==kPending||r.write_iosb==kPending)) ||
           ((r.calls&Flush)&&(r.flush_status==kPending||r.other_iosb==kPending)) ||
           ((r.calls&Close)&&r.close_status==kPending);
}
inline bool BuildStub(uint32_t base,const Exports &e,Action action,uint32_t length,Stub &out,std::string &error) {
    using namespace XemuKernelRpc;
    out={};error.clear();
    const bool opening=action==Action::OpenWrite, writing=opening||action==Action::Write;
    if (length>kMaxChunkBytes||(!writing&&length)||(action==Action::Write&&!length)||
        !e.irql_fn||!e.create_fn||!e.write_fn||!e.flush_fn||!e.close_fn||uint64_t(base)+kData+length>0x100000000ull) {
        error="Invalid stream RPC exports/action/payload range.";return false;
    }
    auto u8=[&](uint8_t v){out.bytes.push_back(v);};
    auto u32=[&](uint32_t v){size_t p=out.bytes.size();out.bytes.resize(p+4);StoreLe32(out.bytes.data()+p,v);};
    auto store=[&](uint32_t off,uint32_t v){u8(0xc7);u8(0x05);u32(base+off);u32(v);};
    auto save=[&](uint32_t off){u8(0xa3);u32(base+off);};
    auto load=[&](uint32_t off){u8(0xa1);u32(base+off);};
    auto push=[&](uint32_t v){u8(0x68);u32(v);};
    auto handle=[&](){u8(0xff);u8(0x35);u32(base+kHandle);};
    auto call=[&](uint32_t target){
        // 32-bit x86 rel32 wraps modulo 2^32; all kernel export/arena pairs are reachable.
        const uint32_t next=base+static_cast<uint32_t>(out.bytes.size())+5u;
        u8(0xe8);u32(target-next);
    };
    std::vector<size_t> jumps;
    auto jump=[&](uint8_t condition){u8(0x0f);u8(condition);jumps.push_back(out.bytes.size());u32(0);};
    auto not_success=[&](){u8(0x85);u8(0xc0);jump(0x85);};
    auto pending=[&](){u8(0x3d);u32(kPending);jump(0x84);};
    auto record=[&](uint32_t mask){u8(0x83);u8(0x0d);u32(base+kResult+20);u8(static_cast<uint8_t>(mask));};
    u8(0x9c);u8(0x60); // pushfd/pushad
    call(e.irql_fn);u8(0x0f);u8(0xb6);u8(0xc0); // movzx eax,al: IRQL is UCHAR
    save(kResult);not_success();
    if(opening) {
        record(Create);
        push(kFileNonDirectoryFile|kFileSynchronousIoNonAlert|kFileOpenForBackupIntent);
        push(kFileCreate);push(0); // strict create-only; exclusive staging handle
        push(kFileAttributeNormal);push(0);push(base+kIoStatus);push(base+kObjects);
        push(kSynchronizeAccess|kFileWriteDataAccess);push(base+kHandle);call(e.create_fn);
        save(kResult+4);not_success();load(kIoStatus);save(kResult+36);not_success();
    }
    load(kHandle);u8(0x85);u8(0xc0);jump(0x84);
    if(writing&&length) {
        record(Write);push(base+kByteOffset);push(length);push(base+kData);push(base+kIoStatus);
        push(0);push(0);push(0);handle();call(e.write_fn);save(kResult+8);
        load(kIoStatus);save(kResult+28);load(kIoStatus+4);save(kResult+24);
        // Host proves exact byte count and both statuses before reusing data.
    } else if(action==Action::FlushClose||action==Action::CloseOnly) {
        if(action==Action::FlushClose) {
            record(Flush);push(base+kIoStatus);handle();call(e.flush_fn);save(kResult+12);pending();
            load(kIoStatus);save(kResult+36);pending(); // never close a pending flush
        }
        record(Close);handle();call(e.close_fn);save(kResult+16);not_success();store(kHandle,0);
    }
    const uint32_t restore=base+static_cast<uint32_t>(out.bytes.size());
    for(size_t p:jumps)StoreLe32(out.bytes.data()+p,restore-(base+static_cast<uint32_t>(p)+4u));
    u8(0x61);u8(0x9d);out.completion_address=base+static_cast<uint32_t>(out.bytes.size());
    u8(0xeb);u8(0xfe); // private completion breakpoint; do not run title yet
    if(out.bytes.size()>=kResult){error="Stream code overlaps result region.";return false;}
    return true;
}
}
