// CSB TEST8: bounded selectable chunks, one handle/private arena per staging file.
#include "qemu/osdep.h"
#include "guest-kernel-rpc.hh"
#include "current-game.hh"
#include "hdd-snapshot-service.hh"
#include "disc-block-ref.hh"
#include <SDL3/SDL.h>
#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
extern "C" {
#include "system/runstate.h"
bool bql_locked(void);
void bql_lock_impl(const char *file, int line);
void bql_unlock(void);
}
namespace {
void PauseStreamVm() {
    const bool own=!bql_locked();
    if(own)bql_lock_impl(__FILE__,__LINE__);
    vm_stop(RUN_STATE_PAUSED);
    if(own)bql_unlock();
}
}
bool GuestKernelRpcManager::StreamSourceMatches() const {
    const auto &game=current_game_manager.Get();XemuDiscBlockRef hdd("ide0-hd0");
    return game.valid && game.title_id==m_fs_title_id && IsTitleExecutionPoint(m_saved.eip) &&
        hdd && xemu_disc_block_is_available(hdd.Get()) && !xemu_disc_block_is_read_only(hdd.Get()) &&
        xemu_disc_block_identity(hdd.Get())==m_stream_hdd_identity;
}
bool GuestKernelRpcManager::StreamCompletionContext(std::string &error) const {
    XemuCheatX86Registers regs={};
    if(runstate_is_running() || !xemu_guest_rpc_arena_active() || !m_breakpoint_installed ||
       !xemu_guest_rpc_arena_validate() || !StreamSourceMatches() ||
       !xemu_cheat_get_x86_registers(&regs) || regs.eip!=m_completion_address || regs.pc!=m_completion_address) {
        error="The pinned stream completion context/mapping/source is no longer owned.";return false;
    }
    return PreservedFilesystemStateMatches(m_saved,regs,error);
}
void GuestKernelRpcManager::FailStreamUnsafe(const std::string &reason) {
    // Do not close an unknown handle in a different thread or reuse an IRP's
    // buffer/IO_STATUS_BLOCK while that request may still be outstanding.
    if(runstate_is_running())PauseStreamVm();
    if(m_state==State::RunningFsQuery)m_stream_metrics.rpc_ms+=SDL_GetTicks()-m_started_ms;
    m_state=State::Failed;m_filesystem_operation.phase=FilesystemOperationPhase::Failed;
    m_stream_finished_ms=SDL_GetTicks();m_stream_metrics.transfer_phase="RESET / RESTART REQUIRED";
    m_status=reason+" Xbox left paused with stream handle/mapping ownership retained; reset/restart before retrying. Staging was not published.";
    hdd_snapshot_service.NotifyFilesystemChanged();
}
bool GuestKernelRpcManager::BeginFastImportAttempt() {
    std::string error;
    if(m_stream_session||m_stream_handle){FailStreamUnsafe("A live stream must not enter another title safe-point search.");return false;}
    if(!ResolveKernelImportExports(error)){AbortBeforeRun(error,false);return false;}
    XemuDiscBlockRef hdd("ide0-hd0");
    if(!hdd||!xemu_disc_block_is_available(hdd.Get())||xemu_disc_block_is_read_only(hdd.Get())||
       !m_stream_hdd_identity||xemu_disc_block_identity(hdd.Get())!=m_stream_hdd_identity) {
        AbortBeforeRun("Mounted HDD changed or is unavailable/read-only before stream open.",false);return false;
    }
    const uint32_t arena_bytes=XemuKernelStream::ArenaBytesForFile(
        m_import_preflight.entries.front().file_size, m_stream_metrics.chunk_bytes);
    if(!arena_bytes || !xemu_guest_rpc_arena_acquire_sized(arena_bytes,&m_arena)) {
        const char *why=xemu_guest_rpc_arena_last_error();
        AbortBeforeRun(std::string("Unable to map the private ")+
            XemuKernelStream::ChunkLabel(m_stream_metrics.chunk_bytes)+
            " stream buffer: "+(why?why:"unknown arena failure"),false);return false;
    }
    m_stream_session=true;
    if(m_stream_wait_started_ms){m_stream_metrics.wait_ms+=SDL_GetTicks()-m_stream_wait_started_ms;m_stream_wait_started_ms=0;}
    return SendStreamCall(XemuKernelStream::Action::OpenWrite);
}
bool GuestKernelRpcManager::SendStreamCall(XemuKernelStream::Action action) {
    namespace S=XemuKernelStream;using XemuKernelRpc::StoreLe32;
    const bool opening=action==S::Action::OpenWrite,writing=opening||action==S::Action::Write;
    const uint64_t refill_start=SDL_GetTicks();
    std::string error;
    if(!opening&&!StreamCompletionContext(error)){FailStreamUnsafe(error);return false;}
    auto reject=[&](const std::string &why,bool restore=false){
        if(opening&&!m_stream_handle){m_stream_session=false;AbortBeforeRun(why,restore);}
        else FailStreamUnsafe(why);
        return false;
    };
    if(!m_stream_session||!xemu_guest_rpc_arena_validate()||!StreamSourceMatches()||(!opening&&!m_stream_handle))
        return reject("Stream call has no matching source/session/handle.");
    const uint32_t base=m_arena.virtual_base;S::Stub stub;
    S::Exports exports{m_export_address,m_import_create_export_address,m_import_write_export_address,m_import_flush_export_address,m_import_close_export_address};
    const uint32_t count=writing?m_import_current_chunk_bytes:0;
    if(!S::BuildStub(base,exports,action,count,stub,error))return reject(error);
    std::array<uint8_t,8> ansi={};std::array<uint8_t,12> objects={};
    if(!XemuKernelRpc::BuildFileQueryObjects(m_query_path,base+S::kPath,base+S::kAnsi,ansi,objects,error,0u))return reject(error);
    const size_t payload_size=S::kData+count;
    if(S::kPath+m_query_path.size()+1u>S::kData||payload_size>m_arena.size||
       count>m_stream_metrics.chunk_bytes||(writing&&m_import_chunk.size()!=count))
        return reject("Stream payload exceeds its mapped buffer/layout.");
    // Only the 8 KiB protocol header is rebuilt. The existing source chunk is
    // copied directly to private RAM by writev, with one translation sync.
    std::array<uint8_t,S::kData> payload{};
    std::copy(stub.bytes.begin(),stub.bytes.end(),payload.begin());StoreLe32(payload.data()+S::kResult,0xffffffffu);
    for(uint32_t off:{4u,8u,12u,16u,28u,36u})StoreLe32(payload.data()+S::kResult+off,S::kNotCalled);
    StoreLe32(payload.data()+S::kHandle,m_stream_handle);StoreLe32(payload.data()+S::kIoStatus,S::kNotCalled);
    StoreLe32(payload.data()+S::kByteOffset,static_cast<uint32_t>(m_import_file_offset));
    StoreLe32(payload.data()+S::kByteOffset+4,static_cast<uint32_t>(m_import_file_offset>>32));
    std::copy(ansi.begin(),ansi.end(),payload.begin()+S::kAnsi);std::copy(objects.begin(),objects.end(),payload.begin()+S::kObjects);
    std::memcpy(payload.data()+S::kPath,m_query_path.c_str(),m_query_path.size()+1u);
    if(m_breakpoint_installed){
        if(!xemu_cheat_breakpoint_remove(m_completion_address))return reject("Stream completion breakpoint removal failed.");
        m_breakpoint_installed=false;
    }
    const XemuGuestRpcArenaWritePart spans[] = {
        {0u,payload.data(),payload.size()},
        {S::kData,m_import_chunk.data(),count},
    };
    if(!xemu_guest_rpc_arena_writev(spans,count?2u:1u))return reject("Stream arena refill failed; no additional write was started.");
    m_stub_address=base;m_completion_address=stub.completion_address;
    if(!xemu_cheat_breakpoint_insert(m_completion_address))return reject("Stream completion breakpoint installation failed.");
    m_breakpoint_installed=true;
    // SAME original borrowed thread/stack for every call. No title instruction
    // or fresh sampling step runs with this private handle still open.
    if((!opening&&!RestoreSavedContext())||!xemu_cheat_set_x86_register("eip",base))return reject("Stream CPU redirection/restoration failed.",true);
    m_stream_action=action;++m_stream_metrics.rpc_calls;
    m_stream_metrics.transfer_phase=writing?"Writing":action==S::Action::CloseOnly?"Closing cancelled/failed stream":"Flushing / closing";
    m_status="FAST STREAM: "+m_stream_metrics.transfer_phase+" "+m_fs_path+" ("+
        S::ChunkLabel(m_stream_metrics.chunk_bytes)+" maximum; final readback before publication).";
    m_stream_metrics.refill_ms+=SDL_GetTicks()-refill_start;
    m_started_ms=SDL_GetTicks();m_state=State::RunningFsQuery;ResumeAfterImportBurst();return true;
}
void GuestKernelRpcManager::CloseFailedStream(const std::string &reason) {
    m_stream_abort_reason=reason;
    if(!m_stream_handle){Finish(false,reason,true);return;}
    SendStreamCall(XemuKernelStream::Action::CloseOnly);
}
void GuestKernelRpcManager::HandleFastImportCompletion(const XemuCheatX86Registers &after) {
    namespace S=XemuKernelStream;
    // Account the completed call once. Preparation/validation failures below
    // must not count that same interval again as a live RPC.
    m_stream_metrics.rpc_ms+=SDL_GetTicks()-m_started_ms;m_started_ms=SDL_GetTicks();
    uint8_t bytes[40]={};std::string error;
    if(!PreservedFilesystemStateMatches(m_saved,after,error)||!StreamCompletionContext(error)||
       !xemu_guest_rpc_arena_read(S::kResult,bytes,sizeof(bytes))) {
        FailStreamUnsafe("Stream completion/result validation failed. "+error);return;
    }
    const auto r=S::ParseResult(bytes);m_irql=r.irql;
    m_stream_metrics.open_calls+=(r.calls&S::Create)!=0;m_stream_metrics.write_calls+=(r.calls&S::Write)!=0;
    m_stream_metrics.flush_calls+=(r.calls&S::Flush)!=0;m_stream_metrics.close_calls+=(r.calls&S::Close)!=0;
    if((r.calls&~15u)||S::HasPending(r)){FailStreamUnsafe("Stream returned unexpected/pending filesystem status; no further buffer refill or cleanup will be attempted.");return;}
    const bool opening=m_stream_action==S::Action::OpenWrite,writing=opening||m_stream_action==S::Action::Write;
    if(r.irql!=0){
        if(!opening||m_stream_handle||r.handle||r.calls){FailStreamUnsafe("IRQL/context changed while the stream owned a file handle.");return;}
        m_stream_session=false;
        if(!CleanupAttemptForRetry(error)){m_state=State::Failed;m_status="Stream IRQL-probe cleanup failed: "+error;return;}
        m_state=State::WaitingSafePoint;m_stream_wait_started_ms=SDL_GetTicks();m_next_safe_point_sample_ms=SDL_GetTicks()+25u;
        m_status="WAITING FOR SAFE HDD WRITE: initial stream IRQL probe skipped all filesystem calls.";return;
    }
    if(opening){
        if(r.calls==S::Create&&r.create_status!=0&&!r.handle){
            char text[192];std::snprintf(text,sizeof(text),"Stream FILE_CREATE failed (%08X); existing files were not overwritten.",r.create_status);
            Finish(false,text,true);return;
        }
        if(r.create_status!=0||r.other_iosb!=0||!r.handle){FailStreamUnsafe("Stream create returned an inconsistent status/handle.");return;}
        m_stream_handle=r.handle;
    }
    const uint32_t expected_calls=writing?((opening?static_cast<uint32_t>(S::Create):0u)|(m_import_current_chunk_bytes?static_cast<uint32_t>(S::Write):0u)):
        m_stream_action==S::Action::FlushClose?S::Flush|S::Close:S::Close;
    if(r.calls!=expected_calls){FailStreamUnsafe("Stream syscall sequence/result mask does not match the requested action.");return;}
    if(writing){
        if(r.handle!=m_stream_handle){FailStreamUnsafe("The private stream handle changed unexpectedly.");return;}
        if(m_import_current_chunk_bytes&&(r.write_status!=0||r.write_iosb!=0||r.information!=m_import_current_chunk_bytes)) {
            char text[256];std::snprintf(text,sizeof(text),"Stream write failed/short: NtWriteFile=%08X, IO_STATUS=%08X, bytes=%u/%u; closing partial staging.",r.write_status,r.write_iosb,r.information,m_import_current_chunk_bytes);
            CloseFailedStream(text);return;
        }
        ++m_import_completed_operations;m_import_written_bytes+=m_import_current_chunk_bytes;m_import_file_offset+=m_import_current_chunk_bytes;
        if(m_filesystem_cancel_requested){CloseFailedStream(m_filesystem_cancel_reason+" Partial staging retained.");return;}
        const auto &item=m_import_preflight.entries.front();
        if(m_import_file_offset==item.file_size){
            if(!item.source_from_fatx&&(m_import_current_source_hash!=item.host_content_hash||!XemuKernelFs::ValidateImportHostEntryMetadata(item,error))){CloseFailedStream("Host source changed during streaming. "+error);return;}
            SendStreamCall(S::Action::FlushClose);return;
        }
        if(m_import_file_offset>item.file_size||!LoadKernelImportOperation(error)){CloseFailedStream("Unable to load next stream chunk. "+error);return;}
        SendStreamCall(S::Action::Write);return;
    }
    if(r.close_status!=0||r.handle!=0){FailStreamUnsafe("Stream NtClose failed or handle release could not be proven.");return;}
    m_stream_handle=0;++m_import_completed_operations;hdd_snapshot_service.NotifyFilesystemChanged();
    if(m_stream_action==S::Action::CloseOnly){Finish(false,m_stream_abort_reason+" Staging handle closed safely; existing music not published/replaced.",true);return;}
    if(r.flush_status!=0||r.other_iosb!=0){Finish(false,"Stream flush failed; handle closed, staging retained, nothing published.",true);return;}
    if(m_filesystem_cancel_requested){Finish(false,m_filesystem_cancel_reason+" Stream closed safely before publication.",true);return;}
    m_state=State::VerifyingImport;m_stream_metrics.transfer_phase="Final readback";
    m_status="FAST STREAM: flushed/closed. Verifying complete staging file once before publication...";
}
void GuestKernelRpcManager::VerifyFastImport() {
    std::string error;
    if(!StreamCompletionContext(error)||m_stream_handle){FailStreamUnsafe("Final stream verification lost paused context. "+error);return;}
    if(m_filesystem_cancel_requested){Finish(false,m_filesystem_cancel_reason+" Stream closed; unverified staging retained.",true);return;}
    const auto &item=m_import_preflight.entries.front();const uint64_t start=SDL_GetTicks();bool verified=false;
    if(item.source_from_fatx){
        HddSnapshotService::FatxCompareItem compare;
        compare.source_partition=item.source_partition;compare.source_components=item.source_components;
        compare.source_directory_entry_offset=item.source_directory_entry_offset;compare.source_first_cluster=item.source_first_cluster;
        compare.source_modified_time=item.source_modified_time;compare.source_modified_date=item.source_modified_date;compare.source_attributes=item.source_attributes;
        compare.destination_partition=m_import_preflight.partition;compare.destination_components=item.components;compare.file_size=item.file_size;compare.directory=false;
        verified=hdd_snapshot_service.VerifyFatxCopyContents({compare},error);
    }else verified=hdd_snapshot_service.VerifyFatxFileHash(m_import_preflight.partition,item.components,item.file_size,item.host_content_hash,error);
    m_stream_metrics.verify_ms+=SDL_GetTicks()-start;
    if(!verified){Finish(false,"Stream final readback failed; staging was NOT published. "+error,true);return;}
    m_stream_contents_verified=true;m_import_completed_files=1;m_import_plan_index=m_import_preflight.entries.size();
    Finish(true,"PASS: FAST STREAM created, streamed, flushed/closed and fully verified staging. No per-chunk destination FATX snapshots or raw FATX writes used.",true);
}
