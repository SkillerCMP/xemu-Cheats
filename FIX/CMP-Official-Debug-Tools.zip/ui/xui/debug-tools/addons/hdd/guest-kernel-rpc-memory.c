#include "qemu/osdep.h"
#include "qemu/error-report.h"
#include "qemu/main-loop.h"
#include "qemu/bswap.h"
#include "qapi/error.h"
#include "hw/boards.h"
#include "system/address-spaces.h"
#include "system/memory.h"

#include "cheat-engine-memory.h"
#include "backend/xemu-dbg.h"
#include "guest-kernel-rpc-memory.h"

#define XEMU_RPC_PAGE_SIZE       0x00001000u
#define XEMU_RPC_ARENA_SIZE      0x00010000u
/* TEST8: exact 4 MiB payload plus 8 KiB protocol overhead crosses a
 * non-PAE PDE boundary. Reserve TWO page tables, not an oversized single PT. */
#define XEMU_RPC_ARENA_MAX_SIZE  0x00402000u
#define XEMU_RPC_PDE_SPAN        0x00400000u
#define XEMU_RPC_MAX_PDES        2u
#define XEMU_RPC_PT_BYTES        (XEMU_RPC_MAX_PDES * XEMU_RPC_PAGE_SIZE)
#define XEMU_RPC_ARENA_OFFSET    XEMU_RPC_PT_BYTES
#define XEMU_RPC_REGION_BYTES    (XEMU_RPC_PT_BYTES + XEMU_RPC_ARENA_MAX_SIZE)
G_STATIC_ASSERT(XEMU_RPC_ARENA_MAX_SIZE % XEMU_RPC_PAGE_SIZE == 0);
G_STATIC_ASSERT((XEMU_RPC_ARENA_MAX_SIZE + XEMU_RPC_PDE_SPAN - 1u) /
                XEMU_RPC_PDE_SPAN == XEMU_RPC_MAX_PDES);

static const uint32_t xemu_rpc_virtual_candidates[] = {
    0x68400000u, 0x68800000u, 0x68c00000u, 0x69000000u,
    0x69400000u, 0x69800000u, 0x69c00000u, 0x6a000000u,
};

/* Offset these from the Type-F candidates (0x70000000, 0x60000000, ...).
 * The flat-view check is authoritative, so 64/128/256 MiB RAM and device
 * mappings are rejected rather than inferred from a fixed RAM assumption. */
static const hwaddr xemu_rpc_phys_candidates[] = {
    0x70400000u, 0x60400000u, 0x50400000u,
    0x40400000u, 0x30400000u, 0x20400000u,
};

static MemoryRegion xemu_rpc_region;
static bool xemu_rpc_region_initialized;
static bool xemu_rpc_mapping_active;
static hwaddr xemu_rpc_phys_base;
static uint32_t xemu_rpc_virtual_base;
static uint32_t xemu_rpc_mapped_cr3;
static uint32_t xemu_rpc_pde_phys[XEMU_RPC_MAX_PDES];
static uint32_t xemu_rpc_wanted_pde[XEMU_RPC_MAX_PDES];
static uint32_t xemu_rpc_original_pde[XEMU_RPC_MAX_PDES];
static uint32_t xemu_rpc_pde_count;
static uint32_t xemu_rpc_attempted_pdes;
static bool xemu_rpc_mapping_ready;
static uint32_t xemu_rpc_active_size;
static const char *xemu_rpc_error;

static bool xemu_rpc_phys_range_unused(hwaddr base, uint64_t size)
{
    MemoryRegionSection section = memory_region_find(get_system_memory(), base, size);
    if (section.mr == NULL) {
        return true;
    }
    memory_region_unref(section.mr);
    return false;
}

static int xemu_rpc_init_region(void)
{
    Error *local_err = NULL;
    if (xemu_rpc_region_initialized) {
        return 1;
    }
    if (current_machine == NULL) {
        xemu_rpc_error = "Xbox machine is not initialized";
        return 0;
    }
    /* A failed earlier initialization must not leave a stale aperture choice. */
    xemu_rpc_phys_base = 0;
    for (size_t i = 0; i < G_N_ELEMENTS(xemu_rpc_phys_candidates); ++i) {
        const hwaddr candidate = xemu_rpc_phys_candidates[i];
        if (candidate < current_machine->ram_size) {
            continue;
        }
        if (xemu_rpc_phys_range_unused(candidate, XEMU_RPC_REGION_BYTES)) {
            xemu_rpc_phys_base = candidate;
            break;
        }
    }
    if (xemu_rpc_phys_base == 0) {
        xemu_rpc_error = "no unused physical aperture found for the Guest Kernel RPC arena";
        return 0;
    }
    if (!memory_region_init_ram(&xemu_rpc_region, NULL, "xemu.guest-kernel-rpc",
                                XEMU_RPC_REGION_BYTES, &local_err)) {
        if (local_err != NULL) {
            error_report_err(local_err);
        }
        xemu_rpc_error = "could not initialize Guest Kernel RPC RAM";
        return 0;
    }
    memory_region_add_subregion_overlap(get_system_memory(), xemu_rpc_phys_base,
                                        &xemu_rpc_region, 1000);
    memset(memory_region_get_ram_ptr(&xemu_rpc_region), 0, XEMU_RPC_REGION_BYTES);
    xemu_rpc_region_initialized = true;
    return 1;
}

/* Ignore CPU Accessed/Dirty and software bits, but require frame, page size,
 * permissions and cache/global/PAT flags to remain our original mapping. */
static bool xemu_rpc_entry_owned(uint32_t actual, uint32_t expected)
{
    return (actual & 0xfffff19fu) == (expected & 0xfffff19fu);
}

static int xemu_rpc_install_mapping(uint32_t size)
{
    XemuCheatX86Registers regs;
    uint8_t pde_bytes[4];
    uint32_t originals[XEMU_RPC_MAX_PDES] = {0};
    const uint32_t count = (size + XEMU_RPC_PDE_SPAN - 1u) / XEMU_RPC_PDE_SPAN;

    if (!xemu_rpc_init_region()) {
        return 0;
    }
    if (!xemu_cheat_get_x86_registers(&regs)) {
        xemu_rpc_error = "could not read the current Xbox CPU/page-table state";
        return 0;
    }
    if ((regs.cr0 & (1u << 31)) == 0 || (regs.cr4 & (1u << 5)) != 0) {
        xemu_rpc_error = "Guest Kernel RPC requires normal non-PAE 32-bit paging";
        return 0;
    }

    const uint32_t cr3 = regs.cr3 & 0xfffff000u;
    uint32_t selected_base = 0;
    for (size_t i = 0; i < G_N_ELEMENTS(xemu_rpc_virtual_candidates); ++i) {
        const uint32_t candidate = xemu_rpc_virtual_candidates[i];
        bool unused = true;
        for (uint32_t n = 0; n < count; ++n) {
            const uint32_t pde_phys = cr3 + ((candidate >> 22) + n) * 4u;
            if (address_space_read(&address_space_memory, pde_phys,
                                   MEMTXATTRS_UNSPECIFIED, pde_bytes, 4) != MEMTX_OK ||
                (ldl_le_p(pde_bytes) & 1u) != 0) {
                unused = false;
                break;
            }
            originals[n] = ldl_le_p(pde_bytes);
        }
        if (unused) {
            selected_base = candidate;
            break;
        }
    }
    if (selected_base == 0) {
        xemu_rpc_error = "no unused contiguous guest PDE range is available for the RPC arena";
        return 0;
    }

    uint8_t *ram_ptr = memory_region_get_ram_ptr(&xemu_rpc_region);
    memset(ram_ptr, 0, XEMU_RPC_PT_BYTES + size);
    for (uint32_t page = 0; page < size / XEMU_RPC_PAGE_SIZE; ++page) {
        const uint32_t phys = (uint32_t)xemu_rpc_phys_base +
                              XEMU_RPC_ARENA_OFFSET + page * XEMU_RPC_PAGE_SIZE;
        /* Sequential groups of 1024 PTEs are independent page tables. */
        stl_le_p(ram_ptr + page * 4u, phys | 0x007u);
    }
    memory_region_set_dirty(&xemu_rpc_region, 0, XEMU_RPC_PT_BYTES + size);

    xemu_rpc_virtual_base = selected_base;
    xemu_rpc_mapped_cr3 = cr3;
    xemu_rpc_active_size = size;
    xemu_rpc_pde_count = count;
    xemu_rpc_attempted_pdes = 0;
    xemu_rpc_mapping_ready = false;
    for (uint32_t n = 0; n < count; ++n) {
        xemu_rpc_pde_phys[n] = cr3 + ((selected_base >> 22) + n) * 4u;
        xemu_rpc_original_pde[n] = originals[n];
        xemu_rpc_wanted_pde[n] = ((uint32_t)xemu_rpc_phys_base +
                                  n * XEMU_RPC_PAGE_SIZE) | 0x007u;
    }
    /* Track even a failed write attempt: a backend can report an error after
     * changing bytes. acquire() then observes/restores ALL attempted entries. */
    xemu_rpc_mapping_active = true;
    for (uint32_t n = 0; n < count; ++n) {
        stl_le_p(pde_bytes, xemu_rpc_wanted_pde[n]);
        xemu_rpc_attempted_pdes = n + 1u;
        if (address_space_write(&address_space_memory, xemu_rpc_pde_phys[n],
                                MEMTXATTRS_UNSPECIFIED, pde_bytes, 4) != MEMTX_OK) {
            xemu_rpc_error = "could not install the complete private RPC page mapping";
            return 0;
        }
    }
    if (!xemu_dbg_flush_guest_translation()) {
        xemu_rpc_error = "private RPC PDEs were written but translation synchronization failed";
        return 0;
    }
    xemu_rpc_mapping_ready = true;
    return 1;
}

int xemu_guest_rpc_arena_acquire(XemuGuestRpcArenaInfo *info)
{
    return xemu_guest_rpc_arena_acquire_sized(XEMU_RPC_ARENA_SIZE, info);
}

int xemu_guest_rpc_arena_acquire_sized(uint32_t min_size, XemuGuestRpcArenaInfo *info)
{
    /* Detached HDD/Kernel-RPC UI can enter without BQL. The arena owns the
     * short QEMU MemoryRegion/page-table synchronization it requires. */
    BQL_LOCK_GUARD();
    xemu_rpc_error = NULL;
    if (!min_size || min_size > XEMU_RPC_ARENA_MAX_SIZE) {
        xemu_rpc_error = "invalid bounded RPC arena size"; return 0;
    }
    const uint32_t size = (min_size + XEMU_RPC_PAGE_SIZE - 1u) & ~(XEMU_RPC_PAGE_SIZE - 1u);
    if (info == NULL || xemu_rpc_mapping_active) {
        xemu_rpc_error = xemu_rpc_mapping_active
            ? "Guest Kernel RPC arena is already active"
            : "invalid Guest Kernel RPC arena request";
        return 0;
    }
    if (!xemu_rpc_install_mapping(size)) {
        const char *install_error = xemu_rpc_error;
        if (xemu_rpc_mapping_active) {
            if (!xemu_guest_rpc_arena_release()) {
                /* release() leaves ownership active when it cannot prove the
                 * PDE was cleared. The caller can therefore fail closed. */
                return 0;
            }
            xemu_rpc_error = install_error;
        }
        return 0;
    }
    info->virtual_base = xemu_rpc_virtual_base;
    info->physical_base = xemu_rpc_phys_base + XEMU_RPC_ARENA_OFFSET;
    info->size = xemu_rpc_active_size;
    return 1;
}

int xemu_guest_rpc_arena_writev(const XemuGuestRpcArenaWritePart *parts,
                                 size_t count)
{
    BQL_LOCK_GUARD();
    if (!xemu_rpc_mapping_active || !xemu_rpc_mapping_ready ||
        parts == NULL || count == 0 || count > 2) {
        xemu_rpc_error = "invalid bounded Guest Kernel RPC arena refill";
        return 0;
    }
    /* Validate every span BEFORE touching either header or payload. The stream
     * sends its small header and existing source buffer directly, avoiding a
     * second zero-filled multi-MiB vector and an extra full-payload copy. */
    size_t previous_end = 0;
    for (size_t n = 0; n < count; ++n) {
        if (parts[n].data == NULL || parts[n].offset < previous_end ||
            parts[n].offset > xemu_rpc_active_size ||
            parts[n].size > xemu_rpc_active_size - parts[n].offset) {
            xemu_rpc_error = "Guest Kernel RPC refill spans overlap or exceed the active mapping";
            return 0;
        }
        previous_end = parts[n].offset + parts[n].size;
    }
    uint8_t *ram_ptr = memory_region_get_ram_ptr(&xemu_rpc_region);
    for (size_t n = 0; n < count; ++n) {
        memcpy(ram_ptr + XEMU_RPC_ARENA_OFFSET + parts[n].offset,
               parts[n].data, parts[n].size);
        memory_region_set_dirty(&xemu_rpc_region,
                                XEMU_RPC_ARENA_OFFSET + parts[n].offset,
                                parts[n].size);
    }
    /* Exactly one code/translation synchronization for the complete refill. */
    xemu_cheat_notify_code_patch();
    if (!xemu_dbg_flush_guest_translation()) {
        xemu_rpc_error = "could not synchronize Guest Kernel RPC code/data writes";
        return 0;
    }
    return 1;
}

int xemu_guest_rpc_arena_write(uint32_t offset, const void *data, size_t size)
{
    BQL_LOCK_GUARD();
    const XemuGuestRpcArenaWritePart part = { offset, data, size };
    return xemu_guest_rpc_arena_writev(&part, 1);
}

int xemu_guest_rpc_arena_read(uint32_t offset, void *data, size_t size)
{
    BQL_LOCK_GUARD();
    if (!xemu_rpc_mapping_active || !xemu_rpc_mapping_ready || data == NULL ||
        offset > xemu_rpc_active_size || size > xemu_rpc_active_size - offset) {
        xemu_rpc_error = "Guest Kernel RPC arena read is outside the active mapping";
        return 0;
    }
    const uint8_t *ram_ptr = memory_region_get_ram_ptr(&xemu_rpc_region);
    memcpy(data, ram_ptr + XEMU_RPC_ARENA_OFFSET + offset, size);
    return 1;
}

int xemu_guest_rpc_arena_release(void)
{
    BQL_LOCK_GUARD();
    xemu_rpc_error = NULL;
    if (!xemu_rpc_mapping_active) {
        return 1;
    }

    XemuCheatX86Registers regs;
    uint32_t current[XEMU_RPC_MAX_PDES] = {0};
    uint8_t bytes[4];
    if (!xemu_cheat_get_x86_registers(&regs) ||
        (regs.cr3 & 0xfffff000u) != xemu_rpc_mapped_cr3) {
        xemu_rpc_error = "RPC page-directory ownership changed; mapping retained";
        return 0;
    }
    /* Prevalidate BOTH entries before restoring either. An exact original is
     * permitted for a failed installation or a previous partial release. Never
     * erase somebody else's mapping, or lose the still-owned second PDE. */
    for (uint32_t n = 0; n < xemu_rpc_attempted_pdes; ++n) {
        if (address_space_read(&address_space_memory, xemu_rpc_pde_phys[n],
                               MEMTXATTRS_UNSPECIFIED, bytes, 4) != MEMTX_OK) {
            xemu_rpc_error = "RPC page-directory read failed; mapping ownership retained";
            return 0;
        }
        current[n] = ldl_le_p(bytes);
        if (current[n] != xemu_rpc_original_pde[n] &&
            !xemu_rpc_entry_owned(current[n], xemu_rpc_wanted_pde[n])) {
            xemu_rpc_error = "RPC temporary guest PDE could not be safely restored; ownership retained";
            return 0;
        }
    }
    xemu_rpc_mapping_ready = false;
    for (uint32_t n = 0; n < xemu_rpc_attempted_pdes; ++n) {
        if (current[n] == xemu_rpc_original_pde[n]) {
            continue;
        }
        stl_le_p(bytes, xemu_rpc_original_pde[n]);
        if (address_space_write(&address_space_memory, xemu_rpc_pde_phys[n],
                                MEMTXATTRS_UNSPECIFIED, bytes, 4) != MEMTX_OK) {
            xemu_rpc_error = "RPC PDE restoration failed; partial mapping ownership retained";
            return 0;
        }
    }
    if (!xemu_dbg_flush_guest_translation()) {
        xemu_rpc_error = "RPC PDEs restored but translation synchronization failed; ownership retained";
        return 0;
    }

    memset(memory_region_get_ram_ptr(&xemu_rpc_region), 0,
           XEMU_RPC_PT_BYTES + xemu_rpc_active_size);
    memory_region_set_dirty(&xemu_rpc_region, 0,
                            XEMU_RPC_PT_BYTES + xemu_rpc_active_size);
    xemu_rpc_active_size = 0;
    xemu_rpc_mapping_active = false;
    xemu_rpc_virtual_base = 0;
    xemu_rpc_mapped_cr3 = 0;
    xemu_rpc_pde_count = xemu_rpc_attempted_pdes = 0;
    memset(xemu_rpc_pde_phys, 0, sizeof(xemu_rpc_pde_phys));
    memset(xemu_rpc_wanted_pde, 0, sizeof(xemu_rpc_wanted_pde));
    memset(xemu_rpc_original_pde, 0, sizeof(xemu_rpc_original_pde));
    return 1;
}

int xemu_guest_rpc_arena_active(void)
{
    return xemu_rpc_mapping_active ? 1 : 0;
}

const char *xemu_guest_rpc_arena_last_error(void)
{
    return xemu_rpc_error;
}

/* Continuations prove ownership of EVERY PDE and active data-page PTE
 * before refilling/reusing a live buffer, including the second 4 MiB window. */
int xemu_guest_rpc_arena_validate(void)
{
    BQL_LOCK_GUARD();
    XemuCheatX86Registers regs;
    uint8_t bytes[4];
    if (!xemu_rpc_mapping_active || !xemu_rpc_mapping_ready ||
        xemu_rpc_attempted_pdes != xemu_rpc_pde_count ||
        !xemu_cheat_get_x86_registers(&regs) ||
        (regs.cr0 & (1u << 31)) == 0 || (regs.cr4 & (1u << 5)) != 0 ||
        (regs.cr3 & 0xfffff000u) != xemu_rpc_mapped_cr3) {
        return 0;
    }
    for (uint32_t n = 0; n < xemu_rpc_pde_count; ++n) {
        if (address_space_read(&address_space_memory, xemu_rpc_pde_phys[n],
                               MEMTXATTRS_UNSPECIFIED, bytes, 4) != MEMTX_OK ||
            !xemu_rpc_entry_owned(ldl_le_p(bytes), xemu_rpc_wanted_pde[n])) {
            return 0;
        }
    }
    const uint8_t *pt = memory_region_get_ram_ptr(&xemu_rpc_region);
    const uint32_t active_pages = xemu_rpc_active_size / XEMU_RPC_PAGE_SIZE;
    for (uint32_t n = 0; n < active_pages; ++n) {
        const uint32_t wanted = ((uint32_t)xemu_rpc_phys_base +
                                XEMU_RPC_ARENA_OFFSET + n * XEMU_RPC_PAGE_SIZE) | 7u;
        if (!xemu_rpc_entry_owned(ldl_le_p(pt + n * 4u), wanted)) {
            return 0;
        }
    }
    /* Reject an unexpected mapping in the otherwise unmapped tail of a PT. */
    for (uint32_t n = active_pages; n < xemu_rpc_pde_count * 1024u; ++n) {
        if (ldl_le_p(pt + n * 4u) != 0) {
            return 0;
        }
    }
    return 1;
}
