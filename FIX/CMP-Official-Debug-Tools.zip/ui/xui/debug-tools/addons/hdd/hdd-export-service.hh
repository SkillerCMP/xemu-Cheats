//
// Read-only FATX -> host export service for the Xbox HDD browser.
//
// Export owns fresh FATX source re-resolution, host-name sanitization,
// collision-safe destination creation, and recursive byte streaming. It never
// writes to FATX and is intentionally independent from ImGui/HDD window state.
//
#pragma once

#include "../../host-export-result.hh"

#include <cstdint>
#include <string>
#include <vector>

namespace XemuHddExport {

struct Target {
    char partition = '?';
    std::vector<std::string> components;
    bool directory = false;
};

using Result = XemuHostExport::Result;

bool ExportToHost(const Target &target, const std::string &destination,
                  Result &result, std::string &error);

} // namespace XemuHddExport
