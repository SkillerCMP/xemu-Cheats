#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "cheat-engine-memory.h"
#include "guest-kernel-rpc-memory.h"
#include "kernel-rpc-utils.hh"
#include "kernel-rpc-filesystem.hh"
#include "kernel-rpc-stream.hh"

class GuestKernelRpcManager
{
public:
    void Tick();
    void DrawTestPanel();

    // HDD browser operations share the async PASSIVE_LEVEL executor.
    bool PrepareHddDelete(char partition,
                          const std::vector<std::string> &components,
                          bool directory,
                          std::vector<XemuKernelFs::DeleteEntry> &plan,
                          std::string &error);
    bool StartHddDelete(char partition,
                        const std::vector<std::string> &components,
                        bool directory,
                        const std::vector<XemuKernelFs::DeleteEntry> &confirmed_plan,
                        const void *sequence_owner = nullptr);
    bool PrepareHddImport(const std::string &host_path,
                          bool host_is_directory,
                          char partition,
                          const std::vector<std::string> &destination_components,
                          XemuKernelFs::ImportPlan &plan,
                          std::string &error);
    bool PrepareHddCreateDirectory(const std::string &name,
                                   char partition,
                                   const std::vector<std::string> &destination_components,
                                   XemuKernelFs::ImportPlan &plan,
                                   std::string &error);
    bool PrepareHddRename(char partition,
                          const std::vector<std::string> &components,
                          bool directory, const std::string &new_name,
                          XemuKernelFs::RelocatePlan &plan,
                          std::string &error);
    bool PrepareHddMove(char partition,
                        const std::vector<std::string> &components,
                        bool directory,
                        const std::vector<std::string> &destination_parent,
                        XemuKernelFs::RelocatePlan &plan,
                        std::string &error);
    bool StartHddRelocate(const XemuKernelFs::RelocatePlan &plan,
                          const void *sequence_owner = nullptr);
    bool PrepareHddCopy(char source_partition,
                        const std::vector<std::string> &source_components,
                        bool source_directory, char destination_partition,
                        const std::vector<std::string> &destination_components,
                        bool delete_source_after_copy,
                        XemuKernelFs::ImportPlan &plan, std::string &error);
    bool StartHddImport(const XemuKernelFs::ImportPlan &plan,
                        const void *sequence_owner = nullptr);
    struct HddOperationProgress {
        bool active = false;
        std::string label;
        std::string current_path;
        uint64_t completed_operations = 0;
        uint64_t total_operations = 0;
        uint64_t completed_bytes = 0;
        uint64_t total_bytes = 0;
        uint32_t completed_files = 0;
        uint32_t total_files = 0;
        uint32_t completed_directories = 0;
        uint32_t total_directories = 0;
        uint64_t elapsed_ms = 0;
        uint64_t safe_point_samples = 0;
        bool fast_stream = false;
        uint32_t chunk_bytes = 0;
        uint64_t rpc_calls=0, open_calls=0, write_calls=0, flush_calls=0, close_calls=0;
        uint64_t wait_ms=0, rpc_ms=0, source_ms=0, refill_ms=0, verify_ms=0;
        std::string transfer_phase;
    };

    // Sequence owners may chain the existing create-only Import / Rename
    // primitives without another frontend stealing their completion state.
    // UI-side OperationBusy includes the lease; the executor's own Tick does not.
    bool ClaimFilesystemSequence(const void *owner, std::string &reason,
                                 bool cancellable_wait = false, bool fast_stream = false,
                                 uint32_t stream_chunk_bytes = XemuKernelStream::kChunkBytes);
    // Only the owning frontend can cancel. In-flight kernel calls are allowed
    // to return/verify/clean up; cancellation never unwinds a live FATX stack.
    bool CancelFilesystemOperation(const void *owner, const std::string &reason);
    void ReleaseFilesystemSequence(const void *owner);
    bool OperationBusy() const { return IsBusy() || m_sequence_owner != nullptr; }
    bool FilesystemOperationRunning() const { return IsBusy(); }
    bool LastFilesystemOperationSucceeded() const { return m_state == State::Passed; }
    bool LastImportContentsVerified() const { return m_state == State::Passed && m_stream_contents_verified; }
    // Keep the original frontend API; only a claimed sequence uses the overload.
    bool FilesystemReady(std::string &reason) const { return FilesystemReady(reason, nullptr); }
    bool FilesystemReady(std::string &reason, const void *sequence_owner) const;
    HddOperationProgress GetHddOperationProgress() const;
    const std::string &Status() const { return m_status; }

private:
    enum class State {
        Idle,
        Running,
        WaitingSafePoint,
        RunningFsQuery,
        VerifyingImport,
        Passed,
        Failed,
    };

    enum class FsTestMode {
        None,
        SingleReadOnlyFile,
        NamespaceDiagnostics,
        KernelDeleteRecursiveFolder,
        KernelImportFolder,
        KernelRelocate,
    };

    // Production HDD operation identity is kept separate from the low-level
    // RPC test mode. This prevents Copy/Move/Delete frontend state from being
    // represented by unrelated booleans that can leak across transactions.
    enum class FilesystemOperationKind {
        None,
        Delete,
        HostImport,
        NewFolder,
        FatxCopy,
        Rename,
        SameVolumeMove,
        CrossVolumeMove,
    };

    enum class FilesystemOperationPhase {
        Idle,
        Preparing,
        WaitingSafePoint,
        DeletingSource,
        Complete,
        Failed,
    };

    struct FilesystemOperationContext {
        FilesystemOperationKind kind = FilesystemOperationKind::None;
        FilesystemOperationPhase phase = FilesystemOperationPhase::Idle;
    };

    struct PathDiagnostic {
        std::string label;
        std::string path;
        uint32_t root_directory = 0;
        uint32_t ntstatus = 0xccccccccu;
        uint64_t file_size = 0;
        uint32_t attributes = 0;
        uint32_t safe_samples = 0;
        bool completed = false;
        bool query_ran = false;
    };

    // Filesystem plan entries are shared with the HDD browser preflight layer.
    using RecursiveDeleteEntry = XemuKernelFs::DeleteEntry;
    using TransferEntry = XemuKernelFs::TransferEntry;

    const void *m_sequence_owner = nullptr;
    bool m_sequence_cancellable_wait = false;
    bool m_sequence_fast_stream = false;
    uint32_t m_sequence_stream_chunk_bytes = XemuKernelStream::kChunkBytes;
    uintptr_t m_sequence_hdd_identity = 0;
    bool m_filesystem_cancel_requested = false;
    std::string m_filesystem_cancel_reason;
    unsigned int m_import_burst_operations = 0;
    uint64_t m_import_burst_started_ms = 0;
    bool CancelAtSafeBoundary();
    bool SequenceAllows(const void *owner) const
    {
        return m_sequence_owner == nullptr ? owner == nullptr
                                           : m_sequence_owner == owner;
    }
    State m_state = State::Idle;
    FsTestMode m_fs_test_mode = FsTestMode::None;
    std::string m_status = "Not tested.";
    XemuCheatX86Registers m_saved = {};
    XemuGuestRpcArenaInfo m_arena = {};
    uint32_t m_export_address = 0;
    uint32_t m_query_export_address = 0;
    uint32_t m_stub_address = 0;
    uint32_t m_completion_address = 0;
    uint32_t m_result_offset = 0x1000u;
    uint32_t m_irql = 0xffffffffu;
    bool m_was_running = false;
    bool m_breakpoint_installed = false;
    uint64_t m_started_ms = 0;
    uint64_t m_hdd_operation_started_ms = 0;
    uint64_t m_hdd_operation_safe_samples = 0;

    char m_fs_partition = 'E';
    FilesystemOperationContext m_filesystem_operation;
    bool m_hdd_delete_root_directory = false;
    std::string m_fs_path;
    std::string m_fs_area;
    std::string m_fs_title_directory;
    std::string m_fs_relative_path;
    uint32_t m_fs_title_id = 0;
    uint64_t m_expected_file_size = 0;
    uint32_t m_expected_attributes = 0;
    uint64_t m_kernel_file_size = 0;
    uint32_t m_kernel_attributes = 0;
    uint32_t m_query_status = 0xccccccccu;
    uint32_t m_query_ran = 0;
    uint32_t m_safe_point_attempts = 0;
    uint32_t m_last_sample_eip = 0;
    uint64_t m_safe_point_started_ms = 0;
    uint64_t m_next_safe_point_sample_ms = 0;

    std::string m_query_path;
    uint32_t m_query_root_directory = 0xfffffffdu;
    uint16_t m_query_ansi_length = 0;
    uint16_t m_query_ansi_maximum = 0;
    uint32_t m_query_ansi_buffer = 0;
    uint32_t m_query_object_name = 0;
    uint32_t m_query_object_attributes = 0x40u;
    std::vector<PathDiagnostic> m_path_diagnostics;
    size_t m_path_diagnostic_index = 0;

    uint32_t m_delete_open_export_address = 0;
    uint32_t m_delete_setinfo_export_address = 0;
    uint32_t m_delete_close_export_address = 0;
    uint32_t m_delete_open_status = 0xccccccccu;
    uint32_t m_delete_setinfo_status = 0xccccccccu;
    uint32_t m_delete_close_status = 0xccccccccu;
    uint32_t m_delete_operation_ran = 0;
    bool m_delete_current_is_directory = false;

    std::vector<RecursiveDeleteEntry> m_recursive_delete_plan;
    size_t m_recursive_delete_index = 0;
    uint32_t m_recursive_deleted_files = 0;
    uint32_t m_recursive_deleted_directories = 0;


    XemuKernelFs::TransferPlan m_import_preflight;
    size_t m_import_plan_index = 0;
    uint64_t m_import_file_offset = 0;
    std::vector<uint8_t> m_import_chunk;
    XemuKernelFs::ImportHostStream m_import_host_stream;
    uint32_t m_import_current_chunk_bytes = 0;
    uint64_t m_import_written_bytes = 0;
    uint64_t m_import_current_source_hash = XemuKernelFs::kContentHashBasis;
    uint32_t m_import_completed_files = 0;
    uint32_t m_import_completed_directories = 0;
    uint64_t m_import_completed_operations = 0;
    bool m_import_current_is_directory = false;
    uint32_t m_import_create_disposition = 0;
    uint32_t m_import_create_export_address = 0;
    uint32_t m_import_write_export_address = 0;
    uint32_t m_import_flush_export_address = 0;
    uint32_t m_import_close_export_address = 0;
    uint32_t m_import_create_status = 0xccccccccu;
    uint32_t m_import_write_status = 0xccccccccu;
    uint32_t m_import_flush_status = 0xccccccccu;
    uint32_t m_import_close_status = 0xccccccccu;
    uint32_t m_import_operation_ran = 0;
    uint32_t m_import_write_information = 0;

    // CSB-only single-file stream. Do not discard an owned/pending handle.
    bool m_import_fast_stream = false;
    bool m_stream_session = false;
    bool m_stream_contents_verified = false;
    uint32_t m_stream_handle = 0;
    uintptr_t m_stream_hdd_identity = 0;
    XemuKernelStream::Action m_stream_action = XemuKernelStream::Action::OpenWrite;
    HddOperationProgress m_stream_metrics;
    uint64_t m_stream_wait_started_ms=0, m_stream_finished_ms=0;
    std::string m_stream_abort_reason;
    bool BeginFastImportAttempt();
    bool SendStreamCall(XemuKernelStream::Action action);
    void HandleFastImportCompletion(const XemuCheatX86Registers &after);
    void VerifyFastImport();
    void CloseFailedStream(const std::string &reason);
    void FailStreamUnsafe(const std::string &reason);
    bool StreamSourceMatches() const;
    bool StreamCompletionContext(std::string &error) const;

    XemuKernelFs::RelocatePlan m_relocate_plan;

    bool IsHddFrontendOperation() const
    {
        return m_filesystem_operation.kind != FilesystemOperationKind::None;
    }
    bool IsCrossVolumeMoveDeletePhase() const
    {
        return m_filesystem_operation.kind == FilesystemOperationKind::CrossVolumeMove &&
               m_filesystem_operation.phase == FilesystemOperationPhase::DeletingSource;
    }
    void ResetFilesystemOperationContext()
    {
        if (!m_stream_session && !m_stream_handle) {
            m_import_fast_stream = false; m_stream_contents_verified = false;
            m_stream_metrics = {}; m_stream_wait_started_ms = m_stream_finished_ms = 0;
            m_stream_abort_reason.clear();
        }
        m_filesystem_operation = {};
        m_filesystem_cancel_requested = false;
        m_filesystem_cancel_reason.clear();
        m_import_burst_operations = 0;
        m_import_burst_started_ms = 0;
    }

    bool StartIrqlTest();
    bool StartReadOnlyFsTest();
    bool StartPathDiagnostics();
    bool LoadRecursiveDeleteEntry(size_t index, std::string &error);
    bool LoadKernelImportOperation(std::string &error);
    bool BeginReadOnlyFsAttempt();
    bool ResolveKernelDeleteExports(std::string &error);
    bool ResolveKernelImportExports(std::string &error);
    bool BeginKernelDeleteAttempt();
    bool BeginKernelImportAttempt();
    void ContinueImportBurst();
    void ResumeAfterImportBurst();
    bool BeginKernelRelocateAttempt();
    void TickWaitingSafePoint();
    void HandleIrqlCompletion(const XemuCheatX86Registers &after);
    void HandleReadOnlyFsCompletion(const XemuCheatX86Registers &after);
    void HandleKernelDeleteCompletion(const XemuCheatX86Registers &after);
    void HandleKernelImportCompletion(const XemuCheatX86Registers &after);
    void HandleKernelRelocateCompletion(const XemuCheatX86Registers &after);
    bool CleanupAttemptForRetry(std::string &error, bool resume = true);
    bool PrepareReadOnlyTarget(std::string &error);
    bool BuildPathDiagnostics(std::string &error);
    void ActivatePathDiagnostic(size_t index);
    void CompletePathDiagnostic(const XemuKernelRpc::FileNetworkOpenResult &parsed);
    bool ValidateCapturedContext(const XemuCheatX86Registers &regs,
                                 std::string &error) const;
    bool IsTitleExecutionPoint(uint32_t eip) const;
    bool IsBusy() const;

    void AbortBeforeRun(const std::string &message, bool restore_context);
    void Finish(bool success, const std::string &message,
                bool resume_original_state);
    bool RestoreSavedContext();
    static bool PreservedStateMatches(const XemuCheatX86Registers &before,
                                      const XemuCheatX86Registers &after,
                                      std::string &difference);
    static bool PreservedFilesystemStateMatches(
        const XemuCheatX86Registers &before,
        const XemuCheatX86Registers &after, std::string &difference);
};

extern GuestKernelRpcManager guest_kernel_rpc_manager;
