//
// xemu Debug Tools integration facade
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
#pragma once

#include <SDL3/SDL.h>
#include <string>
#include <vector>

// These are the only normal xui-facing Debug Tools entry points. Optional
// additions register with this facade instead of adding their own hooks to
// upstream xemu UI files.
using DebugToolsBackgroundJobCallback = void (*)(void *opaque);

void debug_tools_init(SDL_Window *main_window, void *main_gl_context);
void debug_tools_precreate_detached_windows();
void debug_tools_cleanup();
bool debug_tools_process_sdl_event(SDL_Event *event);
bool debug_tools_owns_window_id(SDL_WindowID window_id);

bool debug_tools_queue_background_job(
    DebugToolsBackgroundJobCallback work, void *opaque,
    DebugToolsBackgroundJobCallback completion = nullptr,
    bool preserve_gamepad_input_while_unfocused = false);
bool debug_tools_background_worker_is_running();
unsigned int debug_tools_background_worker_pending_jobs();
bool debug_tools_external_input_lease_active();

void debug_tools_tick();
void debug_tools_draw_menu_items();
void debug_tools_build_unlocked_detached_frames();
void debug_tools_render_detached_frames();
void debug_tools_process_deferred_actions();
void debug_tools_notify_game_reset();
bool debug_tools_cheat_overlay_available();
void debug_tools_get_active_cheat_details(std::vector<std::string> &names,
                                          std::vector<std::string> &credits,
                                          std::vector<std::string> &groups);
