//
// xemu Debug Tools integration facade / module registry
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "debug-tools.hh"
#include "debug-tools-module.hh"

#include "../common.hh"
#include "cheat-engine.hh"
#include "current-game.hh"
#include "detached-tools.hh"
#include "addons/diagnostics/bql-trace-hook.h"

#include <algorithm>
#include <cstdint>
#include <glib.h>
#include <vector>

namespace {

template <typename T>
void StableSortByOrder(std::vector<T> &items)
{
    std::stable_sort(items.begin(), items.end(),
                     [](const T &a, const T &b) { return a.order < b.order; });
}

struct OrderedCallback {
    int order = 0;
    DebugToolsCallback callback = nullptr;
};

struct MenuItemRegistration {
    int order = 0;
    const char *label = nullptr;
    bool *open = nullptr;
};

struct CurrentGameExtensionRegistration {
    int order = 0;
    DebugToolsCurrentGameTabsCallback draw_tabs = nullptr;
    DebugToolsCallback draw_footer = nullptr;
};

struct BackgroundJob {
    DebugToolsBackgroundJobCallback work = nullptr;
    void *opaque = nullptr;
    DebugToolsBackgroundJobCallback completion = nullptr;
    bool preserve_gamepad_input_while_unfocused = false;
};

std::vector<OrderedCallback> g_tick_callbacks;
std::vector<OrderedCallback> g_reset_callbacks;
std::vector<OrderedCallback> g_deferred_callbacks;
std::vector<MenuItemRegistration> g_menu_items;
std::vector<CurrentGameExtensionRegistration> g_current_game_extensions;
GAsyncQueue *g_background_jobs = nullptr;
GAsyncQueue *g_background_completions = nullptr;
GThread *g_background_thread = nullptr;
gint g_background_worker_running = 0;
BackgroundJob g_background_stop_job;
SDL_Window *g_main_window = nullptr;
bool g_external_input_lease_active = false;
bool g_external_input_original = false;
unsigned int g_external_input_job_count = 0;
bool g_external_input_focus_lost_seen = false;
uint64_t g_external_input_completion_ms = 0;
bool g_initialized = false;

void RestoreExternalInputLease()
{
    if (!g_external_input_lease_active) {
        return;
    }
    SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS,
                g_external_input_original ? "1" : "0");
    g_external_input_lease_active = false;
    g_external_input_job_count = 0;
    g_external_input_focus_lost_seen = false;
    g_external_input_completion_ms = 0;
}

void BeginExternalInputLease()
{
    if (!g_external_input_lease_active) {
        g_external_input_original = SDL_GetHintBoolean(
            SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, false);
        SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "1");
        g_external_input_lease_active = true;
        g_external_input_focus_lost_seen = false;
        g_external_input_completion_ms = 0;
    }
    ++g_external_input_job_count;
}

void FinishExternalInputLease()
{
    if (!g_external_input_lease_active) {
        return;
    }
    if (g_external_input_job_count > 0) {
        --g_external_input_job_count;
    }
    if (g_external_input_job_count != 0) {
        return;
    }

    /* Process launch can return before the new application actually takes
     * foreground focus. Keep the lease through a short grace period; if xemu
     * observes focus loss, retain it until the main window gains focus again. */
    g_external_input_completion_ms = SDL_GetTicks();
}

void MaybeRestoreExternalInputLease()
{
    if (!g_external_input_lease_active || g_external_input_job_count != 0 ||
        g_external_input_focus_lost_seen || g_external_input_completion_ms == 0) {
        return;
    }
    if (SDL_GetTicks() - g_external_input_completion_ms >= 3000) {
        RestoreExternalInputLease();
    }
}

void ProcessBackgroundCompletions()
{
    if (!g_background_completions) {
        return;
    }
    while (auto *job = static_cast<BackgroundJob *>(
               g_async_queue_try_pop(g_background_completions))) {
        if (job->completion) {
            job->completion(job->opaque);
        }
        if (job->preserve_gamepad_input_while_unfocused) {
            FinishExternalInputLease();
        }
        delete job;
    }
}

gpointer BackgroundWorkerMain(gpointer)
{
    g_atomic_int_set(&g_background_worker_running, 1);
    for (;;) {
        auto *job = static_cast<BackgroundJob *>(
            g_async_queue_pop(g_background_jobs));
        if (job == &g_background_stop_job) {
            break;
        }
        if (job->work) {
            job->work(job->opaque);
        }
        if (job->completion || job->preserve_gamepad_input_while_unfocused) {
            g_async_queue_push(g_background_completions, job);
        } else {
            delete job;
        }
    }
    g_atomic_int_set(&g_background_worker_running, 0);
    return nullptr;
}

void StartBackgroundWorker()
{
    if (g_background_thread) {
        return;
    }
    g_background_jobs = g_async_queue_new();
    g_background_completions = g_async_queue_new();
    GError *error = nullptr;
    g_background_thread = g_thread_try_new(
        "xemu-debug-worker", BackgroundWorkerMain, nullptr, &error);
    if (!g_background_thread) {
        if (error) {
            g_error_free(error);
        }
        g_async_queue_unref(g_background_jobs);
        g_async_queue_unref(g_background_completions);
        g_background_jobs = nullptr;
        g_background_completions = nullptr;
    }
}

void StopBackgroundWorker()
{
    if (!g_background_thread) {
        RestoreExternalInputLease();
        return;
    }

    g_async_queue_push(g_background_jobs, &g_background_stop_job);
    g_thread_join(g_background_thread);
    g_background_thread = nullptr;

    /* The stop sentinel is queued after all accepted jobs, so their worker
     * phases are complete here. Run UI completions before destroying queues. */
    ProcessBackgroundCompletions();
    g_async_queue_unref(g_background_jobs);
    g_async_queue_unref(g_background_completions);
    g_background_jobs = nullptr;
    g_background_completions = nullptr;
    RestoreExternalInputLease();
}

void DrawCheatEngineDetached()
{
    cheat_engine_window.Draw(true);
}

void DrawCurrentGameDetached()
{
    current_game_manager.Draw(true);
}

void RefreshCurrentGame()
{
    current_game_manager.Tick();
}

void TickCheatEngine()
{
    cheat_engine_window.Tick();
}

void NotifyCheatEngineReset()
{
    cheat_engine_window.NotifyGameResetRequested();
}

void RegisterMainAddition()
{
    /* Info: Keep optional Debug menu items in stable order. */    debug_tools_register_menu_item(100, "Current Game",
                                   &current_game_manager.is_open);
    debug_tools_register_menu_item(300, "Cheat Engine",
                                   &cheat_engine_window.is_open);

    /* Info: Keep optional Debug Tools ticks in stable order. */    debug_tools_register_tick(200, RefreshCurrentGame);
    debug_tools_register_tick(300, TickCheatEngine);

    /* Info: Memory Tools reset runs before Cheat Engine reset handling. */    debug_tools_register_reset(200, NotifyCheatEngineReset);

    detached_tools_register({
        "xemu - Current Game",
        900, 620,
        700, 480,
        &current_game_manager.is_open,
        DrawCurrentGameDetached,
        100,
        false,
    });
    detached_tools_register({
        "xemu - RAW Cheat Engine",
        980, 760,
        720, 520,
        &cheat_engine_window.is_open,
        DrawCheatEngineDetached,
        300,
        false,
    });
}

void FinalizeRegistrations()
{
    StableSortByOrder(g_tick_callbacks);
    StableSortByOrder(g_reset_callbacks);
    StableSortByOrder(g_deferred_callbacks);
    StableSortByOrder(g_menu_items);
    StableSortByOrder(g_current_game_extensions);
    detached_tools_finalize_registry();
}

void ClearRegistrations()
{
    g_tick_callbacks.clear();
    g_reset_callbacks.clear();
    g_deferred_callbacks.clear();
    g_menu_items.clear();
    g_current_game_extensions.clear();
    detached_tools_clear_registry();
}

} // namespace

void debug_tools_register_tick(int order, DebugToolsCallback callback)
{
    if (callback) {
        g_tick_callbacks.push_back({order, callback});
    }
}

void debug_tools_register_reset(int order, DebugToolsCallback callback)
{
    if (callback) {
        g_reset_callbacks.push_back({order, callback});
    }
}

void debug_tools_register_deferred_action(int order,
                                          DebugToolsCallback callback)
{
    if (callback) {
        g_deferred_callbacks.push_back({order, callback});
    }
}

void debug_tools_register_menu_item(int order, const char *label, bool *open)
{
    if (label && open) {
        g_menu_items.push_back({order, label, open});
    }
}

void debug_tools_register_current_game_extension(
    int order,
    DebugToolsCurrentGameTabsCallback draw_tabs,
    DebugToolsCallback draw_footer)
{
    if (draw_tabs || draw_footer) {
        g_current_game_extensions.push_back({order, draw_tabs, draw_footer});
    }
}

void debug_tools_init(SDL_Window *main_window, void *main_gl_context)
{
    if (g_initialized) {
        return;
    }

    ClearRegistrations();
    RegisterMainAddition();

    // Optional additions hook only the Debug Tools module API. Meson supplies
    // real registration units for enabled additions and tiny no-op stubs for
    // disabled additions, so upstream xemu never needs feature-specific code.
    debug_tools_register_hdd_addition();
    debug_tools_register_memory_tools_addition();
    debug_tools_register_diagnostics_addition();

    FinalizeRegistrations();
    detached_tools_init(main_window, main_gl_context);
    g_main_window = main_window;
    StartBackgroundWorker();
    g_initialized = true;
}

void debug_tools_precreate_detached_windows()
{
    if (g_initialized) {
        detached_tools_precreate_windows();
    }
}

void debug_tools_cleanup()
{
    StopBackgroundWorker();
    if (!g_initialized) {
        g_main_window = nullptr;
        return;
    }
    detached_tools_cleanup();
    ClearRegistrations();
    g_main_window = nullptr;
    g_initialized = false;
}

bool debug_tools_process_sdl_event(SDL_Event *event)
{
    if (event && g_external_input_lease_active && g_main_window &&
        event->window.windowID == SDL_GetWindowID(g_main_window)) {
        if (event->type == SDL_EVENT_WINDOW_FOCUS_LOST) {
            g_external_input_focus_lost_seen = true;
        } else if (event->type == SDL_EVENT_WINDOW_FOCUS_GAINED &&
                   g_external_input_job_count == 0 &&
                   g_external_input_focus_lost_seen) {
            RestoreExternalInputLease();
        }
    }
    return detached_tools_process_sdl_event(event);
}

bool debug_tools_owns_window_id(SDL_WindowID window_id)
{
    return detached_tools_owns_window_id(window_id);
}

bool debug_tools_queue_background_job(
    DebugToolsBackgroundJobCallback work, void *opaque,
    DebugToolsBackgroundJobCallback completion,
    bool preserve_gamepad_input_while_unfocused)
{
    if (!work || !g_background_jobs || !g_background_thread) {
        return false;
    }

    if (preserve_gamepad_input_while_unfocused) {
        BeginExternalInputLease();
    }

    auto *job = new BackgroundJob{
        work, opaque, completion, preserve_gamepad_input_while_unfocused};
    g_async_queue_push(g_background_jobs, job);
    return true;
}

bool debug_tools_background_worker_is_running()
{
    return g_background_thread != nullptr;
}

unsigned int debug_tools_background_worker_pending_jobs()
{
    if (!g_background_jobs) {
        return 0;
    }
    const gint length = g_async_queue_length(g_background_jobs);
    return length > 0 ? static_cast<unsigned int>(length) : 0;
}

bool debug_tools_external_input_lease_active()
{
    return g_external_input_lease_active;
}

void debug_tools_tick()
{
    for (const OrderedCallback &entry : g_tick_callbacks) {
        entry.callback();
    }
}

void debug_tools_draw_menu_items()
{
    for (const MenuItemRegistration &entry : g_menu_items) {
        if (ImGui::MenuItem(entry.label, nullptr, *entry.open)) {
            detached_tools_open_or_focus(entry.open);
        }
    }
}

void debug_tools_build_unlocked_detached_frames()
{
    detached_tools_build_unlocked_frames();
}

void debug_tools_render_detached_frames()
{
    detached_tools_render_frames();
}

void debug_tools_process_deferred_actions()
{
    ProcessBackgroundCompletions();
    MaybeRestoreExternalInputLease();
    for (const OrderedCallback &entry : g_deferred_callbacks) {
        entry.callback();
    }
}

void debug_tools_notify_game_reset()
{
    for (const OrderedCallback &entry : g_reset_callbacks) {
        entry.callback();
    }
}

void debug_tools_draw_current_game_extension_tabs(uint32_t title_id)
{
    for (const CurrentGameExtensionRegistration &entry :
         g_current_game_extensions) {
        if (entry.draw_tabs) {
            entry.draw_tabs(title_id);
        }
    }
}

void debug_tools_draw_current_game_extension_footer()
{
    for (const CurrentGameExtensionRegistration &entry :
         g_current_game_extensions) {
        if (entry.draw_footer) {
            entry.draw_footer();
        }
    }
}
