// Confirmed code deletion. Keep unaffected active hooks and PREENTRY state alive:
// reparsing the whole file here would restore every hook and lose applied state.
#include "cheat-engine.hh"
#include "cheat-source-file.hh"
#include "guest-pause-guard.hh"
#include <algorithm>
#include <memory>
#include <sstream>

bool CheatEngineWindow::DeleteCodeFromSource(
    size_t index, uint64_t revision, const std::string &path, std::string &error)
{
    error.clear();
    if (revision != m_source_revision || path != m_loaded_path ||
        index >= m_blocks.size()) {
        error = "The loaded source changed. Select the code again; nothing was deleted.";
        return false;
    }
    const auto &target = m_blocks[index];
    const size_t begin = target.source_begin, end = target.source_end;
    if (begin == std::string::npos || end <= begin || end > m_source.size()) {
        error = "This entry has no explicit +Code source range. Edit its TXT directly.";
        return false;
    }
    // A malformed source span may not cross another header or a group boundary.
    std::istringstream span(m_source.substr(begin, end - begin));
    std::string line;
    size_t headers = 0;
    while (std::getline(span, line)) {
        const std::string text = Trim(line);
        if (text.empty()) continue;
        if (text[0] == '+') ++headers;
        if (text[0] == '!' || text[0] == '^' || headers > 1) {
            error = "The definition range crosses a group/header boundary; deletion refused.";
            return false;
        }
    }
    if (headers != 1 || !XemuCheatSource::ReadUnchanged(path, m_source, error)) return false;

    // Parse the candidate in an isolated, hook-free object before touching the
    // guest or disk. This refreshes diagnostics and proves no neighbour's
    // executable definition was changed by the source-range removal.
    std::string next_source = m_source;
    next_source.erase(begin, end - begin);
    CheatEngineWindow parsed;
    parsed.m_source = next_source;
    parsed.ParseSource(false);
    if (parsed.m_blocks.size() + 1 != m_blocks.size()) {
        error = "Removing this range would change neighbouring definitions; deletion refused.";
        return false;
    }
    for (size_t i = 0; i < parsed.m_blocks.size(); ++i) {
        const auto &before = m_blocks[i < index ? i : i + 1];
        const auto &after = parsed.m_blocks[i];
        bool same = before.name == after.name && before.group_path == after.group_path &&
                    before.preentry == after.preentry && before.codes.size() == after.codes.size() &&
                    before.parse_error == after.parse_error;
        for (size_t c = 0; same && c < before.codes.size(); ++c) {
            const auto &a = before.codes[c];
            const auto &b = after.codes[c];
            same = a.command == b.command && a.value == b.value &&
                   a.f_terminated == b.f_terminated &&
                   a.f_final_valid_bytes == b.f_final_valid_bytes && a.f_body.size() == b.f_body.size();
            for (size_t j = 0; same && j < a.f_body.size(); ++j) same = a.f_body[j].text == b.f_body[j].text;
        }
        if (!same) {
            error = "Removing this range would change a neighbouring code; deletion refused.";
            return false;
        }
    }
    bool have_hook = false;
    for (const auto &item : m_f_hooks)
        if (item.second.owner_block == index && item.second.installed) have_hook = true;
    std::unique_ptr<XemuDebugGuestPauseGuard> pause;
    if (have_hook) {
        pause = std::make_unique<XemuDebugGuestPauseGuard>();
        if (!pause->IsValid()) {
            error = "Could not safely pause the guest to restore this code's hooks.";
            return false;
        }
    }
    DeactivateFHooksForBlock(index);
    for (const auto &item : m_f_hooks) {
        if (item.second.owner_block == index && item.second.installed) {
            error = "Could not restore an active hook. The TXT and code entry were not deleted.";
            return false;
        }
    }

    // Prepare all allocating state updates BEFORE committing the disk write.
    const int removed_lines = static_cast<int>(
        std::count(m_source.begin() + begin, m_source.begin() + end, '\n'));
    auto next_blocks = m_blocks;
    const bool reset_required = target.enabled || target.preentry_applied || have_hook;
    const std::string removed_name = target.name;
    next_blocks.erase(next_blocks.begin() + index);
    auto next_groups = m_groups;
    for (auto &group : next_groups) {
        auto &codes = group.cheats;
        codes.erase(std::remove(codes.begin(), codes.end(), index), codes.end());
        for (auto &i : codes) if (i > index) --i;
    }
    std::unordered_map<std::string, uint32_t> occurrences;
    auto next_preentry = m_selected_preentry_keys;
    const std::string prefix = m_loaded_path + "\n";
    for (auto it = next_preentry.begin(); it != next_preentry.end();) {
        if (it->compare(0, prefix.size(), prefix) == 0) it = next_preentry.erase(it);
        else ++it;
    }
    for (auto &block : next_blocks) {
        if (block.source_begin != std::string::npos && block.source_begin >= end) {
            block.source_begin -= end - begin;
            block.source_end -= end - begin;
            if (block.parse_error_line > 0) block.parse_error_line -= removed_lines;
            for (auto &code : block.codes) {
                code.source_line -= removed_lines;
                if (code.f_precompile_error_line > 0) code.f_precompile_error_line -= removed_lines;
                for (auto &src : code.f_body) src.source_line -= removed_lines;
            }
        }
        if (!block.parse_error.empty() ||
            (block.f_preparation_attempted && !block.f_preparation_ok)) {
            // Re-publish the cached failure with its new source line number.
            PrepareBlockTypeF(block);
            if (block.preentry && !block.preentry_error.empty())
                block.preentry_error = block.runtime_error;
        }
        block.identity_ordinal = occurrences[block.group_path + "\n" + block.name]++;
        if (block.preentry && block.selected) next_preentry.insert(BlockIdentityKey(block));
    }
    auto remap_key = [&](uint64_t key) {
        const size_t owner = (size_t)(key >> 32);
        return owner > index ? key - (UINT64_C(1) << 32) : key;
    };
    std::unordered_map<uint64_t, FHookState> next_hooks;
    next_hooks.reserve(m_f_hooks.size());
    for (const auto &item : m_f_hooks) {
        auto state = item.second;
        if (state.owner_block == index) continue;
        uint64_t key = item.first;
        if (key != kDebuggerFHookKey && state.owner_block < m_blocks.size()) {
            key = remap_key(key);
            if (state.owner_block > index) --state.owner_block;
        }
        next_hooks.emplace(key, std::move(state));
    }
    std::unordered_map<uint64_t, SwitchState> next_switches;
    next_switches.reserve(m_switches.size());
    for (const auto &item : m_switches) {
        if ((size_t)(item.first >> 32) != index)
            next_switches.emplace(remap_key(item.first), item.second);
    }
    std::string next_runtime_error, next_preentry_error;
    for (const auto &block : next_blocks) {
        if (!block.preentry && !block.runtime_error.empty() && next_runtime_error.empty())
            next_runtime_error = block.name + ": " + block.runtime_error;
        if (block.preentry && !block.preentry_error.empty() && next_preentry_error.empty())
            next_preentry_error = block.name + ": " + block.preentry_error;
    }
    if (!XemuCheatSource::Replace(path, m_source, next_source, error)) return false;
    m_source.swap(next_source);
    m_blocks.swap(next_blocks);
    m_groups.swap(next_groups);
    m_parse_messages.swap(parsed.m_parse_messages);
    m_last_runtime_message.swap(next_runtime_error);
    m_last_preentry_message.swap(next_preentry_error);
    m_f_hooks.swap(next_hooks);
    m_switches.swap(next_switches);
    m_selected_preentry_keys.swap(next_preentry);
    for (auto &state : m_retired_f_hooks) {
        if (state.owner_block == index) state.owner_block = (size_t)-2;
        else if (state.owner_block > index && state.owner_block < m_blocks.size() + 1)
            --state.owner_block;
    }
    m_active_f_hooks_scratch.clear();
    m_f_deactivate_scratch.clear();
    InvalidateFTempBankCache();
    ++m_source_revision;
    m_deleted_code_reset_required |= reset_required;
    pause.reset();
    m_file_status = "Deleted '" + removed_name + "'.";
    if (reset_required) m_file_status += " Reset required to clear prior game-state writes.";
    SavePersistentState();
    return true;
}
