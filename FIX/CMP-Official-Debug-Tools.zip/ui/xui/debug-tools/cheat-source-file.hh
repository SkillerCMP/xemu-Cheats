// Host-only, compare-before-write transaction for deleting a cheat definition.
#pragma once
#include <string>

namespace XemuCheatSource {
bool ReadUnchanged(const std::string &path, const std::string &expected,
                   std::string &error);
// On success, path contains replacement. GLib stages a same-directory temporary
// file and renames it consistently; no persistent per-delete backup is created.
// On failure the caller must keep its in-memory definitions.
bool Replace(const std::string &path, const std::string &expected,
             const std::string &replacement, std::string &error);
}
