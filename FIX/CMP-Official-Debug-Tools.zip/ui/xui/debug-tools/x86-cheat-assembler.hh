//
// xemu RAW Cheat Engine - Type-F0/F2 32-bit x86 code-cave frontends
//
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

struct XemuCheatAsmLine {
    int source_line = 0;
    std::string text;
};

struct XemuCheatAsmResult {
    bool ok = false;
    int error_line = 0;
    std::string error;
    /* Executable bytes before DEADCODE's generated return JMP. */
    std::vector<uint8_t> bytes;
    /* Static DD data. InstallFHook places this immediately after the generated
     * 5-byte DEADCODE return JMP, and labels resolve to that final location. */
    std::vector<uint8_t> data;
    bool uses_preserve = false;
    /* Info: One preserve block holds a header plus 16 nested 48-byte frames. */
    uint32_t preserve_bytes = 0;
    bool uses_temp = false;
    /* Info: T0-T7 use a private 40-byte state bank in 0x680F0000-0x680FFFFF. */
    uint32_t temp_bytes = 0;
};

/* Info: Assemble F0 IA-32 with hex-first literals, labels/DD, PRESERVE/RESTORE, T0-T7 and TFLAGS; zero bases are sizing probes. */
bool xemu_cheat_assemble_x86_32_at(const std::vector<XemuCheatAsmLine> &lines,
                                   uint32_t cave_base,
                                   uint32_t preserve_base,
                                   uint32_t temp_base,
                                   XemuCheatAsmResult &result);

/* Info: Assemble Type-F2 literal x86 bytes with relocatable labels and DD data.
 * Raw hex bytes are emitted exactly as typed; DD values are little-endian.
 * cave_base=0 selects the normal Type-F sizing/probe neighborhood. */
bool xemu_cheat_assemble_f2_raw_at(const std::vector<XemuCheatAsmLine> &lines,
                                   uint32_t cave_base,
                                   XemuCheatAsmResult &result);

/* Info: Assemble one Inject > Change instruction at its real guest EIP. */
bool xemu_cheat_assemble_x86_32_change_instruction(
    const std::string &instruction, uint32_t address, size_t max_size,
    XemuCheatAsmResult &result);

/* Info: Default sizing/probe entry point. */
bool xemu_cheat_assemble_x86_32(const std::vector<XemuCheatAsmLine> &lines,
                                XemuCheatAsmResult &result);
