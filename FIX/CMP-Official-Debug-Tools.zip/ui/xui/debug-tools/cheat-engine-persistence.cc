//
// xemu Cheat Engine - persistent selections
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "cheat-engine.hh"
#include "current-game.hh"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <string>

#include <glib.h>
#include <glib/gstdio.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace {

std::string Sha256Text(const std::string &text)
{
    gchar *digest = g_compute_checksum_for_data(
        G_CHECKSUM_SHA256,
        reinterpret_cast<const guchar *>(text.data()), text.size());
    if (!digest) {
        return {};
    }
    std::string result(digest);
    g_free(digest);
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return (char)std::toupper(c); });
    return result;
}

void AppendHexBytes(std::string &out, const std::vector<uint8_t> &bytes)
{
    static const char kHex[] = "0123456789ABCDEF";
    out.reserve(out.size() + bytes.size() * 2u);
    for (uint8_t value : bytes) {
        out.push_back(kHex[value >> 4]);
        out.push_back(kHex[value & 0x0F]);
    }
}

std::string UpperAscii(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(),
                   [](unsigned char c) { return (char)std::toupper(c); });
    return value;
}

} // namespace

std::string CheatEngineWindow::PersistentDirectory() const
{
    const std::string root = CheatDirectory();
    gchar *path = g_build_filename(root.c_str(), "Saved", nullptr);
    std::string result = path ? path : root + "/Saved";
    g_free(path);
    return result;
}

std::string CheatEngineWindow::PersistentMarkerPath() const
{
    const std::string dir = PersistentDirectory();
    gchar *path = g_build_filename(dir.c_str(), "Persistent.enabled", nullptr);
    std::string result = path ? path : dir + "/Persistent.enabled";
    g_free(path);
    return result;
}

std::string CheatEngineWindow::CurrentPersistencePath() const
{
    const auto &game = current_game_manager.Get();
    if (!game.valid) {
        return {};
    }

    std::string identity_hash = game.header_sha256;
    if (identity_hash.empty()) {
        return {};
    }
    identity_hash = UpperAscii(identity_hash);
    const std::string short_hash =
        identity_hash.substr(0, std::min<size_t>(16, identity_hash.size()));
    const std::string filename =
        CurrentGameManager::FormatTitleId(game.title_id) + "-" + short_hash +
        ".persist.json";
    const std::string dir = PersistentDirectory();
    gchar *path = g_build_filename(dir.c_str(), filename.c_str(), nullptr);
    std::string result = path ? path : dir + "/" + filename;
    g_free(path);
    return result;
}

std::string CheatEngineWindow::LegacyPersistencePath() const
{
    const auto &game = current_game_manager.Get();
    if (!game.valid) {
        return {};
    }
    std::string legacy_hash = game.disc_xbe_sha256.empty()
                                  ? game.raw_header_sha256
                                  : game.disc_xbe_sha256;
    if (legacy_hash.empty()) {
        return {};
    }
    legacy_hash = UpperAscii(legacy_hash);
    const std::string short_hash =
        legacy_hash.substr(0, std::min<size_t>(16, legacy_hash.size()));
    const std::string filename =
        CurrentGameManager::FormatTitleId(game.title_id) + "-" + short_hash +
        ".persist.json";
    const std::string dir = PersistentDirectory();
    gchar *path = g_build_filename(dir.c_str(), filename.c_str(), nullptr);
    std::string result = path ? path : dir + "/" + filename;
    g_free(path);
    return result;
}

void CheatEngineWindow::EnsurePersistenceOptionLoaded()
{
    if (m_persistence_option_loaded) {
        return;
    }
    m_persistence_option_loaded = true;
    m_persistent_cheats =
        g_file_test(PersistentMarkerPath().c_str(), G_FILE_TEST_IS_REGULAR);
}

void CheatEngineWindow::SetPersistentCheats(bool enabled)
{
    EnsurePersistenceOptionLoaded();
    if (m_persistent_cheats == enabled) {
        return;
    }

    const std::string dir = PersistentDirectory();
    const std::string marker = PersistentMarkerPath();
    if (enabled) {
        if (g_mkdir_with_parents(dir.c_str(), 0755) != 0) {
            m_file_status = "Could not create persistent cheat folder: " + dir;
            return;
        }
        GError *error = nullptr;
        if (!g_file_set_contents(marker.c_str(), "enabled\n", -1, &error)) {
            m_file_status = "Could not enable persistent cheats: ";
            m_file_status += error ? error->message : marker;
            if (error) {
                g_error_free(error);
            }
            return;
        }
        m_persistent_cheats = true;
        SavePersistentState();
    } else {
        if (g_remove(marker.c_str()) != 0 &&
            g_file_test(marker.c_str(), G_FILE_TEST_EXISTS)) {
            m_file_status = "Could not disable persistent cheats: " + marker;
            return;
        }
        m_persistent_cheats = false;
    }
}

std::string CheatEngineWindow::PersistentIdentityHash(
    const CheatBlock &block) const
{
    std::string identity;
    identity.reserve(block.group_path.size() + block.name.size() + 48u);
    identity += block.group_path;
    identity.push_back('\n');
    identity += block.name;
    identity.push_back('\n');
    identity += block.preentry ? "PREENTRY\n" : "LIVE\n";
    identity += std::to_string(block.identity_ordinal);
    return Sha256Text(identity);
}

std::string CheatEngineWindow::PersistentContentHash(
    const CheatBlock &block) const
{
    std::string content;
    content.reserve(block.codes.size() * 64u);
    char pair[40];
    for (const RawCode &code : block.codes) {
        std::snprintf(pair, sizeof(pair), "%08X:%08X:%02X;",
                      code.command, code.value, code.f_final_valid_bytes);
        content += pair;

        if ((code.command >> 28) == 0xFu) {
            content += "C=";
            AppendHexBytes(content, code.f_probe_code);
            content += ";D=";
            AppendHexBytes(content, code.f_probe_data);
            std::snprintf(pair, sizeof(pair), ";P=%u:%u;T=%u:%u;",
                          code.f_uses_preserve ? 1u : 0u,
                          code.f_preserve_bytes,
                          code.f_uses_temp ? 1u : 0u,
                          code.f_temp_bytes);
            content += pair;
        }
    }
    return Sha256Text(content);
}

void CheatEngineWindow::SavePersistentState()
{
    EnsurePersistenceOptionLoaded();
    if (!m_persistent_cheats || m_loaded_path.empty() ||
        !current_game_manager.HasGame()) {
        return;
    }

    const std::string path = CurrentPersistencePath();
    if (path.empty()) {
        return;
    }
    const std::string dir = PersistentDirectory();
    if (g_mkdir_with_parents(dir.c_str(), 0755) != 0) {
        m_file_status = "Could not create persistent cheat folder: " + dir;
        return;
    }

    const auto &game = current_game_manager.Get();
    const std::string identity_hash = UpperAscii(game.header_sha256);

    json root;
    root["version"] = 2;
    root["title_id"] = CurrentGameManager::FormatTitleId(game.title_id);
    root["xbe_sha256"] = identity_hash;
    root["identity_sha256"] = identity_hash;
    root["header_sha256"] = identity_hash;
    root["raw_header_sha256"] = UpperAscii(game.raw_header_sha256);
    root["codes"] = json::array();

    for (const CheatBlock &block : m_blocks) {
        if (!block.selected) {
            continue;
        }
        json entry;
        entry["group"] = block.group_path;
        entry["name"] = block.name;
        entry["ordinal"] = block.identity_ordinal;
        entry["preentry"] = block.preentry;
        entry["identity_sha256"] = PersistentIdentityHash(block);
        entry["content_sha256"] = PersistentContentHash(block);
        root["codes"].push_back(std::move(entry));
    }

    const std::string text = root.dump(2) + "\n";
    const std::string temp = path + ".tmp";
    GError *error = nullptr;
    if (!g_file_set_contents(temp.c_str(), text.data(), text.size(), &error)) {
        m_file_status = "Could not save persistent cheat state: ";
        m_file_status += error ? error->message : path;
        if (error) {
            g_error_free(error);
        }
        return;
    }
    if (g_rename(temp.c_str(), path.c_str()) != 0) {
        g_remove(temp.c_str());
        m_file_status = "Could not replace persistent cheat state: " + path;
    }
}

void CheatEngineWindow::RestorePersistentState()
{
    EnsurePersistenceOptionLoaded();
    if (!m_persistent_cheats || m_loaded_path.empty() ||
        !current_game_manager.HasGame()) {
        return;
    }

    std::string path = CurrentPersistencePath();
    if (path.empty()) {
        return;
    }
    if (!g_file_test(path.c_str(), G_FILE_TEST_IS_REGULAR)) {
        const std::string legacy = LegacyPersistencePath();
        if (legacy.empty() || legacy == path ||
            !g_file_test(legacy.c_str(), G_FILE_TEST_IS_REGULAR)) {
            return;
        }
        path = legacy;
    }

    gchar *contents = nullptr;
    gsize length = 0;
    GError *error = nullptr;
    if (!g_file_get_contents(path.c_str(), &contents, &length, &error)) {
        if (error) {
            g_error_free(error);
        }
        return;
    }
    const json root = json::parse(contents, contents + length, nullptr, false);
    g_free(contents);
    if (root.is_discarded() || !root.is_object() ||
        root.find("codes") == root.end() || !root["codes"].is_array()) {
        return;
    }

    const auto &game = current_game_manager.Get();
    const std::string expected_title = CurrentGameManager::FormatTitleId(game.title_id);
    const std::string expected_identity = UpperAscii(game.header_sha256);
    const std::string expected_raw = UpperAscii(game.raw_header_sha256);
    const std::string expected_disc = UpperAscii(game.disc_xbe_sha256);
    if (root.find("title_id") == root.end() || !root["title_id"].is_string() ||
        UpperAscii(root["title_id"].get<std::string>()) != expected_title ||
        root.find("xbe_sha256") == root.end() || !root["xbe_sha256"].is_string()) {
        return;
    }
    const std::string saved_game_hash =
        UpperAscii(root["xbe_sha256"].get<std::string>());
    const bool saved_hash_matches =
        saved_game_hash == expected_identity ||
        (!expected_raw.empty() && saved_game_hash == expected_raw) ||
        (!expected_disc.empty() && saved_game_hash == expected_disc);
    if (!saved_hash_matches) {
        return;
    }

    struct SavedCode {
        std::string identity;
        std::string content;
    };
    std::vector<SavedCode> saved;
    saved.reserve(root["codes"].size());
    for (const json &entry : root["codes"]) {
        if (!entry.is_object() ||
            entry.find("identity_sha256") == entry.end() ||
            !entry["identity_sha256"].is_string() ||
            entry.find("content_sha256") == entry.end() ||
            !entry["content_sha256"].is_string()) {
            continue;
        }
        saved.push_back({
            UpperAscii(entry["identity_sha256"].get<std::string>()),
            UpperAscii(entry["content_sha256"].get<std::string>())});
    }

    bool restore_live = false;
    for (CheatBlock &block : m_blocks) {
        const std::string identity = PersistentIdentityHash(block);
        const std::string content = PersistentContentHash(block);
        const auto match = std::find_if(
            saved.begin(), saved.end(), [&](const SavedCode &entry) {
                return entry.identity == identity && entry.content == content;
            });
        if (match == saved.end()) {
            continue;
        }

        block.selected = true;
        if (block.preentry) {
            RememberPreEntrySelection(block);
        } else {
            block.enabled = true;
            restore_live = true;
        }
    }
    if (restore_live) {
        m_live_cheats_enabled = true;
        m_switches.clear();
    }
}
