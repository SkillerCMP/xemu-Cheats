// Retained BlockBackend handle for detached/long-running Debug Tools I/O.
#pragma once

#include "disc-block-io.h"

class XemuDiscBlockRef
{
public:
    XemuDiscBlockRef() = default;
    explicit XemuDiscBlockRef(const char *name) { Acquire(name); }
    ~XemuDiscBlockRef() { Reset(); }

    bool Acquire(const char *name)
    {
        Reset();
        m_handle = xemu_disc_block_acquire_by_name(name);
        return m_handle != nullptr;
    }

    void Reset()
    {
        if (m_handle != nullptr) {
            xemu_disc_block_release(m_handle);
            m_handle = nullptr;
        }
    }

    XemuDiscBlockHandle Get() const { return m_handle; }
    explicit operator bool() const { return m_handle != nullptr; }

    XemuDiscBlockRef(const XemuDiscBlockRef &) = delete;
    XemuDiscBlockRef &operator=(const XemuDiscBlockRef &) = delete;

private:
    XemuDiscBlockHandle m_handle = nullptr;
};
