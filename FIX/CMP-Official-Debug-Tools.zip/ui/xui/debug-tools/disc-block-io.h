//
// xemu mounted-disc BlockBackend bridge
//
// Keeps QEMU block-layer C headers out of the C++ debugger/frontend sources.
//
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void *XemuDiscBlockHandle;

/* Borrowed lookup: caller must already hold BQL for the complete lifetime of
 * the returned handle. Detached/long-running Debug Tools work should use the
 * retained acquire/release pair below; retained-handle queries and I/O
 * self-synchronize with BQL for their individual block-layer calls. */
XemuDiscBlockHandle xemu_disc_block_by_name(const char *name);
XemuDiscBlockHandle xemu_disc_block_acquire_by_name(const char *name);
void xemu_disc_block_release(XemuDiscBlockHandle handle);
bool xemu_disc_block_is_available(XemuDiscBlockHandle handle);
uintptr_t xemu_disc_block_identity(XemuDiscBlockHandle handle);
int64_t xemu_disc_block_get_length(XemuDiscBlockHandle handle);
bool xemu_disc_block_pread(XemuDiscBlockHandle handle, uint64_t offset,
                           void *buffer, size_t size);

#ifdef __cplusplus
}
#endif
