// No guest access here. GLib provides consistent (temporary-file + rename)
// replacement on Windows, Linux and macOS; never truncate the live TXT and
// never leave a persistent per-delete backup beside the Cheats file.
#include "cheat-source-file.hh"
#include <glib.h>
#include <glib/gstdio.h>
#include <sys/stat.h>

namespace XemuCheatSource {
bool ReadUnchanged(const std::string &path, const std::string &expected,
                   std::string &error)
{
    error.clear();
    if (path.empty() || g_file_test(path.c_str(), G_FILE_TEST_IS_SYMLINK) ||
        !g_file_test(path.c_str(), G_FILE_TEST_IS_REGULAR)) {
        error = "The loaded cheat source is not a regular, writable TXT file.";
        return false;
    }
    GStatBuf st;
    if (g_stat(path.c_str(), &st) != 0 || (st.st_mode & 0222) == 0) {
        error = "The cheat source is read-only or cannot be inspected.";
        return false;
    }
    gchar *data = nullptr;
    gsize length = 0;
    GError *err = nullptr;
    if (!g_file_get_contents(path.c_str(), &data, &length, &err)) {
        error = err ? err->message : "Could not read cheat source.";
        g_clear_error(&err);
        return false;
    }
    const bool same = expected.size() == length &&
        (length == 0 || expected.compare(0, length, data, length) == 0);
    g_free(data);
    if (!same) error = "The TXT changed on disk. Reload it and select the code again; nothing was deleted.";
    return same;
}

bool Replace(const std::string &path, const std::string &expected,
             const std::string &replacement, std::string &error)
{
    // The caller already checks once before preparing the in-memory model. Check
    // again immediately before the durable atomic replacement so an ordinary
    // external edit cannot be overwritten by a stale delete confirmation.
    if (!ReadUnchanged(path, expected, error)) return false;

    GError *err = nullptr;
    const auto flags = static_cast<GFileSetContentsFlags>(
        G_FILE_SET_CONTENTS_CONSISTENT | G_FILE_SET_CONTENTS_DURABLE);
    if (!g_file_set_contents_full(path.c_str(), replacement.data(),
                                  replacement.size(), flags, 0644, &err)) {
        error = "Could not replace cheat source: ";
        error += err ? err->message : "unknown file error";
        g_clear_error(&err);
        return false;
    }
    return true;
}
}
