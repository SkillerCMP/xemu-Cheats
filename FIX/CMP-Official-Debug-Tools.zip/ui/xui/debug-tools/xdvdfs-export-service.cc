//
// Read-only XDVDFS -> host export service.
//
#include "xdvdfs-export-service.hh"
#include "host-export-utils.hh"

#include "binary-utils.hh"
#include "disc-block-io.h"
#include "disc-block-ref.hh"
#include "xdvdfs-disc.hh"

#include <glib/gstdio.h>

#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <system_error>
#include <vector>

namespace XemuXdvdfsExport {
namespace {

using XemuHostExportUtils::CreateUniqueHostDirectory;
using XemuHostExportUtils::HostSafeName;
using XemuHostExportUtils::OpenUniqueHostFile;
using XemuDebugBinaryUtils::range_inside;

constexpr size_t kCopyChunkSize = 1024 * 1024;
constexpr size_t kMaxExportDepth = 64;

struct DiscReader {
    XemuDiscBlockHandle disc = nullptr;
    uintptr_t identity = 0;
    uint64_t length = 0;

    bool Read(uint64_t offset, void *buffer, size_t size) const
    {
        return disc && xemu_disc_block_identity(disc) == identity &&
               range_inside(offset, size, length) &&
               xemu_disc_block_pread(disc, offset, buffer, size);
    }
};

bool ExportEntryRecursive(const DiscReader &reader,
                          const XemuXdvdfs::Entry &entry,
                          const std::string &requested_path, size_t depth,
                          Result &result, std::string &actual_path,
                          std::string &error)
{
    namespace fs = std::filesystem;
    if (depth > kMaxExportDepth) {
        error = "Disc export directory depth exceeds the safety limit.";
        return false;
    }

    if (entry.IsDirectory()) {
        if (!CreateUniqueHostDirectory(
                requested_path, actual_path, error,
                "Unable to exclusively create disc export folder: ",
                "Could not claim a unique disc export folder after 10000 attempts.")) {
            return false;
        }
        ++result.directory_count;
        for (const XemuXdvdfs::Entry &child : entry.children) {
            const std::string child_requested =
                (fs::path(actual_path) / HostSafeName(child.name)).string();
            std::string child_actual;
            if (!ExportEntryRecursive(reader, child, child_requested, depth + 1,
                                      result, child_actual, error)) {
                return false;
            }
        }
        return true;
    }

    FILE *fp = nullptr;
    if (!OpenUniqueHostFile(
            requested_path, actual_path, fp, error,
            "Unable to exclusively create disc export file: ",
            "Unable to open the exclusively-created disc export file: ",
            "Could not claim a unique disc export filename after 10000 attempts.")) {
        return false;
    }

    std::vector<uint8_t> buffer;
    buffer.resize(std::min<uint64_t>(kCopyChunkSize,
                                     std::max<uint64_t>(entry.size, 1)));
    uint64_t done = 0;
    bool ok = true;
    while (done < entry.size) {
        const size_t chunk = static_cast<size_t>(std::min<uint64_t>(
            buffer.size(), static_cast<uint64_t>(entry.size) - done));
        if (!reader.Read(entry.disc_offset + done, buffer.data(), chunk)) {
            error = "The mounted disc changed or a disc data read failed during export.";
            ok = false;
            break;
        }
        if (std::fwrite(buffer.data(), 1, chunk, fp) != chunk) {
            error = "Unable to write disc export file: " + actual_path;
            ok = false;
            break;
        }
        done += chunk;
    }
    if (std::fclose(fp) != 0 && ok) {
        error = "Unable to finalize disc export file: " + actual_path;
        ok = false;
    }
    if (!ok) {
        g_remove(actual_path.c_str());
        return false;
    }

    ++result.file_count;
    result.byte_count += entry.size;
    return true;
}

} // namespace

bool ExportToHost(const Target &target, const std::string &destination,
                  Result &result, std::string &error)
{
    namespace fs = std::filesystem;
    result = {};
    error.clear();
    if (target.components.empty()) {
        error = "Select a disc file or folder to export.";
        return false;
    }

    XemuDiscBlockRef disc("ide0-cd1");
    if (!disc || !xemu_disc_block_is_available(disc.Get())) {
        error = "Xbox DVD (ide0-cd1) is not available.";
        return false;
    }
    const int64_t signed_length = xemu_disc_block_get_length(disc.Get());
    if (signed_length <= 0) {
        error = "Unable to determine mounted disc size.";
        return false;
    }

    DiscReader reader;
    reader.disc = disc.Get();
    reader.identity = xemu_disc_block_identity(disc.Get());
    reader.length = static_cast<uint64_t>(signed_length);

    XemuXdvdfs::Disc fresh;
    if (!XemuXdvdfs::Parse(
            [&reader](uint64_t offset, void *buffer, size_t size) {
                return reader.Read(offset, buffer, size);
            },
            reader.length, fresh, error)) {
        if (error.empty()) {
            error = "Unable to refresh the mounted XDVDFS directory.";
        }
        return false;
    }

    const XemuXdvdfs::Entry *entry = XemuXdvdfs::FindEntry(fresh, target.components);
    if (!entry || entry->IsDirectory() != target.directory ||
        entry->size != target.size || entry->start_sector != target.start_sector) {
        error = "The selected disc item changed or no longer exists. Refresh and try again.";
        return false;
    }

    std::error_code ec;
    const fs::path destination_path(destination);
    if (!fs::is_directory(destination_path, ec) || ec) {
        error = "Select an existing host destination folder for disc export.";
        return false;
    }

    const std::string requested =
        (destination_path / HostSafeName(entry->name)).string();
    std::string host_path;
    result.directory = entry->IsDirectory();
    if (!ExportEntryRecursive(reader, *entry, requested, 0, result,
                              host_path, error)) {
        if (entry->IsDirectory() && !host_path.empty()) {
            std::error_code cleanup_error;
            fs::remove_all(fs::path(host_path), cleanup_error);
        }
        return false;
    }
    result.host_path = host_path;
    return true;
}

} // namespace XemuXdvdfsExport
