# xemu Debug Tools Extensions

This directory contains the custom RAW Cheat Engine, Current Game manager,
Memory/Map tools, detached tool windows, x86 debugger UI, HDD/FATX tooling, and
the small C bridges used to access QEMU/xemu CPU and memory facilities.

The project is now split into a **main addition plus optional additions**. Normal
xemu UI code includes only `debug-tools/debug-tools.hh`; optional tools register
with Debug Tools-owned APIs instead of adding their own xemu hooks.

- **Main addition (always built):** Current Game + RAW Cheat Engine, shared guest
  memory/debug bridge, F0 assembler/hook support, Capstone decode, Keystone encode,
  XBE/label/disc support, and the generic detached-window host.
- **HDD addition (optional):** HDD Directory, FATX services, Guest Kernel RPC, and
  the Current Game HDD/Kernel-RPC extension tabs.
- **Memory addition (optional):** Memory Viewer, Search, x86 Debugger, Inject,
  Labels and RAM Dump frontends.
- **Diagnostics addition (optional, full profile):** detached CPU/timing/NV2A/APU
  flight recorder plus opt-in detailed NV2A PTIMER, QEMU timer-dispatch,
  Slow QEMU Timer Callback, OHCI Slow Frame Stage, Controller Input Poll Stage,
  FLIP_STALL/VBlank lifecycle, Main-Loop Wait Stage, BQL Ownership, MMIO
  Dispatch, and focused PTIMER IRQ Delivery / Interrupt-Mask traces used to
  investigate emulator-side timing stalls.

Select the source build in `build-profile.txt`: `main`, `main+hdd`,
`main+memory`, or `full`. `full` is the default and preserves the complete
v2.90.6 feature set. `main` is the intended Current Game/Cheat Engine-only fork;
HDD and Memory implementation translation units are not compiled in that profile.

### Docker profile selection

`Build-Xemu-DOCKER.bat` can select the Debug Tools profile at build time without
editing `build-profile.txt`. Double-click/run the BAT and choose:

1. `main` - Current Game + Cheat Engine only
2. `main+hdd` - Main + HDD Directory/Kernel RPC
3. `main+memory` - Main + Memory Viewer/Search/x86 Debugger
4. `full` - all additions, including Diagnostics/PTIMER timing trace

For scripted builds, pass the profile as argument 2 after an optional source
root, for example `Build-Xemu-DOCKER.bat . main`, or set
`XEMU_DEBUG_TOOLS_PROFILE=main`. The Docker selection is an environment override
and does not rewrite the source-tree `build-profile.txt`. The Docker container
can enter through normal root `build.sh`. A single integration line redirects once into
`ui/xui/debug-tools/build-xemu.sh`, so Capstone/Keystone dependency preparation
remains owned by this addition rather than being implemented in xemu's build script.

### Diagnostics traces and generated output

All generated Debug Tools output is grouped beside `xemu.exe` under one root:

```text
DEBUG/
  Ram-Dumps/
  Trace-Dumps/
  Snapshots/
```

With the `full` profile, open **Debug > Diagnostics > NV2A / PTIMER**. Enable
**Record detailed PTIMER events** for the 4096-event PTIMER/RDTSC ring and
**Record PTIMER QEMU dispatch** for the 16384-event QEMU timer/main-loop flight
recorder. **Record slow QEMU timer callbacks** is a separate lightweight detector
with an editable millisecond threshold (default 1.000 ms) and a 128-event ring;
normal callbacks are filtered before recorder locking, and retained rows include
the callback/timer/opaque addresses, scheduled expiry, host and virtual duration,
dispatch lateness, thread ID, and BQL state. Enabling the QEMU dispatch recorder
also arms the lock-free 4096-event
**BQL Ownership Trace**, which retains only BQL waits/holds of at least 1 ms and
records the blocking owner thread/CPU, acquisition callsite, and guest PC when
available. It also arms the lock-free 4096-event **MMIO Dispatch Trace**, which
retains CPU MMIO reads/writes lasting at least 1 ms and records guest VA/PA,
access size/direction, resolved MemoryRegion name/offset, owner type, and guest
PC. The traces remain in memory and perform no file I/O from PTIMER/MMIO/timer/BQL callbacks.

Diagnostics **View** controls which sections are exported. **Save Snapshot** writes
one timestamped file directly to `DEBUG/Snapshots/`; **Open Snapshots Folder** opens
that directory. The optional rolling crash/stall capture updates only
`DEBUG/Snapshots/XEMU-Diagnostics-Live.txt`. It never creates a sequence of live
files. QEMU timer snapshots include an analysis summary for dispatch lateness,
main-loop timeout selection, wait overshoot, and the gap before timer dispatch.
The **PTIMER IRQ Delivery / Interrupt-Mask Trace (TCG)** follows a PTIMER alarm
from NV2A assertion through PCI/PIC routing into `CPU_INTERRUPT_HARD` and the
TCG/x86 interrupt-take decision. It only samples while a PTIMER service window is
active, pins the last four windows of at least 2 ms, and records guest EFLAGS/IF,
`HF_INHIBIT_IRQ`, `CF_NOIRQ`, CPU hard-request presence/eligibility, and the
hardware interrupt vector when one is taken. While this recorder is enabled,
Patch-305.1's `00223000` one-instruction dispatcher trace is suppressed to avoid
adding avoidable timing pressure to the exact IRQ-delivery interval.

Patch 305.3 adds a smaller **D3D Timer Record / List State Trace** on top of that
suppression. It learns the current InputBuffer timer object from ECX at
`00216473`, snapshots 256 bytes of that object at schedule/callback milestones,
and probes only a fixed set of exact `00223xxx` dispatcher PCs. Snapshot output
includes masks of fields changed from the current schedule baseline and the last
successful callback, so a skipped timer can be compared without restoring the
high-volume dispatcher-page trace.

The **PTIMER Late Callback Capture** is a separate one-shot forensic latch: when
armed it freezes the first watched PTIMER dispatch that begins at least 5 ms late,
including compact tails from the QEMU timer/main-loop, BQL, main-loop lock, PGRAPH
lock, scheduler, and Guest Timer/Deadline recorders. The frozen window persists
until Clear/Re-arm even if the normal rings later wrap.
BQL snapshots report the worst wait and hold, the owner seen when the wait began,
and the longest recorded BQL hold overlapping that wait. MMIO snapshots report
the worst retained device dispatch and the MemoryRegion/address context needed
to identify the slow emulated device handler.

### FLIP_STALL / VBlank investigator

The full Diagnostics profile includes an observation-only flip lifecycle recorder
for NV097 flip setup, `FLIP_INCREMENT_WRITE`, `FLIP_STALL`, the actual PCRTC
VBlank interrupt, `NV_PGRAPH_INCREMENT_READ_3D`, PFIFO stall/release checks, and
Vulkan `VK_FINISH_REASON_FLIP_STALL` duration. Each event snapshots the live
`READ_3D` / `WRITE_3D` / `MODULO_3D` indexes, waiting state, guest PC, and host
thread. The recorder is designed to distinguish a slow host GPU fence wait from
a flip index that fails to advance/release at VBlank. It does not alter NV2A,
PFIFO, VBlank, or renderer behavior.

### Xbox scheduler / thread-wake investigator

The full Diagnostics profile also includes a low-overhead scheduler recorder for
the `KiIdleLoop` used by the current Xbox kernel. It samples CPU0
from the existing Debug Tools tick, remembers the last title-code PC, and retains
only idle enter/checkpoint/exit/title-return transitions. Retained events include
the `KiIdleLoop` EBX scheduler slots at `+0x28/+0x2C`, CPU interrupt state, NV2A
interrupt state, and counts of PCRTC VBlank, PTIMER, PGRAPH, PFIFO, and OHCI
activity observed while idle. The recorder is diagnostic only and does not alter
scheduler or interrupt behavior.

### Guest timer / deadline correlation investigator

The full Diagnostics profile includes an opt-in, non-breaking TCG correlation
recorder for the current InputBuffer/D3D timer-deadline research preset. While
enabled, only the guest code pages containing the watched timer paths
(`000D7000` and `00216000`) use one-instruction translated blocks. Exact-PC
events capture the relevant x86 registers/EFLAGS and one guest-memory sample per
InputBuffer/D3D sequence, then derive the nominal interval, accumulated lateness,
calculated interval, requested deadline, `RDTSC+40` threshold, signed deadline
delta, and final relative delay. The recorder is diagnostic only: it does not
modify guest memory or timer behavior and never pauses the guest. Results are
available in the live Diagnostics table and **Save Snapshot** output.

Patch 305 extends this investigator with the **D3D InputBuffer Callback Dispatch
Capture**. For the current Def Jam research preset it links only D3D schedules
whose callback target is `000D7EA0`, records the raw schedule-return EAX, watches
for callback entry/return and the next `000D7E53` cycle, and derives the expected
callback due time from the accepted relative delay. If the callback has not entered
within 5 ms after that due time, a one-shot `CALLBACK_OVERDUE` capture pins compact
QEMU timer, BQL, main-loop-lock, PGRAPH, scheduler, and guest callback-lifecycle
tails. The watchdog observes only; it does not reschedule the timer, write guest
memory, or pause the VM.

### Cached host gamepad input / BQL isolation

XEMU 3.07 now keeps host SDL gamepad sampling out of guest USB/OHCI transactions.
The SDL/UI thread snapshots the currently live gamepad handles and mappings while
protected, releases the BQL for the potentially blocking SDL button/axis getters,
and then commits the completed Xbox-facing button/axis cache under the lock. XID
interrupt-IN handling consumes that committed cache directly and never refreshes SDL
synchronously. This is a generic emulator behavior change for all XID gamepads; it
does not contain any title-specific condition. Persistent reconnect still neutralizes
the committed state while disconnected. Rumble/output behavior is unchanged by this
input A/B fix.

For USB/controller timing investigations, **OHCI Slow Frame Stage Profiler** breaks
slow `ohci_frame_boundary()` work into top-level OHCI stages and nested ED/TD/DMA/
`usb_handle_packet()` leaves. **Controller Input Poll Stage Profiler** then targets
the XID gamepad interrupt-IN transaction and times `update_input()`, controller
lookup/update, SDL controller-state sampling, report mapping, trace/copy stages,
and every SDL gamepad button/axis getter individually. Both use editable millisecond
thresholds (default 1.000 ms) and retain only completed operations meeting the
threshold. They are observation-only and do not alter USB or controller behavior.

The project rule remains to keep custom implementation inside
`ui/xui/debug-tools/` whenever possible. The root of that directory is reserved for
the main Current Game/RAW Cheat Engine addition, shared/core services, and build/facade
files. Optional HDD and Memory implementations live physically under their respective
`addons/` directories. Upstream xemu files should contain only the smallest required
integration hooks; unrelated upstream code is not a cleanup target.

## RAW Cheat Engine and Patch lifecycle

- Ordinary `+Cheat` blocks live on **Cheats** and execute only when the live
  Cheats control is enabled. Unchecking an ordinary Cheat is an unconditional
  OFF boundary: the block is disabled immediately and any active F0/F1/F2 hook
  owned by it restores the exact original hook bytes captured at installation.
  Group deselection follows the same rule.
- Startup patches use the preferred `+:PREENTRY:Name{Description}` syntax. The
  standalone `:PREENTRY:` compatibility form remains supported.
- **Patch** is independent of the Cheats-tab Enabled/Disabled button. The global
  **Engine Enabled** option remains the master startup safety gate.
- Checking/unchecking a Patch stages the next startup/reset. A Patch is reported
  as applied only after its block executes successfully. Failed startup blocks
  keep their own error and remain reset-required.
- Direct Game A -> Game B identity changes are treated as real startup boundaries.
  Explicit UI Reset retains its separate `ResetRequested -> ApplyPending`
  lifecycle and does not depend on observing a transient no-XBE frame.
- Patch selection identity is code-file path + group path + block name +
  occurrence ordinal, so duplicate names remain independent. Stale identities
  are pruned only for the file currently being parsed.
- Live Type-F ownership and PREENTRY Type-F ownership remain separate. Disabling
  live Cheats never tears down an already-applied Patch hook.

## Debug Tools tab states

Debug Tools use exactly three local tab states without altering xemu's global
theme:

- **Inactive:** light grey (`#949494`)
- **Hovered:** steel blue (`#5B8FBA`)
- **Selected:** xemu's existing active-tab green

The style is owned by a scoped RAII helper so every pushed tab color is restored
automatically. Partially selected Cheat/Patch groups display an indeterminate
mark inside the checkbox.

## Current Game / debugger / memory tools

Current Game tracks the running XBE identity and mounted-disc metadata. Debugger
and Memory Tools provide disassembly/navigation, conditional breakpoints, live
register views, labels/importers, memory/search/map views, RAM dumps, and F0
CodeCave integration. The existing historical debugger behavior is protected by
the packaged golden tests.

## HDD / FATX safety

Filesystem mutation retains the permanent transaction invariant:

`Create/Open -> Write -> Flush -> Close -> fresh FATX Verify`

Cleanup and optimization must not weaken that sequence. Copy/Move verification
continues to use fresh coherent FATX snapshots and byte-for-byte content checks.
Read-side optimizations may reuse host buffers or measurement helpers only when
those verification semantics remain unchanged.

## x86 Debugger Inject restore behavior

`Inject > NOP` and `Inject > Change` share one remembered-original instruction
record for the session. Change exposes only `APPLY` and `RESTORE`; Restore fills
the Replacement field with the remembered original instruction and writes the
exact captured original bytes. A conditional `Inject > Restore` menu item is
shown on rows owned by an active NOP/Change patch and restores the complete
tracked instruction span after verifying that the live bytes still match the
patch xemu wrote. CodeCave continues to use its separate Type-F0 restore path.

The debugger's right-side section is tabbed as **Breakpoints | Changes**. Changes
lists active restorable debugger patches as `Address | Original | Changed | HEX`.
HEX is per-row and defaults off: unchecked rows show decoded instruction text;
checked rows show the captured/written bytes. Address right-click reuses the
normal debugger/disassembler context menu and double-click follows the address.
For the temporary debugger CodeCave/F0 hook, Changes records only the hook /
jump-from address and never enumerates the generated F0 cave body. A real user
Reset discards these debugger-only Changes records without writing captured
pre-reset bytes into the new guest. The disassembler refresh is deferred until QEMU
has consumed the pending reset, then the existing refresh path rereads post-reset RAM
exactly once; PREENTRY Patch activation remains separate.
CodeCave RUN is refused when the hook overwrite span overlaps the live XBE header
(`m_base` through `m_sizeof_headers - 1`) so a debugger JMP cannot modify the
header bytes used for running-XBE revision detection.

After NOP, Change, Restore, or CodeCave RUN/RESTORE, the disassembly refresh is
anchored to the instruction that was actually modified; an older Follow/Go-To
target cannot pull the view away, and the refresh does not add a Back/Forward
history entry.

## Files

- `cheat-engine.cc` - small per-frame Cheat Engine coordinator (`Tick`).
- `cheat-engine-source.cc` - CMP/RAW source parsing, file discovery/loading, game identity, and PREENTRY/Patch lifecycle.
- `cheat-engine-fhooks.cc` - debugger/Live Cheat Type-F0/F1/F2 compile, install, restore, retirement, and ownership lifecycle.
- `cheat-engine-execute.cc` - guest read/write helpers and RAW code execution (0/1/2/3/4/5/6/7/9/A/D/E/F).
- `cheat-engine-ui.cc` - Cheat/Patch selection controls, menu/help, and Cheat Engine rendering frontend.
- `cheat-engine.hh` - shared Cheat Engine state/API contract; unchanged by the Phase-9 split.
- `cheat-engine-memory.c/.h` - C bridge to QEMU/xemu memory and debugger access.
- `current-game.cc/.hh` - current XBE/title/revision, mounted-disc tracking, label/XDK/MAP/PDB state, and disc export core.
- `current-game-ui.cc` - Current Game rendering frontend: summary, Game Info, Disc Contents, extension slots, and disc-entry context UI; it has no HDD/Kernel-RPC dependency.
- `debug-tools.cc/.hh` + `debug-tools-module.hh` - the single xemu-facing integration facade and Debug Tools-owned module/extension registry.
- `prepare-build-dependencies.sh` / `build-xemu.sh` - Debug Tools-owned Capstone/Keystone preparation and the wrapper reached by root `build.sh`'s single integration line.
- `docker-build-windows.sh` - the Docker container-side GitHub-equivalent Windows build driver used by `Build-Xemu-DOCKER.bat`. Every successful Docker build exports both the exact GitHub-style `.tar.zst` source archive and a convenient ZIP made from that same packaged source tree under the run's `source/` directory.
- `detached-tools.cc/.hh` - independent SDL/OpenGL/ImGui tool-window host with registration rather than a hard-coded feature list.
- `addons/hdd/` - the complete optional HDD addition: HDD Directory UI/state, FATX parsing/snapshots/export, Guest Kernel RPC, filesystem planning/streaming, and its registration unit.
- `addons/memory-tools/` - the complete optional Memory addition: Memory Viewer/Search, x86 Debugger, Inject, Labels, RAM Dump, breakpoint conditions, register-copy helper, and its registration unit.
- `addons/stubs/` - tiny no-op registration units linked when an optional addition is disabled.
- `label-symbol-utils.hh` - shared ASCII and Microsoft symbol-display helpers used by XDK/MAP/PDB importers.
- `x86-cheat-assembler.cc` - Type-F0 directive/temp/preserve frontend plus Type-F2 raw-byte labels/relocations/DD layout.
- `x86-cheat-assembler-keystone.cc` / `x86-cheat-assembler-internal.hh` - Keystone-backed IA-32 instruction assembly plus the small F0 syntax/label utility bridge; the old hand-written generic opcode encoder has been removed.
- `backend/xemu-dbg.c/.h`, `backend/whpx-debug.c/.h` - debugger backend bridge.
- `tests/` - historical freeze guards, current feature guards, native goldens,
  and Heavy randomized regression models.

## Upstream integration points

The intended upstream-touch surface remains deliberately small. In particular,
the PREENTRY reset lifecycle uses only the existing two-line Reset notification
bridge in `ui/xui/actions.cc`; PREENTRY execution/state remains inside Debug
Tools.

Capstone and Keystone dependency preparation is owned by Debug Tools rather than
implemented in GitHub workflow YAML or in xemu's build logic. Root `build.sh`
differs from upstream by exactly one redirect line: when the Debug Tools addition
is present it enters `ui/xui/debug-tools/build-xemu.sh` once; when the addition is
absent the upstream build path is unchanged. The wrapper calls
`prepare-build-dependencies.sh`, which reuses compatible target libraries or builds
the pinned static dependencies, exports their pkg-config paths, adds xemu's
`--enable-capstone` configure option, then returns to normal root `build.sh` with a
recursion guard. Capstone is built with only the Xbox-required X86 decoder;
Keystone is built with only the X86 assembler backend.
Both helpers are target-aware for Linux x86_64/AArch64, macOS x86_64/ARM64, and
Windows x86_64/ARM64. Upstream multi-platform workflow YAML remains unchanged.
`build-capstone-windows.sh` remains only as a legacy compatibility wrapper; the
current Docker builder enters through `docker-build-windows.sh` -> root `build.sh` -> the one-line Debug Tools redirect -> `build-xemu.sh`.

Type-F0 source syntax does not change with the Keystone backend. Existing labels,
`DD`, `PRESERVE`/`RESTORE`, `T0-T7`/`TFLAGS`, and hex-first numeric input remain
owned by the F0 frontend, while normal Intel-syntax IA-32 instructions are encoded
by Keystone. A compatibility adapter preserves legacy forms that Keystone itself
parses more strictly: register-sized memory operands such as `mov cl, [0046D784]`
are given the implied size internally, and F0-generated/bare A-F-leading hexadecimal
values are normalized to explicit `0x...` form before assembly. Cheat files therefore
do not need to be rewritten to Keystone-specific spelling. This greatly broadens
usable x86 instructions (including normal x87, MMX, SSE, and less-common integer
forms) without introducing a second cheat-code format. Capstone continues to own
hook-span decoding/disassembly and executable boundary validation.

Type-F2 is the raw-machine-code companion to F0. An `F2000000 AAAAAAAA` block
accepts arbitrary even-length hexadecimal byte strings (spaces are optional), `//`
comments, labels, and the same little-endian `DD` static-data layout used by F0.
`DEADCODE` has no operand; the generated return JMP is placed immediately after the
last executable F2 byte and any DD payload follows that JMP. Symbolic operands are
resolved for direct `E8`/`E9` rel32 branches, `EB`/`70-7F`/`E0-E3` rel8 branches,
`0F80-0F8F` rel32 branches, and `B8-BF`/`68`/`A0-A3` absolute 32-bit forms. A
hex-looking label can be forced with an `@` prefix. F2 does not expose F0's virtual
`T0-T7` or `PRESERVE` directives; use literal x86 save/restore bytes when needed.

## Validation

The `tests/` directory is optional for normal builds. If it is present, the local Docker
builder automatically runs the regression suite before packaging/building. If the entire
`tests/` directory is absent, project-layout validation records that tests are omitted and
the build continues normally. A present-but-incomplete tests directory remains an error so
a damaged regression package cannot be silently ignored.

Every successful Docker build also keeps the exact source package used for that build. The
run output contains `source/xemu-<version>.tar.zst`, `source/xemu-<version>-source.zip`, and
`source/DEBUG_TOOLS_PROFILE.txt`. In the disposable packaged copy, `build-profile.txt` is set
to the profile selected for that run (the user's working source is never rewritten). The ZIP
is created from the same freshly archived source tree consumed by the Windows build, and the
two Windows build BAT files are explicitly staged into that source package so it can be
rebuilt locally with the same profile by default.

The regression suite is under current **v2.87** ownership.
`tests/v287-run-regression-tests.py` exposes Static, Native, and Heavy phases, targeted
`--test` selection, compiler selection, per-command timing, and optional Static
`--jobs` parallelism. Stable behavior-based tests keep subsystem-oriented names,
while historical release-numbered guards are consolidated into the current
`v287-*` suites.

`v287-final-production-audit-golden.py` owns the current v2.91.6 complete 96-file production
fingerprint and the cumulative dead-code/helper-ownership audit.
`v287-ownership-structure-golden.py` owns the current final split boundaries
without retaining stale per-phase byte fingerprints. Current consolidated suites
cover UI/runtime, HDD/FATX/Kernel RPC, PREENTRY/Patch/Cheat, and Windows/build/test
infrastructure regressions. Every retained top-level golden carries a v2.87
current-ownership marker.

The final production audit explicitly follows the production HDD delete/import
entry points and preserves the permanent Xbox-kernel transaction:
`Create/Open -> Write -> Flush -> Close -> fresh FATX Verify`.

Packaging validation must keep generated Python bytecode and `.git/index`
mutations out of source artifacts. The suite remains a regression layer in
addition to the pinned Windows build and runtime confirmation.

## Release history

See [`CHANGELOG.md`](CHANGELOG.md) for the complete release-by-release history.


### Slow timer source identification

Slow timer events also retain the callback expression and source file/line from the normal QEMU timer construction helper. This lets a snapshot identify a callback such as `ohci_frame_boundary` directly instead of relying only on a Windows ASLR address.

### PGRAPH / PTIMER latency
Diagnostics v3.05 adds a PGRAPH Increment Stage profiler and PTIMER IRQ Service Latency profiler for correlating slow guest PGRAPH increment MMIO with delayed PTIMER service. Both are observer-only and thresholded.


### Patch 305.1 D3D PTIMER ISR / Callback Dispatcher Trace

Patch 305.1 extends the Patch-305 callback lifecycle diagnostic by exact-PC tracing guest page `00223000` only while callback `000D7EA0` is outstanding. This captures the dispatcher branch/register path for normal, overdue-recovered, and permanently skipped InputBuffer callbacks. The pinned watchdog also auto-rearms when an overdue callback later recovers so the next permanent failure can be retained. This is diagnostic-only and does not change guest or emulator timer behavior.
