# XEMU Debug Tools

Debug Tools and optional addons are owned by this subtree. Use **Build-All.bat**
in the matrix builder; it calls **Build-XemuMatrix.ps1**. Retired standalone
MINGW64 and Docker BAT launchers are not distributed.

## Code types and deletion

All code lines require `$`; blank lines and supported comments remain allowed.
Read [Strict source format](Codetypes/STRICT-SOURCE-FORMAT.md) and the
[XEMU Code Types Guide](Codetypes/XEMU-Code-Types-Guide.pdf) for RAW, F0/F1/F2
and PREENTRY syntax. Guide addresses are examples, not ready-made game codes.
Type-F compilation is lazy on first execution of a selected definition; loading
disabled definitions does not assemble them. Labels require a trailing colon.

Right-click **Delete Code...** still requires confirmation, source validation,
compare-before-write and GLib's durable consistent temporary-file replacement.
It creates **no permanent backup**. Active hook retirement and reset warnings
retain the existing behavior; deleting a definition is not a general RAW undo.

## Ownership

- Core: Current Game, RAW Cheat Engine, shared services and integration facade.
- `addons/`: Folder-HDD, Video Recorder, File Replace, Game Library, CheatDB, HDD,
  memory tools and Diagnostics; `backend/`: guest/debugger interfaces.
- `tools/`: active build/dependency/validation helpers; `tests/`: regressions.
- `Codetypes/`: user code-format documentation. The old `docs/` is retired;
  archived release documents belong to the matrix builder's `docs/history/`.

Patch 300 keeps necessary upstream integration/observation hooks; addon logic
stays with its addon. Keep detached frame rendering outside BQL and existing
synchronized guest-operation paths intact. Do not add wrappers just to shrink
the patch, move feature implementations upstream, or mix in optional core fixes.

## Build profiles

`main`, `main+hdd`, `main+memory`, `full`, and `folder-hdd` remain supported.
Option 4 is All Addons and Debug Tools; option 5 is Folder-HDD + Video Recorder
without Debug Tools. Its internal profile key remains `folder-hdd`.

## Game identity

`XEMU-XBE-CODE-IDENTITY-V1` hashes Title ID, runtime XBE layout fields and each
section's virtual layout + stored SHA-1 digest. Use Current Game's runtime
identity, not a raw on-disk XBE hash. Mutable title/region/media/signature and
packaging metadata are excluded. Legacy normalized/raw header identities remain
accepted for existing user files.

## File Replace

[Manifest v3 only](addons/file-replace/README.md): Fixed Range, Whole File and
Resizable Range, with the optional OLK size fixer. Manifests/payloads live under
`Cheats/File-Replacements/`; normal cheat discovery skips that reserved tree.
Collapsed groups support single/multiple choices. Information is available
through `[i]` or right-click **Information**. Statuses remain ACTIVE / READY /
NEEDS RESET / ERROR / UNAVAILABLE; enabled names/credits appear in recordings.

Choose **Reset Game** to change selections. Only already-active Fixed Range
payloads support **Reload Active**; whole/resized files require reset. ISO bytes
are never rewritten. Keep the matched Patch 300 and addon ZIP together.

## Portable paths

Linux AppImages use their real containing directory for Cheats, DEBUG and Labels,
not the temporary read-only mount. Non-AppImage builds use xemu's relocated
executable directory. Folder-HDD and Video Recorder keep their existing roots.

## Validation

From a reconstructed source root, run the default full-stack tests with:

```sh
python3 ui/xui/debug-tools/tests/v287-run-regression-tests.py --root .
```

For Patch 300 only, add `--optional-patches none`; for a subset, declare e.g.
`--optional-patches 10,40`. See [test instructions](tests/README.md). Declaring
a patch keeps its assertions mandatory. Source/native tests do not replace a
full platform build and runtime test. v3.16e is a cleanup candidate, not a binary.
