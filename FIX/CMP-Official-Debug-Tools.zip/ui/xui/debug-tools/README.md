# XEMU Debug Tools

Debug Tools and its optional addons are owned by this subtree.
The supported packaged build entry point is **Build-All.bat** in the matrix
builder package; it calls **Build-XemuMatrix.ps1**. The retired standalone
MINGW64 and Docker BAT launchers are no longer distributed.

## Code types

Read [XEMU Code Types - Simple User Guide](Codetypes/XEMU-Code-Types-Guide.pdf)
for file setup, RAW code types, conditions, pointer chains, F0/F1/F2 hooks,
PREENTRY patches, and worked examples. Example addresses are illustrative,
not ready-made codes for a particular game.

## Ownership

- Core files: Current Game, RAW Cheat Engine, shared services and integration facade.
- `addons/`: Folder-HDD, Video Recorder, HDD browser, memory tools and Diagnostics.
- `backend/`: guest/debugger backend interfaces.
- `tools/`: active build, dependency and validation helpers.
- `tests/`: source guards and native regression tests.
- `Codetypes/`: user-facing code-types PDF; the old `docs/` folder is retired.

Patch 300 keeps the necessary upstream integration and observation hooks.
Addon implementations stay in their addon folders. Detached UI rendering stays
outside BQL; guest operations keep the existing synchronized paths.

## Build profiles

`main`, `main+hdd`, `main+memory`, `full`, and `folder-hdd` remain supported.
Option 4 is All Addons and Debug Tools. Option 5 is Folder-HDD + Video Recorder
without Debug Tools. The internal option-5 profile key remains `folder-hdd`.

## Validation

From a reconstructed XEMU source root:

```sh
python3 ui/xui/debug-tools/tests/v287-run-regression-tests.py --root .
```

The suite is not a substitute for a full platform build and runtime test.
