//
// xemu mounted-disc BlockBackend bridge
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "qemu/osdep.h"
#include "qemu/main-loop.h"

#include "system/block-backend-global-state.h"
#include "system/block-backend-io.h"

#include "disc-block-io.h"
#include "block/block_int.h"
#include "block/block-io.h"

XemuDiscBlockHandle xemu_disc_block_by_name(const char *name)
{
    return (XemuDiscBlockHandle)blk_by_name(name);
}

XemuDiscBlockHandle xemu_disc_block_acquire_by_name(const char *name)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = blk_by_name(name);
    if (blk != NULL) {
        blk_ref(blk);
    }
    return (XemuDiscBlockHandle)blk;
}

void xemu_disc_block_release(XemuDiscBlockHandle handle)
{
    if (handle == NULL) {
        return;
    }
    BQL_LOCK_GUARD();
    blk_unref((BlockBackend *)handle);
}

bool xemu_disc_block_is_available(XemuDiscBlockHandle handle)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    return blk != NULL && blk_bs(blk) != NULL && blk_is_available(blk);
}

uintptr_t xemu_disc_block_identity(XemuDiscBlockHandle handle)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    return blk != NULL ? (uintptr_t)blk_bs(blk) : 0;
}

char *xemu_disc_block_source_path(XemuDiscBlockHandle handle)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    BlockDriverState *bs = blk ? blk_bs(blk) : NULL;
    return bs ? g_strdup(bs->exact_filename[0] ? bs->exact_filename
                                              : bs->filename) : NULL;
}

bool xemu_disc_block_is_read_only(XemuDiscBlockHandle handle)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    return !blk || !blk_bs(blk) || bdrv_is_read_only(blk_bs(blk));
}

int64_t xemu_disc_block_get_length(XemuDiscBlockHandle handle)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    if (blk == NULL || blk_bs(blk) == NULL || !blk_is_available(blk)) {
        return -1;
    }
    return blk_getlength(blk);
}

bool xemu_disc_block_pread(XemuDiscBlockHandle handle, uint64_t offset,
                           void *buffer, size_t size)
{
    BQL_LOCK_GUARD();
    BlockBackend *blk = (BlockBackend *)handle;
    if (blk == NULL || buffer == NULL || offset > INT64_MAX ||
        size > INT64_MAX) {
        return false;
    }

    return blk_pread(blk, (int64_t)offset, (int64_t)size, buffer,
                     (BdrvRequestFlags)0) >= 0;
}
