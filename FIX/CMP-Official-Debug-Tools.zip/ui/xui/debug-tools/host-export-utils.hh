//
// xemu Debug Tools - shared host export naming helpers
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
#pragma once

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <filesystem>
#include <fcntl.h>
#include <string>
#include <system_error>

#include <glib/gstdio.h>

namespace XemuHostExportUtils {

inline bool IsReservedWindowsDeviceName(const std::string &name)
{
    std::string base = name;
    const size_t dot = base.find('.');
    if (dot != std::string::npos) {
        base.resize(dot);
    }
    std::transform(base.begin(), base.end(), base.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    if (base == "CON" || base == "PRN" || base == "AUX" || base == "NUL") {
        return true;
    }
    return base.size() == 4 &&
           (base.rfind("COM", 0) == 0 || base.rfind("LPT", 0) == 0) &&
           base[3] >= '1' && base[3] <= '9';
}

inline std::string HostSafeName(const std::string &name)
{
    std::string out;
    out.reserve(name.size());
    for (unsigned char c : name) {
        if (c < 0x20 || c == '<' || c == '>' || c == ':' || c == '"' ||
            c == '/' || c == '\\' || c == '|' || c == '?' || c == '*') {
            out.push_back('_');
        } else {
            out.push_back(static_cast<char>(c));
        }
    }
    if (!out.empty() && (out.back() == ' ' || out.back() == '.')) {
        out.back() = '_';
    }
    if (out.empty() || out == "." || out == "..") {
        out = "_";
    }
    if (IsReservedWindowsDeviceName(out)) {
        out.insert(out.begin(), '_');
    }
    return out;
}

inline std::string NumberedCandidate(const std::string &requested,
                                     unsigned index)
{
    namespace fs = std::filesystem;
    const fs::path path(requested);
    if (index == 0) {
        return path.string();
    }
    return (path.parent_path() /
            (path.stem().string() + " (" + std::to_string(index) + ")" +
             path.extension().string())).string();
}

constexpr unsigned kUniquePathAttempts = 10000;

inline bool OpenUniqueHostFile(const std::string &requested, std::string &actual,
                               FILE *&fp, std::string &error,
                               const char *create_error_prefix,
                               const char *open_error_prefix,
                               const char *exhausted_error)
{
    actual.clear();
    fp = nullptr;
    for (unsigned i = 0; i < kUniquePathAttempts; ++i) {
        const std::string candidate = NumberedCandidate(requested, i);
        int flags = O_CREAT | O_EXCL | O_WRONLY;
#ifdef O_BINARY
        flags |= O_BINARY;
#endif
        const int fd = g_open(candidate.c_str(), flags, 0666);
        if (fd < 0) {
            if (errno == EEXIST) {
                continue;
            }
            error = create_error_prefix;
            error += candidate;
            return false;
        }
        fp = fdopen(fd, "wb");
        if (!fp) {
            g_close(fd, nullptr);
            g_remove(candidate.c_str());
            error = open_error_prefix;
            error += candidate;
            return false;
        }
        actual = candidate;
        return true;
    }
    error = exhausted_error;
    return false;
}

inline bool CreateUniqueHostDirectory(const std::string &requested,
                                      std::string &actual, std::string &error,
                                      const char *create_error_prefix,
                                      const char *exhausted_error)
{
    namespace fs = std::filesystem;
    actual.clear();
    for (unsigned i = 0; i < kUniquePathAttempts; ++i) {
        const fs::path candidate(NumberedCandidate(requested, i));
        std::error_code ec;
        if (fs::create_directory(candidate, ec)) {
            actual = candidate.string();
            return true;
        }
        if (ec == std::errc::file_exists) {
            continue;
        }
        if (ec) {
            error = create_error_prefix;
            error += candidate.string();
            return false;
        }
    }
    error = exhausted_error;
    return false;
}

} // namespace XemuHostExportUtils
