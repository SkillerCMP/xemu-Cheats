/*
 * xemu RAW Cheat Engine - target-specific debugger backend
 *
 * Breakpoint/watchpoint design adapted from Josh's xemu debugger backend.
 * Keep this interface plain C so the ImGui C++ frontend never includes
 * target/i386/cpu.h or QEMU target-specific internals directly.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    XEMU_DBG_WATCH_READ = 0x01,
    XEMU_DBG_WATCH_WRITE = 0x02,
};

enum {
    XEMU_DBG_WATCH_HIT_NONE = 0,
    XEMU_DBG_WATCH_HIT_REPORTED = 1,
};

typedef struct XemuDbgWatchpointHit {
    uint32_t watch_address;
    uint32_t hit_address;
    uint32_t length;
    int access_flags;
} XemuDbgWatchpointHit;

/* Execute breakpoints use guest virtual addresses. */
int xemu_dbg_guest_debug_supported(void);
/* Lightweight EIP-only snapshot used by sampled execution tracing. */
int xemu_dbg_get_pc(uint32_t *pc);
int xemu_dbg_bp_insert(uint32_t address);
int xemu_dbg_bp_remove(uint32_t address);

/* Snapshot floating-point/SIMD state without exposing CPUX86State to the
 * common C/C++ debugger frontend. */
int xemu_dbg_get_extra_registers(uint64_t st_low[8], uint16_t st_high[8],
                                 uint64_t mmx[8], uint32_t xmm[8][4],
                                 uint32_t *fctrl, uint32_t *fstat,
                                 uint32_t *fop, uint32_t *mxcsr,
                                 uint8_t *fp_top);

/* Data watchpoints use QEMU's native watchpoint list. TCG consumes it
 * directly; WHPX mirrors it into x86 DR0-DR3 hardware watchpoints, and
 * KVM uses QEMU AccelOps guest-debug hardware break/watchpoints. Stock x86
 * KVM supports Write and Read/Write hardware data breakpoints, but not a
 * reliable Read-only hardware breakpoint. */
int xemu_dbg_wp_supported(void);
int xemu_dbg_wp_access_supported(int access_flags);
int xemu_dbg_wp_insert(uint32_t address, uint32_t length, int access_flags);
int xemu_dbg_wp_remove(uint32_t address, uint32_t length, int access_flags);
int xemu_dbg_wp_get_hit(XemuDbgWatchpointHit *hit);

/* Flush guest translations after Type-F edits the Xbox page table.
 * WHPX reloads CR3 through WHP; TCG flushes its software TLB; KVM/HVF
 * synchronize architectural state and reload CR3 generically. */
int xemu_dbg_flush_guest_translation(void);

/* Full instruction trace support. The current implementation is WHPX-only;
 * lightweight sampled traces are owned by the Memory Tools frontend. */
enum {
    XEMU_DBG_TRACE_STOP_NONE = 0,
    XEMU_DBG_TRACE_STOP_MANUAL,
    XEMU_DBG_TRACE_STOP_SIZE_LIMIT,
    XEMU_DBG_TRACE_STOP_ADDRESS,
    XEMU_DBG_TRACE_STOP_BREAKPOINT,
    XEMU_DBG_TRACE_STOP_ERROR,
};

typedef struct XemuDbgTraceStatus {
    int active;
    int stop_reason;
    uint64_t entry_count;
    uint64_t entry_capacity;
    uint32_t last_eip;
} XemuDbgTraceStatus;

int xemu_dbg_trace_full_supported(void);
int xemu_dbg_trace_full_start(uint32_t initial_eip, uint32_t range_start,
                              uint32_t range_end, uint64_t max_bytes,
                              int stop_address_enabled,
                              uint32_t stop_address);
void xemu_dbg_trace_full_stop(void);
void xemu_dbg_trace_full_get_status(XemuDbgTraceStatus *status);
uint64_t xemu_dbg_trace_full_copy(uint64_t start_index, uint32_t *entries,
                                  uint64_t entry_capacity);

#ifdef __cplusplus
}
#endif
