//
// xemu Current Game Manager UI
//
// Copyright (C) 2026 xemu contributors
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//

#include "current-game.hh"
#include "tab-style.hh"
#include "debug-tools-module.hh"
#include "../font-manager.hh"

#include <string>
#include <vector>
#include <algorithm>
#include <cstdio>

#include <glib.h>


namespace {

static std::string FormatUnixTimestamp(uint32_t value)
{
    if (value == 0) {
        return "00000000";
    }
    GDateTime *dt = g_date_time_new_from_unix_utc((gint64)value);
    if (!dt) {
        char fallback[16];
        std::snprintf(fallback, sizeof(fallback), "%08X", value);
        return fallback;
    }
    gchar *formatted = g_date_time_format(dt, "%Y-%m-%d %H:%M:%S UTC");
    char prefix[16];
    std::snprintf(prefix, sizeof(prefix), "%08X", value);
    std::string result = prefix;
    if (formatted) {
        result += " (";
        result += formatted;
        result += ")";
    }
    g_free(formatted);
    g_date_time_unref(dt);
    return result;
}

static std::string FormatInitFlags(uint32_t flags)
{
    std::string out;
    auto add = [&](const char *name) {
        if (!out.empty()) out += ", ";
        out += name;
    };
    if (flags & 0x00000001u) add("Mount Utility Drive");
    if (flags & 0x00000002u) add("Format Utility Drive");
    if (flags & 0x00000004u) add("Limit 64 MB");
    if (flags & 0x00000008u) add("Don't Setup HDD");
    if (out.empty()) out = "None";
    return out;
}

static std::string FormatAllowedMedia(uint32_t media)
{
    std::string out;
    auto add = [&](uint32_t flag, const char *name) {
        if ((media & flag) == 0) return;
        if (!out.empty()) out += ", ";
        out += name;
    };
    add(0x00000001u, "HDD");
    add(0x00000002u, "DVD-X2");
    add(0x00000004u, "DVD/CD");
    add(0x00000008u, "CD");
    add(0x00000010u, "DVD5 RO");
    add(0x00000020u, "DVD9 RO");
    add(0x00000040u, "DVD5 RW");
    add(0x00000080u, "DVD9 RW");
    add(0x00000100u, "Dongle");
    add(0x00000200u, "Media Board");
    add(0x40000000u, "Nonsecure HDD");
    add(0x80000000u, "Nonsecure Mode");
    if (out.empty()) out = "None/Unknown";
    return out;
}

static std::string FormatSectionFlags(uint32_t flags)
{
    std::string out;
    auto add = [&](const char *name) {
        if (!out.empty()) out += "|";
        out += name;
    };
    if (flags & 0x01u) add("W");
    if (flags & 0x02u) add("PRE");
    if (flags & 0x04u) add("X");
    if (flags & 0x08u) add("INS");
    if (flags & 0x10u) add("HRO");
    if (flags & 0x20u) add("TRO");
    if (out.empty()) out = "-";
    return out;
}

static const char *FormatApproved(uint8_t approved)
{
    switch (approved) {
    case 0: return "No";
    case 1: return "Possible";
    case 2: return "Yes";
    default: return "Reserved";
    }
}

static const CurrentGameManager::XbeSectionInfo *FindTextSection(
    const CurrentGameManager::GameInfo &info)
{
    const auto it = std::find_if(
        info.sections.begin(), info.sections.end(),
        [](const CurrentGameManager::XbeSectionInfo &section) {
            return section.name == ".text";
        });
    return it == info.sections.end() ? nullptr : &*it;
}

} // namespace

void CurrentGameManager::DrawInlineSummary(const char *id) const
{
    ImGui::PushID(id);
    if (!m_info.valid) {
        ImGui::TextDisabled("Current Game: No XBE detected");
        ImGui::PopID();
        return;
    }

    const std::string title_id = FormatTitleId(m_info.title_id);
    const char *name = m_info.title_name.empty() ? "Unknown title" : m_info.title_name.c_str();
    ImGui::Text("Current Game: %s", name);
    ImGui::SameLine();
    ImGui::TextDisabled("[%s]", title_id.c_str());
    ImGui::SameLine();
    ImGui::TextDisabled("Rev %08X / Disc %u", m_info.version,
                        m_info.disc_number);
    if (ImGui::IsItemHovered()) {
        ImGui::BeginTooltip();
        ImGui::Text("Region: %s", FormatRegion(m_info.region).c_str());
        ImGui::Text("Identity SHA-256: %s", m_info.header_sha256.c_str());
        ImGui::Text("Raw Header SHA-256: %s", m_info.raw_header_sha256.c_str());
        if (!m_info.disc_xbe_sha256.empty()) {
            ImGui::Text("Disc default.xbe SHA-256: %s",
                        m_info.disc_xbe_sha256.c_str());
        }
        ImGui::Text("Revision key: %s", m_info.revision_key.c_str());
        ImGui::EndTooltip();
    }
    ImGui::PopID();
}
void CurrentGameManager::DrawGameInfoTab(bool detached)
{
    if (!m_info.valid) {
        ImGui::TextUnformatted("No running XBE detected.");
        ImGui::TextDisabled("Start a game or dashboard XBE and it will appear here automatically.");
        if (!m_info.disc_xbe_sha256.empty()) {
            ImGui::Separator();
            ImGui::TextWrapped("Disc default.xbe SHA-256   %s",
                               m_info.disc_xbe_sha256.c_str());
        }
        return;
    }

    const bool use_main_fixed_font =
        !detached && g_font_mgr.m_fixed_width_font != nullptr;
    if (use_main_fixed_font) {
        ImGui::PushFont(g_font_mgr.m_fixed_width_font);
    }

    // Keep the everyday identity fields visible. Everything below is advanced
    // XBE detail and intentionally starts collapsed on a fresh UI session.
    ImGui::Text("Title Name       %s",
                m_info.title_name.empty() ? "<unknown>" : m_info.title_name.c_str());
    ImGui::Text("Title ID         %s", FormatTitleId(m_info.title_id).c_str());
    ImGui::Text("Database GameID  %s",
                FormatDatabaseGameId(m_info.title_id).c_str());
    ImGui::Text("Region           %s", FormatRegion(m_info.region).c_str());
    ImGui::Text("Disc Number      %u", m_info.disc_number);
    ImGui::Text("Version          %08X", m_info.version);
    ImGui::Spacing();

    if (ImGui::CollapsingHeader("XBE")) {
        ImGui::Text("XBE Base              %08X", m_info.xbe_base);
        ImGui::Text("Header Size           %08X", m_info.xbe_header_size);
        ImGui::Text("Image Header Size     %08X", m_info.xbe_image_header_size);
        ImGui::Text("XBE Image Size        %08X", m_info.xbe_image_size);
        ImGui::Text("XBE Timestamp         %s",
                    FormatUnixTimestamp(m_info.xbe_timestamp).c_str());
        ImGui::Text("Executable Type       %s", m_info.executable_type.c_str());
        ImGui::Text("Entry Point           %08X (encoded %08X)",
                    m_info.entry_point, m_info.entry_point_encoded);
        ImGui::Text("TLS Address           %08X", m_info.tls_address);
        ImGui::Text("Init Flags            %08X", m_info.xbe_init_flags);
        ImGui::TextWrapped("Init Flags Meaning    %s",
                           FormatInitFlags(m_info.xbe_init_flags).c_str());
        ImGui::Text("Stack Size            %08X", m_info.stack_size);
        ImGui::Text("PE Heap Reserve       %08X", m_info.pe_heap_reserve);
        ImGui::Text("PE Heap Commit        %08X", m_info.pe_heap_commit);
        ImGui::Text("PE Base               %08X", m_info.pe_base);
        ImGui::Text("PE Image Size         %08X", m_info.pe_image_size);
        ImGui::Text("PE Checksum           %08X", m_info.pe_checksum);
        ImGui::Text("PE Timestamp          %s",
                    FormatUnixTimestamp(m_info.pe_timestamp).c_str());
        ImGui::Text("Kernel Thunk          %08X (encoded %08X)",
                    m_info.kernel_thunk_address, m_info.kernel_thunk_encoded);
        ImGui::Text("Non-Kernel Imports    %08X",
                    m_info.nonkernel_import_address);
        ImGui::Text("Logo Bitmap           %08X / %08X bytes",
                    m_info.logo_bitmap_address, m_info.logo_bitmap_size);
        ImGui::Text("Sections              %u", m_info.section_count);
        ImGui::Text("Library Versions      %u", m_info.library_version_count);
        ImGui::Text("XBE-derived Labels    %zu", m_auto_labels.labels.size());
    }

    if (ImGui::CollapsingHeader("Certificate")) {
        ImGui::Text("Certificate Size      %08X", m_info.certificate_size);
        ImGui::Text("Certificate Timestamp %s",
                    FormatUnixTimestamp(m_info.certificate_timestamp).c_str());
        ImGui::Text("Title ID              %s", FormatTitleId(m_info.title_id).c_str());
        ImGui::Text("Title Name            %s",
                    m_info.title_name.empty() ? "<unknown>" : m_info.title_name.c_str());
        ImGui::Text("Region                %08X (%s)", m_info.region,
                    FormatRegion(m_info.region).c_str());
        ImGui::Text("Allowed Media         %08X", m_info.allowed_media);
        ImGui::TextWrapped("Allowed Media Types   %s",
                           FormatAllowedMedia(m_info.allowed_media).c_str());
        ImGui::Text("Game Ratings          %08X", m_info.game_ratings);
        ImGui::Text("Disc Number           %u", m_info.disc_number);
        ImGui::Text("Version               %08X", m_info.version);
        if (m_info.alternate_title_ids.empty()) {
            ImGui::Text("Alternate Title IDs   <none>");
        } else {
            ImGui::Text("Alternate Title IDs   %zu", m_info.alternate_title_ids.size());
            for (uint32_t id : m_info.alternate_title_ids) {
                ImGui::BulletText("%s", FormatTitleId(id).c_str());
            }
        }
        ImGui::Text("LAN Key               %s",
                    m_info.lan_key_present ? "Present" : "Not Present");
        ImGui::Text("Signature Key         %s",
                    m_info.signature_key_present ? "Present" : "Not Present");
        if (m_info.original_certificate_size != 0 ||
            m_info.online_service != 0 || m_info.security_flags != 0 ||
            m_info.code_encryption_key_present) {
            ImGui::Separator();
            ImGui::Text("Original Cert Size    %08X",
                        m_info.original_certificate_size);
            ImGui::Text("Online Service ID     %08X", m_info.online_service);
            ImGui::Text("Runtime Security      %08X", m_info.security_flags);
            ImGui::Text("Code Encryption Key   %s",
                        m_info.code_encryption_key_present ? "Present" : "Not Present");
        }
    }

    if (ImGui::CollapsingHeader("Sections")) {
        ImGui::TextDisabled("Stored SHA-1 values are the XBE section integrity digests.");
        const ImGuiTableFlags flags = ImGuiTableFlags_Borders |
                                      ImGuiTableFlags_RowBg |
                                      ImGuiTableFlags_Resizable |
                                      ImGuiTableFlags_ScrollX |
                                      ImGuiTableFlags_ScrollY;
        if (ImGui::BeginTable("##xbe_sections", 8, flags,
                              ImVec2(0.0f, 240.0f))) {
            ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 105.0f);
            ImGui::TableSetupColumn("Flags", ImGuiTableColumnFlags_WidthFixed, 80.0f);
            ImGui::TableSetupColumn("Virtual", ImGuiTableColumnFlags_WidthFixed, 85.0f);
            ImGui::TableSetupColumn("V Size", ImGuiTableColumnFlags_WidthFixed, 85.0f);
            ImGui::TableSetupColumn("Raw Off", ImGuiTableColumnFlags_WidthFixed, 85.0f);
            ImGui::TableSetupColumn("Raw Size", ImGuiTableColumnFlags_WidthFixed, 85.0f);
            ImGui::TableSetupColumn("Refs", ImGuiTableColumnFlags_WidthFixed, 55.0f);
            ImGui::TableSetupColumn("SHA-1", ImGuiTableColumnFlags_WidthFixed, 330.0f);
            ImGui::TableHeadersRow();
            for (const XbeSectionInfo &section : m_info.sections) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0);
                ImGui::TextUnformatted(section.name.c_str());
                ImGui::TableSetColumnIndex(1);
                const std::string section_flags = FormatSectionFlags(section.flags);
                ImGui::TextUnformatted(section_flags.c_str());
                ImGui::TableSetColumnIndex(2);
                ImGui::Text("%08X", section.virtual_address);
                ImGui::TableSetColumnIndex(3);
                ImGui::Text("%08X", section.virtual_size);
                ImGui::TableSetColumnIndex(4);
                ImGui::Text("%08X", section.raw_address);
                ImGui::TableSetColumnIndex(5);
                ImGui::Text("%08X", section.raw_size);
                ImGui::TableSetColumnIndex(6);
                ImGui::Text("%u", section.reference_count);
                ImGui::TableSetColumnIndex(7);
                ImGui::TextUnformatted(section.sha1.c_str());
            }
            ImGui::EndTable();
        }
    }

    if (ImGui::CollapsingHeader("XDK")) {
        if (m_info.libraries.empty()) {
            ImGui::TextDisabled("No XBE library-version records were found in the copied headers.");
        } else {
            const ImGuiTableFlags flags = ImGuiTableFlags_Borders |
                                          ImGuiTableFlags_RowBg |
                                          ImGuiTableFlags_Resizable |
                                          ImGuiTableFlags_ScrollY;
            if (ImGui::BeginTable("##xbe_libraries", 6, flags,
                                  ImVec2(0.0f, 185.0f))) {
                ImGui::TableSetupColumn("Library", ImGuiTableColumnFlags_WidthFixed, 115.0f);
                ImGui::TableSetupColumn("Version", ImGuiTableColumnFlags_WidthFixed, 85.0f);
                ImGui::TableSetupColumn("Build", ImGuiTableColumnFlags_WidthFixed, 70.0f);
                ImGui::TableSetupColumn("QFE", ImGuiTableColumnFlags_WidthFixed, 60.0f);
                ImGui::TableSetupColumn("Approved", ImGuiTableColumnFlags_WidthFixed, 85.0f);
                ImGui::TableSetupColumn("Debug", ImGuiTableColumnFlags_WidthFixed, 65.0f);
                ImGui::TableHeadersRow();
                for (const XbeLibraryInfo &library : m_info.libraries) {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::TextUnformatted(library.name.c_str());
                    ImGui::TableSetColumnIndex(1);
                    ImGui::Text("%u.%u", (unsigned)library.major,
                                (unsigned)library.minor);
                    ImGui::TableSetColumnIndex(2);
                    ImGui::Text("%u", (unsigned)library.build);
                    ImGui::TableSetColumnIndex(3);
                    ImGui::Text("%u", (unsigned)library.qfe);
                    ImGui::TableSetColumnIndex(4);
                    ImGui::TextUnformatted(FormatApproved(library.approved));
                    ImGui::TableSetColumnIndex(5);
                    ImGui::TextUnformatted(library.debug_build ? "Yes" : "No");
                }
                ImGui::EndTable();
            }
        }
        ImGui::Separator();
        if (m_xdk_status.build != 0) {
            ImGui::Text("XDK Label Build       %u", (unsigned)m_xdk_status.build);
            ImGui::Text("XDK Libraries         %zu/%zu", m_xdk_status.found_libraries,
                        m_xdk_status.required_libraries);
            ImGui::Text("XDK Signatures        %zu", m_xdk_status.signatures);
            ImGui::Text("XDK Exact Labels      %zu", m_xdk_status.exact_matches);
            ImGui::Text("XDK Cache             %s",
                        m_xdk_status.cache_rebuilt ? "Rebuilt" :
                        (m_xdk_status.cache_loaded ? "Loaded" :
                         (m_xdk_status.cache_found ? "Found" : "Not Built")));
        } else {
            ImGui::TextDisabled("No XDK label-library match is currently active.");
        }
        if (!m_xdk_status.message.empty()) {
            ImGui::TextWrapped("XDK Status            %s", m_xdk_status.message.c_str());
        }
    }

    if (ImGui::CollapsingHeader("Identity / Hashes")) {
        ImGui::TextWrapped("Identity SHA-256      %s", m_info.header_sha256.c_str());
        ImGui::TextWrapped("Raw Header SHA-256    %s", m_info.raw_header_sha256.c_str());
        ImGui::Text("Revision Key           %s", m_info.revision_key.c_str());
        const XbeSectionInfo *text_section = FindTextSection(m_info);
        if (text_section) {
            ImGui::TextWrapped(".text Section SHA-1   %s", text_section->sha1.c_str());
        }
        ImGui::TextWrapped("XBE SHA-256 (Disc)     %s",
                           m_info.disc_xbe_sha256.empty()
                               ? "<default.xbe unavailable>"
                               : m_info.disc_xbe_sha256.c_str());
        if (!m_info.disc_xbe_sha256.empty()) {
            ImGui::Text("XBE Disc Size          %08X", m_info.disc_xbe_size);
            ImGui::Text("XBE Start Sector      %08X", m_info.disc_xbe_start_sector);
            ImGui::Text("XBE Disc Offset       %016llX",
                        (unsigned long long)m_info.disc_xbe_offset);
        }
        ImGui::Spacing();
        ImGui::TextDisabled("Identity SHA-256 normalizes Certificate Title Name + Region.");
        ImGui::TextDisabled("The 256-byte XBE digital signature is also normalized because it authenticates those header bytes.");
        ImGui::TextDisabled("Raw Header SHA-256 is retained only for diagnostics and legacy file matching.");
    }

    if (ImGui::CollapsingHeader("Labels / Symbols")) {
        ImGui::Text("Current Labels         %zu", m_labels.labels.size());
        ImGui::Text("Label Packs            %zu", m_loaded_label_packs.size());
        if (m_xbe_pdb_identity.valid) {
            const std::string pdb_guid =
                XemuPdbLabels::FormatGuid(m_xbe_pdb_identity.guid);
            ImGui::Separator();
            ImGui::TextWrapped("XBE PDB Path          %s",
                               m_xbe_pdb_identity.path.c_str());
            ImGui::Text("XBE PDB GUID          %s", pdb_guid.c_str());
            ImGui::Text("XBE PDB Age           %u",
                        (unsigned)m_xbe_pdb_identity.age);
        }
        if (m_map_status.parsed) {
            ImGui::Separator();
            ImGui::Text("MAP Timestamp         %08X (%s)", m_map_status.timestamp,
                        m_map_status.timestamp_match ? "MATCH" : "MISMATCH");
            ImGui::Text("MAP Symbols           %zu", m_map_status.parsed_symbols);
            ImGui::Text("MAP Sections          %zu", m_map_status.mapped_segments);
            ImGui::Text("MAP Exact Labels      %zu", m_map_status.resolved_labels);
            if (!m_loaded_map_path.empty()) {
                ImGui::TextWrapped("MAP File              %s", m_loaded_map_path.c_str());
            }
        }
        if (m_pdb_status.parsed) {
            ImGui::Separator();
            ImGui::Text("PDB GUID              %s (%s)", m_pdb_status.pdb_guid.c_str(),
                        m_pdb_status.guid_match ? "MATCH" : "MISMATCH");
            ImGui::Text("PDB Age               %u / XBE %u (%s)",
                        (unsigned)m_pdb_status.pdb_age,
                        (unsigned)m_pdb_status.xbe_age,
                        m_pdb_status.age_match ? "MATCH" : "MISMATCH");
            ImGui::Text("PDB Publics           %zu", m_pdb_status.public_symbols);
            ImGui::Text("PDB Sections          %zu (%s)", m_pdb_status.mapped_sections,
                        m_pdb_status.layout_match ? "MATCH" : "MISMATCH");
            ImGui::Text("PDB Exact Labels      %zu", m_pdb_status.resolved_labels);
            if (!m_loaded_pdb_path.empty()) {
                ImGui::TextWrapped("PDB File              %s", m_loaded_pdb_path.c_str());
            }
        }
        if (!m_label_status.empty()) {
            ImGui::TextWrapped("Labels Status          %s", m_label_status.c_str());
        }
        if (!m_map_status.message.empty()) {
            ImGui::TextWrapped("MAP Status             %s", m_map_status.message.c_str());
        }
        if (!m_pdb_status.message.empty()) {
            ImGui::TextWrapped("PDB Status             %s", m_pdb_status.message.c_str());
        }
    }

    if (use_main_fixed_font) {
        ImGui::PopFont();
    }

    ImGui::Spacing();
    ImGui::TextDisabled("Advanced XBE sections are collapsed by default; open only what you need.");
    ImGui::TextDisabled(".xlabel packs use XBE section-relative locations; Physical addresses are resolved live and are never persisted.");
    if (!m_disc_status.empty()) {
        ImGui::TextDisabled("Disc: %s", m_disc_status.c_str());
    }
}
void CurrentGameManager::DrawDiscEntry(const XemuXdvdfs::Entry &entry,
                                       std::vector<std::string> &path)
{
    std::vector<std::string> entry_path = path;
    entry_path.push_back(entry.name);

    ImGui::TableNextRow();
    ImGui::TableSetColumnIndex(0);

    ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow |
                               ImGuiTreeNodeFlags_OpenOnDoubleClick |
                               ImGuiTreeNodeFlags_SpanAvailWidth;
    if (!entry.IsDirectory()) {
        flags |= ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
    }

    const bool open = ImGui::TreeNodeEx((const void *)&entry, flags,
                                        "%s", entry.name.c_str());
    if (ImGui::BeginPopupContextItem()) {
        if (ImGui::BeginMenu("Export")) {
            const char *label = entry.IsDirectory() ? "Export Folder..." : "Export File...";
            if (ImGui::MenuItem(label)) {
                RequestDiscExport(entry, entry_path);
            }
            ImGui::EndMenu();
        }
        if (ImGui::MenuItem("Copy Disc Path")) {
            std::string disc_path = "D:\\";
            for (size_t i = 0; i < entry_path.size(); ++i) {
                if (i != 0) {
                    disc_path += "\\";
                }
                disc_path += entry_path[i];
            }
            ImGui::SetClipboardText(disc_path.c_str());
            m_disc_export_status = "Copied disc path: " + disc_path;
        }
        ImGui::TextDisabled("Read-only XDVDFS export; the disc image is never modified.");
        ImGui::EndPopup();
    }

    ImGui::TableSetColumnIndex(1);
    ImGui::TextUnformatted(entry.IsDirectory() ? "Folder" : "File");

    ImGui::TableSetColumnIndex(2);
    const std::string size = FormatByteSize(entry.size);
    ImGui::TextUnformatted(entry.IsDirectory() ? "-" : size.c_str());

    ImGui::TableSetColumnIndex(3);
    ImGui::Text("%08X", entry.start_sector);

    ImGui::TableSetColumnIndex(4);
    ImGui::Text("%016llX", (unsigned long long)entry.disc_offset);

    if (entry.IsDirectory() && open) {
        path.push_back(entry.name);
        for (const XemuXdvdfs::Entry &child : entry.children) {
            DrawDiscEntry(child, path);
        }
        path.pop_back();
        ImGui::TableSetColumnIndex(0);
        ImGui::TreePop();
    }
}
void CurrentGameManager::DrawDiscContentsTab()
{
    if (!m_disc.valid) {
        ImGui::TextUnformatted("Disc contents are not available.");
        if (!m_disc_status.empty()) {
            ImGui::TextWrapped("%s", m_disc_status.c_str());
        }
        ImGui::Spacing();
        ImGui::TextDisabled("This viewer reads the XDVDFS filesystem directly from the currently mounted ide0-cd1 DVD backend.");
        return;
    }

    ImGui::Text("Xbox DVD (D:\\)   %zu files / %zu folders",
                m_disc.file_count, m_disc.directory_count);
    ImGui::SameLine();
    ImGui::TextDisabled("XDVDFS base %016llX",
                        (unsigned long long)m_disc.filesystem_base);
    if (!m_info.disc_xbe_sha256.empty()) {
        ImGui::TextDisabled("default.xbe SHA-256: %s",
                            m_info.disc_xbe_sha256.c_str());
    }
    ImGui::Separator();
    ImGui::TextDisabled("Right-click a disc file/folder to Export or copy its D:\\ path.");
    if (!m_disc_export_status.empty()) {
        ImGui::TextWrapped("%s", m_disc_export_status.c_str());
    }

    const ImGuiTableFlags table_flags = ImGuiTableFlags_BordersInnerV |
                                        ImGuiTableFlags_BordersOuter |
                                        ImGuiTableFlags_RowBg |
                                        ImGuiTableFlags_Resizable |
                                        ImGuiTableFlags_ScrollY |
                                        ImGuiTableFlags_SizingStretchProp;
    if (ImGui::BeginTable("##xdvdfs_contents", 5, table_flags,
                          ImVec2(0.0f, 0.0f))) {
        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch, 3.0f);
        ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthFixed, 70.0f);
        ImGui::TableSetupColumn("Size", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupColumn("Sector", ImGuiTableColumnFlags_WidthFixed, 90.0f);
        ImGui::TableSetupColumn("Disc Offset", ImGuiTableColumnFlags_WidthFixed, 145.0f);
        ImGui::TableHeadersRow();

        std::vector<std::string> path;
        for (const XemuXdvdfs::Entry &entry : m_disc.root_entries) {
            DrawDiscEntry(entry, path);
        }
        ImGui::EndTable();
    }
}
void CurrentGameManager::Draw(bool detached)
{
    if (!is_open) {
        return;
    }

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse;
    const char *window_name = "Current Game";
    bool *window_open = &is_open;
    if (detached) {
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize, ImGuiCond_Always);
        flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings;
        window_name = "##DetachedCurrentGame";
        window_open = nullptr;
    } else {
        ImGui::SetNextWindowSize(ImVec2(860, 520), ImGuiCond_FirstUseEver);
    }
    if (!ImGui::Begin(window_name, window_open, flags)) {
        ImGui::End();
        return;
    }

    if (ImGui::Button("Refresh Now")) {
        RequestRefresh();
    }
    ImGui::SameLine();
    ImGui::TextDisabled("Queues a synchronized refresh of the running XBE and mounted Xbox DVD");
    ImGui::Separator();

    XemuDebugUi::ScopedTabStyle tab_style;
    if (ImGui::BeginTabBar("##current_game_tabs")) {
        if (ImGui::BeginTabItem("Game Info")) {
            DrawGameInfoTab(detached);
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Disc Contents")) {
            DrawDiscContentsTab();
            ImGui::EndTabItem();
        }
        debug_tools_draw_current_game_extension_tabs(
            m_info.valid ? m_info.title_id : 0);
        ImGui::EndTabBar();
    }
    tab_style.Restore();

    debug_tools_draw_current_game_extension_footer();

    ImGui::End();
}
