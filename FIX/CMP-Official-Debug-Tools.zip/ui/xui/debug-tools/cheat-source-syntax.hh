// Host-side cheat TXT classification. Always inspect the original prefix before
// stripping '$' or asking the Type-F frontend about labels/data. No guest access.
#pragma once
#include <cctype>
#include <string>

namespace XemuCheatSourceSyntax {
// The caller has already trimmed leading/trailing whitespace.
inline bool IsCommentOrBlank(const std::string &text)
{
    return text.empty() || text[0] == ';' || text[0] == '#' ||
           text.compare(0, 2, "//") == 0;
}

inline bool IsBoundary(const std::string &text)
{
    if (text.empty()) return false;
    switch (text[0]) {
    case '!': case '+': case '^': case '%': case '{':
        return true;
    case ':': break;
    default: return false;
    }
    // Retain the existing standalone PREENTRY control (not executable source).
    static constexpr char marker[] = ":PREENTRY:";
    static constexpr size_t length = sizeof(marker) - 1;
    if (text.size() < length) return false;
    for (size_t i = 0; i < length; ++i) {
        if (std::toupper(static_cast<unsigned char>(text[i])) != marker[i])
            return false;
    }
    return text.size() == length ||
           std::isspace(static_cast<unsigned char>(text[length])) ||
           text[length] == ';' || text[length] == '#' ||
           text.compare(length, 2, "//") == 0;
}

// Match the F0/F2 identifier alphabet. A colon alone, whitespace, metadata
// prefixes, and x86 segment overrides are not standalone data labels.
inline bool IsLabelName(const std::string &name)
{
    if (name.empty()) return false;
    const unsigned char first = static_cast<unsigned char>(name[0]);
    if (!(std::isalpha(first) || first == '_' || first == '.' || first == '$'))
        return false;
    for (unsigned char c : name) {
        if (!(std::isalnum(c) || c == '_' || c == '.' || c == '$')) return false;
    }
    return true;
}
} // namespace XemuCheatSourceSyntax
