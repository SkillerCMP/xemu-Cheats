//
// xemu Debug Tools - shared host export result
//
#pragma once

#include <cstdint>
#include <string>

namespace XemuHostExport {

struct Result {
    std::string host_path;
    uint64_t byte_count = 0;
    uint32_t file_count = 0;
    uint32_t directory_count = 0;
    bool directory = false;
};

} // namespace XemuHostExport
