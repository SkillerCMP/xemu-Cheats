//
// xemu Debug Tools - scoped guest pause helper
//
#include "qemu/osdep.h"

#include "guest-pause-guard.hh"

extern "C" {
#include "system/runstate.h"
}

extern "C" {
bool bql_locked(void);
void bql_lock_impl(const char *file, int line);
void bql_unlock(void);
}

namespace {
class XemuDebugBqlGuard
{
public:
    XemuDebugBqlGuard(const char *file, int line)
    {
        if (!bql_locked()) {
            bql_lock_impl(file, line);
            m_owned = true;
        }
    }

    ~XemuDebugBqlGuard()
    {
        if (m_owned) {
            bql_unlock();
        }
    }

    XemuDebugBqlGuard(const XemuDebugBqlGuard &) = delete;
    XemuDebugBqlGuard &operator=(const XemuDebugBqlGuard &) = delete;

private:
    bool m_owned = false;
};
} // namespace

#define BQL_LOCK_GUARD() \
    XemuDebugBqlGuard xemu_debug_bql_guard(__FILE__, __LINE__)

XemuDebugGuestPauseGuard::XemuDebugGuestPauseGuard()
{
    /* Detached Debug Tools may create a coherent guest transaction after the
     * HUD has released BQL. Hold BQL only for the run-state transition; the
     * caller's snapshot/file work proceeds with BQL released while the guest
     * remains paused. */
    BQL_LOCK_GUARD();
    m_was_running = runstate_is_running();
    if (!m_was_running) {
        m_stopped = true;
        return;
    }

    m_stop_result = vm_stop(RUN_STATE_PAUSED);
    m_stopped = !runstate_is_running();
    /* Info: Resume ownership follows an actual paused transition. */
    m_resume = m_stopped;
    m_valid = m_stop_result == 0 && m_stopped;
}

XemuDebugGuestPauseGuard::~XemuDebugGuestPauseGuard()
{
    Resume();
}

void XemuDebugGuestPauseGuard::Resume()
{
    if (!m_resume) {
        return;
    }
    BQL_LOCK_GUARD();
    vm_start();
    m_resume = false;
}

#undef BQL_LOCK_GUARD
