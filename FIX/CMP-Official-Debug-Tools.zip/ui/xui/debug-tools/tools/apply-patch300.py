#!/usr/bin/env python3
"""Apply only the reviewed Debug Tools integration for an explicit core stack.

Independent core fixes are already applied. This helper never implements,
enables or reverses a core fix; it selects its matching observation-only patch.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--patch', required=True, type=Path)
    parser.add_argument('--optional-patches', required=True,
                        help='none or comma-separated enabled core-fix numbers')
    args = parser.parse_args()
    source = args.source.resolve()
    canonical = args.patch.resolve()
    directory = Path(__file__).resolve().parent / 'patch300-variants'
    manifest = json.loads((directory / 'manifest.json').read_text())
    if manifest.get('format') != 1:
        raise ValueError('unsupported Patch 300 integration manifest')
    value = args.optional_patches.strip()
    selected = set() if value == 'none' else {int(n) for n in value.split(',')}
    if not selected <= set(manifest['optional_numbers']):
        raise ValueError('optional fixes are 10,20,30,40,50,60')
    mask = sum(1 << bit for bit, number in enumerate(manifest['variant_numbers'])
               if number in selected)
    key = f'{mask:02x}'
    full = manifest['variants'][manifest['canonical_mask']]
    if sha256(canonical) != full['sha256']:
        raise ValueError('Patch 300 and the Debug Tools ZIP are not the matched pair')
    variant = manifest['variants'][key]
    name = variant['path']
    if Path(name).name != name:
        raise ValueError('invalid integration patch path')
    patch = canonical if key == manifest['canonical_mask'] else directory / name
    if sha256(patch) != variant['sha256']:
        raise ValueError(f'Patch 300 integration {key} failed its checksum')
    for relative, expected in variant['input_sha256'].items():
        rel = PurePosixPath(relative)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('invalid integration source path')
        path = source / relative
        actual = sha256(path) if path.is_file() else None
        if actual != expected:
            raise ValueError(f'Patch 300 {key}: unexpected core source: {relative}')
    command = ['git', '-C', str(source), 'apply', '--whitespace=nowarn']
    subprocess.run(command + ['--check', str(patch)], check=True)
    subprocess.run(command + [str(patch)], check=True)
    enabled = ','.join(str(n) for n in sorted(selected)) or 'none'
    state = {'format': 1, 'mask': key, 'optional_patches': sorted(selected),
             'integration_sha256': variant['sha256']}
    (directory / 'applied.json').write_text(json.dumps(state, indent=2) + '\n')
    print(f'Patch 300: applied Debug Tools integration {key}; core fixes {enabled}')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print(f'Patch 300 ERROR: {error}', file=sys.stderr)
        raise SystemExit(1)
