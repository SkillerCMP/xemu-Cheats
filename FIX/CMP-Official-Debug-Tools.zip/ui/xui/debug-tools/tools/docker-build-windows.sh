#!/usr/bin/env bash
set -euo pipefail

SOURCE=/input
OUT=/output
WORK=/tmp/xemu-github-windows-exact
TOOLCHAIN_LABEL='ghcr.io/xemu-project/xemu-win64-toolchain-gcc:sha-2881edd'

rm -rf "$WORK"
mkdir -p "$WORK/source" "$WORK/buildsrc" "$OUT/logs" "$OUT/dist" "$OUT/source"

# Match build-windows.yml's explicit "Install build helpers" step.
# The pinned toolchain image intentionally does not include curl/cmake.
# GitHub installs them before the Windows build; our combined local Docker run
# also needs curl earlier because it performs the source-package job here too.
export DEBIAN_FRONTEND=noninteractive
{
  echo "Installing GitHub build helpers: curl cmake"
  apt-get update
  apt-get install -qy curl cmake
} 2>&1 | tee "$OUT/logs/install-build-helpers.txt"

# Work on Linux filesystem just like GitHub, never in the Windows bind mount.
cp -a "$SOURCE"/. "$WORK/source"/
cd "$WORK/source"
rm -rf build dist .xemu-native-build-logs
find . -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find . -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete 2>/dev/null || true

# ZIP timestamps have no timezone. A source ZIP produced in UTC and extracted
# on Windows can therefore appear several hours in the future when it is copied
# into this Linux container. Meson rejects such files as clock skew. Clamp only
# future-dated regular source files in this disposable copy; contents and the
# user's original tree are never changed.
python3 - <<'PY_NORMALIZE_SOURCE_TIMES' \
  2>&1 | tee "$OUT/logs/source-timestamp-normalization.txt"
import os
import pathlib
import time

root = pathlib.Path('.')
now = time.time()
safe_time = now - 5.0
changed = 0
for path in root.rglob('*'):
    try:
        if not path.is_file() or path.is_symlink():
            continue
        stat = path.stat()
        if stat.st_mtime > now + 1.0:
            os.utime(path, (min(stat.st_atime, safe_time), safe_time))
            changed += 1
    except FileNotFoundError:
        pass
print(f"Source timestamp normalization: clamped {changed} future-dated file(s).")
PY_NORMALIZE_SOURCE_TIMES

{
  echo "Toolchain image: $TOOLCHAIN_LABEL"
  echo "Build host: $(uname -a)"
  echo "gcc: $(x86_64-w64-mingw32.static-gcc --version | head -1)"
  echo "python: $(python3 --version 2>&1)"
  echo "meson: $(meson --version 2>&1)"
} > "$OUT/logs/environment.txt"

# Match the source job's validation before packaging.
python3 ./ui/xui/debug-tools/tools/validate-project-layout.py --root . \
  2>&1 | tee "$OUT/logs/source-layout-validation.txt"
TEST_DIR=./ui/xui/debug-tools/tests
if [[ -d "$TEST_DIR" ]]; then
  TEST_RUNNER="$TEST_DIR/v287-run-regression-tests.py"
  if [[ ! -f "$TEST_RUNNER" ]]; then
    TEST_RUNNER="$TEST_DIR/run-regression-tests.py"
  fi
  if [[ ! -f "$TEST_RUNNER" ]]; then
    echo "ERROR: Debug Tools tests directory is present but no regression runner was found." \
      | tee "$OUT/logs/source-regression-tests.txt" >&2
    exit 25
  fi
  echo "Debug Tools tests detected; running regression suite." \
    | tee "$OUT/logs/source-regression-tests.txt"
  python3 "$TEST_RUNNER" --root . \
    2>&1 | tee -a "$OUT/logs/source-regression-tests.txt"
else
  echo "Debug Tools tests directory is not present; optional regression tests skipped." \
    | tee "$OUT/logs/source-regression-tests.txt"
fi

python3 ./ui/xui/debug-tools/tools/restore-executable-bits.py --root . --update-git-index \
  2>&1 | tee "$OUT/logs/restore-executable-bits.txt"

# Make the disposable packaged source self-describe the profile that this run
# actually builds. This changes only the Linux working copy inside Docker; the
# user's source-tree build-profile.txt remains untouched. The fresh extraction
# used for the Windows build therefore defaults to the same profile even without
# the environment override.
if [[ -n "${XEMU_DEBUG_TOOLS_PROFILE:-}" ]]; then
  printf '%s\n' "$XEMU_DEBUG_TOOLS_PROFILE" > ./ui/xui/debug-tools/build-profile.txt
fi

# Source packages intentionally do not have to carry a .git directory. The
# GitHub-style archive helper uses git archive, though, so when this build is
# started from one of our distributable source ZIPs create a disposable local
# snapshot repository inside WORK. This never modifies the user's source tree.
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Packaged source has no .git metadata; creating temporary snapshot repository."
  git init -q
  git config user.name "Xemu Debug Tools Build"
  git config user.email "xemu-debug-tools@invalid.local"
  git add -A
  git commit -q -m "Temporary packaged-source snapshot"
fi

# Local release ZIPs can contain Debug Tools files as untracked relative to an
# embedded upstream checkout. Ensure the source-owned shell entry points are
# executable in the Linux working copy, then stage this project subtree so
# archive-source.sh records those modes with the current contents.
chmod +x ./ui/xui/debug-tools/tools/*.sh
git add -A ui/xui/debug-tools
# Debug Tools sources and active helpers are staged from their owning subtree and are already
# included by the subtree staging above; no repository-root additions are needed.

if TAG=$(git describe --tags --match 'v*' 2>/dev/null); then
  PKG_VERSION=${TAG#v}
else
  SHORT_HASH=$(git rev-parse --short HEAD)
  PKG_VERSION="0.0.0-0-unofficial-${SHORT_HASH}"
fi
COMMIT=$(git rev-parse HEAD)
printf '%s' "$PKG_VERSION" > "$OUT/PACKAGE_VERSION.txt"
printf '%s' "$COMMIT" > "$OUT/XEMU_COMMIT.txt"

# Match build.yml: create the same source package, add XEMU_COMMIT/XEMU_VERSION,
# compress with zstd, then build from a fresh extraction of that package.
PKG_NAME="xemu-${PKG_VERSION}"
TAR_FILE="$WORK/${PKG_NAME}.tar"
TAR_PREFIX="./${PKG_NAME}/"
bash ./scripts/archive-source.sh "$TAR_FILE" "$TAR_PREFIX" \
  2>&1 | tee "$OUT/logs/archive-source.txt"

printf '%s' "$COMMIT" > XEMU_COMMIT
printf '%s' "$PKG_VERSION" > XEMU_VERSION
tar -r --file "$TAR_FILE" \
  --transform "s,^./,${TAR_PREFIX}," ./XEMU_COMMIT ./XEMU_VERSION
zstd -f "$TAR_FILE" -o "${TAR_FILE}.zst" \
  2>&1 | tee "$OUT/logs/zstd-source.txt"

# Keep the exact GitHub-style source archive and also emit a convenient ZIP
# beside the Windows build. The ZIP is produced from the same freshly packaged
# source tree that the Windows build consumes, not from the host working tree.
cp -f "${TAR_FILE}.zst" "$OUT/source/${PKG_NAME}.tar.zst"
tar -xf "${TAR_FILE}.zst" -C "$WORK/buildsrc" --strip-components=2
python3 - "$WORK/buildsrc" "$OUT/source/${PKG_NAME}-source.zip" "$PKG_NAME" <<'PY_SOURCE_ZIP'
import datetime
import pathlib
import shutil
import sys
import time
import zipfile

source_root = pathlib.Path(sys.argv[1])
out_zip = pathlib.Path(sys.argv[2])
prefix = sys.argv[3]

# ZIP timestamps do not carry a timezone. Cap stored mtimes a full day in the
# past so a ZIP created in UTC cannot look future-dated when Windows interprets
# it in another timezone. Preserve older source mtimes and Unix mode bits.
zip_safe_cutoff = time.time() - 24 * 60 * 60

with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for path in sorted(source_root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(source_root).as_posix()
        stat = path.stat()
        safe_mtime = min(stat.st_mtime, zip_safe_cutoff)
        dt = datetime.datetime.fromtimestamp(safe_mtime)
        info = zipfile.ZipInfo(f"{prefix}/{rel}", dt.timetuple()[:6])
        info.create_system = 3
        info.external_attr = (stat.st_mode & 0xFFFF) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        with path.open("rb") as src, zf.open(info, "w") as dst:
            shutil.copyfileobj(src, dst, length=1024 * 1024)
PY_SOURCE_ZIP
printf '%s\n' "${XEMU_DEBUG_TOOLS_PROFILE:-source-default}" > "$OUT/source/DEBUG_TOOLS_PROFILE.txt"
sha256sum "$OUT/source/${PKG_NAME}-source.zip" > "$OUT/logs/source-zip.sha256"
sha256sum "$OUT/source/${PKG_NAME}.tar.zst" > "$OUT/logs/source-tar-zst.sha256"

cd "$WORK/buildsrc"

# Match build-windows.yml.
python3 ./ui/xui/debug-tools/tools/validate-project-layout.py --root . \
  2>&1 | tee "$OUT/logs/windows-layout-validation.txt"

export CCACHE_DIR=/tmp/xemu-ccache
export CCACHE_MAXSIZE=512M
export LTO_CACHE_DIR=/tmp/xemu-lto-ccache
export CROSSPREFIX=x86_64-w64-mingw32.static-
mkdir -p "$CCACHE_DIR" "$LTO_CACHE_DIR"
ccache -z >/dev/null 2>&1 || true

opts=(
  "--extra-cflags=-flto-incremental=${LTO_CACHE_DIR} -flto-partition=cache"
  -Db_lto=true
  -Dx86_version=3
)

# Enter xemu through its normal root build.sh. Its single Debug Tools hook line
# redirects once into build-xemu.sh, which prepares Capstone/Keystone and then
# returns to the normal xemu build path with XEMU_DEBUG_TOOLS_BUILD_WRAPPED=1.
set +e
bash ./build.sh -p win64-cross "${opts[@]}" \
  2>&1 | tee "$OUT/logs/build-windows.txt"
build_rc=${PIPESTATUS[0]}
set -e
ccache -s > "$OUT/logs/ccache-stats.txt" 2>&1 || true
if [[ "$build_rc" -ne 0 ]]; then
  echo "Build failed with exit code $build_rc" >&2
  exit "$build_rc"
fi

rm -rf "$OUT/dist"
mkdir -p "$OUT/dist"
cp -a dist/. "$OUT/dist/"

# Record the pre-cv2pdb executable so local results can be audited.
sha256sum "$OUT/dist/xemu.exe" > "$OUT/logs/xemu-pre-cv2pdb.sha256"
stat -c '%n %s bytes' "$OUT/dist/xemu.exe" > "$OUT/logs/xemu-pre-cv2pdb-size.txt"

echo "GitHub-equivalent cross build complete: $PKG_VERSION"
