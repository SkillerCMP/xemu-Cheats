//
// xemu Debug Tools - shared generated-output paths
//
// All Debug Tools generated artifacts live beside xemu.exe under DEBUG/.
//
#pragma once

#include "cheat-engine-memory.h"

#include <SDL3/SDL.h>
#include <glib.h>

#include <string>

namespace XemuDebugOutput {

enum class Folder {
    RamDumps,
    TraceDumps,
    Snapshots,
};

inline const char *FolderName(Folder folder)
{
    switch (folder) {
    case Folder::RamDumps: return "Ram-Dumps";
    case Folder::TraceDumps: return "Trace-Dumps";
    case Folder::Snapshots: return "Snapshots";
    }
    return "DEBUG";
}

inline std::string Join(const std::string &base, const std::string &child)
{
    gchar *path = g_build_filename(base.c_str(), child.c_str(), nullptr);
    if (!path) {
        return {};
    }
    std::string result(path);
    g_free(path);
    return result;
}

inline std::string RootDirectory()
{
    char executable_dir[4096] = {};
    if (!xemu_cheat_get_executable_dir(executable_dir, sizeof(executable_dir))) {
        return {};
    }
    gchar *path = g_build_filename(executable_dir, "DEBUG", nullptr);
    if (!path) {
        return {};
    }
    std::string result(path);
    g_free(path);
    return result;
}

inline std::string Directory(Folder folder)
{
    const std::string root = RootDirectory();
    if (root.empty()) {
        return {};
    }
    return Join(root, FolderName(folder));
}

inline bool EnsureDirectory(Folder folder, std::string *error = nullptr)
{
    const std::string directory = Directory(folder);
    if (directory.empty()) {
        if (error) {
            *error = "Could not determine the DEBUG output directory.";
        }
        return false;
    }
    if (g_mkdir_with_parents(directory.c_str(), 0755) != 0) {
        if (error) {
            *error = "Could not create Debug Tools output directory: " + directory;
        }
        return false;
    }
    return true;
}

inline std::string Timestamp(const char *fallback = "unknown-time")
{
    const char *fallback_value = fallback ? fallback : "unknown-time";
    GDateTime *now = g_date_time_new_now_local();
    if (!now) {
        return fallback_value;
    }
    gchar *formatted = g_date_time_format(now, "%Y%m%d-%H%M%S");
    std::string result = formatted ? formatted : fallback_value;
    g_free(formatted);
    g_date_time_unref(now);
    return result;
}

inline std::string UniqueFilePath(Folder folder, const std::string &stem,
                                  const char *extension)
{
    const std::string directory = Directory(folder);
    if (directory.empty()) {
        return {};
    }
    const char *ext = extension ? extension : "";
    for (unsigned int suffix = 0; suffix < 10000; ++suffix) {
        std::string filename = stem;
        if (suffix != 0) {
            filename += "-" + std::to_string(suffix + 1);
        }
        filename += ext;
        const std::string candidate = Join(directory, filename);
        if (!candidate.empty() && !g_file_test(candidate.c_str(), G_FILE_TEST_EXISTS)) {
            return candidate;
        }
    }
    return {};
}

inline bool OpenDirectory(Folder folder, std::string *error = nullptr)
{
    if (!EnsureDirectory(folder, error)) {
        return false;
    }
    const std::string directory = Directory(folder);
    GError *uri_error = nullptr;
    gchar *absolute = g_canonicalize_filename(directory.c_str(), nullptr);
    gchar *uri = absolute ? g_filename_to_uri(absolute, nullptr, &uri_error)
                          : nullptr;
    const bool ok = uri != nullptr && SDL_OpenURL(uri);
    if (!ok && error) {
        *error = "Unable to open Debug Tools output directory: ";
        *error += uri_error ? uri_error->message : SDL_GetError();
    }
    if (uri_error) {
        g_error_free(uri_error);
    }
    g_free(uri);
    g_free(absolute);
    return ok;
}

} // namespace XemuDebugOutput
